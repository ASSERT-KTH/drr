import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_RED;
        lineRenderer3D0.setWallPaint((java.awt.Paint) color1);
        lineRenderer3D0.setYOffset(0.0d);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        try {
            lineRenderer3D0.drawBackground(graphics2D5, categoryPlot6, rectangle2D7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        int int2 = categoryAxis1.getCategoryLabelPositionOffset();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = org.jfree.chart.axis.CategoryAnchor.START;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor3, (int) 'a', 1, rectangle2D6, rectangleEdge7);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(2);
        java.awt.Font font11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryAxis1.setTickLabelFont((java.lang.Comparable) 2, font11);
        org.jfree.chart.plot.Plot plot13 = categoryAxis1.getPlot();
        int int14 = categoryAxis1.getCategoryLabelPositionOffset();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(categoryAnchor3);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNull(plot13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setInverted(true);
        java.awt.Shape shape3 = dateAxis0.getDownArrow();
        java.awt.Stroke stroke4 = null;
        try {
            dateAxis0.setTickMarkStroke(stroke4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (-1), 10.0d, true);
        stackedBarRenderer3D3.setMaximumBarWidth((-1.0d));
        stackedBarRenderer3D3.setDrawBarOutline(true);
        stackedBarRenderer3D3.setBaseCreateEntities(false, true);
        boolean boolean11 = stackedBarRenderer3D3.getBaseSeriesVisibleInLegend();
        java.awt.Paint paint13 = null;
        stackedBarRenderer3D3.setSeriesItemLabelPaint(1900, paint13, false);
        boolean boolean18 = stackedBarRenderer3D3.getItemVisible((int) (byte) 1, (int) 'a');
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (-1), 10.0d, true);
        double double4 = stackedBarRenderer3D3.getItemMargin();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = stackedBarRenderer3D3.getBaseToolTipGenerator();
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator6 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        stackedBarRenderer3D3.setBaseToolTipGenerator((org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator6);
        java.lang.String str8 = standardCategoryToolTipGenerator6.getLabelFormat();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2d + "'", double4 == 0.2d);
        org.junit.Assert.assertNull(categoryToolTipGenerator5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "({0}, {1}) = {2}" + "'", str8.equals("({0}, {1}) = {2}"));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke2 = dateAxis1.getAxisLineStroke();
        double double3 = dateAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource6 = numberAxis3D5.getStandardTickUnits();
        double double7 = numberAxis3D5.getUpperMargin();
        java.awt.Shape shape8 = numberAxis3D5.getLeftArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer9);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        boolean boolean14 = chartChangeEventType12.equals((java.lang.Object) dateAxis13);
        dateAxis13.setTickMarkOutsideLength((float) 1);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) '#', (double) '#', 0.0d);
        org.jfree.chart.block.LineBorder lineBorder24 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color17, stroke18, rectangleInsets23);
        dateAxis13.setAxisLinePaint((java.awt.Paint) color17);
        dateAxis13.setRangeWithMargins(0.0d, 10.0d);
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis();
        dateAxis29.setInverted(true);
        java.awt.Shape shape32 = dateAxis29.getDownArrow();
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke34 = dateAxis33.getAxisLineStroke();
        boolean boolean35 = dateAxis33.isAutoTickUnitSelection();
        org.jfree.chart.axis.Timeline timeline36 = dateAxis33.getTimeline();
        dateAxis29.setTimeline(timeline36);
        dateAxis13.setTimeline(timeline36);
        dateAxis13.setVerticalTickLabels(false);
        xYPlot10.setRangeAxis(5, (org.jfree.chart.axis.ValueAxis) dateAxis13, false);
        java.awt.Color color43 = java.awt.Color.WHITE;
        xYPlot10.setRangeTickBandPaint((java.awt.Paint) color43);
        org.jfree.chart.axis.AxisSpace axisSpace45 = new org.jfree.chart.axis.AxisSpace();
        java.lang.String str46 = axisSpace45.toString();
        xYPlot10.setFixedRangeAxisSpace(axisSpace45);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(chartChangeEventType12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(timeline36);
        org.junit.Assert.assertNotNull(color43);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        java.awt.Shape shape5 = null;
        java.awt.Stroke stroke6 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color7 = java.awt.Color.RED;
        org.jfree.chart.LegendItem legendItem8 = new org.jfree.chart.LegendItem("", "hi!", "RangeType.NEGATIVE", "RangeType.NEGATIVE", shape5, stroke6, (java.awt.Paint) color7);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D12 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (-1), 10.0d, true);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer13 = stackedBarRenderer3D12.getGradientPaintTransformer();
        legendItem8.setFillPaintTransformer(gradientPaintTransformer13);
        legendItemCollection0.add(legendItem8);
        java.awt.Stroke stroke16 = legendItem8.getLineStroke();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(gradientPaintTransformer13);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (-1), 10.0d, true);
        stackedBarRenderer3D3.setMaximumBarWidth((-1.0d));
        stackedBarRenderer3D3.setDrawBarOutline(true);
        stackedBarRenderer3D3.setBaseCreateEntities(false, true);
        boolean boolean11 = stackedBarRenderer3D3.getAutoPopulateSeriesPaint();
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        segmentedTimeline0.setStartTime((long) 5);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment4 = segmentedTimeline0.getSegment(1900L);
        boolean boolean6 = segment4.contains((long) 7);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline7 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        segmentedTimeline7.setStartTime((long) 5);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment11 = segmentedTimeline7.getSegment(1900L);
        boolean boolean13 = segment11.contains((long) 7);
        segment11.moveIndexToEnd();
        boolean boolean15 = segment4.contains(segment11);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(segment4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(segmentedTimeline7);
        org.junit.Assert.assertNotNull(segment11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = null;
        piePlot0.setLegendLabelToolTipGenerator(pieSectionLabelGenerator1);
        java.awt.Paint paint3 = piePlot0.getShadowPaint();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot0);
        org.jfree.chart.event.ChartProgressListener chartProgressListener5 = null;
        jFreeChart4.addProgressListener(chartProgressListener5);
        int int7 = jFreeChart4.getSubtitleCount();
        int int8 = jFreeChart4.getSubtitleCount();
        jFreeChart4.setAntiAlias(false);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        java.awt.Shape shape4 = null;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color6 = java.awt.Color.RED;
        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("", "hi!", "RangeType.NEGATIVE", "RangeType.NEGATIVE", shape4, stroke5, (java.awt.Paint) color6);
        java.text.AttributedString attributedString8 = legendItem7.getAttributedLabel();
        java.awt.Paint paint9 = legendItem7.getOutlinePaint();
        boolean boolean10 = legendItem7.isShapeVisible();
        boolean boolean11 = legendItem7.isShapeFilled();
        java.awt.Shape shape12 = legendItem7.getLine();
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNull(attributedString8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(shape12);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        org.jfree.chart.renderer.OutlierListCollection outlierListCollection0 = new org.jfree.chart.renderer.OutlierListCollection();
        boolean boolean1 = outlierListCollection0.isHighFarOut();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke2 = dateAxis1.getAxisLineStroke();
        double double3 = dateAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource6 = numberAxis3D5.getStandardTickUnits();
        double double7 = numberAxis3D5.getUpperMargin();
        java.awt.Shape shape8 = numberAxis3D5.getLeftArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer9);
        xYPlot10.clearRangeMarkers((int) (byte) -1);
        xYPlot10.setDomainCrosshairVisible(true);
        org.jfree.chart.LegendItemCollection legendItemCollection15 = xYPlot10.getLegendItems();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = xYPlot10.getRenderer((-1));
        org.jfree.chart.axis.AxisSpace axisSpace18 = null;
        xYPlot10.setFixedDomainAxisSpace(axisSpace18);
        xYPlot10.setRangeCrosshairValue(0.0d, true);
        org.jfree.chart.plot.Marker marker23 = null;
        org.jfree.chart.util.Layer layer24 = org.jfree.chart.util.Layer.BACKGROUND;
        java.lang.String str25 = layer24.toString();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType26 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        boolean boolean28 = chartChangeEventType26.equals((java.lang.Object) dateAxis27);
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation31 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number) 0, (java.lang.Number) (short) 0);
        boolean boolean32 = dateAxis27.equals((java.lang.Object) (short) 0);
        dateAxis27.setAxisLineVisible(false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent35 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis27);
        boolean boolean36 = layer24.equals((java.lang.Object) dateAxis27);
        try {
            xYPlot10.addRangeMarker(marker23, layer24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(legendItemCollection15);
        org.junit.Assert.assertNull(xYItemRenderer17);
        org.junit.Assert.assertNotNull(layer24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Layer.BACKGROUND" + "'", str25.equals("Layer.BACKGROUND"));
        org.junit.Assert.assertNotNull(chartChangeEventType26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, true);
        statisticalLineAndShapeRenderer2.setUseFillPaint(false);
        org.jfree.chart.text.TextFragment textFragment6 = new org.jfree.chart.text.TextFragment("");
        java.awt.Paint paint7 = textFragment6.getPaint();
        java.awt.Paint paint8 = textFragment6.getPaint();
        boolean boolean9 = statisticalLineAndShapeRenderer2.equals((java.lang.Object) textFragment6);
        boolean boolean12 = statisticalLineAndShapeRenderer2.getItemVisible((int) '#', (int) (short) 10);
        statisticalLineAndShapeRenderer2.setUseOutlinePaint(true);
        statisticalLineAndShapeRenderer2.setSeriesLinesVisible(15, (java.lang.Boolean) false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int6 = spreadsheetDate3.compare((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int11 = spreadsheetDate8.compare((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate14);
        boolean boolean16 = spreadsheetDate3.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate10, (org.jfree.data.time.SerialDate) spreadsheetDate14);
        java.lang.Number number18 = defaultStatisticalCategoryDataset0.getMeanValue((java.lang.Comparable) boolean16, (java.lang.Comparable) 100.0d);
        org.jfree.data.Range range20 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, (double) (short) 100);
        org.jfree.data.KeyToGroupMap keyToGroupMap21 = null;
        try {
            org.jfree.data.Range range22 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, keyToGroupMap21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNull(number18);
        org.junit.Assert.assertNull(range20);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        org.jfree.chart.renderer.category.AreaRenderer areaRenderer1 = new org.jfree.chart.renderer.category.AreaRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = areaRenderer1.getSeriesPositiveItemLabelPosition((int) (short) 0);
        java.awt.Stroke stroke4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        areaRenderer1.setBaseOutlineStroke(stroke4, true);
        java.awt.Stroke stroke8 = areaRenderer1.getSeriesStroke(100);
        java.awt.Stroke stroke9 = areaRenderer1.getBaseStroke();
        boolean boolean10 = groupedStackedBarRenderer0.equals((java.lang.Object) areaRenderer1);
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(stroke8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.List list1 = segmentedTimeline0.getExceptionSegments();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        java.awt.Paint paint1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder2 = new org.jfree.chart.block.BlockBorder(paint1);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = chartChangeEventType3.equals((java.lang.Object) dateAxis4);
        java.awt.Stroke stroke6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        dateAxis4.setAxisLineStroke(stroke6);
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker((double) '4', paint1, stroke6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker8);
        valueMarker8.setValue(0.0d);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent12 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker8);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = valueMarker8.getLabelOffset();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType14 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        valueMarker8.setLabelOffsetType(lengthAdjustmentType14);
        java.awt.Stroke stroke16 = valueMarker8.getOutlineStroke();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(chartChangeEventType3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(lengthAdjustmentType14);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("VerticalAlignment.BOTTOM");
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) '#', (double) '#', 0.0d);
        boolean boolean7 = textLine1.equals((java.lang.Object) '#');
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType8 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        boolean boolean10 = chartChangeEventType8.equals((java.lang.Object) dateAxis9);
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation13 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number) 0, (java.lang.Number) (short) 0);
        boolean boolean14 = dateAxis9.equals((java.lang.Object) (short) 0);
        dateAxis9.setAxisLineVisible(false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent17 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis9);
        boolean boolean18 = textLine1.equals((java.lang.Object) axisChangeEvent17);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(chartChangeEventType8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer4 = new org.jfree.chart.renderer.category.LevelRenderer();
        java.awt.Stroke stroke7 = levelRenderer4.getItemOutlineStroke(100, (int) (byte) 0);
        java.awt.Shape shape8 = levelRenderer4.getBaseShape();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D12 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (-1), 10.0d, true);
        double double13 = stackedBarRenderer3D12.getItemMargin();
        java.awt.Paint paint15 = stackedBarRenderer3D12.lookupSeriesOutlinePaint(6);
        try {
            org.jfree.chart.LegendItem legendItem16 = new org.jfree.chart.LegendItem(attributedString0, "CategoryLabelWidthType.RANGE", "hi!", "12/31/69", shape8, paint15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.2d + "'", double13 == 0.2d);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke2 = dateAxis1.getAxisLineStroke();
        double double3 = dateAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource6 = numberAxis3D5.getStandardTickUnits();
        double double7 = numberAxis3D5.getUpperMargin();
        java.awt.Shape shape8 = numberAxis3D5.getLeftArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer9);
        xYPlot10.clearRangeMarkers((int) (byte) -1);
        xYPlot10.setDomainCrosshairVisible(true);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        xYPlot10.setDataset(xYDataset15);
        org.jfree.data.time.DateRange dateRange17 = new org.jfree.data.time.DateRange();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer20 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, true);
        statisticalLineAndShapeRenderer20.setSeriesLinesVisible(100, false);
        statisticalLineAndShapeRenderer20.setBaseLinesVisible(false);
        java.lang.Boolean boolean27 = statisticalLineAndShapeRenderer20.getSeriesItemLabelsVisible((int) (short) 0);
        boolean boolean28 = dateRange17.equals((java.lang.Object) boolean27);
        java.util.Date date29 = dateRange17.getUpperDate();
        org.jfree.data.general.Dataset dataset30 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent31 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) dateRange17, dataset30);
        xYPlot10.datasetChanged(datasetChangeEvent31);
        xYPlot10.clearDomainAxes();
        java.awt.Paint paint34 = xYPlot10.getDomainZeroBaselinePaint();
        xYPlot10.setDomainCrosshairVisible(true);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNull(boolean27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(paint34);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("VerticalAlignment.BOTTOM");
        boolean boolean2 = numberAxis1.isInverted();
        numberAxis1.zoomRange(97.0d, (double) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        java.awt.Paint paint1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder2 = new org.jfree.chart.block.BlockBorder(paint1);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = chartChangeEventType3.equals((java.lang.Object) dateAxis4);
        java.awt.Stroke stroke6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        dateAxis4.setAxisLineStroke(stroke6);
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker((double) '4', paint1, stroke6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker8);
        valueMarker8.setValue(0.0d);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent12 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker8);
        java.awt.Paint paint13 = valueMarker8.getOutlinePaint();
        valueMarker8.setLabel("");
        java.awt.Stroke stroke16 = valueMarker8.getStroke();
        java.lang.String str17 = valueMarker8.getLabel();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(chartChangeEventType3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        java.awt.Shape shape5 = null;
        java.awt.Stroke stroke6 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color7 = java.awt.Color.RED;
        org.jfree.chart.LegendItem legendItem8 = new org.jfree.chart.LegendItem("", "hi!", "RangeType.NEGATIVE", "RangeType.NEGATIVE", shape5, stroke6, (java.awt.Paint) color7);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D12 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (-1), 10.0d, true);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer13 = stackedBarRenderer3D12.getGradientPaintTransformer();
        legendItem8.setFillPaintTransformer(gradientPaintTransformer13);
        legendItemCollection0.add(legendItem8);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer16 = legendItem8.getFillPaintTransformer();
        java.lang.String str17 = legendItem8.getDescription();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(gradientPaintTransformer13);
        org.junit.Assert.assertNotNull(gradientPaintTransformer16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = null;
        piePlot0.setLegendLabelToolTipGenerator(pieSectionLabelGenerator1);
        java.awt.Paint paint3 = piePlot0.getShadowPaint();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot0);
        org.jfree.chart.title.LegendTitle legendTitle5 = jFreeChart4.getLegend();
        java.awt.Font font7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("hi!", font7);
        textTitle8.setURLText("({0}, {1}) = {2}");
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.lang.Object obj14 = textTitle8.draw(graphics2D11, rectangle2D12, (java.lang.Object) "{0}");
        boolean boolean15 = legendTitle5.equals((java.lang.Object) graphics2D11);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint17 = org.jfree.chart.block.RectangleConstraint.NONE;
        java.lang.String str18 = rectangleConstraint17.toString();
        org.jfree.data.Range range21 = new org.jfree.data.Range((double) (-1L), (double) '4');
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = rectangleConstraint17.toRangeHeight(range21);
        org.jfree.chart.util.Size2D size2D23 = legendTitle5.arrange(graphics2D16, rectangleConstraint17);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint25 = rectangleConstraint17.toFixedWidth((double) 3);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType26 = rectangleConstraint25.getHeightConstraintType();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(legendTitle5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNull(obj14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]" + "'", str18.equals("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]"));
        org.junit.Assert.assertNotNull(rectangleConstraint22);
        org.junit.Assert.assertNotNull(size2D23);
        org.junit.Assert.assertNotNull(rectangleConstraint25);
        org.junit.Assert.assertNotNull(lengthConstraintType26);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.block.Block block1 = null;
        java.awt.Paint paint3 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder(paint3);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        boolean boolean7 = chartChangeEventType5.equals((java.lang.Object) dateAxis6);
        java.awt.Stroke stroke8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        dateAxis6.setAxisLineStroke(stroke8);
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) '4', paint3, stroke8);
        centerArrangement0.add(block1, (java.lang.Object) '4');
        java.lang.Object obj12 = null;
        boolean boolean13 = centerArrangement0.equals(obj12);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(chartChangeEventType5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (-1), 10.0d, true);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer4 = stackedBarRenderer3D3.getGradientPaintTransformer();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        boolean boolean9 = chartChangeEventType7.equals((java.lang.Object) dateAxis8);
        java.awt.Stroke stroke10 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        dateAxis8.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis8.getUpArrow();
        org.jfree.chart.plot.Plot plot13 = dateAxis8.getPlot();
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        stackedBarRenderer3D3.drawRangeGridline(graphics2D5, categoryPlot6, (org.jfree.chart.axis.ValueAxis) dateAxis8, rectangle2D14, 1.05d);
        java.awt.Color color17 = java.awt.Color.lightGray;
        stackedBarRenderer3D3.setBaseItemLabelPaint((java.awt.Paint) color17, true);
        java.awt.Shape shape21 = null;
        stackedBarRenderer3D3.setSeriesShape((int) (byte) 1, shape21);
        org.junit.Assert.assertNotNull(gradientPaintTransformer4);
        org.junit.Assert.assertNotNull(chartChangeEventType7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNull(plot13);
        org.junit.Assert.assertNotNull(color17);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        org.jfree.chart.event.TitleChangeListener titleChangeListener3 = null;
        textTitle2.addChangeListener(titleChangeListener3);
        textTitle2.setMargin((double) 100, 0.0d, 0.0d, (double) 100);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        textTitle2.setPosition(rectangleEdge10);
        double double12 = textTitle2.getWidth();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment13 = textTitle2.getTextAlignment();
        textTitle2.setToolTipText("{0}");
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = textTitle2.getMargin();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment13);
        org.junit.Assert.assertNotNull(rectangleInsets16);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.jfree.chart.axis.NumberTick numberTick5 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 0L, "EXPAND", textAnchor2, textAnchor3, (double) 2.0f);
        java.lang.String str6 = numberTick5.toString();
        org.jfree.chart.text.TextAnchor textAnchor7 = numberTick5.getRotationAnchor();
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "EXPAND" + "'", str6.equals("EXPAND"));
        org.junit.Assert.assertNotNull(textAnchor7);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = null;
        piePlot0.setLegendLabelToolTipGenerator(pieSectionLabelGenerator1);
        java.awt.Paint paint3 = piePlot0.getShadowPaint();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot0);
        org.jfree.chart.title.LegendTitle legendTitle5 = jFreeChart4.getLegend();
        java.awt.Font font7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("hi!", font7);
        textTitle8.setURLText("({0}, {1}) = {2}");
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.lang.Object obj14 = textTitle8.draw(graphics2D11, rectangle2D12, (java.lang.Object) "{0}");
        boolean boolean15 = legendTitle5.equals((java.lang.Object) graphics2D11);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint17 = org.jfree.chart.block.RectangleConstraint.NONE;
        java.lang.String str18 = rectangleConstraint17.toString();
        org.jfree.data.Range range21 = new org.jfree.data.Range((double) (-1L), (double) '4');
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = rectangleConstraint17.toRangeHeight(range21);
        org.jfree.chart.util.Size2D size2D23 = legendTitle5.arrange(graphics2D16, rectangleConstraint17);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D27 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (-1), 10.0d, true);
        java.lang.Object obj28 = stackedBarRenderer3D27.clone();
        java.awt.Paint paint29 = stackedBarRenderer3D27.getBaseFillPaint();
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        java.awt.Stroke stroke31 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) '#', (double) '#', 0.0d);
        org.jfree.chart.block.LineBorder lineBorder37 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color30, stroke31, rectangleInsets36);
        double double39 = rectangleInsets36.calculateTopOutset((double) 100.0f);
        java.awt.Paint paint40 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder41 = new org.jfree.chart.block.BlockBorder(rectangleInsets36, paint40);
        boolean boolean42 = org.jfree.chart.util.PaintUtilities.equal(paint29, paint40);
        legendTitle5.setItemPaint(paint29);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(legendTitle5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNull(obj14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]" + "'", str18.equals("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]"));
        org.junit.Assert.assertNotNull(rectangleConstraint22);
        org.junit.Assert.assertNotNull(size2D23);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 10.0d + "'", double39 == 10.0d);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline1 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        segmentedTimeline1.setStartTime((long) 5);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment5 = segmentedTimeline1.getSegment(1900L);
        boolean boolean6 = sortOrder0.equals((java.lang.Object) segmentedTimeline1);
        segmentedTimeline1.addException(128L, 0L);
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertNotNull(segmentedTimeline1);
        org.junit.Assert.assertNotNull(segment5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = null;
        piePlot0.setLegendLabelToolTipGenerator(pieSectionLabelGenerator1);
        java.awt.Paint paint3 = piePlot0.getShadowPaint();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot0);
        org.jfree.chart.title.LegendTitle legendTitle5 = jFreeChart4.getLegend();
        java.awt.Font font7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("hi!", font7);
        textTitle8.setURLText("({0}, {1}) = {2}");
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.lang.Object obj14 = textTitle8.draw(graphics2D11, rectangle2D12, (java.lang.Object) "{0}");
        boolean boolean15 = legendTitle5.equals((java.lang.Object) graphics2D11);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint17 = org.jfree.chart.block.RectangleConstraint.NONE;
        java.lang.String str18 = rectangleConstraint17.toString();
        org.jfree.data.Range range21 = new org.jfree.data.Range((double) (-1L), (double) '4');
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = rectangleConstraint17.toRangeHeight(range21);
        org.jfree.chart.util.Size2D size2D23 = legendTitle5.arrange(graphics2D16, rectangleConstraint17);
        size2D23.setHeight(1.05d);
        double double26 = size2D23.getWidth();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(legendTitle5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNull(obj14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]" + "'", str18.equals("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]"));
        org.junit.Assert.assertNotNull(rectangleConstraint22);
        org.junit.Assert.assertNotNull(size2D23);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        java.awt.Color color4 = java.awt.Color.yellow;
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder(10.0d, (double) 100, (double) 1, (double) 'a', (java.awt.Paint) color4);
        org.jfree.chart.renderer.category.AreaRenderer areaRenderer6 = new org.jfree.chart.renderer.category.AreaRenderer();
        java.lang.Object obj7 = areaRenderer6.clone();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        areaRenderer6.setBaseOutlinePaint((java.awt.Paint) color8);
        org.jfree.chart.renderer.category.AreaRenderer areaRenderer10 = new org.jfree.chart.renderer.category.AreaRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = areaRenderer10.getSeriesPositiveItemLabelPosition((int) (short) 0);
        java.awt.Stroke stroke13 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        areaRenderer10.setBaseOutlineStroke(stroke13, true);
        java.awt.Stroke stroke17 = areaRenderer10.getSeriesStroke(100);
        java.awt.Paint paint19 = areaRenderer10.lookupSeriesPaint(128);
        java.awt.Color color20 = java.awt.Color.gray;
        java.awt.Color color21 = color20.brighter();
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer22 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color4, (java.awt.Paint) color8, paint19, (java.awt.Paint) color21);
        java.awt.Paint paint23 = waterfallBarRenderer22.getNegativeBarPaint();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment24 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment25 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment26 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.ColumnArrangement columnArrangement29 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment25, verticalAlignment26, (double) 100L, (double) 10);
        org.jfree.chart.block.FlowArrangement flowArrangement32 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment24, verticalAlignment26, (double) 0L, (double) (-1.0f));
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        boolean boolean34 = flowArrangement32.equals((java.lang.Object) color33);
        waterfallBarRenderer22.setFirstBarPaint((java.awt.Paint) color33);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(itemLabelPosition12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNull(stroke17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(horizontalAlignment24);
        org.junit.Assert.assertNotNull(horizontalAlignment25);
        org.junit.Assert.assertNotNull(verticalAlignment26);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int9 = spreadsheetDate6.compare((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int14 = spreadsheetDate11.compare((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate17);
        boolean boolean19 = spreadsheetDate6.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate13, (org.jfree.data.time.SerialDate) spreadsheetDate17);
        boolean boolean20 = spreadsheetDate3.isOn((org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.util.Date date21 = spreadsheetDate3.toDate();
        java.util.TimeZone timeZone22 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE = timeZone22;
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date21, timeZone22);
        org.jfree.data.gantt.Task task25 = new org.jfree.data.gantt.Task("LegendItemEntity: seriesKey=null, dataset=null", (org.jfree.data.time.TimePeriod) year24);
        java.lang.Double double26 = task25.getPercentComplete();
        java.lang.String str27 = task25.getDescription();
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNull(double26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "LegendItemEntity: seriesKey=null, dataset=null" + "'", str27.equals("LegendItemEntity: seriesKey=null, dataset=null"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke2 = dateAxis1.getAxisLineStroke();
        double double3 = dateAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource6 = numberAxis3D5.getStandardTickUnits();
        double double7 = numberAxis3D5.getUpperMargin();
        java.awt.Shape shape8 = numberAxis3D5.getLeftArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer9);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        dateAxis13.setInverted(true);
        java.awt.Shape shape16 = dateAxis13.getDownArrow();
        lineAndShapeRenderer11.setSeriesShape((int) (short) 10, shape16);
        dateAxis1.setLeftArrow(shape16);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset21 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        java.util.List list22 = defaultBoxAndWhiskerCategoryDataset21.getRowKeys();
        java.lang.Number number25 = defaultBoxAndWhiskerCategoryDataset21.getValue((java.lang.Comparable) 100, (java.lang.Comparable) (short) 1);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity28 = new org.jfree.chart.entity.CategoryItemEntity(shape16, "AreaRendererEndType.TAPER", "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]", (org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset21, (java.lang.Comparable) (short) 10, (java.lang.Comparable) (-128));
        java.lang.String str29 = categoryItemEntity28.getShapeType();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(list22);
        org.junit.Assert.assertNull(number25);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "poly" + "'", str29.equals("poly"));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("VerticalAlignment.BOTTOM");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = numberAxis1.getMarkerBand();
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint4 = polarPlot3.getRadiusGridlinePaint();
        java.awt.Stroke stroke5 = polarPlot3.getRadiusGridlineStroke();
        numberAxis1.setTickMarkStroke(stroke5);
        org.junit.Assert.assertNull(markerAxisBand2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = numberAxis3D1.getStandardTickUnits();
        double double3 = numberAxis3D1.getUpperMargin();
        java.awt.Shape shape4 = numberAxis3D1.getLeftArrow();
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape4);
        java.lang.String str6 = chartEntity5.toString();
        org.junit.Assert.assertNotNull(tickUnitSource2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "ChartEntity: tooltip = null" + "'", str6.equals("ChartEntity: tooltip = null"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke2 = dateAxis1.getAxisLineStroke();
        double double3 = dateAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource6 = numberAxis3D5.getStandardTickUnits();
        double double7 = numberAxis3D5.getUpperMargin();
        java.awt.Shape shape8 = numberAxis3D5.getLeftArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer9);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        boolean boolean14 = chartChangeEventType12.equals((java.lang.Object) dateAxis13);
        dateAxis13.setTickMarkOutsideLength((float) 1);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) '#', (double) '#', 0.0d);
        org.jfree.chart.block.LineBorder lineBorder24 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color17, stroke18, rectangleInsets23);
        dateAxis13.setAxisLinePaint((java.awt.Paint) color17);
        dateAxis13.setRangeWithMargins(0.0d, 10.0d);
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis();
        dateAxis29.setInverted(true);
        java.awt.Shape shape32 = dateAxis29.getDownArrow();
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke34 = dateAxis33.getAxisLineStroke();
        boolean boolean35 = dateAxis33.isAutoTickUnitSelection();
        org.jfree.chart.axis.Timeline timeline36 = dateAxis33.getTimeline();
        dateAxis29.setTimeline(timeline36);
        dateAxis13.setTimeline(timeline36);
        dateAxis13.setVerticalTickLabels(false);
        xYPlot10.setRangeAxis(5, (org.jfree.chart.axis.ValueAxis) dateAxis13, false);
        java.awt.Color color43 = java.awt.Color.WHITE;
        xYPlot10.setRangeTickBandPaint((java.awt.Paint) color43);
        org.jfree.chart.plot.PlotOrientation plotOrientation45 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        xYPlot10.setOrientation(plotOrientation45);
        java.lang.String str47 = plotOrientation45.toString();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(chartChangeEventType12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(timeline36);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(plotOrientation45);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str47.equals("PlotOrientation.HORIZONTAL"));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int3 = spreadsheetDate2.getDayOfWeek();
        int int4 = spreadsheetDate2.getMonth();
        try {
            org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(10, (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        java.util.List list1 = defaultBoxAndWhiskerCategoryDataset0.getRowKeys();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate4);
        int int6 = spreadsheetDate4.toSerial();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType7 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        boolean boolean8 = spreadsheetDate4.equals((java.lang.Object) gradientPaintTransformType7);
        int int9 = defaultBoxAndWhiskerCategoryDataset0.getColumnIndex((java.lang.Comparable) boolean8);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertNotNull(gradientPaintTransformType7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint1 = polarPlot0.getRadiusGridlinePaint();
        java.awt.Stroke stroke2 = polarPlot0.getRadiusGridlineStroke();
        org.jfree.chart.plot.PlotOrientation plotOrientation3 = polarPlot0.getOrientation();
        boolean boolean4 = polarPlot0.isDomainZoomable();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(plotOrientation3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.plot.Plot plot3 = piePlot0.getParent();
        org.jfree.data.general.PieDataset pieDataset4 = null;
        piePlot0.setDataset(pieDataset4);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator6 = null;
        piePlot0.setLegendLabelToolTipGenerator(pieSectionLabelGenerator6);
        piePlot0.setStartAngle((double) 0.0f);
        piePlot0.setCircular(true, false);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer15 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, true);
        statisticalLineAndShapeRenderer15.setSeriesLinesVisible(100, false);
        statisticalLineAndShapeRenderer15.setBaseLinesVisible(false);
        java.awt.Paint paint21 = statisticalLineAndShapeRenderer15.getErrorIndicatorPaint();
        boolean boolean24 = statisticalLineAndShapeRenderer15.getItemLineVisible(128, 3);
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        statisticalLineAndShapeRenderer15.setSeriesFillPaint(2, (java.awt.Paint) color26);
        piePlot0.setLabelLinkPaint((java.awt.Paint) color26);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(color26);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource1 = dateAxis0.getStandardTickUnits();
        dateAxis0.setVerticalTickLabels(false);
        dateAxis0.setRange((double) 1, (double) 2.0f);
        dateAxis0.setFixedAutoRange((double) 1900L);
        org.junit.Assert.assertNotNull(tickUnitSource1);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int9 = spreadsheetDate6.compare((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int14 = spreadsheetDate11.compare((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate17);
        boolean boolean19 = spreadsheetDate6.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate13, (org.jfree.data.time.SerialDate) spreadsheetDate17);
        boolean boolean20 = spreadsheetDate3.isOn((org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.util.Date date21 = spreadsheetDate3.toDate();
        boolean boolean22 = lengthAdjustmentType0.equals((java.lang.Object) spreadsheetDate3);
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = null;
        piePlot0.setLegendLabelToolTipGenerator(pieSectionLabelGenerator1);
        java.awt.Paint paint3 = piePlot0.getShadowPaint();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot0);
        boolean boolean5 = jFreeChart4.isBorderVisible();
        jFreeChart4.setBackgroundImageAlignment((int) '#');
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.awt.geom.Point2D point2D10 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = null;
        try {
            jFreeChart4.draw(graphics2D8, rectangle2D9, point2D10, chartRenderingInfo11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        org.jfree.chart.block.Arrangement arrangement0 = null;
        try {
            org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer(arrangement0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrangement' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        java.awt.Shape shape5 = null;
        java.awt.Stroke stroke6 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color7 = java.awt.Color.RED;
        org.jfree.chart.LegendItem legendItem8 = new org.jfree.chart.LegendItem("", "hi!", "RangeType.NEGATIVE", "RangeType.NEGATIVE", shape5, stroke6, (java.awt.Paint) color7);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D12 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (-1), 10.0d, true);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer13 = stackedBarRenderer3D12.getGradientPaintTransformer();
        legendItem8.setFillPaintTransformer(gradientPaintTransformer13);
        legendItemCollection0.add(legendItem8);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer16 = legendItem8.getFillPaintTransformer();
        boolean boolean17 = legendItem8.isShapeOutlineVisible();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(gradientPaintTransformer13);
        org.junit.Assert.assertNotNull(gradientPaintTransformer16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("ChartEntity: tooltip = null");
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.FlowArrangement flowArrangement13 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment9, verticalAlignment10, 100.0d, (double) (short) -1);
        org.jfree.chart.block.BlockContainer blockContainer14 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement13);
        org.jfree.chart.block.CenterArrangement centerArrangement15 = new org.jfree.chart.block.CenterArrangement();
        blockContainer14.setArrangement((org.jfree.chart.block.Arrangement) centerArrangement15);
        java.util.List list17 = blockContainer14.getBlocks();
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem18 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) 128, (java.lang.Number) 10.0f, (java.lang.Number) (short) -1, (java.lang.Number) 0.0d, (java.lang.Number) 1.0E-8d, (java.lang.Number) (short) 10, (java.lang.Number) 6, (java.lang.Number) 1.0E-8d, list17);
        java.lang.String str19 = boxAndWhiskerItem18.toString();
        java.util.List list20 = boxAndWhiskerItem18.getOutliers();
        axisState0.setTicks(list20);
        org.junit.Assert.assertNotNull(verticalAlignment10);
        org.junit.Assert.assertNotNull(list17);
        org.junit.Assert.assertNotNull(list20);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        java.awt.Paint paint1 = ganttRenderer0.getIncompletePaint();
        double double2 = ganttRenderer0.getEndPercent();
        java.awt.Paint paint3 = ganttRenderer0.getCompletePaint();
        ganttRenderer0.setStartPercent((double) 2958465);
        java.awt.Color color6 = java.awt.Color.blue;
        ganttRenderer0.setIncompletePaint((java.awt.Paint) color6);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.65d + "'", double2 == 0.65d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (-1), 10.0d, true);
        java.lang.Object obj4 = stackedBarRenderer3D3.clone();
        java.awt.Color color5 = java.awt.Color.MAGENTA;
        stackedBarRenderer3D3.setWallPaint((java.awt.Paint) color5);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D10 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (-1), 10.0d, true);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer11 = stackedBarRenderer3D10.getGradientPaintTransformer();
        stackedBarRenderer3D3.setGradientPaintTransformer(gradientPaintTransformer11);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator14 = null;
        try {
            stackedBarRenderer3D3.setSeriesItemLabelGenerator((-1), categoryItemLabelGenerator14, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(gradientPaintTransformer11);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = null;
        piePlot0.setLegendLabelToolTipGenerator(pieSectionLabelGenerator1);
        java.awt.Paint paint3 = piePlot0.getShadowPaint();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot0);
        org.jfree.chart.title.LegendTitle legendTitle5 = jFreeChart4.getLegend();
        java.awt.Font font7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("hi!", font7);
        textTitle8.setURLText("({0}, {1}) = {2}");
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.lang.Object obj14 = textTitle8.draw(graphics2D11, rectangle2D12, (java.lang.Object) "{0}");
        boolean boolean15 = legendTitle5.equals((java.lang.Object) graphics2D11);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = legendTitle5.getLegendItemGraphicPadding();
        legendTitle5.setHeight((double) 2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(legendTitle5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNull(obj14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(rectangleInsets16);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart4 = multiplePiePlot3.getPieChart();
        textTitle2.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart4);
        int int6 = jFreeChart4.getBackgroundImageAlignment();
        org.jfree.chart.event.ChartProgressListener chartProgressListener7 = null;
        jFreeChart4.addProgressListener(chartProgressListener7);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(jFreeChart4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("org.jfree.data.UnknownKeyException: Polar Plot");
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        java.lang.String str0 = org.jfree.chart.ui.Licences.LGPL;
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = piePlot0.getLabelPaint();
        piePlot0.setMinimumArcAngleToDraw((double) (byte) 100);
        java.lang.Class<?> wildcardClass4 = piePlot0.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke2 = dateAxis1.getAxisLineStroke();
        double double3 = dateAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource6 = numberAxis3D5.getStandardTickUnits();
        double double7 = numberAxis3D5.getUpperMargin();
        java.awt.Shape shape8 = numberAxis3D5.getLeftArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer9);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        boolean boolean14 = chartChangeEventType12.equals((java.lang.Object) dateAxis13);
        dateAxis13.setTickMarkOutsideLength((float) 1);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) '#', (double) '#', 0.0d);
        org.jfree.chart.block.LineBorder lineBorder24 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color17, stroke18, rectangleInsets23);
        dateAxis13.setAxisLinePaint((java.awt.Paint) color17);
        dateAxis13.setRangeWithMargins(0.0d, 10.0d);
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis();
        dateAxis29.setInverted(true);
        java.awt.Shape shape32 = dateAxis29.getDownArrow();
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke34 = dateAxis33.getAxisLineStroke();
        boolean boolean35 = dateAxis33.isAutoTickUnitSelection();
        org.jfree.chart.axis.Timeline timeline36 = dateAxis33.getTimeline();
        dateAxis29.setTimeline(timeline36);
        dateAxis13.setTimeline(timeline36);
        dateAxis13.setVerticalTickLabels(false);
        xYPlot10.setRangeAxis(5, (org.jfree.chart.axis.ValueAxis) dateAxis13, false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder43 = xYPlot10.getDatasetRenderingOrder();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer44 = null;
        int int45 = xYPlot10.getIndexOf(xYItemRenderer44);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(chartChangeEventType12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(timeline36);
        org.junit.Assert.assertNotNull(datasetRenderingOrder43);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        double double2 = defaultBoxAndWhiskerCategoryDataset0.getRangeLowerBound(true);
        java.lang.Number number5 = defaultBoxAndWhiskerCategoryDataset0.getMaxOutlier((java.lang.Comparable) 15, (java.lang.Comparable) Double.NaN);
        int int7 = defaultBoxAndWhiskerCategoryDataset0.getColumnIndex((java.lang.Comparable) "TextAnchor.TOP_CENTER");
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke10 = dateAxis9.getAxisLineStroke();
        double double11 = dateAxis9.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D13 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource14 = numberAxis3D13.getStandardTickUnits();
        double double15 = numberAxis3D13.getUpperMargin();
        java.awt.Shape shape16 = numberAxis3D13.getLeftArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset8, (org.jfree.chart.axis.ValueAxis) dateAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis3D13, xYItemRenderer17);
        xYPlot18.clearRangeMarkers((int) (byte) -1);
        xYPlot18.setDomainCrosshairVisible(true);
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        xYPlot18.setDataset(xYDataset23);
        org.jfree.data.time.DateRange dateRange25 = new org.jfree.data.time.DateRange();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer28 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, true);
        statisticalLineAndShapeRenderer28.setSeriesLinesVisible(100, false);
        statisticalLineAndShapeRenderer28.setBaseLinesVisible(false);
        java.lang.Boolean boolean35 = statisticalLineAndShapeRenderer28.getSeriesItemLabelsVisible((int) (short) 0);
        boolean boolean36 = dateRange25.equals((java.lang.Object) boolean35);
        java.util.Date date37 = dateRange25.getUpperDate();
        org.jfree.data.general.Dataset dataset38 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent39 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) dateRange25, dataset38);
        xYPlot18.datasetChanged(datasetChangeEvent39);
        boolean boolean41 = defaultBoxAndWhiskerCategoryDataset0.hasListener((java.util.EventListener) xYPlot18);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate44);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int50 = spreadsheetDate47.compare((org.jfree.data.time.SerialDate) spreadsheetDate49);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate52 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate54 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int55 = spreadsheetDate52.compare((org.jfree.data.time.SerialDate) spreadsheetDate54);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate58 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate59 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate58);
        boolean boolean60 = spreadsheetDate47.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate54, (org.jfree.data.time.SerialDate) spreadsheetDate58);
        boolean boolean61 = spreadsheetDate44.isOn((org.jfree.data.time.SerialDate) spreadsheetDate58);
        java.util.Date date62 = spreadsheetDate44.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate65 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate66 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate65);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate69 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate70 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate69);
        int int71 = spreadsheetDate69.toSerial();
        org.jfree.data.time.SerialDate serialDate73 = org.jfree.data.time.SerialDate.createInstance(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate75 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate77 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int78 = spreadsheetDate75.compare((org.jfree.data.time.SerialDate) spreadsheetDate77);
        int int79 = spreadsheetDate77.getDayOfMonth();
        boolean boolean80 = spreadsheetDate69.isInRange(serialDate73, (org.jfree.data.time.SerialDate) spreadsheetDate77);
        boolean boolean82 = spreadsheetDate44.isInRange(serialDate66, serialDate73, 128);
        java.lang.Comparable comparable83 = null;
        java.lang.Number number84 = defaultBoxAndWhiskerCategoryDataset0.getMinOutlier((java.lang.Comparable) serialDate66, comparable83);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.05d + "'", double15 == 0.05d);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNull(boolean35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertNotNull(serialDate59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(date62);
        org.junit.Assert.assertNotNull(serialDate66);
        org.junit.Assert.assertNotNull(serialDate70);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 10 + "'", int71 == 10);
        org.junit.Assert.assertNotNull(serialDate73);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 0 + "'", int78 == 0);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 9 + "'", int79 == 9);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNull(number84);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        int int2 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setUpperMargin((double) 'a');
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType6 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = chartChangeEventType6.equals((java.lang.Object) dateAxis7);
        java.awt.Paint paint9 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        boolean boolean10 = chartChangeEventType6.equals((java.lang.Object) paint9);
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) "hi!", paint9);
        categoryAxis1.setTickLabelsVisible(true);
        java.awt.Paint paint15 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder16 = new org.jfree.chart.block.BlockBorder(paint15);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType17 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        boolean boolean19 = chartChangeEventType17.equals((java.lang.Object) dateAxis18);
        java.awt.Stroke stroke20 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        dateAxis18.setAxisLineStroke(stroke20);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) '4', paint15, stroke20);
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) '#', (double) '#', 0.0d);
        org.jfree.chart.block.LineBorder lineBorder30 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color23, stroke24, rectangleInsets29);
        double double32 = rectangleInsets29.extendHeight((double) '4');
        valueMarker22.setLabelOffset(rectangleInsets29);
        categoryAxis1.setTickLabelInsets(rectangleInsets29);
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        try {
            rectangleInsets29.trim(rectangle2D35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(chartChangeEventType6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(chartChangeEventType17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 97.0d + "'", double32 == 97.0d);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        double double2 = defaultBoxAndWhiskerCategoryDataset0.getRangeLowerBound(true);
        java.lang.Number number5 = defaultBoxAndWhiskerCategoryDataset0.getMaxOutlier((java.lang.Comparable) 15, (java.lang.Comparable) Double.NaN);
        int int7 = defaultBoxAndWhiskerCategoryDataset0.getColumnIndex((java.lang.Comparable) "TextAnchor.TOP_CENTER");
        org.jfree.data.Range range9 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0, false);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod((long) 7, (long) '4');
        java.util.Date date13 = simpleTimePeriod12.getStart();
        java.lang.Number number15 = defaultBoxAndWhiskerCategoryDataset0.getQ3Value((java.lang.Comparable) date13, (java.lang.Comparable) 10900L);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date13);
        long long17 = month16.getMiddleMillisecond();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(number15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1310400001L) + "'", long17 == (-1310400001L));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        java.awt.Color color0 = java.awt.Color.black;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.FlowArrangement flowArrangement5 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment1, verticalAlignment2, 100.0d, (double) (short) -1);
        org.jfree.chart.block.BlockContainer blockContainer6 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement5);
        blockContainer6.setPadding((double) (byte) -1, (-1.0d), 0.5d, 0.0d);
        boolean boolean12 = tickUnits0.equals((java.lang.Object) 0.0d);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D16 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (-1), 10.0d, true);
        stackedBarRenderer3D16.setMaximumBarWidth((-1.0d));
        stackedBarRenderer3D16.setDrawBarOutline(true);
        stackedBarRenderer3D16.setBaseSeriesVisible(true);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer23 = stackedBarRenderer3D16.getGradientPaintTransformer();
        java.awt.Stroke stroke25 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        stackedBarRenderer3D16.setSeriesStroke((int) (byte) 100, stroke25);
        boolean boolean27 = tickUnits0.equals((java.lang.Object) stroke25);
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(gradientPaintTransformer23);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (-1), 10.0d, true);
        double double4 = stackedBarRenderer3D3.getItemMargin();
        stackedBarRenderer3D3.setSeriesVisibleInLegend((int) ' ', (java.lang.Boolean) false);
        java.awt.Stroke stroke9 = stackedBarRenderer3D3.getSeriesStroke((int) (byte) 10);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot10 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart11 = multiplePiePlot10.getPieChart();
        boolean boolean12 = stackedBarRenderer3D3.equals((java.lang.Object) multiplePiePlot10);
        java.awt.Paint paint13 = multiplePiePlot10.getAggregatedItemsPaint();
        multiplePiePlot10.setBackgroundAlpha((float) 10);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2d + "'", double4 == 0.2d);
        org.junit.Assert.assertNull(stroke9);
        org.junit.Assert.assertNotNull(jFreeChart11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        java.awt.Color color0 = java.awt.Color.pink;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke2 = dateAxis1.getAxisLineStroke();
        double double3 = dateAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource6 = numberAxis3D5.getStandardTickUnits();
        double double7 = numberAxis3D5.getUpperMargin();
        java.awt.Shape shape8 = numberAxis3D5.getLeftArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer9);
        xYPlot10.clearRangeMarkers((int) (byte) -1);
        xYPlot10.setDomainCrosshairVisible(true);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        xYPlot10.setDataset(xYDataset15);
        org.jfree.data.time.DateRange dateRange17 = new org.jfree.data.time.DateRange();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer20 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, true);
        statisticalLineAndShapeRenderer20.setSeriesLinesVisible(100, false);
        statisticalLineAndShapeRenderer20.setBaseLinesVisible(false);
        java.lang.Boolean boolean27 = statisticalLineAndShapeRenderer20.getSeriesItemLabelsVisible((int) (short) 0);
        boolean boolean28 = dateRange17.equals((java.lang.Object) boolean27);
        java.util.Date date29 = dateRange17.getUpperDate();
        org.jfree.data.general.Dataset dataset30 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent31 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) dateRange17, dataset30);
        xYPlot10.datasetChanged(datasetChangeEvent31);
        xYPlot10.clearDomainAxes();
        java.awt.Paint paint34 = xYPlot10.getDomainGridlinePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection35 = xYPlot10.getFixedLegendItems();
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = xYPlot10.getRangeAxisEdge();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNull(boolean27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNull(legendItemCollection35);
        org.junit.Assert.assertNotNull(rectangleEdge36);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        textTitle2.setURLText("({0}, {1}) = {2}");
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.lang.Object obj8 = textTitle2.draw(graphics2D5, rectangle2D6, (java.lang.Object) "{0}");
        double double9 = textTitle2.getWidth();
        java.lang.String str10 = textTitle2.getToolTipText();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(obj8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent1 = null;
        multiplePiePlot0.axisChanged(axisChangeEvent1);
        java.awt.Shape shape7 = null;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color9 = java.awt.Color.RED;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("", "hi!", "RangeType.NEGATIVE", "RangeType.NEGATIVE", shape7, stroke8, (java.awt.Paint) color9);
        multiplePiePlot0.setAggregatedItemsPaint((java.awt.Paint) color9);
        java.awt.Paint paint12 = multiplePiePlot0.getBackgroundPaint();
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        double double0 = org.jfree.chart.renderer.category.LineRenderer3D.DEFAULT_Y_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 8.0d + "'", double0 == 8.0d);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        int int3 = java.awt.Color.HSBtoRGB((float) 3600000L, 0.0f, (float) 15);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-15) + "'", int3 == (-15));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("VerticalAlignment.BOTTOM", "October 128", "CategoryLabelWidthType.RANGE", "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]", "Preceding");
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (-1), 10.0d, true);
        java.awt.Paint paint4 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        stackedBarRenderer3D3.setBaseOutlinePaint(paint4, false);
        stackedBarRenderer3D3.setRenderAsPercentages(true);
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator10 = new org.jfree.chart.urls.StandardCategoryURLGenerator("TextAnchor.TOP_CENTER");
        stackedBarRenderer3D3.setBaseURLGenerator((org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator10);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
        java.awt.GradientPaint gradientPaint2 = null;
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke5 = dateAxis4.getAxisLineStroke();
        double double6 = dateAxis4.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D8 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource9 = numberAxis3D8.getStandardTickUnits();
        double double10 = numberAxis3D8.getUpperMargin();
        java.awt.Shape shape11 = numberAxis3D8.getLeftArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) dateAxis4, (org.jfree.chart.axis.ValueAxis) numberAxis3D8, xYItemRenderer12);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        dateAxis16.setInverted(true);
        java.awt.Shape shape19 = dateAxis16.getDownArrow();
        lineAndShapeRenderer14.setSeriesShape((int) (short) 10, shape19);
        dateAxis4.setLeftArrow(shape19);
        try {
            java.awt.GradientPaint gradientPaint22 = standardGradientPaintTransformer1.transform(gradientPaint2, shape19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.05d + "'", double10 == 0.05d);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(shape19);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource3 = numberAxis3D2.getStandardTickUnits();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.axis.AxisState axisState5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        java.util.List list8 = numberAxis3D2.refreshTicks(graphics2D4, axisState5, rectangle2D6, rectangleEdge7);
        org.jfree.data.Range range12 = new org.jfree.data.Range((double) (-1L), (double) '4');
        double double14 = range12.constrain((double) (short) 10);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = new org.jfree.chart.block.RectangleConstraint(10.0d, range12);
        numberAxis3D2.setRangeWithMargins(range12, false, false);
        java.awt.Font font19 = numberAxis3D2.getTickLabelFont();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D23 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (-1), 10.0d, true);
        java.lang.Object obj24 = stackedBarRenderer3D23.clone();
        java.awt.Paint paint25 = stackedBarRenderer3D23.getBaseFillPaint();
        org.jfree.chart.text.TextFragment textFragment27 = new org.jfree.chart.text.TextFragment("DatasetRenderingOrder.FORWARD", font19, paint25, (float) (-128));
        boolean boolean29 = textFragment27.equals((java.lang.Object) 12.0d);
        org.junit.Assert.assertNotNull(tickUnitSource3);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 10.0d + "'", double14 == 10.0d);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        java.awt.Stroke stroke0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate3.toSerial();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int12 = spreadsheetDate9.compare((org.jfree.data.time.SerialDate) spreadsheetDate11);
        int int13 = spreadsheetDate11.getDayOfMonth();
        boolean boolean14 = spreadsheetDate3.isInRange(serialDate7, (org.jfree.data.time.SerialDate) spreadsheetDate11);
        keyedObjects2D0.removeColumn((java.lang.Comparable) serialDate7);
        try {
            org.jfree.data.time.SerialDate serialDate17 = serialDate7.getNearestDayOfWeek(255);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 9 + "'", int13 == 9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.CENTER;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (-1), 10.0d, true);
        double double4 = stackedBarRenderer3D3.getItemMargin();
        stackedBarRenderer3D3.setSeriesVisibleInLegend((int) ' ', (java.lang.Boolean) false);
        java.awt.Stroke stroke9 = stackedBarRenderer3D3.getSeriesStroke((int) (byte) 10);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot10 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart11 = multiplePiePlot10.getPieChart();
        boolean boolean12 = stackedBarRenderer3D3.equals((java.lang.Object) multiplePiePlot10);
        org.jfree.chart.util.TableOrder tableOrder13 = multiplePiePlot10.getDataExtractOrder();
        multiplePiePlot10.setLimit((double) (-128));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2d + "'", double4 == 0.2d);
        org.junit.Assert.assertNull(stroke9);
        org.junit.Assert.assertNotNull(jFreeChart11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(tableOrder13);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke2 = dateAxis1.getAxisLineStroke();
        double double3 = dateAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource6 = numberAxis3D5.getStandardTickUnits();
        double double7 = numberAxis3D5.getUpperMargin();
        java.awt.Shape shape8 = numberAxis3D5.getLeftArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer9);
        xYPlot10.clearRangeMarkers((int) (byte) -1);
        xYPlot10.setDomainCrosshairVisible(true);
        org.jfree.chart.plot.PlotOrientation plotOrientation15 = xYPlot10.getOrientation();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(plotOrientation15);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        dateAxis2.setInverted(true);
        java.awt.Shape shape5 = dateAxis2.getDownArrow();
        lineAndShapeRenderer0.setSeriesShape((int) (short) 10, shape5);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.clone(shape5);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNull(shape7);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = rectangleConstraint0.toFixedWidth((double) (short) 10);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = rectangleConstraint0.toUnconstrainedHeight();
        java.lang.String str4 = rectangleConstraint0.toString();
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertNotNull(rectangleConstraint2);
        org.junit.Assert.assertNotNull(rectangleConstraint3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]" + "'", str4.equals("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_RED;
        lineRenderer3D0.setWallPaint((java.awt.Paint) color1);
        java.awt.Paint paint3 = lineRenderer3D0.getWallPaint();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D("");
        numberAxis3D7.setUpperMargin((double) 4);
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis3D7.setUpArrow(shape10);
        java.awt.Shape shape14 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 1, (float) ' ');
        org.jfree.chart.entity.ChartEntity chartEntity16 = new org.jfree.chart.entity.ChartEntity(shape14, "Polar Plot");
        numberAxis3D7.setUpArrow(shape14);
        numberAxis3D7.setNegativeArrowVisible(false);
        java.awt.Paint paint21 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder22 = new org.jfree.chart.block.BlockBorder(paint21);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType23 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis();
        boolean boolean25 = chartChangeEventType23.equals((java.lang.Object) dateAxis24);
        java.awt.Stroke stroke26 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        dateAxis24.setAxisLineStroke(stroke26);
        org.jfree.chart.plot.ValueMarker valueMarker28 = new org.jfree.chart.plot.ValueMarker((double) '4', paint21, stroke26);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent29 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker28);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor30 = valueMarker28.getLabelAnchor();
        java.awt.Stroke stroke31 = valueMarker28.getStroke();
        java.awt.Stroke stroke32 = valueMarker28.getStroke();
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis();
        dateAxis33.setInverted(true);
        java.awt.Shape shape36 = dateAxis33.getDownArrow();
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke38 = dateAxis37.getAxisLineStroke();
        boolean boolean39 = dateAxis37.isAutoTickUnitSelection();
        org.jfree.chart.axis.Timeline timeline40 = dateAxis37.getTimeline();
        dateAxis33.setTimeline(timeline40);
        java.lang.String str42 = dateAxis33.getLabelURL();
        dateAxis33.setVisible(false);
        org.jfree.chart.plot.PiePlot piePlot45 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint46 = piePlot45.getLabelPaint();
        piePlot45.setMinimumArcAngleToDraw((double) (byte) 100);
        org.jfree.data.time.SerialDate serialDate50 = org.jfree.data.time.SerialDate.createInstance(9999);
        java.awt.Paint paint51 = piePlot45.getSectionPaint((java.lang.Comparable) 9999);
        dateAxis33.setPlot((org.jfree.chart.plot.Plot) piePlot45);
        org.jfree.chart.JFreeChart jFreeChart53 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot45);
        org.jfree.chart.entity.EntityCollection entityCollection56 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo57 = new org.jfree.chart.ChartRenderingInfo(entityCollection56);
        java.awt.image.BufferedImage bufferedImage58 = jFreeChart53.createBufferedImage((int) (short) 1, 255, chartRenderingInfo57);
        java.awt.geom.Rectangle2D rectangle2D59 = chartRenderingInfo57.getChartArea();
        lineRenderer3D0.drawRangeMarker(graphics2D4, categoryPlot5, (org.jfree.chart.axis.ValueAxis) numberAxis3D7, (org.jfree.chart.plot.Marker) valueMarker28, rectangle2D59);
        org.jfree.chart.ChartColor chartColor64 = new org.jfree.chart.ChartColor((int) '4', 10, 6);
        boolean boolean65 = valueMarker28.equals((java.lang.Object) '4');
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(chartChangeEventType23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(rectangleAnchor30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(timeline40);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertNull(paint51);
        org.junit.Assert.assertNotNull(bufferedImage58);
        org.junit.Assert.assertNotNull(rectangle2D59);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer1 = new org.jfree.chart.renderer.category.StackedBarRenderer(false);
        boolean boolean2 = stackedBarRenderer1.getRenderAsPercentages();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        org.jfree.chart.plot.Plot plot2 = jFreeChart1.getPlot();
        java.util.List list3 = jFreeChart1.getSubtitles();
        org.junit.Assert.assertNotNull(jFreeChart1);
        org.junit.Assert.assertNotNull(plot2);
        org.junit.Assert.assertNotNull(list3);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        stackedAreaRenderer0.setRenderAsPercentages(false);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer8 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, true);
        statisticalLineAndShapeRenderer8.setSeriesLinesVisible(100, false);
        statisticalLineAndShapeRenderer8.setBaseLinesVisible(false);
        java.awt.Font font16 = statisticalLineAndShapeRenderer8.getItemLabelFont((int) (byte) 1, 7);
        org.jfree.chart.text.TextFragment textFragment17 = new org.jfree.chart.text.TextFragment("", font16);
        org.jfree.chart.text.TextFragment textFragment18 = new org.jfree.chart.text.TextFragment("CategoryLabelWidthType.RANGE", font16);
        stackedAreaRenderer0.setSeriesItemLabelFont((int) ' ', font16);
        org.junit.Assert.assertNotNull(font16);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        java.awt.Font font0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        java.lang.Object obj0 = null;
        try {
            org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent(obj0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.FULL;
        org.junit.Assert.assertNotNull(rangeType0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        textTitle2.setMargin((double) (short) -1, (double) 255, (double) 5, 2.0d);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D9 = new org.jfree.chart.renderer.category.LineRenderer3D();
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_RED;
        lineRenderer3D9.setWallPaint((java.awt.Paint) color10);
        java.awt.Paint paint12 = lineRenderer3D9.getWallPaint();
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D16 = new org.jfree.chart.axis.NumberAxis3D("");
        numberAxis3D16.setUpperMargin((double) 4);
        java.awt.Shape shape19 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis3D16.setUpArrow(shape19);
        java.awt.Shape shape23 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 1, (float) ' ');
        org.jfree.chart.entity.ChartEntity chartEntity25 = new org.jfree.chart.entity.ChartEntity(shape23, "Polar Plot");
        numberAxis3D16.setUpArrow(shape23);
        numberAxis3D16.setNegativeArrowVisible(false);
        java.awt.Paint paint30 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder31 = new org.jfree.chart.block.BlockBorder(paint30);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType32 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis();
        boolean boolean34 = chartChangeEventType32.equals((java.lang.Object) dateAxis33);
        java.awt.Stroke stroke35 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        dateAxis33.setAxisLineStroke(stroke35);
        org.jfree.chart.plot.ValueMarker valueMarker37 = new org.jfree.chart.plot.ValueMarker((double) '4', paint30, stroke35);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent38 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker37);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor39 = valueMarker37.getLabelAnchor();
        java.awt.Stroke stroke40 = valueMarker37.getStroke();
        java.awt.Stroke stroke41 = valueMarker37.getStroke();
        org.jfree.chart.axis.DateAxis dateAxis42 = new org.jfree.chart.axis.DateAxis();
        dateAxis42.setInverted(true);
        java.awt.Shape shape45 = dateAxis42.getDownArrow();
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke47 = dateAxis46.getAxisLineStroke();
        boolean boolean48 = dateAxis46.isAutoTickUnitSelection();
        org.jfree.chart.axis.Timeline timeline49 = dateAxis46.getTimeline();
        dateAxis42.setTimeline(timeline49);
        java.lang.String str51 = dateAxis42.getLabelURL();
        dateAxis42.setVisible(false);
        org.jfree.chart.plot.PiePlot piePlot54 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint55 = piePlot54.getLabelPaint();
        piePlot54.setMinimumArcAngleToDraw((double) (byte) 100);
        org.jfree.data.time.SerialDate serialDate59 = org.jfree.data.time.SerialDate.createInstance(9999);
        java.awt.Paint paint60 = piePlot54.getSectionPaint((java.lang.Comparable) 9999);
        dateAxis42.setPlot((org.jfree.chart.plot.Plot) piePlot54);
        org.jfree.chart.JFreeChart jFreeChart62 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot54);
        org.jfree.chart.entity.EntityCollection entityCollection65 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo66 = new org.jfree.chart.ChartRenderingInfo(entityCollection65);
        java.awt.image.BufferedImage bufferedImage67 = jFreeChart62.createBufferedImage((int) (short) 1, 255, chartRenderingInfo66);
        java.awt.geom.Rectangle2D rectangle2D68 = chartRenderingInfo66.getChartArea();
        lineRenderer3D9.drawRangeMarker(graphics2D13, categoryPlot14, (org.jfree.chart.axis.ValueAxis) numberAxis3D16, (org.jfree.chart.plot.Marker) valueMarker37, rectangle2D68);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType70 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis71 = new org.jfree.chart.axis.DateAxis();
        boolean boolean72 = chartChangeEventType70.equals((java.lang.Object) dateAxis71);
        java.awt.Paint paint73 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        boolean boolean74 = chartChangeEventType70.equals((java.lang.Object) paint73);
        java.lang.Object obj75 = textTitle2.draw(graphics2D8, rectangle2D68, (java.lang.Object) paint73);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(chartChangeEventType32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(rectangleAnchor39);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(shape45);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(timeline49);
        org.junit.Assert.assertNull(str51);
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertNotNull(serialDate59);
        org.junit.Assert.assertNull(paint60);
        org.junit.Assert.assertNotNull(bufferedImage67);
        org.junit.Assert.assertNotNull(rectangle2D68);
        org.junit.Assert.assertNotNull(chartChangeEventType70);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(paint73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNull(obj75);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = null;
        piePlot0.setLegendLabelToolTipGenerator(pieSectionLabelGenerator1);
        java.awt.Paint paint3 = piePlot0.getShadowPaint();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot0);
        org.jfree.chart.title.LegendTitle legendTitle5 = jFreeChart4.getLegend();
        java.awt.Font font7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("hi!", font7);
        textTitle8.setURLText("({0}, {1}) = {2}");
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.lang.Object obj14 = textTitle8.draw(graphics2D11, rectangle2D12, (java.lang.Object) "{0}");
        boolean boolean15 = legendTitle5.equals((java.lang.Object) graphics2D11);
        java.awt.Paint paint17 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder18 = new org.jfree.chart.block.BlockBorder(paint17);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType19 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean21 = chartChangeEventType19.equals((java.lang.Object) dateAxis20);
        java.awt.Stroke stroke22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        dateAxis20.setAxisLineStroke(stroke22);
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker((double) '4', paint17, stroke22);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent25 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker24);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = valueMarker24.getLabelAnchor();
        legendTitle5.setLegendItemGraphicAnchor(rectangleAnchor26);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(legendTitle5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNull(obj14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(chartChangeEventType19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(rectangleAnchor26);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke2 = dateAxis1.getAxisLineStroke();
        double double3 = dateAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource6 = numberAxis3D5.getStandardTickUnits();
        double double7 = numberAxis3D5.getUpperMargin();
        java.awt.Shape shape8 = numberAxis3D5.getLeftArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer9);
        xYPlot10.clearRangeMarkers((int) (byte) -1);
        xYPlot10.setDomainCrosshairVisible(true);
        org.jfree.chart.LegendItemCollection legendItemCollection15 = xYPlot10.getLegendItems();
        org.jfree.chart.util.Layer layer16 = org.jfree.chart.util.Layer.BACKGROUND;
        java.lang.String str17 = layer16.toString();
        java.util.Collection collection18 = xYPlot10.getDomainMarkers(layer16);
        xYPlot10.setDomainZeroBaselineVisible(false);
        java.awt.Paint paint22 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder23 = new org.jfree.chart.block.BlockBorder(paint22);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType24 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        boolean boolean26 = chartChangeEventType24.equals((java.lang.Object) dateAxis25);
        java.awt.Stroke stroke27 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        dateAxis25.setAxisLineStroke(stroke27);
        org.jfree.chart.plot.ValueMarker valueMarker29 = new org.jfree.chart.plot.ValueMarker((double) '4', paint22, stroke27);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent30 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker29);
        valueMarker29.setValue(0.0d);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent33 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker29);
        java.awt.Paint paint34 = valueMarker29.getOutlinePaint();
        java.awt.Stroke stroke35 = valueMarker29.getOutlineStroke();
        java.awt.Color color37 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        java.awt.Color color38 = java.awt.Color.getColor("TextAnchor.TOP_CENTER", color37);
        valueMarker29.setOutlinePaint((java.awt.Paint) color38);
        xYPlot10.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker29);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(legendItemCollection15);
        org.junit.Assert.assertNotNull(layer16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Layer.BACKGROUND" + "'", str17.equals("Layer.BACKGROUND"));
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(chartChangeEventType24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(color38);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = chartChangeEventType0.equals((java.lang.Object) dateAxis1);
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation5 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number) 0, (java.lang.Number) (short) 0);
        boolean boolean6 = dateAxis1.equals((java.lang.Object) (short) 0);
        dateAxis1.setAxisLineVisible(false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent9 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis1);
        dateAxis1.setAxisLineVisible(false);
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isTickLabelsVisible();
        dateAxis0.setAutoRangeMinimumSize((double) 4, true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int5 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate4);
        spreadsheetDate2.setDescription("hi!");
        java.awt.Paint paint8 = piePlot0.getSectionOutlinePaint((java.lang.Comparable) spreadsheetDate2);
        java.awt.Stroke stroke9 = piePlot0.getLabelLinkStroke();
        piePlot0.setMaximumLabelWidth((double) 7);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("", "", "hi!", "");
        java.lang.String str6 = basicProjectInfo5.getName();
        basicProjectInfo5.setCopyright("hi!");
        org.jfree.chart.renderer.category.AreaRenderer areaRenderer9 = new org.jfree.chart.renderer.category.AreaRenderer();
        areaRenderer9.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) true, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = areaRenderer9.getPositiveItemLabelPosition(9999, (int) (byte) 100);
        org.jfree.chart.text.TextAnchor textAnchor17 = itemLabelPosition16.getRotationAnchor();
        boolean boolean18 = basicProjectInfo5.equals((java.lang.Object) itemLabelPosition16);
        stackedBarRenderer3D0.setNegativeItemLabelPositionFallback(itemLabelPosition16);
        boolean boolean20 = stackedBarRenderer3D0.getAutoPopulateSeriesShape();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(itemLabelPosition16);
        org.junit.Assert.assertNotNull(textAnchor17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("DateTickUnit[DAY, -1]");
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        defaultKeyedValues0.setValue((java.lang.Comparable) 9999, (java.lang.Number) 1.0d);
        try {
            java.lang.Comparable comparable5 = defaultKeyedValues0.getKey((-460));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke2 = dateAxis1.getAxisLineStroke();
        double double3 = dateAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource6 = numberAxis3D5.getStandardTickUnits();
        double double7 = numberAxis3D5.getUpperMargin();
        java.awt.Shape shape8 = numberAxis3D5.getLeftArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer9);
        xYPlot10.clearRangeMarkers((int) (byte) -1);
        xYPlot10.setDomainCrosshairVisible(true);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        xYPlot10.setDataset(xYDataset15);
        org.jfree.data.time.DateRange dateRange17 = new org.jfree.data.time.DateRange();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer20 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, true);
        statisticalLineAndShapeRenderer20.setSeriesLinesVisible(100, false);
        statisticalLineAndShapeRenderer20.setBaseLinesVisible(false);
        java.lang.Boolean boolean27 = statisticalLineAndShapeRenderer20.getSeriesItemLabelsVisible((int) (short) 0);
        boolean boolean28 = dateRange17.equals((java.lang.Object) boolean27);
        java.util.Date date29 = dateRange17.getUpperDate();
        org.jfree.data.general.Dataset dataset30 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent31 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) dateRange17, dataset30);
        xYPlot10.datasetChanged(datasetChangeEvent31);
        xYPlot10.clearDomainAxes();
        java.awt.Paint paint34 = xYPlot10.getRangeZeroBaselinePaint();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNull(boolean27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(paint34);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Paint paint2 = numberAxis3D1.getLabelPaint();
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke2 = dateAxis1.getAxisLineStroke();
        double double3 = dateAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource6 = numberAxis3D5.getStandardTickUnits();
        double double7 = numberAxis3D5.getUpperMargin();
        java.awt.Shape shape8 = numberAxis3D5.getLeftArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer9);
        xYPlot10.clearRangeMarkers((int) (byte) -1);
        xYPlot10.setDomainCrosshairVisible(true);
        org.jfree.chart.LegendItemCollection legendItemCollection15 = xYPlot10.getLegendItems();
        xYPlot10.setDomainGridlinesVisible(true);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType18 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        boolean boolean20 = chartChangeEventType18.equals((java.lang.Object) dateAxis19);
        dateAxis19.setTickMarkOutsideLength((float) 1);
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) '#', (double) '#', 0.0d);
        org.jfree.chart.block.LineBorder lineBorder30 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color23, stroke24, rectangleInsets29);
        dateAxis19.setAxisLinePaint((java.awt.Paint) color23);
        dateAxis19.setLowerMargin((double) (byte) 0);
        xYPlot10.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis19);
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke36 = dateAxis35.getAxisLineStroke();
        int int37 = xYPlot10.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis35);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(legendItemCollection15);
        org.junit.Assert.assertNotNull(chartChangeEventType18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        int int1 = defaultStatisticalCategoryDataset0.getRowCount();
        int int2 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        double double2 = defaultBoxAndWhiskerCategoryDataset0.getRangeLowerBound(true);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0);
        int int4 = defaultBoxAndWhiskerCategoryDataset0.getColumnCount();
        java.lang.Number number7 = defaultBoxAndWhiskerCategoryDataset0.getMaxRegularValue((java.lang.Comparable) (-1.0d), (java.lang.Comparable) "TextAnchor.TOP_CENTER");
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNull(number7);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType2 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        java.lang.String str3 = categoryLabelWidthType2.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition5 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1, categoryLabelWidthType2, (float) (byte) 100);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor6 = categoryLabelPosition5.getLabelAnchor();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition7 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor9 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType10 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        java.lang.String str11 = categoryLabelWidthType10.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition13 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor8, textBlockAnchor9, categoryLabelWidthType10, (float) (byte) 100);
        double double14 = categoryLabelPosition13.getAngle();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor16 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType17 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        java.lang.String str18 = categoryLabelWidthType17.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition20 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor15, textBlockAnchor16, categoryLabelWidthType17, (float) (byte) 100);
        double double21 = categoryLabelPosition20.getAngle();
        org.jfree.chart.text.TextAnchor textAnchor22 = categoryLabelPosition20.getRotationAnchor();
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions23 = new org.jfree.chart.axis.CategoryLabelPositions(categoryLabelPosition5, categoryLabelPosition7, categoryLabelPosition13, categoryLabelPosition20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'bottom' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(categoryLabelWidthType2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "CategoryLabelWidthType.RANGE" + "'", str3.equals("CategoryLabelWidthType.RANGE"));
        org.junit.Assert.assertNotNull(textBlockAnchor6);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertNotNull(textBlockAnchor9);
        org.junit.Assert.assertNotNull(categoryLabelWidthType10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "CategoryLabelWidthType.RANGE" + "'", str11.equals("CategoryLabelWidthType.RANGE"));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertNotNull(textBlockAnchor16);
        org.junit.Assert.assertNotNull(categoryLabelWidthType17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "CategoryLabelWidthType.RANGE" + "'", str18.equals("CategoryLabelWidthType.RANGE"));
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(textAnchor22);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setBackgroundImageAlpha(0.0f);
        double double4 = piePlot0.getExplodePercent((java.lang.Comparable) "LegendItemEntity: seriesKey=null, dataset=null");
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        piePlot0.setShadowPaint((java.awt.Paint) color5);
        int int7 = piePlot0.getBackgroundImageAlignment();
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D8 = new org.jfree.chart.renderer.category.LineRenderer3D();
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_RED;
        lineRenderer3D8.setWallPaint((java.awt.Paint) color9);
        java.awt.Paint paint11 = lineRenderer3D8.getWallPaint();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        java.awt.Color color13 = color12.darker();
        int int14 = color13.getBlue();
        java.awt.Color color15 = color13.darker();
        lineRenderer3D8.setWallPaint((java.awt.Paint) color13);
        piePlot0.setLabelBackgroundPaint((java.awt.Paint) color13);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 89 + "'", int14 == 89);
        org.junit.Assert.assertNotNull(color15);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, true);
        statisticalLineAndShapeRenderer2.setUseFillPaint(false);
        org.jfree.chart.text.TextFragment textFragment6 = new org.jfree.chart.text.TextFragment("");
        java.awt.Paint paint7 = textFragment6.getPaint();
        java.awt.Paint paint8 = textFragment6.getPaint();
        boolean boolean9 = statisticalLineAndShapeRenderer2.equals((java.lang.Object) textFragment6);
        statisticalLineAndShapeRenderer2.setSeriesCreateEntities((int) (byte) 10, (java.lang.Boolean) true);
        java.awt.Paint paint13 = statisticalLineAndShapeRenderer2.getErrorIndicatorPaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = null;
        statisticalLineAndShapeRenderer2.setSeriesPositiveItemLabelPosition((int) (byte) 100, itemLabelPosition15, true);
        statisticalLineAndShapeRenderer2.setSeriesLinesVisible(100, false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(paint13);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        java.awt.Paint paint1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder2 = new org.jfree.chart.block.BlockBorder(paint1);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = chartChangeEventType3.equals((java.lang.Object) dateAxis4);
        java.awt.Stroke stroke6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        dateAxis4.setAxisLineStroke(stroke6);
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker((double) '4', paint1, stroke6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker8);
        valueMarker8.setValue(0.0d);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent12 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker8);
        java.awt.Paint paint13 = valueMarker8.getOutlinePaint();
        float float14 = valueMarker8.getAlpha();
        org.jfree.chart.plot.PolarPlot polarPlot15 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint16 = polarPlot15.getRadiusGridlinePaint();
        java.awt.Stroke stroke17 = polarPlot15.getRadiusGridlineStroke();
        java.awt.Paint paint18 = polarPlot15.getAngleLabelPaint();
        java.awt.Paint paint19 = polarPlot15.getAngleGridlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        dateAxis20.setInverted(true);
        java.awt.Shape shape23 = dateAxis20.getDownArrow();
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke25 = dateAxis24.getAxisLineStroke();
        boolean boolean26 = dateAxis24.isAutoTickUnitSelection();
        org.jfree.chart.axis.Timeline timeline27 = dateAxis24.getTimeline();
        dateAxis20.setTimeline(timeline27);
        java.lang.String str29 = dateAxis20.getLabelURL();
        dateAxis20.setVisible(false);
        org.jfree.chart.plot.PiePlot piePlot32 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint33 = piePlot32.getLabelPaint();
        piePlot32.setMinimumArcAngleToDraw((double) (byte) 100);
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance(9999);
        java.awt.Paint paint38 = piePlot32.getSectionPaint((java.lang.Comparable) 9999);
        dateAxis20.setPlot((org.jfree.chart.plot.Plot) piePlot32);
        polarPlot15.setParent((org.jfree.chart.plot.Plot) piePlot32);
        valueMarker8.addChangeListener((org.jfree.chart.event.MarkerChangeListener) piePlot32);
        java.awt.Font font42 = valueMarker8.getLabelFont();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(chartChangeEventType3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 1.0f + "'", float14 == 1.0f);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(timeline27);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNull(paint38);
        org.junit.Assert.assertNotNull(font42);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke2 = dateAxis1.getAxisLineStroke();
        double double3 = dateAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource6 = numberAxis3D5.getStandardTickUnits();
        double double7 = numberAxis3D5.getUpperMargin();
        java.awt.Shape shape8 = numberAxis3D5.getLeftArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer9);
        xYPlot10.clearRangeMarkers((int) (byte) -1);
        xYPlot10.setDomainCrosshairVisible(true);
        org.jfree.chart.LegendItemCollection legendItemCollection15 = xYPlot10.getLegendItems();
        xYPlot10.setDomainGridlinesVisible(true);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = xYPlot10.getRangeAxisEdge((int) 'a');
        java.awt.Stroke stroke20 = xYPlot10.getRangeCrosshairStroke();
        xYPlot10.clearRangeMarkers();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(legendItemCollection15);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator1 = piePlot0.getToolTipGenerator();
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = null;
        piePlot2.setLegendLabelToolTipGenerator(pieSectionLabelGenerator3);
        java.awt.Paint paint5 = piePlot2.getShadowPaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.title.LegendTitle legendTitle7 = jFreeChart6.getLegend();
        java.awt.Font font9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("hi!", font9);
        textTitle10.setURLText("({0}, {1}) = {2}");
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.lang.Object obj16 = textTitle10.draw(graphics2D13, rectangle2D14, (java.lang.Object) "{0}");
        boolean boolean17 = legendTitle7.equals((java.lang.Object) graphics2D13);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = legendTitle7.getLegendItemGraphicPadding();
        java.awt.Paint paint19 = legendTitle7.getBackgroundPaint();
        piePlot0.setLabelShadowPaint(paint19);
        org.junit.Assert.assertNull(pieToolTipGenerator1);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(legendTitle7);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNull(obj16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = chartChangeEventType0.equals((java.lang.Object) dateAxis1);
        dateAxis1.setTickMarkOutsideLength((float) 1);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) '#', (double) '#', 0.0d);
        org.jfree.chart.block.LineBorder lineBorder12 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color5, stroke6, rectangleInsets11);
        dateAxis1.setAxisLinePaint((java.awt.Paint) color5);
        dateAxis1.setLowerMargin((double) (byte) 0);
        boolean boolean16 = dateAxis1.isPositiveArrowVisible();
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        dateAxis18.setInverted(true);
        java.awt.Shape shape21 = dateAxis18.getDownArrow();
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke23 = dateAxis22.getAxisLineStroke();
        boolean boolean24 = dateAxis22.isAutoTickUnitSelection();
        org.jfree.chart.axis.Timeline timeline25 = dateAxis22.getTimeline();
        dateAxis18.setTimeline(timeline25);
        java.lang.String str27 = dateAxis18.getLabelURL();
        dateAxis18.setVisible(false);
        org.jfree.chart.plot.PiePlot piePlot30 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint31 = piePlot30.getLabelPaint();
        piePlot30.setMinimumArcAngleToDraw((double) (byte) 100);
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.createInstance(9999);
        java.awt.Paint paint36 = piePlot30.getSectionPaint((java.lang.Comparable) 9999);
        dateAxis18.setPlot((org.jfree.chart.plot.Plot) piePlot30);
        org.jfree.chart.JFreeChart jFreeChart38 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot30);
        org.jfree.chart.entity.EntityCollection entityCollection41 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo42 = new org.jfree.chart.ChartRenderingInfo(entityCollection41);
        java.awt.image.BufferedImage bufferedImage43 = jFreeChart38.createBufferedImage((int) (short) 1, 255, chartRenderingInfo42);
        java.awt.geom.Rectangle2D rectangle2D44 = chartRenderingInfo42.getChartArea();
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = new org.jfree.chart.axis.CategoryAxis("hi!");
        int int47 = categoryAxis46.getCategoryLabelPositionOffset();
        categoryAxis46.setUpperMargin((double) 'a');
        java.awt.Font font51 = categoryAxis46.getTickLabelFont((java.lang.Comparable) (byte) 100);
        categoryAxis46.setUpperMargin(0.05d);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor54 = null;
        java.awt.geom.Rectangle2D rectangle2D57 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge58 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double59 = categoryAxis46.getCategoryJava2DCoordinate(categoryAnchor54, 11, (-1), rectangle2D57, rectangleEdge58);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer62 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, true);
        statisticalLineAndShapeRenderer62.setUseFillPaint(false);
        org.jfree.chart.axis.NumberAxis numberAxis65 = new org.jfree.chart.axis.NumberAxis();
        numberAxis65.configure();
        boolean boolean67 = statisticalLineAndShapeRenderer62.equals((java.lang.Object) numberAxis65);
        boolean boolean68 = rectangleEdge58.equals((java.lang.Object) numberAxis65);
        double double69 = dateAxis1.java2DToValue((double) (-128), rectangle2D44, rectangleEdge58);
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(timeline25);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertNull(paint36);
        org.junit.Assert.assertNotNull(bufferedImage43);
        org.junit.Assert.assertNotNull(rectangle2D44);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 4 + "'", int47 == 4);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertNotNull(rectangleEdge58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 1.0d + "'", double69 == 1.0d);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        double double1 = axisSpace0.getRight();
        java.lang.Object obj2 = axisSpace0.clone();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(9);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
        java.awt.GradientPaint gradientPaint2 = null;
        java.awt.Shape shape3 = null;
        try {
            java.awt.GradientPaint gradientPaint4 = standardGradientPaintTransformer1.transform(gradientPaint2, shape3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        java.awt.Font font1 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D5 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (-1), 10.0d, true);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer6 = stackedBarRenderer3D5.getGradientPaintTransformer();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType9 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        boolean boolean11 = chartChangeEventType9.equals((java.lang.Object) dateAxis10);
        java.awt.Stroke stroke12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        dateAxis10.setAxisLineStroke(stroke12);
        java.awt.Shape shape14 = dateAxis10.getUpArrow();
        org.jfree.chart.plot.Plot plot15 = dateAxis10.getPlot();
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        stackedBarRenderer3D5.drawRangeGridline(graphics2D7, categoryPlot8, (org.jfree.chart.axis.ValueAxis) dateAxis10, rectangle2D16, 1.05d);
        java.awt.Color color19 = java.awt.Color.lightGray;
        stackedBarRenderer3D5.setBaseItemLabelPaint((java.awt.Paint) color19, true);
        java.lang.Boolean boolean23 = stackedBarRenderer3D5.getSeriesVisibleInLegend(0);
        org.jfree.chart.renderer.category.AreaRenderer areaRenderer24 = new org.jfree.chart.renderer.category.AreaRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = areaRenderer24.getSeriesPositiveItemLabelPosition((int) (short) 0);
        java.awt.Stroke stroke27 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        areaRenderer24.setBaseOutlineStroke(stroke27, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition31 = areaRenderer24.getSeriesNegativeItemLabelPosition((int) (short) 0);
        stackedBarRenderer3D5.setBaseNegativeItemLabelPosition(itemLabelPosition31);
        java.awt.Paint paint33 = stackedBarRenderer3D5.getWallPaint();
        java.awt.Graphics2D graphics2D36 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer37 = new org.jfree.chart.text.G2TextMeasurer(graphics2D36);
        try {
            org.jfree.chart.text.TextBlock textBlock38 = org.jfree.chart.text.TextUtilities.createTextBlock("TextAnchor.TOP_CENTER", font1, paint33, (float) 7, (-15), (org.jfree.chart.text.TextMeasurer) g2TextMeasurer37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gradientPaintTransformer6);
        org.junit.Assert.assertNotNull(chartChangeEventType9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNull(plot15);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNull(boolean23);
        org.junit.Assert.assertNotNull(itemLabelPosition26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(itemLabelPosition31);
        org.junit.Assert.assertNotNull(paint33);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = piePlot0.getLabelPaint();
        piePlot0.setMinimumArcAngleToDraw((double) (byte) 100);
        java.lang.Class<?> wildcardClass4 = piePlot0.getClass();
        java.awt.Paint paint5 = piePlot0.getLabelOutlinePaint();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) '#', (double) '#', 0.0d);
        org.jfree.chart.block.LineBorder lineBorder13 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color6, stroke7, rectangleInsets12);
        double double15 = rectangleInsets12.calculateBottomInset((double) (short) 1);
        double double17 = rectangleInsets12.calculateRightInset((double) (byte) 100);
        boolean boolean18 = piePlot0.equals((java.lang.Object) rectangleInsets12);
        double double20 = rectangleInsets12.calculateLeftOutset(12.0d);
        double double22 = rectangleInsets12.calculateRightOutset((double) 100L);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 35.0d + "'", double15 == 35.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 35.0d + "'", double20 == 35.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource3 = numberAxis3D2.getStandardTickUnits();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.axis.AxisState axisState5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        java.util.List list8 = numberAxis3D2.refreshTicks(graphics2D4, axisState5, rectangle2D6, rectangleEdge7);
        org.jfree.data.Range range12 = new org.jfree.data.Range((double) (-1L), (double) '4');
        double double14 = range12.constrain((double) (short) 10);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = new org.jfree.chart.block.RectangleConstraint(10.0d, range12);
        numberAxis3D2.setRangeWithMargins(range12, false, false);
        java.awt.Font font19 = numberAxis3D2.getTickLabelFont();
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        java.awt.Color color21 = color20.darker();
        int int22 = color21.getBlue();
        org.jfree.chart.block.LabelBlock labelBlock23 = new org.jfree.chart.block.LabelBlock("PlotOrientation.HORIZONTAL", font19, (java.awt.Paint) color21);
        org.junit.Assert.assertNotNull(tickUnitSource3);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 10.0d + "'", double14 == 10.0d);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 89 + "'", int22 == 89);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke2 = dateAxis1.getAxisLineStroke();
        double double3 = dateAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource6 = numberAxis3D5.getStandardTickUnits();
        double double7 = numberAxis3D5.getUpperMargin();
        java.awt.Shape shape8 = numberAxis3D5.getLeftArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer9);
        xYPlot10.clearRangeMarkers((int) (byte) -1);
        xYPlot10.setDomainCrosshairVisible(true);
        org.jfree.chart.LegendItemCollection legendItemCollection15 = xYPlot10.getLegendItems();
        org.jfree.chart.util.Layer layer16 = org.jfree.chart.util.Layer.BACKGROUND;
        java.lang.String str17 = layer16.toString();
        java.util.Collection collection18 = xYPlot10.getDomainMarkers(layer16);
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = xYPlot10.getRendererForDataset(xYDataset19);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(legendItemCollection15);
        org.junit.Assert.assertNotNull(layer16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Layer.BACKGROUND" + "'", str17.equals("Layer.BACKGROUND"));
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertNull(xYItemRenderer20);
    }
}

