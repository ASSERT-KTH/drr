import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        java.awt.Paint paint1 = null;
        java.awt.Stroke stroke2 = null;
        try {
            org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) -1, paint1, stroke2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_RED;
        int int1 = color0.getBlue();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 64 + "'", int1 == 64);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.lang.String str1 = color0.toString();
        float[] floatArray5 = new float[] { 0.0f, (byte) 0, (byte) 0 };
        try {
            float[] floatArray6 = color0.getRGBComponents(floatArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java.awt.Color[r=128,g=0,b=0]" + "'", str1.equals("java.awt.Color[r=128,g=0,b=0]"));
        org.junit.Assert.assertNotNull(floatArray5);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        java.awt.Paint paint1 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke2 = null;
        try {
            org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (-1), paint1, stroke2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        try {
            java.awt.Color color1 = java.awt.Color.decode("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Zero length string");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot6.getDrawingSupplier();
        org.jfree.chart.plot.Marker marker9 = null;
        org.jfree.chart.util.Layer layer10 = org.jfree.chart.util.Layer.FOREGROUND;
        try {
            categoryPlot6.addRangeMarker(marker9, layer10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(layer10);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        java.lang.Object obj8 = categoryPlot6.clone();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        int int1 = color0.getGreen();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.Stroke stroke2 = null;
        try {
            org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) 'a', (java.awt.Paint) color1, stroke2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_INCLUDES_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        int int8 = categoryPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.data.Range range9 = null;
        try {
            dateAxis7.setRange(range9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        java.awt.Paint paint7 = categoryPlot6.getDomainGridlinePaint();
        int int8 = categoryPlot6.getBackgroundImageAlignment();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation9 = null;
        try {
            categoryPlot6.addAnnotation(categoryAnnotation9, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 15 + "'", int8 == 15);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        try {
            java.awt.Paint paint2 = xYPlot0.getQuadrantPaint((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (97) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_STICKY_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeZeroBaselineVisible(false);
        boolean boolean3 = xYPlot0.isOutlineVisible();
        xYPlot0.clearRangeAxes();
        xYPlot0.setDomainCrosshairLockedOnData(true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        java.awt.Font font8 = categoryPlot6.getNoDataMessageFont();
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = categoryPlot6.getRangeAxisEdge((int) (short) 10);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        categoryPlot6.setDomainAxis(categoryAxis11);
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = null;
        org.jfree.chart.util.Layer layer15 = org.jfree.chart.util.Layer.FOREGROUND;
        try {
            categoryPlot6.addDomainMarker((int) (short) 1, categoryMarker14, layer15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNotNull(layer15);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        java.awt.Paint paint7 = categoryPlot6.getDomainGridlinePaint();
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        try {
            categoryPlot6.setDataset((int) (short) -1, categoryDataset9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean2 = dateAxis1.isNegativeArrowVisible();
        dateAxis1.setAutoRangeMinimumSize((double) (short) 1, true);
        org.jfree.chart.axis.Timeline timeline6 = null;
        dateAxis1.setTimeline(timeline6);
        try {
            dateAxis1.setRange((double) 100, 100.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        java.awt.Color color1 = java.awt.Color.getColor("");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeZeroBaselineVisible(false);
        boolean boolean3 = xYPlot0.isOutlineVisible();
        xYPlot0.clearRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation6 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot0.setDomainAxisLocation(64, axisLocation6);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean13 = dateAxis12.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis12, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getDomainGridlinePaint();
        java.lang.Object obj17 = categoryPlot15.clone();
        boolean boolean18 = categoryPlot15.isRangeZoomable();
        java.awt.Paint paint19 = categoryPlot15.getOutlinePaint();
        try {
            xYPlot0.setQuadrantPaint((int) '#', paint19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (35) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean2 = dateAxis1.isNegativeArrowVisible();
        double double3 = dateAxis1.getLowerBound();
        java.awt.Paint paint4 = dateAxis1.getTickLabelPaint();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean10 = dateAxis9.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis9, categoryItemRenderer11);
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean18 = dateAxis17.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, (org.jfree.chart.axis.ValueAxis) dateAxis17, categoryItemRenderer19);
        boolean boolean21 = categoryPlot20.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier22 = categoryPlot20.getDrawingSupplier();
        categoryPlot20.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = categoryPlot20.getDomainAxisEdge(10);
        org.jfree.chart.axis.AxisSpace axisSpace26 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace27 = dateAxis1.reserveSpace(graphics2D5, (org.jfree.chart.plot.Plot) categoryPlot12, rectangle2D13, rectangleEdge25, axisSpace26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(drawingSupplier22);
        org.junit.Assert.assertNotNull(rectangleEdge25);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-8d + "'", double0 == 1.0E-8d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean2 = dateAxis1.isNegativeArrowVisible();
        double double3 = dateAxis1.getLowerBound();
        java.awt.Paint paint4 = null;
        try {
            dateAxis1.setLabelPaint(paint4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        dateAxis0.setTickLabelPaint((java.awt.Paint) color1);
        java.awt.Stroke stroke3 = null;
        try {
            dateAxis0.setTickMarkStroke(stroke3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.color.ColorSpace colorSpace1 = null;
        float[] floatArray7 = new float[] { 'a', (byte) -1, (byte) 10, 0.0f, 0 };
        try {
            float[] floatArray8 = color0.getComponents(colorSpace1, floatArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray7);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        java.awt.Paint paint8 = categoryPlot6.getDomainGridlinePaint();
        java.awt.Image image9 = null;
        categoryPlot6.setBackgroundImage(image9);
        categoryPlot6.setDomainGridlinesVisible(true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_OUTSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 2.0f + "'", float0 == 2.0f);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeZeroBaselineVisible(false);
        boolean boolean3 = xYPlot0.isOutlineVisible();
        xYPlot0.clearRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation6 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot0.setDomainAxisLocation(64, axisLocation6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        xYPlot0.zoomDomainAxes((double) (-8388608), (double) (byte) 0, plotRenderingInfo10, point2D11);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(axisLocation6);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.color.ColorSpace colorSpace1 = null;
        float[] floatArray8 = new float[] { (-8388608), 10L, (byte) 100, 100, (-1.0f), 10L };
        try {
            float[] floatArray9 = color0.getColorComponents(colorSpace1, floatArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray8);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = dateAxis3.getTickLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        dateAxis8.setTickLabelPaint((java.awt.Paint) color9);
        boolean boolean11 = rectangleInsets7.equals((java.lang.Object) dateAxis8);
        java.lang.String str12 = rectangleInsets7.toString();
        org.jfree.chart.util.UnitType unitType13 = rectangleInsets7.getUnitType();
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        try {
            rectangleInsets7.trim(rectangle2D14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str12.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
        org.junit.Assert.assertNotNull(unitType13);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        java.awt.Color color0 = java.awt.Color.WHITE;
        float[] floatArray1 = new float[] {};
        try {
            float[] floatArray2 = color0.getColorComponents(floatArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray1);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_YELLOW;
        int int1 = color0.getAlpha();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        categoryPlot6.mapDatasetToDomainAxis(100, (int) 'a');
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        categoryPlot6.setRenderer(255, categoryItemRenderer12, false);
        double double15 = categoryPlot6.getRangeCrosshairValue();
        java.awt.Paint paint16 = categoryPlot6.getOutlinePaint();
        int int17 = categoryPlot6.getRangeAxisCount();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        java.awt.Color color0 = java.awt.Color.ORANGE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot6.getDrawingSupplier();
        categoryPlot6.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot6.getDomainAxisEdge(10);
        boolean boolean12 = categoryPlot6.isRangeZoomable();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation13 = null;
        try {
            categoryPlot6.addAnnotation(categoryAnnotation13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.data.time.SerialDate serialDate0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(serialDate0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'serialDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_DOMAIN_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setUpperMargin((double) 'a');
        dateAxis0.setTickMarkOutsideLength((float) 192);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range6 = dateAxis5.getDefaultAutoRange();
        xYPlot3.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis5);
        java.awt.Paint paint8 = xYPlot3.getOutlinePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = xYPlot3.getRangeAxisEdge();
        try {
            double double10 = dateAxis0.lengthToJava2D(1.0E-8d, rectangle2D2, rectangleEdge9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(rectangleEdge9);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_UPPER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        java.awt.Paint paint2 = null;
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range6 = dateAxis5.getDefaultAutoRange();
        xYPlot3.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis5);
        java.awt.Paint paint8 = xYPlot3.getOutlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        xYPlot3.zoomRangeAxes((double) (byte) 100, plotRenderingInfo10, point2D11, false);
        java.awt.Stroke stroke14 = xYPlot3.getRangeGridlineStroke();
        java.awt.Color color15 = java.awt.Color.GREEN;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range19 = dateAxis18.getDefaultAutoRange();
        xYPlot16.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis18);
        java.awt.Paint paint21 = xYPlot16.getOutlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        xYPlot16.zoomRangeAxes((double) (byte) 100, plotRenderingInfo23, point2D24, false);
        java.awt.Stroke stroke27 = xYPlot16.getRangeGridlineStroke();
        try {
            org.jfree.chart.plot.IntervalMarker intervalMarker29 = new org.jfree.chart.plot.IntervalMarker((double) 2.0f, (double) (byte) 10, paint2, stroke14, (java.awt.Paint) color15, stroke27, (float) 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke27);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = dateAxis3.getTickLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        dateAxis8.setTickLabelPaint((java.awt.Paint) color9);
        boolean boolean11 = rectangleInsets7.equals((java.lang.Object) dateAxis8);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean20 = dateAxis19.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, (org.jfree.chart.axis.ValueAxis) dateAxis19, categoryItemRenderer21);
        boolean boolean23 = categoryPlot22.isOutlineVisible();
        java.awt.Font font24 = categoryPlot22.getNoDataMessageFont();
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot22.getRangeAxisEdge((int) (short) 10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        try {
            org.jfree.chart.axis.AxisState axisState28 = dateAxis8.draw(graphics2D12, (double) (byte) 10, rectangle2D14, rectangle2D15, rectangleEdge26, plotRenderingInfo27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(rectangleEdge26);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        xYPlot0.setDataset(xYDataset5);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        xYPlot0.setDomainTickBandPaint((java.awt.Paint) color7);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        int int10 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis9);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        java.awt.Paint paint8 = categoryPlot6.getDomainGridlinePaint();
        java.awt.Image image9 = null;
        categoryPlot6.setBackgroundImage(image9);
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        xYPlot12.setRangeZeroBaselineVisible(false);
        boolean boolean15 = xYPlot12.isOutlineVisible();
        xYPlot12.clearRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot12.setDomainAxisLocation(64, axisLocation18);
        categoryPlot6.setRangeAxisLocation(12, axisLocation18);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation21 = null;
        try {
            categoryPlot6.addAnnotation(categoryAnnotation21, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(axisLocation18);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        java.awt.Stroke stroke2 = numberAxis1.getTickMarkStroke();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = numberAxis1.getMarkerBand();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(markerAxisBand3);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot6.getDrawingSupplier();
        categoryPlot6.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot6.getDomainAxisEdge(10);
        boolean boolean12 = categoryPlot6.isRangeZoomable();
        categoryPlot6.setOutlineVisible(true);
        categoryPlot6.setRangeCrosshairLockedOnData(false);
        double double17 = categoryPlot6.getRangeCrosshairValue();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(12, (int) (byte) 1, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean2 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot3 = dateAxis1.getPlot();
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis1.setLabelPaint((java.awt.Paint) color4);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot6.getDrawingSupplier();
        categoryPlot6.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot6.getDomainAxisEdge(10);
        boolean boolean12 = categoryPlot6.isRangeZoomable();
        java.awt.Paint paint13 = categoryPlot6.getDomainGridlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot6.setDomainAxisLocation(64, axisLocation15, false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder18 = categoryPlot6.getDatasetRenderingOrder();
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean23 = dateAxis22.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, (org.jfree.chart.axis.ValueAxis) dateAxis22, categoryItemRenderer24);
        dateAxis22.resizeRange((double) 100.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = dateAxis22.getLabelInsets();
        categoryPlot6.setAxisOffset(rectangleInsets28);
        double double31 = rectangleInsets28.calculateTopOutset((double) 1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(datasetRenderingOrder18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 3.0d + "'", double31 == 3.0d);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABELS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 3, 100.0d);
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range6 = dateAxis5.getDefaultAutoRange();
        xYPlot3.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis5);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot3.setRangeCrosshairStroke(stroke8);
        intervalMarker2.setStroke(stroke8);
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        intervalMarker2.setOutlinePaint((java.awt.Paint) color11);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent13 = null;
        intervalMarker2.notifyListeners(markerChangeEvent13);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean5 = dateAxis4.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        org.jfree.data.Range range8 = dateAxis4.getRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis4);
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = null;
        dateAxis4.setTickUnit(dateTickUnit10);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(range8);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeZeroBaselineVisible(false);
        boolean boolean3 = xYPlot0.isOutlineVisible();
        xYPlot0.clearRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation6 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot0.setDomainAxisLocation(64, axisLocation6);
        org.jfree.chart.plot.Plot plot8 = xYPlot0.getParent();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNull(plot8);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean5 = dateAxis4.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        org.jfree.data.Range range8 = dateAxis4.getRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis4);
        java.awt.Stroke stroke10 = xYPlot0.getDomainCrosshairStroke();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.awt.geom.Point2D point2D13 = null;
        org.jfree.chart.plot.PlotState plotState14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        try {
            xYPlot0.draw(graphics2D11, rectangle2D12, point2D13, plotState14, plotRenderingInfo15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        java.awt.Paint paint5 = xYPlot0.getOutlinePaint();
        xYPlot0.setRangeCrosshairValue(1.0E-8d);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        xYPlot0.setAxisOffset(rectangleInsets8);
        org.jfree.chart.util.UnitType unitType10 = rectangleInsets8.getUnitType();
        double double12 = rectangleInsets8.calculateRightInset((double) (-1));
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(unitType10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 8.0d + "'", double12 == 8.0d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_VERTICAL_TICK_LABELS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        java.awt.Color color1 = java.awt.Color.getColor("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean12 = dateAxis11.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis11, categoryItemRenderer13);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = dateAxis11.getTickLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        dateAxis16.setTickLabelPaint((java.awt.Paint) color17);
        boolean boolean19 = rectangleInsets15.equals((java.lang.Object) dateAxis16);
        java.lang.String str20 = rectangleInsets15.toString();
        org.jfree.chart.util.UnitType unitType21 = rectangleInsets15.getUnitType();
        double double22 = rectangleInsets15.getBottom();
        categoryPlot6.setAxisOffset(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str20.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
        org.junit.Assert.assertNotNull(unitType21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 2.0d + "'", double22 == 2.0d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Paint[] paintArray3 = new java.awt.Paint[] { color1, color2 };
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Paint paint5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Paint paint7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        java.awt.Paint[] paintArray8 = new java.awt.Paint[] { color4, paint5, color6, paint7 };
        java.awt.Stroke stroke9 = null;
        java.awt.Stroke[] strokeArray10 = new java.awt.Stroke[] { stroke9 };
        java.awt.Stroke[] strokeArray11 = null;
        java.awt.Shape[] shapeArray12 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier13 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray3, paintArray8, strokeArray10, strokeArray11, shapeArray12);
        java.awt.Paint paint14 = defaultDrawingSupplier13.getNextFillPaint();
        java.lang.Object obj15 = defaultDrawingSupplier13.clone();
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paintArray3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paintArray8);
        org.junit.Assert.assertNotNull(strokeArray10);
        org.junit.Assert.assertNotNull(shapeArray12);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(obj15);
    }

//    @Test
//    public void test084() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test084");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getMiddleMillisecond();
//        java.util.Calendar calendar2 = null;
//        try {
//            long long3 = day0.getMiddleMillisecond(calendar2);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560452399999L + "'", long1 == 1560452399999L);
//    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        categoryPlot6.clearRangeMarkers(0);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = null;
        categoryPlot6.markerChanged(markerChangeEvent9);
        boolean boolean11 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        org.jfree.chart.util.Layer layer6 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean8 = layer6.equals((java.lang.Object) true);
        java.util.Collection collection9 = xYPlot0.getRangeMarkers((int) '#', layer6);
        try {
            java.awt.Paint paint11 = xYPlot0.getQuadrantPaint((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (-1) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(layer6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(collection9);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        xYPlot0.setDataset(xYDataset5);
        java.awt.Stroke stroke7 = null;
        try {
            xYPlot0.setDomainZeroBaselineStroke(stroke7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range3);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean2 = dateAxis1.isNegativeArrowVisible();
        dateAxis1.setAutoRangeMinimumSize((double) (short) 1, true);
        org.jfree.chart.axis.Timeline timeline6 = null;
        dateAxis1.setTimeline(timeline6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean12 = dateAxis11.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis11, categoryItemRenderer13);
        boolean boolean15 = categoryPlot14.isOutlineVisible();
        java.awt.Paint paint16 = categoryPlot14.getDomainGridlinePaint();
        java.lang.String str17 = categoryPlot14.getNoDataMessage();
        dateAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot14);
        java.util.Date date19 = null;
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean24 = dateAxis23.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, (org.jfree.chart.axis.ValueAxis) dateAxis23, categoryItemRenderer25);
        dateAxis23.resizeRange((double) 100.0f);
        java.util.Date date29 = dateAxis23.getMaximumDate();
        try {
            dateAxis1.setRange(date19, date29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(date29);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean2 = dateAxis1.isNegativeArrowVisible();
        dateAxis1.setFixedDimension((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        org.jfree.chart.plot.Marker marker5 = null;
        boolean boolean6 = xYPlot0.removeDomainMarker(marker5);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation7 = null;
        try {
            xYPlot0.addAnnotation(xYAnnotation7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        java.awt.Stroke stroke2 = numberAxis1.getTickMarkStroke();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis1.setTickUnit(numberTickUnit3);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean11 = dateAxis10.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis10, categoryItemRenderer12);
        boolean boolean14 = categoryPlot13.isOutlineVisible();
        java.awt.Font font15 = categoryPlot13.getNoDataMessageFont();
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot13.getRangeAxisEdge((int) (short) 10);
        try {
            double double18 = numberAxis1.valueToJava2D(0.0d, rectangle2D6, rectangleEdge17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(numberTickUnit3);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(rectangleEdge17);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot6.getDrawingSupplier();
        categoryPlot6.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot6.getDomainAxisEdge(10);
        boolean boolean12 = categoryPlot6.isRangeZoomable();
        java.awt.Paint paint13 = categoryPlot6.getDomainGridlinePaint();
        java.awt.Paint paint14 = categoryPlot6.getOutlinePaint();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation15 = null;
        try {
            boolean boolean17 = categoryPlot6.removeAnnotation(categoryAnnotation15, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isTickMarksVisible();
        dateAxis0.setLowerMargin(10.0d);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        java.awt.Paint paint7 = categoryPlot6.getDomainGridlinePaint();
        java.lang.Object obj8 = categoryPlot6.clone();
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean13 = dateAxis12.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis12, categoryItemRenderer14);
        dateAxis12.resizeRange((double) 100.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = dateAxis12.getLabelInsets();
        int int19 = categoryPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis12);
        org.jfree.chart.axis.AxisLocation axisLocation20 = categoryPlot6.getRangeAxisLocation();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(axisLocation20);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        java.lang.String str1 = seriesRenderingOrder0.toString();
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SeriesRenderingOrder.FORWARD" + "'", str1.equals("SeriesRenderingOrder.FORWARD"));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_TICK_UNIT_SELECTION;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        int int8 = categoryPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.data.Range range10 = categoryPlot6.getDataRange(valueAxis9);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNull(range10);
    }

//    @Test
//    public void test099() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test099");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getMiddleMillisecond();
//        int int2 = day0.getDayOfMonth();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = day0.getLastMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560452399999L + "'", long1 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//    }

//    @Test
//    public void test100() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test100");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        java.awt.Paint paint5 = xYPlot0.getOutlinePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = xYPlot0.getRangeAxisEdge();
        java.awt.Paint paint8 = null;
        xYPlot0.setQuadrantPaint(0, paint8);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        java.awt.Stroke stroke2 = numberAxis1.getTickMarkStroke();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis1.setTickUnit(numberTickUnit3);
        boolean boolean5 = numberAxis1.isAutoTickUnitSelection();
        java.text.NumberFormat numberFormat6 = null;
        numberAxis1.setNumberFormatOverride(numberFormat6);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(numberTickUnit3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        java.awt.Paint paint7 = categoryPlot6.getDomainGridlinePaint();
        java.lang.Object obj8 = categoryPlot6.clone();
        boolean boolean9 = categoryPlot6.isRangeZoomable();
        double double10 = categoryPlot6.getAnchorValue();
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = null;
        org.jfree.chart.util.Layer layer12 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean14 = layer12.equals((java.lang.Object) true);
        try {
            categoryPlot6.addDomainMarker(categoryMarker11, layer12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(layer12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot6.getDrawingSupplier();
        categoryPlot6.clearRangeAxes();
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        categoryPlot6.setFixedRangeAxisSpace(axisSpace10);
        org.jfree.chart.plot.Marker marker13 = null;
        org.jfree.chart.util.Layer layer14 = org.jfree.chart.util.Layer.FOREGROUND;
        try {
            boolean boolean16 = categoryPlot6.removeRangeMarker(11, marker13, layer14, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(layer14);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        java.awt.Paint paint5 = xYPlot0.getOutlinePaint();
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        xYPlot7.setRangeZeroBaselineVisible(false);
        boolean boolean10 = xYPlot7.isOutlineVisible();
        xYPlot7.clearRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot7.setDomainAxisLocation(64, axisLocation13);
        xYPlot0.setDomainAxisLocation(2, axisLocation13);
        org.jfree.chart.axis.AxisLocation axisLocation16 = xYPlot0.getDomainAxisLocation();
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean22 = dateAxis21.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis21, categoryItemRenderer23);
        org.jfree.data.Range range25 = dateAxis21.getRange();
        xYPlot17.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis21);
        dateAxis21.resizeRange((double) 8);
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range31 = dateAxis30.getDefaultAutoRange();
        java.awt.Paint paint32 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        dateAxis30.setAxisLinePaint(paint32);
        dateAxis30.setAutoRange(true);
        org.jfree.data.category.CategoryDataset categoryDataset36 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = null;
        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean40 = dateAxis39.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer41 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis37, (org.jfree.chart.axis.ValueAxis) dateAxis39, categoryItemRenderer41);
        org.jfree.chart.axis.DateAxis dateAxis43 = new org.jfree.chart.axis.DateAxis();
        int int44 = categoryPlot42.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis43);
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean47 = dateAxis46.isNegativeArrowVisible();
        org.jfree.data.category.CategoryDataset categoryDataset48 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = null;
        org.jfree.chart.axis.DateAxis dateAxis51 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean52 = dateAxis51.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset48, categoryAxis49, (org.jfree.chart.axis.ValueAxis) dateAxis51, categoryItemRenderer53);
        dateAxis51.resizeRange((double) 100.0f);
        java.awt.Shape shape57 = dateAxis51.getDownArrow();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray58 = new org.jfree.chart.axis.ValueAxis[] { dateAxis21, dateAxis30, dateAxis43, dateAxis46, dateAxis51 };
        xYPlot0.setDomainAxes(valueAxisArray58);
        int int60 = xYPlot0.getRangeAxisCount();
        java.lang.String str61 = xYPlot0.getNoDataMessage();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(shape57);
        org.junit.Assert.assertNotNull(valueAxisArray58);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1 + "'", int60 == 1);
        org.junit.Assert.assertNull(str61);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 3, 100.0d);
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean7 = dateAxis6.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis6, categoryItemRenderer8);
        boolean boolean10 = categoryPlot9.isOutlineVisible();
        java.awt.Paint paint11 = categoryPlot9.getDomainGridlinePaint();
        java.lang.String str12 = categoryPlot9.getNoDataMessage();
        intervalMarker2.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot9);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder14 = categoryPlot9.getDatasetRenderingOrder();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        try {
            categoryPlot9.handleClick(13, 10, plotRenderingInfo17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(datasetRenderingOrder14);
    }

//    @Test
//    public void test107() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test107");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getMiddleMillisecond();
//        int int2 = day0.getDayOfMonth();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = day0.getFirstMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560452399999L + "'", long1 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("", timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 3, 100.0d);
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range6 = dateAxis5.getDefaultAutoRange();
        xYPlot3.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis5);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot3.setRangeCrosshairStroke(stroke8);
        intervalMarker2.setStroke(stroke8);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.CENTER;
        intervalMarker2.setLabelAnchor(rectangleAnchor11);
        java.awt.Color color13 = java.awt.Color.red;
        intervalMarker2.setLabelPaint((java.awt.Paint) color13);
        org.jfree.chart.text.TextAnchor textAnchor15 = intervalMarker2.getLabelTextAnchor();
        intervalMarker2.setEndValue((double) (byte) -1);
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean22 = dateAxis21.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis21, categoryItemRenderer23);
        boolean boolean25 = categoryPlot24.isOutlineVisible();
        java.awt.Paint paint26 = categoryPlot24.getDomainGridlinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = categoryPlot24.getDomainAxisForDataset((int) (short) 0);
        org.jfree.data.category.CategoryDataset categoryDataset29 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = null;
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean33 = dateAxis32.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset29, categoryAxis30, (org.jfree.chart.axis.ValueAxis) dateAxis32, categoryItemRenderer34);
        org.jfree.data.Range range36 = dateAxis32.getRange();
        int int37 = categoryPlot24.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis32);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent38 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot24);
        intervalMarker2.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot24);
        org.jfree.chart.axis.AxisSpace axisSpace40 = categoryPlot24.getFixedDomainAxisSpace();
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(textAnchor15);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNull(categoryAxis28);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(range36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertNull(axisSpace40);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        java.awt.Paint paint8 = categoryPlot6.getDomainGridlinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot6.getDomainAxisForDataset((int) (short) 0);
        java.awt.Font font11 = categoryPlot6.getNoDataMessageFont();
        boolean boolean12 = categoryPlot6.isDomainGridlinesVisible();
        org.jfree.chart.event.PlotChangeListener plotChangeListener13 = null;
        categoryPlot6.removeChangeListener(plotChangeListener13);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor(2, (int) '4', 192);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean2 = dateAxis1.isNegativeArrowVisible();
        float float3 = dateAxis1.getTickMarkInsideLength();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        double double0 = org.jfree.chart.axis.DateAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE_IN_MILLISECONDS;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.0d + "'", double0 == 2.0d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean2 = dateAxis1.isNegativeArrowVisible();
        dateAxis1.setAutoRangeMinimumSize((double) (short) 1, true);
        java.awt.Shape shape6 = dateAxis1.getUpArrow();
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean11 = dateAxis10.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis10, categoryItemRenderer12);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = dateAxis10.getTickLabelInsets();
        dateAxis1.setLabelInsets(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(rectangleInsets14);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        java.awt.Stroke stroke2 = numberAxis1.getTickMarkStroke();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis1.setTickUnit(numberTickUnit3);
        boolean boolean5 = numberAxis1.isAutoTickUnitSelection();
        org.jfree.data.RangeType rangeType6 = null;
        try {
            numberAxis1.setRangeType(rangeType6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rangeType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(numberTickUnit3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (byte) 0, 1);
        float[] floatArray10 = new float[] { 1, 1L, 0L };
        float[] floatArray11 = java.awt.Color.RGBtoHSB((int) (short) -1, 8, 0, floatArray10);
        try {
            float[] floatArray12 = chartColor3.getComponents(floatArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        java.awt.Paint paint7 = categoryPlot6.getDomainGridlinePaint();
        java.lang.Object obj8 = categoryPlot6.clone();
        boolean boolean9 = categoryPlot6.isRangeZoomable();
        java.awt.Paint paint10 = categoryPlot6.getOutlinePaint();
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = null;
        org.jfree.chart.util.Layer layer13 = org.jfree.chart.util.Layer.BACKGROUND;
        try {
            categoryPlot6.addDomainMarker((-1), categoryMarker12, layer13, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(layer13);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        java.awt.Paint paint5 = xYPlot0.getOutlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        xYPlot0.zoomRangeAxes((double) (byte) 100, plotRenderingInfo7, point2D8, false);
        java.awt.Stroke stroke11 = xYPlot0.getRangeGridlineStroke();
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_YELLOW;
        xYPlot0.setRangeGridlinePaint((java.awt.Paint) color12);
        org.jfree.chart.plot.IntervalMarker intervalMarker16 = new org.jfree.chart.plot.IntervalMarker((double) 64, (double) 12);
        java.lang.Object obj17 = intervalMarker16.clone();
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker16);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(obj17);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        java.awt.Paint paint8 = categoryPlot6.getDomainGridlinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot6.getDomainAxisForDataset((int) (short) 0);
        categoryPlot6.clearRangeAxes();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryAxis10);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        org.jfree.chart.plot.Marker marker5 = null;
        boolean boolean6 = xYPlot0.removeDomainMarker(marker5);
        xYPlot0.setDomainCrosshairValue((double) (-1), true);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean12 = dateAxis11.isNegativeArrowVisible();
        dateAxis11.setAutoRangeMinimumSize((double) (short) 1, true);
        org.jfree.chart.axis.Timeline timeline16 = null;
        dateAxis11.setTimeline(timeline16);
        boolean boolean18 = xYPlot0.equals((java.lang.Object) dateAxis11);
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range22 = dateAxis21.getDefaultAutoRange();
        xYPlot19.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis21);
        java.awt.Paint paint24 = xYPlot19.getDomainGridlinePaint();
        xYPlot0.setRangeGridlinePaint(paint24);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent26 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYPlot0);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNotNull(paint24);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.plot.IntervalMarker intervalMarker5 = new org.jfree.chart.plot.IntervalMarker((double) 3, 100.0d);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range9 = dateAxis8.getDefaultAutoRange();
        xYPlot6.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis8);
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot6.setRangeCrosshairStroke(stroke11);
        intervalMarker5.setStroke(stroke11);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = org.jfree.chart.util.RectangleAnchor.CENTER;
        intervalMarker5.setLabelAnchor(rectangleAnchor14);
        try {
            java.awt.geom.Rectangle2D rectangle2D16 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) 192, (double) 15, rectangleAnchor14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(rectangleAnchor14);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeZeroBaselineVisible(false);
        boolean boolean3 = xYPlot0.isOutlineVisible();
        xYPlot0.clearRangeAxes();
        java.awt.Image image5 = xYPlot0.getBackgroundImage();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(image5);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 3, 100.0d);
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range6 = dateAxis5.getDefaultAutoRange();
        xYPlot3.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis5);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot3.setRangeCrosshairStroke(stroke8);
        intervalMarker2.setStroke(stroke8);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.CENTER;
        intervalMarker2.setLabelAnchor(rectangleAnchor11);
        java.awt.Color color13 = java.awt.Color.red;
        intervalMarker2.setLabelPaint((java.awt.Paint) color13);
        int int15 = color13.getAlpha();
        java.awt.Color color16 = color13.brighter();
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 255 + "'", int15 == 255);
        org.junit.Assert.assertNotNull(color16);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        org.jfree.chart.util.Layer layer6 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean8 = layer6.equals((java.lang.Object) true);
        java.util.Collection collection9 = xYPlot0.getRangeMarkers((int) '#', layer6);
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        java.awt.geom.Point2D point2D12 = null;
        org.jfree.chart.plot.PlotState plotState13 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        try {
            xYPlot0.draw(graphics2D10, rectangle2D11, point2D12, plotState13, plotRenderingInfo14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(layer6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(collection9);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean5 = dateAxis4.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        org.jfree.data.Range range8 = dateAxis4.getRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis4);
        java.awt.Stroke stroke10 = xYPlot0.getDomainCrosshairStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        try {
            xYPlot0.handleClick(0, (int) (byte) -1, plotRenderingInfo13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        java.awt.Paint paint7 = categoryPlot6.getDomainGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot6.getRenderer((int) (byte) 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation10 = null;
        try {
            boolean boolean12 = categoryPlot6.removeAnnotation(categoryAnnotation10, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(categoryItemRenderer9);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        java.awt.Color color0 = java.awt.Color.gray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        xYPlot0.setDataset(xYDataset5);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        xYPlot0.setRangeGridlinePaint((java.awt.Paint) color7);
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_RED;
        float[] floatArray16 = new float[] { 1, 1L, 0L };
        float[] floatArray17 = java.awt.Color.RGBtoHSB((int) (short) -1, 8, 0, floatArray16);
        float[] floatArray18 = color9.getRGBColorComponents(floatArray16);
        try {
            float[] floatArray19 = color7.getComponents(floatArray18);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean5 = dateAxis4.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        org.jfree.data.Range range8 = dateAxis4.getRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis4);
        dateAxis4.resizeRange((double) 8);
        java.awt.Paint paint12 = dateAxis4.getAxisLinePaint();
        dateAxis4.setAutoTickUnitSelection(false, false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        java.awt.Paint paint5 = xYPlot0.getOutlinePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = xYPlot0.getRangeAxisEdge();
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = xYPlot0.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = xYPlot0.getLegendItems();
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        xYPlot9.setRangeZeroBaselineVisible(false);
        boolean boolean12 = xYPlot9.isOutlineVisible();
        xYPlot9.clearRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot9.setDomainAxisLocation(64, axisLocation15);
        java.awt.Paint paint17 = xYPlot9.getDomainGridlinePaint();
        xYPlot0.setNoDataMessagePaint(paint17);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(plotOrientation7);
        org.junit.Assert.assertNotNull(legendItemCollection8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        java.awt.Color color0 = java.awt.Color.YELLOW;
        int int1 = color0.getAlpha();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Paint[] paintArray3 = new java.awt.Paint[] { color1, color2 };
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Paint paint5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Paint paint7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        java.awt.Paint[] paintArray8 = new java.awt.Paint[] { color4, paint5, color6, paint7 };
        java.awt.Stroke stroke9 = null;
        java.awt.Stroke[] strokeArray10 = new java.awt.Stroke[] { stroke9 };
        java.awt.Stroke[] strokeArray11 = null;
        java.awt.Shape[] shapeArray12 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier13 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray3, paintArray8, strokeArray10, strokeArray11, shapeArray12);
        try {
            java.awt.Stroke stroke14 = defaultDrawingSupplier13.getNextOutlineStroke();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paintArray3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paintArray8);
        org.junit.Assert.assertNotNull(strokeArray10);
        org.junit.Assert.assertNotNull(shapeArray12);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot6.getDrawingSupplier();
        categoryPlot6.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot6.getDomainAxisEdge(10);
        boolean boolean12 = categoryPlot6.isRangeZoomable();
        java.awt.Paint paint13 = categoryPlot6.getDomainGridlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot6.setDomainAxisLocation(64, axisLocation15, false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder18 = categoryPlot6.getDatasetRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation19 = categoryPlot6.getRangeAxisLocation();
        org.jfree.chart.axis.AxisLocation axisLocation21 = null;
        try {
            categoryPlot6.setDomainAxisLocation(0, axisLocation21, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(datasetRenderingOrder18);
        org.junit.Assert.assertNotNull(axisLocation19);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean2 = dateAxis1.isNegativeArrowVisible();
        double double3 = dateAxis1.getLowerBound();
        java.awt.Paint paint4 = dateAxis1.getTickLabelPaint();
        dateAxis1.setLowerBound(0.0d);
        dateAxis1.setLabelURL("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.awt.Font font9 = null;
        try {
            dateAxis1.setLabelFont(font9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        java.awt.Paint paint7 = categoryPlot6.getDomainGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot6.getRenderer((int) (byte) 0);
        categoryPlot6.zoom((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(categoryItemRenderer9);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        categoryPlot6.clearRangeMarkers(0);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = null;
        categoryPlot6.markerChanged(markerChangeEvent9);
        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot6.getRangeAxisForDataset(0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(valueAxis12);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        java.awt.Paint paint8 = categoryPlot6.getDomainGridlinePaint();
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range12 = dateAxis11.getDefaultAutoRange();
        xYPlot9.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis11);
        java.awt.Paint paint14 = xYPlot9.getOutlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        xYPlot9.zoomRangeAxes((double) (byte) 100, plotRenderingInfo16, point2D17, false);
        java.awt.Stroke stroke20 = xYPlot9.getDomainCrosshairStroke();
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean24 = layer22.equals((java.lang.Object) true);
        java.util.Collection collection25 = xYPlot9.getRangeMarkers(3, layer22);
        java.util.Collection collection26 = categoryPlot6.getRangeMarkers(layer22);
        org.jfree.chart.axis.AxisSpace axisSpace27 = null;
        categoryPlot6.setFixedDomainAxisSpace(axisSpace27, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        categoryPlot6.setRenderer(categoryItemRenderer30, false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertNull(collection26);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = dateAxis3.getTickLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        dateAxis8.setTickLabelPaint((java.awt.Paint) color9);
        boolean boolean11 = rectangleInsets7.equals((java.lang.Object) dateAxis8);
        java.lang.String str12 = rectangleInsets7.toString();
        org.jfree.chart.util.UnitType unitType13 = rectangleInsets7.getUnitType();
        double double14 = rectangleInsets7.getBottom();
        double double16 = rectangleInsets7.calculateRightInset(0.0d);
        double double17 = rectangleInsets7.getRight();
        double double18 = rectangleInsets7.getTop();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str12.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
        org.junit.Assert.assertNotNull(unitType13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 2.0d + "'", double14 == 2.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 4.0d + "'", double16 == 4.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 4.0d + "'", double17 == 4.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 2.0d + "'", double18 == 2.0d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        java.awt.Color color3 = java.awt.Color.getHSBColor(0.0f, 0.0f, (float) 2);
        int int4 = color3.getRed();
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range8 = dateAxis7.getDefaultAutoRange();
        xYPlot5.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        xYPlot5.setDataset(xYDataset10);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        xYPlot5.setDomainTickBandPaint((java.awt.Paint) color12);
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range17 = dateAxis16.getDefaultAutoRange();
        xYPlot14.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis16);
        java.awt.Paint paint19 = xYPlot14.getOutlinePaint();
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot();
        xYPlot21.setRangeZeroBaselineVisible(false);
        boolean boolean24 = xYPlot21.isOutlineVisible();
        xYPlot21.clearRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation27 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot21.setDomainAxisLocation(64, axisLocation27);
        xYPlot14.setDomainAxisLocation(2, axisLocation27);
        boolean boolean30 = color12.equals((java.lang.Object) 2);
        int int31 = color12.getGreen();
        boolean boolean32 = color3.equals((java.lang.Object) color12);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 255 + "'", int4 == 255);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = categoryPlot6.getRenderer();
        boolean boolean9 = categoryPlot6.isRangeCrosshairVisible();
        int int10 = categoryPlot6.getDatasetCount();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(categoryItemRenderer8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        categoryPlot6.mapDatasetToDomainAxis(100, (int) 'a');
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        categoryPlot6.setRenderer(255, categoryItemRenderer12, false);
        double double15 = categoryPlot6.getRangeCrosshairValue();
        categoryPlot6.setRangeCrosshairLockedOnData(false);
        boolean boolean18 = categoryPlot6.isSubplot();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        categoryPlot6.mapDatasetToDomainAxis(100, (int) 'a');
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        categoryPlot6.setRenderer(255, categoryItemRenderer12, false);
        org.jfree.chart.util.SortOrder sortOrder15 = categoryPlot6.getColumnRenderingOrder();
        int int16 = categoryPlot6.getWeight();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(sortOrder15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        java.awt.Color color2 = java.awt.Color.getColor("hi!", 6);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = dateAxis3.getTickLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        dateAxis8.setTickLabelPaint((java.awt.Paint) color9);
        boolean boolean11 = rectangleInsets7.equals((java.lang.Object) dateAxis8);
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D13 = rectangleInsets7.createInsetRectangle(rectangle2D12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeZeroBaselineVisible(false);
        boolean boolean3 = xYPlot0.isOutlineVisible();
        xYPlot0.clearRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation6 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot0.setDomainAxisLocation(64, axisLocation6);
        xYPlot0.clearRangeAxes();
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        try {
            xYPlot0.drawBackground(graphics2D9, rectangle2D10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(axisLocation6);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        java.awt.Paint paint8 = categoryPlot6.getDomainGridlinePaint();
        java.lang.String str9 = categoryPlot6.getNoDataMessage();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        categoryPlot6.setRangeCrosshairPaint((java.awt.Paint) color10);
        org.jfree.data.general.DatasetGroup datasetGroup12 = categoryPlot6.getDatasetGroup();
        categoryPlot6.clearRangeAxes();
        categoryPlot6.setAnchorValue(10.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNull(datasetGroup12);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        java.awt.Paint paint5 = xYPlot0.getOutlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        xYPlot0.zoomRangeAxes((double) (byte) 100, plotRenderingInfo7, point2D8, false);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean15 = dateAxis14.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis14, categoryItemRenderer16);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = dateAxis14.getTickLabelInsets();
        xYPlot0.setInsets(rectangleInsets18, false);
        double double22 = rectangleInsets18.calculateBottomInset((double) (byte) 100);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 2.0d + "'", double22 == 2.0d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 3, 100.0d);
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range6 = dateAxis5.getDefaultAutoRange();
        xYPlot3.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis5);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot3.setRangeCrosshairStroke(stroke8);
        intervalMarker2.setStroke(stroke8);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.CENTER;
        intervalMarker2.setLabelAnchor(rectangleAnchor11);
        java.awt.Color color13 = java.awt.Color.red;
        intervalMarker2.setLabelPaint((java.awt.Paint) color13);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType15 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        intervalMarker2.setLabelOffsetType(lengthAdjustmentType15);
        java.lang.Object obj17 = intervalMarker2.clone();
        java.awt.Font font18 = null;
        try {
            intervalMarker2.setLabelFont(font18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(lengthAdjustmentType15);
        org.junit.Assert.assertNotNull(obj17);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean8 = dateAxis7.isTickLabelsVisible();
        xYPlot0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis7, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        try {
            xYPlot0.zoomRangeAxes((double) 100L, plotRenderingInfo12, point2D13, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean5 = dateAxis4.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        org.jfree.data.Range range8 = dateAxis4.getRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis4);
        java.text.DateFormat dateFormat10 = dateAxis4.getDateFormatOverride();
        java.util.Date date11 = null;
        try {
            dateAxis4.setMinimumDate(date11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'date' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNull(dateFormat10);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        org.jfree.data.Range range7 = dateAxis3.getRange();
        org.jfree.data.Range range8 = null;
        try {
            dateAxis3.setRange(range8, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(range7);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        java.awt.Paint paint8 = categoryPlot6.getDomainGridlinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot6.getDomainAxisForDataset((int) (short) 0);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean15 = dateAxis14.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis14, categoryItemRenderer16);
        org.jfree.data.Range range18 = dateAxis14.getRange();
        int int19 = categoryPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis14);
        dateAxis14.setFixedAutoRange((double) 255);
        org.jfree.data.time.DateRange dateRange22 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis14.setRange((org.jfree.data.Range) dateRange22, false, true);
        boolean boolean26 = dateAxis14.isAutoRange();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(dateRange22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean5 = dateAxis4.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        org.jfree.data.Range range8 = dateAxis4.getRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis4);
        dateAxis4.resizeRange((double) 8);
        java.awt.Paint paint12 = dateAxis4.getAxisLinePaint();
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent14 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) paint12, jFreeChart13);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        java.awt.Paint paint8 = categoryPlot6.getDomainGridlinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot6.getDomainAxisForDataset((int) (short) 0);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean15 = dateAxis14.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis14, categoryItemRenderer16);
        org.jfree.data.Range range18 = dateAxis14.getRange();
        int int19 = categoryPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis14);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent20 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot6);
        org.jfree.chart.plot.Marker marker21 = null;
        try {
            boolean boolean22 = categoryPlot6.removeRangeMarker(marker21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Paint[] paintArray3 = new java.awt.Paint[] { color1, color2 };
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Paint paint5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Paint paint7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        java.awt.Paint[] paintArray8 = new java.awt.Paint[] { color4, paint5, color6, paint7 };
        java.awt.Stroke stroke9 = null;
        java.awt.Stroke[] strokeArray10 = new java.awt.Stroke[] { stroke9 };
        java.awt.Stroke[] strokeArray11 = null;
        java.awt.Shape[] shapeArray12 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier13 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray3, paintArray8, strokeArray10, strokeArray11, shapeArray12);
        java.awt.Paint paint14 = defaultDrawingSupplier13.getNextFillPaint();
        try {
            java.awt.Stroke stroke15 = defaultDrawingSupplier13.getNextOutlineStroke();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paintArray3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paintArray8);
        org.junit.Assert.assertNotNull(strokeArray10);
        org.junit.Assert.assertNotNull(shapeArray12);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getTickLabelInsets();
        double double7 = rectangleInsets5.calculateRightInset((double) (-1));
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        java.awt.Paint paint5 = xYPlot0.getOutlinePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = xYPlot0.getRangeAxisEdge();
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean11 = dateAxis10.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis10, categoryItemRenderer12);
        boolean boolean14 = categoryPlot13.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier15 = categoryPlot13.getDrawingSupplier();
        categoryPlot13.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = categoryPlot13.getDomainAxisEdge(10);
        boolean boolean19 = categoryPlot13.isRangeZoomable();
        java.awt.Paint paint20 = categoryPlot13.getDomainGridlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation22 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot13.setDomainAxisLocation(64, axisLocation22, false);
        xYPlot0.setRangeAxisLocation(axisLocation22, false);
        java.awt.Paint paint27 = xYPlot0.getRangeGridlinePaint();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(drawingSupplier15);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertNotNull(paint27);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        java.awt.Paint paint5 = xYPlot0.getOutlinePaint();
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        xYPlot7.setRangeZeroBaselineVisible(false);
        boolean boolean10 = xYPlot7.isOutlineVisible();
        xYPlot7.clearRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot7.setDomainAxisLocation(64, axisLocation13);
        xYPlot0.setDomainAxisLocation(2, axisLocation13);
        org.jfree.chart.axis.AxisLocation axisLocation16 = xYPlot0.getDomainAxisLocation();
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean22 = dateAxis21.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis21, categoryItemRenderer23);
        org.jfree.data.Range range25 = dateAxis21.getRange();
        xYPlot17.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis21);
        dateAxis21.resizeRange((double) 8);
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range31 = dateAxis30.getDefaultAutoRange();
        java.awt.Paint paint32 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        dateAxis30.setAxisLinePaint(paint32);
        dateAxis30.setAutoRange(true);
        org.jfree.data.category.CategoryDataset categoryDataset36 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = null;
        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean40 = dateAxis39.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer41 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis37, (org.jfree.chart.axis.ValueAxis) dateAxis39, categoryItemRenderer41);
        org.jfree.chart.axis.DateAxis dateAxis43 = new org.jfree.chart.axis.DateAxis();
        int int44 = categoryPlot42.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis43);
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean47 = dateAxis46.isNegativeArrowVisible();
        org.jfree.data.category.CategoryDataset categoryDataset48 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = null;
        org.jfree.chart.axis.DateAxis dateAxis51 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean52 = dateAxis51.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset48, categoryAxis49, (org.jfree.chart.axis.ValueAxis) dateAxis51, categoryItemRenderer53);
        dateAxis51.resizeRange((double) 100.0f);
        java.awt.Shape shape57 = dateAxis51.getDownArrow();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray58 = new org.jfree.chart.axis.ValueAxis[] { dateAxis21, dateAxis30, dateAxis43, dateAxis46, dateAxis51 };
        xYPlot0.setDomainAxes(valueAxisArray58);
        int int60 = xYPlot0.getRangeAxisCount();
        java.awt.Paint paint61 = xYPlot0.getOutlinePaint();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation62 = null;
        try {
            boolean boolean63 = xYPlot0.removeAnnotation(xYAnnotation62);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(shape57);
        org.junit.Assert.assertNotNull(valueAxisArray58);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1 + "'", int60 == 1);
        org.junit.Assert.assertNotNull(paint61);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        dateAxis3.resizeRange((double) 100.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = dateAxis3.getLabelInsets();
        java.util.EventListener eventListener10 = null;
        boolean boolean11 = dateAxis3.hasListener(eventListener10);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        java.awt.Color color0 = java.awt.Color.DARK_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        java.awt.Color color0 = java.awt.Color.blue;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        java.awt.Paint paint5 = xYPlot0.getOutlinePaint();
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        xYPlot7.setRangeZeroBaselineVisible(false);
        boolean boolean10 = xYPlot7.isOutlineVisible();
        xYPlot7.clearRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot7.setDomainAxisLocation(64, axisLocation13);
        xYPlot0.setDomainAxisLocation(2, axisLocation13);
        xYPlot0.setRangeCrosshairValue((double) (short) 10);
        org.jfree.chart.plot.IntervalMarker intervalMarker21 = new org.jfree.chart.plot.IntervalMarker((double) 3, 100.0d);
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range25 = dateAxis24.getDefaultAutoRange();
        xYPlot22.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis24);
        java.awt.Stroke stroke27 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot22.setRangeCrosshairStroke(stroke27);
        intervalMarker21.setStroke(stroke27);
        java.awt.Color color30 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        intervalMarker21.setOutlinePaint((java.awt.Paint) color30);
        double double32 = intervalMarker21.getEndValue();
        org.jfree.chart.util.Layer layer33 = null;
        boolean boolean34 = xYPlot0.removeRangeMarker(2, (org.jfree.chart.plot.Marker) intervalMarker21, layer33);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        java.awt.geom.Point2D point2D37 = null;
        xYPlot0.zoomRangeAxes(3.0d, plotRenderingInfo36, point2D37, false);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 100.0d + "'", double32 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        java.awt.Paint paint5 = xYPlot0.getOutlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        xYPlot0.zoomRangeAxes((double) (byte) 100, plotRenderingInfo7, point2D8, false);
        java.awt.Stroke stroke11 = xYPlot0.getRangeGridlineStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection12 = xYPlot0.getLegendItems();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(legendItemCollection12);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.START;
        boolean boolean2 = categoryAnchor0.equals((java.lang.Object) 64);
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.lang.String str2 = dateAxis1.getLabelURL();
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        java.awt.Paint paint7 = categoryPlot6.getDomainGridlinePaint();
        java.lang.Object obj8 = categoryPlot6.clone();
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean13 = dateAxis12.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis12, categoryItemRenderer14);
        dateAxis12.resizeRange((double) 100.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = dateAxis12.getLabelInsets();
        int int19 = categoryPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis12);
        java.awt.Graphics2D graphics2D20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        try {
            categoryPlot6.drawBackground(graphics2D20, rectangle2D21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot6.getDrawingSupplier();
        categoryPlot6.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot6.getDomainAxisEdge(10);
        boolean boolean12 = categoryPlot6.isRangeZoomable();
        java.awt.Paint paint13 = categoryPlot6.getDomainGridlinePaint();
        boolean boolean14 = categoryPlot6.isDomainGridlinesVisible();
        boolean boolean15 = categoryPlot6.isDomainGridlinesVisible();
        categoryPlot6.setRangeCrosshairValue((double) 1560409200000L);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range4 = dateAxis3.getDefaultAutoRange();
        java.awt.Paint paint5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        dateAxis3.setAxisLinePaint(paint5);
        dateAxis3.setAutoRange(true);
        boolean boolean9 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        int int13 = categoryPlot11.getIndexOf(categoryItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        try {
            categoryPlot11.handleClick((int) (byte) 1, (-8388608), plotRenderingInfo16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        java.awt.Color color0 = java.awt.Color.lightGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        java.awt.Paint paint5 = xYPlot0.getOutlinePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = xYPlot0.getRangeAxisEdge();
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = xYPlot0.getOrientation();
        boolean boolean8 = xYPlot0.isDomainZeroBaselineVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = xYPlot0.getRenderer(11);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        try {
            xYPlot0.setRenderer((int) (short) -1, xYItemRenderer12, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(plotOrientation7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(xYItemRenderer10);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.CENTER;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) (short) 10, (double) 3, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor3);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        java.lang.Object obj0 = null;
        org.jfree.data.general.Dataset dataset1 = null;
        try {
            org.jfree.data.general.DatasetChangeEvent datasetChangeEvent2 = new org.jfree.data.general.DatasetChangeEvent(obj0, dataset1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        java.awt.Color color1 = java.awt.Color.getColor("Layer.FOREGROUND");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        try {
            java.awt.geom.Point2D point2D2 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor1);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 3, 100.0d);
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range6 = dateAxis5.getDefaultAutoRange();
        xYPlot3.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis5);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot3.setRangeCrosshairStroke(stroke8);
        intervalMarker2.setStroke(stroke8);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.CENTER;
        intervalMarker2.setLabelAnchor(rectangleAnchor11);
        java.awt.Color color13 = java.awt.Color.red;
        intervalMarker2.setLabelPaint((java.awt.Paint) color13);
        org.jfree.chart.text.TextAnchor textAnchor15 = intervalMarker2.getLabelTextAnchor();
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean20 = dateAxis19.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, (org.jfree.chart.axis.ValueAxis) dateAxis19, categoryItemRenderer21);
        boolean boolean23 = categoryPlot22.isOutlineVisible();
        java.awt.Paint paint24 = categoryPlot22.getDomainGridlinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = categoryPlot22.getDomainAxisForDataset((int) (short) 0);
        java.awt.Font font27 = categoryPlot22.getNoDataMessageFont();
        intervalMarker2.setLabelFont(font27);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer29 = null;
        intervalMarker2.setGradientPaintTransformer(gradientPaintTransformer29);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(textAnchor15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNull(categoryAxis26);
        org.junit.Assert.assertNotNull(font27);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        dateAxis3.resizeRange((double) 100.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = dateAxis3.getLabelInsets();
        java.text.DateFormat dateFormat10 = null;
        dateAxis3.setDateFormatOverride(dateFormat10);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(rectangleInsets9);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range4 = dateAxis3.getDefaultAutoRange();
        xYPlot1.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis3);
        java.awt.Paint paint6 = xYPlot1.getOutlinePaint();
        xYPlot1.setRangeCrosshairValue(1.0E-8d);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        xYPlot1.setAxisOffset(rectangleInsets9);
        org.jfree.chart.util.UnitType unitType11 = rectangleInsets9.getUnitType();
        boolean boolean12 = numberAxis0.equals((java.lang.Object) rectangleInsets9);
        boolean boolean13 = numberAxis0.isAutoTickUnitSelection();
        boolean boolean14 = numberAxis0.isVisible();
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(unitType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        java.awt.Paint paint5 = xYPlot0.getOutlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        xYPlot0.zoomRangeAxes((double) (byte) 100, plotRenderingInfo7, point2D8, false);
        org.jfree.chart.plot.IntervalMarker intervalMarker14 = new org.jfree.chart.plot.IntervalMarker((double) 3, 100.0d);
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range18 = dateAxis17.getDefaultAutoRange();
        xYPlot15.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis17);
        org.jfree.chart.util.Layer layer21 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean23 = layer21.equals((java.lang.Object) true);
        java.util.Collection collection24 = xYPlot15.getRangeMarkers((int) '#', layer21);
        xYPlot0.addRangeMarker(3, (org.jfree.chart.plot.Marker) intervalMarker14, layer21);
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = null;
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean30 = dateAxis29.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset26, categoryAxis27, (org.jfree.chart.axis.ValueAxis) dateAxis29, categoryItemRenderer31);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = dateAxis29.getTickLabelInsets();
        double double35 = rectangleInsets33.calculateLeftOutset((double) (-1.0f));
        xYPlot0.setAxisOffset(rectangleInsets33);
        boolean boolean38 = rectangleInsets33.equals((java.lang.Object) 100L);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNotNull(layer21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 4.0d + "'", double35 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        java.awt.Stroke stroke4 = numberAxis3.getTickMarkStroke();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis3.setTickUnit(numberTickUnit5);
        numberAxis1.setTickUnit(numberTickUnit5);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        java.awt.Stroke stroke12 = numberAxis11.getTickMarkStroke();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit13 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis11.setTickUnit(numberTickUnit13);
        numberAxis9.setTickUnit(numberTickUnit13);
        numberAxis1.setTickUnit(numberTickUnit13);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape18 = dateAxis17.getLeftArrow();
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean23 = dateAxis22.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, (org.jfree.chart.axis.ValueAxis) dateAxis22, categoryItemRenderer24);
        dateAxis22.resizeRange((double) 100.0f);
        java.awt.Shape shape28 = dateAxis22.getDownArrow();
        dateAxis17.setDownArrow(shape28);
        numberAxis1.setDownArrow(shape28);
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.data.category.CategoryDataset categoryDataset33 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = null;
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean37 = dateAxis36.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, categoryAxis34, (org.jfree.chart.axis.ValueAxis) dateAxis36, categoryItemRenderer38);
        categoryPlot39.clearRangeMarkers(0);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent42 = null;
        categoryPlot39.markerChanged(markerChangeEvent42);
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = categoryPlot39.getDomainAxisEdge();
        try {
            double double45 = numberAxis1.valueToJava2D(0.0d, rectangle2D32, rectangleEdge44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(numberTickUnit5);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(numberTickUnit13);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(rectangleEdge44);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        java.awt.Paint paint8 = categoryPlot6.getDomainGridlinePaint();
        java.lang.String str9 = categoryPlot6.getNoDataMessage();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        categoryPlot6.setRangeCrosshairPaint((java.awt.Paint) color10);
        org.jfree.data.general.DatasetGroup datasetGroup12 = categoryPlot6.getDatasetGroup();
        categoryPlot6.clearRangeAxes();
        float float14 = categoryPlot6.getBackgroundImageAlpha();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNull(datasetGroup12);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.5f + "'", float14 == 0.5f);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        java.awt.Paint paint5 = xYPlot0.getOutlinePaint();
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        xYPlot7.setRangeZeroBaselineVisible(false);
        boolean boolean10 = xYPlot7.isOutlineVisible();
        xYPlot7.clearRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot7.setDomainAxisLocation(64, axisLocation13);
        xYPlot0.setDomainAxisLocation(2, axisLocation13);
        org.jfree.chart.axis.AxisLocation axisLocation16 = xYPlot0.getDomainAxisLocation();
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean22 = dateAxis21.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis21, categoryItemRenderer23);
        org.jfree.data.Range range25 = dateAxis21.getRange();
        xYPlot17.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis21);
        dateAxis21.resizeRange((double) 8);
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range31 = dateAxis30.getDefaultAutoRange();
        java.awt.Paint paint32 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        dateAxis30.setAxisLinePaint(paint32);
        dateAxis30.setAutoRange(true);
        org.jfree.data.category.CategoryDataset categoryDataset36 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = null;
        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean40 = dateAxis39.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer41 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis37, (org.jfree.chart.axis.ValueAxis) dateAxis39, categoryItemRenderer41);
        org.jfree.chart.axis.DateAxis dateAxis43 = new org.jfree.chart.axis.DateAxis();
        int int44 = categoryPlot42.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis43);
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean47 = dateAxis46.isNegativeArrowVisible();
        org.jfree.data.category.CategoryDataset categoryDataset48 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = null;
        org.jfree.chart.axis.DateAxis dateAxis51 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean52 = dateAxis51.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset48, categoryAxis49, (org.jfree.chart.axis.ValueAxis) dateAxis51, categoryItemRenderer53);
        dateAxis51.resizeRange((double) 100.0f);
        java.awt.Shape shape57 = dateAxis51.getDownArrow();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray58 = new org.jfree.chart.axis.ValueAxis[] { dateAxis21, dateAxis30, dateAxis43, dateAxis46, dateAxis51 };
        xYPlot0.setDomainAxes(valueAxisArray58);
        java.awt.Color color65 = java.awt.Color.getHSBColor(0.0f, 0.0f, (float) 2);
        java.awt.Color color66 = java.awt.Color.getColor("ChartChangeEventType.DATASET_UPDATED", color65);
        java.awt.Stroke stroke67 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Paint paint68 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke69 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker71 = new org.jfree.chart.plot.ValueMarker((double) 15, (java.awt.Paint) color65, stroke67, paint68, stroke69, 0.0f);
        org.jfree.chart.plot.ValueMarker valueMarker73 = new org.jfree.chart.plot.ValueMarker((double) 11);
        java.awt.Paint paint74 = valueMarker73.getPaint();
        valueMarker73.setValue(8.0d);
        org.jfree.chart.plot.IntervalMarker intervalMarker79 = new org.jfree.chart.plot.IntervalMarker((double) 3, 100.0d);
        org.jfree.chart.plot.XYPlot xYPlot80 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis82 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range83 = dateAxis82.getDefaultAutoRange();
        xYPlot80.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis82);
        java.awt.Stroke stroke85 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot80.setRangeCrosshairStroke(stroke85);
        intervalMarker79.setStroke(stroke85);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor88 = org.jfree.chart.util.RectangleAnchor.CENTER;
        intervalMarker79.setLabelAnchor(rectangleAnchor88);
        valueMarker73.setLabelAnchor(rectangleAnchor88);
        valueMarker71.setLabelAnchor(rectangleAnchor88);
        boolean boolean92 = xYPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker71);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(shape57);
        org.junit.Assert.assertNotNull(valueAxisArray58);
        org.junit.Assert.assertNotNull(color65);
        org.junit.Assert.assertNotNull(color66);
        org.junit.Assert.assertNotNull(stroke67);
        org.junit.Assert.assertNotNull(paint68);
        org.junit.Assert.assertNotNull(stroke69);
        org.junit.Assert.assertNotNull(paint74);
        org.junit.Assert.assertNotNull(range83);
        org.junit.Assert.assertNotNull(stroke85);
        org.junit.Assert.assertNotNull(rectangleAnchor88);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        java.awt.Paint paint7 = categoryPlot6.getDomainGridlinePaint();
        java.lang.Object obj8 = categoryPlot6.clone();
        boolean boolean9 = categoryPlot6.isRangeZoomable();
        double double10 = categoryPlot6.getRangeCrosshairValue();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        java.awt.Font font8 = categoryPlot6.getNoDataMessageFont();
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = categoryPlot6.getRangeAxisEdge((int) (short) 10);
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = null;
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean17 = dateAxis16.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis16, categoryItemRenderer18);
        boolean boolean20 = categoryPlot19.isOutlineVisible();
        java.awt.Paint paint21 = categoryPlot19.getDomainGridlinePaint();
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range25 = dateAxis24.getDefaultAutoRange();
        xYPlot22.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis24);
        java.awt.Paint paint27 = xYPlot22.getOutlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        java.awt.geom.Point2D point2D30 = null;
        xYPlot22.zoomRangeAxes((double) (byte) 100, plotRenderingInfo29, point2D30, false);
        java.awt.Stroke stroke33 = xYPlot22.getDomainCrosshairStroke();
        org.jfree.chart.util.Layer layer35 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean37 = layer35.equals((java.lang.Object) true);
        java.util.Collection collection38 = xYPlot22.getRangeMarkers(3, layer35);
        java.util.Collection collection39 = categoryPlot19.getRangeMarkers(layer35);
        try {
            categoryPlot6.addDomainMarker(0, categoryMarker12, layer35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(layer35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNull(collection38);
        org.junit.Assert.assertNull(collection39);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        java.awt.Color color1 = null;
        java.awt.Color color2 = java.awt.Color.getColor("java.awt.Color[r=0,g=0,b=128]", color1);
        org.junit.Assert.assertNull(color2);
    }

//    @Test
//    public void test195() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test195");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getMiddleMillisecond();
//        int int2 = day0.getDayOfMonth();
//        long long3 = day0.getFirstMillisecond();
//        long long4 = day0.getMiddleMillisecond();
//        java.lang.String str5 = day0.toString();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560452399999L + "'", long1 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560452399999L + "'", long4 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "13-June-2019" + "'", str5.equals("13-June-2019"));
//    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        java.awt.Color color0 = java.awt.Color.PINK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        java.awt.Color color1 = java.awt.Color.YELLOW;
        boolean boolean2 = textAnchor0.equals((java.lang.Object) color1);
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.lang.Object obj1 = numberAxis0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean2 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot3 = dateAxis1.getPlot();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean8 = dateAxis7.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer9);
        java.awt.Paint paint11 = categoryPlot10.getDomainGridlinePaint();
        dateAxis1.setTickMarkPaint(paint11);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_INVERTED;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        java.awt.Paint paint8 = categoryPlot6.getDomainGridlinePaint();
        java.lang.String str9 = categoryPlot6.getNoDataMessage();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        categoryPlot6.setRangeCrosshairPaint((java.awt.Paint) color10);
        org.jfree.chart.axis.AxisSpace axisSpace12 = categoryPlot6.getFixedDomainAxisSpace();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNull(axisSpace12);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        java.awt.Stroke stroke4 = numberAxis3.getTickMarkStroke();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis3.setTickUnit(numberTickUnit5);
        numberAxis1.setTickUnit(numberTickUnit5, false, false);
        numberAxis1.setPositiveArrowVisible(true);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(numberTickUnit5);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean2 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot3 = dateAxis1.getPlot();
        java.awt.Stroke stroke4 = dateAxis1.getAxisLineStroke();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = categoryPlot6.getLegendItems();
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range12 = dateAxis11.getDefaultAutoRange();
        xYPlot9.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis11);
        java.awt.Paint paint14 = xYPlot9.getOutlinePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = xYPlot9.getRangeAxisEdge();
        org.jfree.chart.plot.PlotOrientation plotOrientation16 = xYPlot9.getOrientation();
        categoryPlot6.setOrientation(plotOrientation16);
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean22 = dateAxis21.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis21, categoryItemRenderer23);
        boolean boolean25 = categoryPlot24.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier26 = categoryPlot24.getDrawingSupplier();
        categoryPlot24.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = categoryPlot24.getDomainAxisEdge(10);
        boolean boolean30 = categoryPlot24.isRangeZoomable();
        java.awt.Paint paint31 = categoryPlot24.getDomainGridlinePaint();
        java.awt.Paint paint32 = categoryPlot24.getOutlinePaint();
        categoryPlot6.setRangeGridlinePaint(paint32);
        boolean boolean34 = categoryPlot6.isRangeZoomable();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(legendItemCollection8);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(plotOrientation16);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(drawingSupplier26);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        categoryPlot6.mapDatasetToDomainAxis(100, (int) 'a');
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        categoryPlot6.setRenderer(255, categoryItemRenderer12, false);
        double double15 = categoryPlot6.getRangeCrosshairValue();
        org.jfree.data.general.Dataset dataset16 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent17 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) categoryPlot6, dataset16);
        categoryPlot6.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisSpace axisSpace20 = categoryPlot6.getFixedDomainAxisSpace();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNull(axisSpace20);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean8 = dateAxis7.isTickLabelsVisible();
        xYPlot0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis7, true);
        org.jfree.chart.plot.PlotOrientation plotOrientation11 = xYPlot0.getOrientation();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(plotOrientation11);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace1 = null;
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_RED;
        float[] floatArray6 = null;
        float[] floatArray7 = java.awt.Color.RGBtoHSB((int) (byte) 100, (-4145152), (-1), floatArray6);
        float[] floatArray8 = color2.getRGBColorComponents(floatArray6);
        try {
            float[] floatArray9 = color0.getComponents(colorSpace1, floatArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray8);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range2 = dateAxis1.getDefaultAutoRange();
        java.awt.Paint paint3 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        dateAxis1.setAxisLinePaint(paint3);
        dateAxis1.setAutoRange(true);
        org.jfree.chart.JFreeChart jFreeChart7 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateAxis1, jFreeChart7);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType9 = chartChangeEvent8.getType();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(chartChangeEventType9);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        java.awt.Paint paint5 = xYPlot0.getOutlinePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = xYPlot0.getRangeAxisEdge();
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = xYPlot0.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = xYPlot0.getLegendItems();
        try {
            xYPlot0.setBackgroundImageAlpha((float) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(plotOrientation7);
        org.junit.Assert.assertNotNull(legendItemCollection8);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateTopInset((double) 12);
        double double4 = rectangleInsets0.calculateLeftInset((double) 11);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0d + "'", double2 == 2.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
    }

//    @Test
//    public void test214() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test214");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560409200000L + "'", long1 == 1560409200000L);
//    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        java.awt.Color color6 = java.awt.Color.getHSBColor(0.0f, 0.0f, (float) 2);
        java.awt.Color color7 = java.awt.Color.getColor("ChartChangeEventType.DATASET_UPDATED", color6);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Paint paint9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) 15, (java.awt.Paint) color6, stroke8, paint9, stroke10, 0.0f);
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker((double) 11);
        java.awt.Paint paint15 = valueMarker14.getPaint();
        valueMarker14.setValue(8.0d);
        org.jfree.chart.plot.IntervalMarker intervalMarker20 = new org.jfree.chart.plot.IntervalMarker((double) 3, 100.0d);
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range24 = dateAxis23.getDefaultAutoRange();
        xYPlot21.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis23);
        java.awt.Stroke stroke26 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot21.setRangeCrosshairStroke(stroke26);
        intervalMarker20.setStroke(stroke26);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor29 = org.jfree.chart.util.RectangleAnchor.CENTER;
        intervalMarker20.setLabelAnchor(rectangleAnchor29);
        valueMarker14.setLabelAnchor(rectangleAnchor29);
        valueMarker12.setLabelAnchor(rectangleAnchor29);
        try {
            java.awt.geom.Point2D point2D33 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(rectangleAnchor29);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot6.getDrawingSupplier();
        categoryPlot6.clearRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot6.getRangeAxisLocation();
        categoryPlot6.setAnchorValue((double) (short) 10, true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(axisLocation10);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot6.getDrawingSupplier();
        categoryPlot6.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot6.getDomainAxisEdge(10);
        boolean boolean12 = categoryPlot6.isRangeZoomable();
        categoryPlot6.setOutlineVisible(true);
        org.jfree.data.general.DatasetGroup datasetGroup15 = categoryPlot6.getDatasetGroup();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(datasetGroup15);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        dateAxis3.resizeRange((double) 100.0f);
        java.util.Date date9 = dateAxis3.getMaximumDate();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean14 = dateAxis13.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis13, categoryItemRenderer15);
        java.util.TimeZone timeZone17 = dateAxis13.getTimeZone();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date9, timeZone17);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date9);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(timeZone17);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setRangeCrosshairStroke(stroke5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range10 = dateAxis9.getDefaultAutoRange();
        xYPlot7.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis9);
        java.awt.Paint paint12 = xYPlot7.getOutlinePaint();
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot();
        xYPlot14.setRangeZeroBaselineVisible(false);
        boolean boolean17 = xYPlot14.isOutlineVisible();
        xYPlot14.clearRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation20 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot14.setDomainAxisLocation(64, axisLocation20);
        xYPlot7.setDomainAxisLocation(2, axisLocation20);
        org.jfree.chart.axis.AxisLocation axisLocation23 = xYPlot7.getDomainAxisLocation();
        xYPlot0.setRangeAxisLocation(axisLocation23);
        xYPlot0.setRangeCrosshairVisible(false);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertNotNull(axisLocation23);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        categoryPlot6.mapDatasetToDomainAxis(100, (int) 'a');
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        categoryPlot6.setRenderer(255, categoryItemRenderer12, false);
        double double15 = categoryPlot6.getRangeCrosshairValue();
        org.jfree.data.general.Dataset dataset16 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent17 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) categoryPlot6, dataset16);
        java.awt.Paint paint18 = categoryPlot6.getDomainGridlinePaint();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeZeroBaselineVisible(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        xYPlot0.zoomRangeAxes(0.0d, (double) 11, plotRenderingInfo5, point2D6);
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace8, false);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        java.awt.Stroke stroke2 = numberAxis1.getTickMarkStroke();
        boolean boolean3 = numberAxis1.getAutoRangeStickyZero();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range2 = dateAxis1.getDefaultAutoRange();
        java.awt.Paint paint3 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        dateAxis1.setAxisLinePaint(paint3);
        dateAxis1.setUpperBound(6.0d);
        dateAxis1.setUpperMargin((double) (-1));
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        dateAxis3.resizeRange((double) 100.0f);
        java.util.Date date9 = dateAxis3.getMaximumDate();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean14 = dateAxis13.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis13, categoryItemRenderer15);
        java.util.TimeZone timeZone17 = dateAxis13.getTimeZone();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date9, timeZone17);
        java.util.Calendar calendar19 = null;
        try {
            day18.peg(calendar19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(timeZone17);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeZeroBaselineVisible(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        xYPlot0.zoomRangeAxes(0.0d, (double) 11, plotRenderingInfo5, point2D6);
        java.awt.Paint paint8 = xYPlot0.getRangeGridlinePaint();
        boolean boolean9 = xYPlot0.isDomainCrosshairVisible();
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot6.getDrawingSupplier();
        categoryPlot6.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot6.getDomainAxisEdge(10);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = categoryPlot6.getDomainAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Point2D point2D16 = null;
        categoryPlot6.zoomDomainAxes((double) 'a', (double) '#', plotRenderingInfo15, point2D16);
        org.jfree.chart.LegendItemCollection legendItemCollection18 = categoryPlot6.getFixedLegendItems();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNull(categoryAxis12);
        org.junit.Assert.assertNull(legendItemCollection18);
    }

//    @Test
//    public void test228() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test228");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getMiddleMillisecond();
//        long long2 = day0.getFirstMillisecond();
//        java.lang.String str3 = day0.toString();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560452399999L + "'", long1 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean2 = dateAxis1.isNegativeArrowVisible();
        dateAxis1.setAutoRangeMinimumSize((double) (short) 1, true);
        java.awt.Shape shape6 = dateAxis1.getUpArrow();
        double double7 = dateAxis1.getFixedDimension();
        dateAxis1.setTickMarkOutsideLength((float) (-8388608));
        dateAxis1.setTickMarkOutsideLength((float) 0L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot6.getDrawingSupplier();
        categoryPlot6.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot6.getDomainAxisEdge(10);
        boolean boolean12 = categoryPlot6.isRangeZoomable();
        java.awt.Paint paint13 = categoryPlot6.getDomainGridlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot6.setDomainAxisLocation(64, axisLocation15, false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder18 = categoryPlot6.getDatasetRenderingOrder();
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean23 = dateAxis22.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, (org.jfree.chart.axis.ValueAxis) dateAxis22, categoryItemRenderer24);
        boolean boolean26 = categoryPlot25.isOutlineVisible();
        categoryPlot25.mapDatasetToDomainAxis(100, (int) 'a');
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        categoryPlot25.setRenderer(255, categoryItemRenderer31, false);
        org.jfree.chart.util.SortOrder sortOrder34 = categoryPlot25.getColumnRenderingOrder();
        categoryPlot6.setColumnRenderingOrder(sortOrder34);
        boolean boolean37 = sortOrder34.equals((java.lang.Object) 64);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(datasetRenderingOrder18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(sortOrder34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean2 = dateAxis1.isNegativeArrowVisible();
        dateAxis1.setAutoRangeMinimumSize((double) (short) 1, true);
        org.jfree.chart.axis.Timeline timeline6 = null;
        dateAxis1.setTimeline(timeline6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean12 = dateAxis11.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis11, categoryItemRenderer13);
        boolean boolean15 = categoryPlot14.isOutlineVisible();
        java.awt.Paint paint16 = categoryPlot14.getDomainGridlinePaint();
        java.lang.String str17 = categoryPlot14.getNoDataMessage();
        dateAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot14);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = categoryPlot14.getDomainAxisEdge((int) '#');
        java.lang.String str21 = categoryPlot14.getNoDataMessage();
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = categoryPlot14.getDomainAxis(0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNull(categoryAxis23);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 3, 100.0d);
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range6 = dateAxis5.getDefaultAutoRange();
        xYPlot3.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis5);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot3.setRangeCrosshairStroke(stroke8);
        intervalMarker2.setStroke(stroke8);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.CENTER;
        intervalMarker2.setLabelAnchor(rectangleAnchor11);
        java.awt.Color color13 = java.awt.Color.red;
        intervalMarker2.setLabelPaint((java.awt.Paint) color13);
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean20 = dateAxis19.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, (org.jfree.chart.axis.ValueAxis) dateAxis19, categoryItemRenderer21);
        org.jfree.data.Range range23 = dateAxis19.getRange();
        xYPlot15.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis19);
        dateAxis19.resizeRange((double) 8);
        java.awt.Font font27 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis19.setTickLabelFont(font27);
        intervalMarker2.setLabelFont(font27);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent30 = null;
        intervalMarker2.notifyListeners(markerChangeEvent30);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertNotNull(font27);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        categoryPlot6.mapDatasetToDomainAxis(100, (int) 'a');
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = categoryPlot6.getDomainAxis(0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(categoryAxis12);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 11);
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range5 = dateAxis4.getDefaultAutoRange();
        xYPlot2.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis4);
        java.awt.Paint paint7 = xYPlot2.getOutlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        xYPlot2.zoomRangeAxes((double) (byte) 100, plotRenderingInfo9, point2D10, false);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean17 = dateAxis16.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis16, categoryItemRenderer18);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = dateAxis16.getTickLabelInsets();
        xYPlot2.setInsets(rectangleInsets20, false);
        boolean boolean23 = valueMarker1.equals((java.lang.Object) rectangleInsets20);
        org.jfree.chart.JFreeChart jFreeChart24 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent25 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) valueMarker1, jFreeChart24);
        valueMarker1.setValue(1.0E-8d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        dateAxis3.resizeRange((double) 100.0f);
        java.util.Date date9 = dateAxis3.getMaximumDate();
        double double10 = dateAxis3.getUpperMargin();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.05d + "'", double10 == 0.05d);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeZeroBaselineVisible(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder3 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot0.setRangeAxisLocation((int) (byte) 100, axisLocation5);
        xYPlot0.setRangeCrosshairVisible(false);
        java.lang.String str9 = xYPlot0.getPlotType();
        org.junit.Assert.assertNotNull(datasetRenderingOrder3);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "XY Plot" + "'", str9.equals("XY Plot"));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot6.getDrawingSupplier();
        categoryPlot6.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot6.getDomainAxisEdge(10);
        boolean boolean12 = categoryPlot6.isRangeZoomable();
        categoryPlot6.setOutlineVisible(true);
        categoryPlot6.setRangeCrosshairLockedOnData(false);
        double double17 = categoryPlot6.getAnchorValue();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean9 = dateAxis8.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis8, categoryItemRenderer10);
        boolean boolean12 = categoryPlot11.isOutlineVisible();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        org.jfree.chart.util.Layer layer14 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean15 = datasetRenderingOrder13.equals((java.lang.Object) layer14);
        java.lang.Object obj16 = null;
        boolean boolean17 = datasetRenderingOrder13.equals(obj16);
        categoryPlot11.setDatasetRenderingOrder(datasetRenderingOrder13);
        xYPlot0.setDatasetRenderingOrder(datasetRenderingOrder13);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertNotNull(layer14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        java.awt.Stroke stroke0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        org.jfree.data.Range range7 = dateAxis3.getRange();
        dateAxis3.setTickMarkOutsideLength(2.0f);
        dateAxis3.resizeRange(0.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(range7);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        dateAxis2.setUpperMargin(100.0d);
        dateAxis2.setPositiveArrowVisible(false);
        java.awt.Paint paint9 = null;
        try {
            dateAxis2.setTickLabelPaint(paint9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range3);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        java.awt.Paint paint8 = categoryPlot6.getDomainGridlinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot6.getDomainAxisForDataset((int) (short) 0);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean15 = dateAxis14.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis14, categoryItemRenderer16);
        org.jfree.data.Range range18 = dateAxis14.getRange();
        int int19 = categoryPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis14);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent20 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot6);
        java.awt.Stroke stroke21 = categoryPlot6.getRangeCrosshairStroke();
        boolean boolean22 = categoryPlot6.isRangeGridlinesVisible();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        java.awt.Paint paint7 = categoryPlot6.getDomainGridlinePaint();
        int int8 = categoryPlot6.getBackgroundImageAlignment();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot6.zoomRangeAxes(50.0d, plotRenderingInfo10, point2D11, false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 15 + "'", int8 == 15);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        org.jfree.chart.plot.Marker marker5 = null;
        boolean boolean6 = xYPlot0.removeDomainMarker(marker5);
        xYPlot0.setDomainCrosshairValue((double) (-1), true);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean12 = dateAxis11.isNegativeArrowVisible();
        dateAxis11.setAutoRangeMinimumSize((double) (short) 1, true);
        org.jfree.chart.axis.Timeline timeline16 = null;
        dateAxis11.setTimeline(timeline16);
        boolean boolean18 = xYPlot0.equals((java.lang.Object) dateAxis11);
        org.jfree.data.Range range19 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis11.setRange(range19, true, false);
        java.awt.Stroke stroke23 = dateAxis11.getAxisLineStroke();
        org.jfree.data.Range range24 = dateAxis11.getDefaultAutoRange();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(range24);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        java.awt.Paint paint7 = categoryPlot6.getDomainGridlinePaint();
        java.lang.Object obj8 = categoryPlot6.clone();
        org.jfree.chart.axis.ValueAxis valueAxis10 = categoryPlot6.getRangeAxis(3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNull(valueAxis10);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot6.getDrawingSupplier();
        categoryPlot6.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot6.getDomainAxisEdge(10);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = categoryPlot6.getDomainAxis();
        categoryPlot6.setDomainGridlinesVisible(true);
        boolean boolean15 = categoryPlot6.isDomainZoomable();
        java.awt.Paint paint16 = categoryPlot6.getOutlinePaint();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNull(categoryAxis12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getLeftArrow();
        dateAxis0.setLowerMargin(0.0d);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range6 = dateAxis5.getDefaultAutoRange();
        dateAxis0.setRange(range6);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(range6);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean5 = dateAxis4.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        org.jfree.data.Range range8 = dateAxis4.getRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis4);
        java.awt.Stroke stroke10 = xYPlot0.getDomainCrosshairStroke();
        org.jfree.data.xy.XYDataset xYDataset11 = xYPlot0.getDataset();
        xYPlot0.mapDatasetToRangeAxis(0, (int) (byte) -1);
        java.awt.Stroke stroke15 = xYPlot0.getDomainCrosshairStroke();
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        java.awt.geom.Point2D point2D18 = null;
        org.jfree.chart.plot.PlotState plotState19 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        try {
            xYPlot0.draw(graphics2D16, rectangle2D17, point2D18, plotState19, plotRenderingInfo20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNull(xYDataset11);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        boolean boolean0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot6.getDrawingSupplier();
        categoryPlot6.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot6.getDomainAxisEdge(10);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean16 = dateAxis15.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, (org.jfree.chart.axis.ValueAxis) dateAxis15, categoryItemRenderer17);
        dateAxis15.resizeRange((double) 100.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = dateAxis15.getLabelInsets();
        int int22 = categoryPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis15);
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.axis.AxisState axisState24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = xYPlot26.getDomainAxisEdge(192);
        try {
            java.util.List list29 = dateAxis15.refreshTicks(graphics2D23, axisState24, rectangle2D25, rectangleEdge28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(rectangleEdge28);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        java.awt.Paint paint7 = categoryPlot6.getDomainGridlinePaint();
        try {
            categoryPlot6.mapDatasetToDomainAxis((-4145152), (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean2 = dateAxis1.isNegativeArrowVisible();
        dateAxis1.setAutoRangeMinimumSize((double) (short) 1, true);
        java.awt.Shape shape6 = dateAxis1.getUpArrow();
        dateAxis1.setInverted(false);
        java.text.DateFormat dateFormat9 = dateAxis1.getDateFormatOverride();
        try {
            dateAxis1.setRange(4.0d, (double) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNull(dateFormat9);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        java.awt.Paint paint8 = categoryPlot6.getDomainGridlinePaint();
        java.awt.Image image9 = null;
        categoryPlot6.setBackgroundImage(image9);
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        xYPlot12.setRangeZeroBaselineVisible(false);
        boolean boolean15 = xYPlot12.isOutlineVisible();
        xYPlot12.clearRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot12.setDomainAxisLocation(64, axisLocation18);
        categoryPlot6.setRangeAxisLocation(12, axisLocation18);
        boolean boolean21 = categoryPlot6.isDomainGridlinesVisible();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean2 = dateAxis1.isNegativeArrowVisible();
        dateAxis1.setAutoRangeMinimumSize((double) (short) 1, true);
        org.jfree.chart.axis.Timeline timeline6 = null;
        dateAxis1.setTimeline(timeline6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean12 = dateAxis11.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis11, categoryItemRenderer13);
        boolean boolean15 = categoryPlot14.isOutlineVisible();
        java.awt.Paint paint16 = categoryPlot14.getDomainGridlinePaint();
        java.lang.String str17 = categoryPlot14.getNoDataMessage();
        dateAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot14);
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        xYPlot20.setRangeZeroBaselineVisible(false);
        boolean boolean23 = xYPlot20.isOutlineVisible();
        xYPlot20.clearRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation26 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot20.setDomainAxisLocation(64, axisLocation26);
        categoryPlot14.setRangeAxisLocation(192, axisLocation26);
        org.jfree.chart.axis.AxisLocation axisLocation29 = axisLocation26.getOpposite();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNotNull(axisLocation29);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean5 = dateAxis4.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        org.jfree.data.Range range8 = dateAxis4.getRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis4);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        xYPlot0.setQuadrantPaint((int) (short) 0, (java.awt.Paint) color11);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D2 = rectangleInsets0.createInsetRectangle(rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean5 = dateAxis4.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        org.jfree.data.Range range8 = dateAxis4.getRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis4);
        dateAxis4.resizeRange((double) 8);
        java.awt.Paint paint12 = dateAxis4.getAxisLinePaint();
        java.awt.Shape shape13 = dateAxis4.getDownArrow();
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.axis.AxisState axisState15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean21 = dateAxis20.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis20, categoryItemRenderer22);
        boolean boolean24 = categoryPlot23.isOutlineVisible();
        java.awt.Paint paint25 = categoryPlot23.getDomainGridlinePaint();
        java.awt.Image image26 = null;
        categoryPlot23.setBackgroundImage(image26);
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot();
        xYPlot29.setRangeZeroBaselineVisible(false);
        boolean boolean32 = xYPlot29.isOutlineVisible();
        xYPlot29.clearRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation35 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot29.setDomainAxisLocation(64, axisLocation35);
        categoryPlot23.setRangeAxisLocation(12, axisLocation35);
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = categoryPlot23.getDomainAxisEdge((int) '4');
        try {
            java.util.List list40 = dateAxis4.refreshTicks(graphics2D14, axisState15, rectangle2D16, rectangleEdge39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertNotNull(rectangleEdge39);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 11);
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range5 = dateAxis4.getDefaultAutoRange();
        xYPlot2.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis4);
        java.awt.Paint paint7 = xYPlot2.getOutlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        xYPlot2.zoomRangeAxes((double) (byte) 100, plotRenderingInfo9, point2D10, false);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean17 = dateAxis16.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis16, categoryItemRenderer18);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = dateAxis16.getTickLabelInsets();
        xYPlot2.setInsets(rectangleInsets20, false);
        boolean boolean23 = valueMarker1.equals((java.lang.Object) rectangleInsets20);
        org.jfree.chart.JFreeChart jFreeChart24 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent25 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) valueMarker1, jFreeChart24);
        java.awt.Paint[] paintArray26 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Color color27 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Paint[] paintArray29 = new java.awt.Paint[] { color27, color28 };
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Paint paint31 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Paint paint33 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        java.awt.Paint[] paintArray34 = new java.awt.Paint[] { color30, paint31, color32, paint33 };
        java.awt.Stroke stroke35 = null;
        java.awt.Stroke[] strokeArray36 = new java.awt.Stroke[] { stroke35 };
        java.awt.Stroke[] strokeArray37 = null;
        java.awt.Shape[] shapeArray38 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier39 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray26, paintArray29, paintArray34, strokeArray36, strokeArray37, shapeArray38);
        org.jfree.chart.JFreeChart jFreeChart40 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType41 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        java.lang.String str42 = chartChangeEventType41.toString();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent43 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) paintArray29, jFreeChart40, chartChangeEventType41);
        chartChangeEvent25.setType(chartChangeEventType41);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(paintArray26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(paintArray29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(paintArray34);
        org.junit.Assert.assertNotNull(strokeArray36);
        org.junit.Assert.assertNotNull(shapeArray38);
        org.junit.Assert.assertNotNull(chartChangeEventType41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str42.equals("ChartChangeEventType.DATASET_UPDATED"));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = categoryPlot6.getLegendItems();
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range12 = dateAxis11.getDefaultAutoRange();
        xYPlot9.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis11);
        java.awt.Paint paint14 = xYPlot9.getOutlinePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = xYPlot9.getRangeAxisEdge();
        org.jfree.chart.plot.PlotOrientation plotOrientation16 = xYPlot9.getOrientation();
        categoryPlot6.setOrientation(plotOrientation16);
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean22 = dateAxis21.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis21, categoryItemRenderer23);
        boolean boolean25 = categoryPlot24.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier26 = categoryPlot24.getDrawingSupplier();
        categoryPlot24.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = categoryPlot24.getDomainAxisEdge(10);
        boolean boolean30 = categoryPlot24.isRangeZoomable();
        java.awt.Paint paint31 = categoryPlot24.getDomainGridlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation33 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot24.setDomainAxisLocation(64, axisLocation33, false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder36 = categoryPlot24.getDatasetRenderingOrder();
        org.jfree.data.category.CategoryDataset categoryDataset37 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = null;
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean41 = dateAxis40.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer42 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset37, categoryAxis38, (org.jfree.chart.axis.ValueAxis) dateAxis40, categoryItemRenderer42);
        boolean boolean44 = categoryPlot43.isOutlineVisible();
        categoryPlot43.mapDatasetToDomainAxis(100, (int) 'a');
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer49 = null;
        categoryPlot43.setRenderer(255, categoryItemRenderer49, false);
        org.jfree.chart.util.SortOrder sortOrder52 = categoryPlot43.getColumnRenderingOrder();
        categoryPlot24.setColumnRenderingOrder(sortOrder52);
        categoryPlot6.setColumnRenderingOrder(sortOrder52);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(legendItemCollection8);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(plotOrientation16);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(drawingSupplier26);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(axisLocation33);
        org.junit.Assert.assertNotNull(datasetRenderingOrder36);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(sortOrder52);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot6.getDrawingSupplier();
        categoryPlot6.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot6.getDomainAxisEdge(10);
        boolean boolean12 = categoryPlot6.isRangeZoomable();
        java.awt.Paint paint13 = categoryPlot6.getDomainGridlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot6.setDomainAxisLocation(64, axisLocation15, false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder18 = categoryPlot6.getDatasetRenderingOrder();
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range22 = dateAxis21.getDefaultAutoRange();
        xYPlot19.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis21);
        java.awt.Paint paint24 = xYPlot19.getOutlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        xYPlot19.zoomRangeAxes((double) (byte) 100, plotRenderingInfo26, point2D27, false);
        java.awt.Stroke stroke30 = xYPlot19.getDomainCrosshairStroke();
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean33 = dateAxis32.isNegativeArrowVisible();
        double double34 = dateAxis32.getLowerBound();
        java.awt.Paint paint35 = dateAxis32.getTickLabelPaint();
        java.awt.Stroke stroke36 = dateAxis32.getAxisLineStroke();
        xYPlot19.setDomainGridlineStroke(stroke36);
        boolean boolean38 = datasetRenderingOrder18.equals((java.lang.Object) stroke36);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(datasetRenderingOrder18);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        int int1 = color0.getGreen();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 128 + "'", int1 == 128);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        java.awt.Color color1 = java.awt.Color.getColor("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.junit.Assert.assertNull(color1);
    }

//    @Test
//    public void test266() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test266");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getMiddleMillisecond();
//        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
//        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("hi!");
//        boolean boolean6 = dateAxis5.isNegativeArrowVisible();
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer7);
//        boolean boolean9 = categoryPlot8.isOutlineVisible();
//        categoryPlot8.mapDatasetToDomainAxis(100, (int) 'a');
//        int int13 = day0.compareTo((java.lang.Object) 100);
//        java.util.Date date14 = day0.getStart();
//        int int15 = day0.getMonth();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560452399999L + "'", long1 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
//    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot6.getDrawingSupplier();
        categoryPlot6.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot6.getDomainAxisEdge(10);
        boolean boolean12 = categoryPlot6.isRangeZoomable();
        categoryPlot6.setOutlineVisible(true);
        java.awt.Paint paint15 = null;
        categoryPlot6.setOutlinePaint(paint15);
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean22 = dateAxis21.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis21, categoryItemRenderer23);
        org.jfree.data.Range range25 = dateAxis21.getRange();
        xYPlot17.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis21);
        java.awt.Stroke stroke27 = xYPlot17.getDomainCrosshairStroke();
        categoryPlot6.setDomainGridlineStroke(stroke27);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertNotNull(stroke27);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        java.awt.Paint paint8 = categoryPlot6.getDomainGridlinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot6.getDomainAxisForDataset((int) (short) 0);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean15 = dateAxis14.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis14, categoryItemRenderer16);
        org.jfree.data.Range range18 = dateAxis14.getRange();
        int int19 = categoryPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis14);
        dateAxis14.setFixedAutoRange((double) 255);
        dateAxis14.setLabelAngle((double) 1L);
        boolean boolean24 = dateAxis14.isVisible();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

//    @Test
//    public void test269() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test269");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getMiddleMillisecond();
//        int int2 = day0.getDayOfMonth();
//        long long3 = day0.getFirstMillisecond();
//        long long4 = day0.getMiddleMillisecond();
//        java.util.Date date5 = day0.getEnd();
//        java.util.Calendar calendar6 = null;
//        try {
//            day0.peg(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560452399999L + "'", long1 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560452399999L + "'", long4 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date5);
//    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        java.awt.Paint paint5 = xYPlot0.getOutlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        xYPlot0.zoomRangeAxes((double) (byte) 100, plotRenderingInfo7, point2D8, false);
        java.awt.Stroke stroke11 = xYPlot0.getRangeGridlineStroke();
        int int12 = xYPlot0.getRangeAxisCount();
        xYPlot0.setRangeCrosshairValue((double) (-1));
        java.awt.Paint paint15 = xYPlot0.getRangeCrosshairPaint();
        java.awt.Paint paint17 = xYPlot0.getQuadrantPaint(0);
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = xYPlot0.getRendererForDataset(xYDataset18);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertNull(xYItemRenderer19);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot6.getDrawingSupplier();
        categoryPlot6.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot6.getDomainAxisEdge(10);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = categoryPlot6.getDomainAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Point2D point2D16 = null;
        categoryPlot6.zoomDomainAxes((double) 'a', (double) '#', plotRenderingInfo15, point2D16);
        categoryPlot6.setWeight(12);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNull(categoryAxis12);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        java.awt.Paint paint0 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot6.getDrawingSupplier();
        categoryPlot6.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot6.getDomainAxisEdge(10);
        boolean boolean12 = categoryPlot6.isRangeZoomable();
        java.awt.Paint paint13 = categoryPlot6.getDomainGridlinePaint();
        java.awt.Paint paint14 = categoryPlot6.getOutlinePaint();
        categoryPlot6.clearDomainAxes();
        categoryPlot6.setAnchorValue((double) 10L);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean2 = dateAxis1.isTickLabelsVisible();
        dateAxis1.setLabelURL("Layer.FOREGROUND");
        double double5 = dateAxis1.getLowerMargin();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range2 = dateAxis1.getDefaultAutoRange();
        java.awt.Paint paint3 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        dateAxis1.setAxisLinePaint(paint3);
        dateAxis1.setAutoRange(true);
        java.awt.Shape shape7 = dateAxis1.getLeftArrow();
        java.lang.String str8 = dateAxis1.getLabelToolTip();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range2 = dateAxis1.getDefaultAutoRange();
        java.awt.Paint paint3 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        dateAxis1.setAxisLinePaint(paint3);
        dateAxis1.setUpperBound(6.0d);
        boolean boolean7 = dateAxis1.isInverted();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 3, 100.0d);
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range6 = dateAxis5.getDefaultAutoRange();
        xYPlot3.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis5);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot3.setRangeCrosshairStroke(stroke8);
        intervalMarker2.setStroke(stroke8);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.CENTER;
        intervalMarker2.setLabelAnchor(rectangleAnchor11);
        java.awt.Color color13 = java.awt.Color.red;
        intervalMarker2.setLabelPaint((java.awt.Paint) color13);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType15 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        intervalMarker2.setLabelOffsetType(lengthAdjustmentType15);
        intervalMarker2.setEndValue((double) (byte) -1);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(lengthAdjustmentType15);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeZeroBaselineVisible(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder3 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot0.setRangeAxisLocation((int) (byte) 100, axisLocation5);
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean11 = dateAxis10.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis10, categoryItemRenderer12);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = dateAxis10.getTickLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        dateAxis15.setTickLabelPaint((java.awt.Paint) color16);
        boolean boolean18 = rectangleInsets14.equals((java.lang.Object) dateAxis15);
        java.lang.String str19 = rectangleInsets14.toString();
        org.jfree.chart.util.UnitType unitType20 = rectangleInsets14.getUnitType();
        double double21 = rectangleInsets14.getBottom();
        double double23 = rectangleInsets14.calculateRightInset(0.0d);
        double double24 = rectangleInsets14.getRight();
        xYPlot0.setAxisOffset(rectangleInsets14);
        org.jfree.chart.axis.AxisSpace axisSpace26 = xYPlot0.getFixedRangeAxisSpace();
        org.junit.Assert.assertNotNull(datasetRenderingOrder3);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str19.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
        org.junit.Assert.assertNotNull(unitType20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 2.0d + "'", double21 == 2.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 4.0d + "'", double23 == 4.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 4.0d + "'", double24 == 4.0d);
        org.junit.Assert.assertNull(axisSpace26);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeZeroBaselineVisible(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder3 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot0.setRangeAxisLocation((int) (byte) 100, axisLocation5);
        boolean boolean7 = xYPlot0.isDomainGridlinesVisible();
        xYPlot0.setOutlineVisible(true);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder10 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean13 = dateAxis12.isNegativeArrowVisible();
        double double14 = dateAxis12.getLowerBound();
        dateAxis12.setAutoRange(false);
        org.jfree.data.Range range17 = xYPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis12);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition18 = null;
        try {
            dateAxis12.setTickMarkPosition(dateTickMarkPosition18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(datasetRenderingOrder3);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(seriesRenderingOrder10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNull(range17);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        categoryPlot6.mapDatasetToDomainAxis(100, (int) 'a');
        categoryPlot6.mapDatasetToRangeAxis(2, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        java.awt.Paint paint5 = xYPlot0.getOutlinePaint();
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        xYPlot7.setRangeZeroBaselineVisible(false);
        boolean boolean10 = xYPlot7.isOutlineVisible();
        xYPlot7.clearRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot7.setDomainAxisLocation(64, axisLocation13);
        xYPlot0.setDomainAxisLocation(2, axisLocation13);
        org.jfree.chart.axis.AxisLocation axisLocation16 = xYPlot0.getDomainAxisLocation();
        xYPlot0.zoom((double) 100.0f);
        java.awt.Paint paint19 = xYPlot0.getDomainZeroBaselinePaint();
        boolean boolean20 = xYPlot0.isRangeZoomable();
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot();
        xYPlot21.setRangeZeroBaselineVisible(false);
        boolean boolean24 = xYPlot21.isOutlineVisible();
        xYPlot21.clearRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation27 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot21.setDomainAxisLocation(64, axisLocation27);
        java.awt.Color color29 = java.awt.Color.WHITE;
        xYPlot21.setRangeTickBandPaint((java.awt.Paint) color29);
        java.awt.Stroke stroke31 = xYPlot21.getDomainCrosshairStroke();
        xYPlot0.setOutlineStroke(stroke31);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(stroke31);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        java.awt.Paint paint5 = xYPlot0.getOutlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        xYPlot0.zoomRangeAxes((double) (byte) 100, plotRenderingInfo7, point2D8, false);
        java.awt.Stroke stroke11 = xYPlot0.getRangeGridlineStroke();
        int int12 = xYPlot0.getRangeAxisCount();
        xYPlot0.setRangeCrosshairValue((double) (-1));
        java.awt.Paint paint15 = xYPlot0.getRangeCrosshairPaint();
        boolean boolean16 = xYPlot0.isRangeGridlinesVisible();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation17 = null;
        try {
            xYPlot0.addAnnotation(xYAnnotation17, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeZeroBaselineVisible(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder3 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot0.setRangeAxisLocation((int) (byte) 100, axisLocation5);
        boolean boolean7 = xYPlot0.isDomainGridlinesVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        int int9 = xYPlot0.getIndexOf(xYItemRenderer8);
        org.junit.Assert.assertNotNull(datasetRenderingOrder3);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeZeroBaselineVisible(false);
        boolean boolean3 = xYPlot0.isOutlineVisible();
        org.jfree.chart.plot.IntervalMarker intervalMarker6 = new org.jfree.chart.plot.IntervalMarker((double) 3, 100.0d);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range10 = dateAxis9.getDefaultAutoRange();
        xYPlot7.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis9);
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot7.setRangeCrosshairStroke(stroke12);
        intervalMarker6.setStroke(stroke12);
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        intervalMarker6.setOutlinePaint((java.awt.Paint) color15);
        double double17 = intervalMarker6.getEndValue();
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker6);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 100.0d + "'", double17 == 100.0d);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        java.awt.Paint paint5 = xYPlot0.getOutlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        xYPlot0.zoomRangeAxes((double) (byte) 100, plotRenderingInfo7, point2D8, false);
        org.jfree.chart.plot.IntervalMarker intervalMarker14 = new org.jfree.chart.plot.IntervalMarker((double) 3, 100.0d);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean19 = dateAxis18.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, (org.jfree.chart.axis.ValueAxis) dateAxis18, categoryItemRenderer20);
        boolean boolean22 = categoryPlot21.isOutlineVisible();
        java.awt.Paint paint23 = categoryPlot21.getDomainGridlinePaint();
        java.lang.String str24 = categoryPlot21.getNoDataMessage();
        intervalMarker14.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot21);
        org.jfree.chart.util.Layer layer26 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addRangeMarker((int) (short) 1, (org.jfree.chart.plot.Marker) intervalMarker14, layer26);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        java.awt.geom.Point2D point2D31 = null;
        try {
            xYPlot0.zoomDomainAxes((double) 'a', 1.0d, plotRenderingInfo30, point2D31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (97.0) <= upper (1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertNotNull(layer26);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        java.awt.Paint paint8 = categoryPlot6.getDomainGridlinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot6.getDomainAxisForDataset((int) (short) 0);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean15 = dateAxis14.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis14, categoryItemRenderer16);
        org.jfree.data.Range range18 = dateAxis14.getRange();
        int int19 = categoryPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis14);
        dateAxis14.setFixedAutoRange((double) 255);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = dateAxis14.getLabelInsets();
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType24 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.plot.IntervalMarker intervalMarker27 = new org.jfree.chart.plot.IntervalMarker((double) 3, 100.0d);
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range31 = dateAxis30.getDefaultAutoRange();
        xYPlot28.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis30);
        java.awt.Stroke stroke33 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot28.setRangeCrosshairStroke(stroke33);
        intervalMarker27.setStroke(stroke33);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor36 = org.jfree.chart.util.RectangleAnchor.CENTER;
        intervalMarker27.setLabelAnchor(rectangleAnchor36);
        java.awt.Color color38 = java.awt.Color.red;
        intervalMarker27.setLabelPaint((java.awt.Paint) color38);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType40 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        intervalMarker27.setLabelOffsetType(lengthAdjustmentType40);
        try {
            java.awt.geom.Rectangle2D rectangle2D42 = rectangleInsets22.createAdjustedRectangle(rectangle2D23, lengthAdjustmentType24, lengthAdjustmentType40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(lengthAdjustmentType24);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(rectangleAnchor36);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(lengthAdjustmentType40);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) 0, 0, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeZeroBaselineVisible(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder3 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot0.setRangeAxisLocation((int) (byte) 100, axisLocation5);
        xYPlot0.setRangeCrosshairVisible(false);
        boolean boolean9 = xYPlot0.isRangeZeroBaselineVisible();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        xYPlot0.setDomainGridlinePaint((java.awt.Paint) color10);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean16 = dateAxis15.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, (org.jfree.chart.axis.ValueAxis) dateAxis15, categoryItemRenderer17);
        boolean boolean19 = categoryPlot18.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier20 = categoryPlot18.getDrawingSupplier();
        categoryPlot18.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = categoryPlot18.getDomainAxisEdge(10);
        boolean boolean24 = categoryPlot18.isRangeZoomable();
        java.awt.Paint paint25 = categoryPlot18.getDomainGridlinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = categoryPlot18.getDomainAxis();
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range30 = dateAxis29.getDefaultAutoRange();
        xYPlot27.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis29);
        java.awt.Paint paint32 = xYPlot27.getOutlinePaint();
        xYPlot27.setRangeCrosshairValue(1.0E-8d);
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        xYPlot27.setAxisOffset(rectangleInsets35);
        org.jfree.chart.util.UnitType unitType37 = rectangleInsets35.getUnitType();
        categoryPlot18.setAxisOffset(rectangleInsets35);
        xYPlot0.setInsets(rectangleInsets35, true);
        double double42 = rectangleInsets35.calculateRightInset((double) 0);
        org.junit.Assert.assertNotNull(datasetRenderingOrder3);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(drawingSupplier20);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(categoryAxis26);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertNotNull(unitType37);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 8.0d + "'", double42 == 8.0d);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        java.awt.Paint paint5 = xYPlot0.getOutlinePaint();
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        xYPlot7.setRangeZeroBaselineVisible(false);
        boolean boolean10 = xYPlot7.isOutlineVisible();
        xYPlot7.clearRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot7.setDomainAxisLocation(64, axisLocation13);
        xYPlot0.setDomainAxisLocation(2, axisLocation13);
        org.jfree.chart.axis.AxisLocation axisLocation16 = xYPlot0.getDomainAxisLocation();
        xYPlot0.zoom((double) 100.0f);
        java.awt.Paint paint19 = xYPlot0.getDomainZeroBaselinePaint();
        boolean boolean20 = xYPlot0.isRangeZoomable();
        java.util.List list21 = xYPlot0.getAnnotations();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(list21);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        java.awt.Stroke stroke4 = numberAxis3.getTickMarkStroke();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis3.setTickUnit(numberTickUnit5);
        numberAxis1.setTickUnit(numberTickUnit5);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean12 = dateAxis11.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis11, categoryItemRenderer13);
        boolean boolean15 = categoryPlot14.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier16 = categoryPlot14.getDrawingSupplier();
        java.lang.Object obj17 = null;
        boolean boolean18 = categoryPlot14.equals(obj17);
        categoryPlot14.clearRangeMarkers(3);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = categoryPlot14.getDomainAxis((int) (byte) -1);
        boolean boolean23 = numberAxis1.equals((java.lang.Object) (byte) -1);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(numberTickUnit5);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(drawingSupplier16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(categoryAxis22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot6.getDrawingSupplier();
        categoryPlot6.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot6.getDomainAxisEdge(10);
        boolean boolean12 = categoryPlot6.isRangeZoomable();
        java.awt.Paint paint13 = categoryPlot6.getDomainGridlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot6.setDomainAxisLocation(64, axisLocation15, false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder18 = categoryPlot6.getDatasetRenderingOrder();
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean23 = dateAxis22.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, (org.jfree.chart.axis.ValueAxis) dateAxis22, categoryItemRenderer24);
        dateAxis22.resizeRange((double) 100.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = dateAxis22.getLabelInsets();
        categoryPlot6.setAxisOffset(rectangleInsets28);
        double double30 = rectangleInsets28.getLeft();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(datasetRenderingOrder18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.0d + "'", double30 == 3.0d);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getDomainAxisEdge(192);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean6 = dateAxis5.isNegativeArrowVisible();
        dateAxis5.setAutoRangeMinimumSize((double) (short) 1, true);
        org.jfree.chart.axis.Timeline timeline10 = null;
        dateAxis5.setTimeline(timeline10);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean14 = dateAxis13.isTickLabelsVisible();
        org.jfree.data.time.DateRange dateRange15 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis13.setRange((org.jfree.data.Range) dateRange15);
        dateAxis5.setDefaultAutoRange((org.jfree.data.Range) dateRange15);
        try {
            xYPlot0.setRangeAxis((-1), (org.jfree.chart.axis.ValueAxis) dateAxis5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateRange15);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        categoryPlot6.mapDatasetToDomainAxis(100, (int) 'a');
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        categoryPlot6.setRenderer(255, categoryItemRenderer12, false);
        double double15 = categoryPlot6.getRangeCrosshairValue();
        org.jfree.data.general.Dataset dataset16 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent17 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) categoryPlot6, dataset16);
        java.lang.String str18 = datasetChangeEvent17.toString();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.plot.IntervalMarker intervalMarker3 = new org.jfree.chart.plot.IntervalMarker((double) 3, 100.0d);
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range7 = dateAxis6.getDefaultAutoRange();
        xYPlot4.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot4.setRangeCrosshairStroke(stroke9);
        intervalMarker3.setStroke(stroke9);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = org.jfree.chart.util.RectangleAnchor.CENTER;
        intervalMarker3.setLabelAnchor(rectangleAnchor12);
        try {
            java.awt.geom.Point2D point2D14 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 64, (double) 12);
        java.lang.Object obj3 = intervalMarker2.clone();
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.CENTER;
        intervalMarker2.setLabelTextAnchor(textAnchor4);
        java.awt.Paint paint6 = intervalMarker2.getLabelPaint();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder8 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean10 = datasetRenderingOrder8.equals((java.lang.Object) layer9);
        java.lang.Object obj11 = null;
        boolean boolean12 = datasetRenderingOrder8.equals(obj11);
        categoryPlot6.setDatasetRenderingOrder(datasetRenderingOrder8);
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        categoryPlot6.setOrientation(plotOrientation14);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder8);
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(plotOrientation14);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        int int3 = java.awt.Color.HSBtoRGB((float) (byte) 10, 0.0f, (float) 100L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-100) + "'", int3 == (-100));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        java.util.TimeZone timeZone7 = dateAxis3.getTimeZone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource8 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone7);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(tickUnitSource8);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        java.awt.Paint paint5 = xYPlot0.getOutlinePaint();
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        xYPlot7.setRangeZeroBaselineVisible(false);
        boolean boolean10 = xYPlot7.isOutlineVisible();
        xYPlot7.clearRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot7.setDomainAxisLocation(64, axisLocation13);
        xYPlot0.setDomainAxisLocation(2, axisLocation13);
        org.jfree.chart.axis.AxisLocation axisLocation16 = xYPlot0.getDomainAxisLocation();
        xYPlot0.zoom((double) 100.0f);
        xYPlot0.configureDomainAxes();
        xYPlot0.mapDatasetToRangeAxis((int) (byte) -1, 192);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(axisLocation16);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeZeroBaselineVisible(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        xYPlot0.zoomRangeAxes(0.0d, (double) 11, plotRenderingInfo5, point2D6);
        java.awt.Paint paint8 = xYPlot0.getRangeGridlinePaint();
        xYPlot0.clearRangeAxes();
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range14 = dateAxis13.getDefaultAutoRange();
        xYPlot11.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis13);
        java.awt.Paint paint16 = xYPlot11.getOutlinePaint();
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        xYPlot18.setRangeZeroBaselineVisible(false);
        boolean boolean21 = xYPlot18.isOutlineVisible();
        xYPlot18.clearRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation24 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot18.setDomainAxisLocation(64, axisLocation24);
        xYPlot11.setDomainAxisLocation(2, axisLocation24);
        xYPlot0.setDomainAxisLocation((int) (byte) 0, axisLocation24);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(axisLocation24);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        java.awt.Paint paint5 = xYPlot0.getOutlinePaint();
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        xYPlot7.setRangeZeroBaselineVisible(false);
        boolean boolean10 = xYPlot7.isOutlineVisible();
        xYPlot7.clearRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot7.setDomainAxisLocation(64, axisLocation13);
        xYPlot0.setDomainAxisLocation(2, axisLocation13);
        org.jfree.chart.axis.AxisLocation axisLocation16 = xYPlot0.getDomainAxisLocation();
        xYPlot0.zoom((double) 100.0f);
        xYPlot0.configureDomainAxes();
        xYPlot0.clearRangeAxes();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(axisLocation16);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean5 = dateAxis4.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        org.jfree.data.Range range8 = dateAxis4.getRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis4);
        org.jfree.chart.axis.AxisSpace axisSpace10 = xYPlot0.getFixedRangeAxisSpace();
        int int11 = xYPlot0.getSeriesCount();
        xYPlot0.setWeight((int) 'a');
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNull(axisSpace10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        java.awt.Paint paint7 = categoryPlot6.getDomainGridlinePaint();
        java.lang.Object obj8 = categoryPlot6.clone();
        boolean boolean9 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = categoryPlot6.getDomainAxisForDataset(6);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(categoryAxis11);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean2 = dateAxis1.isNegativeArrowVisible();
        double double3 = dateAxis1.getLowerBound();
        java.awt.Paint paint4 = dateAxis1.getTickLabelPaint();
        dateAxis1.setLowerBound(0.0d);
        dateAxis1.setRangeAboutValue((double) 13, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        java.awt.Paint paint8 = categoryPlot6.getDomainGridlinePaint();
        java.lang.String str9 = categoryPlot6.getNoDataMessage();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        categoryPlot6.setRangeCrosshairPaint((java.awt.Paint) color10);
        org.jfree.data.general.DatasetGroup datasetGroup12 = categoryPlot6.getDatasetGroup();
        categoryPlot6.clearRangeAxes();
        org.jfree.chart.axis.AxisSpace axisSpace14 = categoryPlot6.getFixedDomainAxisSpace();
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = categoryPlot6.getDomainAxis();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNull(datasetGroup12);
        org.junit.Assert.assertNull(axisSpace14);
        org.junit.Assert.assertNull(categoryAxis15);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        categoryPlot6.clearRangeMarkers(0);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryPlot6.setOutlineStroke(stroke9);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeZeroBaselineVisible(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder3 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot0.setRangeAxisLocation((int) (byte) 100, axisLocation5);
        boolean boolean7 = xYPlot0.isDomainGridlinesVisible();
        java.awt.Paint paint8 = null;
        try {
            xYPlot0.setDomainCrosshairPaint(paint8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(datasetRenderingOrder3);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        java.awt.Font font8 = categoryPlot6.getNoDataMessageFont();
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = categoryPlot6.getRangeAxisEdge((int) (short) 10);
        org.jfree.data.category.CategoryDataset categoryDataset11 = categoryPlot6.getDataset();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNull(categoryDataset11);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot6.getDrawingSupplier();
        categoryPlot6.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot6.getDomainAxisEdge(10);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean16 = dateAxis15.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, (org.jfree.chart.axis.ValueAxis) dateAxis15, categoryItemRenderer17);
        dateAxis15.resizeRange((double) 100.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = dateAxis15.getLabelInsets();
        int int22 = categoryPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis15);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation23 = null;
        try {
            boolean boolean24 = categoryPlot6.removeAnnotation(categoryAnnotation23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        java.awt.Stroke stroke4 = numberAxis3.getTickMarkStroke();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis3.setTickUnit(numberTickUnit5);
        numberAxis1.setTickUnit(numberTickUnit5);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        java.awt.Stroke stroke12 = numberAxis11.getTickMarkStroke();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit13 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis11.setTickUnit(numberTickUnit13);
        numberAxis9.setTickUnit(numberTickUnit13);
        numberAxis1.setTickUnit(numberTickUnit13);
        org.jfree.data.RangeType rangeType17 = numberAxis1.getRangeType();
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        java.awt.Stroke stroke22 = numberAxis21.getTickMarkStroke();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit23 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis21.setTickUnit(numberTickUnit23);
        numberAxis19.setTickUnit(numberTickUnit23);
        numberAxis1.setTickUnit(numberTickUnit23, false, false);
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        java.awt.Stroke stroke33 = numberAxis32.getTickMarkStroke();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit34 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis32.setTickUnit(numberTickUnit34);
        numberAxis30.setTickUnit(numberTickUnit34, false, false);
        numberAxis1.setTickUnit(numberTickUnit34, false, false);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(numberTickUnit5);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(numberTickUnit13);
        org.junit.Assert.assertNotNull(rangeType17);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(numberTickUnit23);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(numberTickUnit34);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot6.getDrawingSupplier();
        categoryPlot6.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot6.getDomainAxisEdge(10);
        boolean boolean12 = categoryPlot6.isRangeZoomable();
        java.awt.Paint paint13 = categoryPlot6.getDomainGridlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot6.setDomainAxisLocation(64, axisLocation15, false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder18 = categoryPlot6.getDatasetRenderingOrder();
        categoryPlot6.clearDomainAxes();
        float float20 = categoryPlot6.getBackgroundAlpha();
        categoryPlot6.setRangeCrosshairLockedOnData(false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(datasetRenderingOrder18);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 1.0f + "'", float20 == 1.0f);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeZeroBaselineVisible(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder3 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot0.setRangeAxisLocation((int) (byte) 100, axisLocation5);
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean11 = dateAxis10.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis10, categoryItemRenderer12);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = dateAxis10.getTickLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        dateAxis15.setTickLabelPaint((java.awt.Paint) color16);
        boolean boolean18 = rectangleInsets14.equals((java.lang.Object) dateAxis15);
        java.lang.String str19 = rectangleInsets14.toString();
        org.jfree.chart.util.UnitType unitType20 = rectangleInsets14.getUnitType();
        double double21 = rectangleInsets14.getBottom();
        double double23 = rectangleInsets14.calculateRightInset(0.0d);
        double double24 = rectangleInsets14.getRight();
        xYPlot0.setAxisOffset(rectangleInsets14);
        java.awt.Stroke stroke26 = xYPlot0.getRangeZeroBaselineStroke();
        java.awt.Color color27 = org.jfree.chart.ChartColor.DARK_YELLOW;
        int int28 = color27.getRGB();
        xYPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color27);
        org.junit.Assert.assertNotNull(datasetRenderingOrder3);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str19.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
        org.junit.Assert.assertNotNull(unitType20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 2.0d + "'", double21 == 2.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 4.0d + "'", double23 == 4.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 4.0d + "'", double24 == 4.0d);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-4145152) + "'", int28 == (-4145152));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        java.lang.String str1 = lengthAdjustmentType0.toString();
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CONTRACT" + "'", str1.equals("CONTRACT"));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot6.getDrawingSupplier();
        categoryPlot6.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot6.getDomainAxisEdge(10);
        boolean boolean12 = categoryPlot6.isRangeZoomable();
        java.awt.Paint paint13 = categoryPlot6.getDomainGridlinePaint();
        java.awt.Paint paint14 = categoryPlot6.getOutlinePaint();
        categoryPlot6.clearDomainAxes();
        categoryPlot6.configureRangeAxes();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        java.lang.Class class0 = null;
        java.util.Date date1 = null;
        java.util.TimeZone timeZone2 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date1, timeZone2);
        org.junit.Assert.assertNull(regularTimePeriod3);
    }

//    @Test
//    public void test320() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test320");
//        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
//        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) 3.0d, "ChartChangeEventType.DATASET_UPDATED");
//        categoryAxis0.setMaximumCategoryLabelLines((int) ' ');
//        org.jfree.chart.axis.NumberTickUnit numberTickUnit6 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
//        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
//        java.awt.geom.Rectangle2D rectangle2D10 = null;
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        long long12 = day11.getMiddleMillisecond();
//        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
//        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("hi!");
//        boolean boolean17 = dateAxis16.isNegativeArrowVisible();
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis16, categoryItemRenderer18);
//        boolean boolean20 = categoryPlot19.isOutlineVisible();
//        categoryPlot19.mapDatasetToDomainAxis(100, (int) 'a');
//        int int24 = day11.compareTo((java.lang.Object) 100);
//        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis26 = null;
//        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis("hi!");
//        boolean boolean29 = dateAxis28.isNegativeArrowVisible();
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot(categoryDataset25, categoryAxis26, (org.jfree.chart.axis.ValueAxis) dateAxis28, categoryItemRenderer30);
//        categoryPlot31.clearRangeMarkers(0);
//        org.jfree.chart.axis.AxisLocation axisLocation35 = categoryPlot31.getRangeAxisLocation(10);
//        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot();
//        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis("hi!");
//        org.jfree.data.Range range39 = dateAxis38.getDefaultAutoRange();
//        xYPlot36.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis38);
//        java.awt.Paint paint41 = xYPlot36.getOutlinePaint();
//        org.jfree.chart.util.RectangleEdge rectangleEdge42 = xYPlot36.getRangeAxisEdge();
//        org.jfree.chart.plot.PlotOrientation plotOrientation43 = xYPlot36.getOrientation();
//        org.jfree.chart.util.RectangleEdge rectangleEdge44 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation35, plotOrientation43);
//        boolean boolean45 = day11.equals((java.lang.Object) rectangleEdge44);
//        try {
//            double double46 = categoryAxis0.getCategorySeriesMiddle((java.lang.Comparable) numberTickUnit6, (java.lang.Comparable) 50.0d, categoryDataset8, 0.2d, rectangle2D10, rectangleEdge44);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(numberTickUnit6);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560452399999L + "'", long12 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(axisLocation35);
//        org.junit.Assert.assertNotNull(range39);
//        org.junit.Assert.assertNotNull(paint41);
//        org.junit.Assert.assertNotNull(rectangleEdge42);
//        org.junit.Assert.assertNotNull(plotOrientation43);
//        org.junit.Assert.assertNotNull(rectangleEdge44);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeZeroBaselineVisible(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder3 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot0.setRangeAxisLocation((int) (byte) 100, axisLocation5);
        xYPlot0.setRangeCrosshairVisible(false);
        boolean boolean9 = xYPlot0.isRangeZeroBaselineVisible();
        org.jfree.chart.plot.IntervalMarker intervalMarker12 = new org.jfree.chart.plot.IntervalMarker((double) 3, 100.0d);
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range16 = dateAxis15.getDefaultAutoRange();
        xYPlot13.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis15);
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot13.setRangeCrosshairStroke(stroke18);
        intervalMarker12.setStroke(stroke18);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder21 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean23 = datasetRenderingOrder21.equals((java.lang.Object) layer22);
        boolean boolean24 = xYPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker12, layer22);
        org.jfree.chart.axis.ValueAxis valueAxis26 = xYPlot0.getRangeAxis((int) (byte) 100);
        org.junit.Assert.assertNotNull(datasetRenderingOrder3);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(datasetRenderingOrder21);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(valueAxis26);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 3, 100.0d);
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range6 = dateAxis5.getDefaultAutoRange();
        xYPlot3.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis5);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot3.setRangeCrosshairStroke(stroke8);
        intervalMarker2.setStroke(stroke8);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.CENTER;
        intervalMarker2.setLabelAnchor(rectangleAnchor11);
        java.awt.Color color13 = java.awt.Color.red;
        intervalMarker2.setLabelPaint((java.awt.Paint) color13);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType15 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        intervalMarker2.setLabelOffsetType(lengthAdjustmentType15);
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range20 = dateAxis19.getDefaultAutoRange();
        xYPlot17.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis19);
        org.jfree.chart.plot.Marker marker22 = null;
        boolean boolean23 = xYPlot17.removeDomainMarker(marker22);
        xYPlot17.setDomainCrosshairValue((double) (-1), true);
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean29 = dateAxis28.isNegativeArrowVisible();
        dateAxis28.setAutoRangeMinimumSize((double) (short) 1, true);
        org.jfree.chart.axis.Timeline timeline33 = null;
        dateAxis28.setTimeline(timeline33);
        boolean boolean35 = xYPlot17.equals((java.lang.Object) dateAxis28);
        boolean boolean36 = lengthAdjustmentType15.equals((java.lang.Object) dateAxis28);
        java.lang.Object obj37 = dateAxis28.clone();
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        org.jfree.chart.axis.NumberAxis numberAxis41 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        java.awt.Stroke stroke42 = numberAxis41.getTickMarkStroke();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit43 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis41.setTickUnit(numberTickUnit43);
        numberAxis39.setTickUnit(numberTickUnit43);
        org.jfree.chart.axis.NumberAxis numberAxis47 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        org.jfree.chart.axis.NumberAxis numberAxis49 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        java.awt.Stroke stroke50 = numberAxis49.getTickMarkStroke();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit51 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis49.setTickUnit(numberTickUnit51);
        numberAxis47.setTickUnit(numberTickUnit51);
        numberAxis39.setTickUnit(numberTickUnit51);
        org.jfree.chart.axis.DateAxis dateAxis55 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape56 = dateAxis55.getLeftArrow();
        org.jfree.data.category.CategoryDataset categoryDataset57 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis58 = null;
        org.jfree.chart.axis.DateAxis dateAxis60 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean61 = dateAxis60.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer62 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot63 = new org.jfree.chart.plot.CategoryPlot(categoryDataset57, categoryAxis58, (org.jfree.chart.axis.ValueAxis) dateAxis60, categoryItemRenderer62);
        dateAxis60.resizeRange((double) 100.0f);
        java.awt.Shape shape66 = dateAxis60.getDownArrow();
        dateAxis55.setDownArrow(shape66);
        numberAxis39.setDownArrow(shape66);
        dateAxis28.setRightArrow(shape66);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(lengthAdjustmentType15);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(obj37);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(numberTickUnit43);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(numberTickUnit51);
        org.junit.Assert.assertNotNull(shape56);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(shape66);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        int int3 = java.awt.Color.HSBtoRGB((float) 1560452399999L, (float) 128, (float) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-9) + "'", int3 == (-9));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        xYPlot0.setDataset(xYDataset5);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        xYPlot0.setDomainTickBandPaint((java.awt.Paint) color7);
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot0.getRangeAxis();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range13 = dateAxis12.getDefaultAutoRange();
        java.awt.Paint paint14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        dateAxis12.setAxisLinePaint(paint14);
        dateAxis12.setAutoRange(true);
        xYPlot0.setDomainAxis(192, (org.jfree.chart.axis.ValueAxis) dateAxis12);
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        xYPlot0.drawAnnotations(graphics2D19, rectangle2D20, plotRenderingInfo21);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNotNull(paint14);
    }

//    @Test
//    public void test325() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test325");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getMiddleMillisecond();
//        int int2 = day0.getDayOfMonth();
//        int int3 = day0.getYear();
//        int int4 = day0.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560452399999L + "'", long1 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 13 + "'", int4 == 13);
//    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot6.getDrawingSupplier();
        categoryPlot6.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot6.getDomainAxisEdge(10);
        boolean boolean12 = categoryPlot6.isRangeZoomable();
        java.awt.Paint paint13 = categoryPlot6.getDomainGridlinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = categoryPlot6.getDomainAxis();
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range18 = dateAxis17.getDefaultAutoRange();
        xYPlot15.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis17);
        java.awt.Paint paint20 = xYPlot15.getOutlinePaint();
        xYPlot15.setRangeCrosshairValue(1.0E-8d);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        xYPlot15.setAxisOffset(rectangleInsets23);
        org.jfree.chart.util.UnitType unitType25 = rectangleInsets23.getUnitType();
        categoryPlot6.setAxisOffset(rectangleInsets23);
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = null;
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean31 = dateAxis30.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer32 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis28, (org.jfree.chart.axis.ValueAxis) dateAxis30, categoryItemRenderer32);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = dateAxis30.getTickLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis();
        java.awt.Color color36 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        dateAxis35.setTickLabelPaint((java.awt.Paint) color36);
        boolean boolean38 = rectangleInsets34.equals((java.lang.Object) dateAxis35);
        org.jfree.data.general.Dataset dataset39 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent40 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) dateAxis35, dataset39);
        org.jfree.data.general.Dataset dataset41 = datasetChangeEvent40.getDataset();
        categoryPlot6.datasetChanged(datasetChangeEvent40);
        java.lang.String str43 = datasetChangeEvent40.toString();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(categoryAxis14);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(unitType25);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(dataset41);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 0.0f, (float) 2);
        java.awt.Color color6 = java.awt.Color.getColor("ChartChangeEventType.DATASET_UPDATED", color5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Paint paint8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker((double) 15, (java.awt.Paint) color5, stroke7, paint8, stroke9, 0.0f);
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker((double) 11);
        java.awt.Paint paint14 = valueMarker13.getPaint();
        valueMarker13.setValue(8.0d);
        org.jfree.chart.plot.IntervalMarker intervalMarker19 = new org.jfree.chart.plot.IntervalMarker((double) 3, 100.0d);
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range23 = dateAxis22.getDefaultAutoRange();
        xYPlot20.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis22);
        java.awt.Stroke stroke25 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot20.setRangeCrosshairStroke(stroke25);
        intervalMarker19.setStroke(stroke25);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor28 = org.jfree.chart.util.RectangleAnchor.CENTER;
        intervalMarker19.setLabelAnchor(rectangleAnchor28);
        valueMarker13.setLabelAnchor(rectangleAnchor28);
        valueMarker11.setLabelAnchor(rectangleAnchor28);
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean36 = dateAxis35.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, (org.jfree.chart.axis.ValueAxis) dateAxis35, categoryItemRenderer37);
        boolean boolean39 = categoryPlot38.isOutlineVisible();
        java.awt.Paint paint40 = categoryPlot38.getDomainGridlinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = categoryPlot38.getDomainAxisForDataset((int) (short) 0);
        java.awt.Font font43 = categoryPlot38.getNoDataMessageFont();
        java.util.List list44 = categoryPlot38.getAnnotations();
        boolean boolean45 = valueMarker11.equals((java.lang.Object) categoryPlot38);
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = categoryPlot38.getRangeAxisEdge();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(rectangleAnchor28);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNull(categoryAxis42);
        org.junit.Assert.assertNotNull(font43);
        org.junit.Assert.assertNotNull(list44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(rectangleEdge46);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        xYPlot0.setDataset(xYDataset5);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        xYPlot0.setDomainTickBandPaint((java.awt.Paint) color7);
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot0.getRangeAxis();
        boolean boolean10 = xYPlot0.isRangeCrosshairLockedOnData();
        java.lang.String str11 = xYPlot0.getNoDataMessage();
        xYPlot0.setDomainGridlinesVisible(true);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(str11);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        org.jfree.chart.plot.Marker marker5 = null;
        boolean boolean6 = xYPlot0.removeDomainMarker(marker5);
        xYPlot0.setDomainCrosshairValue((double) (-1), true);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean12 = dateAxis11.isNegativeArrowVisible();
        dateAxis11.setAutoRangeMinimumSize((double) (short) 1, true);
        org.jfree.chart.axis.Timeline timeline16 = null;
        dateAxis11.setTimeline(timeline16);
        boolean boolean18 = xYPlot0.equals((java.lang.Object) dateAxis11);
        boolean boolean19 = dateAxis11.isTickLabelsVisible();
        double double20 = dateAxis11.getUpperBound();
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean23 = dateAxis22.isNegativeArrowVisible();
        dateAxis22.setAutoRangeMinimumSize((double) (short) 1, true);
        org.jfree.chart.axis.Timeline timeline27 = null;
        dateAxis22.setTimeline(timeline27);
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean31 = dateAxis30.isTickLabelsVisible();
        org.jfree.data.time.DateRange dateRange32 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis30.setRange((org.jfree.data.Range) dateRange32);
        dateAxis22.setDefaultAutoRange((org.jfree.data.Range) dateRange32);
        dateAxis11.setRangeWithMargins((org.jfree.data.Range) dateRange32, false, false);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(dateRange32);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        org.jfree.chart.plot.Marker marker5 = null;
        boolean boolean6 = xYPlot0.removeDomainMarker(marker5);
        xYPlot0.setDomainCrosshairValue((double) (-1), true);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean12 = dateAxis11.isNegativeArrowVisible();
        dateAxis11.setAutoRangeMinimumSize((double) (short) 1, true);
        org.jfree.chart.axis.Timeline timeline16 = null;
        dateAxis11.setTimeline(timeline16);
        boolean boolean18 = xYPlot0.equals((java.lang.Object) dateAxis11);
        dateAxis11.setTickMarksVisible(false);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

//    @Test
//    public void test331() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test331");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getMiddleMillisecond();
//        int int2 = day0.getMonth();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560452399999L + "'", long1 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.ASCENDING;
        org.junit.Assert.assertNotNull(sortOrder0);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot6.getDrawingSupplier();
        categoryPlot6.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot6.getDomainAxisEdge(10);
        boolean boolean12 = categoryPlot6.isRangeZoomable();
        categoryPlot6.setOutlineVisible(true);
        categoryPlot6.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation17 = null;
        try {
            categoryPlot6.addAnnotation(categoryAnnotation17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean2 = dateAxis1.isTickLabelsVisible();
        org.jfree.data.time.DateRange dateRange3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis1.setRange((org.jfree.data.Range) dateRange3);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition5 = null;
        try {
            dateAxis1.setTickMarkPosition(dateTickMarkPosition5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(dateRange3);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        java.awt.Stroke stroke2 = numberAxis1.getTickMarkStroke();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis1.setTickUnit(numberTickUnit3);
        boolean boolean5 = numberAxis1.isAutoTickUnitSelection();
        numberAxis1.setTickMarkOutsideLength((float) (short) 100);
        numberAxis1.setRangeAboutValue((double) 100L, (double) 6);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(numberTickUnit3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        java.awt.Color color0 = java.awt.Color.BLACK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("SeriesRenderingOrder.FORWARD");
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean6 = dateAxis5.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer7);
        boolean boolean9 = categoryPlot8.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier10 = categoryPlot8.getDrawingSupplier();
        categoryPlot8.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = categoryPlot8.getDomainAxisEdge(10);
        boolean boolean14 = categoryPlot8.isRangeZoomable();
        java.awt.Paint paint15 = categoryPlot8.getDomainGridlinePaint();
        boolean boolean16 = categoryPlot8.isDomainGridlinesVisible();
        boolean boolean17 = categoryAxis1.equals((java.lang.Object) boolean16);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(drawingSupplier10);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor(0, (int) (short) 10, 0);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        java.awt.Paint paint5 = xYPlot0.getOutlinePaint();
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        xYPlot7.setRangeZeroBaselineVisible(false);
        boolean boolean10 = xYPlot7.isOutlineVisible();
        xYPlot7.clearRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot7.setDomainAxisLocation(64, axisLocation13);
        xYPlot0.setDomainAxisLocation(2, axisLocation13);
        org.jfree.chart.axis.AxisLocation axisLocation16 = xYPlot0.getDomainAxisLocation();
        xYPlot0.zoom((double) 100.0f);
        java.awt.Paint paint19 = xYPlot0.getDomainZeroBaselinePaint();
        double double20 = xYPlot0.getDomainCrosshairValue();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
    }

//    @Test
//    public void test340() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test340");
//        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
//        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) 3.0d, "ChartChangeEventType.DATASET_UPDATED");
//        categoryAxis0.setMaximumCategoryLabelLines((int) ' ');
//        java.awt.geom.Rectangle2D rectangle2D8 = null;
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        long long10 = day9.getMiddleMillisecond();
//        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
//        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("hi!");
//        boolean boolean15 = dateAxis14.isNegativeArrowVisible();
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis14, categoryItemRenderer16);
//        boolean boolean18 = categoryPlot17.isOutlineVisible();
//        categoryPlot17.mapDatasetToDomainAxis(100, (int) 'a');
//        int int22 = day9.compareTo((java.lang.Object) 100);
//        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
//        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
//        boolean boolean27 = dateAxis26.isNegativeArrowVisible();
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, (org.jfree.chart.axis.ValueAxis) dateAxis26, categoryItemRenderer28);
//        categoryPlot29.clearRangeMarkers(0);
//        org.jfree.chart.axis.AxisLocation axisLocation33 = categoryPlot29.getRangeAxisLocation(10);
//        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot();
//        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis("hi!");
//        org.jfree.data.Range range37 = dateAxis36.getDefaultAutoRange();
//        xYPlot34.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis36);
//        java.awt.Paint paint39 = xYPlot34.getOutlinePaint();
//        org.jfree.chart.util.RectangleEdge rectangleEdge40 = xYPlot34.getRangeAxisEdge();
//        org.jfree.chart.plot.PlotOrientation plotOrientation41 = xYPlot34.getOrientation();
//        org.jfree.chart.util.RectangleEdge rectangleEdge42 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation33, plotOrientation41);
//        boolean boolean43 = day9.equals((java.lang.Object) rectangleEdge42);
//        try {
//            double double44 = categoryAxis0.getCategoryMiddle(8, (int) (short) 100, rectangle2D8, rectangleEdge42);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560452399999L + "'", long10 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertNotNull(axisLocation33);
//        org.junit.Assert.assertNotNull(range37);
//        org.junit.Assert.assertNotNull(paint39);
//        org.junit.Assert.assertNotNull(rectangleEdge40);
//        org.junit.Assert.assertNotNull(plotOrientation41);
//        org.junit.Assert.assertNotNull(rectangleEdge42);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot6.getDrawingSupplier();
        categoryPlot6.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot6.getDomainAxisEdge(10);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = categoryPlot6.getDomainAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = categoryPlot6.getDomainAxis();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNull(categoryAxis12);
        org.junit.Assert.assertNull(categoryAxis13);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        org.jfree.chart.plot.Marker marker5 = null;
        boolean boolean6 = xYPlot0.removeDomainMarker(marker5);
        xYPlot0.setDomainCrosshairValue((double) (-1), true);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean12 = dateAxis11.isNegativeArrowVisible();
        dateAxis11.setAutoRangeMinimumSize((double) (short) 1, true);
        org.jfree.chart.axis.Timeline timeline16 = null;
        dateAxis11.setTimeline(timeline16);
        boolean boolean18 = xYPlot0.equals((java.lang.Object) dateAxis11);
        org.jfree.data.Range range19 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis11.setRange(range19, true, false);
        java.awt.Stroke stroke23 = dateAxis11.getAxisLineStroke();
        double double24 = dateAxis11.getLowerBound();
        java.awt.Shape shape25 = dateAxis11.getUpArrow();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(shape25);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        categoryPlot6.clearRangeMarkers(0);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = null;
        categoryPlot6.markerChanged(markerChangeEvent9);
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range14 = dateAxis13.getDefaultAutoRange();
        xYPlot11.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis13);
        java.awt.Paint paint16 = xYPlot11.getOutlinePaint();
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        xYPlot18.setRangeZeroBaselineVisible(false);
        boolean boolean21 = xYPlot18.isOutlineVisible();
        xYPlot18.clearRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation24 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot18.setDomainAxisLocation(64, axisLocation24);
        xYPlot11.setDomainAxisLocation(2, axisLocation24);
        xYPlot11.setRangeCrosshairValue((double) (short) 10);
        org.jfree.chart.plot.IntervalMarker intervalMarker32 = new org.jfree.chart.plot.IntervalMarker((double) 3, 100.0d);
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range36 = dateAxis35.getDefaultAutoRange();
        xYPlot33.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis35);
        java.awt.Stroke stroke38 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot33.setRangeCrosshairStroke(stroke38);
        intervalMarker32.setStroke(stroke38);
        java.awt.Color color41 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        intervalMarker32.setOutlinePaint((java.awt.Paint) color41);
        double double43 = intervalMarker32.getEndValue();
        org.jfree.chart.util.Layer layer44 = null;
        boolean boolean45 = xYPlot11.removeRangeMarker(2, (org.jfree.chart.plot.Marker) intervalMarker32, layer44);
        org.jfree.chart.util.Layer layer46 = null;
        boolean boolean47 = categoryPlot6.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker32, layer46);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertNotNull(range36);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 100.0d + "'", double43 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot6.getDrawingSupplier();
        categoryPlot6.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot6.getDomainAxisEdge(10);
        boolean boolean12 = categoryPlot6.isRangeZoomable();
        java.awt.Paint paint13 = categoryPlot6.getDomainGridlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot6.setDomainAxisLocation(64, axisLocation15, false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder18 = categoryPlot6.getDatasetRenderingOrder();
        categoryPlot6.setRangeCrosshairValue((double) (-1));
        categoryPlot6.clearRangeMarkers(0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(datasetRenderingOrder18);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        xYPlot0.setDataset(xYDataset5);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        xYPlot0.setDomainTickBandPaint((java.awt.Paint) color7);
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot0.getRangeAxis();
        boolean boolean10 = xYPlot0.isRangeCrosshairLockedOnData();
        boolean boolean11 = xYPlot0.isRangeGridlinesVisible();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean2 = dateAxis1.isNegativeArrowVisible();
        dateAxis1.setAutoRangeMinimumSize((double) (short) 1, true);
        org.jfree.chart.axis.Timeline timeline6 = null;
        dateAxis1.setTimeline(timeline6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean12 = dateAxis11.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis11, categoryItemRenderer13);
        boolean boolean15 = categoryPlot14.isOutlineVisible();
        java.awt.Paint paint16 = categoryPlot14.getDomainGridlinePaint();
        java.lang.String str17 = categoryPlot14.getNoDataMessage();
        dateAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot14);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = categoryPlot14.getDomainAxisEdge((int) '#');
        java.awt.Graphics2D graphics2D21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        try {
            categoryPlot14.drawBackground(graphics2D21, rectangle2D22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(rectangleEdge20);
    }

//    @Test
//    public void test347() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test347");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getMiddleMillisecond();
//        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
//        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("hi!");
//        boolean boolean6 = dateAxis5.isNegativeArrowVisible();
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer7);
//        boolean boolean9 = categoryPlot8.isOutlineVisible();
//        categoryPlot8.mapDatasetToDomainAxis(100, (int) 'a');
//        int int13 = day0.compareTo((java.lang.Object) 100);
//        java.util.Calendar calendar14 = null;
//        try {
//            long long15 = day0.getFirstMillisecond(calendar14);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560452399999L + "'", long1 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean2 = dateAxis1.isNegativeArrowVisible();
        double double3 = dateAxis1.getLowerBound();
        java.awt.Paint paint4 = dateAxis1.getTickLabelPaint();
        java.awt.Stroke stroke5 = dateAxis1.getAxisLineStroke();
        dateAxis1.configure();
        org.jfree.data.Range range7 = dateAxis1.getDefaultAutoRange();
        boolean boolean8 = dateAxis1.isTickLabelsVisible();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Paint[] paintArray3 = new java.awt.Paint[] { color1, color2 };
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Paint paint5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Paint paint7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        java.awt.Paint[] paintArray8 = new java.awt.Paint[] { color4, paint5, color6, paint7 };
        java.awt.Stroke stroke9 = null;
        java.awt.Stroke[] strokeArray10 = new java.awt.Stroke[] { stroke9 };
        java.awt.Stroke[] strokeArray11 = null;
        java.awt.Shape[] shapeArray12 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier13 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray3, paintArray8, strokeArray10, strokeArray11, shapeArray12);
        java.awt.Paint paint14 = defaultDrawingSupplier13.getNextFillPaint();
        java.awt.Paint paint15 = defaultDrawingSupplier13.getNextPaint();
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paintArray3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paintArray8);
        org.junit.Assert.assertNotNull(strokeArray10);
        org.junit.Assert.assertNotNull(shapeArray12);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeZeroBaselineVisible(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder3 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot0.setRangeAxisLocation((int) (byte) 100, axisLocation5);
        boolean boolean7 = xYPlot0.isDomainGridlinesVisible();
        xYPlot0.setOutlineVisible(true);
        org.jfree.chart.util.Layer layer11 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection12 = xYPlot0.getRangeMarkers(11, layer11);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation13 = null;
        try {
            boolean boolean14 = xYPlot0.removeAnnotation(xYAnnotation13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(datasetRenderingOrder3);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(layer11);
        org.junit.Assert.assertNull(collection12);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot6.getDrawingSupplier();
        categoryPlot6.clearRangeAxes();
        categoryPlot6.setBackgroundAlpha((float) 10L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        categoryPlot6.setRenderer(0, categoryItemRenderer13);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(drawingSupplier8);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        java.awt.Paint paint5 = xYPlot0.getOutlinePaint();
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        xYPlot7.setRangeZeroBaselineVisible(false);
        boolean boolean10 = xYPlot7.isOutlineVisible();
        xYPlot7.clearRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot7.setDomainAxisLocation(64, axisLocation13);
        xYPlot0.setDomainAxisLocation(2, axisLocation13);
        org.jfree.chart.axis.AxisLocation axisLocation16 = xYPlot0.getDomainAxisLocation();
        xYPlot0.zoom((double) 100.0f);
        java.awt.Paint paint19 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        xYPlot0.setDataset(xYDataset20);
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        xYPlot0.setDomainAxis(valueAxis22);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeZeroBaselineVisible(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder3 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot0.setRangeAxisLocation((int) (byte) 100, axisLocation5);
        java.awt.Stroke stroke7 = xYPlot0.getDomainCrosshairStroke();
        java.awt.Paint paint8 = xYPlot0.getBackgroundPaint();
        org.junit.Assert.assertNotNull(datasetRenderingOrder3);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeZeroBaselineVisible(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder3 = xYPlot0.getDatasetRenderingOrder();
        xYPlot0.setDomainCrosshairLockedOnData(false);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        try {
            xYPlot0.drawOutline(graphics2D6, rectangle2D7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(datasetRenderingOrder3);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        java.awt.Paint paint5 = xYPlot0.getOutlinePaint();
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        xYPlot7.setRangeZeroBaselineVisible(false);
        boolean boolean10 = xYPlot7.isOutlineVisible();
        xYPlot7.clearRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot7.setDomainAxisLocation(64, axisLocation13);
        xYPlot0.setDomainAxisLocation(2, axisLocation13);
        java.lang.String str16 = axisLocation13.toString();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str16.equals("AxisLocation.BOTTOM_OR_RIGHT"));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        org.jfree.chart.plot.Marker marker5 = null;
        boolean boolean6 = xYPlot0.removeDomainMarker(marker5);
        xYPlot0.setDomainCrosshairValue((double) (-1), true);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean12 = dateAxis11.isNegativeArrowVisible();
        dateAxis11.setAutoRangeMinimumSize((double) (short) 1, true);
        org.jfree.chart.axis.Timeline timeline16 = null;
        dateAxis11.setTimeline(timeline16);
        boolean boolean18 = xYPlot0.equals((java.lang.Object) dateAxis11);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition19 = null;
        try {
            dateAxis11.setTickMarkPosition(dateTickMarkPosition19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        java.awt.Paint paint7 = categoryPlot6.getDomainGridlinePaint();
        java.lang.Object obj8 = categoryPlot6.clone();
        boolean boolean9 = categoryPlot6.isRangeZoomable();
        double double10 = categoryPlot6.getAnchorValue();
        java.awt.Paint paint11 = categoryPlot6.getRangeGridlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean14 = dateAxis13.isNegativeArrowVisible();
        double double15 = dateAxis13.getLowerBound();
        java.awt.Paint paint16 = dateAxis13.getTickLabelPaint();
        java.awt.Stroke stroke17 = dateAxis13.getAxisLineStroke();
        categoryPlot6.setRangeGridlineStroke(stroke17);
        categoryPlot6.setDomainGridlinesVisible(true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        java.awt.Paint paint8 = categoryPlot6.getDomainGridlinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot6.getDomainAxisForDataset((int) (short) 0);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean15 = dateAxis14.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis14, categoryItemRenderer16);
        org.jfree.data.Range range18 = dateAxis14.getRange();
        int int19 = categoryPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis14);
        dateAxis14.setRangeAboutValue((double) 100L, (double) 10);
        boolean boolean24 = dateAxis14.isHiddenValue((long) 15);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = null;
        try {
            categoryAxis0.setCategoryLabelPositions(categoryLabelPositions1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'positions' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        java.awt.Color color0 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel1 = null;
        java.awt.Rectangle rectangle2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.AffineTransform affineTransform4 = null;
        java.awt.RenderingHints renderingHints5 = null;
        java.awt.PaintContext paintContext6 = color0.createContext(colorModel1, rectangle2, rectangle2D3, affineTransform4, renderingHints5);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paintContext6);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeZeroBaselineVisible(false);
        boolean boolean3 = xYPlot0.isOutlineVisible();
        xYPlot0.clearRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation6 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot0.setDomainAxisLocation(64, axisLocation6);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean10 = dateAxis9.isNegativeArrowVisible();
        double double11 = dateAxis9.getLowerBound();
        java.awt.Paint paint12 = dateAxis9.getTickLabelPaint();
        java.awt.Stroke stroke13 = dateAxis9.getAxisLineStroke();
        xYPlot0.setDomainGridlineStroke(stroke13);
        org.jfree.chart.plot.IntervalMarker intervalMarker17 = new org.jfree.chart.plot.IntervalMarker((double) 3, 100.0d);
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range21 = dateAxis20.getDefaultAutoRange();
        xYPlot18.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis20);
        java.awt.Stroke stroke23 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot18.setRangeCrosshairStroke(stroke23);
        intervalMarker17.setStroke(stroke23);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = org.jfree.chart.util.RectangleAnchor.CENTER;
        intervalMarker17.setLabelAnchor(rectangleAnchor26);
        java.awt.Color color28 = java.awt.Color.red;
        intervalMarker17.setLabelPaint((java.awt.Paint) color28);
        boolean boolean30 = xYPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker17);
        try {
            java.awt.Paint paint32 = xYPlot0.getQuadrantPaint((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (35) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(rectangleAnchor26);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 11);
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range5 = dateAxis4.getDefaultAutoRange();
        xYPlot2.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis4);
        java.awt.Paint paint7 = xYPlot2.getOutlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        xYPlot2.zoomRangeAxes((double) (byte) 100, plotRenderingInfo9, point2D10, false);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean17 = dateAxis16.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis16, categoryItemRenderer18);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = dateAxis16.getTickLabelInsets();
        xYPlot2.setInsets(rectangleInsets20, false);
        boolean boolean23 = valueMarker1.equals((java.lang.Object) rectangleInsets20);
        org.jfree.chart.JFreeChart jFreeChart24 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent25 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) valueMarker1, jFreeChart24);
        org.jfree.chart.text.TextAnchor textAnchor26 = org.jfree.chart.text.TextAnchor.CENTER;
        valueMarker1.setLabelTextAnchor(textAnchor26);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(textAnchor26);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        java.awt.Stroke stroke4 = numberAxis3.getTickMarkStroke();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis3.setTickUnit(numberTickUnit5);
        numberAxis1.setTickUnit(numberTickUnit5, false, false);
        org.jfree.data.RangeType rangeType10 = numberAxis1.getRangeType();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(numberTickUnit5);
        org.junit.Assert.assertNotNull(rangeType10);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeZeroBaselineVisible(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder3 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot0.setRangeAxisLocation((int) (byte) 100, axisLocation5);
        boolean boolean7 = xYPlot0.isDomainGridlinesVisible();
        xYPlot0.setOutlineVisible(true);
        org.jfree.chart.util.Layer layer11 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection12 = xYPlot0.getRangeMarkers(11, layer11);
        java.awt.Stroke stroke13 = xYPlot0.getDomainGridlineStroke();
        org.junit.Assert.assertNotNull(datasetRenderingOrder3);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(layer11);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        xYPlot0.setDataset(xYDataset5);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range10 = dateAxis9.getDefaultAutoRange();
        java.awt.Paint paint11 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        dateAxis9.setAxisLinePaint(paint11);
        dateAxis9.setUpperBound(6.0d);
        xYPlot0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis9, false);
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        org.jfree.chart.plot.CrosshairState crosshairState21 = null;
        boolean boolean22 = xYPlot0.render(graphics2D17, rectangle2D18, (int) 'a', plotRenderingInfo20, crosshairState21);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairVisible();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor8 = categoryPlot6.getDomainGridlinePosition();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(categoryAnchor8);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 3, 100.0d);
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range6 = dateAxis5.getDefaultAutoRange();
        xYPlot3.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis5);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot3.setRangeCrosshairStroke(stroke8);
        intervalMarker2.setStroke(stroke8);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.CENTER;
        intervalMarker2.setLabelAnchor(rectangleAnchor11);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean15 = dateAxis14.isNegativeArrowVisible();
        double double16 = dateAxis14.getLowerBound();
        java.awt.Paint paint17 = dateAxis14.getTickLabelPaint();
        java.awt.Stroke stroke18 = dateAxis14.getAxisLineStroke();
        intervalMarker2.setStroke(stroke18);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent20 = null;
        intervalMarker2.notifyListeners(markerChangeEvent20);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = intervalMarker2.getLabelOffset();
        float float23 = intervalMarker2.getAlpha();
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 0.8f + "'", float23 == 0.8f);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        xYPlot0.setDataset(xYDataset5);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        xYPlot0.setDomainTickBandPaint((java.awt.Paint) color7);
        float[] floatArray11 = new float[] { 15, 255 };
        try {
            float[] floatArray12 = color7.getColorComponents(floatArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(floatArray11);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeZeroBaselineVisible(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        xYPlot0.zoomRangeAxes(0.0d, (double) 11, plotRenderingInfo5, point2D6);
        java.awt.Paint paint8 = xYPlot0.getRangeGridlinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = null;
        try {
            xYPlot0.setInsets(rectangleInsets9, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range2 = dateAxis1.getDefaultAutoRange();
        java.util.Date date3 = dateAxis1.getMinimumDate();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        categoryPlot6.clearRangeMarkers(0);
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot6.getRangeAxisLocation(10);
        java.awt.Stroke stroke11 = categoryPlot6.getRangeCrosshairStroke();
        org.jfree.chart.axis.AxisSpace axisSpace12 = null;
        categoryPlot6.setFixedDomainAxisSpace(axisSpace12);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getMaximumCategoryLabelLines();
        categoryAxis0.setTickLabelsVisible(false);
        categoryAxis0.setAxisLineVisible(false);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot6.getDrawingSupplier();
        categoryPlot6.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot6.getDomainAxisEdge(10);
        boolean boolean12 = categoryPlot6.isRangeZoomable();
        java.awt.Paint paint13 = categoryPlot6.getDomainGridlinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = categoryPlot6.getDomainAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        try {
            int int16 = categoryPlot6.getDomainAxisIndex(categoryAxis15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(categoryAxis14);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot6.getDrawingSupplier();
        java.lang.Object obj9 = null;
        boolean boolean10 = categoryPlot6.equals(obj9);
        categoryPlot6.clearRangeMarkers(3);
        categoryPlot6.configureDomainAxes();
        boolean boolean14 = categoryPlot6.isRangeGridlinesVisible();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 3, 100.0d);
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range6 = dateAxis5.getDefaultAutoRange();
        xYPlot3.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis5);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot3.setRangeCrosshairStroke(stroke8);
        intervalMarker2.setStroke(stroke8);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.CENTER;
        intervalMarker2.setLabelAnchor(rectangleAnchor11);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean15 = dateAxis14.isNegativeArrowVisible();
        double double16 = dateAxis14.getLowerBound();
        java.awt.Paint paint17 = dateAxis14.getTickLabelPaint();
        java.awt.Stroke stroke18 = dateAxis14.getAxisLineStroke();
        intervalMarker2.setStroke(stroke18);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent20 = null;
        intervalMarker2.notifyListeners(markerChangeEvent20);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = intervalMarker2.getLabelOffset();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer23 = intervalMarker2.getGradientPaintTransformer();
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNull(gradientPaintTransformer23);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeZeroBaselineVisible(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder3 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot0.setRangeAxisLocation((int) (byte) 100, axisLocation5);
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean11 = dateAxis10.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis10, categoryItemRenderer12);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = dateAxis10.getTickLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        dateAxis15.setTickLabelPaint((java.awt.Paint) color16);
        boolean boolean18 = rectangleInsets14.equals((java.lang.Object) dateAxis15);
        java.lang.String str19 = rectangleInsets14.toString();
        org.jfree.chart.util.UnitType unitType20 = rectangleInsets14.getUnitType();
        double double21 = rectangleInsets14.getBottom();
        double double23 = rectangleInsets14.calculateRightInset(0.0d);
        double double24 = rectangleInsets14.getRight();
        xYPlot0.setAxisOffset(rectangleInsets14);
        java.awt.Stroke stroke26 = xYPlot0.getRangeZeroBaselineStroke();
        java.awt.Paint paint28 = xYPlot0.getQuadrantPaint(3);
        org.junit.Assert.assertNotNull(datasetRenderingOrder3);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str19.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
        org.junit.Assert.assertNotNull(unitType20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 2.0d + "'", double21 == 2.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 4.0d + "'", double23 == 4.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 4.0d + "'", double24 == 4.0d);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNull(paint28);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        java.awt.Paint paint5 = xYPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        xYPlot0.zoomDomainAxes((double) 128, plotRenderingInfo7, point2D8, false);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean15 = dateAxis14.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis14, categoryItemRenderer16);
        double double18 = dateAxis14.getUpperBound();
        int int19 = xYPlot0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis14);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        java.awt.Paint[] paintArray8 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Paint[] paintArray11 = new java.awt.Paint[] { color9, color10 };
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Paint paint13 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Paint paint15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        java.awt.Paint[] paintArray16 = new java.awt.Paint[] { color12, paint13, color14, paint15 };
        java.awt.Stroke stroke17 = null;
        java.awt.Stroke[] strokeArray18 = new java.awt.Stroke[] { stroke17 };
        java.awt.Stroke[] strokeArray19 = null;
        java.awt.Shape[] shapeArray20 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier21 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray8, paintArray11, paintArray16, strokeArray18, strokeArray19, shapeArray20);
        java.awt.Shape shape22 = defaultDrawingSupplier21.getNextShape();
        categoryPlot6.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier21);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paintArray8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paintArray11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(paintArray16);
        org.junit.Assert.assertNotNull(strokeArray18);
        org.junit.Assert.assertNotNull(shapeArray20);
        org.junit.Assert.assertNotNull(shape22);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeZeroBaselineVisible(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder3 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot0.setRangeAxisLocation((int) (byte) 100, axisLocation5);
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean11 = dateAxis10.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis10, categoryItemRenderer12);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = dateAxis10.getTickLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        dateAxis15.setTickLabelPaint((java.awt.Paint) color16);
        boolean boolean18 = rectangleInsets14.equals((java.lang.Object) dateAxis15);
        java.lang.String str19 = rectangleInsets14.toString();
        org.jfree.chart.util.UnitType unitType20 = rectangleInsets14.getUnitType();
        double double21 = rectangleInsets14.getBottom();
        double double23 = rectangleInsets14.calculateRightInset(0.0d);
        double double24 = rectangleInsets14.getRight();
        xYPlot0.setAxisOffset(rectangleInsets14);
        java.awt.Stroke stroke26 = xYPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder27 = xYPlot0.getSeriesRenderingOrder();
        org.junit.Assert.assertNotNull(datasetRenderingOrder3);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str19.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
        org.junit.Assert.assertNotNull(unitType20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 2.0d + "'", double21 == 2.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 4.0d + "'", double23 == 4.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 4.0d + "'", double24 == 4.0d);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(seriesRenderingOrder27);
    }

//    @Test
//    public void test381() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test381");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getMiddleMillisecond();
//        int int2 = day0.getDayOfMonth();
//        long long3 = day0.getFirstMillisecond();
//        long long4 = day0.getMiddleMillisecond();
//        java.util.Date date5 = day0.getEnd();
//        java.lang.Object obj6 = null;
//        int int7 = day0.compareTo(obj6);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560452399999L + "'", long1 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560452399999L + "'", long4 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        java.awt.Paint paint5 = xYPlot0.getOutlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        xYPlot0.zoomRangeAxes((double) (byte) 100, plotRenderingInfo7, point2D8, false);
        org.jfree.chart.plot.IntervalMarker intervalMarker14 = new org.jfree.chart.plot.IntervalMarker((double) 3, 100.0d);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean19 = dateAxis18.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, (org.jfree.chart.axis.ValueAxis) dateAxis18, categoryItemRenderer20);
        boolean boolean22 = categoryPlot21.isOutlineVisible();
        java.awt.Paint paint23 = categoryPlot21.getDomainGridlinePaint();
        java.lang.String str24 = categoryPlot21.getNoDataMessage();
        intervalMarker14.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot21);
        org.jfree.chart.util.Layer layer26 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addRangeMarker((int) (short) 1, (org.jfree.chart.plot.Marker) intervalMarker14, layer26);
        java.awt.Stroke stroke28 = xYPlot0.getOutlineStroke();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertNotNull(layer26);
        org.junit.Assert.assertNotNull(stroke28);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        xYPlot0.setDataset(xYDataset5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        xYPlot0.zoomRangeAxes(3.0d, (double) 11, plotRenderingInfo9, point2D10);
        org.junit.Assert.assertNotNull(range3);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        xYPlot0.setDataset(xYDataset5);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        xYPlot0.setDomainTickBandPaint((java.awt.Paint) color7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range12 = dateAxis11.getDefaultAutoRange();
        xYPlot9.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis11);
        java.awt.Paint paint14 = xYPlot9.getOutlinePaint();
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        xYPlot16.setRangeZeroBaselineVisible(false);
        boolean boolean19 = xYPlot16.isOutlineVisible();
        xYPlot16.clearRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation22 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot16.setDomainAxisLocation(64, axisLocation22);
        xYPlot9.setDomainAxisLocation(2, axisLocation22);
        boolean boolean25 = color7.equals((java.lang.Object) 2);
        java.lang.String str26 = color7.toString();
        int int27 = color7.getGreen();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "java.awt.Color[r=0,g=0,b=128]" + "'", str26.equals("java.awt.Color[r=0,g=0,b=128]"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        dateAxis3.centerRange((double) 1.0f);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape10 = dateAxis9.getLeftArrow();
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean15 = dateAxis14.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis14, categoryItemRenderer16);
        dateAxis14.resizeRange((double) 100.0f);
        java.awt.Shape shape20 = dateAxis14.getDownArrow();
        dateAxis9.setDownArrow(shape20);
        dateAxis3.setDownArrow(shape20);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(shape20);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot6.getDrawingSupplier();
        java.lang.Object obj9 = null;
        boolean boolean10 = categoryPlot6.equals(obj9);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        int int12 = categoryPlot6.getIndexOf(categoryItemRenderer11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot6.zoomRangeAxes((double) 10.0f, plotRenderingInfo14, point2D15);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean2 = dateAxis1.isNegativeArrowVisible();
        dateAxis1.setAutoRangeMinimumSize((double) (short) 1, true);
        org.jfree.data.Range range6 = dateAxis1.getDefaultAutoRange();
        org.jfree.chart.axis.DateTickUnit dateTickUnit7 = dateAxis1.getTickUnit();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(dateTickUnit7);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        java.awt.Paint paint5 = xYPlot0.getOutlinePaint();
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        xYPlot7.setRangeZeroBaselineVisible(false);
        boolean boolean10 = xYPlot7.isOutlineVisible();
        xYPlot7.clearRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot7.setDomainAxisLocation(64, axisLocation13);
        xYPlot0.setDomainAxisLocation(2, axisLocation13);
        org.jfree.chart.axis.AxisLocation axisLocation16 = xYPlot0.getDomainAxisLocation();
        xYPlot0.zoom((double) 100.0f);
        java.awt.Paint paint19 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        xYPlot0.setDataset(xYDataset20);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder22 = xYPlot0.getSeriesRenderingOrder();
        xYPlot0.setRangeGridlinesVisible(false);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(seriesRenderingOrder22);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean5 = dateAxis4.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        org.jfree.data.Range range8 = dateAxis4.getRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis4);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean12 = dateAxis11.isNegativeArrowVisible();
        double double13 = dateAxis11.getLowerBound();
        java.awt.Paint paint14 = dateAxis11.getTickLabelPaint();
        java.awt.Stroke stroke15 = dateAxis11.getAxisLineStroke();
        xYPlot0.setRangeZeroBaselineStroke(stroke15);
        xYPlot0.clearDomainAxes();
        xYPlot0.setRangeZeroBaselineVisible(true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot6.getDrawingSupplier();
        categoryPlot6.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot6.getDomainAxisEdge(10);
        boolean boolean12 = categoryPlot6.isRangeZoomable();
        double double13 = categoryPlot6.getRangeCrosshairValue();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setCategoryMargin((double) (short) 100);
        java.lang.Comparable comparable3 = null;
        try {
            java.awt.Font font4 = categoryAxis0.getTickLabelFont(comparable3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 3, 100.0d);
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range6 = dateAxis5.getDefaultAutoRange();
        xYPlot3.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis5);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot3.setRangeCrosshairStroke(stroke8);
        intervalMarker2.setStroke(stroke8);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.CENTER;
        intervalMarker2.setLabelAnchor(rectangleAnchor11);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean15 = dateAxis14.isNegativeArrowVisible();
        double double16 = dateAxis14.getLowerBound();
        java.awt.Paint paint17 = dateAxis14.getTickLabelPaint();
        java.awt.Stroke stroke18 = dateAxis14.getAxisLineStroke();
        intervalMarker2.setStroke(stroke18);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer20 = null;
        intervalMarker2.setGradientPaintTransformer(gradientPaintTransformer20);
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean26 = dateAxis25.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis23, (org.jfree.chart.axis.ValueAxis) dateAxis25, categoryItemRenderer27);
        boolean boolean29 = categoryPlot28.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier30 = categoryPlot28.getDrawingSupplier();
        categoryPlot28.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = categoryPlot28.getDomainAxisEdge(10);
        org.jfree.data.category.CategoryDataset categoryDataset34 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = null;
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean38 = dateAxis37.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset34, categoryAxis35, (org.jfree.chart.axis.ValueAxis) dateAxis37, categoryItemRenderer39);
        dateAxis37.resizeRange((double) 100.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = dateAxis37.getLabelInsets();
        int int44 = categoryPlot28.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis37);
        intervalMarker2.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot28);
        try {
            categoryPlot28.setBackgroundImageAlpha((float) 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(drawingSupplier30);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        java.awt.Paint paint5 = xYPlot0.getOutlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        xYPlot0.zoomRangeAxes((double) (byte) 100, plotRenderingInfo7, point2D8, false);
        java.awt.Stroke stroke11 = xYPlot0.getRangeGridlineStroke();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.ValueAxis valueAxis14 = xYPlot0.getRangeAxis((int) ' ');
        xYPlot0.setDomainZeroBaselineVisible(false);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNull(valueAxis14);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 3, 100.0d);
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range6 = dateAxis5.getDefaultAutoRange();
        xYPlot3.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis5);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot3.setRangeCrosshairStroke(stroke8);
        intervalMarker2.setStroke(stroke8);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.CENTER;
        intervalMarker2.setLabelAnchor(rectangleAnchor11);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean15 = dateAxis14.isNegativeArrowVisible();
        double double16 = dateAxis14.getLowerBound();
        java.awt.Paint paint17 = dateAxis14.getTickLabelPaint();
        java.awt.Stroke stroke18 = dateAxis14.getAxisLineStroke();
        intervalMarker2.setStroke(stroke18);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent20 = null;
        intervalMarker2.notifyListeners(markerChangeEvent20);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = intervalMarker2.getLabelOffset();
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean27 = dateAxis26.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, (org.jfree.chart.axis.ValueAxis) dateAxis26, categoryItemRenderer28);
        boolean boolean30 = categoryPlot29.isOutlineVisible();
        categoryPlot29.mapDatasetToDomainAxis(100, (int) 'a');
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        categoryPlot29.setRenderer(255, categoryItemRenderer35, false);
        double double38 = categoryPlot29.getRangeCrosshairValue();
        java.awt.Paint paint39 = categoryPlot29.getOutlinePaint();
        intervalMarker2.setPaint(paint39);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(paint39);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        dateAxis3.resizeRange((double) 100.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = dateAxis3.getLabelInsets();
        java.lang.Object obj10 = null;
        boolean boolean11 = rectangleInsets9.equals(obj10);
        double double13 = rectangleInsets9.trimHeight(0.0d);
        double double15 = rectangleInsets9.calculateRightOutset((double) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-6.0d) + "'", double13 == (-6.0d));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 3.0d + "'", double15 == 3.0d);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean2 = dateAxis1.isTickLabelsVisible();
        org.jfree.data.time.DateRange dateRange3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis1.setRange((org.jfree.data.Range) dateRange3);
        java.awt.Paint paint5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        dateAxis1.setLabelPaint(paint5);
        org.jfree.chart.JFreeChart jFreeChart7 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType8 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent9 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) paint5, jFreeChart7, chartChangeEventType8);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(dateRange3);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 3, 100.0d);
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range6 = dateAxis5.getDefaultAutoRange();
        xYPlot3.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis5);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot3.setRangeCrosshairStroke(stroke8);
        intervalMarker2.setStroke(stroke8);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.CENTER;
        intervalMarker2.setLabelAnchor(rectangleAnchor11);
        java.awt.Color color13 = java.awt.Color.red;
        intervalMarker2.setLabelPaint((java.awt.Paint) color13);
        org.jfree.chart.text.TextAnchor textAnchor15 = intervalMarker2.getLabelTextAnchor();
        intervalMarker2.setEndValue((double) (byte) -1);
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean22 = dateAxis21.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis21, categoryItemRenderer23);
        boolean boolean25 = categoryPlot24.isOutlineVisible();
        java.awt.Paint paint26 = categoryPlot24.getDomainGridlinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = categoryPlot24.getDomainAxisForDataset((int) (short) 0);
        org.jfree.data.category.CategoryDataset categoryDataset29 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = null;
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean33 = dateAxis32.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset29, categoryAxis30, (org.jfree.chart.axis.ValueAxis) dateAxis32, categoryItemRenderer34);
        org.jfree.data.Range range36 = dateAxis32.getRange();
        int int37 = categoryPlot24.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis32);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent38 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot24);
        intervalMarker2.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot24);
        categoryPlot24.setRangeCrosshairValue((double) (-9));
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(textAnchor15);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNull(categoryAxis28);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(range36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeZeroBaselineVisible(false);
        boolean boolean3 = xYPlot0.isOutlineVisible();
        xYPlot0.clearRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation6 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot0.setDomainAxisLocation(64, axisLocation6);
        java.awt.Color color8 = java.awt.Color.WHITE;
        xYPlot0.setRangeTickBandPaint((java.awt.Paint) color8);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis11 = xYPlot0.getRangeAxisForDataset(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 8 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean5 = dateAxis4.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        org.jfree.data.Range range8 = dateAxis4.getRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis4);
        java.text.DateFormat dateFormat10 = dateAxis4.getDateFormatOverride();
        dateAxis4.setRangeAboutValue(6.0d, (double) 10L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNull(dateFormat10);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = dateAxis3.getTickLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        dateAxis8.setTickLabelPaint((java.awt.Paint) color9);
        boolean boolean11 = rectangleInsets7.equals((java.lang.Object) dateAxis8);
        dateAxis8.resizeRange((double) 3);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.axis.AxisState axisState15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean21 = dateAxis20.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis20, categoryItemRenderer22);
        categoryPlot23.clearRangeMarkers(0);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent26 = null;
        categoryPlot23.markerChanged(markerChangeEvent26);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = categoryPlot23.getDomainAxisEdge();
        try {
            java.util.List list29 = dateAxis8.refreshTicks(graphics2D14, axisState15, rectangle2D16, rectangleEdge28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(rectangleEdge28);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        int int8 = categoryPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis7);
        categoryPlot6.clearDomainAxes();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot6.getDrawingSupplier();
        categoryPlot6.clearRangeAxes();
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        categoryPlot6.setFixedRangeAxisSpace(axisSpace10);
        categoryPlot6.setBackgroundImageAlignment((int) (byte) -1);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        categoryPlot6.setRangeAxis(8, valueAxis15, true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(drawingSupplier8);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range4 = dateAxis3.getDefaultAutoRange();
        java.awt.Paint paint5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        dateAxis3.setAxisLinePaint(paint5);
        dateAxis3.setAutoRange(true);
        boolean boolean9 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer10);
        dateAxis3.setAutoRangeMinimumSize((double) 100, false);
        java.lang.String str15 = dateAxis3.getLabelToolTip();
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(str15);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYPlot0.setDomainZeroBaselinePaint(paint1);
        org.jfree.chart.axis.AxisSpace axisSpace3 = xYPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = xYPlot0.getRangeAxisEdge();
        xYPlot0.setNoDataMessage("SeriesRenderingOrder.FORWARD");
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(axisSpace3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.lang.Object obj1 = null;
        boolean boolean2 = chartChangeEventType0.equals(obj1);
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean5 = dateAxis4.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        boolean boolean8 = categoryPlot7.isOutlineVisible();
        java.awt.Paint paint9 = categoryPlot7.getDomainGridlinePaint();
        boolean boolean10 = objectList0.equals((java.lang.Object) paint9);
        int int11 = objectList0.size();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        double double7 = dateAxis3.getUpperBound();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean12 = dateAxis11.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis11, categoryItemRenderer13);
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        int int16 = categoryPlot14.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis15);
        categoryPlot14.configureRangeAxes();
        dateAxis3.setPlot((org.jfree.chart.plot.Plot) categoryPlot14);
        java.awt.Paint paint19 = categoryPlot14.getRangeCrosshairPaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        categoryPlot14.setRenderer(3, categoryItemRenderer21);
        categoryPlot14.setWeight(10);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 3, 100.0d);
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range6 = dateAxis5.getDefaultAutoRange();
        xYPlot3.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis5);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot3.setRangeCrosshairStroke(stroke8);
        intervalMarker2.setStroke(stroke8);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.CENTER;
        intervalMarker2.setLabelAnchor(rectangleAnchor11);
        java.lang.String str13 = intervalMarker2.getLabel();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer14 = null;
        intervalMarker2.setGradientPaintTransformer(gradientPaintTransformer14);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNull(str13);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot6.getDrawingSupplier();
        categoryPlot6.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot6.getDomainAxisEdge(10);
        boolean boolean12 = categoryPlot6.isRangeZoomable();
        categoryPlot6.setOutlineVisible(true);
        java.util.List list15 = categoryPlot6.getAnnotations();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(list15);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        java.awt.Paint paint1 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean7 = dateAxis6.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis6, categoryItemRenderer8);
        boolean boolean10 = categoryPlot9.isOutlineVisible();
        java.awt.Paint paint11 = categoryPlot9.getDomainGridlinePaint();
        java.lang.String str12 = categoryPlot9.getNoDataMessage();
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        categoryPlot9.setRangeCrosshairPaint((java.awt.Paint) color13);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean17 = dateAxis16.isNegativeArrowVisible();
        double double18 = dateAxis16.getLowerBound();
        java.awt.Paint paint19 = dateAxis16.getTickLabelPaint();
        java.awt.Stroke stroke20 = dateAxis16.getAxisLineStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker21 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-1), (java.awt.Paint) color13, stroke20);
        java.awt.Color color22 = java.awt.Color.green;
        java.awt.Color color23 = color22.brighter();
        java.awt.Color color29 = java.awt.Color.getHSBColor(0.0f, 0.0f, (float) 2);
        java.awt.Color color30 = java.awt.Color.getColor("ChartChangeEventType.DATASET_UPDATED", color29);
        java.awt.Stroke stroke31 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Paint paint32 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke33 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker35 = new org.jfree.chart.plot.ValueMarker((double) 15, (java.awt.Paint) color29, stroke31, paint32, stroke33, 0.0f);
        try {
            org.jfree.chart.plot.ValueMarker valueMarker37 = new org.jfree.chart.plot.ValueMarker((double) 'a', paint1, stroke20, (java.awt.Paint) color22, stroke31, (float) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(stroke33);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.calculateTopOutset(0.0d);
        double double3 = rectangleInsets0.getTop();
        double double4 = rectangleInsets0.getBottom();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean2 = dateAxis1.isNegativeArrowVisible();
        dateAxis1.setAutoRangeMinimumSize((double) (short) 1, true);
        java.awt.Shape shape6 = dateAxis1.getUpArrow();
        java.awt.Shape shape7 = dateAxis1.getLeftArrow();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape7);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        dateAxis3.setLowerBound((double) 13);
        dateAxis3.resizeRange((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        java.awt.Stroke stroke5 = numberAxis4.getTickMarkStroke();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit6 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis4.setTickUnit(numberTickUnit6);
        numberAxis2.setTickUnit(numberTickUnit6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        java.awt.Stroke stroke13 = numberAxis12.getTickMarkStroke();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit14 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis12.setTickUnit(numberTickUnit14);
        numberAxis10.setTickUnit(numberTickUnit14);
        numberAxis2.setTickUnit(numberTickUnit14);
        org.jfree.data.RangeType rangeType18 = numberAxis2.getRangeType();
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        java.awt.Stroke stroke23 = numberAxis22.getTickMarkStroke();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit24 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis22.setTickUnit(numberTickUnit24);
        numberAxis20.setTickUnit(numberTickUnit24);
        numberAxis2.setTickUnit(numberTickUnit24, false, false);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        java.awt.Stroke stroke32 = numberAxis31.getTickMarkStroke();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit33 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis31.setTickUnit(numberTickUnit33);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = null;
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis31, xYItemRenderer35);
        xYPlot36.mapDatasetToRangeAxis(100, 11);
        org.jfree.chart.plot.IntervalMarker intervalMarker43 = new org.jfree.chart.plot.IntervalMarker((double) 3, 100.0d);
        org.jfree.chart.plot.XYPlot xYPlot44 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range47 = dateAxis46.getDefaultAutoRange();
        xYPlot44.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis46);
        java.awt.Stroke stroke49 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot44.setRangeCrosshairStroke(stroke49);
        intervalMarker43.setStroke(stroke49);
        java.awt.Color color52 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        intervalMarker43.setOutlinePaint((java.awt.Paint) color52);
        org.jfree.chart.util.Layer layer54 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean56 = layer54.equals((java.lang.Object) true);
        java.lang.String str57 = layer54.toString();
        boolean boolean58 = xYPlot36.removeDomainMarker(12, (org.jfree.chart.plot.Marker) intervalMarker43, layer54);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(numberTickUnit6);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(numberTickUnit14);
        org.junit.Assert.assertNotNull(rangeType18);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(numberTickUnit24);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(numberTickUnit33);
        org.junit.Assert.assertNotNull(range47);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertNotNull(layer54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "Layer.FOREGROUND" + "'", str57.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        java.awt.Stroke stroke2 = numberAxis1.getTickMarkStroke();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis1.setTickUnit(numberTickUnit3);
        boolean boolean5 = numberAxis1.isAutoTickUnitSelection();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit6 = numberAxis1.getTickUnit();
        numberAxis1.setLabel("XY Plot");
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(numberTickUnit3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(numberTickUnit6);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        org.junit.Assert.assertNotNull(categoryAnchor0);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        java.awt.Stroke stroke5 = numberAxis4.getTickMarkStroke();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit6 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis4.setTickUnit(numberTickUnit6);
        numberAxis2.setTickUnit(numberTickUnit6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        java.awt.Stroke stroke13 = numberAxis12.getTickMarkStroke();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit14 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis12.setTickUnit(numberTickUnit14);
        numberAxis10.setTickUnit(numberTickUnit14);
        numberAxis2.setTickUnit(numberTickUnit14);
        org.jfree.data.RangeType rangeType18 = numberAxis2.getRangeType();
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        java.awt.Stroke stroke23 = numberAxis22.getTickMarkStroke();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit24 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis22.setTickUnit(numberTickUnit24);
        numberAxis20.setTickUnit(numberTickUnit24);
        numberAxis2.setTickUnit(numberTickUnit24, false, false);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        java.awt.Stroke stroke32 = numberAxis31.getTickMarkStroke();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit33 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis31.setTickUnit(numberTickUnit33);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = null;
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis31, xYItemRenderer35);
        xYPlot36.mapDatasetToRangeAxis(100, 11);
        xYPlot36.mapDatasetToDomainAxis((-100), (int) (short) -1);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(numberTickUnit6);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(numberTickUnit14);
        org.junit.Assert.assertNotNull(rangeType18);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(numberTickUnit24);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(numberTickUnit33);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 3, 100.0d);
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range6 = dateAxis5.getDefaultAutoRange();
        xYPlot3.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis5);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot3.setRangeCrosshairStroke(stroke8);
        intervalMarker2.setStroke(stroke8);
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        intervalMarker2.setOutlinePaint((java.awt.Paint) color11);
        double double13 = intervalMarker2.getEndValue();
        java.awt.Paint paint14 = intervalMarker2.getLabelPaint();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType15 = intervalMarker2.getLabelOffsetType();
        java.lang.Object obj16 = intervalMarker2.clone();
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 100.0d + "'", double13 == 100.0d);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(lengthAdjustmentType15);
        org.junit.Assert.assertNotNull(obj16);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeZeroBaselineVisible(false);
        boolean boolean3 = xYPlot0.isOutlineVisible();
        xYPlot0.clearRangeAxes();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        xYPlot0.drawAnnotations(graphics2D5, rectangle2D6, plotRenderingInfo7);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getBackgroundPaint();
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        java.awt.Color color1 = java.awt.Color.LIGHT_GRAY;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean7 = dateAxis6.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis6, categoryItemRenderer8);
        org.jfree.data.Range range10 = dateAxis6.getRange();
        xYPlot2.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        java.awt.Stroke stroke12 = xYPlot2.getDomainCrosshairStroke();
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        xYPlot13.setRangeZeroBaselineVisible(false);
        boolean boolean16 = xYPlot13.isOutlineVisible();
        xYPlot13.clearRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation19 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot13.setDomainAxisLocation(64, axisLocation19);
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean23 = dateAxis22.isNegativeArrowVisible();
        double double24 = dateAxis22.getLowerBound();
        java.awt.Paint paint25 = dateAxis22.getTickLabelPaint();
        java.awt.Stroke stroke26 = dateAxis22.getAxisLineStroke();
        xYPlot13.setDomainGridlineStroke(stroke26);
        xYPlot2.setRangeCrosshairStroke(stroke26);
        org.jfree.chart.plot.CategoryMarker categoryMarker29 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]", (java.awt.Paint) color1, stroke26);
        int int30 = color1.getBlue();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 192 + "'", int30 == 192);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 3, 100.0d);
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range6 = dateAxis5.getDefaultAutoRange();
        xYPlot3.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis5);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot3.setRangeCrosshairStroke(stroke8);
        intervalMarker2.setStroke(stroke8);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.CENTER;
        intervalMarker2.setLabelAnchor(rectangleAnchor11);
        java.awt.Color color13 = java.awt.Color.red;
        intervalMarker2.setLabelPaint((java.awt.Paint) color13);
        org.jfree.chart.text.TextAnchor textAnchor15 = intervalMarker2.getLabelTextAnchor();
        java.awt.Stroke stroke16 = null;
        try {
            intervalMarker2.setStroke(stroke16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(textAnchor15);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        java.awt.Color color0 = java.awt.Color.MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        java.awt.Paint paint5 = xYPlot0.getOutlinePaint();
        xYPlot0.setRangeCrosshairValue(1.0E-8d);
        xYPlot0.configureDomainAxes();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        java.awt.Paint paint8 = categoryPlot6.getDomainGridlinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot6.getDomainAxisForDataset((int) (short) 0);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean15 = dateAxis14.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis14, categoryItemRenderer16);
        org.jfree.data.Range range18 = dateAxis14.getRange();
        int int19 = categoryPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis14);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent20 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot6);
        java.awt.Stroke stroke21 = categoryPlot6.getDomainGridlineStroke();
        java.awt.Paint paint22 = categoryPlot6.getDomainGridlinePaint();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        xYPlot0.setDataset(xYDataset5);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        xYPlot0.setRangeGridlinePaint((java.awt.Paint) color7);
        float float9 = xYPlot0.getForegroundAlpha();
        boolean boolean10 = xYPlot0.isDomainZoomable();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1.0f + "'", float9 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        java.awt.Paint paint7 = categoryPlot6.getDomainGridlinePaint();
        categoryPlot6.setBackgroundImageAlignment(1);
        categoryPlot6.mapDatasetToRangeAxis((int) ' ', 100);
        java.awt.Image image13 = null;
        categoryPlot6.setBackgroundImage(image13);
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = categoryPlot6.getDomainAxis();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(categoryAxis15);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        java.awt.Paint paint5 = xYPlot0.getOutlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        xYPlot0.zoomRangeAxes((double) (byte) 100, plotRenderingInfo7, point2D8, false);
        java.awt.Stroke stroke11 = xYPlot0.getRangeGridlineStroke();
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_YELLOW;
        xYPlot0.setRangeGridlinePaint((java.awt.Paint) color12);
        org.jfree.chart.axis.DateTickUnit dateTickUnit14 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        boolean boolean15 = xYPlot0.equals((java.lang.Object) dateTickUnit14);
        org.jfree.chart.axis.AxisSpace axisSpace16 = xYPlot0.getFixedRangeAxisSpace();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(dateTickUnit14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(axisSpace16);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        java.awt.Paint paint5 = xYPlot0.getOutlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        xYPlot0.zoomRangeAxes((double) (byte) 100, plotRenderingInfo7, point2D8, false);
        java.awt.Stroke stroke11 = xYPlot0.getDomainCrosshairStroke();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean14 = dateAxis13.isNegativeArrowVisible();
        double double15 = dateAxis13.getLowerBound();
        java.awt.Paint paint16 = dateAxis13.getTickLabelPaint();
        java.awt.Stroke stroke17 = dateAxis13.getAxisLineStroke();
        xYPlot0.setDomainGridlineStroke(stroke17);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation19 = null;
        try {
            boolean boolean21 = xYPlot0.removeAnnotation(xYAnnotation19, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        dateAxis3.resizeRange((double) 100.0f);
        java.awt.Shape shape9 = dateAxis3.getDownArrow();
        dateAxis3.setTickMarkInsideLength((float) (-9));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(shape9);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean5 = dateAxis4.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        org.jfree.data.Range range8 = dateAxis4.getRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis4);
        java.awt.Stroke stroke10 = xYPlot0.getDomainCrosshairStroke();
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        xYPlot11.setRangeZeroBaselineVisible(false);
        boolean boolean14 = xYPlot11.isOutlineVisible();
        xYPlot11.clearRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation17 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot11.setDomainAxisLocation(64, axisLocation17);
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean21 = dateAxis20.isNegativeArrowVisible();
        double double22 = dateAxis20.getLowerBound();
        java.awt.Paint paint23 = dateAxis20.getTickLabelPaint();
        java.awt.Stroke stroke24 = dateAxis20.getAxisLineStroke();
        xYPlot11.setDomainGridlineStroke(stroke24);
        xYPlot0.setRangeCrosshairStroke(stroke24);
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range30 = dateAxis29.getDefaultAutoRange();
        xYPlot27.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis29);
        org.jfree.data.xy.XYDataset xYDataset32 = null;
        xYPlot27.setDataset(xYDataset32);
        java.awt.Color color34 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        xYPlot27.setDomainTickBandPaint((java.awt.Paint) color34);
        org.jfree.chart.axis.ValueAxis valueAxis36 = xYPlot27.getRangeAxis();
        org.jfree.chart.plot.PlotOrientation plotOrientation37 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        xYPlot27.setOrientation(plotOrientation37);
        xYPlot0.setOrientation(plotOrientation37);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNull(valueAxis36);
        org.junit.Assert.assertNotNull(plotOrientation37);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeZeroBaselineVisible(false);
        boolean boolean3 = xYPlot0.isOutlineVisible();
        xYPlot0.clearRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation6 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot0.setDomainAxisLocation(64, axisLocation6);
        java.awt.Color color8 = java.awt.Color.WHITE;
        xYPlot0.setRangeTickBandPaint((java.awt.Paint) color8);
        int int10 = color8.getTransparency();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        java.awt.Color color6 = java.awt.Color.getHSBColor(0.0f, 0.0f, (float) 2);
        java.awt.Color color7 = java.awt.Color.getColor("ChartChangeEventType.DATASET_UPDATED", color6);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Paint paint9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) 15, (java.awt.Paint) color6, stroke8, paint9, stroke10, 0.0f);
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker((double) 11);
        java.awt.Paint paint15 = valueMarker14.getPaint();
        valueMarker14.setValue(8.0d);
        org.jfree.chart.plot.IntervalMarker intervalMarker20 = new org.jfree.chart.plot.IntervalMarker((double) 3, 100.0d);
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range24 = dateAxis23.getDefaultAutoRange();
        xYPlot21.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis23);
        java.awt.Stroke stroke26 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot21.setRangeCrosshairStroke(stroke26);
        intervalMarker20.setStroke(stroke26);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor29 = org.jfree.chart.util.RectangleAnchor.CENTER;
        intervalMarker20.setLabelAnchor(rectangleAnchor29);
        valueMarker14.setLabelAnchor(rectangleAnchor29);
        valueMarker12.setLabelAnchor(rectangleAnchor29);
        org.jfree.data.category.CategoryDataset categoryDataset33 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = null;
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean37 = dateAxis36.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, categoryAxis34, (org.jfree.chart.axis.ValueAxis) dateAxis36, categoryItemRenderer38);
        boolean boolean40 = categoryPlot39.isOutlineVisible();
        java.awt.Paint paint41 = categoryPlot39.getDomainGridlinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = categoryPlot39.getDomainAxisForDataset((int) (short) 0);
        java.awt.Font font44 = categoryPlot39.getNoDataMessageFont();
        java.util.List list45 = categoryPlot39.getAnnotations();
        boolean boolean46 = valueMarker12.equals((java.lang.Object) categoryPlot39);
        java.awt.Paint paint47 = categoryPlot39.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = new org.jfree.chart.axis.CategoryAxis();
        int int49 = categoryAxis48.getMaximumCategoryLabelLines();
        int int50 = categoryPlot39.getDomainAxisIndex(categoryAxis48);
        org.jfree.chart.axis.DateAxis dateAxis52 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean53 = dateAxis52.isTickLabelsVisible();
        org.jfree.data.time.DateRange dateRange54 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis52.setRange((org.jfree.data.Range) dateRange54);
        java.awt.Paint paint56 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        dateAxis52.setLabelPaint(paint56);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer58 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot59 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis48, (org.jfree.chart.axis.ValueAxis) dateAxis52, categoryItemRenderer58);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(rectangleAnchor29);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNull(categoryAxis43);
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertNotNull(list45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertNotNull(dateRange54);
        org.junit.Assert.assertNotNull(paint56);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        java.awt.Stroke stroke2 = numberAxis1.getTickMarkStroke();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis1.setTickUnit(numberTickUnit3);
        boolean boolean5 = numberAxis1.isAutoTickUnitSelection();
        numberAxis1.setTickMarkOutsideLength((float) (short) 100);
        java.text.NumberFormat numberFormat8 = numberAxis1.getNumberFormatOverride();
        java.lang.Object obj9 = numberAxis1.clone();
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        double double13 = numberAxis1.lengthToJava2D((double) (-4145152), rectangle2D11, rectangleEdge12);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(numberTickUnit3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(numberFormat8);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        java.awt.Paint paint7 = categoryPlot6.getDomainGridlinePaint();
        java.lang.Object obj8 = categoryPlot6.clone();
        boolean boolean9 = categoryPlot6.isRangeZoomable();
        categoryPlot6.mapDatasetToDomainAxis(255, 4);
        int int13 = categoryPlot6.getBackgroundImageAlignment();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 15 + "'", int13 == 15);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range2 = dateAxis1.getDefaultAutoRange();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean7 = dateAxis6.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis6, categoryItemRenderer8);
        boolean boolean10 = categoryPlot9.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier11 = categoryPlot9.getDrawingSupplier();
        categoryPlot9.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = categoryPlot9.getDomainAxisEdge(10);
        boolean boolean15 = categoryPlot9.isRangeZoomable();
        java.awt.Paint paint16 = categoryPlot9.getDomainGridlinePaint();
        boolean boolean17 = categoryPlot9.isDomainGridlinesVisible();
        boolean boolean18 = categoryPlot9.isDomainGridlinesVisible();
        dateAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = null;
        try {
            dateAxis1.setTickLabelInsets(rectangleInsets20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(drawingSupplier11);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj2 = objectList0.get((int) '4');
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        java.awt.Font font8 = categoryPlot6.getNoDataMessageFont();
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = categoryPlot6.getRangeAxisEdge((int) (short) 10);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        categoryPlot6.setFixedRangeAxisSpace(axisSpace11);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier13 = categoryPlot6.getDrawingSupplier();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNotNull(drawingSupplier13);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        int int3 = java.awt.Color.HSBtoRGB((float) (byte) 100, (float) 0, 0.5f);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-8355712) + "'", int3 == (-8355712));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeZeroBaselineVisible(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder3 = xYPlot0.getDatasetRenderingOrder();
        xYPlot0.setDomainCrosshairLockedOnData(false);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        java.awt.Stroke stroke8 = numberAxis7.getTickMarkStroke();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit9 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis7.setTickUnit(numberTickUnit9);
        boolean boolean11 = xYPlot0.equals((java.lang.Object) numberTickUnit9);
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker((double) 11);
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker13);
        java.awt.Stroke stroke15 = xYPlot0.getRangeCrosshairStroke();
        org.junit.Assert.assertNotNull(datasetRenderingOrder3);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(numberTickUnit9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        java.awt.Paint paint8 = categoryPlot6.getDomainGridlinePaint();
        java.awt.Image image9 = null;
        categoryPlot6.setBackgroundImage(image9);
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        xYPlot12.setRangeZeroBaselineVisible(false);
        boolean boolean15 = xYPlot12.isOutlineVisible();
        xYPlot12.clearRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot12.setDomainAxisLocation(64, axisLocation18);
        categoryPlot6.setRangeAxisLocation(12, axisLocation18);
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray22 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis21 };
        categoryPlot6.setDomainAxes(categoryAxisArray22);
        categoryPlot6.clearDomainMarkers((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(categoryAxisArray22);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        java.awt.Font font8 = categoryPlot6.getNoDataMessageFont();
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = categoryPlot6.getRangeAxisEdge((int) (short) 10);
        double double11 = categoryPlot6.getAnchorValue();
        categoryPlot6.setAnchorValue((double) (short) -1, true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        org.jfree.chart.plot.Marker marker5 = null;
        boolean boolean6 = xYPlot0.removeDomainMarker(marker5);
        xYPlot0.setDomainCrosshairValue((double) (-1), true);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean12 = dateAxis11.isNegativeArrowVisible();
        dateAxis11.setAutoRangeMinimumSize((double) (short) 1, true);
        org.jfree.chart.axis.Timeline timeline16 = null;
        dateAxis11.setTimeline(timeline16);
        boolean boolean18 = xYPlot0.equals((java.lang.Object) dateAxis11);
        org.jfree.data.Range range19 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis11.setRange(range19, true, false);
        dateAxis11.setNegativeArrowVisible(true);
        org.jfree.data.Range range25 = dateAxis11.getRange();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertNotNull(range25);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot6.getDrawingSupplier();
        categoryPlot6.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot6.getDomainAxisEdge(10);
        boolean boolean12 = categoryPlot6.isRangeZoomable();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        categoryPlot6.setRenderer(categoryItemRenderer13, true);
        categoryPlot6.setRangeCrosshairValue((double) 10.0f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Point2D point2D21 = null;
        categoryPlot6.zoomRangeAxes(100.0d, (double) 1, plotRenderingInfo20, point2D21);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 11);
        java.awt.Paint paint2 = valueMarker1.getPaint();
        valueMarker1.setValue((double) 0.5f);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 11);
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range5 = dateAxis4.getDefaultAutoRange();
        xYPlot2.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis4);
        java.awt.Paint paint7 = xYPlot2.getOutlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        xYPlot2.zoomRangeAxes((double) (byte) 100, plotRenderingInfo9, point2D10, false);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean17 = dateAxis16.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis16, categoryItemRenderer18);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = dateAxis16.getTickLabelInsets();
        xYPlot2.setInsets(rectangleInsets20, false);
        boolean boolean23 = valueMarker1.equals((java.lang.Object) rectangleInsets20);
        double double25 = rectangleInsets20.calculateRightInset((double) 'a');
        double double27 = rectangleInsets20.extendHeight(10.0d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 4.0d + "'", double25 == 4.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 14.0d + "'", double27 == 14.0d);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot6.getDrawingSupplier();
        categoryPlot6.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot6.getDomainAxisEdge(10);
        boolean boolean12 = categoryPlot6.isRangeZoomable();
        java.awt.Paint paint13 = categoryPlot6.getDomainGridlinePaint();
        boolean boolean14 = categoryPlot6.isDomainGridlinesVisible();
        boolean boolean15 = categoryPlot6.isDomainGridlinesVisible();
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        boolean boolean20 = categoryPlot6.render(graphics2D16, rectangle2D17, 255, plotRenderingInfo19);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent21 = null;
        categoryPlot6.markerChanged(markerChangeEvent21);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        xYPlot0.setDataset(xYDataset5);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        xYPlot0.setDomainTickBandPaint((java.awt.Paint) color7);
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot0.getRangeAxis();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range13 = dateAxis12.getDefaultAutoRange();
        java.awt.Paint paint14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        dateAxis12.setAxisLinePaint(paint14);
        dateAxis12.setAutoRange(true);
        xYPlot0.setDomainAxis(192, (org.jfree.chart.axis.ValueAxis) dateAxis12);
        org.jfree.chart.plot.IntervalMarker intervalMarker21 = new org.jfree.chart.plot.IntervalMarker((double) 3, 100.0d);
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range25 = dateAxis24.getDefaultAutoRange();
        xYPlot22.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis24);
        java.awt.Stroke stroke27 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot22.setRangeCrosshairStroke(stroke27);
        intervalMarker21.setStroke(stroke27);
        java.awt.Color color30 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        intervalMarker21.setOutlinePaint((java.awt.Paint) color30);
        double double32 = intervalMarker21.getEndValue();
        java.awt.Paint paint33 = intervalMarker21.getLabelPaint();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType34 = intervalMarker21.getLabelOffsetType();
        boolean boolean35 = xYPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker21);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 100.0d + "'", double32 == 100.0d);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(lengthAdjustmentType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        int int3 = java.awt.Color.HSBtoRGB(0.8f, (float) (short) 100, 0.0f);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        java.awt.Paint paint5 = xYPlot0.getOutlinePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = xYPlot0.getRangeAxisEdge();
        org.jfree.chart.axis.AxisLocation axisLocation7 = xYPlot0.getDomainAxisLocation();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(axisLocation7);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.TOP;
        try {
            java.awt.geom.Point2D point2D2 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor1);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        java.awt.Color color0 = java.awt.Color.darkGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getLeftArrow();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean6 = dateAxis5.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer7);
        dateAxis5.resizeRange((double) 100.0f);
        java.awt.Shape shape11 = dateAxis5.getDownArrow();
        dateAxis0.setDownArrow(shape11);
        boolean boolean13 = dateAxis0.isAutoRange();
        double double14 = dateAxis0.getFixedDimension();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        categoryPlot6.mapDatasetToDomainAxis(100, (int) 'a');
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        categoryPlot6.setRenderer(255, categoryItemRenderer12, false);
        double double15 = categoryPlot6.getRangeCrosshairValue();
        java.lang.String str16 = categoryPlot6.getNoDataMessage();
        boolean boolean17 = categoryPlot6.isDomainGridlinesVisible();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        java.awt.Paint paint5 = xYPlot0.getOutlinePaint();
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        xYPlot7.setRangeZeroBaselineVisible(false);
        boolean boolean10 = xYPlot7.isOutlineVisible();
        xYPlot7.clearRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot7.setDomainAxisLocation(64, axisLocation13);
        xYPlot0.setDomainAxisLocation(2, axisLocation13);
        org.jfree.chart.axis.AxisLocation axisLocation16 = xYPlot0.getDomainAxisLocation();
        xYPlot0.zoom((double) 100.0f);
        java.awt.Paint paint19 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        xYPlot0.setDataset(xYDataset20);
        java.awt.Paint paint22 = xYPlot0.getRangeZeroBaselinePaint();
        int int23 = xYPlot0.getRangeAxisCount();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range4 = dateAxis3.getDefaultAutoRange();
        java.awt.Paint paint5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        dateAxis3.setAxisLinePaint(paint5);
        dateAxis3.setAutoRange(true);
        boolean boolean9 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer10);
        java.util.Date date12 = dateAxis3.getMinimumDate();
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date12);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor(192, 100, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Blue");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        dateAxis2.setUpperMargin(100.0d);
        dateAxis2.setPositiveArrowVisible(false);
        dateAxis2.setLowerMargin((double) 1560409200000L);
        org.junit.Assert.assertNotNull(range3);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        xYPlot0.setDataset(xYDataset5);
        java.awt.Paint paint7 = xYPlot0.getDomainTickBandPaint();
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        xYPlot8.setRangeZeroBaselineVisible(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = xYPlot8.getDatasetRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot8.setRangeAxisLocation((int) (byte) 100, axisLocation13);
        xYPlot8.setRangeCrosshairVisible(false);
        boolean boolean17 = xYPlot8.isRangeZeroBaselineVisible();
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        xYPlot8.setDomainGridlinePaint((java.awt.Paint) color18);
        xYPlot0.setDomainCrosshairPaint((java.awt.Paint) color18);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(color18);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateTopInset((double) (short) -1);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0d + "'", double2 == 2.0d);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        xYPlot0.setDataset(xYDataset5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range10 = dateAxis9.getDefaultAutoRange();
        xYPlot7.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis9);
        java.awt.Paint paint12 = xYPlot7.getOutlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        xYPlot7.zoomRangeAxes((double) (byte) 100, plotRenderingInfo14, point2D15, false);
        java.awt.Stroke stroke18 = xYPlot7.getRangeGridlineStroke();
        int int19 = xYPlot7.getRangeAxisCount();
        xYPlot7.setRangeCrosshairValue((double) (-1));
        java.awt.Paint paint22 = xYPlot7.getRangeCrosshairPaint();
        java.awt.Paint paint24 = xYPlot7.getQuadrantPaint(0);
        java.awt.Paint paint25 = xYPlot7.getOutlinePaint();
        xYPlot0.setRangeGridlinePaint(paint25);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNull(paint24);
        org.junit.Assert.assertNotNull(paint25);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Paint[] paintArray3 = new java.awt.Paint[] { color1, color2 };
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Paint paint5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Paint paint7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        java.awt.Paint[] paintArray8 = new java.awt.Paint[] { color4, paint5, color6, paint7 };
        java.awt.Stroke stroke9 = null;
        java.awt.Stroke[] strokeArray10 = new java.awt.Stroke[] { stroke9 };
        java.awt.Stroke[] strokeArray11 = null;
        java.awt.Shape[] shapeArray12 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier13 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray3, paintArray8, strokeArray10, strokeArray11, shapeArray12);
        org.jfree.chart.JFreeChart jFreeChart14 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType15 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        java.lang.String str16 = chartChangeEventType15.toString();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent17 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) paintArray3, jFreeChart14, chartChangeEventType15);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType18 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        chartChangeEvent17.setType(chartChangeEventType18);
        org.jfree.chart.JFreeChart jFreeChart20 = null;
        chartChangeEvent17.setChart(jFreeChart20);
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paintArray3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paintArray8);
        org.junit.Assert.assertNotNull(strokeArray10);
        org.junit.Assert.assertNotNull(shapeArray12);
        org.junit.Assert.assertNotNull(chartChangeEventType15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str16.equals("ChartChangeEventType.DATASET_UPDATED"));
        org.junit.Assert.assertNotNull(chartChangeEventType18);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.END;
        java.lang.String str1 = categoryAnchor0.toString();
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CategoryAnchor.END" + "'", str1.equals("CategoryAnchor.END"));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = dateAxis3.getTickLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        dateAxis8.setTickLabelPaint((java.awt.Paint) color9);
        boolean boolean11 = rectangleInsets7.equals((java.lang.Object) dateAxis8);
        java.lang.String str12 = rectangleInsets7.toString();
        double double14 = rectangleInsets7.trimHeight((double) 6);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str12.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 2.0d + "'", double14 == 2.0d);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        org.jfree.chart.plot.Marker marker5 = null;
        boolean boolean6 = xYPlot0.removeDomainMarker(marker5);
        xYPlot0.setDomainCrosshairValue((double) (-1), true);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean12 = dateAxis11.isNegativeArrowVisible();
        dateAxis11.setAutoRangeMinimumSize((double) (short) 1, true);
        org.jfree.chart.axis.Timeline timeline16 = null;
        dateAxis11.setTimeline(timeline16);
        boolean boolean18 = xYPlot0.equals((java.lang.Object) dateAxis11);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range23 = dateAxis22.getDefaultAutoRange();
        java.awt.Paint paint24 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        dateAxis22.setAxisLinePaint(paint24);
        dateAxis22.setAutoRange(true);
        boolean boolean28 = dateAxis22.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, (org.jfree.chart.axis.ValueAxis) dateAxis22, categoryItemRenderer29);
        int int31 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis22);
        org.jfree.chart.axis.AxisLocation axisLocation32 = xYPlot0.getRangeAxisLocation();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertNotNull(axisLocation32);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        dateAxis2.setUpperMargin(100.0d);
        dateAxis2.setPositiveArrowVisible(false);
        java.awt.Shape shape9 = dateAxis2.getDownArrow();
        boolean boolean10 = dateAxis2.isTickLabelsVisible();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        dateAxis3.resizeRange((double) 100.0f);
        java.util.Date date9 = dateAxis3.getMaximumDate();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean14 = dateAxis13.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis13, categoryItemRenderer15);
        java.util.TimeZone timeZone17 = dateAxis13.getTimeZone();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date9, timeZone17);
        org.jfree.chart.axis.TickUnitSource tickUnitSource19 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone17);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNotNull(tickUnitSource19);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 3, 100.0d);
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range6 = dateAxis5.getDefaultAutoRange();
        xYPlot3.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis5);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot3.setRangeCrosshairStroke(stroke8);
        intervalMarker2.setStroke(stroke8);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer11 = null;
        intervalMarker2.setGradientPaintTransformer(gradientPaintTransformer11);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeZeroBaselineVisible(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder3 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot0.setRangeAxisLocation((int) (byte) 100, axisLocation5);
        xYPlot0.setRangeCrosshairVisible(false);
        boolean boolean9 = xYPlot0.isRangeZeroBaselineVisible();
        org.jfree.chart.plot.IntervalMarker intervalMarker12 = new org.jfree.chart.plot.IntervalMarker((double) 3, 100.0d);
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range16 = dateAxis15.getDefaultAutoRange();
        xYPlot13.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis15);
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot13.setRangeCrosshairStroke(stroke18);
        intervalMarker12.setStroke(stroke18);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder21 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean23 = datasetRenderingOrder21.equals((java.lang.Object) layer22);
        boolean boolean24 = xYPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker12, layer22);
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint26 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYPlot25.setDomainZeroBaselinePaint(paint26);
        org.jfree.chart.axis.AxisSpace axisSpace28 = xYPlot25.getFixedDomainAxisSpace();
        java.awt.Stroke stroke29 = xYPlot25.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke29);
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean36 = dateAxis35.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, (org.jfree.chart.axis.ValueAxis) dateAxis35, categoryItemRenderer37);
        boolean boolean39 = categoryPlot38.isOutlineVisible();
        java.awt.Paint paint40 = categoryPlot38.getDomainGridlinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = categoryPlot38.getDomainAxisForDataset((int) (short) 0);
        org.jfree.data.category.CategoryDataset categoryDataset43 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = null;
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean47 = dateAxis46.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer48 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot49 = new org.jfree.chart.plot.CategoryPlot(categoryDataset43, categoryAxis44, (org.jfree.chart.axis.ValueAxis) dateAxis46, categoryItemRenderer48);
        org.jfree.data.Range range50 = dateAxis46.getRange();
        int int51 = categoryPlot38.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis46);
        dateAxis46.setFixedAutoRange((double) 255);
        boolean boolean54 = dateAxis46.isAutoRange();
        dateAxis46.setTickLabelsVisible(true);
        try {
            xYPlot0.setDomainAxis((-9), (org.jfree.chart.axis.ValueAxis) dateAxis46);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(datasetRenderingOrder3);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(datasetRenderingOrder21);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNull(axisSpace28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNull(categoryAxis42);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(range50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1) + "'", int51 == (-1));
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot6.getDrawingSupplier();
        categoryPlot6.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot6.getDomainAxisEdge(10);
        boolean boolean12 = categoryPlot6.isRangeZoomable();
        java.awt.Paint paint13 = categoryPlot6.getDomainGridlinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = categoryPlot6.getDomainAxis();
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range18 = dateAxis17.getDefaultAutoRange();
        xYPlot15.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis17);
        java.awt.Paint paint20 = xYPlot15.getOutlinePaint();
        xYPlot15.setRangeCrosshairValue(1.0E-8d);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        xYPlot15.setAxisOffset(rectangleInsets23);
        org.jfree.chart.util.UnitType unitType25 = rectangleInsets23.getUnitType();
        categoryPlot6.setAxisOffset(rectangleInsets23);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = categoryPlot6.getRenderer(2019);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(categoryAxis14);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(unitType25);
        org.junit.Assert.assertNull(categoryItemRenderer28);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYPlot0.setDomainZeroBaselinePaint(paint1);
        org.jfree.chart.axis.AxisSpace axisSpace3 = xYPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = xYPlot0.getRangeAxisEdge();
        org.jfree.chart.plot.IntervalMarker intervalMarker7 = new org.jfree.chart.plot.IntervalMarker(0.05d, 0.0d);
        org.jfree.chart.util.Layer layer8 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker7, layer8);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = intervalMarker7.getLabelAnchor();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(axisSpace3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(layer8);
        org.junit.Assert.assertNotNull(rectangleAnchor10);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        java.awt.Paint paint8 = categoryPlot6.getDomainGridlinePaint();
        java.awt.Image image9 = null;
        categoryPlot6.setBackgroundImage(image9);
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        xYPlot12.setRangeZeroBaselineVisible(false);
        boolean boolean15 = xYPlot12.isOutlineVisible();
        xYPlot12.clearRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot12.setDomainAxisLocation(64, axisLocation18);
        categoryPlot6.setRangeAxisLocation(12, axisLocation18);
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray22 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis21 };
        categoryPlot6.setDomainAxes(categoryAxisArray22);
        org.jfree.chart.LegendItemCollection legendItemCollection24 = categoryPlot6.getFixedLegendItems();
        java.awt.Stroke stroke25 = categoryPlot6.getOutlineStroke();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(categoryAxisArray22);
        org.junit.Assert.assertNull(legendItemCollection24);
        org.junit.Assert.assertNotNull(stroke25);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        java.awt.Color color0 = java.awt.Color.black;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeZeroBaselineVisible(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder3 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot0.setRangeAxisLocation((int) (byte) 100, axisLocation5);
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean11 = dateAxis10.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis10, categoryItemRenderer12);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = dateAxis10.getTickLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        dateAxis15.setTickLabelPaint((java.awt.Paint) color16);
        boolean boolean18 = rectangleInsets14.equals((java.lang.Object) dateAxis15);
        java.lang.String str19 = rectangleInsets14.toString();
        org.jfree.chart.util.UnitType unitType20 = rectangleInsets14.getUnitType();
        double double21 = rectangleInsets14.getBottom();
        double double23 = rectangleInsets14.calculateRightInset(0.0d);
        double double24 = rectangleInsets14.getRight();
        xYPlot0.setAxisOffset(rectangleInsets14);
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        dateAxis26.setTickLabelPaint((java.awt.Paint) color27);
        int int29 = color27.getAlpha();
        xYPlot0.setDomainGridlinePaint((java.awt.Paint) color27);
        org.jfree.chart.axis.AxisSpace axisSpace31 = xYPlot0.getFixedDomainAxisSpace();
        org.junit.Assert.assertNotNull(datasetRenderingOrder3);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str19.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
        org.junit.Assert.assertNotNull(unitType20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 2.0d + "'", double21 == 2.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 4.0d + "'", double23 == 4.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 4.0d + "'", double24 == 4.0d);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 255 + "'", int29 == 255);
        org.junit.Assert.assertNull(axisSpace31);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot6.getDrawingSupplier();
        categoryPlot6.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot6.getDomainAxisEdge(10);
        boolean boolean12 = categoryPlot6.isRangeZoomable();
        java.awt.Paint paint13 = categoryPlot6.getDomainGridlinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = categoryPlot6.getDomainAxis();
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range18 = dateAxis17.getDefaultAutoRange();
        xYPlot15.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis17);
        java.awt.Paint paint20 = xYPlot15.getOutlinePaint();
        xYPlot15.setRangeCrosshairValue(1.0E-8d);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        xYPlot15.setAxisOffset(rectangleInsets23);
        org.jfree.chart.util.UnitType unitType25 = rectangleInsets23.getUnitType();
        categoryPlot6.setAxisOffset(rectangleInsets23);
        java.lang.String str27 = rectangleInsets23.toString();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(categoryAxis14);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(unitType25);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]" + "'", str27.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean2 = numberAxis1.isVisible();
        java.text.NumberFormat numberFormat3 = null;
        numberAxis1.setNumberFormatOverride(numberFormat3);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 11);
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range5 = dateAxis4.getDefaultAutoRange();
        xYPlot2.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis4);
        java.awt.Paint paint7 = xYPlot2.getOutlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        xYPlot2.zoomRangeAxes((double) (byte) 100, plotRenderingInfo9, point2D10, false);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean17 = dateAxis16.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis16, categoryItemRenderer18);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = dateAxis16.getTickLabelInsets();
        xYPlot2.setInsets(rectangleInsets20, false);
        boolean boolean23 = valueMarker1.equals((java.lang.Object) rectangleInsets20);
        org.jfree.chart.JFreeChart jFreeChart24 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent25 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) valueMarker1, jFreeChart24);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = valueMarker1.getLabelOffset();
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rectangleInsets26);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        java.awt.Color color0 = java.awt.Color.GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean2 = dateAxis1.isNegativeArrowVisible();
        double double3 = dateAxis1.getLowerBound();
        java.awt.Paint paint4 = dateAxis1.getTickLabelPaint();
        dateAxis1.setLowerBound(0.0d);
        boolean boolean7 = dateAxis1.isInverted();
        dateAxis1.resizeRange((double) 9, (double) 12);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setUpperMargin((double) 1.0f);
        dateAxis1.setRange(2.0d, (double) 64);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        java.lang.String str1 = seriesRenderingOrder0.toString();
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SeriesRenderingOrder.REVERSE" + "'", str1.equals("SeriesRenderingOrder.REVERSE"));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        java.awt.Paint paint8 = categoryPlot6.getDomainGridlinePaint();
        java.awt.Image image9 = null;
        categoryPlot6.setBackgroundImage(image9);
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        xYPlot12.setRangeZeroBaselineVisible(false);
        boolean boolean15 = xYPlot12.isOutlineVisible();
        xYPlot12.clearRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot12.setDomainAxisLocation(64, axisLocation18);
        categoryPlot6.setRangeAxisLocation(12, axisLocation18);
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = categoryPlot6.getDomainAxisEdge((int) '4');
        org.jfree.chart.plot.IntervalMarker intervalMarker26 = new org.jfree.chart.plot.IntervalMarker((double) 3, 100.0d);
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = null;
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean31 = dateAxis30.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer32 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis28, (org.jfree.chart.axis.ValueAxis) dateAxis30, categoryItemRenderer32);
        boolean boolean34 = categoryPlot33.isOutlineVisible();
        java.awt.Paint paint35 = categoryPlot33.getDomainGridlinePaint();
        java.lang.String str36 = categoryPlot33.getNoDataMessage();
        intervalMarker26.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot33);
        org.jfree.chart.plot.XYPlot xYPlot38 = new org.jfree.chart.plot.XYPlot();
        xYPlot38.setRangeZeroBaselineVisible(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder41 = xYPlot38.getDatasetRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation43 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot38.setRangeAxisLocation((int) (byte) 100, axisLocation43);
        boolean boolean45 = xYPlot38.isDomainGridlinesVisible();
        xYPlot38.setOutlineVisible(true);
        org.jfree.chart.util.Layer layer49 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection50 = xYPlot38.getRangeMarkers(11, layer49);
        boolean boolean51 = categoryPlot6.removeDomainMarker(0, (org.jfree.chart.plot.Marker) intervalMarker26, layer49);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertNotNull(datasetRenderingOrder41);
        org.junit.Assert.assertNotNull(axisLocation43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(layer49);
        org.junit.Assert.assertNull(collection50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        java.awt.Paint paint5 = xYPlot0.getOutlinePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = xYPlot0.getRangeAxisEdge();
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean11 = dateAxis10.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis10, categoryItemRenderer12);
        boolean boolean14 = categoryPlot13.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier15 = categoryPlot13.getDrawingSupplier();
        categoryPlot13.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = categoryPlot13.getDomainAxisEdge(10);
        boolean boolean19 = categoryPlot13.isRangeZoomable();
        java.awt.Paint paint20 = categoryPlot13.getDomainGridlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation22 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot13.setDomainAxisLocation(64, axisLocation22, false);
        xYPlot0.setRangeAxisLocation(axisLocation22, false);
        java.awt.Graphics2D graphics2D27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.data.category.CategoryDataset categoryDataset29 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = null;
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean33 = dateAxis32.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset29, categoryAxis30, (org.jfree.chart.axis.ValueAxis) dateAxis32, categoryItemRenderer34);
        boolean boolean36 = categoryPlot35.isOutlineVisible();
        java.awt.Paint paint37 = categoryPlot35.getDomainGridlinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = categoryPlot35.getDomainAxisForDataset((int) (short) 0);
        java.awt.Font font40 = categoryPlot35.getNoDataMessageFont();
        java.util.List list41 = categoryPlot35.getAnnotations();
        xYPlot0.drawRangeTickBands(graphics2D27, rectangle2D28, list41);
        org.jfree.chart.plot.XYPlot xYPlot43 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range46 = dateAxis45.getDefaultAutoRange();
        xYPlot43.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis45);
        org.jfree.data.xy.XYDataset xYDataset48 = null;
        xYPlot43.setDataset(xYDataset48);
        java.awt.Color color50 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        xYPlot43.setDomainTickBandPaint((java.awt.Paint) color50);
        org.jfree.chart.axis.ValueAxis valueAxis52 = xYPlot43.getRangeAxis();
        org.jfree.chart.axis.DateAxis dateAxis55 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range56 = dateAxis55.getDefaultAutoRange();
        java.awt.Paint paint57 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        dateAxis55.setAxisLinePaint(paint57);
        dateAxis55.setAutoRange(true);
        xYPlot43.setDomainAxis(192, (org.jfree.chart.axis.ValueAxis) dateAxis55);
        int int62 = xYPlot0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis55);
        java.awt.Color color63 = java.awt.Color.LIGHT_GRAY;
        int int64 = color63.getRed();
        dateAxis55.setTickLabelPaint((java.awt.Paint) color63);
        dateAxis55.setAutoRangeMinimumSize((double) 1560452399999L);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(drawingSupplier15);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNull(categoryAxis39);
        org.junit.Assert.assertNotNull(font40);
        org.junit.Assert.assertNotNull(list41);
        org.junit.Assert.assertNotNull(range46);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNull(valueAxis52);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-1) + "'", int62 == (-1));
        org.junit.Assert.assertNotNull(color63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 192 + "'", int64 == 192);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(255);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) 3.0d, "ChartChangeEventType.DATASET_UPDATED");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder4 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        org.jfree.chart.util.Layer layer5 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean6 = datasetRenderingOrder4.equals((java.lang.Object) layer5);
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean11 = dateAxis10.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis10, categoryItemRenderer12);
        java.awt.Paint paint14 = categoryPlot13.getDomainGridlinePaint();
        int int15 = categoryPlot13.getBackgroundImageAlignment();
        boolean boolean16 = datasetRenderingOrder4.equals((java.lang.Object) categoryPlot13);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean21 = dateAxis20.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis20, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getDomainGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = categoryPlot23.getRenderer((int) (byte) 0);
        org.jfree.chart.LegendItemCollection legendItemCollection27 = categoryPlot23.getFixedLegendItems();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double30 = rectangleInsets28.calculateTopOutset(0.0d);
        categoryPlot23.setAxisOffset(rectangleInsets28);
        categoryPlot13.setAxisOffset(rectangleInsets28);
        categoryAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot13);
        java.lang.Comparable comparable34 = null;
        try {
            java.awt.Font font35 = categoryAxis0.getTickLabelFont(comparable34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(datasetRenderingOrder4);
        org.junit.Assert.assertNotNull(layer5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 15 + "'", int15 == 15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNull(categoryItemRenderer26);
        org.junit.Assert.assertNull(legendItemCollection27);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 4.0d + "'", double30 == 4.0d);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range4 = dateAxis3.getDefaultAutoRange();
        xYPlot1.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis3);
        java.awt.Paint paint6 = xYPlot1.getOutlinePaint();
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        xYPlot8.setRangeZeroBaselineVisible(false);
        boolean boolean11 = xYPlot8.isOutlineVisible();
        xYPlot8.clearRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation14 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot8.setDomainAxisLocation(64, axisLocation14);
        xYPlot1.setDomainAxisLocation(2, axisLocation14);
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot1.getDomainAxisLocation();
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean23 = dateAxis22.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, (org.jfree.chart.axis.ValueAxis) dateAxis22, categoryItemRenderer24);
        org.jfree.data.Range range26 = dateAxis22.getRange();
        xYPlot18.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis22);
        dateAxis22.resizeRange((double) 8);
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range32 = dateAxis31.getDefaultAutoRange();
        java.awt.Paint paint33 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        dateAxis31.setAxisLinePaint(paint33);
        dateAxis31.setAutoRange(true);
        org.jfree.data.category.CategoryDataset categoryDataset37 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = null;
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean41 = dateAxis40.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer42 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset37, categoryAxis38, (org.jfree.chart.axis.ValueAxis) dateAxis40, categoryItemRenderer42);
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis();
        int int45 = categoryPlot43.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis44);
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean48 = dateAxis47.isNegativeArrowVisible();
        org.jfree.data.category.CategoryDataset categoryDataset49 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = null;
        org.jfree.chart.axis.DateAxis dateAxis52 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean53 = dateAxis52.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer54 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot55 = new org.jfree.chart.plot.CategoryPlot(categoryDataset49, categoryAxis50, (org.jfree.chart.axis.ValueAxis) dateAxis52, categoryItemRenderer54);
        dateAxis52.resizeRange((double) 100.0f);
        java.awt.Shape shape58 = dateAxis52.getDownArrow();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray59 = new org.jfree.chart.axis.ValueAxis[] { dateAxis22, dateAxis31, dateAxis44, dateAxis47, dateAxis52 };
        xYPlot1.setDomainAxes(valueAxisArray59);
        org.jfree.chart.util.Layer layer61 = null;
        java.util.Collection collection62 = xYPlot1.getDomainMarkers(layer61);
        java.awt.Paint paint63 = xYPlot1.getDomainCrosshairPaint();
        org.jfree.chart.plot.IntervalMarker intervalMarker66 = new org.jfree.chart.plot.IntervalMarker((double) 3, 100.0d);
        org.jfree.chart.plot.XYPlot xYPlot67 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis69 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range70 = dateAxis69.getDefaultAutoRange();
        xYPlot67.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis69);
        java.awt.Stroke stroke72 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot67.setRangeCrosshairStroke(stroke72);
        intervalMarker66.setStroke(stroke72);
        java.awt.Color color75 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.jfree.chart.plot.XYPlot xYPlot76 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis78 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range79 = dateAxis78.getDefaultAutoRange();
        xYPlot76.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis78);
        java.awt.Stroke stroke81 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot76.setRangeCrosshairStroke(stroke81);
        try {
            org.jfree.chart.plot.ValueMarker valueMarker84 = new org.jfree.chart.plot.ValueMarker((double) '#', paint63, stroke72, (java.awt.Paint) color75, stroke81, (float) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(shape58);
        org.junit.Assert.assertNotNull(valueAxisArray59);
        org.junit.Assert.assertNull(collection62);
        org.junit.Assert.assertNotNull(paint63);
        org.junit.Assert.assertNotNull(range70);
        org.junit.Assert.assertNotNull(stroke72);
        org.junit.Assert.assertNotNull(color75);
        org.junit.Assert.assertNotNull(range79);
        org.junit.Assert.assertNotNull(stroke81);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        dateAxis3.resizeRange((double) 100.0f);
        java.util.Date date9 = dateAxis3.getMaximumDate();
        dateAxis3.configure();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot6.getDrawingSupplier();
        categoryPlot6.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot6.getDomainAxisEdge(10);
        boolean boolean12 = categoryPlot6.isRangeZoomable();
        java.awt.Paint paint13 = categoryPlot6.getDomainGridlinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = categoryPlot6.getDomainAxis();
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range18 = dateAxis17.getDefaultAutoRange();
        xYPlot15.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis17);
        java.awt.Paint paint20 = xYPlot15.getOutlinePaint();
        xYPlot15.setRangeCrosshairValue(1.0E-8d);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        xYPlot15.setAxisOffset(rectangleInsets23);
        org.jfree.chart.util.UnitType unitType25 = rectangleInsets23.getUnitType();
        categoryPlot6.setAxisOffset(rectangleInsets23);
        int int27 = categoryPlot6.getDatasetCount();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(categoryAxis14);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(unitType25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        java.awt.Paint paint5 = xYPlot0.getOutlinePaint();
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        xYPlot7.setRangeZeroBaselineVisible(false);
        boolean boolean10 = xYPlot7.isOutlineVisible();
        xYPlot7.clearRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot7.setDomainAxisLocation(64, axisLocation13);
        xYPlot0.setDomainAxisLocation(2, axisLocation13);
        org.jfree.chart.axis.AxisLocation axisLocation16 = xYPlot0.getDomainAxisLocation();
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = xYPlot0.getRendererForDataset(xYDataset17);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNull(xYItemRenderer18);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 3, 100.0d);
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range6 = dateAxis5.getDefaultAutoRange();
        xYPlot3.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis5);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot3.setRangeCrosshairStroke(stroke8);
        intervalMarker2.setStroke(stroke8);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.CENTER;
        intervalMarker2.setLabelAnchor(rectangleAnchor11);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean15 = dateAxis14.isNegativeArrowVisible();
        double double16 = dateAxis14.getLowerBound();
        java.awt.Paint paint17 = dateAxis14.getTickLabelPaint();
        java.awt.Stroke stroke18 = dateAxis14.getAxisLineStroke();
        intervalMarker2.setStroke(stroke18);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer20 = null;
        intervalMarker2.setGradientPaintTransformer(gradientPaintTransformer20);
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean26 = dateAxis25.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis23, (org.jfree.chart.axis.ValueAxis) dateAxis25, categoryItemRenderer27);
        boolean boolean29 = categoryPlot28.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier30 = categoryPlot28.getDrawingSupplier();
        categoryPlot28.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = categoryPlot28.getDomainAxisEdge(10);
        org.jfree.data.category.CategoryDataset categoryDataset34 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = null;
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean38 = dateAxis37.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset34, categoryAxis35, (org.jfree.chart.axis.ValueAxis) dateAxis37, categoryItemRenderer39);
        dateAxis37.resizeRange((double) 100.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = dateAxis37.getLabelInsets();
        int int44 = categoryPlot28.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis37);
        intervalMarker2.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot28);
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = categoryPlot28.getDomainAxis(1);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(drawingSupplier30);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertNull(categoryAxis47);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYPlot0.setDomainZeroBaselinePaint(paint1);
        org.jfree.chart.axis.AxisSpace axisSpace3 = xYPlot0.getFixedDomainAxisSpace();
        java.awt.Stroke stroke4 = xYPlot0.getDomainCrosshairStroke();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        xYPlot0.drawAnnotations(graphics2D5, rectangle2D6, plotRenderingInfo7);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(axisSpace3);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        xYPlot0.setDataset(xYDataset5);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        xYPlot0.setDomainTickBandPaint((java.awt.Paint) color7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range12 = dateAxis11.getDefaultAutoRange();
        xYPlot9.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis11);
        java.awt.Paint paint14 = xYPlot9.getOutlinePaint();
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        xYPlot16.setRangeZeroBaselineVisible(false);
        boolean boolean19 = xYPlot16.isOutlineVisible();
        xYPlot16.clearRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation22 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot16.setDomainAxisLocation(64, axisLocation22);
        xYPlot9.setDomainAxisLocation(2, axisLocation22);
        boolean boolean25 = color7.equals((java.lang.Object) 2);
        java.awt.color.ColorSpace colorSpace26 = color7.getColorSpace();
        java.awt.Color color27 = org.jfree.chart.ChartColor.DARK_RED;
        float[] floatArray34 = new float[] { 1, 1L, 0L };
        float[] floatArray35 = java.awt.Color.RGBtoHSB((int) (short) -1, 8, 0, floatArray34);
        float[] floatArray36 = color27.getRGBColorComponents(floatArray34);
        try {
            float[] floatArray37 = color7.getRGBComponents(floatArray34);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(colorSpace26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertNotNull(floatArray35);
        org.junit.Assert.assertNotNull(floatArray36);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        java.awt.Paint paint5 = xYPlot0.getOutlinePaint();
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        xYPlot7.setRangeZeroBaselineVisible(false);
        boolean boolean10 = xYPlot7.isOutlineVisible();
        xYPlot7.clearRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot7.setDomainAxisLocation(64, axisLocation13);
        xYPlot0.setDomainAxisLocation(2, axisLocation13);
        org.jfree.chart.axis.AxisLocation axisLocation16 = xYPlot0.getDomainAxisLocation();
        xYPlot0.zoom((double) 100.0f);
        java.awt.Paint paint19 = xYPlot0.getDomainZeroBaselinePaint();
        xYPlot0.setDomainCrosshairValue((double) 12);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairVisible();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis8.setCategoryMargin((double) (short) 100);
        categoryPlot6.setDomainAxis(categoryAxis8);
        org.jfree.chart.plot.IntervalMarker intervalMarker15 = new org.jfree.chart.plot.IntervalMarker((double) 3, 100.0d);
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range19 = dateAxis18.getDefaultAutoRange();
        xYPlot16.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis18);
        java.awt.Stroke stroke21 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot16.setRangeCrosshairStroke(stroke21);
        intervalMarker15.setStroke(stroke21);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.CENTER;
        intervalMarker15.setLabelAnchor(rectangleAnchor24);
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean28 = dateAxis27.isNegativeArrowVisible();
        double double29 = dateAxis27.getLowerBound();
        java.awt.Paint paint30 = dateAxis27.getTickLabelPaint();
        java.awt.Stroke stroke31 = dateAxis27.getAxisLineStroke();
        intervalMarker15.setStroke(stroke31);
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint34 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYPlot33.setDomainZeroBaselinePaint(paint34);
        org.jfree.chart.axis.AxisSpace axisSpace36 = xYPlot33.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = xYPlot33.getRangeAxisEdge();
        org.jfree.chart.plot.IntervalMarker intervalMarker40 = new org.jfree.chart.plot.IntervalMarker(0.05d, 0.0d);
        org.jfree.chart.util.Layer layer41 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot33.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker40, layer41);
        categoryPlot6.addRangeMarker((int) ' ', (org.jfree.chart.plot.Marker) intervalMarker15, layer41);
        intervalMarker15.setStartValue((double) 12);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNull(axisSpace36);
        org.junit.Assert.assertNotNull(rectangleEdge37);
        org.junit.Assert.assertNotNull(layer41);
    }
}

