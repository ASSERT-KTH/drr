import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        categoryPlot6.clearRangeMarkers(0);
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot6.getRangeAxisLocation(10);
        categoryPlot6.setRangeGridlinesVisible(true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent13 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot6);
        org.jfree.chart.plot.Plot plot14 = plotChangeEvent13.getPlot();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(plot14);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.START;
        boolean boolean2 = categoryAnchor0.equals((java.lang.Object) (-8388608));
        java.lang.String str3 = categoryAnchor0.toString();
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "CategoryAnchor.START" + "'", str3.equals("CategoryAnchor.START"));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot6.getDrawingSupplier();
        categoryPlot6.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot6.getDomainAxisEdge(10);
        boolean boolean12 = categoryPlot6.isRangeZoomable();
        java.awt.Paint paint13 = categoryPlot6.getDomainGridlinePaint();
        boolean boolean14 = categoryPlot6.isDomainGridlinesVisible();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation15 = null;
        try {
            boolean boolean17 = categoryPlot6.removeAnnotation(categoryAnnotation15, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range4 = dateAxis3.getDefaultAutoRange();
        java.awt.Paint paint5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        dateAxis3.setAxisLinePaint(paint5);
        dateAxis3.setAutoRange(true);
        boolean boolean9 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer10);
        java.awt.Paint paint12 = dateAxis3.getTickMarkPaint();
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot6.getDrawingSupplier();
        categoryPlot6.clearRangeAxes();
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        categoryPlot6.setFixedRangeAxisSpace(axisSpace10);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean16 = dateAxis15.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, (org.jfree.chart.axis.ValueAxis) dateAxis15, categoryItemRenderer17);
        boolean boolean19 = categoryPlot18.isOutlineVisible();
        java.awt.Paint paint20 = categoryPlot18.getDomainGridlinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = categoryPlot18.getDomainAxisForDataset((int) (short) 0);
        java.awt.Font font23 = categoryPlot18.getNoDataMessageFont();
        categoryPlot6.setNoDataMessageFont(font23);
        boolean boolean25 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        java.awt.geom.Point2D point2D28 = null;
        categoryPlot6.zoomRangeAxes((double) 192, plotRenderingInfo27, point2D28);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNull(categoryAxis22);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot6.getDrawingSupplier();
        categoryPlot6.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot6.getDomainAxisEdge(10);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = categoryPlot6.getDomainAxis();
        categoryPlot6.setDomainGridlinesVisible(true);
        boolean boolean15 = categoryPlot6.isDomainZoomable();
        java.awt.Color color18 = java.awt.Color.LIGHT_GRAY;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean24 = dateAxis23.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, (org.jfree.chart.axis.ValueAxis) dateAxis23, categoryItemRenderer25);
        org.jfree.data.Range range27 = dateAxis23.getRange();
        xYPlot19.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis23);
        java.awt.Stroke stroke29 = xYPlot19.getDomainCrosshairStroke();
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot();
        xYPlot30.setRangeZeroBaselineVisible(false);
        boolean boolean33 = xYPlot30.isOutlineVisible();
        xYPlot30.clearRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation36 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot30.setDomainAxisLocation(64, axisLocation36);
        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean40 = dateAxis39.isNegativeArrowVisible();
        double double41 = dateAxis39.getLowerBound();
        java.awt.Paint paint42 = dateAxis39.getTickLabelPaint();
        java.awt.Stroke stroke43 = dateAxis39.getAxisLineStroke();
        xYPlot30.setDomainGridlineStroke(stroke43);
        xYPlot19.setRangeCrosshairStroke(stroke43);
        org.jfree.chart.plot.CategoryMarker categoryMarker46 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]", (java.awt.Paint) color18, stroke43);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder47 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        org.jfree.chart.util.Layer layer48 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean49 = datasetRenderingOrder47.equals((java.lang.Object) layer48);
        categoryPlot6.addDomainMarker(0, categoryMarker46, layer48, false);
        boolean boolean52 = categoryMarker46.getDrawAsLine();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNull(categoryAxis12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(datasetRenderingOrder47);
        org.junit.Assert.assertNotNull(layer48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        java.awt.Stroke stroke5 = numberAxis4.getTickMarkStroke();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit6 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis4.setTickUnit(numberTickUnit6);
        numberAxis2.setTickUnit(numberTickUnit6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        java.awt.Stroke stroke13 = numberAxis12.getTickMarkStroke();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit14 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis12.setTickUnit(numberTickUnit14);
        numberAxis10.setTickUnit(numberTickUnit14);
        numberAxis2.setTickUnit(numberTickUnit14);
        org.jfree.data.RangeType rangeType18 = numberAxis2.getRangeType();
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        java.awt.Stroke stroke23 = numberAxis22.getTickMarkStroke();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit24 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis22.setTickUnit(numberTickUnit24);
        numberAxis20.setTickUnit(numberTickUnit24);
        numberAxis2.setTickUnit(numberTickUnit24, false, false);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        java.awt.Stroke stroke32 = numberAxis31.getTickMarkStroke();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit33 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis31.setTickUnit(numberTickUnit33);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = null;
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis31, xYItemRenderer35);
        xYPlot36.mapDatasetToRangeAxis(100, 11);
        java.awt.Paint paint40 = xYPlot36.getDomainTickBandPaint();
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(numberTickUnit6);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(numberTickUnit14);
        org.junit.Assert.assertNotNull(rangeType18);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(numberTickUnit24);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(numberTickUnit33);
        org.junit.Assert.assertNull(paint40);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairVisible();
        java.awt.Color color8 = java.awt.Color.white;
        categoryPlot6.setBackgroundPaint((java.awt.Paint) color8);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        dateAxis2.setUpperMargin(100.0d);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.axis.AxisState axisState8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        java.util.List list11 = dateAxis2.refreshTicks(graphics2D7, axisState8, rectangle2D9, rectangleEdge10);
        dateAxis2.setAutoTickUnitSelection(false, false);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNull(list11);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        java.awt.Paint paint7 = categoryPlot6.getDomainGridlinePaint();
        int int8 = categoryPlot6.getBackgroundImageAlignment();
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range12 = dateAxis11.getDefaultAutoRange();
        xYPlot9.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis11);
        org.jfree.chart.plot.Marker marker14 = null;
        boolean boolean15 = xYPlot9.removeDomainMarker(marker14);
        xYPlot9.setDomainCrosshairValue((double) (-1), true);
        java.lang.Object obj19 = xYPlot9.clone();
        org.jfree.chart.plot.IntervalMarker intervalMarker23 = new org.jfree.chart.plot.IntervalMarker((double) 3, 100.0d);
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean28 = dateAxis27.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer29);
        boolean boolean31 = categoryPlot30.isOutlineVisible();
        java.awt.Paint paint32 = categoryPlot30.getDomainGridlinePaint();
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range36 = dateAxis35.getDefaultAutoRange();
        xYPlot33.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis35);
        java.awt.Paint paint38 = xYPlot33.getOutlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo40 = null;
        java.awt.geom.Point2D point2D41 = null;
        xYPlot33.zoomRangeAxes((double) (byte) 100, plotRenderingInfo40, point2D41, false);
        java.awt.Stroke stroke44 = xYPlot33.getDomainCrosshairStroke();
        org.jfree.chart.util.Layer layer46 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean48 = layer46.equals((java.lang.Object) true);
        java.util.Collection collection49 = xYPlot33.getRangeMarkers(3, layer46);
        java.util.Collection collection50 = categoryPlot30.getRangeMarkers(layer46);
        xYPlot9.addRangeMarker(8, (org.jfree.chart.plot.Marker) intervalMarker23, layer46, true);
        java.util.Collection collection53 = categoryPlot6.getRangeMarkers(layer46);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 15 + "'", int8 == 15);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(range36);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(layer46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNull(collection49);
        org.junit.Assert.assertNull(collection50);
        org.junit.Assert.assertNull(collection53);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean8 = dateAxis7.isTickLabelsVisible();
        xYPlot0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis7, true);
        org.jfree.chart.plot.IntervalMarker intervalMarker13 = new org.jfree.chart.plot.IntervalMarker((double) 3, 100.0d);
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range17 = dateAxis16.getDefaultAutoRange();
        xYPlot14.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis16);
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot14.setRangeCrosshairStroke(stroke19);
        intervalMarker13.setStroke(stroke19);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        java.lang.String str23 = rectangleInsets22.toString();
        double double25 = rectangleInsets22.extendWidth(0.0d);
        intervalMarker13.setLabelOffset(rectangleInsets22);
        boolean boolean27 = xYPlot0.equals((java.lang.Object) rectangleInsets22);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]" + "'", str23.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 16.0d + "'", double25 == 16.0d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 11);
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range5 = dateAxis4.getDefaultAutoRange();
        xYPlot2.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis4);
        java.awt.Paint paint7 = xYPlot2.getOutlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        xYPlot2.zoomRangeAxes((double) (byte) 100, plotRenderingInfo9, point2D10, false);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean17 = dateAxis16.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis16, categoryItemRenderer18);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = dateAxis16.getTickLabelInsets();
        xYPlot2.setInsets(rectangleInsets20, false);
        boolean boolean23 = valueMarker1.equals((java.lang.Object) rectangleInsets20);
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) 11);
        java.awt.Paint paint26 = valueMarker25.getPaint();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType27 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        valueMarker25.setLabelOffsetType(lengthAdjustmentType27);
        valueMarker1.setLabelOffsetType(lengthAdjustmentType27);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(lengthAdjustmentType27);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        dateAxis3.resizeRange((double) 100.0f);
        java.awt.Shape shape9 = dateAxis3.getDownArrow();
        java.awt.Paint paint10 = dateAxis3.getTickLabelPaint();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        java.awt.Paint paint5 = xYPlot0.getOutlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        xYPlot0.zoomRangeAxes((double) (byte) 100, plotRenderingInfo7, point2D8, false);
        java.awt.Stroke stroke11 = xYPlot0.getRangeGridlineStroke();
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_YELLOW;
        xYPlot0.setRangeGridlinePaint((java.awt.Paint) color12);
        java.lang.String str14 = color12.toString();
        int int15 = color12.getTransparency();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "java.awt.Color[r=192,g=192,b=0]" + "'", str14.equals("java.awt.Color[r=192,g=192,b=0]"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot6.getDrawingSupplier();
        categoryPlot6.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot6.getDomainAxisEdge(10);
        boolean boolean12 = categoryPlot6.isRangeZoomable();
        java.awt.Paint paint13 = categoryPlot6.getDomainGridlinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = categoryPlot6.getDomainAxis();
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range18 = dateAxis17.getDefaultAutoRange();
        xYPlot15.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis17);
        java.awt.Paint paint20 = xYPlot15.getOutlinePaint();
        xYPlot15.setRangeCrosshairValue(1.0E-8d);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        xYPlot15.setAxisOffset(rectangleInsets23);
        org.jfree.chart.util.UnitType unitType25 = rectangleInsets23.getUnitType();
        categoryPlot6.setAxisOffset(rectangleInsets23);
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = null;
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean31 = dateAxis30.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer32 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis28, (org.jfree.chart.axis.ValueAxis) dateAxis30, categoryItemRenderer32);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = dateAxis30.getTickLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis();
        java.awt.Color color36 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        dateAxis35.setTickLabelPaint((java.awt.Paint) color36);
        boolean boolean38 = rectangleInsets34.equals((java.lang.Object) dateAxis35);
        org.jfree.data.general.Dataset dataset39 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent40 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) dateAxis35, dataset39);
        org.jfree.data.general.Dataset dataset41 = datasetChangeEvent40.getDataset();
        categoryPlot6.datasetChanged(datasetChangeEvent40);
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        java.awt.Stroke stroke45 = numberAxis44.getTickMarkStroke();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit46 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis44.setTickUnit(numberTickUnit46);
        boolean boolean48 = numberAxis44.isAutoTickUnitSelection();
        org.jfree.data.Range range49 = categoryPlot6.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis44);
        java.text.NumberFormat numberFormat50 = numberAxis44.getNumberFormatOverride();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(categoryAxis14);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(unitType25);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(dataset41);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(numberTickUnit46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNull(range49);
        org.junit.Assert.assertNull(numberFormat50);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairVisible();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis8.setCategoryMargin((double) (short) 100);
        categoryPlot6.setDomainAxis(categoryAxis8);
        categoryAxis8.setLowerMargin((double) (-1L));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeZeroBaselineVisible(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder3 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot0.setRangeAxisLocation((int) (byte) 100, axisLocation5);
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean11 = dateAxis10.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis10, categoryItemRenderer12);
        boolean boolean14 = categoryPlot13.isOutlineVisible();
        categoryPlot13.mapDatasetToDomainAxis(100, (int) 'a');
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        categoryPlot13.setRenderer(255, categoryItemRenderer19, false);
        double double22 = categoryPlot13.getRangeCrosshairValue();
        org.jfree.data.general.Dataset dataset23 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent24 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) categoryPlot13, dataset23);
        xYPlot0.datasetChanged(datasetChangeEvent24);
        boolean boolean26 = xYPlot0.isDomainZeroBaselineVisible();
        org.junit.Assert.assertNotNull(datasetRenderingOrder3);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot6.getDrawingSupplier();
        categoryPlot6.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot6.getDomainAxisEdge(10);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = categoryPlot6.getDomainAxis();
        categoryPlot6.setDomainGridlinesVisible(true);
        boolean boolean15 = categoryPlot6.isDomainGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        categoryPlot6.zoomDomainAxes((-6.0d), (double) 25568L, plotRenderingInfo18, point2D19);
        org.jfree.chart.axis.AxisLocation axisLocation22 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        try {
            categoryPlot6.setRangeAxisLocation((-8355712), axisLocation22, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNull(categoryAxis12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(axisLocation22);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeZeroBaselineVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation4 = null;
        xYPlot0.setRangeAxisLocation((int) ' ', axisLocation4, false);
        xYPlot0.mapDatasetToDomainAxis((int) (short) 10, 13);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray11 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer10 };
        xYPlot0.setRenderers(xYItemRendererArray11);
        org.junit.Assert.assertNotNull(xYItemRendererArray11);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        java.awt.Paint paint5 = xYPlot0.getOutlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        xYPlot0.zoomRangeAxes((double) (byte) 100, plotRenderingInfo7, point2D8, false);
        java.awt.Stroke stroke11 = xYPlot0.getRangeGridlineStroke();
        int int12 = xYPlot0.getRangeAxisCount();
        xYPlot0.setRangeCrosshairValue((double) (-1));
        java.awt.Paint paint15 = xYPlot0.getRangeCrosshairPaint();
        boolean boolean16 = xYPlot0.isRangeGridlinesVisible();
        int int17 = xYPlot0.getRangeAxisCount();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Paint[] paintArray3 = new java.awt.Paint[] { color1, color2 };
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Paint paint5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Paint paint7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        java.awt.Paint[] paintArray8 = new java.awt.Paint[] { color4, paint5, color6, paint7 };
        java.awt.Stroke stroke9 = null;
        java.awt.Stroke[] strokeArray10 = new java.awt.Stroke[] { stroke9 };
        java.awt.Stroke[] strokeArray11 = null;
        java.awt.Shape[] shapeArray12 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier13 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray3, paintArray8, strokeArray10, strokeArray11, shapeArray12);
        java.lang.Object obj14 = defaultDrawingSupplier13.clone();
        java.awt.Paint paint15 = defaultDrawingSupplier13.getNextPaint();
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paintArray3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paintArray8);
        org.junit.Assert.assertNotNull(strokeArray10);
        org.junit.Assert.assertNotNull(shapeArray12);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        java.awt.Paint paint5 = xYPlot0.getOutlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        xYPlot0.zoomRangeAxes((double) (byte) 100, plotRenderingInfo7, point2D8, false);
        java.awt.Stroke stroke11 = xYPlot0.getRangeGridlineStroke();
        int int12 = xYPlot0.getRangeAxisCount();
        xYPlot0.setRangeCrosshairValue((double) (-1));
        java.awt.Paint paint15 = xYPlot0.getRangeCrosshairPaint();
        java.awt.Paint paint17 = xYPlot0.getQuadrantPaint(0);
        boolean boolean18 = xYPlot0.isDomainCrosshairVisible();
        boolean boolean19 = xYPlot0.isRangeCrosshairLockedOnData();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean5 = dateAxis4.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        org.jfree.data.Range range8 = dateAxis4.getRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis4);
        dateAxis4.resizeRange((double) 8);
        java.awt.Paint paint12 = dateAxis4.getAxisLinePaint();
        java.awt.Shape shape13 = dateAxis4.getDownArrow();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean16 = dateAxis15.isNegativeArrowVisible();
        dateAxis15.setAutoRangeMinimumSize((double) (short) 1, true);
        double double20 = dateAxis15.getFixedAutoRange();
        java.util.Date date21 = dateAxis15.getMinimumDate();
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean26 = dateAxis25.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis23, (org.jfree.chart.axis.ValueAxis) dateAxis25, categoryItemRenderer27);
        dateAxis25.resizeRange((double) 100.0f);
        java.util.Date date31 = dateAxis25.getMaximumDate();
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean36 = dateAxis35.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, (org.jfree.chart.axis.ValueAxis) dateAxis35, categoryItemRenderer37);
        java.util.TimeZone timeZone39 = dateAxis35.getTimeZone();
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date31, timeZone39);
        dateAxis4.setRange(date21, date31);
        java.util.Date date42 = dateAxis4.getMaximumDate();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(timeZone39);
        org.junit.Assert.assertNotNull(date42);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getDomainAxisEdge(192);
        xYPlot0.setRangeZeroBaselineVisible(true);
        org.junit.Assert.assertNotNull(rectangleEdge2);
    }

//    @Test
//    public void test028() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test028");
//        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
//        org.jfree.data.Range range2 = dateAxis1.getDefaultAutoRange();
//        java.awt.Paint paint3 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
//        dateAxis1.setAxisLinePaint(paint3);
//        dateAxis1.setAutoRange(true);
//        org.jfree.chart.JFreeChart jFreeChart7 = null;
//        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateAxis1, jFreeChart7);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        long long10 = day9.getMiddleMillisecond();
//        int int11 = day9.getDayOfMonth();
//        long long12 = day9.getFirstMillisecond();
//        long long13 = day9.getMiddleMillisecond();
//        java.util.Date date14 = day9.getEnd();
//        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
//        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("hi!");
//        boolean boolean19 = dateAxis18.isNegativeArrowVisible();
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, (org.jfree.chart.axis.ValueAxis) dateAxis18, categoryItemRenderer20);
//        dateAxis18.resizeRange((double) 100.0f);
//        java.util.Date date24 = dateAxis18.getMaximumDate();
//        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis26 = null;
//        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis("hi!");
//        boolean boolean29 = dateAxis28.isNegativeArrowVisible();
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot(categoryDataset25, categoryAxis26, (org.jfree.chart.axis.ValueAxis) dateAxis28, categoryItemRenderer30);
//        java.util.TimeZone timeZone32 = dateAxis28.getTimeZone();
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date24, timeZone32);
//        try {
//            dateAxis1.setRange(date14, date24);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(range2);
//        org.junit.Assert.assertNotNull(paint3);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560452399999L + "'", long10 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 13 + "'", int11 == 13);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560409200000L + "'", long12 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560452399999L + "'", long13 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(timeZone32);
//    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range2 = dateAxis1.getDefaultAutoRange();
        java.awt.Paint paint3 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        dateAxis1.setAxisLinePaint(paint3);
        dateAxis1.setAutoRange(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource7 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis1.setStandardTickUnits(tickUnitSource7);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(tickUnitSource7);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean5 = dateAxis4.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        org.jfree.data.Range range8 = dateAxis4.getRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis4);
        dateAxis4.resizeRange((double) 8);
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        xYPlot12.setRangeZeroBaselineVisible(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder15 = xYPlot12.getDatasetRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation17 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot12.setRangeAxisLocation((int) (byte) 100, axisLocation17);
        xYPlot12.setRangeCrosshairVisible(false);
        boolean boolean21 = xYPlot12.isRangeZeroBaselineVisible();
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        xYPlot12.setDomainGridlinePaint((java.awt.Paint) color22);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer25 = xYPlot12.getRenderer((int) '4');
        dateAxis4.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot12);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder27 = xYPlot12.getSeriesRenderingOrder();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = xYPlot12.getAxisOffset();
        xYPlot12.setRangeZeroBaselineVisible(false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(datasetRenderingOrder15);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNull(xYItemRenderer25);
        org.junit.Assert.assertNotNull(seriesRenderingOrder27);
        org.junit.Assert.assertNotNull(rectangleInsets28);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean5 = dateAxis4.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        org.jfree.data.Range range8 = dateAxis4.getRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis4);
        java.awt.Stroke stroke10 = xYPlot0.getDomainCrosshairStroke();
        org.jfree.data.xy.XYDataset xYDataset11 = xYPlot0.getDataset();
        xYPlot0.mapDatasetToRangeAxis(0, (int) (byte) -1);
        java.awt.Stroke stroke15 = xYPlot0.getDomainCrosshairStroke();
        double double16 = xYPlot0.getDomainCrosshairValue();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNull(xYDataset11);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = categoryPlot6.getLegendItems();
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range12 = dateAxis11.getDefaultAutoRange();
        xYPlot9.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis11);
        java.awt.Paint paint14 = xYPlot9.getOutlinePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = xYPlot9.getRangeAxisEdge();
        org.jfree.chart.plot.PlotOrientation plotOrientation16 = xYPlot9.getOrientation();
        categoryPlot6.setOrientation(plotOrientation16);
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean22 = dateAxis21.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis21, categoryItemRenderer23);
        boolean boolean25 = categoryPlot24.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier26 = categoryPlot24.getDrawingSupplier();
        categoryPlot24.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = categoryPlot24.getDomainAxisEdge(10);
        boolean boolean30 = categoryPlot24.isRangeZoomable();
        java.awt.Paint paint31 = categoryPlot24.getDomainGridlinePaint();
        java.awt.Paint paint32 = categoryPlot24.getOutlinePaint();
        categoryPlot6.setRangeGridlinePaint(paint32);
        categoryPlot6.mapDatasetToRangeAxis((int) (byte) 10, (int) (byte) 100);
        java.awt.Font font37 = categoryPlot6.getNoDataMessageFont();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = categoryPlot6.getRenderer((-9));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(legendItemCollection8);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(plotOrientation16);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(drawingSupplier26);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNull(categoryItemRenderer39);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        java.awt.Paint paint5 = xYPlot0.getOutlinePaint();
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        xYPlot7.setRangeZeroBaselineVisible(false);
        boolean boolean10 = xYPlot7.isOutlineVisible();
        xYPlot7.clearRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot7.setDomainAxisLocation(64, axisLocation13);
        xYPlot0.setDomainAxisLocation(2, axisLocation13);
        org.jfree.chart.axis.AxisLocation axisLocation16 = xYPlot0.getDomainAxisLocation();
        xYPlot0.zoom((double) 100.0f);
        xYPlot0.clearRangeAxes();
        boolean boolean20 = xYPlot0.isDomainGridlinesVisible();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(0.05d, 0.0d);
        java.awt.Paint paint3 = intervalMarker2.getLabelPaint();
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean9 = dateAxis8.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis8, categoryItemRenderer10);
        boolean boolean12 = categoryPlot11.isOutlineVisible();
        java.awt.Paint paint13 = categoryPlot11.getDomainGridlinePaint();
        java.lang.String str14 = categoryPlot11.getNoDataMessage();
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        categoryPlot11.setRangeCrosshairPaint((java.awt.Paint) color15);
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean19 = dateAxis18.isNegativeArrowVisible();
        double double20 = dateAxis18.getLowerBound();
        java.awt.Paint paint21 = dateAxis18.getTickLabelPaint();
        java.awt.Stroke stroke22 = dateAxis18.getAxisLineStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker23 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-1), (java.awt.Paint) color15, stroke22);
        intervalMarker2.setStroke(stroke22);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke22);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean2 = dateAxis1.isNegativeArrowVisible();
        dateAxis1.setAutoRangeMinimumSize((double) (short) 1, true);
        java.awt.Shape shape6 = dateAxis1.getUpArrow();
        dateAxis1.setInverted(false);
        java.text.DateFormat dateFormat9 = dateAxis1.getDateFormatOverride();
        try {
            dateAxis1.zoomRange((double) 64, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (64.0) <= upper (0.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNull(dateFormat9);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        java.awt.Paint paint7 = categoryPlot6.getDomainGridlinePaint();
        categoryPlot6.setBackgroundImageAlignment(1);
        categoryPlot6.mapDatasetToRangeAxis((int) ' ', 100);
        java.awt.Stroke stroke13 = categoryPlot6.getRangeCrosshairStroke();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        java.awt.Paint paint5 = xYPlot0.getOutlinePaint();
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        xYPlot7.setRangeZeroBaselineVisible(false);
        boolean boolean10 = xYPlot7.isOutlineVisible();
        xYPlot7.clearRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot7.setDomainAxisLocation(64, axisLocation13);
        xYPlot0.setDomainAxisLocation(2, axisLocation13);
        org.jfree.chart.axis.AxisLocation axisLocation16 = xYPlot0.getDomainAxisLocation();
        xYPlot0.zoom((double) 100.0f);
        java.awt.Paint paint19 = xYPlot0.getDomainZeroBaselinePaint();
        boolean boolean20 = xYPlot0.isDomainZoomable();
        java.awt.Graphics2D graphics2D21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        org.jfree.chart.plot.CrosshairState crosshairState25 = null;
        boolean boolean26 = xYPlot0.render(graphics2D21, rectangle2D22, (-16777216), plotRenderingInfo24, crosshairState25);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = dateAxis3.getTickLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        dateAxis8.setTickLabelPaint((java.awt.Paint) color9);
        boolean boolean11 = rectangleInsets7.equals((java.lang.Object) dateAxis8);
        java.lang.String str12 = rectangleInsets7.toString();
        org.jfree.chart.util.UnitType unitType13 = rectangleInsets7.getUnitType();
        double double14 = rectangleInsets7.getBottom();
        double double16 = rectangleInsets7.calculateRightInset(0.0d);
        double double18 = rectangleInsets7.calculateTopOutset((double) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str12.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
        org.junit.Assert.assertNotNull(unitType13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 2.0d + "'", double14 == 2.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 4.0d + "'", double16 == 4.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 2.0d + "'", double18 == 2.0d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        xYPlot0.setDataset(xYDataset5);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        xYPlot0.setDomainTickBandPaint((java.awt.Paint) color7);
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot0.getRangeAxis();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range13 = dateAxis12.getDefaultAutoRange();
        java.awt.Paint paint14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        dateAxis12.setAxisLinePaint(paint14);
        dateAxis12.setAutoRange(true);
        xYPlot0.setDomainAxis(192, (org.jfree.chart.axis.ValueAxis) dateAxis12);
        org.jfree.chart.axis.AxisSpace axisSpace19 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace19, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        xYPlot0.zoomDomainAxes(14.0d, plotRenderingInfo23, point2D24, false);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setRangeCrosshairStroke(stroke5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range12 = dateAxis11.getDefaultAutoRange();
        xYPlot9.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis11);
        org.jfree.chart.plot.Marker marker14 = null;
        boolean boolean15 = xYPlot9.removeDomainMarker(marker14);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        xYPlot9.zoomRangeAxes((double) (byte) 10, plotRenderingInfo17, point2D18, false);
        java.util.List list21 = xYPlot9.getAnnotations();
        xYPlot0.drawDomainTickBands(graphics2D7, rectangle2D8, list21);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(list21);
    }

//    @Test
//    public void test042() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test042");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getMiddleMillisecond();
//        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
//        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("hi!");
//        boolean boolean6 = dateAxis5.isNegativeArrowVisible();
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer7);
//        boolean boolean9 = categoryPlot8.isOutlineVisible();
//        categoryPlot8.mapDatasetToDomainAxis(100, (int) 'a');
//        int int13 = day0.compareTo((java.lang.Object) 100);
//        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
//        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
//        boolean boolean18 = dateAxis17.isNegativeArrowVisible();
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, (org.jfree.chart.axis.ValueAxis) dateAxis17, categoryItemRenderer19);
//        categoryPlot20.clearRangeMarkers(0);
//        org.jfree.chart.axis.AxisLocation axisLocation24 = categoryPlot20.getRangeAxisLocation(10);
//        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot();
//        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("hi!");
//        org.jfree.data.Range range28 = dateAxis27.getDefaultAutoRange();
//        xYPlot25.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis27);
//        java.awt.Paint paint30 = xYPlot25.getOutlinePaint();
//        org.jfree.chart.util.RectangleEdge rectangleEdge31 = xYPlot25.getRangeAxisEdge();
//        org.jfree.chart.plot.PlotOrientation plotOrientation32 = xYPlot25.getOrientation();
//        org.jfree.chart.util.RectangleEdge rectangleEdge33 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation24, plotOrientation32);
//        boolean boolean34 = day0.equals((java.lang.Object) rectangleEdge33);
//        int int35 = day0.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560452399999L + "'", long1 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(axisLocation24);
//        org.junit.Assert.assertNotNull(range28);
//        org.junit.Assert.assertNotNull(paint30);
//        org.junit.Assert.assertNotNull(rectangleEdge31);
//        org.junit.Assert.assertNotNull(plotOrientation32);
//        org.junit.Assert.assertNotNull(rectangleEdge33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 13 + "'", int35 == 13);
//    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeZeroBaselineVisible(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder3 = xYPlot0.getDatasetRenderingOrder();
        xYPlot0.setDomainCrosshairLockedOnData(false);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        java.awt.Stroke stroke8 = numberAxis7.getTickMarkStroke();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit9 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis7.setTickUnit(numberTickUnit9);
        boolean boolean11 = xYPlot0.equals((java.lang.Object) numberTickUnit9);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation12 = null;
        try {
            xYPlot0.addAnnotation(xYAnnotation12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(datasetRenderingOrder3);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(numberTickUnit9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean5 = dateAxis4.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        boolean boolean8 = categoryPlot7.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = categoryPlot7.getDrawingSupplier();
        categoryPlot7.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = categoryPlot7.getDomainAxisEdge(10);
        boolean boolean13 = categoryPlot7.isRangeZoomable();
        categoryPlot7.setOutlineVisible(true);
        org.jfree.chart.util.SortOrder sortOrder16 = categoryPlot7.getRowRenderingOrder();
        boolean boolean17 = rectangleAnchor0.equals((java.lang.Object) categoryPlot7);
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range21 = dateAxis20.getDefaultAutoRange();
        xYPlot18.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis20);
        java.awt.Paint paint23 = xYPlot18.getOutlinePaint();
        categoryPlot7.setRangeCrosshairPaint(paint23);
        float float25 = categoryPlot7.getBackgroundAlpha();
        categoryPlot7.setDomainGridlinesVisible(true);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(drawingSupplier9);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(sortOrder16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 1.0f + "'", float25 == 1.0f);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot6.getDrawingSupplier();
        categoryPlot6.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot6.getDomainAxisEdge(10);
        boolean boolean12 = categoryPlot6.isRangeZoomable();
        java.awt.Stroke stroke13 = categoryPlot6.getRangeGridlineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset15 = categoryPlot6.getDataset(11);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNull(categoryDataset15);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean2 = dateAxis1.isNegativeArrowVisible();
        dateAxis1.setAutoRangeMinimumSize((double) (short) 1, true);
        java.awt.Shape shape6 = dateAxis1.getUpArrow();
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean11 = dateAxis10.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis10, categoryItemRenderer12);
        dateAxis10.resizeRange((double) 100.0f);
        java.util.Date date16 = dateAxis10.getMaximumDate();
        dateAxis1.setMaximumDate(date16);
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range21 = dateAxis20.getDefaultAutoRange();
        xYPlot18.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis20);
        java.awt.Paint paint23 = xYPlot18.getOutlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        xYPlot18.zoomRangeAxes((double) (byte) 100, plotRenderingInfo25, point2D26, false);
        java.awt.Stroke stroke29 = xYPlot18.getRangeGridlineStroke();
        java.awt.Color color30 = org.jfree.chart.ChartColor.DARK_YELLOW;
        xYPlot18.setRangeGridlinePaint((java.awt.Paint) color30);
        org.jfree.chart.axis.DateTickUnit dateTickUnit32 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        boolean boolean33 = xYPlot18.equals((java.lang.Object) dateTickUnit32);
        java.util.Date date34 = dateAxis1.calculateHighestVisibleTickValue(dateTickUnit32);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(dateTickUnit32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(date34);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.END;
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        boolean boolean2 = categoryAnchor0.equals((java.lang.Object) font1);
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean5 = dateAxis4.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        org.jfree.data.Range range8 = dateAxis4.getRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis4);
        dateAxis4.resizeRange((double) 8);
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        xYPlot12.setRangeZeroBaselineVisible(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder15 = xYPlot12.getDatasetRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation17 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot12.setRangeAxisLocation((int) (byte) 100, axisLocation17);
        xYPlot12.setRangeCrosshairVisible(false);
        boolean boolean21 = xYPlot12.isRangeZeroBaselineVisible();
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        xYPlot12.setDomainGridlinePaint((java.awt.Paint) color22);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer25 = xYPlot12.getRenderer((int) '4');
        dateAxis4.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot12);
        org.jfree.chart.axis.AxisLocation axisLocation27 = xYPlot12.getRangeAxisLocation();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        xYPlot12.setRenderer((int) '#', xYItemRenderer29);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(datasetRenderingOrder15);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNull(xYItemRenderer25);
        org.junit.Assert.assertNotNull(axisLocation27);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = dateAxis3.getTickLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        dateAxis8.setTickLabelPaint((java.awt.Paint) color9);
        boolean boolean11 = rectangleInsets7.equals((java.lang.Object) dateAxis8);
        boolean boolean12 = dateAxis8.isTickMarksVisible();
        org.jfree.chart.axis.Timeline timeline13 = null;
        dateAxis8.setTimeline(timeline13);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

//    @Test
//    public void test050() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test050");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getMiddleMillisecond();
//        int int2 = day0.getDayOfMonth();
//        long long3 = day0.getFirstMillisecond();
//        long long4 = day0.getMiddleMillisecond();
//        org.jfree.data.time.SerialDate serialDate5 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day0.previous();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560452399999L + "'", long1 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560452399999L + "'", long4 == 1560452399999L);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        dateAxis2.setUpperMargin(100.0d);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.axis.AxisState axisState8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        java.util.List list11 = dateAxis2.refreshTicks(graphics2D7, axisState8, rectangle2D9, rectangleEdge10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = dateAxis2.getLabelInsets();
        dateAxis2.centerRange((double) 100L);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNull(list11);
        org.junit.Assert.assertNotNull(rectangleInsets12);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range2 = dateAxis1.getDefaultAutoRange();
        java.awt.Paint paint3 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        dateAxis1.setAxisLinePaint(paint3);
        dateAxis1.setAutoRange(true);
        boolean boolean7 = dateAxis1.isNegativeArrowVisible();
        java.awt.Paint paint8 = dateAxis1.getLabelPaint();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        java.awt.Color color1 = java.awt.Color.green;
        java.awt.Color color2 = java.awt.Color.getColor("java.awt.Color[r=0,g=0,b=128]", color1);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        dateAxis2.setUpperMargin(100.0d);
        dateAxis2.setPositiveArrowVisible(false);
        java.awt.Stroke stroke9 = dateAxis2.getTickMarkStroke();
        double double10 = dateAxis2.getLowerBound();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("SeriesRenderingOrder.FORWARD");
        categoryAxis1.setUpperMargin(0.2d);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range8 = dateAxis7.getDefaultAutoRange();
        xYPlot5.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis7);
        java.awt.Paint paint10 = xYPlot5.getOutlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        xYPlot5.zoomRangeAxes((double) (byte) 100, plotRenderingInfo12, point2D13, false);
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = null;
        org.jfree.chart.axis.AxisSpace axisSpace18 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace19 = categoryAxis1.reserveSpace(graphics2D4, (org.jfree.chart.plot.Plot) xYPlot5, rectangle2D16, rectangleEdge17, axisSpace18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        org.jfree.chart.plot.Marker marker5 = null;
        boolean boolean6 = xYPlot0.removeDomainMarker(marker5);
        xYPlot0.setDomainCrosshairValue((double) (-1), true);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean12 = dateAxis11.isNegativeArrowVisible();
        dateAxis11.setAutoRangeMinimumSize((double) (short) 1, true);
        org.jfree.chart.axis.Timeline timeline16 = null;
        dateAxis11.setTimeline(timeline16);
        boolean boolean18 = xYPlot0.equals((java.lang.Object) dateAxis11);
        boolean boolean19 = dateAxis11.isTickLabelsVisible();
        double double20 = dateAxis11.getUpperBound();
        dateAxis11.setLowerBound((double) 1L);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range4 = dateAxis3.getDefaultAutoRange();
        xYPlot1.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis3);
        java.awt.Paint paint6 = xYPlot1.getOutlinePaint();
        xYPlot1.setRangeCrosshairValue(1.0E-8d);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        xYPlot1.setAxisOffset(rectangleInsets9);
        org.jfree.chart.util.UnitType unitType11 = rectangleInsets9.getUnitType();
        boolean boolean12 = numberAxis0.equals((java.lang.Object) rectangleInsets9);
        boolean boolean13 = numberAxis0.getAutoRangeIncludesZero();
        boolean boolean14 = numberAxis0.isVerticalTickLabels();
        numberAxis0.setTickMarkOutsideLength((float) (short) 0);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(unitType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getCategoryLabelPositionOffset();
        int int2 = categoryAxis0.getCategoryLabelPositionOffset();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        java.awt.Paint paint5 = xYPlot0.getOutlinePaint();
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        xYPlot7.setRangeZeroBaselineVisible(false);
        boolean boolean10 = xYPlot7.isOutlineVisible();
        xYPlot7.clearRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot7.setDomainAxisLocation(64, axisLocation13);
        xYPlot0.setDomainAxisLocation(2, axisLocation13);
        org.jfree.chart.axis.AxisLocation axisLocation16 = xYPlot0.getDomainAxisLocation();
        xYPlot0.zoom((double) 100.0f);
        java.awt.Paint paint19 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        xYPlot0.setDataset(xYDataset20);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder22 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        try {
            xYPlot0.handleClick(11, 4, plotRenderingInfo25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(seriesRenderingOrder22);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean2 = dateAxis1.isNegativeArrowVisible();
        dateAxis1.setAutoRangeMinimumSize((double) (short) 1, true);
        org.jfree.chart.axis.Timeline timeline6 = null;
        dateAxis1.setTimeline(timeline6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean12 = dateAxis11.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis11, categoryItemRenderer13);
        boolean boolean15 = categoryPlot14.isOutlineVisible();
        java.awt.Paint paint16 = categoryPlot14.getDomainGridlinePaint();
        java.lang.String str17 = categoryPlot14.getNoDataMessage();
        dateAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot14);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = categoryPlot14.getDomainAxisEdge((int) '#');
        java.lang.String str21 = categoryPlot14.getNoDataMessage();
        categoryPlot14.configureRangeAxes();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNull(str21);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = dateAxis3.getTickLabelInsets();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis3.getTickUnit();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(dateTickUnit8);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean2 = dateAxis1.isNegativeArrowVisible();
        dateAxis1.setAutoRangeMinimumSize((double) (short) 1, true);
        boolean boolean6 = dateAxis1.isAxisLineVisible();
        dateAxis1.setAutoTickUnitSelection(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = dateAxis1.getTickLabelInsets();
        org.jfree.chart.axis.TickUnitSource tickUnitSource10 = dateAxis1.getStandardTickUnits();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(tickUnitSource10);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        int int3 = java.awt.Color.HSBtoRGB(0.0f, 0.0f, (float) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-52) + "'", int3 == (-52));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot6.getDrawingSupplier();
        categoryPlot6.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot6.getDomainAxisEdge(10);
        boolean boolean12 = categoryPlot6.isRangeZoomable();
        java.awt.Paint paint13 = categoryPlot6.getDomainGridlinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = categoryPlot6.getDomainAxis();
        float float15 = categoryPlot6.getForegroundAlpha();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(categoryAxis14);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 1.0f + "'", float15 == 1.0f);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        java.awt.Paint paint7 = categoryPlot6.getDomainGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot6.getRenderer((int) (byte) 0);
        categoryPlot6.setRangeGridlinesVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = categoryPlot6.getAxisOffset();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(categoryItemRenderer9);
        org.junit.Assert.assertNotNull(rectangleInsets12);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot6.getDrawingSupplier();
        categoryPlot6.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot6.getDomainAxisEdge(10);
        boolean boolean12 = categoryPlot6.isRangeZoomable();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        categoryPlot6.setRenderer(categoryItemRenderer13, true);
        org.jfree.chart.axis.AxisLocation axisLocation17 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot6.setRangeAxisLocation((int) 'a', axisLocation17, false);
        java.awt.Stroke stroke20 = categoryPlot6.getRangeCrosshairStroke();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        java.awt.Paint paint5 = xYPlot0.getOutlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        xYPlot0.zoomRangeAxes((double) (byte) 100, plotRenderingInfo7, point2D8, false);
        java.awt.Stroke stroke11 = xYPlot0.getRangeGridlineStroke();
        int int12 = xYPlot0.getRangeAxisCount();
        xYPlot0.setRangeCrosshairValue((double) (-1));
        java.awt.Paint paint15 = xYPlot0.getRangeCrosshairPaint();
        java.awt.Paint paint17 = xYPlot0.getQuadrantPaint(0);
        java.awt.Color color19 = java.awt.Color.LIGHT_GRAY;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean25 = dateAxis24.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, (org.jfree.chart.axis.ValueAxis) dateAxis24, categoryItemRenderer26);
        org.jfree.data.Range range28 = dateAxis24.getRange();
        xYPlot20.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis24);
        java.awt.Stroke stroke30 = xYPlot20.getDomainCrosshairStroke();
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot();
        xYPlot31.setRangeZeroBaselineVisible(false);
        boolean boolean34 = xYPlot31.isOutlineVisible();
        xYPlot31.clearRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation37 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot31.setDomainAxisLocation(64, axisLocation37);
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean41 = dateAxis40.isNegativeArrowVisible();
        double double42 = dateAxis40.getLowerBound();
        java.awt.Paint paint43 = dateAxis40.getTickLabelPaint();
        java.awt.Stroke stroke44 = dateAxis40.getAxisLineStroke();
        xYPlot31.setDomainGridlineStroke(stroke44);
        xYPlot20.setRangeCrosshairStroke(stroke44);
        org.jfree.chart.plot.CategoryMarker categoryMarker47 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]", (java.awt.Paint) color19, stroke44);
        xYPlot0.setDomainZeroBaselineStroke(stroke44);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(stroke44);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis1.resizeRange((double) 255);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeZeroBaselineVisible(false);
        boolean boolean3 = xYPlot0.isOutlineVisible();
        xYPlot0.clearRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation6 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot0.setDomainAxisLocation(64, axisLocation6);
        java.awt.Color color8 = java.awt.Color.WHITE;
        xYPlot0.setRangeTickBandPaint((java.awt.Paint) color8);
        xYPlot0.configureRangeAxes();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation11 = null;
        try {
            xYPlot0.addAnnotation(xYAnnotation11, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean5 = dateAxis4.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        org.jfree.data.Range range8 = dateAxis4.getRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis4);
        java.awt.Stroke stroke10 = xYPlot0.getDomainCrosshairStroke();
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        xYPlot11.setRangeZeroBaselineVisible(false);
        boolean boolean14 = xYPlot11.isOutlineVisible();
        xYPlot11.clearRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation17 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot11.setDomainAxisLocation(64, axisLocation17);
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean21 = dateAxis20.isNegativeArrowVisible();
        double double22 = dateAxis20.getLowerBound();
        java.awt.Paint paint23 = dateAxis20.getTickLabelPaint();
        java.awt.Stroke stroke24 = dateAxis20.getAxisLineStroke();
        xYPlot11.setDomainGridlineStroke(stroke24);
        xYPlot0.setRangeCrosshairStroke(stroke24);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = xYPlot0.getDomainAxisEdge((int) (short) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray29 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot0.setRenderers(xYItemRendererArray29);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertNotNull(xYItemRendererArray29);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        dateAxis3.setLowerBound((double) 13);
        java.lang.String str9 = dateAxis3.getLabel();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        java.awt.Paint paint5 = xYPlot0.getOutlinePaint();
        xYPlot0.setRangeCrosshairValue(1.0E-8d);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        xYPlot0.setAxisOffset(rectangleInsets8);
        org.jfree.chart.util.UnitType unitType10 = rectangleInsets8.getUnitType();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = new org.jfree.chart.util.RectangleInsets(unitType10, (double) (byte) 0, (double) 15, 0.0d, (double) 2);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets(unitType10, (double) 13, 0.0d, 100.0d, 0.0d);
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D24 = rectangleInsets20.createInsetRectangle(rectangle2D21, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(unitType10);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 3, 100.0d);
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range6 = dateAxis5.getDefaultAutoRange();
        xYPlot3.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis5);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot3.setRangeCrosshairStroke(stroke8);
        intervalMarker2.setStroke(stroke8);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.CENTER;
        intervalMarker2.setLabelAnchor(rectangleAnchor11);
        java.awt.Color color13 = java.awt.Color.red;
        intervalMarker2.setLabelPaint((java.awt.Paint) color13);
        org.jfree.chart.text.TextAnchor textAnchor15 = intervalMarker2.getLabelTextAnchor();
        intervalMarker2.setEndValue((double) (byte) -1);
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean22 = dateAxis21.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis21, categoryItemRenderer23);
        boolean boolean25 = categoryPlot24.isOutlineVisible();
        java.awt.Paint paint26 = categoryPlot24.getDomainGridlinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = categoryPlot24.getDomainAxisForDataset((int) (short) 0);
        org.jfree.data.category.CategoryDataset categoryDataset29 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = null;
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean33 = dateAxis32.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset29, categoryAxis30, (org.jfree.chart.axis.ValueAxis) dateAxis32, categoryItemRenderer34);
        org.jfree.data.Range range36 = dateAxis32.getRange();
        int int37 = categoryPlot24.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis32);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent38 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot24);
        intervalMarker2.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot24);
        org.jfree.chart.plot.Marker marker41 = null;
        org.jfree.chart.plot.XYPlot xYPlot42 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range45 = dateAxis44.getDefaultAutoRange();
        xYPlot42.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis44);
        java.awt.Paint paint47 = xYPlot42.getOutlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo49 = null;
        java.awt.geom.Point2D point2D50 = null;
        xYPlot42.zoomRangeAxes((double) (byte) 100, plotRenderingInfo49, point2D50, false);
        java.awt.Stroke stroke53 = xYPlot42.getDomainCrosshairStroke();
        org.jfree.chart.util.Layer layer55 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean57 = layer55.equals((java.lang.Object) true);
        java.util.Collection collection58 = xYPlot42.getRangeMarkers(3, layer55);
        try {
            categoryPlot24.addRangeMarker((int) '4', marker41, layer55, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(textAnchor15);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNull(categoryAxis28);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(range36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertNotNull(range45);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(layer55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNull(collection58);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        java.awt.Paint paint8 = categoryPlot6.getDomainGridlinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot6.getDomainAxisForDataset((int) (short) 0);
        java.awt.Font font11 = categoryPlot6.getNoDataMessageFont();
        boolean boolean12 = categoryPlot6.isDomainGridlinesVisible();
        categoryPlot6.configureRangeAxes();
        java.lang.Object obj14 = categoryPlot6.clone();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("CONTRACT");
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.lang.String str1 = rectangleAnchor0.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleAnchor.TOP_RIGHT" + "'", str1.equals("RectangleAnchor.TOP_RIGHT"));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        dateAxis3.resizeRange((double) 100.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = dateAxis3.getLabelInsets();
        dateAxis3.resizeRange((double) 100L);
        org.jfree.data.time.DateRange dateRange12 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis3.setRange((org.jfree.data.Range) dateRange12);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(dateRange12);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        java.awt.Stroke stroke4 = numberAxis3.getTickMarkStroke();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis3.setTickUnit(numberTickUnit5);
        numberAxis1.setTickUnit(numberTickUnit5, false, false);
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        java.awt.Stroke stroke14 = numberAxis13.getTickMarkStroke();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit15 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis13.setTickUnit(numberTickUnit15);
        numberAxis11.setTickUnit(numberTickUnit15);
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        java.awt.Stroke stroke22 = numberAxis21.getTickMarkStroke();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit23 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis21.setTickUnit(numberTickUnit23);
        numberAxis19.setTickUnit(numberTickUnit23);
        numberAxis11.setTickUnit(numberTickUnit23);
        numberAxis1.setTickUnit(numberTickUnit23, true, false);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(numberTickUnit5);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(numberTickUnit15);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(numberTickUnit23);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        xYPlot0.setDataset(xYDataset5);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        xYPlot0.setDomainTickBandPaint((java.awt.Paint) color7);
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot0.getRangeAxis();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range13 = dateAxis12.getDefaultAutoRange();
        java.awt.Paint paint14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        dateAxis12.setAxisLinePaint(paint14);
        dateAxis12.setAutoRange(true);
        xYPlot0.setDomainAxis(192, (org.jfree.chart.axis.ValueAxis) dateAxis12);
        java.awt.Paint paint19 = xYPlot0.getDomainGridlinePaint();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot6.getDrawingSupplier();
        java.lang.Object obj9 = null;
        boolean boolean10 = categoryPlot6.equals(obj9);
        categoryPlot6.clearRangeMarkers(3);
        categoryPlot6.configureDomainAxes();
        org.jfree.chart.LegendItemCollection legendItemCollection14 = categoryPlot6.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        categoryPlot6.setRangeAxis(11, valueAxis16, false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(legendItemCollection14);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        java.awt.Paint paint5 = xYPlot0.getOutlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        xYPlot0.zoomRangeAxes((double) (byte) 100, plotRenderingInfo7, point2D8, false);
        java.awt.Stroke stroke11 = xYPlot0.getRangeGridlineStroke();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double15 = rectangleInsets13.calculateTopOutset(0.0d);
        double double16 = rectangleInsets13.getTop();
        boolean boolean17 = seriesRenderingOrder12.equals((java.lang.Object) rectangleInsets13);
        java.lang.String str18 = seriesRenderingOrder12.toString();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 4.0d + "'", double15 == 4.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 4.0d + "'", double16 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "SeriesRenderingOrder.REVERSE" + "'", str18.equals("SeriesRenderingOrder.REVERSE"));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
    }

//    @Test
//    public void test083() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test083");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getMiddleMillisecond();
//        int int2 = day0.getDayOfMonth();
//        long long3 = day0.getFirstMillisecond();
//        int int4 = day0.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560452399999L + "'", long1 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 13 + "'", int4 == 13);
//    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = categoryPlot6.getLegendItems();
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range12 = dateAxis11.getDefaultAutoRange();
        xYPlot9.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis11);
        java.awt.Paint paint14 = xYPlot9.getOutlinePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = xYPlot9.getRangeAxisEdge();
        org.jfree.chart.plot.PlotOrientation plotOrientation16 = xYPlot9.getOrientation();
        categoryPlot6.setOrientation(plotOrientation16);
        org.jfree.chart.axis.ValueAxis valueAxis19 = categoryPlot6.getRangeAxisForDataset(8);
        java.awt.Paint paint20 = categoryPlot6.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = categoryPlot6.getRangeAxisEdge((-1));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(legendItemCollection8);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(plotOrientation16);
        org.junit.Assert.assertNotNull(valueAxis19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(rectangleEdge22);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("SeriesRenderingOrder.FORWARD");
        categoryAxis1.setUpperMargin(0.2d);
        float float4 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        categoryAxis1.clearCategoryLabelToolTips();
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) 3.0d, "ChartChangeEventType.DATASET_UPDATED");
        categoryAxis0.setMaximumCategoryLabelLines((int) ' ');
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions6 = null;
        try {
            categoryAxis0.setCategoryLabelPositions(categoryLabelPositions6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'positions' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeZeroBaselineVisible(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder3 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot0.setRangeAxisLocation((int) (byte) 100, axisLocation5);
        boolean boolean7 = xYPlot0.isDomainGridlinesVisible();
        xYPlot0.setOutlineVisible(true);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder10 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean13 = dateAxis12.isNegativeArrowVisible();
        double double14 = dateAxis12.getLowerBound();
        dateAxis12.setAutoRange(false);
        org.jfree.data.Range range17 = xYPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis12);
        java.awt.Stroke stroke18 = xYPlot0.getRangeZeroBaselineStroke();
        org.junit.Assert.assertNotNull(datasetRenderingOrder3);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(seriesRenderingOrder10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 0.0f, (float) 2);
        java.awt.Color color6 = java.awt.Color.getColor("ChartChangeEventType.DATASET_UPDATED", color5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Paint paint8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker((double) 15, (java.awt.Paint) color5, stroke7, paint8, stroke9, 0.0f);
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker((double) 11);
        java.awt.Paint paint14 = valueMarker13.getPaint();
        valueMarker13.setValue(8.0d);
        org.jfree.chart.plot.IntervalMarker intervalMarker19 = new org.jfree.chart.plot.IntervalMarker((double) 3, 100.0d);
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range23 = dateAxis22.getDefaultAutoRange();
        xYPlot20.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis22);
        java.awt.Stroke stroke25 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot20.setRangeCrosshairStroke(stroke25);
        intervalMarker19.setStroke(stroke25);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor28 = org.jfree.chart.util.RectangleAnchor.CENTER;
        intervalMarker19.setLabelAnchor(rectangleAnchor28);
        valueMarker13.setLabelAnchor(rectangleAnchor28);
        valueMarker11.setLabelAnchor(rectangleAnchor28);
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean36 = dateAxis35.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, (org.jfree.chart.axis.ValueAxis) dateAxis35, categoryItemRenderer37);
        boolean boolean39 = categoryPlot38.isOutlineVisible();
        java.awt.Paint paint40 = categoryPlot38.getDomainGridlinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = categoryPlot38.getDomainAxisForDataset((int) (short) 0);
        java.awt.Font font43 = categoryPlot38.getNoDataMessageFont();
        java.util.List list44 = categoryPlot38.getAnnotations();
        boolean boolean45 = valueMarker11.equals((java.lang.Object) categoryPlot38);
        java.awt.Paint paint46 = categoryPlot38.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = new org.jfree.chart.axis.CategoryAxis();
        int int48 = categoryAxis47.getMaximumCategoryLabelLines();
        int int49 = categoryPlot38.getDomainAxisIndex(categoryAxis47);
        categoryAxis47.setLabel("java.awt.Color[r=0,g=0,b=128]");
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(rectangleAnchor28);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNull(categoryAxis42);
        org.junit.Assert.assertNotNull(font43);
        org.junit.Assert.assertNotNull(list44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeZeroBaselineVisible(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder3 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot0.setRangeAxisLocation((int) (byte) 100, axisLocation5);
        xYPlot0.setRangeCrosshairVisible(false);
        boolean boolean9 = xYPlot0.isRangeZeroBaselineVisible();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        xYPlot0.setDomainGridlinePaint((java.awt.Paint) color10);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean16 = dateAxis15.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, (org.jfree.chart.axis.ValueAxis) dateAxis15, categoryItemRenderer17);
        boolean boolean19 = categoryPlot18.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier20 = categoryPlot18.getDrawingSupplier();
        categoryPlot18.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = categoryPlot18.getDomainAxisEdge(10);
        boolean boolean24 = categoryPlot18.isRangeZoomable();
        java.awt.Paint paint25 = categoryPlot18.getDomainGridlinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = categoryPlot18.getDomainAxis();
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range30 = dateAxis29.getDefaultAutoRange();
        xYPlot27.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis29);
        java.awt.Paint paint32 = xYPlot27.getOutlinePaint();
        xYPlot27.setRangeCrosshairValue(1.0E-8d);
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        xYPlot27.setAxisOffset(rectangleInsets35);
        org.jfree.chart.util.UnitType unitType37 = rectangleInsets35.getUnitType();
        categoryPlot18.setAxisOffset(rectangleInsets35);
        xYPlot0.setInsets(rectangleInsets35, true);
        double double42 = rectangleInsets35.calculateBottomInset(0.0d);
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType44 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType45 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        try {
            java.awt.geom.Rectangle2D rectangle2D46 = rectangleInsets35.createAdjustedRectangle(rectangle2D43, lengthAdjustmentType44, lengthAdjustmentType45);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(datasetRenderingOrder3);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(drawingSupplier20);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(categoryAxis26);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertNotNull(unitType37);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 4.0d + "'", double42 == 4.0d);
        org.junit.Assert.assertNotNull(lengthAdjustmentType45);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isTickMarksVisible();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean6 = dateAxis5.isNegativeArrowVisible();
        dateAxis5.setAutoRangeMinimumSize((double) (short) 1, true);
        org.jfree.chart.axis.Timeline timeline10 = null;
        dateAxis5.setTimeline(timeline10);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean16 = dateAxis15.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, (org.jfree.chart.axis.ValueAxis) dateAxis15, categoryItemRenderer17);
        boolean boolean19 = categoryPlot18.isOutlineVisible();
        java.awt.Paint paint20 = categoryPlot18.getDomainGridlinePaint();
        java.lang.String str21 = categoryPlot18.getNoDataMessage();
        dateAxis5.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot18);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = categoryPlot18.getDomainAxisEdge((int) '#');
        try {
            double double25 = dateAxis0.java2DToValue((double) 64, rectangle2D3, rectangleEdge24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(rectangleEdge24);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = dateAxis3.getTickLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        dateAxis8.setTickLabelPaint((java.awt.Paint) color9);
        boolean boolean11 = rectangleInsets7.equals((java.lang.Object) dateAxis8);
        double double13 = rectangleInsets7.calculateBottomInset(1.0E-8d);
        double double15 = rectangleInsets7.calculateRightOutset((double) 100);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.0d + "'", double13 == 2.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 4.0d + "'", double15 == 4.0d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        xYPlot0.setDataset(xYDataset5);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        xYPlot0.setDomainTickBandPaint((java.awt.Paint) color7);
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot0.getRangeAxis();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range13 = dateAxis12.getDefaultAutoRange();
        java.awt.Paint paint14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        dateAxis12.setAxisLinePaint(paint14);
        dateAxis12.setAutoRange(true);
        xYPlot0.setDomainAxis(192, (org.jfree.chart.axis.ValueAxis) dateAxis12);
        boolean boolean19 = xYPlot0.isDomainZeroBaselineVisible();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot6.getDrawingSupplier();
        categoryPlot6.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot6.getDomainAxisEdge(10);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = categoryPlot6.getDomainAxis();
        categoryPlot6.setDomainGridlinesVisible(true);
        categoryPlot6.setDrawSharedDomainAxis(false);
        float float17 = categoryPlot6.getBackgroundAlpha();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNull(categoryAxis12);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 1.0f + "'", float17 == 1.0f);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        java.awt.Paint paint5 = xYPlot0.getOutlinePaint();
        xYPlot0.setRangeCrosshairValue(1.0E-8d);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        xYPlot0.setAxisOffset(rectangleInsets8);
        double double11 = rectangleInsets8.calculateBottomInset(0.0d);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("CategoryAnchor.END");
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        dateAxis3.resizeRange((double) 100.0f);
        java.util.Date date9 = dateAxis3.getMaximumDate();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date9);
        long long11 = day10.getSerialIndex();
        int int12 = day10.getMonth();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 25568L + "'", long11 == 25568L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 12 + "'", int12 == 12);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        java.lang.String str1 = textAnchor0.toString();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextAnchor.CENTER_LEFT" + "'", str1.equals("TextAnchor.CENTER_LEFT"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        java.awt.Paint paint8 = categoryPlot6.getDomainGridlinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot6.getDomainAxisForDataset((int) (short) 0);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean15 = dateAxis14.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis14, categoryItemRenderer16);
        org.jfree.data.Range range18 = dateAxis14.getRange();
        int int19 = categoryPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis14);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent20 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot6);
        java.awt.Stroke stroke21 = categoryPlot6.getDomainGridlineStroke();
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range25 = dateAxis24.getDefaultAutoRange();
        xYPlot22.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis24);
        java.awt.Paint paint27 = xYPlot22.getOutlinePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = xYPlot22.getRangeAxisEdge();
        org.jfree.chart.plot.PlotOrientation plotOrientation29 = xYPlot22.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection30 = xYPlot22.getLegendItems();
        categoryPlot6.setFixedLegendItems(legendItemCollection30);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertNotNull(plotOrientation29);
        org.junit.Assert.assertNotNull(legendItemCollection30);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 0.0f, (float) 2);
        java.awt.Color color6 = java.awt.Color.getColor("ChartChangeEventType.DATASET_UPDATED", color5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Paint paint8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker((double) 15, (java.awt.Paint) color5, stroke7, paint8, stroke9, 0.0f);
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker((double) 11);
        java.awt.Paint paint14 = valueMarker13.getPaint();
        valueMarker13.setValue(8.0d);
        org.jfree.chart.plot.IntervalMarker intervalMarker19 = new org.jfree.chart.plot.IntervalMarker((double) 3, 100.0d);
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range23 = dateAxis22.getDefaultAutoRange();
        xYPlot20.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis22);
        java.awt.Stroke stroke25 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot20.setRangeCrosshairStroke(stroke25);
        intervalMarker19.setStroke(stroke25);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor28 = org.jfree.chart.util.RectangleAnchor.CENTER;
        intervalMarker19.setLabelAnchor(rectangleAnchor28);
        valueMarker13.setLabelAnchor(rectangleAnchor28);
        valueMarker11.setLabelAnchor(rectangleAnchor28);
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean36 = dateAxis35.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, (org.jfree.chart.axis.ValueAxis) dateAxis35, categoryItemRenderer37);
        boolean boolean39 = categoryPlot38.isOutlineVisible();
        java.awt.Paint paint40 = categoryPlot38.getDomainGridlinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = categoryPlot38.getDomainAxisForDataset((int) (short) 0);
        java.awt.Font font43 = categoryPlot38.getNoDataMessageFont();
        java.util.List list44 = categoryPlot38.getAnnotations();
        boolean boolean45 = valueMarker11.equals((java.lang.Object) categoryPlot38);
        java.awt.Paint paint46 = categoryPlot38.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = new org.jfree.chart.axis.CategoryAxis();
        int int48 = categoryAxis47.getMaximumCategoryLabelLines();
        int int49 = categoryPlot38.getDomainAxisIndex(categoryAxis47);
        categoryAxis47.setLabelToolTip("ChartChangeEventType.DATASET_UPDATED");
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(rectangleAnchor28);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNull(categoryAxis42);
        org.junit.Assert.assertNotNull(font43);
        org.junit.Assert.assertNotNull(list44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        java.awt.Paint paint5 = xYPlot0.getOutlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        xYPlot0.zoomRangeAxes((double) (byte) 100, plotRenderingInfo7, point2D8, false);
        java.awt.Stroke stroke11 = xYPlot0.getRangeGridlineStroke();
        int int12 = xYPlot0.getRangeAxisCount();
        xYPlot0.setRangeCrosshairValue((double) (-1));
        org.jfree.chart.axis.AxisLocation axisLocation15 = xYPlot0.getRangeAxisLocation();
        java.lang.String str16 = xYPlot0.getNoDataMessage();
        xYPlot0.setForegroundAlpha((float) 1560452399999L);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNull(str16);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        java.awt.Paint paint8 = categoryPlot6.getDomainGridlinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot6.getDomainAxisForDataset((int) (short) 0);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean15 = dateAxis14.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis14, categoryItemRenderer16);
        org.jfree.data.Range range18 = dateAxis14.getRange();
        int int19 = categoryPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis14);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent20 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot6);
        java.awt.Stroke stroke21 = categoryPlot6.getRangeCrosshairStroke();
        categoryPlot6.clearAnnotations();
        org.jfree.chart.util.Layer layer23 = null;
        java.util.Collection collection24 = categoryPlot6.getRangeMarkers(layer23);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNull(collection24);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        java.awt.Stroke stroke5 = numberAxis4.getTickMarkStroke();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit6 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis4.setTickUnit(numberTickUnit6);
        numberAxis2.setTickUnit(numberTickUnit6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        java.awt.Stroke stroke13 = numberAxis12.getTickMarkStroke();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit14 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis12.setTickUnit(numberTickUnit14);
        numberAxis10.setTickUnit(numberTickUnit14);
        numberAxis2.setTickUnit(numberTickUnit14);
        org.jfree.data.RangeType rangeType18 = numberAxis2.getRangeType();
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        java.awt.Stroke stroke23 = numberAxis22.getTickMarkStroke();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit24 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis22.setTickUnit(numberTickUnit24);
        numberAxis20.setTickUnit(numberTickUnit24);
        numberAxis2.setTickUnit(numberTickUnit24, false, false);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        java.awt.Stroke stroke32 = numberAxis31.getTickMarkStroke();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit33 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis31.setTickUnit(numberTickUnit33);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = null;
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis31, xYItemRenderer35);
        numberAxis31.setTickMarkInsideLength((float) 12);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(numberTickUnit6);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(numberTickUnit14);
        org.junit.Assert.assertNotNull(rangeType18);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(numberTickUnit24);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(numberTickUnit33);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_INSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0 == 0.0f);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        xYPlot0.rendererChanged(rendererChangeEvent5);
        org.jfree.chart.axis.ValueAxis valueAxis7 = xYPlot0.getDomainAxis();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(valueAxis7);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean5 = dateAxis4.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        boolean boolean8 = categoryPlot7.isOutlineVisible();
        java.awt.Paint paint9 = categoryPlot7.getDomainGridlinePaint();
        java.lang.String str10 = categoryPlot7.getNoDataMessage();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        categoryPlot7.setRangeCrosshairPaint((java.awt.Paint) color11);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean15 = dateAxis14.isNegativeArrowVisible();
        double double16 = dateAxis14.getLowerBound();
        java.awt.Paint paint17 = dateAxis14.getTickLabelPaint();
        java.awt.Stroke stroke18 = dateAxis14.getAxisLineStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker19 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-1), (java.awt.Paint) color11, stroke18);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent20 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color11);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
    }

//    @Test
//    public void test106() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test106");
//        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
//        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
//        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
//        boolean boolean7 = categoryPlot6.isOutlineVisible();
//        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot6.getDrawingSupplier();
//        categoryPlot6.clearRangeAxes();
//        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot6.getDomainAxisEdge(10);
//        boolean boolean12 = categoryPlot6.isRangeZoomable();
//        java.awt.Paint paint13 = categoryPlot6.getDomainGridlinePaint();
//        java.awt.Paint paint14 = categoryPlot6.getOutlinePaint();
//        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
//        categoryPlot6.setDataset((int) (short) 1, categoryDataset16);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        long long19 = day18.getMiddleMillisecond();
//        int int20 = day18.getDayOfMonth();
//        long long21 = day18.getFirstMillisecond();
//        long long22 = day18.getMiddleMillisecond();
//        org.jfree.data.time.SerialDate serialDate23 = day18.getSerialDate();
//        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot();
//        xYPlot24.setRangeZeroBaselineVisible(false);
//        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder27 = xYPlot24.getDatasetRenderingOrder();
//        org.jfree.chart.axis.AxisLocation axisLocation29 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
//        xYPlot24.setRangeAxisLocation((int) (byte) 100, axisLocation29);
//        xYPlot24.setRangeCrosshairVisible(false);
//        boolean boolean33 = xYPlot24.isRangeZeroBaselineVisible();
//        java.awt.Color color34 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
//        xYPlot24.setDomainGridlinePaint((java.awt.Paint) color34);
//        int int36 = day18.compareTo((java.lang.Object) color34);
//        categoryPlot6.setRangeCrosshairPaint((java.awt.Paint) color34);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(drawingSupplier8);
//        org.junit.Assert.assertNotNull(rectangleEdge11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertNotNull(paint13);
//        org.junit.Assert.assertNotNull(paint14);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560452399999L + "'", long19 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 13 + "'", int20 == 13);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560409200000L + "'", long21 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560452399999L + "'", long22 == 1560452399999L);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertNotNull(datasetRenderingOrder27);
//        org.junit.Assert.assertNotNull(axisLocation29);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(color34);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeZeroBaselineVisible(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder3 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot0.setRangeAxisLocation((int) (byte) 100, axisLocation5);
        xYPlot0.setRangeCrosshairVisible(false);
        boolean boolean9 = xYPlot0.isRangeZeroBaselineVisible();
        org.jfree.chart.plot.IntervalMarker intervalMarker12 = new org.jfree.chart.plot.IntervalMarker((double) 3, 100.0d);
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range16 = dateAxis15.getDefaultAutoRange();
        xYPlot13.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis15);
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot13.setRangeCrosshairStroke(stroke18);
        intervalMarker12.setStroke(stroke18);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder21 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean23 = datasetRenderingOrder21.equals((java.lang.Object) layer22);
        boolean boolean24 = xYPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker12, layer22);
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint26 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYPlot25.setDomainZeroBaselinePaint(paint26);
        org.jfree.chart.axis.AxisSpace axisSpace28 = xYPlot25.getFixedDomainAxisSpace();
        java.awt.Stroke stroke29 = xYPlot25.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke29);
        org.jfree.chart.axis.AxisLocation axisLocation31 = xYPlot0.getDomainAxisLocation();
        org.jfree.chart.axis.AxisLocation axisLocation32 = xYPlot0.getDomainAxisLocation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        java.awt.geom.Point2D point2D35 = null;
        xYPlot0.zoomDomainAxes(14.0d, plotRenderingInfo34, point2D35);
        org.junit.Assert.assertNotNull(datasetRenderingOrder3);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(datasetRenderingOrder21);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNull(axisSpace28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertNotNull(axisLocation32);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean2 = dateAxis1.isNegativeArrowVisible();
        dateAxis1.setAutoTickUnitSelection(false, false);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range9 = dateAxis8.getDefaultAutoRange();
        xYPlot6.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis8);
        org.jfree.chart.plot.Marker marker11 = null;
        boolean boolean12 = xYPlot6.removeDomainMarker(marker11);
        xYPlot6.setDomainCrosshairValue((double) (-1), true);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean18 = dateAxis17.isNegativeArrowVisible();
        dateAxis17.setAutoRangeMinimumSize((double) (short) 1, true);
        org.jfree.chart.axis.Timeline timeline22 = null;
        dateAxis17.setTimeline(timeline22);
        boolean boolean24 = xYPlot6.equals((java.lang.Object) dateAxis17);
        org.jfree.data.Range range25 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis17.setRange(range25, true, false);
        dateAxis1.setRangeWithMargins(range25);
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = dateAxis1.getLabelInsets();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertNotNull(rectangleInsets30);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        java.awt.Paint paint5 = xYPlot0.getOutlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        xYPlot0.zoomRangeAxes((double) (byte) 100, plotRenderingInfo7, point2D8, false);
        java.awt.Stroke stroke11 = xYPlot0.getRangeGridlineStroke();
        int int12 = xYPlot0.getRangeAxisCount();
        xYPlot0.setRangeCrosshairValue((double) (-1));
        org.jfree.chart.axis.AxisLocation axisLocation15 = xYPlot0.getRangeAxisLocation();
        java.lang.String str16 = xYPlot0.getNoDataMessage();
        java.awt.geom.Point2D point2D17 = null;
        try {
            xYPlot0.setQuadrantOrigin(point2D17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'origin' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNull(str16);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        categoryPlot6.clearRangeMarkers(0);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = null;
        categoryPlot6.markerChanged(markerChangeEvent9);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot6.getDomainAxisEdge();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        int int13 = categoryPlot6.getIndexOf(categoryItemRenderer12);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = categoryPlot6.getRenderer((-100));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNull(categoryItemRenderer15);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        java.awt.Paint paint5 = xYPlot0.getOutlinePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = xYPlot0.getRangeAxisEdge();
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = xYPlot0.getOrientation();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean10 = dateAxis9.isNegativeArrowVisible();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis9);
        java.lang.String str12 = dateAxis9.getLabel();
        try {
            dateAxis9.setAutoRangeMinimumSize(0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(plotOrientation7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        org.jfree.chart.util.Layer layer1 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean2 = datasetRenderingOrder0.equals((java.lang.Object) layer1);
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean7 = dateAxis6.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis6, categoryItemRenderer8);
        java.awt.Paint paint10 = categoryPlot9.getDomainGridlinePaint();
        int int11 = categoryPlot9.getBackgroundImageAlignment();
        boolean boolean12 = datasetRenderingOrder0.equals((java.lang.Object) categoryPlot9);
        org.jfree.data.general.DatasetGroup datasetGroup13 = categoryPlot9.getDatasetGroup();
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertNotNull(layer1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 15 + "'", int11 == 15);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(datasetGroup13);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_CYAN;
        int int1 = color0.getRed();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean2 = dateAxis1.isNegativeArrowVisible();
        dateAxis1.setAutoRangeMinimumSize((double) (short) 1, true);
        boolean boolean6 = dateAxis1.isAxisLineVisible();
        java.awt.Paint paint7 = dateAxis1.getTickMarkPaint();
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean13 = dateAxis12.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis12, categoryItemRenderer14);
        org.jfree.data.Range range16 = dateAxis12.getRange();
        xYPlot8.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis12);
        dateAxis12.resizeRange((double) 8);
        java.awt.Paint paint20 = dateAxis12.getAxisLinePaint();
        dateAxis1.setTickLabelPaint(paint20);
        org.jfree.data.Range range22 = dateAxis1.getDefaultAutoRange();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(range22);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        xYPlot0.setDataset(xYDataset5);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        xYPlot0.setDomainTickBandPaint((java.awt.Paint) color7);
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot0.getRangeAxis();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range13 = dateAxis12.getDefaultAutoRange();
        java.awt.Paint paint14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        dateAxis12.setAxisLinePaint(paint14);
        dateAxis12.setAutoRange(true);
        xYPlot0.setDomainAxis(192, (org.jfree.chart.axis.ValueAxis) dateAxis12);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean23 = dateAxis22.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, (org.jfree.chart.axis.ValueAxis) dateAxis22, categoryItemRenderer24);
        java.awt.Paint paint26 = categoryPlot25.getDomainGridlinePaint();
        categoryPlot25.setBackgroundImageAlignment(1);
        categoryPlot25.mapDatasetToRangeAxis((int) ' ', 100);
        boolean boolean32 = categoryPlot25.isOutlineVisible();
        xYPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot25);
        int int34 = xYPlot0.getDatasetCount();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        org.jfree.chart.util.Layer layer1 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean2 = datasetRenderingOrder0.equals((java.lang.Object) layer1);
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean7 = dateAxis6.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis6, categoryItemRenderer8);
        java.awt.Paint paint10 = categoryPlot9.getDomainGridlinePaint();
        int int11 = categoryPlot9.getBackgroundImageAlignment();
        boolean boolean12 = datasetRenderingOrder0.equals((java.lang.Object) categoryPlot9);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent13 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot9);
        categoryPlot9.setDrawSharedDomainAxis(false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertNotNull(layer1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 15 + "'", int11 == 15);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isTickMarksVisible();
        double double2 = dateAxis0.getFixedAutoRange();
        dateAxis0.setVisible(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean5 = dateAxis4.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        java.util.TimeZone timeZone8 = dateAxis4.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("SortOrder.ASCENDING", timeZone8);
        dateAxis9.setRangeWithMargins((double) '4', 100.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(timeZone8);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        java.awt.Paint paint5 = xYPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        xYPlot0.zoomDomainAxes((double) 128, plotRenderingInfo7, point2D8, false);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean15 = dateAxis14.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis14, categoryItemRenderer16);
        boolean boolean18 = categoryPlot17.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier19 = categoryPlot17.getDrawingSupplier();
        categoryPlot17.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = categoryPlot17.getDomainAxisEdge(10);
        boolean boolean23 = categoryPlot17.isRangeZoomable();
        java.awt.Paint paint24 = categoryPlot17.getDomainGridlinePaint();
        xYPlot0.setRangeZeroBaselinePaint(paint24);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(drawingSupplier19);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(paint24);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        java.awt.Paint paint5 = xYPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot0.zoomDomainAxes((double) (short) 1, 8.0d, plotRenderingInfo8, point2D9);
        int int11 = xYPlot0.getDatasetCount();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        org.jfree.chart.util.Layer layer1 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean2 = datasetRenderingOrder0.equals((java.lang.Object) layer1);
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean7 = dateAxis6.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis6, categoryItemRenderer8);
        java.awt.Paint paint10 = categoryPlot9.getDomainGridlinePaint();
        int int11 = categoryPlot9.getBackgroundImageAlignment();
        boolean boolean12 = datasetRenderingOrder0.equals((java.lang.Object) categoryPlot9);
        java.lang.String str13 = categoryPlot9.getPlotType();
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertNotNull(layer1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 15 + "'", int11 == 15);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Category Plot" + "'", str13.equals("Category Plot"));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean2 = dateAxis1.isNegativeArrowVisible();
        dateAxis1.setAutoRangeMinimumSize((double) (short) 1, true);
        boolean boolean6 = dateAxis1.isAxisLineVisible();
        java.awt.Paint paint7 = dateAxis1.getTickMarkPaint();
        boolean boolean8 = dateAxis1.isVisible();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        java.awt.Paint paint8 = categoryPlot6.getDomainGridlinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot6.getDomainAxisForDataset((int) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = categoryPlot6.getDomainAxis(192);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        int int14 = categoryPlot6.getIndexOf(categoryItemRenderer13);
        categoryPlot6.clearDomainAxes();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertNull(categoryAxis12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        categoryPlot6.mapDatasetToDomainAxis(100, (int) 'a');
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent11 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot6);
        org.jfree.chart.JFreeChart jFreeChart12 = null;
        plotChangeEvent11.setChart(jFreeChart12);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeZeroBaselineVisible(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder3 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot0.setRangeAxisLocation((int) (byte) 100, axisLocation5);
        xYPlot0.setRangeCrosshairVisible(false);
        boolean boolean9 = xYPlot0.isRangeZeroBaselineVisible();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        xYPlot0.setDomainGridlinePaint((java.awt.Paint) color10);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = xYPlot0.getRenderer((int) '4');
        org.jfree.chart.util.Layer layer15 = null;
        java.util.Collection collection16 = xYPlot0.getRangeMarkers((int) (byte) 1, layer15);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = xYPlot0.getRangeAxisEdge();
        org.junit.Assert.assertNotNull(datasetRenderingOrder3);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNull(xYItemRenderer13);
        org.junit.Assert.assertNull(collection16);
        org.junit.Assert.assertNotNull(rectangleEdge17);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        java.awt.Paint paint5 = xYPlot0.getOutlinePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = xYPlot0.getRangeAxisEdge();
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        xYPlot0.setDataset((int) '#', xYDataset8);
        boolean boolean10 = xYPlot0.isRangeZeroBaselineVisible();
        xYPlot0.setDomainCrosshairVisible(true);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = categoryPlot6.getLegendItems();
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range12 = dateAxis11.getDefaultAutoRange();
        xYPlot9.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis11);
        java.awt.Paint paint14 = xYPlot9.getOutlinePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = xYPlot9.getRangeAxisEdge();
        org.jfree.chart.plot.PlotOrientation plotOrientation16 = xYPlot9.getOrientation();
        categoryPlot6.setOrientation(plotOrientation16);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        try {
            categoryPlot6.handleClick((int) 'a', 12, plotRenderingInfo20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(legendItemCollection8);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(plotOrientation16);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean2 = dateAxis1.isNegativeArrowVisible();
        dateAxis1.setAutoRangeMinimumSize((double) (short) 1, true);
        org.jfree.chart.axis.Timeline timeline6 = null;
        dateAxis1.setTimeline(timeline6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean12 = dateAxis11.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis11, categoryItemRenderer13);
        boolean boolean15 = categoryPlot14.isOutlineVisible();
        java.awt.Paint paint16 = categoryPlot14.getDomainGridlinePaint();
        java.lang.String str17 = categoryPlot14.getNoDataMessage();
        dateAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot14);
        int int19 = categoryPlot14.getBackgroundImageAlignment();
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean24 = dateAxis23.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, (org.jfree.chart.axis.ValueAxis) dateAxis23, categoryItemRenderer25);
        boolean boolean27 = categoryPlot26.isOutlineVisible();
        categoryPlot26.mapDatasetToDomainAxis(100, (int) 'a');
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer32 = null;
        categoryPlot26.setRenderer(255, categoryItemRenderer32, false);
        org.jfree.chart.util.SortOrder sortOrder35 = categoryPlot26.getColumnRenderingOrder();
        java.lang.String str36 = sortOrder35.toString();
        categoryPlot14.setRowRenderingOrder(sortOrder35);
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = new org.jfree.chart.axis.CategoryAxis();
        int int39 = categoryAxis38.getMaximumCategoryLabelLines();
        categoryAxis38.addCategoryLabelToolTip((java.lang.Comparable) 100.0d, "DatasetRenderingOrder.REVERSE");
        int int43 = categoryPlot14.getDomainAxisIndex(categoryAxis38);
        org.jfree.chart.axis.AxisSpace axisSpace44 = null;
        categoryPlot14.setFixedDomainAxisSpace(axisSpace44);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 15 + "'", int19 == 15);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(sortOrder35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "SortOrder.ASCENDING" + "'", str36.equals("SortOrder.ASCENDING"));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_RED;
        float[] floatArray4 = null;
        float[] floatArray5 = java.awt.Color.RGBtoHSB((int) (byte) 100, (-4145152), (-1), floatArray4);
        float[] floatArray6 = color0.getRGBColorComponents(floatArray5);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray6);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        org.jfree.chart.plot.Marker marker5 = null;
        boolean boolean6 = xYPlot0.removeDomainMarker(marker5);
        xYPlot0.setDomainCrosshairValue((double) (-1), true);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean12 = dateAxis11.isNegativeArrowVisible();
        dateAxis11.setAutoRangeMinimumSize((double) (short) 1, true);
        org.jfree.chart.axis.Timeline timeline16 = null;
        dateAxis11.setTimeline(timeline16);
        boolean boolean18 = xYPlot0.equals((java.lang.Object) dateAxis11);
        boolean boolean19 = dateAxis11.isTickLabelsVisible();
        org.jfree.data.Range range20 = dateAxis11.getRange();
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean25 = dateAxis24.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, (org.jfree.chart.axis.ValueAxis) dateAxis24, categoryItemRenderer26);
        boolean boolean28 = categoryPlot27.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier29 = categoryPlot27.getDrawingSupplier();
        categoryPlot27.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = categoryPlot27.getDomainAxisEdge(10);
        boolean boolean33 = categoryPlot27.isRangeZoomable();
        java.awt.Paint paint34 = categoryPlot27.getDomainGridlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation36 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot27.setDomainAxisLocation(64, axisLocation36, false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder39 = categoryPlot27.getDatasetRenderingOrder();
        org.jfree.data.category.CategoryDataset categoryDataset40 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = null;
        org.jfree.chart.axis.DateAxis dateAxis43 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean44 = dateAxis43.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset40, categoryAxis41, (org.jfree.chart.axis.ValueAxis) dateAxis43, categoryItemRenderer45);
        dateAxis43.resizeRange((double) 100.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets49 = dateAxis43.getLabelInsets();
        categoryPlot27.setAxisOffset(rectangleInsets49);
        dateAxis11.setLabelInsets(rectangleInsets49);
        double double53 = rectangleInsets49.extendWidth((double) 192);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(drawingSupplier29);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertNotNull(datasetRenderingOrder39);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(rectangleInsets49);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 198.0d + "'", double53 == 198.0d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeZeroBaselineVisible(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder3 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot0.setRangeAxisLocation((int) (byte) 100, axisLocation5);
        boolean boolean7 = xYPlot0.isDomainGridlinesVisible();
        xYPlot0.setOutlineVisible(true);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder10 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean13 = dateAxis12.isNegativeArrowVisible();
        double double14 = dateAxis12.getLowerBound();
        dateAxis12.setAutoRange(false);
        org.jfree.data.Range range17 = xYPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis12);
        xYPlot0.setBackgroundImageAlpha(0.0f);
        boolean boolean20 = xYPlot0.isOutlineVisible();
        org.junit.Assert.assertNotNull(datasetRenderingOrder3);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(seriesRenderingOrder10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean2 = dateAxis1.isTickLabelsVisible();
        dateAxis1.configure();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        java.awt.Color color0 = java.awt.Color.BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        java.awt.Color color0 = java.awt.Color.cyan;
        java.lang.String str1 = color0.toString();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java.awt.Color[r=0,g=255,b=255]" + "'", str1.equals("java.awt.Color[r=0,g=255,b=255]"));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        org.jfree.chart.util.Layer layer1 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean2 = datasetRenderingOrder0.equals((java.lang.Object) layer1);
        java.lang.String str3 = datasetRenderingOrder0.toString();
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertNotNull(layer1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "DatasetRenderingOrder.REVERSE" + "'", str3.equals("DatasetRenderingOrder.REVERSE"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot6.getDrawingSupplier();
        categoryPlot6.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot6.getDomainAxisEdge(10);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = categoryPlot6.getDomainAxis();
        categoryPlot6.setDomainGridlinesVisible(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = categoryPlot6.getRenderer();
        categoryPlot6.setOutlineVisible(true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNull(categoryAxis12);
        org.junit.Assert.assertNull(categoryItemRenderer15);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean2 = dateAxis1.isNegativeArrowVisible();
        double double3 = dateAxis1.getLowerBound();
        dateAxis1.setAutoRange(false);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean10 = dateAxis9.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis9, categoryItemRenderer11);
        dateAxis9.resizeRange((double) 100.0f);
        java.util.Date date15 = dateAxis9.getMaximumDate();
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean20 = dateAxis19.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, (org.jfree.chart.axis.ValueAxis) dateAxis19, categoryItemRenderer21);
        java.util.TimeZone timeZone23 = dateAxis19.getTimeZone();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date15, timeZone23);
        dateAxis1.setMinimumDate(date15);
        boolean boolean27 = dateAxis1.isHiddenValue((long) 192);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        java.awt.Paint paint5 = xYPlot0.getOutlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        xYPlot0.zoomRangeAxes((double) (byte) 100, plotRenderingInfo7, point2D8, false);
        java.awt.Stroke stroke11 = xYPlot0.getRangeGridlineStroke();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double15 = rectangleInsets13.calculateTopOutset(0.0d);
        double double16 = rectangleInsets13.getTop();
        boolean boolean17 = seriesRenderingOrder12.equals((java.lang.Object) rectangleInsets13);
        java.lang.String str18 = rectangleInsets13.toString();
        double double20 = rectangleInsets13.trimHeight((double) 1560452399999L);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 4.0d + "'", double15 == 4.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 4.0d + "'", double16 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]" + "'", str18.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.560452399991E12d + "'", double20 == 1.560452399991E12d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        java.awt.Paint paint5 = xYPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot0.zoomDomainAxes((double) (short) 1, 8.0d, plotRenderingInfo8, point2D9);
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean16 = dateAxis15.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, (org.jfree.chart.axis.ValueAxis) dateAxis15, categoryItemRenderer17);
        org.jfree.data.Range range19 = dateAxis15.getRange();
        xYPlot11.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis15);
        java.text.DateFormat dateFormat21 = dateAxis15.getDateFormatOverride();
        int int22 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis15);
        try {
            java.awt.Paint paint24 = xYPlot0.getQuadrantPaint((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (52) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertNull(dateFormat21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot6.getDrawingSupplier();
        categoryPlot6.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot6.getDomainAxisEdge(10);
        boolean boolean12 = categoryPlot6.isRangeZoomable();
        java.awt.Paint paint13 = categoryPlot6.getDomainGridlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot6.setDomainAxisLocation(64, axisLocation15, false);
        org.jfree.chart.axis.ValueAxis valueAxis19 = categoryPlot6.getRangeAxis((int) (short) 1);
        java.awt.Stroke stroke20 = categoryPlot6.getOutlineStroke();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNull(valueAxis19);
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        java.awt.Stroke stroke4 = numberAxis3.getTickMarkStroke();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis3.setTickUnit(numberTickUnit5);
        numberAxis1.setTickUnit(numberTickUnit5);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        java.awt.Stroke stroke12 = numberAxis11.getTickMarkStroke();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit13 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis11.setTickUnit(numberTickUnit13);
        numberAxis9.setTickUnit(numberTickUnit13);
        numberAxis1.setTickUnit(numberTickUnit13);
        org.jfree.data.RangeType rangeType17 = numberAxis1.getRangeType();
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        java.awt.Stroke stroke22 = numberAxis21.getTickMarkStroke();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit23 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis21.setTickUnit(numberTickUnit23);
        numberAxis19.setTickUnit(numberTickUnit23);
        numberAxis1.setTickUnit(numberTickUnit23, false, false);
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = null;
        double double32 = numberAxis1.valueToJava2D(16.0d, rectangle2D30, rectangleEdge31);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(numberTickUnit5);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(numberTickUnit13);
        org.junit.Assert.assertNotNull(rangeType17);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(numberTickUnit23);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.lang.String str1 = rectangleAnchor0.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleAnchor.BOTTOM_RIGHT" + "'", str1.equals("RectangleAnchor.BOTTOM_RIGHT"));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot6.getDrawingSupplier();
        categoryPlot6.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot6.getDomainAxisEdge(10);
        boolean boolean12 = categoryPlot6.isRangeZoomable();
        java.awt.Paint paint13 = categoryPlot6.getDomainGridlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot6.setDomainAxisLocation(64, axisLocation15, false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder18 = categoryPlot6.getDatasetRenderingOrder();
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean23 = dateAxis22.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, (org.jfree.chart.axis.ValueAxis) dateAxis22, categoryItemRenderer24);
        boolean boolean26 = categoryPlot25.isOutlineVisible();
        categoryPlot25.mapDatasetToDomainAxis(100, (int) 'a');
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        categoryPlot25.setRenderer(255, categoryItemRenderer31, false);
        org.jfree.chart.util.SortOrder sortOrder34 = categoryPlot25.getColumnRenderingOrder();
        categoryPlot6.setColumnRenderingOrder(sortOrder34);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = null;
        categoryPlot6.setRenderer(categoryItemRenderer36, false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(datasetRenderingOrder18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(sortOrder34);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean2 = dateAxis1.isNegativeArrowVisible();
        dateAxis1.setAutoRangeMinimumSize((double) (short) 1, true);
        org.jfree.chart.axis.Timeline timeline6 = null;
        dateAxis1.setTimeline(timeline6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean12 = dateAxis11.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis11, categoryItemRenderer13);
        boolean boolean15 = categoryPlot14.isOutlineVisible();
        java.awt.Paint paint16 = categoryPlot14.getDomainGridlinePaint();
        java.lang.String str17 = categoryPlot14.getNoDataMessage();
        dateAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot14);
        int int19 = categoryPlot14.getBackgroundImageAlignment();
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean24 = dateAxis23.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, (org.jfree.chart.axis.ValueAxis) dateAxis23, categoryItemRenderer25);
        boolean boolean27 = categoryPlot26.isOutlineVisible();
        categoryPlot26.mapDatasetToDomainAxis(100, (int) 'a');
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer32 = null;
        categoryPlot26.setRenderer(255, categoryItemRenderer32, false);
        org.jfree.chart.util.SortOrder sortOrder35 = categoryPlot26.getColumnRenderingOrder();
        java.lang.String str36 = sortOrder35.toString();
        categoryPlot14.setRowRenderingOrder(sortOrder35);
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = new org.jfree.chart.axis.CategoryAxis();
        int int39 = categoryAxis38.getMaximumCategoryLabelLines();
        categoryAxis38.addCategoryLabelToolTip((java.lang.Comparable) 100.0d, "DatasetRenderingOrder.REVERSE");
        int int43 = categoryPlot14.getDomainAxisIndex(categoryAxis38);
        org.jfree.data.general.DatasetGroup datasetGroup44 = categoryPlot14.getDatasetGroup();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 15 + "'", int19 == 15);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(sortOrder35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "SortOrder.ASCENDING" + "'", str36.equals("SortOrder.ASCENDING"));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertNull(datasetGroup44);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        org.jfree.chart.plot.Marker marker5 = null;
        boolean boolean6 = xYPlot0.removeDomainMarker(marker5);
        xYPlot0.setDomainCrosshairValue((double) (-1), true);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean12 = dateAxis11.isNegativeArrowVisible();
        dateAxis11.setAutoRangeMinimumSize((double) (short) 1, true);
        java.awt.Shape shape16 = dateAxis11.getUpArrow();
        double double17 = dateAxis11.getFixedDimension();
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range21 = dateAxis20.getDefaultAutoRange();
        xYPlot18.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis20);
        org.jfree.chart.plot.Marker marker23 = null;
        boolean boolean24 = xYPlot18.removeDomainMarker(marker23);
        xYPlot18.setDomainCrosshairValue((double) (-1), true);
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean30 = dateAxis29.isNegativeArrowVisible();
        dateAxis29.setAutoRangeMinimumSize((double) (short) 1, true);
        org.jfree.chart.axis.Timeline timeline34 = null;
        dateAxis29.setTimeline(timeline34);
        boolean boolean36 = xYPlot18.equals((java.lang.Object) dateAxis29);
        org.jfree.data.Range range37 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis29.setRange(range37, true, false);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray41 = new org.jfree.chart.axis.ValueAxis[] { dateAxis11, dateAxis29 };
        xYPlot0.setRangeAxes(valueAxisArray41);
        org.jfree.chart.axis.ValueAxis valueAxis43 = xYPlot0.getRangeAxis();
        java.awt.Shape shape44 = valueAxis43.getUpArrow();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertNotNull(valueAxisArray41);
        org.junit.Assert.assertNotNull(valueAxis43);
        org.junit.Assert.assertNotNull(shape44);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot6.getDrawingSupplier();
        categoryPlot6.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot6.getDomainAxisEdge(10);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = categoryPlot6.getDomainAxis();
        categoryPlot6.setDomainGridlinesVisible(true);
        boolean boolean15 = categoryPlot6.isDomainGridlinesVisible();
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range19 = dateAxis18.getDefaultAutoRange();
        xYPlot16.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis18);
        java.awt.Paint paint21 = xYPlot16.getOutlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        xYPlot16.zoomRangeAxes((double) (byte) 100, plotRenderingInfo23, point2D24, false);
        java.awt.Stroke stroke27 = xYPlot16.getDomainCrosshairStroke();
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean30 = dateAxis29.isNegativeArrowVisible();
        double double31 = dateAxis29.getLowerBound();
        java.awt.Paint paint32 = dateAxis29.getTickLabelPaint();
        java.awt.Stroke stroke33 = dateAxis29.getAxisLineStroke();
        xYPlot16.setDomainGridlineStroke(stroke33);
        categoryPlot6.setDomainGridlineStroke(stroke33);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNull(categoryAxis12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(stroke33);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        java.awt.Paint paint5 = xYPlot0.getOutlinePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = xYPlot0.getRangeAxisEdge();
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = xYPlot0.getOrientation();
        boolean boolean8 = xYPlot0.isDomainZeroBaselineVisible();
        java.awt.Color color9 = java.awt.Color.green;
        java.awt.Color color10 = color9.brighter();
        xYPlot0.setBackgroundPaint((java.awt.Paint) color9);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(plotOrientation7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeZeroBaselineVisible(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder3 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot0.setRangeAxisLocation((int) (byte) 100, axisLocation5);
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean11 = dateAxis10.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis10, categoryItemRenderer12);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = dateAxis10.getTickLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        dateAxis15.setTickLabelPaint((java.awt.Paint) color16);
        boolean boolean18 = rectangleInsets14.equals((java.lang.Object) dateAxis15);
        java.lang.String str19 = rectangleInsets14.toString();
        org.jfree.chart.util.UnitType unitType20 = rectangleInsets14.getUnitType();
        double double21 = rectangleInsets14.getBottom();
        double double23 = rectangleInsets14.calculateRightInset(0.0d);
        double double24 = rectangleInsets14.getRight();
        xYPlot0.setAxisOffset(rectangleInsets14);
        xYPlot0.clearRangeMarkers();
        org.jfree.chart.axis.AxisLocation axisLocation28 = xYPlot0.getRangeAxisLocation((int) '4');
        org.junit.Assert.assertNotNull(datasetRenderingOrder3);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str19.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
        org.junit.Assert.assertNotNull(unitType20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 2.0d + "'", double21 == 2.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 4.0d + "'", double23 == 4.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 4.0d + "'", double24 == 4.0d);
        org.junit.Assert.assertNotNull(axisLocation28);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        java.awt.Paint paint5 = xYPlot0.getOutlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        xYPlot0.zoomRangeAxes((double) (byte) 100, plotRenderingInfo7, point2D8, false);
        java.awt.Stroke stroke11 = xYPlot0.getRangeGridlineStroke();
        int int12 = xYPlot0.getRangeAxisCount();
        xYPlot0.setRangeCrosshairValue((double) (-1));
        java.awt.Paint paint15 = xYPlot0.getRangeCrosshairPaint();
        java.awt.Paint paint17 = xYPlot0.getQuadrantPaint(0);
        boolean boolean18 = xYPlot0.isDomainCrosshairVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = xYPlot0.getRangeAxisEdge((int) (short) 1);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent21 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) rectangleEdge20);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(rectangleEdge20);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        dateAxis3.resizeRange((double) 100.0f);
        java.util.Date date9 = dateAxis3.getMaximumDate();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date9);
        java.lang.String str11 = day10.toString();
        long long12 = day10.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "31-December-1969" + "'", str11.equals("31-December-1969"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-57600000L) + "'", long12 == (-57600000L));
    }

//    @Test
//    public void test151() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test151");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getMiddleMillisecond();
//        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
//        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("hi!");
//        boolean boolean6 = dateAxis5.isNegativeArrowVisible();
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer7);
//        boolean boolean9 = categoryPlot8.isOutlineVisible();
//        categoryPlot8.mapDatasetToDomainAxis(100, (int) 'a');
//        int int13 = day0.compareTo((java.lang.Object) 100);
//        java.util.Date date14 = day0.getStart();
//        int int15 = day0.getYear();
//        long long16 = day0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560452399999L + "'", long1 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560452399999L + "'", long16 == 1560452399999L);
//    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        categoryPlot6.clearRangeMarkers(0);
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot6.getRangeAxisLocation(10);
        categoryPlot6.setRangeCrosshairValue(11.0d, true);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean18 = dateAxis17.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, (org.jfree.chart.axis.ValueAxis) dateAxis17, categoryItemRenderer19);
        dateAxis17.resizeRange((double) 100.0f);
        java.awt.Shape shape23 = dateAxis17.getDownArrow();
        org.jfree.chart.axis.Timeline timeline24 = null;
        dateAxis17.setTimeline(timeline24);
        categoryPlot6.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis17);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor27 = categoryPlot6.getDomainGridlinePosition();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(categoryAnchor27);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range4 = dateAxis3.getDefaultAutoRange();
        java.awt.Paint paint5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        dateAxis3.setAxisLinePaint(paint5);
        dateAxis3.setAutoRange(true);
        boolean boolean9 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer10);
        categoryPlot11.setRangeGridlinesVisible(true);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot6.getDrawingSupplier();
        categoryPlot6.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot6.getDomainAxisEdge(10);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = categoryPlot6.getDomainAxis();
        categoryPlot6.setDomainGridlinesVisible(true);
        categoryPlot6.setDrawSharedDomainAxis(false);
        org.jfree.chart.util.SortOrder sortOrder17 = categoryPlot6.getColumnRenderingOrder();
        int int18 = categoryPlot6.getDomainAxisCount();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNull(categoryAxis12);
        org.junit.Assert.assertNotNull(sortOrder17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = categoryPlot6.getLegendItems();
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range12 = dateAxis11.getDefaultAutoRange();
        xYPlot9.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis11);
        java.awt.Paint paint14 = xYPlot9.getOutlinePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = xYPlot9.getRangeAxisEdge();
        org.jfree.chart.plot.PlotOrientation plotOrientation16 = xYPlot9.getOrientation();
        categoryPlot6.setOrientation(plotOrientation16);
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean22 = dateAxis21.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis21, categoryItemRenderer23);
        boolean boolean25 = categoryPlot24.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier26 = categoryPlot24.getDrawingSupplier();
        categoryPlot24.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = categoryPlot24.getDomainAxisEdge(10);
        boolean boolean30 = categoryPlot24.isRangeZoomable();
        java.awt.Paint paint31 = categoryPlot24.getDomainGridlinePaint();
        java.awt.Paint paint32 = categoryPlot24.getOutlinePaint();
        categoryPlot6.setRangeGridlinePaint(paint32);
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = categoryPlot6.getDomainAxis(64);
        categoryPlot6.setRangeGridlinesVisible(false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(legendItemCollection8);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(plotOrientation16);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(drawingSupplier26);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNull(categoryAxis35);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range2 = dateAxis1.getDefaultAutoRange();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean7 = dateAxis6.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis6, categoryItemRenderer8);
        boolean boolean10 = categoryPlot9.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier11 = categoryPlot9.getDrawingSupplier();
        categoryPlot9.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = categoryPlot9.getDomainAxisEdge(10);
        boolean boolean15 = categoryPlot9.isRangeZoomable();
        java.awt.Paint paint16 = categoryPlot9.getDomainGridlinePaint();
        boolean boolean17 = categoryPlot9.isDomainGridlinesVisible();
        boolean boolean18 = categoryPlot9.isDomainGridlinesVisible();
        dateAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range20 = null;
        try {
            dateAxis1.setRangeWithMargins(range20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(drawingSupplier11);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        org.jfree.chart.plot.Marker marker5 = null;
        boolean boolean6 = xYPlot0.removeDomainMarker(marker5);
        xYPlot0.setDomainCrosshairValue((double) (-1), true);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean12 = dateAxis11.isNegativeArrowVisible();
        dateAxis11.setAutoRangeMinimumSize((double) (short) 1, true);
        org.jfree.chart.axis.Timeline timeline16 = null;
        dateAxis11.setTimeline(timeline16);
        boolean boolean18 = xYPlot0.equals((java.lang.Object) dateAxis11);
        org.jfree.data.Range range19 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis11.setRange(range19, true, false);
        dateAxis11.setNegativeArrowVisible(true);
        org.jfree.chart.plot.Plot plot25 = dateAxis11.getPlot();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertNull(plot25);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        java.awt.Paint paint5 = xYPlot0.getOutlinePaint();
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        xYPlot7.setRangeZeroBaselineVisible(false);
        boolean boolean10 = xYPlot7.isOutlineVisible();
        xYPlot7.clearRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot7.setDomainAxisLocation(64, axisLocation13);
        xYPlot0.setDomainAxisLocation(2, axisLocation13);
        org.jfree.chart.axis.AxisLocation axisLocation16 = xYPlot0.getDomainAxisLocation();
        xYPlot0.zoom((double) 100.0f);
        xYPlot0.clearRangeAxes();
        java.awt.Color color23 = java.awt.Color.getHSBColor(0.0f, 0.0f, (float) 2);
        int int24 = color23.getRed();
        xYPlot0.setRangeGridlinePaint((java.awt.Paint) color23);
        boolean boolean26 = xYPlot0.isDomainZoomable();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 255 + "'", int24 == 255);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        double double7 = dateAxis3.getUpperBound();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean12 = dateAxis11.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis11, categoryItemRenderer13);
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        int int16 = categoryPlot14.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis15);
        categoryPlot14.configureRangeAxes();
        dateAxis3.setPlot((org.jfree.chart.plot.Plot) categoryPlot14);
        java.awt.Paint paint19 = categoryPlot14.getRangeCrosshairPaint();
        org.jfree.chart.plot.IntervalMarker intervalMarker22 = new org.jfree.chart.plot.IntervalMarker((double) 64, (double) 12);
        java.lang.Object obj23 = intervalMarker22.clone();
        org.jfree.chart.text.TextAnchor textAnchor24 = org.jfree.chart.text.TextAnchor.CENTER;
        intervalMarker22.setLabelTextAnchor(textAnchor24);
        categoryPlot14.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker22);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertNotNull(textAnchor24);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getDomainAxisEdge(192);
        java.awt.Image image3 = null;
        xYPlot0.setBackgroundImage(image3);
        org.junit.Assert.assertNotNull(rectangleEdge2);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = categoryPlot6.getLegendItems();
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range12 = dateAxis11.getDefaultAutoRange();
        xYPlot9.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis11);
        java.awt.Paint paint14 = xYPlot9.getOutlinePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = xYPlot9.getRangeAxisEdge();
        org.jfree.chart.plot.PlotOrientation plotOrientation16 = xYPlot9.getOrientation();
        categoryPlot6.setOrientation(plotOrientation16);
        boolean boolean18 = categoryPlot6.isSubplot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean25 = dateAxis24.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, (org.jfree.chart.axis.ValueAxis) dateAxis24, categoryItemRenderer26);
        boolean boolean28 = categoryPlot27.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier29 = categoryPlot27.getDrawingSupplier();
        categoryPlot27.clearRangeAxes();
        categoryPlot27.setBackgroundAlpha((float) 10L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = null;
        categoryPlot27.setRenderer(15, categoryItemRenderer34);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo37 = null;
        org.jfree.chart.plot.XYPlot xYPlot38 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range41 = dateAxis40.getDefaultAutoRange();
        xYPlot38.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis40);
        org.jfree.data.xy.XYDataset xYDataset43 = null;
        xYPlot38.setDataset(xYDataset43);
        java.awt.Color color45 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        xYPlot38.setDomainTickBandPaint((java.awt.Paint) color45);
        org.jfree.chart.axis.ValueAxis valueAxis47 = xYPlot38.getRangeAxis();
        org.jfree.chart.plot.PlotOrientation plotOrientation48 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        xYPlot38.setOrientation(plotOrientation48);
        java.awt.geom.Point2D point2D50 = xYPlot38.getQuadrantOrigin();
        categoryPlot27.zoomDomainAxes(0.0d, plotRenderingInfo37, point2D50, false);
        categoryPlot6.zoomDomainAxes((double) 'a', plotRenderingInfo20, point2D50, false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(legendItemCollection8);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(plotOrientation16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(drawingSupplier29);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNull(valueAxis47);
        org.junit.Assert.assertNotNull(plotOrientation48);
        org.junit.Assert.assertNotNull(point2D50);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 11);
        java.awt.Paint paint2 = valueMarker1.getPaint();
        valueMarker1.setValue(8.0d);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range8 = dateAxis7.getDefaultAutoRange();
        xYPlot5.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis7);
        java.awt.Paint paint10 = xYPlot5.getOutlinePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = xYPlot5.getRangeAxisEdge();
        org.jfree.chart.plot.PlotOrientation plotOrientation12 = xYPlot5.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection13 = xYPlot5.getLegendItems();
        xYPlot5.setRangeZeroBaselineVisible(false);
        valueMarker1.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean23 = dateAxis22.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, (org.jfree.chart.axis.ValueAxis) dateAxis22, categoryItemRenderer24);
        boolean boolean26 = categoryPlot25.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier27 = categoryPlot25.getDrawingSupplier();
        categoryPlot25.clearRangeAxes();
        categoryPlot25.setBackgroundAlpha((float) 10L);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer32 = null;
        categoryPlot25.setRenderer(15, categoryItemRenderer32);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range39 = dateAxis38.getDefaultAutoRange();
        xYPlot36.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis38);
        org.jfree.data.xy.XYDataset xYDataset41 = null;
        xYPlot36.setDataset(xYDataset41);
        java.awt.Color color43 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        xYPlot36.setDomainTickBandPaint((java.awt.Paint) color43);
        org.jfree.chart.axis.ValueAxis valueAxis45 = xYPlot36.getRangeAxis();
        org.jfree.chart.plot.PlotOrientation plotOrientation46 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        xYPlot36.setOrientation(plotOrientation46);
        java.awt.geom.Point2D point2D48 = xYPlot36.getQuadrantOrigin();
        categoryPlot25.zoomDomainAxes(0.0d, plotRenderingInfo35, point2D48, false);
        try {
            xYPlot5.zoomDomainAxes((double) 192, plotRenderingInfo18, point2D48, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNotNull(plotOrientation12);
        org.junit.Assert.assertNotNull(legendItemCollection13);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(drawingSupplier27);
        org.junit.Assert.assertNotNull(range39);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNull(valueAxis45);
        org.junit.Assert.assertNotNull(plotOrientation46);
        org.junit.Assert.assertNotNull(point2D48);
    }

//    @Test
//    public void test163() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test163");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getMiddleMillisecond();
//        long long2 = day0.getMiddleMillisecond();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = day0.getLastMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560452399999L + "'", long1 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560452399999L + "'", long2 == 1560452399999L);
//    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range4 = dateAxis3.getDefaultAutoRange();
        xYPlot1.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis3);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        xYPlot1.setDataset(xYDataset6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        xYPlot1.setDomainTickBandPaint((java.awt.Paint) color8);
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range13 = dateAxis12.getDefaultAutoRange();
        xYPlot10.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis12);
        java.awt.Paint paint15 = xYPlot10.getOutlinePaint();
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot();
        xYPlot17.setRangeZeroBaselineVisible(false);
        boolean boolean20 = xYPlot17.isOutlineVisible();
        xYPlot17.clearRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation23 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot17.setDomainAxisLocation(64, axisLocation23);
        xYPlot10.setDomainAxisLocation(2, axisLocation23);
        boolean boolean26 = color8.equals((java.lang.Object) 2);
        java.awt.color.ColorSpace colorSpace27 = color8.getColorSpace();
        float[] floatArray34 = new float[] { 1, 1L, 0L };
        float[] floatArray35 = java.awt.Color.RGBtoHSB((int) (short) -1, 8, 0, floatArray34);
        try {
            float[] floatArray36 = color0.getComponents(colorSpace27, floatArray34);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(colorSpace27);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertNotNull(floatArray35);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("SeriesRenderingOrder.FORWARD");
        categoryAxis1.setUpperMargin(0.2d);
        java.lang.Comparable comparable4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        categoryAxis5.addCategoryLabelToolTip((java.lang.Comparable) "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]", "java.awt.Color[r=0,g=0,b=128]");
        double double10 = categoryAxis5.getCategoryMargin();
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        xYPlot11.setRangeZeroBaselineVisible(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder14 = xYPlot11.getDatasetRenderingOrder();
        xYPlot11.setDomainCrosshairLockedOnData(false);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        java.awt.Stroke stroke19 = numberAxis18.getTickMarkStroke();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit20 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis18.setTickUnit(numberTickUnit20);
        boolean boolean22 = xYPlot11.equals((java.lang.Object) numberTickUnit20);
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot();
        xYPlot23.setRangeZeroBaselineVisible(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = xYPlot23.getDatasetRenderingOrder();
        xYPlot23.setDomainCrosshairLockedOnData(false);
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        java.awt.Stroke stroke31 = numberAxis30.getTickMarkStroke();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit32 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis30.setTickUnit(numberTickUnit32);
        boolean boolean34 = xYPlot23.equals((java.lang.Object) numberTickUnit32);
        org.jfree.chart.plot.ValueMarker valueMarker36 = new org.jfree.chart.plot.ValueMarker((double) 11);
        xYPlot23.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker36);
        java.awt.Font font38 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        valueMarker36.setLabelFont(font38);
        categoryAxis5.setTickLabelFont((java.lang.Comparable) numberTickUnit20, font38);
        try {
            categoryAxis1.setTickLabelFont(comparable4, font38);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.2d + "'", double10 == 0.2d);
        org.junit.Assert.assertNotNull(datasetRenderingOrder14);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(numberTickUnit20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(numberTickUnit32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(font38);
    }

//    @Test
//    public void test166() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test166");
//        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
//        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
//        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
//        org.jfree.data.Range range4 = dateAxis3.getDefaultAutoRange();
//        xYPlot1.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis3);
//        java.awt.Paint paint6 = xYPlot1.getOutlinePaint();
//        xYPlot1.setRangeCrosshairValue(1.0E-8d);
//        org.jfree.chart.util.RectangleInsets rectangleInsets9 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
//        xYPlot1.setAxisOffset(rectangleInsets9);
//        org.jfree.chart.util.UnitType unitType11 = rectangleInsets9.getUnitType();
//        boolean boolean12 = numberAxis0.equals((java.lang.Object) rectangleInsets9);
//        boolean boolean13 = numberAxis0.isAutoTickUnitSelection();
//        java.awt.Graphics2D graphics2D14 = null;
//        java.awt.geom.Rectangle2D rectangle2D16 = null;
//        java.awt.geom.Rectangle2D rectangle2D17 = null;
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        long long19 = day18.getMiddleMillisecond();
//        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
//        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("hi!");
//        boolean boolean24 = dateAxis23.isNegativeArrowVisible();
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, (org.jfree.chart.axis.ValueAxis) dateAxis23, categoryItemRenderer25);
//        boolean boolean27 = categoryPlot26.isOutlineVisible();
//        categoryPlot26.mapDatasetToDomainAxis(100, (int) 'a');
//        int int31 = day18.compareTo((java.lang.Object) 100);
//        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
//        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("hi!");
//        boolean boolean36 = dateAxis35.isNegativeArrowVisible();
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, (org.jfree.chart.axis.ValueAxis) dateAxis35, categoryItemRenderer37);
//        categoryPlot38.clearRangeMarkers(0);
//        org.jfree.chart.axis.AxisLocation axisLocation42 = categoryPlot38.getRangeAxisLocation(10);
//        org.jfree.chart.plot.XYPlot xYPlot43 = new org.jfree.chart.plot.XYPlot();
//        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis("hi!");
//        org.jfree.data.Range range46 = dateAxis45.getDefaultAutoRange();
//        xYPlot43.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis45);
//        java.awt.Paint paint48 = xYPlot43.getOutlinePaint();
//        org.jfree.chart.util.RectangleEdge rectangleEdge49 = xYPlot43.getRangeAxisEdge();
//        org.jfree.chart.plot.PlotOrientation plotOrientation50 = xYPlot43.getOrientation();
//        org.jfree.chart.util.RectangleEdge rectangleEdge51 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation42, plotOrientation50);
//        boolean boolean52 = day18.equals((java.lang.Object) rectangleEdge51);
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo53 = null;
//        try {
//            org.jfree.chart.axis.AxisState axisState54 = numberAxis0.draw(graphics2D14, (double) (-100), rectangle2D16, rectangle2D17, rectangleEdge51, plotRenderingInfo53);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(range4);
//        org.junit.Assert.assertNotNull(paint6);
//        org.junit.Assert.assertNotNull(rectangleInsets9);
//        org.junit.Assert.assertNotNull(unitType11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560452399999L + "'", long19 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(axisLocation42);
//        org.junit.Assert.assertNotNull(range46);
//        org.junit.Assert.assertNotNull(paint48);
//        org.junit.Assert.assertNotNull(rectangleEdge49);
//        org.junit.Assert.assertNotNull(plotOrientation50);
//        org.junit.Assert.assertNotNull(rectangleEdge51);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        int int1 = objectList0.size();
        java.lang.Object obj3 = objectList0.get((int) ' ');
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean8 = dateAxis7.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer9);
        boolean boolean11 = categoryPlot10.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier12 = categoryPlot10.getDrawingSupplier();
        categoryPlot10.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = categoryPlot10.getDomainAxisEdge(10);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = categoryPlot10.getDomainAxis();
        categoryPlot10.setDomainGridlinesVisible(true);
        int int19 = objectList0.indexOf((java.lang.Object) categoryPlot10);
        int int20 = objectList0.size();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(drawingSupplier12);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNull(categoryAxis16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range2 = dateAxis1.getDefaultAutoRange();
        java.awt.Paint paint3 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        dateAxis1.setAxisLinePaint(paint3);
        dateAxis1.setUpperBound(6.0d);
        java.awt.Shape shape7 = dateAxis1.getDownArrow();
        java.awt.Shape shape8 = dateAxis1.getUpArrow();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(shape8);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        categoryPlot6.clearRangeMarkers(0);
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot6.getRangeAxisLocation(10);
        java.awt.Stroke stroke11 = categoryPlot6.getRangeCrosshairStroke();
        org.jfree.chart.axis.AxisSpace axisSpace12 = categoryPlot6.getFixedDomainAxisSpace();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(axisSpace12);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        categoryPlot6.mapDatasetToDomainAxis(100, (int) 'a');
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        categoryPlot6.setRenderer(255, categoryItemRenderer12, false);
        double double15 = categoryPlot6.getRangeCrosshairValue();
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        xYPlot16.setRangeZeroBaselineVisible(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder19 = xYPlot16.getDatasetRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation21 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot16.setRangeAxisLocation((int) (byte) 100, axisLocation21);
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean27 = dateAxis26.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, (org.jfree.chart.axis.ValueAxis) dateAxis26, categoryItemRenderer28);
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = dateAxis26.getTickLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis();
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        dateAxis31.setTickLabelPaint((java.awt.Paint) color32);
        boolean boolean34 = rectangleInsets30.equals((java.lang.Object) dateAxis31);
        java.lang.String str35 = rectangleInsets30.toString();
        org.jfree.chart.util.UnitType unitType36 = rectangleInsets30.getUnitType();
        double double37 = rectangleInsets30.getBottom();
        double double39 = rectangleInsets30.calculateRightInset(0.0d);
        double double40 = rectangleInsets30.getRight();
        xYPlot16.setAxisOffset(rectangleInsets30);
        java.awt.Stroke stroke42 = xYPlot16.getRangeZeroBaselineStroke();
        categoryPlot6.setRangeCrosshairStroke(stroke42);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(datasetRenderingOrder19);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str35.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
        org.junit.Assert.assertNotNull(unitType36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 2.0d + "'", double37 == 2.0d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 4.0d + "'", double39 == 4.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 4.0d + "'", double40 == 4.0d);
        org.junit.Assert.assertNotNull(stroke42);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeZeroBaselineVisible(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder3 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot0.setRangeAxisLocation((int) (byte) 100, axisLocation5);
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean11 = dateAxis10.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis10, categoryItemRenderer12);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = dateAxis10.getTickLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        dateAxis15.setTickLabelPaint((java.awt.Paint) color16);
        boolean boolean18 = rectangleInsets14.equals((java.lang.Object) dateAxis15);
        java.lang.String str19 = rectangleInsets14.toString();
        org.jfree.chart.util.UnitType unitType20 = rectangleInsets14.getUnitType();
        double double21 = rectangleInsets14.getBottom();
        double double23 = rectangleInsets14.calculateRightInset(0.0d);
        double double24 = rectangleInsets14.getRight();
        xYPlot0.setAxisOffset(rectangleInsets14);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        try {
            xYPlot0.setRenderer((-100), xYItemRenderer27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(datasetRenderingOrder3);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str19.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
        org.junit.Assert.assertNotNull(unitType20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 2.0d + "'", double21 == 2.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 4.0d + "'", double23 == 4.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 4.0d + "'", double24 == 4.0d);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        java.awt.Paint paint5 = xYPlot0.getOutlinePaint();
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        xYPlot7.setRangeZeroBaselineVisible(false);
        boolean boolean10 = xYPlot7.isOutlineVisible();
        xYPlot7.clearRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot7.setDomainAxisLocation(64, axisLocation13);
        xYPlot0.setDomainAxisLocation(2, axisLocation13);
        org.jfree.chart.axis.AxisLocation axisLocation16 = xYPlot0.getDomainAxisLocation();
        xYPlot0.zoom((double) 100.0f);
        java.awt.Paint paint19 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        xYPlot0.setDataset(xYDataset20);
        java.awt.Paint paint22 = xYPlot0.getRangeZeroBaselinePaint();
        boolean boolean23 = xYPlot0.isDomainZoomable();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot6.getDrawingSupplier();
        categoryPlot6.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot6.getDomainAxisEdge(10);
        boolean boolean12 = categoryPlot6.isRangeZoomable();
        java.awt.Paint paint13 = categoryPlot6.getDomainGridlinePaint();
        boolean boolean14 = categoryPlot6.isDomainGridlinesVisible();
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker((double) 11);
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range20 = dateAxis19.getDefaultAutoRange();
        xYPlot17.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis19);
        java.awt.Paint paint22 = xYPlot17.getOutlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        java.awt.geom.Point2D point2D25 = null;
        xYPlot17.zoomRangeAxes((double) (byte) 100, plotRenderingInfo24, point2D25, false);
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean32 = dateAxis31.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, (org.jfree.chart.axis.ValueAxis) dateAxis31, categoryItemRenderer33);
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = dateAxis31.getTickLabelInsets();
        xYPlot17.setInsets(rectangleInsets35, false);
        boolean boolean38 = valueMarker16.equals((java.lang.Object) rectangleInsets35);
        categoryPlot6.setInsets(rectangleInsets35, false);
        org.jfree.chart.plot.IntervalMarker intervalMarker43 = new org.jfree.chart.plot.IntervalMarker((double) 3, 100.0d);
        org.jfree.chart.plot.XYPlot xYPlot44 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range47 = dateAxis46.getDefaultAutoRange();
        xYPlot44.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis46);
        java.awt.Stroke stroke49 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot44.setRangeCrosshairStroke(stroke49);
        intervalMarker43.setStroke(stroke49);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor52 = org.jfree.chart.util.RectangleAnchor.CENTER;
        intervalMarker43.setLabelAnchor(rectangleAnchor52);
        java.awt.Color color54 = java.awt.Color.red;
        intervalMarker43.setLabelPaint((java.awt.Paint) color54);
        boolean boolean56 = categoryPlot6.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker43);
        int int57 = categoryPlot6.getWeight();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(range47);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(rectangleAnchor52);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        dateAxis3.resizeRange((double) 100.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = dateAxis3.getLabelInsets();
        java.lang.Object obj10 = null;
        boolean boolean11 = rectangleInsets9.equals(obj10);
        double double13 = rectangleInsets9.trimHeight(0.0d);
        double double15 = rectangleInsets9.calculateLeftInset((double) 192);
        double double17 = rectangleInsets9.extendWidth(2.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-6.0d) + "'", double13 == (-6.0d));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 3.0d + "'", double15 == 3.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 8.0d + "'", double17 == 8.0d);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = dateAxis3.getTickLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        dateAxis8.setTickLabelPaint((java.awt.Paint) color9);
        boolean boolean11 = rectangleInsets7.equals((java.lang.Object) dateAxis8);
        boolean boolean12 = dateAxis8.isTickMarksVisible();
        double double13 = dateAxis8.getUpperMargin();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.05d + "'", double13 == 0.05d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 11);
        java.awt.Paint paint2 = valueMarker1.getPaint();
        valueMarker1.setValue(8.0d);
        valueMarker1.setValue((double) 11);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeZeroBaselineVisible(false);
        boolean boolean3 = xYPlot0.isOutlineVisible();
        xYPlot0.clearRangeAxes();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean7 = dateAxis6.isNegativeArrowVisible();
        dateAxis6.setAutoRangeMinimumSize((double) (short) 1, true);
        org.jfree.chart.axis.Timeline timeline11 = null;
        dateAxis6.setTimeline(timeline11);
        float float13 = dateAxis6.getTickMarkInsideLength();
        java.awt.Stroke stroke14 = dateAxis6.getAxisLineStroke();
        xYPlot0.setDomainZeroBaselineStroke(stroke14);
        java.awt.Stroke stroke16 = null;
        try {
            xYPlot0.setRangeZeroBaselineStroke(stroke16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.0f + "'", float13 == 0.0f);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        int int8 = categoryPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis7);
        categoryPlot6.configureRangeAxes();
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        categoryPlot6.drawBackgroundImage(graphics2D10, rectangle2D11);
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = categoryPlot6.getRangeAxisEdge((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(rectangleEdge14);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        java.awt.Paint paint8 = categoryPlot6.getDomainGridlinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot6.getDomainAxisForDataset((int) (short) 0);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean15 = dateAxis14.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis14, categoryItemRenderer16);
        org.jfree.data.Range range18 = dateAxis14.getRange();
        int int19 = categoryPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis14);
        dateAxis14.setFixedAutoRange((double) 255);
        boolean boolean22 = dateAxis14.isAutoRange();
        dateAxis14.setTickLabelsVisible(true);
        dateAxis14.configure();
        java.util.TimeZone timeZone26 = dateAxis14.getTimeZone();
        java.util.Date date27 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.data.category.CategoryDataset categoryDataset29 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = null;
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean33 = dateAxis32.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset29, categoryAxis30, (org.jfree.chart.axis.ValueAxis) dateAxis32, categoryItemRenderer34);
        boolean boolean36 = categoryPlot35.isOutlineVisible();
        java.awt.Paint paint37 = categoryPlot35.getDomainGridlinePaint();
        java.awt.Image image38 = null;
        categoryPlot35.setBackgroundImage(image38);
        org.jfree.chart.plot.XYPlot xYPlot41 = new org.jfree.chart.plot.XYPlot();
        xYPlot41.setRangeZeroBaselineVisible(false);
        boolean boolean44 = xYPlot41.isOutlineVisible();
        xYPlot41.clearRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation47 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot41.setDomainAxisLocation(64, axisLocation47);
        categoryPlot35.setRangeAxisLocation(12, axisLocation47);
        org.jfree.chart.util.RectangleEdge rectangleEdge51 = categoryPlot35.getDomainAxisEdge((int) '4');
        try {
            double double52 = dateAxis14.dateToJava2D(date27, rectangle2D28, rectangleEdge51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(axisLocation47);
        org.junit.Assert.assertNotNull(rectangleEdge51);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot6.getDrawingSupplier();
        java.lang.Object obj9 = null;
        boolean boolean10 = categoryPlot6.equals(obj9);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        int int12 = categoryPlot6.getIndexOf(categoryItemRenderer11);
        java.util.List list13 = categoryPlot6.getAnnotations();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(list13);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        java.awt.Stroke stroke5 = numberAxis4.getTickMarkStroke();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit6 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis4.setTickUnit(numberTickUnit6);
        numberAxis2.setTickUnit(numberTickUnit6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        java.awt.Stroke stroke13 = numberAxis12.getTickMarkStroke();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit14 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis12.setTickUnit(numberTickUnit14);
        numberAxis10.setTickUnit(numberTickUnit14);
        numberAxis2.setTickUnit(numberTickUnit14);
        org.jfree.data.RangeType rangeType18 = numberAxis2.getRangeType();
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        java.awt.Stroke stroke23 = numberAxis22.getTickMarkStroke();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit24 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis22.setTickUnit(numberTickUnit24);
        numberAxis20.setTickUnit(numberTickUnit24);
        numberAxis2.setTickUnit(numberTickUnit24, false, false);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        java.awt.Stroke stroke32 = numberAxis31.getTickMarkStroke();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit33 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis31.setTickUnit(numberTickUnit33);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = null;
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis31, xYItemRenderer35);
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean39 = dateAxis38.isNegativeArrowVisible();
        double double40 = dateAxis38.getLowerBound();
        java.awt.Paint paint41 = dateAxis38.getTickLabelPaint();
        java.awt.Stroke stroke42 = dateAxis38.getAxisLineStroke();
        dateAxis38.configure();
        org.jfree.data.Range range44 = dateAxis38.getDefaultAutoRange();
        int int45 = xYPlot36.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis38);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(numberTickUnit6);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(numberTickUnit14);
        org.junit.Assert.assertNotNull(rangeType18);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(numberTickUnit24);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(numberTickUnit33);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(range44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean5 = dateAxis4.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        org.jfree.data.Range range8 = dateAxis4.getRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis4);
        dateAxis4.resizeRange((double) 8);
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        xYPlot12.setRangeZeroBaselineVisible(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder15 = xYPlot12.getDatasetRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation17 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot12.setRangeAxisLocation((int) (byte) 100, axisLocation17);
        xYPlot12.setRangeCrosshairVisible(false);
        boolean boolean21 = xYPlot12.isRangeZeroBaselineVisible();
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        xYPlot12.setDomainGridlinePaint((java.awt.Paint) color22);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer25 = xYPlot12.getRenderer((int) '4');
        dateAxis4.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot12);
        int int27 = xYPlot12.getDatasetCount();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(datasetRenderingOrder15);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNull(xYItemRenderer25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        java.awt.Paint paint5 = xYPlot0.getOutlinePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = xYPlot0.getRangeAxisEdge();
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = xYPlot0.getOrientation();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean10 = dateAxis9.isNegativeArrowVisible();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis9);
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range15 = dateAxis14.getDefaultAutoRange();
        xYPlot12.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis14);
        dateAxis14.setUpperMargin(100.0d);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.axis.AxisState axisState20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = null;
        java.util.List list23 = dateAxis14.refreshTicks(graphics2D19, axisState20, rectangle2D21, rectangleEdge22);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = dateAxis14.getLabelInsets();
        org.jfree.chart.axis.DateTickUnit dateTickUnit25 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis14.setTickUnit(dateTickUnit25, false, true);
        dateAxis9.setTickUnit(dateTickUnit25, false, true);
        java.text.DateFormat dateFormat32 = dateAxis9.getDateFormatOverride();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(plotOrientation7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNull(list23);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(dateTickUnit25);
        org.junit.Assert.assertNull(dateFormat32);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeZeroBaselineVisible(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder3 = xYPlot0.getDatasetRenderingOrder();
        xYPlot0.setDomainCrosshairLockedOnData(false);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        java.awt.Stroke stroke8 = numberAxis7.getTickMarkStroke();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit9 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis7.setTickUnit(numberTickUnit9);
        boolean boolean11 = xYPlot0.equals((java.lang.Object) numberTickUnit9);
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker((double) 11);
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker13);
        org.jfree.chart.axis.AxisLocation axisLocation15 = xYPlot0.getDomainAxisLocation();
        org.junit.Assert.assertNotNull(datasetRenderingOrder3);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(numberTickUnit9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(axisLocation15);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        java.awt.Paint paint5 = xYPlot0.getOutlinePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = xYPlot0.getRangeAxisEdge();
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = xYPlot0.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = xYPlot0.getLegendItems();
        xYPlot0.setRangeZeroBaselineVisible(false);
        boolean boolean11 = xYPlot0.isDomainCrosshairLockedOnData();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        try {
            xYPlot0.setRenderer((-8355712), xYItemRenderer13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(plotOrientation7);
        org.junit.Assert.assertNotNull(legendItemCollection8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot6.getDrawingSupplier();
        categoryPlot6.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot6.getDomainAxisEdge(10);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = categoryPlot6.getDomainAxis();
        categoryPlot6.setDomainGridlinesVisible(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = categoryPlot6.getRenderer();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        categoryPlot6.setRenderer(categoryItemRenderer16);
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range21 = dateAxis20.getDefaultAutoRange();
        xYPlot18.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis20);
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        xYPlot18.setDataset(xYDataset23);
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        xYPlot18.setDomainTickBandPaint((java.awt.Paint) color25);
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range30 = dateAxis29.getDefaultAutoRange();
        xYPlot27.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis29);
        java.awt.Paint paint32 = xYPlot27.getOutlinePaint();
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot();
        xYPlot34.setRangeZeroBaselineVisible(false);
        boolean boolean37 = xYPlot34.isOutlineVisible();
        xYPlot34.clearRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation40 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot34.setDomainAxisLocation(64, axisLocation40);
        xYPlot27.setDomainAxisLocation(2, axisLocation40);
        boolean boolean43 = color25.equals((java.lang.Object) 2);
        java.awt.color.ColorSpace colorSpace44 = color25.getColorSpace();
        categoryPlot6.setRangeCrosshairPaint((java.awt.Paint) color25);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier46 = categoryPlot6.getDrawingSupplier();
        java.awt.Paint paint47 = categoryPlot6.getRangeGridlinePaint();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNull(categoryAxis12);
        org.junit.Assert.assertNull(categoryItemRenderer15);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(axisLocation40);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(colorSpace44);
        org.junit.Assert.assertNotNull(drawingSupplier46);
        org.junit.Assert.assertNotNull(paint47);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean2 = dateAxis1.isNegativeArrowVisible();
        double double3 = dateAxis1.getLowerBound();
        java.awt.Paint paint4 = dateAxis1.getTickLabelPaint();
        dateAxis1.setPositiveArrowVisible(false);
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean11 = dateAxis10.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis10, categoryItemRenderer12);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = dateAxis10.getTickLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        dateAxis15.setTickLabelPaint((java.awt.Paint) color16);
        boolean boolean18 = rectangleInsets14.equals((java.lang.Object) dateAxis15);
        java.lang.String str19 = rectangleInsets14.toString();
        org.jfree.chart.util.UnitType unitType20 = rectangleInsets14.getUnitType();
        double double21 = rectangleInsets14.getBottom();
        double double23 = rectangleInsets14.calculateRightInset(0.0d);
        dateAxis1.setLabelInsets(rectangleInsets14);
        double double25 = rectangleInsets14.getBottom();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str19.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
        org.junit.Assert.assertNotNull(unitType20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 2.0d + "'", double21 == 2.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 4.0d + "'", double23 == 4.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 2.0d + "'", double25 == 2.0d);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        int int8 = categoryPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis7);
        double double9 = categoryPlot6.getRangeCrosshairValue();
        org.jfree.chart.plot.IntervalMarker intervalMarker12 = new org.jfree.chart.plot.IntervalMarker((double) 3, 100.0d);
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range16 = dateAxis15.getDefaultAutoRange();
        xYPlot13.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis15);
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot13.setRangeCrosshairStroke(stroke18);
        intervalMarker12.setStroke(stroke18);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = org.jfree.chart.util.RectangleAnchor.CENTER;
        intervalMarker12.setLabelAnchor(rectangleAnchor21);
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean25 = dateAxis24.isNegativeArrowVisible();
        double double26 = dateAxis24.getLowerBound();
        java.awt.Paint paint27 = dateAxis24.getTickLabelPaint();
        java.awt.Stroke stroke28 = dateAxis24.getAxisLineStroke();
        intervalMarker12.setStroke(stroke28);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent30 = null;
        intervalMarker12.notifyListeners(markerChangeEvent30);
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = intervalMarker12.getLabelOffset();
        java.awt.Font font33 = intervalMarker12.getLabelFont();
        boolean boolean34 = categoryPlot6.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker12);
        intervalMarker12.setLabel("java.awt.Color[r=128,g=0,b=0]");
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(rectangleAnchor21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        xYPlot0.setDataset(xYDataset5);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        xYPlot0.setDomainTickBandPaint((java.awt.Paint) color7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range12 = dateAxis11.getDefaultAutoRange();
        xYPlot9.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis11);
        java.awt.Paint paint14 = xYPlot9.getOutlinePaint();
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        xYPlot16.setRangeZeroBaselineVisible(false);
        boolean boolean19 = xYPlot16.isOutlineVisible();
        xYPlot16.clearRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation22 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot16.setDomainAxisLocation(64, axisLocation22);
        xYPlot9.setDomainAxisLocation(2, axisLocation22);
        boolean boolean25 = color7.equals((java.lang.Object) 2);
        java.awt.color.ColorSpace colorSpace26 = color7.getColorSpace();
        float[] floatArray30 = null;
        float[] floatArray31 = java.awt.Color.RGBtoHSB((int) (byte) 100, (-4145152), (-1), floatArray30);
        try {
            float[] floatArray32 = color7.getComponents(floatArray31);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(colorSpace26);
        org.junit.Assert.assertNotNull(floatArray31);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getTickLabelInsets();
        double double7 = rectangleInsets5.calculateBottomOutset((double) 1);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        categoryPlot6.clearRangeMarkers(0);
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot6.getRangeAxisLocation(10);
        categoryPlot6.setDrawSharedDomainAxis(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = categoryPlot6.getRangeAxisEdge((int) ' ');
        org.jfree.chart.util.SortOrder sortOrder15 = org.jfree.chart.util.SortOrder.DESCENDING;
        categoryPlot6.setRowRenderingOrder(sortOrder15);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertNotNull(sortOrder15);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeZeroBaselineVisible(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder3 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot0.setRangeAxisLocation((int) (byte) 100, axisLocation5);
        java.awt.Stroke stroke7 = xYPlot0.getDomainCrosshairStroke();
        java.lang.Object obj8 = xYPlot0.clone();
        org.junit.Assert.assertNotNull(datasetRenderingOrder3);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getMaximumCategoryLabelLines();
        categoryAxis0.setTickLabelsVisible(false);
        categoryAxis0.configure();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        java.awt.Stroke stroke7 = numberAxis6.getTickMarkStroke();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit8 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis6.setTickUnit(numberTickUnit8);
        boolean boolean10 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean15 = dateAxis14.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis14, categoryItemRenderer16);
        org.jfree.data.Range range18 = dateAxis14.getRange();
        numberAxis6.setRange(range18, false, false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit22 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis6.setTickUnit(numberTickUnit22, false, true);
        java.awt.Font font26 = categoryAxis0.getTickLabelFont((java.lang.Comparable) numberTickUnit22);
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range33 = dateAxis32.getDefaultAutoRange();
        xYPlot30.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis32);
        java.awt.Paint paint35 = xYPlot30.getOutlinePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = xYPlot30.getRangeAxisEdge();
        try {
            double double37 = categoryAxis0.getCategoryStart((-8388608), 192, rectangle2D29, rectangleEdge36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(numberTickUnit8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNotNull(numberTickUnit22);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(range33);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(rectangleEdge36);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        java.awt.Paint paint8 = categoryPlot6.getDomainGridlinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot6.getDomainAxisForDataset((int) (short) 0);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        categoryPlot6.setRenderer(100, categoryItemRenderer12);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryAxis10);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean2 = dateAxis1.isNegativeArrowVisible();
        dateAxis1.setAutoRangeMinimumSize((double) (short) 1, true);
        java.awt.Shape shape6 = dateAxis1.getUpArrow();
        dateAxis1.setInverted(false);
        java.text.DateFormat dateFormat9 = dateAxis1.getDateFormatOverride();
        dateAxis1.setAutoTickUnitSelection(false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNull(dateFormat9);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean2 = dateAxis1.isTickLabelsVisible();
        dateAxis1.setLabelURL("Layer.FOREGROUND");
        java.awt.Paint paint5 = dateAxis1.getAxisLinePaint();
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range9 = dateAxis8.getDefaultAutoRange();
        xYPlot6.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis8);
        java.awt.Paint paint11 = xYPlot6.getOutlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        xYPlot6.zoomRangeAxes((double) (byte) 100, plotRenderingInfo13, point2D14, false);
        org.jfree.chart.plot.IntervalMarker intervalMarker20 = new org.jfree.chart.plot.IntervalMarker((double) 3, 100.0d);
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range24 = dateAxis23.getDefaultAutoRange();
        xYPlot21.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis23);
        org.jfree.chart.util.Layer layer27 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean29 = layer27.equals((java.lang.Object) true);
        java.util.Collection collection30 = xYPlot21.getRangeMarkers((int) '#', layer27);
        xYPlot6.addRangeMarker(3, (org.jfree.chart.plot.Marker) intervalMarker20, layer27);
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean36 = dateAxis35.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, (org.jfree.chart.axis.ValueAxis) dateAxis35, categoryItemRenderer37);
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = dateAxis35.getTickLabelInsets();
        double double41 = rectangleInsets39.calculateLeftOutset((double) (-1.0f));
        xYPlot6.setAxisOffset(rectangleInsets39);
        dateAxis1.setLabelInsets(rectangleInsets39);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNotNull(layer27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNull(collection30);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(rectangleInsets39);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 4.0d + "'", double41 == 4.0d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        java.awt.Paint paint5 = xYPlot0.getOutlinePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = xYPlot0.getRangeAxisEdge();
        xYPlot0.setDomainCrosshairLockedOnData(true);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range12 = dateAxis11.getDefaultAutoRange();
        xYPlot9.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis11);
        java.awt.Paint paint14 = xYPlot9.getOutlinePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = xYPlot9.getRangeAxisEdge();
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean20 = dateAxis19.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, (org.jfree.chart.axis.ValueAxis) dateAxis19, categoryItemRenderer21);
        boolean boolean23 = categoryPlot22.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier24 = categoryPlot22.getDrawingSupplier();
        categoryPlot22.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = categoryPlot22.getDomainAxisEdge(10);
        boolean boolean28 = categoryPlot22.isRangeZoomable();
        java.awt.Paint paint29 = categoryPlot22.getDomainGridlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation31 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot22.setDomainAxisLocation(64, axisLocation31, false);
        xYPlot9.setRangeAxisLocation(axisLocation31, false);
        xYPlot0.setRangeAxisLocation(axisLocation31, true);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(drawingSupplier24);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(axisLocation31);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean2 = dateAxis1.isNegativeArrowVisible();
        dateAxis1.setAutoRangeMinimumSize((double) (short) 1, true);
        org.jfree.chart.axis.Timeline timeline6 = null;
        dateAxis1.setTimeline(timeline6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean12 = dateAxis11.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis11, categoryItemRenderer13);
        boolean boolean15 = categoryPlot14.isOutlineVisible();
        java.awt.Paint paint16 = categoryPlot14.getDomainGridlinePaint();
        java.lang.String str17 = categoryPlot14.getNoDataMessage();
        dateAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot14);
        int int19 = categoryPlot14.getBackgroundImageAlignment();
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean24 = dateAxis23.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, (org.jfree.chart.axis.ValueAxis) dateAxis23, categoryItemRenderer25);
        boolean boolean27 = categoryPlot26.isOutlineVisible();
        categoryPlot26.mapDatasetToDomainAxis(100, (int) 'a');
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer32 = null;
        categoryPlot26.setRenderer(255, categoryItemRenderer32, false);
        org.jfree.chart.util.SortOrder sortOrder35 = categoryPlot26.getColumnRenderingOrder();
        java.lang.String str36 = sortOrder35.toString();
        categoryPlot14.setRowRenderingOrder(sortOrder35);
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = new org.jfree.chart.axis.CategoryAxis();
        int int39 = categoryAxis38.getMaximumCategoryLabelLines();
        categoryAxis38.addCategoryLabelToolTip((java.lang.Comparable) 100.0d, "DatasetRenderingOrder.REVERSE");
        int int43 = categoryPlot14.getDomainAxisIndex(categoryAxis38);
        categoryPlot14.mapDatasetToDomainAxis(255, 2);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 15 + "'", int19 == 15);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(sortOrder35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "SortOrder.ASCENDING" + "'", str36.equals("SortOrder.ASCENDING"));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        java.awt.Stroke stroke4 = numberAxis3.getTickMarkStroke();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis3.setTickUnit(numberTickUnit5);
        numberAxis1.setTickUnit(numberTickUnit5);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        java.awt.Stroke stroke12 = numberAxis11.getTickMarkStroke();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit13 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis11.setTickUnit(numberTickUnit13);
        numberAxis9.setTickUnit(numberTickUnit13);
        numberAxis1.setTickUnit(numberTickUnit13);
        org.jfree.data.RangeType rangeType17 = numberAxis1.getRangeType();
        org.jfree.data.Range range18 = numberAxis1.getDefaultAutoRange();
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot();
        xYPlot19.setRangeZeroBaselineVisible(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder22 = xYPlot19.getDatasetRenderingOrder();
        xYPlot19.setDomainCrosshairLockedOnData(false);
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        java.awt.Stroke stroke27 = numberAxis26.getTickMarkStroke();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit28 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis26.setTickUnit(numberTickUnit28);
        boolean boolean30 = xYPlot19.equals((java.lang.Object) numberTickUnit28);
        numberAxis1.setTickUnit(numberTickUnit28, false, true);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(numberTickUnit5);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(numberTickUnit13);
        org.junit.Assert.assertNotNull(rangeType17);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNotNull(datasetRenderingOrder22);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(numberTickUnit28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        dateAxis3.resizeRange((double) 100.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = dateAxis3.getLabelInsets();
        dateAxis3.resizeRange((double) 100L);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        java.awt.Stroke stroke16 = numberAxis15.getTickMarkStroke();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit17 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis15.setTickUnit(numberTickUnit17);
        numberAxis13.setTickUnit(numberTickUnit17);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        java.awt.Stroke stroke24 = numberAxis23.getTickMarkStroke();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit25 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis23.setTickUnit(numberTickUnit25);
        numberAxis21.setTickUnit(numberTickUnit25);
        numberAxis13.setTickUnit(numberTickUnit25);
        org.jfree.data.RangeType rangeType29 = numberAxis13.getRangeType();
        org.jfree.data.Range range30 = numberAxis13.getDefaultAutoRange();
        dateAxis3.setDefaultAutoRange(range30);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(numberTickUnit17);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(numberTickUnit25);
        org.junit.Assert.assertNotNull(rangeType29);
        org.junit.Assert.assertNotNull(range30);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        java.lang.String str1 = rectangleInsets0.toString();
        double double3 = rectangleInsets0.calculateTopInset(3.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]" + "'", str1.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.chart.util.Layer layer0 = org.jfree.chart.util.Layer.BACKGROUND;
        java.lang.String str1 = layer0.toString();
        java.lang.String str2 = layer0.toString();
        org.junit.Assert.assertNotNull(layer0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Layer.BACKGROUND" + "'", str1.equals("Layer.BACKGROUND"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Layer.BACKGROUND" + "'", str2.equals("Layer.BACKGROUND"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 3, 100.0d);
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range6 = dateAxis5.getDefaultAutoRange();
        xYPlot3.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis5);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot3.setRangeCrosshairStroke(stroke8);
        intervalMarker2.setStroke(stroke8);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.CENTER;
        intervalMarker2.setLabelAnchor(rectangleAnchor11);
        java.awt.Paint paint13 = intervalMarker2.getOutlinePaint();
        java.awt.Stroke stroke14 = intervalMarker2.getStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = intervalMarker2.getLabelOffset();
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        dateAxis3.resizeRange((double) 100.0f);
        java.util.Date date9 = dateAxis3.getMaximumDate();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date9);
        java.lang.String str11 = day10.toString();
        java.util.Calendar calendar12 = null;
        try {
            long long13 = day10.getMiddleMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "31-December-1969" + "'", str11.equals("31-December-1969"));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 3, 100.0d);
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range6 = dateAxis5.getDefaultAutoRange();
        xYPlot3.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis5);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot3.setRangeCrosshairStroke(stroke8);
        intervalMarker2.setStroke(stroke8);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.CENTER;
        intervalMarker2.setLabelAnchor(rectangleAnchor11);
        java.awt.Color color13 = java.awt.Color.red;
        intervalMarker2.setLabelPaint((java.awt.Paint) color13);
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean20 = dateAxis19.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, (org.jfree.chart.axis.ValueAxis) dateAxis19, categoryItemRenderer21);
        org.jfree.data.Range range23 = dateAxis19.getRange();
        xYPlot15.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis19);
        dateAxis19.resizeRange((double) 8);
        java.awt.Font font27 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis19.setTickLabelFont(font27);
        intervalMarker2.setLabelFont(font27);
        java.awt.Paint paint30 = intervalMarker2.getOutlinePaint();
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(paint30);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 3, 100.0d);
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean7 = dateAxis6.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis6, categoryItemRenderer8);
        boolean boolean10 = categoryPlot9.isOutlineVisible();
        java.awt.Paint paint11 = categoryPlot9.getDomainGridlinePaint();
        java.lang.String str12 = categoryPlot9.getNoDataMessage();
        intervalMarker2.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot9);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent14 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot9);
        try {
            categoryPlot9.setBackgroundImageAlpha((float) 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean2 = dateAxis1.isNegativeArrowVisible();
        double double3 = dateAxis1.getLowerBound();
        dateAxis1.setAutoRange(false);
        java.awt.Color color10 = java.awt.Color.getHSBColor(0.0f, 0.0f, (float) 2);
        java.awt.Color color11 = java.awt.Color.getColor("ChartChangeEventType.DATASET_UPDATED", color10);
        dateAxis1.setLabelPaint((java.awt.Paint) color11);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        xYPlot0.setDataset(xYDataset5);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        xYPlot0.setRangeGridlinePaint((java.awt.Paint) color7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        int int10 = categoryAxis9.getMaximumCategoryLabelLines();
        categoryAxis9.addCategoryLabelToolTip((java.lang.Comparable) "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]", "java.awt.Color[r=0,g=0,b=128]");
        double double14 = categoryAxis9.getCategoryMargin();
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        xYPlot15.setRangeZeroBaselineVisible(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder18 = xYPlot15.getDatasetRenderingOrder();
        xYPlot15.setDomainCrosshairLockedOnData(false);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        java.awt.Stroke stroke23 = numberAxis22.getTickMarkStroke();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit24 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis22.setTickUnit(numberTickUnit24);
        boolean boolean26 = xYPlot15.equals((java.lang.Object) numberTickUnit24);
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot();
        xYPlot27.setRangeZeroBaselineVisible(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder30 = xYPlot27.getDatasetRenderingOrder();
        xYPlot27.setDomainCrosshairLockedOnData(false);
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        java.awt.Stroke stroke35 = numberAxis34.getTickMarkStroke();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit36 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis34.setTickUnit(numberTickUnit36);
        boolean boolean38 = xYPlot27.equals((java.lang.Object) numberTickUnit36);
        org.jfree.chart.plot.ValueMarker valueMarker40 = new org.jfree.chart.plot.ValueMarker((double) 11);
        xYPlot27.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker40);
        java.awt.Font font42 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        valueMarker40.setLabelFont(font42);
        categoryAxis9.setTickLabelFont((java.lang.Comparable) numberTickUnit24, font42);
        xYPlot0.setNoDataMessageFont(font42);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.2d + "'", double14 == 0.2d);
        org.junit.Assert.assertNotNull(datasetRenderingOrder18);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(numberTickUnit24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder30);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(numberTickUnit36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(font42);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        java.awt.Paint paint5 = xYPlot0.getOutlinePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = xYPlot0.getFixedLegendItems();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(legendItemCollection6);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        double double1 = xYPlot0.getRangeCrosshairValue();
        xYPlot0.setRangeCrosshairVisible(true);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        dateAxis2.setUpperMargin(100.0d);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.axis.AxisState axisState8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        java.util.List list11 = dateAxis2.refreshTicks(graphics2D7, axisState8, rectangle2D9, rectangleEdge10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = dateAxis2.getLabelInsets();
        try {
            dateAxis2.setAutoRangeMinimumSize((double) (-100));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNull(list11);
        org.junit.Assert.assertNotNull(rectangleInsets12);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeZeroBaselineVisible(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder3 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot0.setRangeAxisLocation((int) (byte) 100, axisLocation5);
        xYPlot0.setRangeCrosshairVisible(false);
        boolean boolean9 = xYPlot0.isRangeZeroBaselineVisible();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        xYPlot0.setDomainGridlinePaint((java.awt.Paint) color10);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = xYPlot0.getRenderer((int) '4');
        org.jfree.chart.axis.AxisLocation axisLocation14 = xYPlot0.getDomainAxisLocation();
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean17 = dateAxis16.isNegativeArrowVisible();
        dateAxis16.setAutoRangeMinimumSize((double) (short) 1, true);
        boolean boolean21 = dateAxis16.isAxisLineVisible();
        dateAxis16.setAutoTickUnitSelection(false);
        org.jfree.data.Range range24 = dateAxis16.getDefaultAutoRange();
        xYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis16);
        java.awt.Color color26 = java.awt.Color.green;
        java.awt.Color color27 = color26.brighter();
        xYPlot0.setBackgroundPaint((java.awt.Paint) color26);
        org.junit.Assert.assertNotNull(datasetRenderingOrder3);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNull(xYItemRenderer13);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(color27);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        java.awt.Paint paint8 = categoryPlot6.getDomainGridlinePaint();
        java.awt.Image image9 = null;
        categoryPlot6.setBackgroundImage(image9);
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        xYPlot12.setRangeZeroBaselineVisible(false);
        boolean boolean15 = xYPlot12.isOutlineVisible();
        xYPlot12.clearRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot12.setDomainAxisLocation(64, axisLocation18);
        categoryPlot6.setRangeAxisLocation(12, axisLocation18);
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = categoryPlot6.getDomainAxisEdge((int) '4');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        categoryPlot6.zoomDomainAxes((double) 0L, 0.0d, plotRenderingInfo25, point2D26);
        categoryPlot6.setBackgroundAlpha((float) 2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(rectangleEdge22);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean2 = dateAxis1.isNegativeArrowVisible();
        dateAxis1.setAutoRangeMinimumSize((double) (short) 1, true);
        java.awt.Shape shape6 = dateAxis1.getUpArrow();
        dateAxis1.setRangeAboutValue(0.0d, (double) (byte) 10);
        java.awt.Shape shape10 = dateAxis1.getUpArrow();
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean15 = dateAxis14.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis14, categoryItemRenderer16);
        java.awt.Paint paint18 = categoryPlot17.getDomainGridlinePaint();
        java.lang.Object obj19 = categoryPlot17.clone();
        java.awt.Color color20 = java.awt.Color.pink;
        categoryPlot17.setRangeCrosshairPaint((java.awt.Paint) color20);
        dateAxis1.setAxisLinePaint((java.awt.Paint) color20);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertNotNull(color20);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        org.jfree.chart.util.Layer layer1 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean2 = datasetRenderingOrder0.equals((java.lang.Object) layer1);
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean7 = dateAxis6.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis6, categoryItemRenderer8);
        java.awt.Paint paint10 = categoryPlot9.getDomainGridlinePaint();
        int int11 = categoryPlot9.getBackgroundImageAlignment();
        boolean boolean12 = datasetRenderingOrder0.equals((java.lang.Object) categoryPlot9);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean17 = dateAxis16.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis16, categoryItemRenderer18);
        java.awt.Paint paint20 = categoryPlot19.getDomainGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = categoryPlot19.getRenderer((int) (byte) 0);
        org.jfree.chart.LegendItemCollection legendItemCollection23 = categoryPlot19.getFixedLegendItems();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double26 = rectangleInsets24.calculateTopOutset(0.0d);
        categoryPlot19.setAxisOffset(rectangleInsets24);
        categoryPlot9.setAxisOffset(rectangleInsets24);
        java.awt.Stroke stroke29 = categoryPlot9.getDomainGridlineStroke();
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertNotNull(layer1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 15 + "'", int11 == 15);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNull(categoryItemRenderer22);
        org.junit.Assert.assertNull(legendItemCollection23);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 4.0d + "'", double26 == 4.0d);
        org.junit.Assert.assertNotNull(stroke29);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 3, 100.0d);
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range6 = dateAxis5.getDefaultAutoRange();
        xYPlot3.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis5);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot3.setRangeCrosshairStroke(stroke8);
        intervalMarker2.setStroke(stroke8);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.CENTER;
        intervalMarker2.setLabelAnchor(rectangleAnchor11);
        java.awt.Color color13 = java.awt.Color.red;
        intervalMarker2.setLabelPaint((java.awt.Paint) color13);
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean20 = dateAxis19.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, (org.jfree.chart.axis.ValueAxis) dateAxis19, categoryItemRenderer21);
        org.jfree.data.Range range23 = dateAxis19.getRange();
        xYPlot15.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis19);
        dateAxis19.resizeRange((double) 8);
        java.awt.Font font27 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis19.setTickLabelFont(font27);
        intervalMarker2.setLabelFont(font27);
        intervalMarker2.setEndValue((double) 192);
        java.awt.Paint paint32 = intervalMarker2.getPaint();
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(paint32);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 3, 100.0d);
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range6 = dateAxis5.getDefaultAutoRange();
        xYPlot3.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis5);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot3.setRangeCrosshairStroke(stroke8);
        intervalMarker2.setStroke(stroke8);
        double double11 = intervalMarker2.getEndValue();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean14 = dateAxis13.isNegativeArrowVisible();
        double double15 = dateAxis13.getLowerBound();
        java.awt.Paint paint16 = dateAxis13.getTickLabelPaint();
        dateAxis13.setPositiveArrowVisible(false);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean23 = dateAxis22.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, (org.jfree.chart.axis.ValueAxis) dateAxis22, categoryItemRenderer24);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = dateAxis22.getTickLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        dateAxis27.setTickLabelPaint((java.awt.Paint) color28);
        boolean boolean30 = rectangleInsets26.equals((java.lang.Object) dateAxis27);
        java.lang.String str31 = rectangleInsets26.toString();
        org.jfree.chart.util.UnitType unitType32 = rectangleInsets26.getUnitType();
        double double33 = rectangleInsets26.getBottom();
        double double35 = rectangleInsets26.calculateRightInset(0.0d);
        dateAxis13.setLabelInsets(rectangleInsets26);
        double double38 = rectangleInsets26.calculateLeftInset((double) (byte) 0);
        intervalMarker2.setLabelOffset(rectangleInsets26);
        double double41 = rectangleInsets26.calculateTopOutset((double) 9);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 100.0d + "'", double11 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str31.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
        org.junit.Assert.assertNotNull(unitType32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 2.0d + "'", double33 == 2.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 4.0d + "'", double35 == 4.0d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 4.0d + "'", double38 == 4.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 2.0d + "'", double41 == 2.0d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot6.getDrawingSupplier();
        categoryPlot6.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot6.getDomainAxisEdge(10);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = categoryPlot6.getDomainAxis();
        categoryPlot6.setDomainGridlinesVisible(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = categoryPlot6.getRenderer();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        categoryPlot6.setRenderer(categoryItemRenderer16);
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range21 = dateAxis20.getDefaultAutoRange();
        xYPlot18.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis20);
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        xYPlot18.setDataset(xYDataset23);
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        xYPlot18.setDomainTickBandPaint((java.awt.Paint) color25);
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range30 = dateAxis29.getDefaultAutoRange();
        xYPlot27.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis29);
        java.awt.Paint paint32 = xYPlot27.getOutlinePaint();
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot();
        xYPlot34.setRangeZeroBaselineVisible(false);
        boolean boolean37 = xYPlot34.isOutlineVisible();
        xYPlot34.clearRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation40 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot34.setDomainAxisLocation(64, axisLocation40);
        xYPlot27.setDomainAxisLocation(2, axisLocation40);
        boolean boolean43 = color25.equals((java.lang.Object) 2);
        java.awt.color.ColorSpace colorSpace44 = color25.getColorSpace();
        categoryPlot6.setRangeCrosshairPaint((java.awt.Paint) color25);
        org.jfree.data.category.CategoryDataset categoryDataset46 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = null;
        org.jfree.chart.axis.DateAxis dateAxis49 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean50 = dateAxis49.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer51 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot52 = new org.jfree.chart.plot.CategoryPlot(categoryDataset46, categoryAxis47, (org.jfree.chart.axis.ValueAxis) dateAxis49, categoryItemRenderer51);
        dateAxis49.resizeRange((double) 100.0f);
        java.awt.Shape shape55 = dateAxis49.getDownArrow();
        java.awt.Shape shape56 = dateAxis49.getUpArrow();
        float float57 = dateAxis49.getTickMarkInsideLength();
        boolean boolean58 = color25.equals((java.lang.Object) dateAxis49);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNull(categoryAxis12);
        org.junit.Assert.assertNull(categoryItemRenderer15);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(axisLocation40);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(colorSpace44);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(shape55);
        org.junit.Assert.assertNotNull(shape56);
        org.junit.Assert.assertTrue("'" + float57 + "' != '" + 0.0f + "'", float57 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairVisible();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis8.setCategoryMargin((double) (short) 100);
        categoryPlot6.setDomainAxis(categoryAxis8);
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean19 = dateAxis18.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, (org.jfree.chart.axis.ValueAxis) dateAxis18, categoryItemRenderer20);
        boolean boolean22 = categoryPlot21.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier23 = categoryPlot21.getDrawingSupplier();
        categoryPlot21.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot21.getDomainAxisEdge(10);
        boolean boolean27 = categoryPlot21.isRangeZoomable();
        java.awt.Paint paint28 = categoryPlot21.getDomainGridlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation30 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot21.setDomainAxisLocation(64, axisLocation30, false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder33 = categoryPlot21.getDatasetRenderingOrder();
        org.jfree.data.category.CategoryDataset categoryDataset34 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = null;
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean38 = dateAxis37.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset34, categoryAxis35, (org.jfree.chart.axis.ValueAxis) dateAxis37, categoryItemRenderer39);
        dateAxis37.resizeRange((double) 100.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = dateAxis37.getLabelInsets();
        categoryPlot21.setAxisOffset(rectangleInsets43);
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = categoryPlot21.getDomainAxisEdge((-1));
        try {
            double double47 = categoryAxis8.getCategoryEnd((int) (byte) 0, 2, rectangle2D14, rectangleEdge46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(drawingSupplier23);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(axisLocation30);
        org.junit.Assert.assertNotNull(datasetRenderingOrder33);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertNotNull(rectangleEdge46);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = categoryPlot6.getRenderer();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        try {
            categoryPlot6.handleClick((int) (byte) 0, (int) (byte) -1, plotRenderingInfo11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(categoryItemRenderer8);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean2 = dateAxis1.isNegativeArrowVisible();
        double double3 = dateAxis1.getLowerBound();
        java.awt.Paint paint4 = dateAxis1.getTickLabelPaint();
        dateAxis1.setLowerBound(0.0d);
        dateAxis1.setLabelURL("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean13 = dateAxis12.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis12, categoryItemRenderer14);
        boolean boolean16 = categoryPlot15.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier17 = categoryPlot15.getDrawingSupplier();
        categoryPlot15.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = categoryPlot15.getDomainAxisEdge(10);
        boolean boolean21 = categoryPlot15.isRangeZoomable();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        categoryPlot15.setRenderer(categoryItemRenderer22, true);
        categoryPlot15.setRangeCrosshairValue((double) 10.0f);
        org.jfree.chart.axis.AxisLocation axisLocation27 = categoryPlot15.getRangeAxisLocation();
        boolean boolean28 = dateAxis1.equals((java.lang.Object) axisLocation27);
        java.lang.String str29 = axisLocation27.toString();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(drawingSupplier17);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "AxisLocation.TOP_OR_LEFT" + "'", str29.equals("AxisLocation.TOP_OR_LEFT"));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        java.awt.Stroke stroke5 = numberAxis4.getTickMarkStroke();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit6 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis4.setTickUnit(numberTickUnit6);
        numberAxis2.setTickUnit(numberTickUnit6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        java.awt.Stroke stroke13 = numberAxis12.getTickMarkStroke();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit14 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis12.setTickUnit(numberTickUnit14);
        numberAxis10.setTickUnit(numberTickUnit14);
        numberAxis2.setTickUnit(numberTickUnit14);
        org.jfree.data.RangeType rangeType18 = numberAxis2.getRangeType();
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        java.awt.Stroke stroke23 = numberAxis22.getTickMarkStroke();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit24 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis22.setTickUnit(numberTickUnit24);
        numberAxis20.setTickUnit(numberTickUnit24);
        numberAxis2.setTickUnit(numberTickUnit24, false, false);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        java.awt.Stroke stroke32 = numberAxis31.getTickMarkStroke();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit33 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis31.setTickUnit(numberTickUnit33);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = null;
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis31, xYItemRenderer35);
        java.lang.Object obj37 = numberAxis31.clone();
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(numberTickUnit6);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(numberTickUnit14);
        org.junit.Assert.assertNotNull(rangeType18);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(numberTickUnit24);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(numberTickUnit33);
        org.junit.Assert.assertNotNull(obj37);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        categoryPlot6.clearRangeMarkers(0);
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot6.getRangeAxisLocation(10);
        categoryPlot6.setDrawSharedDomainAxis(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = categoryPlot6.getDatasetRenderingOrder();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        java.awt.Paint paint8 = categoryPlot6.getDomainGridlinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot6.getDomainAxisForDataset((int) (short) 0);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean15 = dateAxis14.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis14, categoryItemRenderer16);
        org.jfree.data.Range range18 = dateAxis14.getRange();
        int int19 = categoryPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis14);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent20 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot6);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation21 = null;
        try {
            boolean boolean23 = categoryPlot6.removeAnnotation(categoryAnnotation21, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        java.awt.Stroke stroke5 = numberAxis4.getTickMarkStroke();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit6 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis4.setTickUnit(numberTickUnit6);
        numberAxis2.setTickUnit(numberTickUnit6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        java.awt.Stroke stroke13 = numberAxis12.getTickMarkStroke();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit14 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis12.setTickUnit(numberTickUnit14);
        numberAxis10.setTickUnit(numberTickUnit14);
        numberAxis2.setTickUnit(numberTickUnit14);
        org.jfree.data.RangeType rangeType18 = numberAxis2.getRangeType();
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        java.awt.Stroke stroke23 = numberAxis22.getTickMarkStroke();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit24 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis22.setTickUnit(numberTickUnit24);
        numberAxis20.setTickUnit(numberTickUnit24);
        numberAxis2.setTickUnit(numberTickUnit24, false, false);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        java.awt.Stroke stroke32 = numberAxis31.getTickMarkStroke();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit33 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis31.setTickUnit(numberTickUnit33);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = null;
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis31, xYItemRenderer35);
        xYPlot36.mapDatasetToRangeAxis(100, 11);
        org.jfree.chart.plot.IntervalMarker intervalMarker42 = new org.jfree.chart.plot.IntervalMarker((double) 3, 100.0d);
        org.jfree.chart.plot.XYPlot xYPlot43 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range46 = dateAxis45.getDefaultAutoRange();
        xYPlot43.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis45);
        java.awt.Stroke stroke48 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot43.setRangeCrosshairStroke(stroke48);
        intervalMarker42.setStroke(stroke48);
        double double51 = intervalMarker42.getEndValue();
        java.awt.Stroke stroke52 = intervalMarker42.getOutlineStroke();
        xYPlot36.setDomainGridlineStroke(stroke52);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(numberTickUnit6);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(numberTickUnit14);
        org.junit.Assert.assertNotNull(rangeType18);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(numberTickUnit24);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(numberTickUnit33);
        org.junit.Assert.assertNotNull(range46);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 100.0d + "'", double51 == 100.0d);
        org.junit.Assert.assertNotNull(stroke52);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 3, 100.0d);
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean7 = dateAxis6.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis6, categoryItemRenderer8);
        boolean boolean10 = categoryPlot9.isOutlineVisible();
        java.awt.Paint paint11 = categoryPlot9.getDomainGridlinePaint();
        java.lang.String str12 = categoryPlot9.getNoDataMessage();
        intervalMarker2.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot9);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        int int17 = categoryAxis16.getCategoryLabelPositionOffset();
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis();
        int int19 = categoryAxis18.getCategoryLabelPositionOffset();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray20 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis14, categoryAxis15, categoryAxis16, categoryAxis18 };
        categoryPlot9.setDomainAxes(categoryAxisArray20);
        org.jfree.chart.axis.AxisSpace axisSpace22 = null;
        categoryPlot9.setFixedDomainAxisSpace(axisSpace22);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = categoryPlot9.getDomainAxisEdge();
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = null;
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean30 = dateAxis29.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset26, categoryAxis27, (org.jfree.chart.axis.ValueAxis) dateAxis29, categoryItemRenderer31);
        boolean boolean33 = categoryPlot32.isOutlineVisible();
        java.awt.Paint paint34 = categoryPlot32.getDomainGridlinePaint();
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range38 = dateAxis37.getDefaultAutoRange();
        xYPlot35.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis37);
        java.awt.Paint paint40 = xYPlot35.getOutlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo42 = null;
        java.awt.geom.Point2D point2D43 = null;
        xYPlot35.zoomRangeAxes((double) (byte) 100, plotRenderingInfo42, point2D43, false);
        java.awt.Stroke stroke46 = xYPlot35.getDomainCrosshairStroke();
        org.jfree.chart.util.Layer layer48 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean50 = layer48.equals((java.lang.Object) true);
        java.util.Collection collection51 = xYPlot35.getRangeMarkers(3, layer48);
        java.util.Collection collection52 = categoryPlot32.getRangeMarkers(layer48);
        java.util.Collection collection53 = categoryPlot9.getDomainMarkers((int) (short) 100, layer48);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
        org.junit.Assert.assertNotNull(categoryAxisArray20);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(layer48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNull(collection51);
        org.junit.Assert.assertNull(collection52);
        org.junit.Assert.assertNull(collection53);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 0.0f, (float) 2);
        java.awt.Color color6 = java.awt.Color.getColor("ChartChangeEventType.DATASET_UPDATED", color5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Paint paint8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker((double) 15, (java.awt.Paint) color5, stroke7, paint8, stroke9, 0.0f);
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker((double) 11);
        java.awt.Paint paint14 = valueMarker13.getPaint();
        valueMarker13.setValue(8.0d);
        org.jfree.chart.plot.IntervalMarker intervalMarker19 = new org.jfree.chart.plot.IntervalMarker((double) 3, 100.0d);
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range23 = dateAxis22.getDefaultAutoRange();
        xYPlot20.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis22);
        java.awt.Stroke stroke25 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot20.setRangeCrosshairStroke(stroke25);
        intervalMarker19.setStroke(stroke25);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor28 = org.jfree.chart.util.RectangleAnchor.CENTER;
        intervalMarker19.setLabelAnchor(rectangleAnchor28);
        valueMarker13.setLabelAnchor(rectangleAnchor28);
        valueMarker11.setLabelAnchor(rectangleAnchor28);
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean36 = dateAxis35.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, (org.jfree.chart.axis.ValueAxis) dateAxis35, categoryItemRenderer37);
        boolean boolean39 = categoryPlot38.isOutlineVisible();
        java.awt.Paint paint40 = categoryPlot38.getDomainGridlinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = categoryPlot38.getDomainAxisForDataset((int) (short) 0);
        java.awt.Font font43 = categoryPlot38.getNoDataMessageFont();
        java.util.List list44 = categoryPlot38.getAnnotations();
        boolean boolean45 = valueMarker11.equals((java.lang.Object) categoryPlot38);
        java.awt.Paint paint46 = categoryPlot38.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = new org.jfree.chart.axis.CategoryAxis();
        int int48 = categoryAxis47.getMaximumCategoryLabelLines();
        int int49 = categoryPlot38.getDomainAxisIndex(categoryAxis47);
        java.awt.Paint paint50 = categoryPlot38.getRangeGridlinePaint();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(rectangleAnchor28);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNull(categoryAxis42);
        org.junit.Assert.assertNotNull(font43);
        org.junit.Assert.assertNotNull(list44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertNotNull(paint50);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean2 = dateAxis1.isNegativeArrowVisible();
        double double3 = dateAxis1.getLowerBound();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean8 = dateAxis7.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer9);
        boolean boolean11 = categoryPlot10.isOutlineVisible();
        categoryPlot10.mapDatasetToDomainAxis(100, (int) 'a');
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        categoryPlot10.setRenderer(255, categoryItemRenderer16, false);
        double double19 = categoryPlot10.getRangeCrosshairValue();
        categoryPlot10.setRangeCrosshairLockedOnData(false);
        boolean boolean22 = dateAxis1.hasListener((java.util.EventListener) categoryPlot10);
        org.jfree.chart.plot.IntervalMarker intervalMarker26 = new org.jfree.chart.plot.IntervalMarker((double) 3, 100.0d);
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range30 = dateAxis29.getDefaultAutoRange();
        xYPlot27.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis29);
        java.awt.Stroke stroke32 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot27.setRangeCrosshairStroke(stroke32);
        intervalMarker26.setStroke(stroke32);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor35 = org.jfree.chart.util.RectangleAnchor.CENTER;
        intervalMarker26.setLabelAnchor(rectangleAnchor35);
        java.awt.Color color37 = java.awt.Color.red;
        intervalMarker26.setLabelPaint((java.awt.Paint) color37);
        org.jfree.chart.plot.XYPlot xYPlot39 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.category.CategoryDataset categoryDataset40 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = null;
        org.jfree.chart.axis.DateAxis dateAxis43 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean44 = dateAxis43.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset40, categoryAxis41, (org.jfree.chart.axis.ValueAxis) dateAxis43, categoryItemRenderer45);
        org.jfree.data.Range range47 = dateAxis43.getRange();
        xYPlot39.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis43);
        dateAxis43.resizeRange((double) 8);
        java.awt.Font font51 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis43.setTickLabelFont(font51);
        intervalMarker26.setLabelFont(font51);
        intervalMarker26.setEndValue((double) 192);
        org.jfree.chart.util.Layer layer56 = null;
        categoryPlot10.addRangeMarker(8, (org.jfree.chart.plot.Marker) intervalMarker26, layer56, true);
        categoryPlot10.setRangeCrosshairLockedOnData(false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(rectangleAnchor35);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(range47);
        org.junit.Assert.assertNotNull(font51);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        int int2 = categoryAxis1.getMaximumCategoryLabelLines();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]", "java.awt.Color[r=0,g=0,b=128]");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor6 = org.jfree.chart.axis.CategoryAnchor.END;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        double double11 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor6, 0, 4, rectangle2D9, rectangleEdge10);
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis12, categoryItemRenderer13);
        double double15 = categoryAxis1.getUpperMargin();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(categoryAnchor6);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.05d + "'", double15 == 0.05d);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 3, 100.0d);
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range6 = dateAxis5.getDefaultAutoRange();
        xYPlot3.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis5);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot3.setRangeCrosshairStroke(stroke8);
        intervalMarker2.setStroke(stroke8);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.CENTER;
        intervalMarker2.setLabelAnchor(rectangleAnchor11);
        java.awt.Color color13 = java.awt.Color.red;
        intervalMarker2.setLabelPaint((java.awt.Paint) color13);
        intervalMarker2.setStartValue(100.0d);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType17 = intervalMarker2.getLabelOffsetType();
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(lengthAdjustmentType17);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean5 = dateAxis4.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        org.jfree.data.Range range8 = dateAxis4.getRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis4);
        org.jfree.chart.axis.AxisSpace axisSpace10 = xYPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape12 = dateAxis11.getLeftArrow();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis11);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNull(axisSpace10);
        org.junit.Assert.assertNotNull(shape12);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        int int8 = categoryPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis7);
        double double9 = dateAxis7.getAutoRangeMinimumSize();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot6.getDrawingSupplier();
        categoryPlot6.clearRangeAxes();
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        categoryPlot6.setFixedRangeAxisSpace(axisSpace10);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean16 = dateAxis15.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, (org.jfree.chart.axis.ValueAxis) dateAxis15, categoryItemRenderer17);
        boolean boolean19 = categoryPlot18.isOutlineVisible();
        java.awt.Paint paint20 = categoryPlot18.getDomainGridlinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = categoryPlot18.getDomainAxisForDataset((int) (short) 0);
        java.awt.Font font23 = categoryPlot18.getNoDataMessageFont();
        categoryPlot6.setNoDataMessageFont(font23);
        boolean boolean25 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot();
        xYPlot26.setRangeZeroBaselineVisible(false);
        boolean boolean29 = xYPlot26.isOutlineVisible();
        xYPlot26.clearRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation32 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot26.setDomainAxisLocation(64, axisLocation32);
        java.awt.Paint paint34 = xYPlot26.getDomainGridlinePaint();
        org.jfree.chart.axis.AxisSpace axisSpace35 = xYPlot26.getFixedRangeAxisSpace();
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range39 = dateAxis38.getDefaultAutoRange();
        xYPlot36.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis38);
        dateAxis38.setUpperMargin(100.0d);
        dateAxis38.setPositiveArrowVisible(false);
        java.awt.Stroke stroke45 = dateAxis38.getTickMarkStroke();
        xYPlot26.setRangeCrosshairStroke(stroke45);
        categoryPlot6.setRangeGridlineStroke(stroke45);
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = new org.jfree.chart.axis.CategoryAxis("SeriesRenderingOrder.FORWARD");
        categoryAxis49.setUpperMargin(0.2d);
        categoryAxis49.setMaximumCategoryLabelLines((-52));
        int int54 = categoryPlot6.getDomainAxisIndex(categoryAxis49);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNull(categoryAxis22);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(axisLocation32);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNull(axisSpace35);
        org.junit.Assert.assertNotNull(range39);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        org.jfree.data.Range range7 = dateAxis3.getRange();
        dateAxis3.setTickMarkOutsideLength(2.0f);
        java.text.DateFormat dateFormat10 = dateAxis3.getDateFormatOverride();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNull(dateFormat10);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("SeriesRenderingOrder.FORWARD");
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean6 = dateAxis5.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer7);
        dateAxis5.resizeRange((double) 100.0f);
        java.util.Date date11 = dateAxis5.getMaximumDate();
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYPlot13.setDomainZeroBaselinePaint(paint14);
        org.jfree.chart.axis.AxisSpace axisSpace16 = xYPlot13.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = xYPlot13.getRangeAxisEdge();
        try {
            double double18 = dateAxis1.dateToJava2D(date11, rectangle2D12, rectangleEdge17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(axisSpace16);
        org.junit.Assert.assertNotNull(rectangleEdge17);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        java.awt.Paint paint5 = xYPlot0.getOutlinePaint();
        xYPlot0.setRangeCrosshairValue(1.0E-8d);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        xYPlot0.setRenderer(3, xYItemRenderer9);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        org.jfree.chart.plot.CrosshairState crosshairState15 = null;
        boolean boolean16 = xYPlot0.render(graphics2D11, rectangle2D12, (-8388608), plotRenderingInfo14, crosshairState15);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        org.jfree.chart.util.Layer layer1 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean2 = datasetRenderingOrder0.equals((java.lang.Object) layer1);
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean7 = dateAxis6.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis6, categoryItemRenderer8);
        java.awt.Paint paint10 = categoryPlot9.getDomainGridlinePaint();
        int int11 = categoryPlot9.getBackgroundImageAlignment();
        boolean boolean12 = datasetRenderingOrder0.equals((java.lang.Object) categoryPlot9);
        java.awt.Stroke stroke13 = null;
        try {
            categoryPlot9.setRangeCrosshairStroke(stroke13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertNotNull(layer1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 15 + "'", int11 == 15);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot6.getDrawingSupplier();
        categoryPlot6.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot6.getDomainAxisEdge(10);
        boolean boolean12 = categoryPlot6.getDrawSharedDomainAxis();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        java.awt.Color color0 = java.awt.Color.yellow;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        java.awt.Paint paint5 = xYPlot0.getOutlinePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = xYPlot0.getRangeAxisEdge();
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = xYPlot0.getOrientation();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean10 = dateAxis9.isNegativeArrowVisible();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis9);
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range15 = dateAxis14.getDefaultAutoRange();
        xYPlot12.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis14);
        dateAxis14.setUpperMargin(100.0d);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.axis.AxisState axisState20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = null;
        java.util.List list23 = dateAxis14.refreshTicks(graphics2D19, axisState20, rectangle2D21, rectangleEdge22);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = dateAxis14.getLabelInsets();
        org.jfree.chart.axis.DateTickUnit dateTickUnit25 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis14.setTickUnit(dateTickUnit25, false, true);
        dateAxis9.setTickUnit(dateTickUnit25, false, true);
        dateAxis9.setTickMarksVisible(true);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(plotOrientation7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNull(list23);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(dateTickUnit25);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setUpperMargin((double) 1.0f);
        boolean boolean4 = dateAxis1.isAutoTickUnitSelection();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot6.getDrawingSupplier();
        categoryPlot6.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot6.getDomainAxisEdge(10);
        boolean boolean12 = categoryPlot6.isDomainZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis14 = categoryPlot6.getRangeAxisForDataset((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(valueAxis14);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        int int1 = objectList0.size();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean6 = dateAxis5.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = dateAxis5.getTickLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        dateAxis10.setTickLabelPaint((java.awt.Paint) color11);
        boolean boolean13 = rectangleInsets9.equals((java.lang.Object) dateAxis10);
        java.lang.String str14 = rectangleInsets9.toString();
        boolean boolean15 = objectList0.equals((java.lang.Object) str14);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str14.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeZeroBaselineVisible(false);
        boolean boolean3 = xYPlot0.isOutlineVisible();
        xYPlot0.clearRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation6 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot0.setDomainAxisLocation(64, axisLocation6);
        xYPlot0.clearRangeAxes();
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        int int10 = xYPlot0.getRangeAxisIndex(valueAxis9);
        org.jfree.data.xy.XYDataset xYDataset11 = xYPlot0.getDataset();
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range16 = dateAxis15.getDefaultAutoRange();
        xYPlot13.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis15);
        dateAxis15.setUpperMargin(100.0d);
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.axis.AxisState axisState21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = null;
        java.util.List list24 = dateAxis15.refreshTicks(graphics2D20, axisState21, rectangle2D22, rectangleEdge23);
        xYPlot0.setDomainAxis(2, (org.jfree.chart.axis.ValueAxis) dateAxis15, false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNull(xYDataset11);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNull(list24);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range4 = dateAxis3.getDefaultAutoRange();
        xYPlot1.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis3);
        java.awt.Paint paint6 = xYPlot1.getOutlinePaint();
        xYPlot1.setRangeCrosshairValue(1.0E-8d);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        xYPlot1.setAxisOffset(rectangleInsets9);
        org.jfree.chart.util.UnitType unitType11 = rectangleInsets9.getUnitType();
        boolean boolean12 = numberAxis0.equals((java.lang.Object) rectangleInsets9);
        java.lang.Object obj13 = numberAxis0.clone();
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(unitType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(obj13);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        org.jfree.data.RangeType rangeType2 = numberAxis1.getRangeType();
        org.junit.Assert.assertNotNull(rangeType2);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeZeroBaselineVisible(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder3 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot0.setRangeAxisLocation((int) (byte) 100, axisLocation5);
        boolean boolean7 = xYPlot0.isDomainGridlinesVisible();
        xYPlot0.setDomainZeroBaselineVisible(false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder3);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        categoryPlot6.clearRangeMarkers(0);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = null;
        categoryPlot6.markerChanged(markerChangeEvent9);
        org.jfree.chart.axis.AxisLocation axisLocation11 = categoryPlot6.getRangeAxisLocation();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(axisLocation11);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYPlot0.setDomainZeroBaselinePaint(paint1);
        org.jfree.chart.axis.AxisSpace axisSpace3 = xYPlot0.getFixedDomainAxisSpace();
        xYPlot0.clearRangeAxes();
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        int int6 = color5.getRed();
        xYPlot0.setRangeCrosshairPaint((java.awt.Paint) color5);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(axisSpace3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 192 + "'", int6 == 192);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        java.awt.Paint paint7 = categoryPlot6.getDomainGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot6.getRenderer((int) (byte) 0);
        categoryPlot6.setRangeGridlinesVisible(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        categoryPlot6.setRenderer(categoryItemRenderer12, false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(categoryItemRenderer9);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.text.NumberFormat numberFormat1 = null;
        numberAxis0.setNumberFormatOverride(numberFormat1);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot6.getDrawingSupplier();
        categoryPlot6.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot6.getDomainAxisEdge(10);
        boolean boolean12 = categoryPlot6.isRangeZoomable();
        java.awt.Paint paint13 = categoryPlot6.getDomainGridlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot6.setDomainAxisLocation(64, axisLocation15, false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder18 = categoryPlot6.getDatasetRenderingOrder();
        categoryPlot6.clearDomainAxes();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder20 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        org.jfree.chart.util.Layer layer21 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean22 = datasetRenderingOrder20.equals((java.lang.Object) layer21);
        java.lang.Object obj23 = null;
        boolean boolean24 = datasetRenderingOrder20.equals(obj23);
        categoryPlot6.setDatasetRenderingOrder(datasetRenderingOrder20);
        org.jfree.chart.util.Layer layer27 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean29 = layer27.equals((java.lang.Object) true);
        java.lang.String str30 = layer27.toString();
        java.util.Collection collection31 = categoryPlot6.getRangeMarkers(13, layer27);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(datasetRenderingOrder18);
        org.junit.Assert.assertNotNull(datasetRenderingOrder20);
        org.junit.Assert.assertNotNull(layer21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(layer27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Layer.FOREGROUND" + "'", str30.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection31);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean2 = dateAxis1.isNegativeArrowVisible();
        dateAxis1.setAutoRangeMinimumSize((double) (short) 1, true);
        java.awt.Shape shape6 = dateAxis1.getUpArrow();
        double double7 = dateAxis1.getFixedDimension();
        org.jfree.data.Range range8 = dateAxis1.getRange();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(range8);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeZeroBaselineVisible(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder3 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot0.setRangeAxisLocation((int) (byte) 100, axisLocation5);
        xYPlot0.setRangeCrosshairVisible(false);
        boolean boolean9 = xYPlot0.isRangeZeroBaselineVisible();
        org.jfree.chart.plot.IntervalMarker intervalMarker12 = new org.jfree.chart.plot.IntervalMarker((double) 3, 100.0d);
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range16 = dateAxis15.getDefaultAutoRange();
        xYPlot13.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis15);
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot13.setRangeCrosshairStroke(stroke18);
        intervalMarker12.setStroke(stroke18);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder21 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean23 = datasetRenderingOrder21.equals((java.lang.Object) layer22);
        boolean boolean24 = xYPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker12, layer22);
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = xYPlot0.getRendererForDataset(xYDataset25);
        org.junit.Assert.assertNotNull(datasetRenderingOrder3);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(datasetRenderingOrder21);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(xYItemRenderer26);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        java.awt.Paint paint5 = xYPlot0.getOutlinePaint();
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        xYPlot7.setRangeZeroBaselineVisible(false);
        boolean boolean10 = xYPlot7.isOutlineVisible();
        xYPlot7.clearRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot7.setDomainAxisLocation(64, axisLocation13);
        xYPlot0.setDomainAxisLocation(2, axisLocation13);
        org.jfree.chart.axis.AxisLocation axisLocation16 = xYPlot0.getDomainAxisLocation();
        xYPlot0.zoom((double) 100.0f);
        java.awt.Paint paint19 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        xYPlot0.setDataset(xYDataset20);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder22 = xYPlot0.getSeriesRenderingOrder();
        java.awt.Paint paint23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        xYPlot0.setDomainCrosshairPaint(paint23);
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = null;
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean29 = dateAxis28.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot(categoryDataset25, categoryAxis26, (org.jfree.chart.axis.ValueAxis) dateAxis28, categoryItemRenderer30);
        boolean boolean32 = categoryPlot31.isRangeCrosshairVisible();
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis33.setCategoryMargin((double) (short) 100);
        categoryPlot31.setDomainAxis(categoryAxis33);
        org.jfree.chart.plot.IntervalMarker intervalMarker40 = new org.jfree.chart.plot.IntervalMarker((double) 3, 100.0d);
        org.jfree.chart.plot.XYPlot xYPlot41 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis43 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range44 = dateAxis43.getDefaultAutoRange();
        xYPlot41.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis43);
        java.awt.Stroke stroke46 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot41.setRangeCrosshairStroke(stroke46);
        intervalMarker40.setStroke(stroke46);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor49 = org.jfree.chart.util.RectangleAnchor.CENTER;
        intervalMarker40.setLabelAnchor(rectangleAnchor49);
        org.jfree.chart.axis.DateAxis dateAxis52 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean53 = dateAxis52.isNegativeArrowVisible();
        double double54 = dateAxis52.getLowerBound();
        java.awt.Paint paint55 = dateAxis52.getTickLabelPaint();
        java.awt.Stroke stroke56 = dateAxis52.getAxisLineStroke();
        intervalMarker40.setStroke(stroke56);
        org.jfree.chart.plot.XYPlot xYPlot58 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint59 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYPlot58.setDomainZeroBaselinePaint(paint59);
        org.jfree.chart.axis.AxisSpace axisSpace61 = xYPlot58.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge62 = xYPlot58.getRangeAxisEdge();
        org.jfree.chart.plot.IntervalMarker intervalMarker65 = new org.jfree.chart.plot.IntervalMarker(0.05d, 0.0d);
        org.jfree.chart.util.Layer layer66 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot58.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker65, layer66);
        categoryPlot31.addRangeMarker((int) ' ', (org.jfree.chart.plot.Marker) intervalMarker40, layer66);
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker40);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(seriesRenderingOrder22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(range44);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(rectangleAnchor49);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertNotNull(paint59);
        org.junit.Assert.assertNull(axisSpace61);
        org.junit.Assert.assertNotNull(rectangleEdge62);
        org.junit.Assert.assertNotNull(layer66);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot6.getDrawingSupplier();
        categoryPlot6.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot6.getDomainAxisEdge(10);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = categoryPlot6.getDomainAxis();
        categoryPlot6.setDomainGridlinesVisible(true);
        categoryPlot6.setDrawSharedDomainAxis(false);
        org.jfree.chart.util.SortOrder sortOrder17 = categoryPlot6.getColumnRenderingOrder();
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint19 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYPlot18.setDomainZeroBaselinePaint(paint19);
        org.jfree.chart.axis.AxisSpace axisSpace21 = xYPlot18.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = xYPlot18.getRangeAxisEdge();
        org.jfree.chart.plot.IntervalMarker intervalMarker25 = new org.jfree.chart.plot.IntervalMarker(0.05d, 0.0d);
        org.jfree.chart.util.Layer layer26 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot18.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker25, layer26);
        boolean boolean28 = categoryPlot6.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker25);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNull(categoryAxis12);
        org.junit.Assert.assertNotNull(sortOrder17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNull(axisSpace21);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertNotNull(layer26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        java.awt.Paint paint5 = xYPlot0.getOutlinePaint();
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        xYPlot7.setRangeZeroBaselineVisible(false);
        boolean boolean10 = xYPlot7.isOutlineVisible();
        xYPlot7.clearRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot7.setDomainAxisLocation(64, axisLocation13);
        xYPlot0.setDomainAxisLocation(2, axisLocation13);
        org.jfree.chart.axis.AxisLocation axisLocation16 = xYPlot0.getDomainAxisLocation();
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation16, plotOrientation17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(axisLocation16);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot6.getDrawingSupplier();
        java.lang.Object obj9 = null;
        boolean boolean10 = categoryPlot6.equals(obj9);
        categoryPlot6.setRangeGridlinesVisible(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = categoryPlot6.getRenderer(4);
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = categoryPlot6.getDomainAxis();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(categoryItemRenderer14);
        org.junit.Assert.assertNull(categoryAxis15);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 3, 100.0d);
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range6 = dateAxis5.getDefaultAutoRange();
        xYPlot3.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis5);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot3.setRangeCrosshairStroke(stroke8);
        intervalMarker2.setStroke(stroke8);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.CENTER;
        intervalMarker2.setLabelAnchor(rectangleAnchor11);
        intervalMarker2.setLabel("");
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeZeroBaselineVisible(false);
        boolean boolean3 = xYPlot0.isOutlineVisible();
        xYPlot0.clearRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation6 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot0.setDomainAxisLocation(64, axisLocation6);
        java.awt.Paint paint8 = xYPlot0.getDomainGridlinePaint();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot0.getRenderer();
        org.jfree.chart.plot.Plot plot10 = xYPlot0.getRootPlot();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertNotNull(plot10);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean2 = dateAxis1.isNegativeArrowVisible();
        double double3 = dateAxis1.getLowerBound();
        java.awt.Paint paint4 = dateAxis1.getTickLabelPaint();
        java.awt.Stroke stroke5 = dateAxis1.getAxisLineStroke();
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean11 = dateAxis10.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis10, categoryItemRenderer12);
        org.jfree.data.Range range14 = dateAxis10.getRange();
        xYPlot6.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis10);
        dateAxis10.resizeRange((double) 8);
        java.awt.Paint paint18 = dateAxis10.getAxisLinePaint();
        java.awt.Shape shape19 = dateAxis10.getDownArrow();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean22 = dateAxis21.isNegativeArrowVisible();
        dateAxis21.setAutoRangeMinimumSize((double) (short) 1, true);
        double double26 = dateAxis21.getFixedAutoRange();
        java.util.Date date27 = dateAxis21.getMinimumDate();
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean32 = dateAxis31.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, (org.jfree.chart.axis.ValueAxis) dateAxis31, categoryItemRenderer33);
        dateAxis31.resizeRange((double) 100.0f);
        java.util.Date date37 = dateAxis31.getMaximumDate();
        org.jfree.data.category.CategoryDataset categoryDataset38 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = null;
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean42 = dateAxis41.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer43 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot(categoryDataset38, categoryAxis39, (org.jfree.chart.axis.ValueAxis) dateAxis41, categoryItemRenderer43);
        java.util.TimeZone timeZone45 = dateAxis41.getTimeZone();
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date37, timeZone45);
        dateAxis10.setRange(date27, date37);
        java.awt.geom.Rectangle2D rectangle2D48 = null;
        org.jfree.chart.plot.XYPlot xYPlot49 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint50 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYPlot49.setDomainZeroBaselinePaint(paint50);
        org.jfree.chart.axis.AxisSpace axisSpace52 = xYPlot49.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge53 = xYPlot49.getRangeAxisEdge();
        try {
            double double54 = dateAxis1.dateToJava2D(date37, rectangle2D48, rectangleEdge53);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(timeZone45);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertNull(axisSpace52);
        org.junit.Assert.assertNotNull(rectangleEdge53);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        java.awt.Stroke stroke5 = numberAxis4.getTickMarkStroke();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit6 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis4.setTickUnit(numberTickUnit6);
        numberAxis2.setTickUnit(numberTickUnit6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        java.awt.Stroke stroke13 = numberAxis12.getTickMarkStroke();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit14 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis12.setTickUnit(numberTickUnit14);
        numberAxis10.setTickUnit(numberTickUnit14);
        numberAxis2.setTickUnit(numberTickUnit14);
        org.jfree.data.RangeType rangeType18 = numberAxis2.getRangeType();
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        java.awt.Stroke stroke23 = numberAxis22.getTickMarkStroke();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit24 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis22.setTickUnit(numberTickUnit24);
        numberAxis20.setTickUnit(numberTickUnit24);
        numberAxis2.setTickUnit(numberTickUnit24, false, false);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        java.awt.Stroke stroke32 = numberAxis31.getTickMarkStroke();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit33 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis31.setTickUnit(numberTickUnit33);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = null;
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis31, xYItemRenderer35);
        java.util.List list37 = xYPlot36.getAnnotations();
        java.awt.Paint paint38 = xYPlot36.getDomainZeroBaselinePaint();
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(numberTickUnit6);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(numberTickUnit14);
        org.junit.Assert.assertNotNull(rangeType18);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(numberTickUnit24);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(numberTickUnit33);
        org.junit.Assert.assertNotNull(list37);
        org.junit.Assert.assertNotNull(paint38);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairVisible();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis8.setCategoryMargin((double) (short) 100);
        categoryPlot6.setDomainAxis(categoryAxis8);
        categoryAxis8.setCategoryMargin((double) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit0 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.JFreeChart jFreeChart3 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType4 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        java.lang.String str5 = chartChangeEventType4.toString();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) textAnchor2, jFreeChart3, chartChangeEventType4);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent7 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) numberTickUnit0, jFreeChart1, chartChangeEventType4);
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) 11);
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range13 = dateAxis12.getDefaultAutoRange();
        xYPlot10.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis12);
        java.awt.Paint paint15 = xYPlot10.getOutlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        xYPlot10.zoomRangeAxes((double) (byte) 100, plotRenderingInfo17, point2D18, false);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean25 = dateAxis24.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, (org.jfree.chart.axis.ValueAxis) dateAxis24, categoryItemRenderer26);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = dateAxis24.getTickLabelInsets();
        xYPlot10.setInsets(rectangleInsets28, false);
        boolean boolean31 = valueMarker9.equals((java.lang.Object) rectangleInsets28);
        double double32 = valueMarker9.getValue();
        boolean boolean33 = chartChangeEventType4.equals((java.lang.Object) double32);
        org.junit.Assert.assertNotNull(numberTickUnit0);
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(chartChangeEventType4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str5.equals("ChartChangeEventType.DATASET_UPDATED"));
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 11.0d + "'", double32 == 11.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeZeroBaselineVisible(false);
        boolean boolean3 = xYPlot0.isOutlineVisible();
        xYPlot0.clearRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation6 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot0.setDomainAxisLocation(64, axisLocation6);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean10 = dateAxis9.isNegativeArrowVisible();
        double double11 = dateAxis9.getLowerBound();
        java.awt.Paint paint12 = dateAxis9.getTickLabelPaint();
        java.awt.Stroke stroke13 = dateAxis9.getAxisLineStroke();
        xYPlot0.setDomainGridlineStroke(stroke13);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent15 = null;
        xYPlot0.rendererChanged(rendererChangeEvent15);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation17 = null;
        try {
            xYPlot0.addAnnotation(xYAnnotation17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeZeroBaselineVisible(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder3 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot0.setRangeAxisLocation((int) (byte) 100, axisLocation5);
        boolean boolean7 = xYPlot0.isDomainGridlinesVisible();
        xYPlot0.setOutlineVisible(true);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder10 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean13 = dateAxis12.isNegativeArrowVisible();
        double double14 = dateAxis12.getLowerBound();
        dateAxis12.setAutoRange(false);
        org.jfree.data.Range range17 = xYPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis12);
        org.jfree.chart.plot.IntervalMarker intervalMarker20 = new org.jfree.chart.plot.IntervalMarker((double) 3, 100.0d);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean25 = dateAxis24.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, (org.jfree.chart.axis.ValueAxis) dateAxis24, categoryItemRenderer26);
        boolean boolean28 = categoryPlot27.isOutlineVisible();
        java.awt.Paint paint29 = categoryPlot27.getDomainGridlinePaint();
        java.lang.String str30 = categoryPlot27.getNoDataMessage();
        intervalMarker20.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot27);
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker20);
        org.junit.Assert.assertNotNull(datasetRenderingOrder3);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(seriesRenderingOrder10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNull(str30);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        java.awt.Font font8 = categoryPlot6.getNoDataMessageFont();
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = categoryPlot6.getRangeAxisEdge((int) (short) 10);
        categoryPlot6.setRangeCrosshairValue((double) (short) -1);
        java.awt.Stroke stroke13 = categoryPlot6.getRangeGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation15 = null;
        categoryPlot6.setDomainAxisLocation((int) (short) 1, axisLocation15);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) 3.0d, "ChartChangeEventType.DATASET_UPDATED");
        categoryAxis0.setMaximumCategoryLabelLines((int) ' ');
        categoryAxis0.setCategoryMargin((double) (-52));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot6.getDrawingSupplier();
        categoryPlot6.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot6.getDomainAxisEdge(10);
        boolean boolean12 = categoryPlot6.isRangeZoomable();
        java.awt.Paint paint13 = categoryPlot6.getDomainGridlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot6.setDomainAxisLocation(64, axisLocation15, false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder18 = categoryPlot6.getDatasetRenderingOrder();
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean23 = dateAxis22.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, (org.jfree.chart.axis.ValueAxis) dateAxis22, categoryItemRenderer24);
        dateAxis22.resizeRange((double) 100.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = dateAxis22.getLabelInsets();
        categoryPlot6.setAxisOffset(rectangleInsets28);
        categoryPlot6.setRangeGridlinesVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = categoryPlot6.getDomainAxisEdge();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(datasetRenderingOrder18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(rectangleEdge32);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 3, 100.0d);
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range6 = dateAxis5.getDefaultAutoRange();
        xYPlot3.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis5);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot3.setRangeCrosshairStroke(stroke8);
        intervalMarker2.setStroke(stroke8);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.CENTER;
        intervalMarker2.setLabelAnchor(rectangleAnchor11);
        java.awt.Color color13 = java.awt.Color.red;
        intervalMarker2.setLabelPaint((java.awt.Paint) color13);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType15 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        intervalMarker2.setLabelOffsetType(lengthAdjustmentType15);
        java.awt.Paint paint17 = intervalMarker2.getPaint();
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(lengthAdjustmentType15);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getMaximumCategoryLabelLines();
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) 100.0d, "DatasetRenderingOrder.REVERSE");
        categoryAxis0.setMaximumCategoryLabelWidthRatio((float) (byte) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot6.getDrawingSupplier();
        categoryPlot6.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot6.getDomainAxisEdge(10);
        boolean boolean12 = categoryPlot6.isRangeZoomable();
        java.awt.Paint paint13 = categoryPlot6.getDomainGridlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot6.setDomainAxisLocation(64, axisLocation15, false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder18 = categoryPlot6.getDatasetRenderingOrder();
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean23 = dateAxis22.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, (org.jfree.chart.axis.ValueAxis) dateAxis22, categoryItemRenderer24);
        dateAxis22.resizeRange((double) 100.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = dateAxis22.getLabelInsets();
        categoryPlot6.setAxisOffset(rectangleInsets28);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = categoryPlot6.getDomainAxisEdge((-1));
        org.jfree.chart.plot.Marker marker33 = null;
        org.jfree.data.category.CategoryDataset categoryDataset34 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = null;
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean38 = dateAxis37.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset34, categoryAxis35, (org.jfree.chart.axis.ValueAxis) dateAxis37, categoryItemRenderer39);
        boolean boolean41 = categoryPlot40.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier42 = categoryPlot40.getDrawingSupplier();
        categoryPlot40.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = categoryPlot40.getDomainAxisEdge(10);
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = categoryPlot40.getDomainAxis();
        categoryPlot40.setDomainGridlinesVisible(true);
        boolean boolean49 = categoryPlot40.isDomainZoomable();
        java.awt.Color color52 = java.awt.Color.LIGHT_GRAY;
        org.jfree.chart.plot.XYPlot xYPlot53 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.category.CategoryDataset categoryDataset54 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis55 = null;
        org.jfree.chart.axis.DateAxis dateAxis57 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean58 = dateAxis57.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer59 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot(categoryDataset54, categoryAxis55, (org.jfree.chart.axis.ValueAxis) dateAxis57, categoryItemRenderer59);
        org.jfree.data.Range range61 = dateAxis57.getRange();
        xYPlot53.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis57);
        java.awt.Stroke stroke63 = xYPlot53.getDomainCrosshairStroke();
        org.jfree.chart.plot.XYPlot xYPlot64 = new org.jfree.chart.plot.XYPlot();
        xYPlot64.setRangeZeroBaselineVisible(false);
        boolean boolean67 = xYPlot64.isOutlineVisible();
        xYPlot64.clearRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation70 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot64.setDomainAxisLocation(64, axisLocation70);
        org.jfree.chart.axis.DateAxis dateAxis73 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean74 = dateAxis73.isNegativeArrowVisible();
        double double75 = dateAxis73.getLowerBound();
        java.awt.Paint paint76 = dateAxis73.getTickLabelPaint();
        java.awt.Stroke stroke77 = dateAxis73.getAxisLineStroke();
        xYPlot64.setDomainGridlineStroke(stroke77);
        xYPlot53.setRangeCrosshairStroke(stroke77);
        org.jfree.chart.plot.CategoryMarker categoryMarker80 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]", (java.awt.Paint) color52, stroke77);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder81 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        org.jfree.chart.util.Layer layer82 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean83 = datasetRenderingOrder81.equals((java.lang.Object) layer82);
        categoryPlot40.addDomainMarker(0, categoryMarker80, layer82, false);
        try {
            boolean boolean86 = categoryPlot6.removeRangeMarker(15, marker33, layer82);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(datasetRenderingOrder18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(drawingSupplier42);
        org.junit.Assert.assertNotNull(rectangleEdge45);
        org.junit.Assert.assertNull(categoryAxis46);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(range61);
        org.junit.Assert.assertNotNull(stroke63);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertNotNull(axisLocation70);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
        org.junit.Assert.assertNotNull(paint76);
        org.junit.Assert.assertNotNull(stroke77);
        org.junit.Assert.assertNotNull(datasetRenderingOrder81);
        org.junit.Assert.assertNotNull(layer82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean2 = dateAxis1.isNegativeArrowVisible();
        dateAxis1.setAutoRangeMinimumSize((double) (short) 1, true);
        org.jfree.chart.axis.Timeline timeline6 = null;
        dateAxis1.setTimeline(timeline6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean12 = dateAxis11.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis11, categoryItemRenderer13);
        boolean boolean15 = categoryPlot14.isOutlineVisible();
        java.awt.Paint paint16 = categoryPlot14.getDomainGridlinePaint();
        java.lang.String str17 = categoryPlot14.getNoDataMessage();
        dateAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot14);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = categoryPlot14.getDomainAxisEdge((int) '#');
        int int21 = categoryPlot14.getBackgroundImageAlignment();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 15 + "'", int21 == 15);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = dateAxis3.getTickLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        dateAxis8.setTickLabelPaint((java.awt.Paint) color9);
        boolean boolean11 = rectangleInsets7.equals((java.lang.Object) dateAxis8);
        boolean boolean12 = dateAxis8.isTickMarksVisible();
        boolean boolean13 = dateAxis8.isNegativeArrowVisible();
        dateAxis8.setLowerMargin((double) (-8355712));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        java.awt.Font font8 = categoryPlot6.getNoDataMessageFont();
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = categoryPlot6.getRangeAxisEdge((int) (short) 10);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        categoryPlot6.setFixedRangeAxisSpace(axisSpace11);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean17 = dateAxis16.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis16, categoryItemRenderer18);
        boolean boolean20 = categoryPlot19.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier21 = categoryPlot19.getDrawingSupplier();
        categoryPlot19.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = categoryPlot19.getDomainAxisEdge(10);
        boolean boolean25 = categoryPlot19.isRangeZoomable();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        categoryPlot19.setRenderer(categoryItemRenderer26, true);
        categoryPlot19.setRangeCrosshairValue((double) 10.0f);
        org.jfree.chart.axis.AxisLocation axisLocation31 = categoryPlot19.getRangeAxisLocation();
        categoryPlot6.setRangeAxisLocation(axisLocation31);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(drawingSupplier21);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(axisLocation31);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean2 = dateAxis1.isNegativeArrowVisible();
        dateAxis1.setAutoRangeMinimumSize((double) (short) 1, true);
        org.jfree.data.Range range6 = dateAxis1.getDefaultAutoRange();
        dateAxis1.setPositiveArrowVisible(false);
        boolean boolean9 = dateAxis1.isVisible();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        org.jfree.chart.plot.Marker marker5 = null;
        boolean boolean6 = xYPlot0.removeDomainMarker(marker5);
        xYPlot0.setDomainCrosshairValue((double) (-1), true);
        java.lang.Object obj10 = xYPlot0.clone();
        org.jfree.chart.axis.ValueAxis valueAxis11 = xYPlot0.getDomainAxis();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(valueAxis11);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeZeroBaselineVisible(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder3 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot0.setRangeAxisLocation((int) (byte) 100, axisLocation5);
        java.awt.Stroke stroke7 = xYPlot0.getDomainCrosshairStroke();
        xYPlot0.setOutlineVisible(true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder3);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        int int1 = objectList0.size();
        java.lang.Object obj3 = objectList0.get((int) ' ');
        int int4 = objectList0.size();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        categoryPlot6.mapDatasetToDomainAxis(100, (int) 'a');
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        categoryPlot6.setRenderer(255, categoryItemRenderer12, false);
        double double15 = categoryPlot6.getRangeCrosshairValue();
        org.jfree.data.general.Dataset dataset16 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent17 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) categoryPlot6, dataset16);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder18 = categoryPlot6.getDatasetRenderingOrder();
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        boolean boolean20 = datasetRenderingOrder18.equals((java.lang.Object) color19);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(datasetRenderingOrder18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        categoryPlot6.mapDatasetToDomainAxis(100, (int) 'a');
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        categoryPlot6.setRenderer(255, categoryItemRenderer12, false);
        org.jfree.chart.util.SortOrder sortOrder15 = categoryPlot6.getColumnRenderingOrder();
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean21 = dateAxis20.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis20, categoryItemRenderer22);
        boolean boolean24 = categoryPlot23.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier25 = categoryPlot23.getDrawingSupplier();
        categoryPlot23.clearRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation27 = categoryPlot23.getRangeAxisLocation();
        try {
            categoryPlot6.setDomainAxisLocation((-8388608), axisLocation27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(sortOrder15);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(drawingSupplier25);
        org.junit.Assert.assertNotNull(axisLocation27);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        java.awt.Paint paint5 = xYPlot0.getOutlinePaint();
        xYPlot0.setRangeCrosshairValue(1.0E-8d);
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace8);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean5 = dateAxis4.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        org.jfree.data.Range range8 = dateAxis4.getRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis4);
        dateAxis4.resizeRange((double) 8);
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        xYPlot12.setRangeZeroBaselineVisible(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder15 = xYPlot12.getDatasetRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation17 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot12.setRangeAxisLocation((int) (byte) 100, axisLocation17);
        xYPlot12.setRangeCrosshairVisible(false);
        boolean boolean21 = xYPlot12.isRangeZeroBaselineVisible();
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        xYPlot12.setDomainGridlinePaint((java.awt.Paint) color22);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer25 = xYPlot12.getRenderer((int) '4');
        dateAxis4.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot12);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder27 = xYPlot12.getSeriesRenderingOrder();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        xYPlot12.setRenderer(xYItemRenderer28);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(datasetRenderingOrder15);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNull(xYItemRenderer25);
        org.junit.Assert.assertNotNull(seriesRenderingOrder27);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        java.awt.Paint paint8 = categoryPlot6.getDomainGridlinePaint();
        java.lang.String str9 = categoryPlot6.getNoDataMessage();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        categoryPlot6.setRangeCrosshairPaint((java.awt.Paint) color10);
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range15 = dateAxis14.getDefaultAutoRange();
        xYPlot12.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis14);
        java.awt.Paint paint17 = xYPlot12.getOutlinePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = xYPlot12.getRangeAxisEdge();
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean23 = dateAxis22.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, (org.jfree.chart.axis.ValueAxis) dateAxis22, categoryItemRenderer24);
        boolean boolean26 = categoryPlot25.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier27 = categoryPlot25.getDrawingSupplier();
        categoryPlot25.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = categoryPlot25.getDomainAxisEdge(10);
        boolean boolean31 = categoryPlot25.isRangeZoomable();
        java.awt.Paint paint32 = categoryPlot25.getDomainGridlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation34 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot25.setDomainAxisLocation(64, axisLocation34, false);
        xYPlot12.setRangeAxisLocation(axisLocation34, false);
        categoryPlot6.setRangeAxisLocation(axisLocation34, false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(drawingSupplier27);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(axisLocation34);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        categoryPlot6.clearRangeMarkers(0);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = null;
        categoryPlot6.markerChanged(markerChangeEvent9);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot6.getDomainAxisEdge();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        int int13 = categoryPlot6.getIndexOf(categoryItemRenderer12);
        org.jfree.chart.axis.AxisSpace axisSpace14 = null;
        categoryPlot6.setFixedRangeAxisSpace(axisSpace14);
        java.awt.Paint paint16 = categoryPlot6.getRangeGridlinePaint();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean5 = dateAxis4.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        org.jfree.data.Range range8 = dateAxis4.getRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis4);
        java.awt.Stroke stroke10 = xYPlot0.getDomainCrosshairStroke();
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        xYPlot11.setRangeZeroBaselineVisible(false);
        boolean boolean14 = xYPlot11.isOutlineVisible();
        xYPlot11.clearRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation17 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot11.setDomainAxisLocation(64, axisLocation17);
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean21 = dateAxis20.isNegativeArrowVisible();
        double double22 = dateAxis20.getLowerBound();
        java.awt.Paint paint23 = dateAxis20.getTickLabelPaint();
        java.awt.Stroke stroke24 = dateAxis20.getAxisLineStroke();
        xYPlot11.setDomainGridlineStroke(stroke24);
        xYPlot0.setRangeCrosshairStroke(stroke24);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = xYPlot0.getDomainAxisEdge((int) (short) 1);
        java.awt.Paint paint29 = xYPlot0.getRangeTickBandPaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        try {
            xYPlot0.handleClick((int) '4', (-4145152), plotRenderingInfo32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertNull(paint29);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 1560409200000L, (double) 'a');
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range2 = dateAxis1.getDefaultAutoRange();
        java.awt.Paint paint3 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        dateAxis1.setAxisLinePaint(paint3);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        java.awt.Stroke stroke9 = numberAxis8.getTickMarkStroke();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit10 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis8.setTickUnit(numberTickUnit10);
        numberAxis6.setTickUnit(numberTickUnit10);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        java.awt.Stroke stroke17 = numberAxis16.getTickMarkStroke();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit18 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis16.setTickUnit(numberTickUnit18);
        numberAxis14.setTickUnit(numberTickUnit18);
        numberAxis6.setTickUnit(numberTickUnit18);
        org.jfree.data.RangeType rangeType22 = numberAxis6.getRangeType();
        org.jfree.data.Range range23 = numberAxis6.getDefaultAutoRange();
        dateAxis1.setRange(range23, true, true);
        dateAxis1.setAutoTickUnitSelection(false, true);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(numberTickUnit10);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(numberTickUnit18);
        org.junit.Assert.assertNotNull(rangeType22);
        org.junit.Assert.assertNotNull(range23);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYPlot0.setDomainZeroBaselinePaint(paint1);
        org.jfree.chart.axis.AxisSpace axisSpace3 = xYPlot0.getFixedDomainAxisSpace();
        java.awt.Stroke stroke4 = xYPlot0.getDomainCrosshairStroke();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot0.getSeriesRenderingOrder();
        boolean boolean6 = xYPlot0.isRangeCrosshairLockedOnData();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(axisSpace3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean5 = dateAxis4.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        boolean boolean8 = categoryPlot7.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = categoryPlot7.getDrawingSupplier();
        java.lang.Object obj10 = null;
        boolean boolean11 = categoryPlot7.equals(obj10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        int int13 = categoryPlot7.getIndexOf(categoryItemRenderer12);
        boolean boolean14 = unitType0.equals((java.lang.Object) int13);
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range18 = dateAxis17.getDefaultAutoRange();
        xYPlot15.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis17);
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean23 = dateAxis22.isTickLabelsVisible();
        xYPlot15.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis22, true);
        boolean boolean26 = unitType0.equals((java.lang.Object) true);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(drawingSupplier9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeZeroBaselineVisible(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder3 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot0.setRangeAxisLocation((int) (byte) 100, axisLocation5);
        xYPlot0.setRangeCrosshairVisible(false);
        boolean boolean9 = xYPlot0.isRangeZeroBaselineVisible();
        org.jfree.chart.plot.IntervalMarker intervalMarker12 = new org.jfree.chart.plot.IntervalMarker((double) 3, 100.0d);
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range16 = dateAxis15.getDefaultAutoRange();
        xYPlot13.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis15);
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot13.setRangeCrosshairStroke(stroke18);
        intervalMarker12.setStroke(stroke18);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder21 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean23 = datasetRenderingOrder21.equals((java.lang.Object) layer22);
        boolean boolean24 = xYPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker12, layer22);
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range28 = dateAxis27.getDefaultAutoRange();
        xYPlot25.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis27);
        java.awt.Paint paint30 = xYPlot25.getOutlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        java.awt.geom.Point2D point2D33 = null;
        xYPlot25.zoomRangeAxes((double) (byte) 100, plotRenderingInfo32, point2D33, false);
        java.awt.Stroke stroke36 = xYPlot25.getDomainCrosshairStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = new org.jfree.chart.util.RectangleInsets((double) (byte) 1, (-1.0d), (double) (byte) 1, (double) 10.0f);
        xYPlot25.setAxisOffset(rectangleInsets41);
        xYPlot0.setAxisOffset(rectangleInsets41);
        org.junit.Assert.assertNotNull(datasetRenderingOrder3);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(datasetRenderingOrder21);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(stroke36);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 0.0f, (float) 2);
        java.awt.Color color6 = java.awt.Color.getColor("ChartChangeEventType.DATASET_UPDATED", color5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Paint paint8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker((double) 15, (java.awt.Paint) color5, stroke7, paint8, stroke9, 0.0f);
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker((double) 11);
        java.awt.Paint paint14 = valueMarker13.getPaint();
        valueMarker13.setValue(8.0d);
        org.jfree.chart.plot.IntervalMarker intervalMarker19 = new org.jfree.chart.plot.IntervalMarker((double) 3, 100.0d);
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range23 = dateAxis22.getDefaultAutoRange();
        xYPlot20.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis22);
        java.awt.Stroke stroke25 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot20.setRangeCrosshairStroke(stroke25);
        intervalMarker19.setStroke(stroke25);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor28 = org.jfree.chart.util.RectangleAnchor.CENTER;
        intervalMarker19.setLabelAnchor(rectangleAnchor28);
        valueMarker13.setLabelAnchor(rectangleAnchor28);
        valueMarker11.setLabelAnchor(rectangleAnchor28);
        org.jfree.chart.text.TextAnchor textAnchor32 = valueMarker11.getLabelTextAnchor();
        double double33 = valueMarker11.getValue();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(rectangleAnchor28);
        org.junit.Assert.assertNotNull(textAnchor32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 15.0d + "'", double33 == 15.0d);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = dateAxis3.getTickLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        dateAxis8.setTickLabelPaint((java.awt.Paint) color9);
        boolean boolean11 = rectangleInsets7.equals((java.lang.Object) dateAxis8);
        double double13 = rectangleInsets7.calculateBottomInset(1.0E-8d);
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D17 = rectangleInsets7.createOutsetRectangle(rectangle2D14, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.0d + "'", double13 == 2.0d);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean5 = dateAxis4.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        java.util.TimeZone timeZone8 = dateAxis4.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("SortOrder.ASCENDING", timeZone8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        dateAxis9.setLabelPaint((java.awt.Paint) color10);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation0, plotOrientation1);
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range6 = dateAxis5.getDefaultAutoRange();
        xYPlot3.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis5);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        xYPlot3.setDataset(xYDataset8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        xYPlot3.setDomainTickBandPaint((java.awt.Paint) color10);
        org.jfree.chart.axis.ValueAxis valueAxis12 = xYPlot3.getRangeAxis();
        org.jfree.chart.plot.PlotOrientation plotOrientation13 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        xYPlot3.setOrientation(plotOrientation13);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation0, plotOrientation13);
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNotNull(plotOrientation13);
        org.junit.Assert.assertNotNull(rectangleEdge15);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        java.awt.Paint paint5 = xYPlot0.getOutlinePaint();
        xYPlot0.setDomainCrosshairValue((double) 9, true);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeZeroBaselineVisible(false);
        boolean boolean3 = xYPlot0.isOutlineVisible();
        xYPlot0.clearRangeAxes();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean7 = dateAxis6.isNegativeArrowVisible();
        dateAxis6.setAutoRangeMinimumSize((double) (short) 1, true);
        org.jfree.chart.axis.Timeline timeline11 = null;
        dateAxis6.setTimeline(timeline11);
        float float13 = dateAxis6.getTickMarkInsideLength();
        java.awt.Stroke stroke14 = dateAxis6.getAxisLineStroke();
        xYPlot0.setDomainZeroBaselineStroke(stroke14);
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range19 = dateAxis18.getDefaultAutoRange();
        xYPlot16.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis18);
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        xYPlot16.setDataset(xYDataset21);
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        xYPlot16.setDomainTickBandPaint((java.awt.Paint) color23);
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range28 = dateAxis27.getDefaultAutoRange();
        xYPlot25.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis27);
        java.awt.Paint paint30 = xYPlot25.getOutlinePaint();
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot();
        xYPlot32.setRangeZeroBaselineVisible(false);
        boolean boolean35 = xYPlot32.isOutlineVisible();
        xYPlot32.clearRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation38 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot32.setDomainAxisLocation(64, axisLocation38);
        xYPlot25.setDomainAxisLocation(2, axisLocation38);
        boolean boolean41 = color23.equals((java.lang.Object) 2);
        int int42 = color23.getGreen();
        xYPlot0.setDomainTickBandPaint((java.awt.Paint) color23);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.0f + "'", float13 == 0.0f);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(axisLocation38);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYPlot0.setDomainZeroBaselinePaint(paint1);
        xYPlot0.setRangeGridlinesVisible(true);
        xYPlot0.configureDomainAxes();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range12 = dateAxis11.getDefaultAutoRange();
        xYPlot9.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis11);
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        xYPlot9.setDataset(xYDataset14);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        xYPlot9.setDomainTickBandPaint((java.awt.Paint) color16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = xYPlot9.getRangeAxis();
        org.jfree.chart.plot.PlotOrientation plotOrientation19 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        xYPlot9.setOrientation(plotOrientation19);
        java.awt.geom.Point2D point2D21 = xYPlot9.getQuadrantOrigin();
        xYPlot0.zoomDomainAxes((-1.0d), (double) (short) 1, plotRenderingInfo8, point2D21);
        java.lang.Object obj23 = null;
        boolean boolean24 = xYPlot0.equals(obj23);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(valueAxis18);
        org.junit.Assert.assertNotNull(plotOrientation19);
        org.junit.Assert.assertNotNull(point2D21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

//    @Test
//    public void test302() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test302");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getMiddleMillisecond();
//        int int2 = day0.getDayOfMonth();
//        long long3 = day0.getFirstMillisecond();
//        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
//        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("hi!");
//        boolean boolean8 = dateAxis7.isNegativeArrowVisible();
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer9);
//        boolean boolean11 = categoryPlot10.isOutlineVisible();
//        boolean boolean12 = day0.equals((java.lang.Object) categoryPlot10);
//        org.jfree.chart.axis.AxisSpace axisSpace13 = null;
//        categoryPlot10.setFixedRangeAxisSpace(axisSpace13, true);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560452399999L + "'", long1 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0.8f);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = categoryMarker1.getLabelOffset();
        double double3 = rectangleInsets2.getRight();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.0d + "'", double3 == 3.0d);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        dateAxis3.resizeRange((double) 100.0f);
        java.util.Date date9 = dateAxis3.getMaximumDate();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean14 = dateAxis13.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis13, categoryItemRenderer15);
        java.util.TimeZone timeZone17 = dateAxis13.getTimeZone();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date9, timeZone17);
        java.lang.Object obj19 = null;
        int int20 = day18.compareTo(obj19);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        org.jfree.chart.util.Layer layer1 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean2 = datasetRenderingOrder0.equals((java.lang.Object) layer1);
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean7 = dateAxis6.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis6, categoryItemRenderer8);
        java.awt.Paint paint10 = categoryPlot9.getDomainGridlinePaint();
        int int11 = categoryPlot9.getBackgroundImageAlignment();
        boolean boolean12 = datasetRenderingOrder0.equals((java.lang.Object) categoryPlot9);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean17 = dateAxis16.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis16, categoryItemRenderer18);
        java.awt.Paint paint20 = categoryPlot19.getDomainGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = categoryPlot19.getRenderer((int) (byte) 0);
        org.jfree.chart.LegendItemCollection legendItemCollection23 = categoryPlot19.getFixedLegendItems();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double26 = rectangleInsets24.calculateTopOutset(0.0d);
        categoryPlot19.setAxisOffset(rectangleInsets24);
        categoryPlot9.setAxisOffset(rectangleInsets24);
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape31 = dateAxis30.getLeftArrow();
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean36 = dateAxis35.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, (org.jfree.chart.axis.ValueAxis) dateAxis35, categoryItemRenderer37);
        dateAxis35.resizeRange((double) 100.0f);
        java.awt.Shape shape41 = dateAxis35.getDownArrow();
        dateAxis30.setDownArrow(shape41);
        try {
            categoryPlot9.setRangeAxis((-100), (org.jfree.chart.axis.ValueAxis) dateAxis30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertNotNull(layer1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 15 + "'", int11 == 15);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNull(categoryItemRenderer22);
        org.junit.Assert.assertNull(legendItemCollection23);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 4.0d + "'", double26 == 4.0d);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(shape41);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot6.getDrawingSupplier();
        categoryPlot6.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot6.getDomainAxisEdge(10);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean16 = dateAxis15.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, (org.jfree.chart.axis.ValueAxis) dateAxis15, categoryItemRenderer17);
        dateAxis15.resizeRange((double) 100.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = dateAxis15.getLabelInsets();
        int int22 = categoryPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis15);
        org.jfree.chart.LegendItemCollection legendItemCollection23 = categoryPlot6.getLegendItems();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(legendItemCollection23);
    }

//    @Test
//    public void test307() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test307");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        java.lang.String str2 = day0.toString();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean2 = dateAxis1.isNegativeArrowVisible();
        dateAxis1.setAutoRangeMinimumSize((double) (short) 1, true);
        java.awt.Shape shape6 = dateAxis1.getUpArrow();
        dateAxis1.setRangeAboutValue(0.0d, (double) (byte) 10);
        java.awt.Shape shape10 = dateAxis1.getUpArrow();
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range14 = dateAxis13.getDefaultAutoRange();
        xYPlot11.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis13);
        org.jfree.chart.plot.Marker marker16 = null;
        boolean boolean17 = xYPlot11.removeDomainMarker(marker16);
        xYPlot11.setDomainCrosshairValue((double) (-1), true);
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean23 = dateAxis22.isNegativeArrowVisible();
        double double24 = dateAxis22.getLowerBound();
        dateAxis22.setAutoRange(false);
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = null;
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean31 = dateAxis30.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer32 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis28, (org.jfree.chart.axis.ValueAxis) dateAxis30, categoryItemRenderer32);
        dateAxis30.resizeRange((double) 100.0f);
        java.util.Date date36 = dateAxis30.getMaximumDate();
        org.jfree.data.category.CategoryDataset categoryDataset37 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = null;
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean41 = dateAxis40.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer42 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset37, categoryAxis38, (org.jfree.chart.axis.ValueAxis) dateAxis40, categoryItemRenderer42);
        java.util.TimeZone timeZone44 = dateAxis40.getTimeZone();
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date36, timeZone44);
        dateAxis22.setMinimumDate(date36);
        int int47 = xYPlot11.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis22);
        java.awt.Shape shape48 = dateAxis22.getRightArrow();
        dateAxis1.setUpArrow(shape48);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(timeZone44);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertNotNull(shape48);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 3, 100.0d);
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range6 = dateAxis5.getDefaultAutoRange();
        xYPlot3.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis5);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot3.setRangeCrosshairStroke(stroke8);
        intervalMarker2.setStroke(stroke8);
        double double11 = intervalMarker2.getEndValue();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean14 = dateAxis13.isNegativeArrowVisible();
        double double15 = dateAxis13.getLowerBound();
        java.awt.Paint paint16 = dateAxis13.getTickLabelPaint();
        dateAxis13.setPositiveArrowVisible(false);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean23 = dateAxis22.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, (org.jfree.chart.axis.ValueAxis) dateAxis22, categoryItemRenderer24);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = dateAxis22.getTickLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        dateAxis27.setTickLabelPaint((java.awt.Paint) color28);
        boolean boolean30 = rectangleInsets26.equals((java.lang.Object) dateAxis27);
        java.lang.String str31 = rectangleInsets26.toString();
        org.jfree.chart.util.UnitType unitType32 = rectangleInsets26.getUnitType();
        double double33 = rectangleInsets26.getBottom();
        double double35 = rectangleInsets26.calculateRightInset(0.0d);
        dateAxis13.setLabelInsets(rectangleInsets26);
        double double38 = rectangleInsets26.calculateLeftInset((double) (byte) 0);
        intervalMarker2.setLabelOffset(rectangleInsets26);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor40 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder41 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        java.lang.String str42 = datasetRenderingOrder41.toString();
        boolean boolean43 = rectangleAnchor40.equals((java.lang.Object) str42);
        java.awt.Color color44 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        int int45 = color44.getBlue();
        boolean boolean46 = rectangleAnchor40.equals((java.lang.Object) color44);
        intervalMarker2.setOutlinePaint((java.awt.Paint) color44);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 100.0d + "'", double11 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str31.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
        org.junit.Assert.assertNotNull(unitType32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 2.0d + "'", double33 == 2.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 4.0d + "'", double35 == 4.0d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 4.0d + "'", double38 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor40);
        org.junit.Assert.assertNotNull(datasetRenderingOrder41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "DatasetRenderingOrder.REVERSE" + "'", str42.equals("DatasetRenderingOrder.REVERSE"));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 128 + "'", int45 == 128);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        org.jfree.chart.plot.IntervalMarker intervalMarker3 = new org.jfree.chart.plot.IntervalMarker((double) 64, (double) 12);
        boolean boolean4 = seriesRenderingOrder0.equals((java.lang.Object) 12);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean9 = dateAxis8.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis8, categoryItemRenderer10);
        boolean boolean12 = categoryPlot11.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier13 = categoryPlot11.getDrawingSupplier();
        categoryPlot11.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = categoryPlot11.getDomainAxisEdge(10);
        boolean boolean17 = categoryPlot11.isRangeZoomable();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        categoryPlot11.setRenderer(categoryItemRenderer18, true);
        boolean boolean21 = seriesRenderingOrder0.equals((java.lang.Object) categoryPlot11);
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(drawingSupplier13);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        java.awt.Color color1 = java.awt.Color.LIGHT_GRAY;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean7 = dateAxis6.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis6, categoryItemRenderer8);
        org.jfree.data.Range range10 = dateAxis6.getRange();
        xYPlot2.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        java.awt.Stroke stroke12 = xYPlot2.getDomainCrosshairStroke();
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        xYPlot13.setRangeZeroBaselineVisible(false);
        boolean boolean16 = xYPlot13.isOutlineVisible();
        xYPlot13.clearRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation19 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot13.setDomainAxisLocation(64, axisLocation19);
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean23 = dateAxis22.isNegativeArrowVisible();
        double double24 = dateAxis22.getLowerBound();
        java.awt.Paint paint25 = dateAxis22.getTickLabelPaint();
        java.awt.Stroke stroke26 = dateAxis22.getAxisLineStroke();
        xYPlot13.setDomainGridlineStroke(stroke26);
        xYPlot2.setRangeCrosshairStroke(stroke26);
        org.jfree.chart.plot.CategoryMarker categoryMarker29 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]", (java.awt.Paint) color1, stroke26);
        boolean boolean30 = categoryMarker29.getDrawAsLine();
        boolean boolean31 = categoryMarker29.getDrawAsLine();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean2 = dateAxis1.isTickLabelsVisible();
        org.jfree.data.time.DateRange dateRange3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis1.setRange((org.jfree.data.Range) dateRange3);
        dateAxis1.setTickMarksVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = dateAxis1.getLabelInsets();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(dateRange3);
        org.junit.Assert.assertNotNull(rectangleInsets7);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot6.getDrawingSupplier();
        categoryPlot6.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot6.getDomainAxisEdge(10);
        categoryPlot6.configureDomainAxes();
        org.jfree.chart.axis.AxisLocation axisLocation14 = categoryPlot6.getDomainAxisLocation(100);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNotNull(axisLocation14);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        java.awt.Font font8 = categoryPlot6.getNoDataMessageFont();
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = categoryPlot6.getRangeAxisEdge((int) (short) 10);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        categoryPlot6.setDomainAxis(categoryAxis11);
        java.awt.Stroke stroke13 = categoryPlot6.getDomainGridlineStroke();
        java.lang.Object obj14 = categoryPlot6.clone();
        float float15 = categoryPlot6.getForegroundAlpha();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 1.0f + "'", float15 == 1.0f);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot6.getDrawingSupplier();
        categoryPlot6.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot6.getDomainAxisEdge(10);
        boolean boolean12 = categoryPlot6.isRangeZoomable();
        java.awt.Paint paint13 = categoryPlot6.getDomainGridlinePaint();
        boolean boolean14 = categoryPlot6.isDomainGridlinesVisible();
        boolean boolean15 = categoryPlot6.isDomainGridlinesVisible();
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        categoryPlot6.removeChangeListener(plotChangeListener16);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot6.getDrawingSupplier();
        categoryPlot6.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot6.getDomainAxisEdge(10);
        boolean boolean12 = categoryPlot6.isRangeZoomable();
        categoryPlot6.setOutlineVisible(true);
        org.jfree.chart.util.SortOrder sortOrder15 = categoryPlot6.getRowRenderingOrder();
        boolean boolean16 = categoryPlot6.getDrawSharedDomainAxis();
        org.jfree.chart.axis.AxisLocation axisLocation17 = categoryPlot6.getDomainAxisLocation();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        categoryPlot6.setRenderer((int) (byte) 0, categoryItemRenderer19, false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(sortOrder15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(axisLocation17);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        boolean boolean4 = rectangleAnchor0.equals((java.lang.Object) range3);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 64, (double) 12);
        java.lang.Object obj3 = intervalMarker2.clone();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer4 = intervalMarker2.getGradientPaintTransformer();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNull(gradientPaintTransformer4);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot6.getDrawingSupplier();
        categoryPlot6.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot6.getDomainAxisEdge(10);
        boolean boolean12 = categoryPlot6.isRangeZoomable();
        java.awt.Paint paint13 = categoryPlot6.getDomainGridlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot6.setDomainAxisLocation(64, axisLocation15, false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder18 = categoryPlot6.getDatasetRenderingOrder();
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean23 = dateAxis22.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, (org.jfree.chart.axis.ValueAxis) dateAxis22, categoryItemRenderer24);
        dateAxis22.resizeRange((double) 100.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = dateAxis22.getLabelInsets();
        categoryPlot6.setAxisOffset(rectangleInsets28);
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean32 = dateAxis31.isTickLabelsVisible();
        dateAxis31.setLabelURL("Layer.FOREGROUND");
        java.awt.Shape shape35 = dateAxis31.getRightArrow();
        org.jfree.data.Range range36 = categoryPlot6.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis31);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(datasetRenderingOrder18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNull(range36);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        java.awt.Paint paint5 = xYPlot0.getOutlinePaint();
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        xYPlot7.setRangeZeroBaselineVisible(false);
        boolean boolean10 = xYPlot7.isOutlineVisible();
        xYPlot7.clearRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot7.setDomainAxisLocation(64, axisLocation13);
        xYPlot0.setDomainAxisLocation(2, axisLocation13);
        xYPlot0.setRangeCrosshairValue((double) (short) 10);
        org.jfree.chart.plot.IntervalMarker intervalMarker21 = new org.jfree.chart.plot.IntervalMarker((double) 3, 100.0d);
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range25 = dateAxis24.getDefaultAutoRange();
        xYPlot22.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis24);
        java.awt.Stroke stroke27 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot22.setRangeCrosshairStroke(stroke27);
        intervalMarker21.setStroke(stroke27);
        java.awt.Color color30 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        intervalMarker21.setOutlinePaint((java.awt.Paint) color30);
        double double32 = intervalMarker21.getEndValue();
        org.jfree.chart.util.Layer layer33 = null;
        boolean boolean34 = xYPlot0.removeRangeMarker(2, (org.jfree.chart.plot.Marker) intervalMarker21, layer33);
        intervalMarker21.setEndValue((double) 12);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 100.0d + "'", double32 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        java.awt.Stroke stroke5 = numberAxis4.getTickMarkStroke();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit6 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis4.setTickUnit(numberTickUnit6);
        numberAxis2.setTickUnit(numberTickUnit6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        java.awt.Stroke stroke13 = numberAxis12.getTickMarkStroke();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit14 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis12.setTickUnit(numberTickUnit14);
        numberAxis10.setTickUnit(numberTickUnit14);
        numberAxis2.setTickUnit(numberTickUnit14);
        org.jfree.data.RangeType rangeType18 = numberAxis2.getRangeType();
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        java.awt.Stroke stroke23 = numberAxis22.getTickMarkStroke();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit24 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis22.setTickUnit(numberTickUnit24);
        numberAxis20.setTickUnit(numberTickUnit24);
        numberAxis2.setTickUnit(numberTickUnit24, false, false);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        java.awt.Stroke stroke32 = numberAxis31.getTickMarkStroke();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit33 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis31.setTickUnit(numberTickUnit33);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = null;
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis31, xYItemRenderer35);
        java.util.List list37 = xYPlot36.getAnnotations();
        org.jfree.chart.axis.AxisLocation axisLocation39 = xYPlot36.getDomainAxisLocation(64);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(numberTickUnit6);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(numberTickUnit14);
        org.junit.Assert.assertNotNull(rangeType18);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(numberTickUnit24);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(numberTickUnit33);
        org.junit.Assert.assertNotNull(list37);
        org.junit.Assert.assertNotNull(axisLocation39);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray1 = null;
        java.awt.Paint[] paintArray2 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray3 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray4 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray5 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier6 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, paintArray2, strokeArray3, strokeArray4, shapeArray5);
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertNotNull(strokeArray3);
        org.junit.Assert.assertNotNull(strokeArray4);
        org.junit.Assert.assertNotNull(shapeArray5);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean2 = dateAxis1.isNegativeArrowVisible();
        double double3 = dateAxis1.getLowerBound();
        dateAxis1.setAutoRange(false);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean10 = dateAxis9.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis9, categoryItemRenderer11);
        dateAxis9.resizeRange((double) 100.0f);
        java.util.Date date15 = dateAxis9.getMaximumDate();
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean20 = dateAxis19.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, (org.jfree.chart.axis.ValueAxis) dateAxis19, categoryItemRenderer21);
        java.util.TimeZone timeZone23 = dateAxis19.getTimeZone();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date15, timeZone23);
        dateAxis1.setMinimumDate(date15);
        double double26 = dateAxis1.getLowerBound();
        dateAxis1.setLowerMargin(0.0d);
        java.lang.String str29 = dateAxis1.getLabelToolTip();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 50.0d + "'", double26 == 50.0d);
        org.junit.Assert.assertNull(str29);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot6.getDrawingSupplier();
        categoryPlot6.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot6.getDomainAxisEdge(10);
        boolean boolean12 = categoryPlot6.isRangeZoomable();
        java.awt.Paint paint13 = categoryPlot6.getDomainGridlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot6.setDomainAxisLocation(64, axisLocation15, false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder18 = categoryPlot6.getDatasetRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation19 = categoryPlot6.getRangeAxisLocation();
        org.jfree.chart.axis.AxisLocation axisLocation20 = categoryPlot6.getDomainAxisLocation();
        org.jfree.chart.axis.AxisLocation axisLocation21 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation22 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation21, plotOrientation22);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation20, plotOrientation22);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(datasetRenderingOrder18);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNotNull(plotOrientation22);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNotNull(rectangleEdge24);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeZeroBaselineVisible(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder3 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot0.setRangeAxisLocation((int) (byte) 100, axisLocation5);
        xYPlot0.setRangeCrosshairVisible(false);
        boolean boolean9 = xYPlot0.isRangeZeroBaselineVisible();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        xYPlot0.setDomainGridlinePaint((java.awt.Paint) color10);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = xYPlot0.getRenderer((int) '4');
        org.jfree.chart.util.Layer layer15 = null;
        java.util.Collection collection16 = xYPlot0.getRangeMarkers((int) (byte) 1, layer15);
        java.awt.geom.Point2D point2D17 = xYPlot0.getQuadrantOrigin();
        org.junit.Assert.assertNotNull(datasetRenderingOrder3);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNull(xYItemRenderer13);
        org.junit.Assert.assertNull(collection16);
        org.junit.Assert.assertNotNull(point2D17);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.trimWidth((double) 8);
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            rectangleInsets0.trim(rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot6.getDrawingSupplier();
        java.lang.Object obj9 = null;
        boolean boolean10 = categoryPlot6.equals(obj9);
        categoryPlot6.setRangeGridlinesVisible(true);
        categoryPlot6.setOutlineVisible(false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        java.awt.Paint paint5 = xYPlot0.getOutlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        xYPlot0.zoomRangeAxes((double) (byte) 100, plotRenderingInfo7, point2D8, false);
        java.awt.Stroke stroke11 = xYPlot0.getRangeGridlineStroke();
        int int12 = xYPlot0.getRangeAxisCount();
        xYPlot0.setWeight(100);
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        try {
            xYPlot0.drawOutline(graphics2D15, rectangle2D16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
        java.awt.Stroke stroke2 = numberAxis1.getTickMarkStroke();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis1.setTickUnit(numberTickUnit3);
        boolean boolean5 = numberAxis1.isAutoTickUnitSelection();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean10 = dateAxis9.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis9, categoryItemRenderer11);
        org.jfree.data.Range range13 = dateAxis9.getRange();
        numberAxis1.setRange(range13, false, false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit17 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis1.setTickUnit(numberTickUnit17, false, true);
        boolean boolean21 = numberAxis1.isTickLabelsVisible();
        numberAxis1.configure();
        numberAxis1.setLowerMargin((double) (-57600000L));
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(numberTickUnit3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNotNull(numberTickUnit17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        dateAxis2.setUpperMargin(100.0d);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.axis.AxisState axisState8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        java.util.List list11 = dateAxis2.refreshTicks(graphics2D7, axisState8, rectangle2D9, rectangleEdge10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = dateAxis2.getLabelInsets();
        dateAxis2.setTickLabelsVisible(true);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNull(list11);
        org.junit.Assert.assertNotNull(rectangleInsets12);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        java.awt.Paint paint5 = xYPlot0.getOutlinePaint();
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        xYPlot7.setRangeZeroBaselineVisible(false);
        boolean boolean10 = xYPlot7.isOutlineVisible();
        xYPlot7.clearRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot7.setDomainAxisLocation(64, axisLocation13);
        xYPlot0.setDomainAxisLocation(2, axisLocation13);
        org.jfree.chart.axis.AxisLocation axisLocation16 = xYPlot0.getDomainAxisLocation();
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean22 = dateAxis21.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis21, categoryItemRenderer23);
        org.jfree.data.Range range25 = dateAxis21.getRange();
        xYPlot17.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis21);
        dateAxis21.resizeRange((double) 8);
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range31 = dateAxis30.getDefaultAutoRange();
        java.awt.Paint paint32 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        dateAxis30.setAxisLinePaint(paint32);
        dateAxis30.setAutoRange(true);
        org.jfree.data.category.CategoryDataset categoryDataset36 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = null;
        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean40 = dateAxis39.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer41 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis37, (org.jfree.chart.axis.ValueAxis) dateAxis39, categoryItemRenderer41);
        org.jfree.chart.axis.DateAxis dateAxis43 = new org.jfree.chart.axis.DateAxis();
        int int44 = categoryPlot42.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis43);
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean47 = dateAxis46.isNegativeArrowVisible();
        org.jfree.data.category.CategoryDataset categoryDataset48 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = null;
        org.jfree.chart.axis.DateAxis dateAxis51 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean52 = dateAxis51.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset48, categoryAxis49, (org.jfree.chart.axis.ValueAxis) dateAxis51, categoryItemRenderer53);
        dateAxis51.resizeRange((double) 100.0f);
        java.awt.Shape shape57 = dateAxis51.getDownArrow();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray58 = new org.jfree.chart.axis.ValueAxis[] { dateAxis21, dateAxis30, dateAxis43, dateAxis46, dateAxis51 };
        xYPlot0.setDomainAxes(valueAxisArray58);
        boolean boolean60 = xYPlot0.isDomainZoomable();
        org.jfree.chart.plot.XYPlot xYPlot61 = new org.jfree.chart.plot.XYPlot();
        xYPlot61.setRangeZeroBaselineVisible(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder64 = xYPlot61.getDatasetRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation66 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot61.setRangeAxisLocation((int) (byte) 100, axisLocation66);
        xYPlot61.setRangeCrosshairVisible(false);
        boolean boolean70 = xYPlot61.isRangeZeroBaselineVisible();
        java.awt.Color color71 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        xYPlot61.setDomainGridlinePaint((java.awt.Paint) color71);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer74 = xYPlot61.getRenderer((int) '4');
        org.jfree.chart.axis.AxisLocation axisLocation75 = xYPlot61.getDomainAxisLocation();
        xYPlot0.setDomainAxisLocation(axisLocation75, false);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(shape57);
        org.junit.Assert.assertNotNull(valueAxisArray58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder64);
        org.junit.Assert.assertNotNull(axisLocation66);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(color71);
        org.junit.Assert.assertNull(xYItemRenderer74);
        org.junit.Assert.assertNotNull(axisLocation75);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 100, 198.0d, 6.0d, (double) 4);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D6 = rectangleInsets4.createOutsetRectangle(rectangle2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, 0.0f, (float) 2);
        java.awt.Color color6 = java.awt.Color.getColor("ChartChangeEventType.DATASET_UPDATED", color5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Paint paint8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker((double) 15, (java.awt.Paint) color5, stroke7, paint8, stroke9, 0.0f);
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker((double) 11);
        java.awt.Paint paint14 = valueMarker13.getPaint();
        valueMarker13.setValue(8.0d);
        org.jfree.chart.plot.IntervalMarker intervalMarker19 = new org.jfree.chart.plot.IntervalMarker((double) 3, 100.0d);
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range23 = dateAxis22.getDefaultAutoRange();
        xYPlot20.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis22);
        java.awt.Stroke stroke25 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot20.setRangeCrosshairStroke(stroke25);
        intervalMarker19.setStroke(stroke25);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor28 = org.jfree.chart.util.RectangleAnchor.CENTER;
        intervalMarker19.setLabelAnchor(rectangleAnchor28);
        valueMarker13.setLabelAnchor(rectangleAnchor28);
        valueMarker11.setLabelAnchor(rectangleAnchor28);
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean36 = dateAxis35.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, (org.jfree.chart.axis.ValueAxis) dateAxis35, categoryItemRenderer37);
        boolean boolean39 = categoryPlot38.isOutlineVisible();
        java.awt.Paint paint40 = categoryPlot38.getDomainGridlinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = categoryPlot38.getDomainAxisForDataset((int) (short) 0);
        java.awt.Font font43 = categoryPlot38.getNoDataMessageFont();
        java.util.List list44 = categoryPlot38.getAnnotations();
        boolean boolean45 = valueMarker11.equals((java.lang.Object) categoryPlot38);
        java.awt.Paint paint46 = categoryPlot38.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = new org.jfree.chart.axis.CategoryAxis();
        int int48 = categoryAxis47.getMaximumCategoryLabelLines();
        int int49 = categoryPlot38.getDomainAxisIndex(categoryAxis47);
        int int50 = categoryAxis47.getMaximumCategoryLabelLines();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(rectangleAnchor28);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNull(categoryAxis42);
        org.junit.Assert.assertNotNull(font43);
        org.junit.Assert.assertNotNull(list44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.plot.ValueMarker valueMarker2 = new org.jfree.chart.plot.ValueMarker((double) 11);
        java.awt.Paint paint3 = valueMarker2.getPaint();
        valueMarker2.setValue(8.0d);
        org.jfree.chart.plot.IntervalMarker intervalMarker8 = new org.jfree.chart.plot.IntervalMarker((double) 3, 100.0d);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range12 = dateAxis11.getDefaultAutoRange();
        xYPlot9.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis11);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot9.setRangeCrosshairStroke(stroke14);
        intervalMarker8.setStroke(stroke14);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = org.jfree.chart.util.RectangleAnchor.CENTER;
        intervalMarker8.setLabelAnchor(rectangleAnchor17);
        valueMarker2.setLabelAnchor(rectangleAnchor17);
        try {
            java.awt.geom.Point2D point2D20 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(rectangleAnchor17);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean2 = dateAxis1.isNegativeArrowVisible();
        dateAxis1.setAutoTickUnitSelection(false, false);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        xYPlot6.setRangeZeroBaselineVisible(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        xYPlot6.zoomRangeAxes(0.0d, (double) 11, plotRenderingInfo11, point2D12);
        java.awt.Paint paint14 = xYPlot6.getRangeGridlinePaint();
        dateAxis1.setLabelPaint(paint14);
        dateAxis1.setAutoRangeMinimumSize(1.560452399991E12d, true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        org.jfree.chart.plot.Marker marker5 = null;
        boolean boolean6 = xYPlot0.removeDomainMarker(marker5);
        xYPlot0.setDomainCrosshairValue((double) (-1), true);
        org.jfree.chart.plot.Plot plot10 = xYPlot0.getParent();
        int int11 = xYPlot0.getDomainAxisCount();
        xYPlot0.setForegroundAlpha((float) 25568L);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(plot10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean2 = dateAxis1.isTickLabelsVisible();
        org.jfree.data.time.DateRange dateRange3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis1.setRange((org.jfree.data.Range) dateRange3);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean9 = dateAxis8.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis8, categoryItemRenderer10);
        dateAxis8.resizeRange((double) 100.0f);
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean16 = dateAxis15.isNegativeArrowVisible();
        double double17 = dateAxis15.getLowerBound();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range20 = dateAxis19.getDefaultAutoRange();
        dateAxis15.setRange(range20);
        dateAxis8.setDefaultAutoRange(range20);
        dateAxis1.setRange(range20, true, true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(dateRange3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(range20);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range3 = dateAxis2.getDefaultAutoRange();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
        java.awt.Paint paint5 = xYPlot0.getOutlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        xYPlot0.zoomRangeAxes((double) (byte) 100, plotRenderingInfo7, point2D8, false);
        java.awt.Stroke stroke11 = xYPlot0.getRangeGridlineStroke();
        int int12 = xYPlot0.getRangeAxisCount();
        java.awt.Stroke stroke13 = xYPlot0.getRangeCrosshairStroke();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 11);
        java.awt.Paint paint2 = valueMarker1.getPaint();
        valueMarker1.setValue(8.0d);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range8 = dateAxis7.getDefaultAutoRange();
        xYPlot5.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis7);
        java.awt.Paint paint10 = xYPlot5.getOutlinePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = xYPlot5.getRangeAxisEdge();
        org.jfree.chart.plot.PlotOrientation plotOrientation12 = xYPlot5.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection13 = xYPlot5.getLegendItems();
        xYPlot5.setRangeZeroBaselineVisible(false);
        valueMarker1.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot5);
        valueMarker1.setValue(0.0d);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNotNull(plotOrientation12);
        org.junit.Assert.assertNotNull(legendItemCollection13);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        dateAxis3.resizeRange((double) 100.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = dateAxis3.getLabelInsets();
        double double11 = rectangleInsets9.extendWidth((double) 0);
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D13 = rectangleInsets9.createInsetRectangle(rectangle2D12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 6.0d + "'", double11 == 6.0d);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range5 = dateAxis4.getDefaultAutoRange();
        xYPlot2.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis4);
        java.awt.Paint paint7 = xYPlot2.getOutlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        xYPlot2.zoomRangeAxes((double) (byte) 100, plotRenderingInfo9, point2D10, false);
        java.awt.Stroke stroke13 = xYPlot2.getDomainCrosshairStroke();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean16 = dateAxis15.isNegativeArrowVisible();
        double double17 = dateAxis15.getLowerBound();
        java.awt.Paint paint18 = dateAxis15.getTickLabelPaint();
        java.awt.Stroke stroke19 = dateAxis15.getAxisLineStroke();
        xYPlot2.setDomainGridlineStroke(stroke19);
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color1, stroke19);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(stroke19);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getMaximumCategoryLabelLines();
        categoryAxis0.setTickLabelsVisible(false);
        categoryAxis0.configure();
        double double5 = categoryAxis0.getCategoryMargin();
        double double6 = categoryAxis0.getUpperMargin();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 255, (double) 12);
        java.awt.Color color3 = java.awt.Color.RED;
        intervalMarker2.setLabelPaint((java.awt.Paint) color3);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot6.getDrawingSupplier();
        categoryPlot6.clearRangeAxes();
        categoryPlot6.setBackgroundAlpha((float) 10L);
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range16 = dateAxis15.getDefaultAutoRange();
        xYPlot13.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis15);
        java.awt.Paint paint18 = xYPlot13.getOutlinePaint();
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        xYPlot20.setRangeZeroBaselineVisible(false);
        boolean boolean23 = xYPlot20.isOutlineVisible();
        xYPlot20.clearRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation26 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot20.setDomainAxisLocation(64, axisLocation26);
        xYPlot13.setDomainAxisLocation(2, axisLocation26);
        xYPlot13.setRangeCrosshairValue((double) (short) 10);
        org.jfree.chart.plot.IntervalMarker intervalMarker34 = new org.jfree.chart.plot.IntervalMarker((double) 3, 100.0d);
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range38 = dateAxis37.getDefaultAutoRange();
        xYPlot35.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis37);
        java.awt.Stroke stroke40 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot35.setRangeCrosshairStroke(stroke40);
        intervalMarker34.setStroke(stroke40);
        java.awt.Color color43 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        intervalMarker34.setOutlinePaint((java.awt.Paint) color43);
        double double45 = intervalMarker34.getEndValue();
        org.jfree.chart.util.Layer layer46 = null;
        boolean boolean47 = xYPlot13.removeRangeMarker(2, (org.jfree.chart.plot.Marker) intervalMarker34, layer46);
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis50 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range51 = dateAxis50.getDefaultAutoRange();
        xYPlot48.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis50);
        java.awt.Paint paint53 = xYPlot48.getOutlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo55 = null;
        java.awt.geom.Point2D point2D56 = null;
        xYPlot48.zoomRangeAxes((double) (byte) 100, plotRenderingInfo55, point2D56, false);
        org.jfree.chart.plot.IntervalMarker intervalMarker62 = new org.jfree.chart.plot.IntervalMarker((double) 3, 100.0d);
        org.jfree.data.category.CategoryDataset categoryDataset63 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis64 = null;
        org.jfree.chart.axis.DateAxis dateAxis66 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean67 = dateAxis66.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer68 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot69 = new org.jfree.chart.plot.CategoryPlot(categoryDataset63, categoryAxis64, (org.jfree.chart.axis.ValueAxis) dateAxis66, categoryItemRenderer68);
        boolean boolean70 = categoryPlot69.isOutlineVisible();
        java.awt.Paint paint71 = categoryPlot69.getDomainGridlinePaint();
        java.lang.String str72 = categoryPlot69.getNoDataMessage();
        intervalMarker62.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot69);
        org.jfree.chart.util.Layer layer74 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot48.addRangeMarker((int) (short) 1, (org.jfree.chart.plot.Marker) intervalMarker62, layer74);
        boolean boolean76 = categoryPlot6.removeRangeMarker((int) (short) 100, (org.jfree.chart.plot.Marker) intervalMarker34, layer74);
        categoryPlot6.configureRangeAxes();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 100.0d + "'", double45 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(range51);
        org.junit.Assert.assertNotNull(paint53);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNotNull(paint71);
        org.junit.Assert.assertNull(str72);
        org.junit.Assert.assertNotNull(layer74);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeZeroBaselineVisible(false);
        boolean boolean3 = xYPlot0.isOutlineVisible();
        xYPlot0.clearRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation6 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot0.setDomainAxisLocation(64, axisLocation6);
        java.awt.Paint paint8 = xYPlot0.getDomainGridlinePaint();
        java.awt.geom.Point2D point2D9 = null;
        try {
            xYPlot0.setQuadrantOrigin(point2D9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'origin' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        dateAxis3.resizeRange((double) 100.0f);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean15 = dateAxis14.isNegativeArrowVisible();
        dateAxis14.setAutoRangeMinimumSize((double) (short) 1, true);
        org.jfree.chart.axis.Timeline timeline19 = null;
        dateAxis14.setTimeline(timeline19);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean25 = dateAxis24.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, (org.jfree.chart.axis.ValueAxis) dateAxis24, categoryItemRenderer26);
        boolean boolean28 = categoryPlot27.isOutlineVisible();
        java.awt.Paint paint29 = categoryPlot27.getDomainGridlinePaint();
        java.lang.String str30 = categoryPlot27.getNoDataMessage();
        dateAxis14.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot27);
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = categoryPlot27.getDomainAxisEdge((int) '#');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        try {
            org.jfree.chart.axis.AxisState axisState35 = dateAxis3.draw(graphics2D9, (double) (byte) 0, rectangle2D11, rectangle2D12, rectangleEdge33, plotRenderingInfo34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertNotNull(rectangleEdge33);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean2 = dateAxis1.isNegativeArrowVisible();
        double double3 = dateAxis1.getLowerBound();
        dateAxis1.setUpperMargin(0.2d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 3, 100.0d);
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range6 = dateAxis5.getDefaultAutoRange();
        xYPlot3.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis5);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot3.setRangeCrosshairStroke(stroke8);
        intervalMarker2.setStroke(stroke8);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        java.lang.String str12 = rectangleInsets11.toString();
        double double14 = rectangleInsets11.extendWidth(0.0d);
        intervalMarker2.setLabelOffset(rectangleInsets11);
        double double17 = rectangleInsets11.calculateRightInset((double) (-1L));
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]" + "'", str12.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 16.0d + "'", double14 == 16.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 8.0d + "'", double17 == 8.0d);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.lang.String str1 = color0.toString();
        int int2 = color0.getRGB();
        float[] floatArray12 = new float[] { 1, 1L, 0L };
        float[] floatArray13 = java.awt.Color.RGBtoHSB((int) (short) -1, 8, 0, floatArray12);
        float[] floatArray14 = java.awt.Color.RGBtoHSB(11, (int) '#', 15, floatArray13);
        float[] floatArray15 = color0.getRGBColorComponents(floatArray13);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java.awt.Color[r=128,g=0,b=0]" + "'", str1.equals("java.awt.Color[r=128,g=0,b=0]"));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-8388608) + "'", int2 == (-8388608));
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray15);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot6.getDrawingSupplier();
        categoryPlot6.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot6.getDomainAxisEdge(10);
        boolean boolean12 = categoryPlot6.isRangeZoomable();
        java.awt.Paint paint13 = categoryPlot6.getDomainGridlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot6.setDomainAxisLocation(64, axisLocation15, false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder18 = categoryPlot6.getDatasetRenderingOrder();
        categoryPlot6.clearDomainAxes();
        float float20 = categoryPlot6.getBackgroundAlpha();
        java.awt.Stroke stroke21 = categoryPlot6.getRangeGridlineStroke();
        float float22 = categoryPlot6.getBackgroundImageAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation23 = null;
        try {
            categoryPlot6.setDomainAxisLocation(axisLocation23, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(datasetRenderingOrder18);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 1.0f + "'", float20 == 1.0f);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 0.5f + "'", float22 == 0.5f);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeZeroBaselineVisible(false);
        boolean boolean3 = xYPlot0.isOutlineVisible();
        xYPlot0.configureRangeAxes();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isOutlineVisible();
        java.awt.Paint paint8 = categoryPlot6.getDomainGridlinePaint();
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range12 = dateAxis11.getDefaultAutoRange();
        xYPlot9.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis11);
        java.awt.Paint paint14 = xYPlot9.getOutlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        xYPlot9.zoomRangeAxes((double) (byte) 100, plotRenderingInfo16, point2D17, false);
        java.awt.Stroke stroke20 = xYPlot9.getDomainCrosshairStroke();
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean24 = layer22.equals((java.lang.Object) true);
        java.util.Collection collection25 = xYPlot9.getRangeMarkers(3, layer22);
        java.util.Collection collection26 = categoryPlot6.getRangeMarkers(layer22);
        org.jfree.chart.axis.AxisLocation axisLocation27 = categoryPlot6.getDomainAxisLocation();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation28 = null;
        try {
            categoryPlot6.addAnnotation(categoryAnnotation28, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertNull(collection26);
        org.junit.Assert.assertNotNull(axisLocation27);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        java.awt.Paint paint7 = categoryPlot6.getDomainGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot6.getRenderer((int) (byte) 0);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        categoryPlot6.setRenderer(categoryItemRenderer10);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder12 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        org.jfree.chart.util.Layer layer13 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean14 = datasetRenderingOrder12.equals((java.lang.Object) layer13);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean19 = dateAxis18.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, (org.jfree.chart.axis.ValueAxis) dateAxis18, categoryItemRenderer20);
        java.awt.Paint paint22 = categoryPlot21.getDomainGridlinePaint();
        int int23 = categoryPlot21.getBackgroundImageAlignment();
        boolean boolean24 = datasetRenderingOrder12.equals((java.lang.Object) categoryPlot21);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent25 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot21);
        categoryPlot6.notifyListeners(plotChangeEvent25);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(categoryItemRenderer9);
        org.junit.Assert.assertNotNull(datasetRenderingOrder12);
        org.junit.Assert.assertNotNull(layer13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 15 + "'", int23 == 15);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeZeroBaselineVisible(false);
        boolean boolean3 = xYPlot0.isOutlineVisible();
        xYPlot0.clearRangeAxes();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean7 = dateAxis6.isNegativeArrowVisible();
        dateAxis6.setAutoRangeMinimumSize((double) (short) 1, true);
        org.jfree.chart.axis.Timeline timeline11 = null;
        dateAxis6.setTimeline(timeline11);
        float float13 = dateAxis6.getTickMarkInsideLength();
        java.awt.Stroke stroke14 = dateAxis6.getAxisLineStroke();
        xYPlot0.setDomainZeroBaselineStroke(stroke14);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder16 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot0.setDatasetRenderingOrder(datasetRenderingOrder16);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.0f + "'", float13 == 0.0f);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(datasetRenderingOrder16);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = dateAxis3.getTickLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        dateAxis8.setTickLabelPaint((java.awt.Paint) color9);
        boolean boolean11 = rectangleInsets7.equals((java.lang.Object) dateAxis8);
        dateAxis8.resizeRange((double) 3);
        dateAxis8.setLabelAngle((double) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Paint[] paintArray3 = new java.awt.Paint[] { color1, color2 };
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Paint paint5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Paint paint7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        java.awt.Paint[] paintArray8 = new java.awt.Paint[] { color4, paint5, color6, paint7 };
        java.awt.Stroke stroke9 = null;
        java.awt.Stroke[] strokeArray10 = new java.awt.Stroke[] { stroke9 };
        java.awt.Stroke[] strokeArray11 = null;
        java.awt.Shape[] shapeArray12 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier13 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray3, paintArray8, strokeArray10, strokeArray11, shapeArray12);
        java.lang.Object obj14 = defaultDrawingSupplier13.clone();
        java.awt.Shape shape15 = defaultDrawingSupplier13.getNextShape();
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paintArray3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paintArray8);
        org.junit.Assert.assertNotNull(strokeArray10);
        org.junit.Assert.assertNotNull(shapeArray12);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(shape15);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        java.awt.Color color1 = java.awt.Color.LIGHT_GRAY;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean7 = dateAxis6.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis6, categoryItemRenderer8);
        org.jfree.data.Range range10 = dateAxis6.getRange();
        xYPlot2.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        java.awt.Stroke stroke12 = xYPlot2.getDomainCrosshairStroke();
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        xYPlot13.setRangeZeroBaselineVisible(false);
        boolean boolean16 = xYPlot13.isOutlineVisible();
        xYPlot13.clearRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation19 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot13.setDomainAxisLocation(64, axisLocation19);
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean23 = dateAxis22.isNegativeArrowVisible();
        double double24 = dateAxis22.getLowerBound();
        java.awt.Paint paint25 = dateAxis22.getTickLabelPaint();
        java.awt.Stroke stroke26 = dateAxis22.getAxisLineStroke();
        xYPlot13.setDomainGridlineStroke(stroke26);
        xYPlot2.setRangeCrosshairStroke(stroke26);
        org.jfree.chart.plot.CategoryMarker categoryMarker29 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]", (java.awt.Paint) color1, stroke26);
        boolean boolean30 = categoryMarker29.getDrawAsLine();
        java.lang.Comparable comparable31 = categoryMarker29.getKey();
        java.lang.Object obj32 = null;
        boolean boolean33 = categoryMarker29.equals(obj32);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + comparable31 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", comparable31.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }
}

