import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.Timeline timeline2 = dateAxis1.getTimeline();
        boolean boolean4 = dateAxis1.isHiddenValue((long) (byte) 1);
        org.jfree.chart.axis.Timeline timeline5 = dateAxis1.getTimeline();
        java.util.Date date6 = dateAxis1.getMaximumDate();
        org.jfree.data.Range range7 = null;
        org.jfree.data.Range range9 = org.jfree.data.Range.expandToInclude(range7, (-1.0d));
        boolean boolean11 = range9.contains((double) 1);
        org.jfree.data.Range range14 = org.jfree.data.Range.shift(range9, (double) 100, false);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot15 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.Plot plot16 = multiplePiePlot15.getParent();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent17 = null;
        multiplePiePlot15.markerChanged(markerChangeEvent17);
        java.lang.Comparable comparable19 = multiplePiePlot15.getAggregatedItemsKey();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent20 = null;
        multiplePiePlot15.datasetChanged(datasetChangeEvent20);
        boolean boolean22 = range9.equals((java.lang.Object) multiplePiePlot15);
        org.jfree.data.Range range24 = org.jfree.data.Range.expandToInclude(range9, (double) (-1));
        dateAxis1.setRange(range9);
        org.jfree.chart.axis.DateTickUnit dateTickUnit26 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis1.setTickUnit(dateTickUnit26, false, false);
        boolean boolean31 = dateAxis1.isHiddenValue((long) (byte) 1);
        org.junit.Assert.assertNotNull(timeline2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeline5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNull(plot16);
        org.junit.Assert.assertTrue("'" + comparable19 + "' != '" + "Other" + "'", comparable19.equals("Other"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNotNull(dateTickUnit26);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("hi!", "", "RectangleEdge.TOP", image3, "RectangleEdge.TOP", "", "RectangleEdge.TOP");
        projectInfo7.setVersion("TextAnchor.CENTER_RIGHT");
        java.awt.Image image13 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo17 = new org.jfree.chart.ui.ProjectInfo("hi!", "", "RectangleEdge.TOP", image13, "RectangleEdge.TOP", "", "RectangleEdge.TOP");
        projectInfo17.setVersion("TextAnchor.CENTER_RIGHT");
        projectInfo7.addLibrary((org.jfree.chart.ui.Library) projectInfo17);
        projectInfo7.setVersion("");
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D1.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D1.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, polarItemRenderer6);
        java.lang.String str8 = polarPlot7.getPlotType();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent9 = null;
        polarPlot7.datasetChanged(datasetChangeEvent9);
        polarPlot7.setRadiusGridlinesVisible(false);
        java.awt.Paint paint13 = polarPlot7.getAngleLabelPaint();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Polar Plot" + "'", str8.equals("Polar Plot"));
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (short) 100, (double) (byte) 0, (double) 0.0f, (double) '#');
        double double7 = rectangleInsets5.calculateBottomOutset((double) 1L);
        java.lang.String str8 = rectangleInsets5.toString();
        org.jfree.chart.block.BlockBorder blockBorder9 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = blockBorder9.getInsets();
        double double12 = rectangleInsets10.trimWidth((double) (byte) 10);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D13 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D13.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D13.setAutoRangeStickyZero(false);
        numberAxis3D13.setUpperBound(100.0d);
        float float20 = numberAxis3D13.getTickMarkOutsideLength();
        org.jfree.chart.block.BlockContainer blockContainer21 = new org.jfree.chart.block.BlockContainer();
        blockContainer21.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D24 = blockContainer21.getBounds();
        numberAxis3D13.setLeftArrow((java.awt.Shape) rectangle2D24);
        org.jfree.chart.entity.ChartEntity chartEntity27 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D24, "");
        java.awt.geom.Rectangle2D rectangle2D28 = rectangleInsets10.createOutsetRectangle(rectangle2D24);
        java.awt.geom.Rectangle2D rectangle2D29 = rectangleInsets5.createOutsetRectangle(rectangle2D24);
        org.jfree.chart.entity.ChartEntity chartEntity30 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D24);
        java.lang.String str31 = chartEntity30.getURLText();
        java.lang.Object obj32 = chartEntity30.clone();
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "RectangleInsets[t=100.0,l=0.0,b=0.0,r=35.0]" + "'", str8.equals("RectangleInsets[t=100.0,l=0.0,b=0.0,r=35.0]"));
        org.junit.Assert.assertNotNull(blockBorder9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 10.0d + "'", double12 == 10.0d);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 1.0f + "'", float20 == 1.0f);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertNotNull(obj32);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D0.setAutoRangeStickyZero(false);
        numberAxis3D0.setUpperBound(100.0d);
        float float7 = numberAxis3D0.getTickMarkOutsideLength();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit8 = numberAxis3D0.getTickUnit();
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
        org.junit.Assert.assertNotNull(numberTickUnit8);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        java.awt.Paint paint2 = ringPlot1.getSeparatorPaint();
        double double3 = ringPlot1.getMaximumExplodePercent();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        piePlot6.setSectionOutlinesVisible(true);
        java.awt.Paint paint9 = piePlot6.getBackgroundPaint();
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.image.ColorModel colorModel12 = null;
        java.awt.Rectangle rectangle13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.awt.geom.AffineTransform affineTransform15 = null;
        java.awt.RenderingHints renderingHints16 = null;
        java.awt.PaintContext paintContext17 = color11.createContext(colorModel12, rectangle13, rectangle2D14, affineTransform15, renderingHints16);
        piePlot6.setSectionPaint((java.lang.Comparable) (byte) 100, (java.awt.Paint) color11);
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor20 = null;
        org.jfree.chart.block.BlockContainer blockContainer23 = new org.jfree.chart.block.BlockContainer();
        blockContainer23.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D26 = blockContainer23.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double28 = categoryAxis19.getCategoryJava2DCoordinate(categoryAnchor20, (int) (byte) 10, 0, rectangle2D26, rectangleEdge27);
        piePlot6.setLegendItemShape((java.awt.Shape) rectangle2D26);
        org.jfree.chart.plot.PiePlot3D piePlot3D30 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D30.setBackgroundImageAlignment(1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        org.jfree.chart.plot.PiePlotState piePlotState35 = ringPlot1.initialise(graphics2D4, rectangle2D26, (org.jfree.chart.plot.PiePlot) piePlot3D30, (java.lang.Integer) 100, plotRenderingInfo34);
        double double36 = piePlotState35.getPieCenterY();
        java.awt.geom.Rectangle2D rectangle2D37 = piePlotState35.getExplodedPieArea();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(paintContext17);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(piePlotState35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNull(rectangle2D37);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("ChartEntity: tooltip = ");
        java.lang.Object obj2 = null;
        boolean boolean3 = textFragment1.equals(obj2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("RectangleEdge.TOP", "Polar Plot");
        java.lang.String str3 = contributor2.getEmail();
        java.lang.String str4 = contributor2.getEmail();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Polar Plot" + "'", str3.equals("Polar Plot"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Polar Plot" + "'", str4.equals("Polar Plot"));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getDomainAxisEdge((int) (byte) 1);
        org.jfree.chart.axis.AxisLocation axisLocation4 = categoryPlot0.getDomainAxisLocation(200);
        org.jfree.chart.util.Layer layer5 = null;
        java.util.Collection collection6 = categoryPlot0.getDomainMarkers(layer5);
        categoryPlot0.setRangeCrosshairValue(0.025d);
        java.awt.Stroke stroke9 = categoryPlot0.getDomainGridlineStroke();
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNull(collection6);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getDomainAxisEdge((int) (byte) 1);
        org.jfree.chart.axis.AxisLocation axisLocation4 = categoryPlot0.getDomainAxisLocation(200);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis();
        org.jfree.chart.axis.ValueAxis valueAxis7 = categoryPlot0.getRangeAxisForDataset(10);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        double double9 = categoryAxis8.getCategoryMargin();
        categoryAxis8.addCategoryLabelToolTip((java.lang.Comparable) 100, "TextAnchor.CENTER_RIGHT");
        java.lang.Object obj13 = categoryAxis8.clone();
        categoryAxis8.clearCategoryLabelToolTips();
        org.jfree.chart.block.BlockBorder blockBorder15 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = blockBorder15.getInsets();
        org.jfree.chart.block.BlockContainer blockContainer17 = new org.jfree.chart.block.BlockContainer();
        blockContainer17.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D20 = blockContainer17.getBounds();
        rectangleInsets16.trim(rectangle2D20);
        categoryAxis8.setLabelInsets(rectangleInsets16);
        categoryPlot0.setDomainAxis(categoryAxis8);
        org.jfree.chart.plot.CategoryMarker categoryMarker25 = null;
        org.jfree.chart.util.Layer layer26 = null;
        try {
            categoryPlot0.addDomainMarker(1, categoryMarker25, layer26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.2d + "'", double9 == 0.2d);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(blockBorder15);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(rectangle2D20);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        java.awt.Font font2 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer6 = null;
        org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, paint3, (float) (-1), 0, textMeasurer6);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        multiplePiePlot8.removeChangeListener(plotChangeListener9);
        org.jfree.chart.plot.Plot plot11 = multiplePiePlot8.getParent();
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("ThreadContext", font2, (org.jfree.chart.plot.Plot) multiplePiePlot8, false);
        org.jfree.chart.title.LegendTitle legendTitle14 = jFreeChart13.getLegend();
        java.awt.Paint paint15 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        jFreeChart13.setBorderPaint(paint15);
        org.jfree.chart.event.ChartProgressListener chartProgressListener17 = null;
        jFreeChart13.removeProgressListener(chartProgressListener17);
        java.awt.Stroke stroke19 = jFreeChart13.getBorderStroke();
        org.jfree.chart.event.ChartProgressListener chartProgressListener20 = null;
        jFreeChart13.addProgressListener(chartProgressListener20);
        int int22 = jFreeChart13.getBackgroundImageAlignment();
        jFreeChart13.setNotify(true);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(textBlock7);
        org.junit.Assert.assertNull(plot11);
        org.junit.Assert.assertNull(legendTitle14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 15 + "'", int22 == 15);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setBackgroundAlpha((float) (-1));
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        piePlot5.setSectionOutlinesVisible(true);
        java.awt.Paint paint8 = piePlot5.getBackgroundPaint();
        java.awt.Paint paint10 = piePlot5.getSectionOutlinePaint((java.lang.Comparable) 100.0f);
        java.awt.Stroke stroke11 = piePlot5.getLabelOutlineStroke();
        java.awt.Paint paint12 = piePlot5.getShadowPaint();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator14 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        piePlot5.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator14);
        piePlot1.setParent((org.jfree.chart.plot.Plot) piePlot5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getDomainAxisEdge((int) (byte) 1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryPlot0.getAxisOffset();
        boolean boolean4 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        try {
            categoryPlot0.handleClick(10, (int) '#', plotRenderingInfo7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextLine textLine1 = null;
        textBlock0.addLine(textLine1);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = textBlock0.getLineAlignment();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = textBlock0.getLineAlignment();
        java.awt.Graphics2D graphics2D5 = null;
        try {
            org.jfree.chart.util.Size2D size2D6 = textBlock0.calculateDimensions(graphics2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment3);
        org.junit.Assert.assertNotNull(horizontalAlignment4);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        java.awt.Paint paint2 = ringPlot1.getSeparatorPaint();
        double double3 = ringPlot1.getMaximumExplodePercent();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        piePlot6.setSectionOutlinesVisible(true);
        java.awt.Paint paint9 = piePlot6.getBackgroundPaint();
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.image.ColorModel colorModel12 = null;
        java.awt.Rectangle rectangle13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.awt.geom.AffineTransform affineTransform15 = null;
        java.awt.RenderingHints renderingHints16 = null;
        java.awt.PaintContext paintContext17 = color11.createContext(colorModel12, rectangle13, rectangle2D14, affineTransform15, renderingHints16);
        piePlot6.setSectionPaint((java.lang.Comparable) (byte) 100, (java.awt.Paint) color11);
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor20 = null;
        org.jfree.chart.block.BlockContainer blockContainer23 = new org.jfree.chart.block.BlockContainer();
        blockContainer23.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D26 = blockContainer23.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double28 = categoryAxis19.getCategoryJava2DCoordinate(categoryAnchor20, (int) (byte) 10, 0, rectangle2D26, rectangleEdge27);
        piePlot6.setLegendItemShape((java.awt.Shape) rectangle2D26);
        org.jfree.chart.plot.PiePlot3D piePlot3D30 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D30.setBackgroundImageAlignment(1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        org.jfree.chart.plot.PiePlotState piePlotState35 = ringPlot1.initialise(graphics2D4, rectangle2D26, (org.jfree.chart.plot.PiePlot) piePlot3D30, (java.lang.Integer) 100, plotRenderingInfo34);
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = piePlot3D30.getSimpleLabelOffset();
        double double38 = rectangleInsets36.extendHeight((double) (short) 100);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(paintContext17);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(piePlotState35);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 156.25d + "'", double38 == 156.25d);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        double[] doubleArray5 = new double[] { (byte) 0, 0.2d, (-1.0d) };
        double[] doubleArray9 = new double[] { (byte) 0, 0.2d, (-1.0d) };
        double[] doubleArray13 = new double[] { (byte) 0, 0.2d, (-1.0d) };
        double[][] doubleArray14 = new double[][] { doubleArray5, doubleArray9, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("rect", "RectangleAnchor.BOTTOM_LEFT", doubleArray14);
        try {
            org.jfree.data.general.PieDataset pieDataset17 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset15, (java.lang.Comparable) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("RectangleAnchor.LEFT");
        numberAxis3D1.setRangeAboutValue(0.0d, 0.05d);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = numberAxis3D1.getLabelInsets();
        org.junit.Assert.assertNotNull(rectangleInsets5);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.Timeline timeline2 = dateAxis1.getTimeline();
        java.awt.Color color3 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        dateAxis1.setTickMarkPaint((java.awt.Paint) color3);
        org.junit.Assert.assertNotNull(timeline2);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setSectionOutlinesVisible(true);
        java.awt.Paint paint4 = piePlot1.getBackgroundPaint();
        java.awt.Paint paint6 = piePlot1.getSectionOutlinePaint((java.lang.Comparable) 100.0f);
        java.awt.Stroke stroke7 = piePlot1.getLabelOutlineStroke();
        java.awt.Paint paint8 = piePlot1.getShadowPaint();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator10 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        piePlot1.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator10);
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        piePlot13.setSectionOutlinesVisible(true);
        java.awt.Paint paint16 = piePlot13.getBackgroundPaint();
        java.awt.Paint paint18 = piePlot13.getSectionOutlinePaint((java.lang.Comparable) 100.0f);
        java.awt.Stroke stroke19 = piePlot13.getLabelLinkStroke();
        java.awt.Stroke stroke21 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        piePlot13.setSectionOutlineStroke((java.lang.Comparable) (byte) 100, stroke21);
        piePlot1.setLabelOutlineStroke(stroke21);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke21);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit(1.0d);
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot0);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = multiplePiePlot0.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis5.setLowerMargin((double) (short) 100);
        categoryAxis5.setLowerMargin((double) 0);
        java.awt.Font font11 = categoryAxis5.getTickLabelFont((java.lang.Comparable) (byte) 100);
        double double12 = categoryAxis5.getLowerMargin();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor13 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D16 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.RangeType rangeType17 = numberAxis3D16.getRangeType();
        org.jfree.data.general.PieDataset pieDataset18 = null;
        org.jfree.chart.plot.PiePlot piePlot19 = new org.jfree.chart.plot.PiePlot(pieDataset18);
        piePlot19.setSectionOutlinesVisible(true);
        java.awt.Paint paint22 = piePlot19.getBackgroundPaint();
        java.awt.Color color24 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.image.ColorModel colorModel25 = null;
        java.awt.Rectangle rectangle26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        java.awt.geom.AffineTransform affineTransform28 = null;
        java.awt.RenderingHints renderingHints29 = null;
        java.awt.PaintContext paintContext30 = color24.createContext(colorModel25, rectangle26, rectangle2D27, affineTransform28, renderingHints29);
        piePlot19.setSectionPaint((java.lang.Comparable) (byte) 100, (java.awt.Paint) color24);
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor33 = null;
        org.jfree.chart.block.BlockContainer blockContainer36 = new org.jfree.chart.block.BlockContainer();
        blockContainer36.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D39 = blockContainer36.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double41 = categoryAxis32.getCategoryJava2DCoordinate(categoryAnchor33, (int) (byte) 10, 0, rectangle2D39, rectangleEdge40);
        piePlot19.setLegendItemShape((java.awt.Shape) rectangle2D39);
        numberAxis3D16.setRightArrow((java.awt.Shape) rectangle2D39);
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = org.jfree.chart.util.RectangleEdge.TOP;
        double double45 = categoryAxis5.getCategoryJava2DCoordinate(categoryAnchor13, 2, (int) (short) 100, rectangle2D39, rectangleEdge44);
        rectangleInsets4.trim(rectangle2D39);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(rangeType17);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(paintContext30);
        org.junit.Assert.assertNotNull(rectangle2D39);
        org.junit.Assert.assertNotNull(rectangleEdge40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        java.lang.String str1 = textAnchor0.toString();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextAnchor.BASELINE_CENTER" + "'", str1.equals("TextAnchor.BASELINE_CENTER"));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) blockBorder0, jFreeChart1);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D3.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D3.resizeRange((double) 1, (double) 1);
        numberAxis3D3.setVisible(true);
        boolean boolean11 = blockBorder0.equals((java.lang.Object) true);
        org.junit.Assert.assertNotNull(blockBorder0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.CENTER;
        java.awt.Paint paint2 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        boolean boolean3 = verticalAlignment1.equals((java.lang.Object) paint2);
        org.jfree.chart.block.ColumnArrangement columnArrangement6 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) (byte) 1, (double) (byte) -1);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot7 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot7.setLimit(1.0d);
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot7);
        org.jfree.chart.util.VerticalAlignment verticalAlignment11 = legendTitle10.getVerticalAlignment();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint13.toFixedWidth((double) 200);
        org.jfree.chart.util.Size2D size2D16 = legendTitle10.arrange(graphics2D12, rectangleConstraint15);
        boolean boolean17 = verticalAlignment1.equals((java.lang.Object) graphics2D12);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = categoryPlot18.getDomainAxisEdge((int) (byte) 1);
        org.jfree.chart.axis.AxisLocation axisLocation22 = categoryPlot18.getDomainAxisLocation(200);
        org.jfree.chart.plot.PlotOrientation plotOrientation23 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation22, plotOrientation23);
        boolean boolean25 = verticalAlignment1.equals((java.lang.Object) rectangleEdge24);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(verticalAlignment11);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(size2D16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertNotNull(plotOrientation23);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setSectionOutlinesVisible(true);
        java.awt.Paint paint4 = piePlot1.getBackgroundPaint();
        java.awt.Paint paint6 = piePlot1.getSectionOutlinePaint((java.lang.Comparable) 100.0f);
        java.awt.Font font9 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint10 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer13 = null;
        org.jfree.chart.text.TextBlock textBlock14 = org.jfree.chart.text.TextUtilities.createTextBlock("", font9, paint10, (float) (-1), 0, textMeasurer13);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot15 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        multiplePiePlot15.removeChangeListener(plotChangeListener16);
        org.jfree.chart.plot.Plot plot18 = multiplePiePlot15.getParent();
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("ThreadContext", font9, (org.jfree.chart.plot.Plot) multiplePiePlot15, false);
        jFreeChart20.setBackgroundImageAlignment(200);
        float float23 = jFreeChart20.getBackgroundImageAlpha();
        piePlot1.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart20);
        boolean boolean25 = jFreeChart20.isNotify();
        org.jfree.chart.plot.Plot plot26 = jFreeChart20.getPlot();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(textBlock14);
        org.junit.Assert.assertNull(plot18);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 0.5f + "'", float23 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(plot26);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D1.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D1.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, polarItemRenderer6);
        double double8 = polarPlot7.getMaxRadius();
        org.jfree.chart.LegendItemCollection legendItemCollection9 = polarPlot7.getLegendItems();
        org.jfree.chart.LegendItem legendItem10 = null;
        legendItemCollection9.add(legendItem10);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.05d + "'", double8 == 1.05d);
        org.junit.Assert.assertNotNull(legendItemCollection9);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("hi!", "", "RectangleEdge.TOP", image3, "RectangleEdge.TOP", "", "RectangleEdge.TOP");
        projectInfo7.setVersion("TextAnchor.CENTER_RIGHT");
        org.jfree.chart.ui.ProjectInfo projectInfo10 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.Library[] libraryArray11 = projectInfo10.getLibraries();
        projectInfo7.addLibrary((org.jfree.chart.ui.Library) projectInfo10);
        java.awt.Image image16 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo20 = new org.jfree.chart.ui.ProjectInfo("hi!", "", "RectangleEdge.TOP", image16, "RectangleEdge.TOP", "", "RectangleEdge.TOP");
        projectInfo20.setVersion("TextAnchor.CENTER_RIGHT");
        java.awt.Image image26 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo30 = new org.jfree.chart.ui.ProjectInfo("hi!", "", "RectangleEdge.TOP", image26, "RectangleEdge.TOP", "", "RectangleEdge.TOP");
        projectInfo30.setVersion("TextAnchor.CENTER_RIGHT");
        projectInfo20.addLibrary((org.jfree.chart.ui.Library) projectInfo30);
        java.awt.Image image34 = null;
        projectInfo20.setLogo(image34);
        java.lang.String str36 = projectInfo20.getName();
        org.jfree.data.general.PieDataset pieDataset37 = null;
        org.jfree.chart.plot.PiePlot piePlot38 = new org.jfree.chart.plot.PiePlot(pieDataset37);
        piePlot38.setSectionOutlinesVisible(true);
        java.awt.Paint paint41 = piePlot38.getBackgroundPaint();
        java.awt.Paint paint43 = piePlot38.getSectionOutlinePaint((java.lang.Comparable) 100.0f);
        java.awt.Font font46 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint47 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer50 = null;
        org.jfree.chart.text.TextBlock textBlock51 = org.jfree.chart.text.TextUtilities.createTextBlock("", font46, paint47, (float) (-1), 0, textMeasurer50);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot52 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener53 = null;
        multiplePiePlot52.removeChangeListener(plotChangeListener53);
        org.jfree.chart.plot.Plot plot55 = multiplePiePlot52.getParent();
        org.jfree.chart.JFreeChart jFreeChart57 = new org.jfree.chart.JFreeChart("ThreadContext", font46, (org.jfree.chart.plot.Plot) multiplePiePlot52, false);
        jFreeChart57.setBackgroundImageAlignment(200);
        float float60 = jFreeChart57.getBackgroundImageAlpha();
        piePlot38.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart57);
        java.util.List list62 = jFreeChart57.getSubtitles();
        projectInfo20.setContributors(list62);
        projectInfo10.setContributors(list62);
        org.junit.Assert.assertNotNull(projectInfo10);
        org.junit.Assert.assertNotNull(libraryArray11);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "hi!" + "'", str36.equals("hi!"));
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNull(paint43);
        org.junit.Assert.assertNotNull(font46);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(textBlock51);
        org.junit.Assert.assertNull(plot55);
        org.junit.Assert.assertTrue("'" + float60 + "' != '" + 0.5f + "'", float60 == 0.5f);
        org.junit.Assert.assertNotNull(list62);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        java.awt.Paint paint1 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker(35.0d, paint1, stroke2);
        float float4 = valueMarker3.getAlpha();
        java.awt.Paint paint5 = valueMarker3.getPaint();
        java.awt.Paint paint7 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker(35.0d, paint7, stroke8);
        float float10 = valueMarker9.getAlpha();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType11 = valueMarker9.getLabelOffsetType();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType12 = valueMarker9.getLabelOffsetType();
        valueMarker3.setLabelOffsetType(lengthAdjustmentType12);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = org.jfree.chart.util.RectangleAnchor.CENTER;
        valueMarker3.setLabelAnchor(rectangleAnchor14);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 1.0f + "'", float10 == 1.0f);
        org.junit.Assert.assertNotNull(lengthAdjustmentType11);
        org.junit.Assert.assertNotNull(lengthAdjustmentType12);
        org.junit.Assert.assertNotNull(rectangleAnchor14);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getCategoryMargin();
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) 100, "TextAnchor.CENTER_RIGHT");
        java.lang.Object obj5 = categoryAxis0.clone();
        categoryAxis0.clearCategoryLabelToolTips();
        org.jfree.chart.block.BlockBorder blockBorder7 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = blockBorder7.getInsets();
        org.jfree.chart.block.BlockContainer blockContainer9 = new org.jfree.chart.block.BlockContainer();
        blockContainer9.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D12 = blockContainer9.getBounds();
        rectangleInsets8.trim(rectangle2D12);
        categoryAxis0.setLabelInsets(rectangleInsets8);
        java.lang.Object obj15 = categoryAxis0.clone();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(blockBorder7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D0.clearCategoryLabelToolTips();
        java.lang.Object obj2 = categoryAxis3D0.clone();
        double double3 = categoryAxis3D0.getLabelAngle();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        java.awt.Paint paint1 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker(35.0d, paint1, stroke2);
        float float4 = valueMarker3.getAlpha();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType5 = valueMarker3.getLabelOffsetType();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType6 = valueMarker3.getLabelOffsetType();
        java.awt.Paint paint8 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke9 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(35.0d, paint8, stroke9);
        valueMarker3.setStroke(stroke9);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(lengthAdjustmentType5);
        org.junit.Assert.assertNotNull(lengthAdjustmentType6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        double double0 = org.jfree.chart.axis.DateAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE_IN_MILLISECONDS;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.0d + "'", double0 == 2.0d);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.TOP;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge0);
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertNotNull(rectangleEdge1);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D1.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D1.setAutoRangeStickyZero(false);
        numberAxis3D1.setUpperBound(100.0d);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand8 = numberAxis3D1.getMarkerBand();
        double double9 = numberAxis3D1.getFixedAutoRange();
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D11.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D11.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer16 = null;
        org.jfree.chart.plot.PolarPlot polarPlot17 = new org.jfree.chart.plot.PolarPlot(xYDataset10, (org.jfree.chart.axis.ValueAxis) numberAxis3D11, polarItemRenderer16);
        java.lang.String str18 = polarPlot17.getPlotType();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent19 = null;
        polarPlot17.datasetChanged(datasetChangeEvent19);
        java.awt.Stroke stroke21 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        polarPlot17.setRadiusGridlineStroke(stroke21);
        numberAxis3D1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) polarPlot17);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent24 = null;
        polarPlot17.datasetChanged(datasetChangeEvent24);
        boolean boolean26 = lengthConstraintType0.equals((java.lang.Object) datasetChangeEvent24);
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis();
        double double28 = categoryAxis27.getCategoryMargin();
        categoryAxis27.addCategoryLabelToolTip((java.lang.Comparable) 100, "TextAnchor.CENTER_RIGHT");
        java.lang.Object obj32 = categoryAxis27.clone();
        boolean boolean33 = lengthConstraintType0.equals(obj32);
        org.junit.Assert.assertNotNull(lengthConstraintType0);
        org.junit.Assert.assertNull(markerAxisBand8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Polar Plot" + "'", str18.equals("Polar Plot"));
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.2d + "'", double28 == 0.2d);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape0, "ClassContext");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setSectionOutlinesVisible(true);
        java.awt.Paint paint4 = piePlot1.getBackgroundPaint();
        java.awt.Paint paint6 = piePlot1.getSectionOutlinePaint((java.lang.Comparable) 100.0f);
        piePlot1.setCircular(false, false);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = piePlot1.getLegendItems();
        double double11 = piePlot1.getStartAngle();
        piePlot1.setIgnoreNullValues(true);
        java.lang.String str14 = piePlot1.getPlotType();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(legendItemCollection10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 90.0d + "'", double11 == 90.0d);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Pie Plot" + "'", str14.equals("Pie Plot"));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getDomainAxisEdge((int) (byte) 1);
        org.jfree.chart.axis.AxisLocation axisLocation4 = categoryPlot0.getDomainAxisLocation(200);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis();
        org.jfree.chart.axis.ValueAxis valueAxis7 = categoryPlot0.getRangeAxisForDataset(10);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        double double9 = categoryAxis8.getCategoryMargin();
        categoryAxis8.addCategoryLabelToolTip((java.lang.Comparable) 100, "TextAnchor.CENTER_RIGHT");
        java.lang.Object obj13 = categoryAxis8.clone();
        categoryAxis8.clearCategoryLabelToolTips();
        org.jfree.chart.block.BlockBorder blockBorder15 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = blockBorder15.getInsets();
        org.jfree.chart.block.BlockContainer blockContainer17 = new org.jfree.chart.block.BlockContainer();
        blockContainer17.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D20 = blockContainer17.getBounds();
        rectangleInsets16.trim(rectangle2D20);
        categoryAxis8.setLabelInsets(rectangleInsets16);
        categoryPlot0.setDomainAxis(categoryAxis8);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder24 = null;
        try {
            categoryPlot0.setDatasetRenderingOrder(datasetRenderingOrder24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.2d + "'", double9 == 0.2d);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(blockBorder15);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(rectangle2D20);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D0.setMaximumCategoryLabelWidthRatio((float) 15);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis5.setLowerMargin((double) (short) 100);
        org.jfree.chart.block.BlockBorder blockBorder10 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = blockBorder10.getInsets();
        double double13 = rectangleInsets11.trimWidth((double) (byte) 10);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D14.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D14.setAutoRangeStickyZero(false);
        numberAxis3D14.setUpperBound(100.0d);
        float float21 = numberAxis3D14.getTickMarkOutsideLength();
        org.jfree.chart.block.BlockContainer blockContainer22 = new org.jfree.chart.block.BlockContainer();
        blockContainer22.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D25 = blockContainer22.getBounds();
        numberAxis3D14.setLeftArrow((java.awt.Shape) rectangle2D25);
        org.jfree.chart.entity.ChartEntity chartEntity28 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D25, "");
        java.awt.geom.Rectangle2D rectangle2D29 = rectangleInsets11.createOutsetRectangle(rectangle2D25);
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = new org.jfree.chart.axis.CategoryAxis();
        double double31 = categoryAxis30.getCategoryMargin();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor32 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = org.jfree.chart.util.RectangleEdge.TOP;
        java.lang.String str37 = rectangleEdge36.toString();
        double double38 = categoryAxis30.getCategoryJava2DCoordinate(categoryAnchor32, (int) 'a', 1, rectangle2D35, rectangleEdge36);
        double double39 = categoryAxis5.getCategoryEnd((-1), (int) '4', rectangle2D25, rectangleEdge36);
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = categoryPlot40.getDomainAxisEdge((int) (byte) 1);
        org.jfree.chart.axis.AxisLocation axisLocation44 = categoryPlot40.getDomainAxisLocation(200);
        org.jfree.chart.plot.PlotOrientation plotOrientation45 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation44, plotOrientation45);
        double double47 = categoryAxis3D0.getCategoryMiddle((int) 'a', 0, rectangle2D25, rectangleEdge46);
        org.junit.Assert.assertNotNull(blockBorder10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 10.0d + "'", double13 == 10.0d);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 1.0f + "'", float21 == 1.0f);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.2d + "'", double31 == 0.2d);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "RectangleEdge.TOP" + "'", str37.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge42);
        org.junit.Assert.assertNotNull(axisLocation44);
        org.junit.Assert.assertNotNull(plotOrientation45);
        org.junit.Assert.assertNotNull(rectangleEdge46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        java.awt.Paint paint1 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker(35.0d, paint1, stroke2);
        java.awt.Font font4 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        boolean boolean5 = valueMarker3.equals((java.lang.Object) font4);
        java.awt.Font font8 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint9 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer12 = null;
        org.jfree.chart.text.TextBlock textBlock13 = org.jfree.chart.text.TextUtilities.createTextBlock("", font8, paint9, (float) (-1), 0, textMeasurer12);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot14 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        multiplePiePlot14.removeChangeListener(plotChangeListener15);
        org.jfree.chart.plot.Plot plot17 = multiplePiePlot14.getParent();
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart("ThreadContext", font8, (org.jfree.chart.plot.Plot) multiplePiePlot14, false);
        java.util.List list20 = jFreeChart19.getSubtitles();
        org.jfree.chart.block.BlockContainer blockContainer21 = new org.jfree.chart.block.BlockContainer();
        blockContainer21.setWidth((double) 10.0f);
        org.jfree.chart.block.BlockBorder blockBorder24 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = blockBorder24.getInsets();
        blockContainer21.setMargin(rectangleInsets25);
        boolean boolean27 = jFreeChart19.equals((java.lang.Object) rectangleInsets25);
        java.awt.Color color28 = java.awt.Color.white;
        int int29 = color28.getTransparency();
        jFreeChart19.setBackgroundPaint((java.awt.Paint) color28);
        valueMarker3.setLabelPaint((java.awt.Paint) color28);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(textBlock13);
        org.junit.Assert.assertNull(plot17);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertNotNull(blockBorder24);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D();
        boolean boolean3 = numberAxis3D2.isAutoTickUnitSelection();
        boolean boolean4 = numberAxis3D2.isVerticalTickLabels();
        numberAxis3D2.resizeRange(0.0d);
        boolean boolean7 = ringPlot1.equals((java.lang.Object) 0.0d);
        ringPlot1.setPieIndex((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit(1.0d);
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot0);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = legendTitle3.getVerticalAlignment();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = legendTitle3.getLegendItemGraphicLocation();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        legendTitle3.setItemLabelPadding(rectangleInsets6);
        double double8 = legendTitle3.getContentYOffset();
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        try {
            legendTitle3.setBounds(rectangle2D9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'bounds' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer1 = new org.jfree.chart.text.G2TextMeasurer(graphics2D0);
        try {
            float float5 = g2TextMeasurer1.getStringWidth("Rotation.CLOCKWISE", (int) ' ', 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D3.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D3.setAutoRangeStickyZero(false);
        numberAxis3D3.setUpperBound(100.0d);
        float float10 = numberAxis3D3.getTickMarkOutsideLength();
        org.jfree.chart.block.BlockContainer blockContainer11 = new org.jfree.chart.block.BlockContainer();
        blockContainer11.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D14 = blockContainer11.getBounds();
        numberAxis3D3.setLeftArrow((java.awt.Shape) rectangle2D14);
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.plot.PiePlot piePlot17 = new org.jfree.chart.plot.PiePlot(pieDataset16);
        piePlot17.setSectionOutlinesVisible(true);
        java.awt.Paint paint20 = piePlot17.getBackgroundPaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        org.jfree.chart.plot.PiePlotState piePlotState23 = ringPlot1.initialise(graphics2D2, rectangle2D14, piePlot17, (java.lang.Integer) 3, plotRenderingInfo22);
        ringPlot1.setSectionDepth(0.0d);
        ringPlot1.setLabelLinksVisible(false);
        ringPlot1.setLabelLinkMargin(35.0d);
        java.awt.Graphics2D graphics2D30 = null;
        org.jfree.chart.block.BlockBorder blockBorder31 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = blockBorder31.getInsets();
        double double34 = rectangleInsets32.trimWidth((double) (byte) 10);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D35 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D35.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D35.setAutoRangeStickyZero(false);
        numberAxis3D35.setUpperBound(100.0d);
        float float42 = numberAxis3D35.getTickMarkOutsideLength();
        org.jfree.chart.block.BlockContainer blockContainer43 = new org.jfree.chart.block.BlockContainer();
        blockContainer43.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D46 = blockContainer43.getBounds();
        numberAxis3D35.setLeftArrow((java.awt.Shape) rectangle2D46);
        org.jfree.chart.entity.ChartEntity chartEntity49 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D46, "");
        java.awt.geom.Rectangle2D rectangle2D50 = rectangleInsets32.createOutsetRectangle(rectangle2D46);
        org.jfree.chart.plot.PiePlot piePlot51 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo53 = null;
        try {
            org.jfree.chart.plot.PiePlotState piePlotState54 = ringPlot1.initialise(graphics2D30, rectangle2D46, piePlot51, (java.lang.Integer) (-1), plotRenderingInfo53);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 1.0f + "'", float10 == 1.0f);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(piePlotState23);
        org.junit.Assert.assertNotNull(blockBorder31);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 10.0d + "'", double34 == 10.0d);
        org.junit.Assert.assertTrue("'" + float42 + "' != '" + 1.0f + "'", float42 == 1.0f);
        org.junit.Assert.assertNotNull(rectangle2D46);
        org.junit.Assert.assertNotNull(rectangle2D50);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getCategoryMargin();
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) 100, "TextAnchor.CENTER_RIGHT");
        java.awt.Paint paint6 = categoryAxis0.getTickLabelPaint((java.lang.Comparable) "ThreadContext");
        java.awt.Paint paint7 = categoryAxis0.getAxisLinePaint();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        java.awt.Paint paint2 = ringPlot1.getSeparatorPaint();
        double double3 = ringPlot1.getMaximumExplodePercent();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        piePlot6.setSectionOutlinesVisible(true);
        java.awt.Paint paint9 = piePlot6.getBackgroundPaint();
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.image.ColorModel colorModel12 = null;
        java.awt.Rectangle rectangle13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.awt.geom.AffineTransform affineTransform15 = null;
        java.awt.RenderingHints renderingHints16 = null;
        java.awt.PaintContext paintContext17 = color11.createContext(colorModel12, rectangle13, rectangle2D14, affineTransform15, renderingHints16);
        piePlot6.setSectionPaint((java.lang.Comparable) (byte) 100, (java.awt.Paint) color11);
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor20 = null;
        org.jfree.chart.block.BlockContainer blockContainer23 = new org.jfree.chart.block.BlockContainer();
        blockContainer23.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D26 = blockContainer23.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double28 = categoryAxis19.getCategoryJava2DCoordinate(categoryAnchor20, (int) (byte) 10, 0, rectangle2D26, rectangleEdge27);
        piePlot6.setLegendItemShape((java.awt.Shape) rectangle2D26);
        org.jfree.chart.plot.PiePlot3D piePlot3D30 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D30.setBackgroundImageAlignment(1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        org.jfree.chart.plot.PiePlotState piePlotState35 = ringPlot1.initialise(graphics2D4, rectangle2D26, (org.jfree.chart.plot.PiePlot) piePlot3D30, (java.lang.Integer) 100, plotRenderingInfo34);
        double double36 = piePlotState35.getPieCenterY();
        double double37 = piePlotState35.getPieCenterY();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(paintContext17);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(piePlotState35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot1.getPieChart();
        boolean boolean3 = jFreeChart2.getAntiAlias();
        org.junit.Assert.assertNotNull(jFreeChart2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.expandToInclude(range0, (-1.0d));
        boolean boolean4 = range2.contains((double) 1);
        org.jfree.data.Range range7 = org.jfree.data.Range.shift(range2, (double) 100, false);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.Plot plot9 = multiplePiePlot8.getParent();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        multiplePiePlot8.markerChanged(markerChangeEvent10);
        java.lang.Comparable comparable12 = multiplePiePlot8.getAggregatedItemsKey();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent13 = null;
        multiplePiePlot8.datasetChanged(datasetChangeEvent13);
        boolean boolean15 = range2.equals((java.lang.Object) multiplePiePlot8);
        org.jfree.data.Range range17 = org.jfree.data.Range.expandToInclude(range2, (double) (-1));
        java.lang.String str18 = range2.toString();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNull(plot9);
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + "Other" + "'", comparable12.equals("Other"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Range[-1.0,-1.0]" + "'", str18.equals("Range[-1.0,-1.0]"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.data.function.Function2D function2D0 = null;
        try {
            org.jfree.data.xy.XYDataset xYDataset5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, 0.025d, 0.0d, (int) (short) 1, (java.lang.Comparable) 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.Timeline timeline2 = dateAxis1.getTimeline();
        java.util.TimeZone timeZone3 = dateAxis1.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("hi!");
        java.lang.Object obj6 = null;
        boolean boolean7 = dateAxis5.equals(obj6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D9 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D9.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D9.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer14 = null;
        org.jfree.chart.plot.PolarPlot polarPlot15 = new org.jfree.chart.plot.PolarPlot(xYDataset8, (org.jfree.chart.axis.ValueAxis) numberAxis3D9, polarItemRenderer14);
        org.jfree.data.Range range16 = null;
        org.jfree.data.Range range18 = org.jfree.data.Range.expandToInclude(range16, (-1.0d));
        numberAxis3D9.setRangeWithMargins(range18);
        dateAxis5.setRange(range18, true, false);
        boolean boolean24 = dateAxis5.isHiddenValue((long) (-237));
        java.util.TimeZone timeZone25 = dateAxis5.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.Timeline timeline28 = dateAxis27.getTimeline();
        boolean boolean30 = dateAxis27.isHiddenValue((long) (byte) 1);
        org.jfree.chart.axis.Timeline timeline31 = dateAxis27.getTimeline();
        java.util.Date date32 = dateAxis27.getMaximumDate();
        dateAxis5.setMinimumDate(date32);
        dateAxis1.setMaximumDate(date32);
        boolean boolean35 = dateAxis1.isVerticalTickLabels();
        org.junit.Assert.assertNotNull(timeline2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNotNull(timeline28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(timeline31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        double double1 = blockParams0.getTranslateX();
        double double2 = blockParams0.getTranslateX();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) 35.0d, 1.0E-5d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder(49.66059027777778d, 0.2d, 0.08d, 2.0d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        java.awt.Font font2 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer6 = null;
        org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, paint3, (float) (byte) 1, 100, textMeasurer6);
        java.awt.Color color8 = java.awt.Color.pink;
        int int9 = color8.getTransparency();
        int int10 = color8.getAlpha();
        org.jfree.chart.text.TextLine textLine11 = new org.jfree.chart.text.TextLine("", font2, (java.awt.Paint) color8);
        java.awt.Graphics2D graphics2D12 = null;
        try {
            org.jfree.chart.util.Size2D size2D13 = textLine11.calculateDimensions(graphics2D12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(textBlock7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 255 + "'", int10 == 255);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        org.jfree.chart.text.TextFragment textFragment1 = textLine0.getFirstTextFragment();
        org.jfree.chart.text.TextFragment textFragment2 = null;
        textLine0.addFragment(textFragment2);
        org.jfree.chart.text.TextFragment textFragment4 = textLine0.getLastTextFragment();
        org.junit.Assert.assertNull(textFragment1);
        org.junit.Assert.assertNull(textFragment4);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getDomainAxisEdge((int) (byte) 1);
        org.jfree.chart.axis.AxisLocation axisLocation4 = categoryPlot0.getDomainAxisLocation(200);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj7 = categoryAxis6.clone();
        categoryPlot0.setDomainAxis((int) ' ', categoryAxis6, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray10 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot0.setRenderers(categoryItemRendererArray10);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(categoryItemRendererArray10);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("hi!", "", "RectangleEdge.TOP", image3, "RectangleEdge.TOP", "", "RectangleEdge.TOP");
        projectInfo7.setVersion("TextAnchor.CENTER_RIGHT");
        java.awt.Image image13 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo17 = new org.jfree.chart.ui.ProjectInfo("hi!", "", "RectangleEdge.TOP", image13, "RectangleEdge.TOP", "", "RectangleEdge.TOP");
        projectInfo17.setVersion("TextAnchor.CENTER_RIGHT");
        projectInfo7.addLibrary((org.jfree.chart.ui.Library) projectInfo17);
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo25 = new org.jfree.chart.ui.BasicProjectInfo("", "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "hi!", "");
        projectInfo7.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo25);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D1.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D1.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, polarItemRenderer6);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = null;
        polarPlot7.datasetChanged(datasetChangeEvent8);
        java.lang.String str10 = polarPlot7.getNoDataMessage();
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        java.awt.Font font2 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer6 = null;
        org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, paint3, (float) (-1), 0, textMeasurer6);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        multiplePiePlot8.removeChangeListener(plotChangeListener9);
        org.jfree.chart.plot.Plot plot11 = multiplePiePlot8.getParent();
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("ThreadContext", font2, (org.jfree.chart.plot.Plot) multiplePiePlot8, false);
        java.util.List list14 = jFreeChart13.getSubtitles();
        java.awt.Paint paint15 = jFreeChart13.getBorderPaint();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(textBlock7);
        org.junit.Assert.assertNull(plot11);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        double[] doubleArray5 = new double[] { (byte) 0, 0.2d, (-1.0d) };
        double[] doubleArray9 = new double[] { (byte) 0, 0.2d, (-1.0d) };
        double[] doubleArray13 = new double[] { (byte) 0, 0.2d, (-1.0d) };
        double[][] doubleArray14 = new double[][] { doubleArray5, doubleArray9, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("rect", "RectangleAnchor.BOTTOM_LEFT", doubleArray14);
        java.lang.Number number16 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset15);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot17 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset15);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 0.2d + "'", number16.equals(0.2d));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0, waferMapRenderer1);
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset3);
        org.jfree.chart.JFreeChart jFreeChart5 = multiplePiePlot4.getPieChart();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot6 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot6.setLimit(1.0d);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot6);
        java.lang.Object obj10 = legendTitle9.clone();
        jFreeChart5.removeSubtitle((org.jfree.chart.title.Title) legendTitle9);
        java.awt.Stroke stroke12 = jFreeChart5.getBorderStroke();
        waferMapPlot2.setOutlineStroke(stroke12);
        org.junit.Assert.assertNotNull(jFreeChart5);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setSectionOutlinesVisible(true);
        java.awt.Paint paint4 = piePlot1.getBackgroundPaint();
        java.awt.Paint paint6 = piePlot1.getSectionOutlinePaint((java.lang.Comparable) 100.0f);
        java.awt.Stroke stroke7 = piePlot1.getLabelOutlineStroke();
        java.awt.Paint paint8 = piePlot1.getShadowPaint();
        piePlot1.setShadowYOffset((double) 1.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D11.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D11.setAutoRangeStickyZero(false);
        numberAxis3D11.setUpperBound(100.0d);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand18 = numberAxis3D11.getMarkerBand();
        java.awt.Shape shape19 = numberAxis3D11.getLeftArrow();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit20 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis3D11.setTickUnit(numberTickUnit20, false, true);
        java.awt.Paint paint24 = piePlot1.getSectionOutlinePaint((java.lang.Comparable) numberTickUnit20);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(markerAxisBand18);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(numberTickUnit20);
        org.junit.Assert.assertNull(paint24);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("0,0,1,1", "RectangleAnchor.BOTTOM_LEFT", "Range[-1.0,-1.0]", "RectangleEdge.TOP");
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        blockContainer0.setWidth((double) 10.0f);
        org.jfree.chart.block.BlockBorder blockBorder3 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = blockBorder3.getInsets();
        blockContainer0.setMargin(rectangleInsets4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = rectangleConstraint7.toFixedWidth((double) 200);
        org.jfree.chart.util.Size2D size2D10 = blockContainer0.arrange(graphics2D6, rectangleConstraint9);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot11.setLimit(1.0d);
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot11);
        org.jfree.chart.util.VerticalAlignment verticalAlignment15 = legendTitle14.getVerticalAlignment();
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint17 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint19 = rectangleConstraint17.toFixedWidth((double) 200);
        org.jfree.chart.util.Size2D size2D20 = legendTitle14.arrange(graphics2D16, rectangleConstraint19);
        size2D20.height = 100.0f;
        org.jfree.chart.util.Size2D size2D23 = rectangleConstraint9.calculateConstrainedSize(size2D20);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.lang.String str27 = rectangleAnchor26.toString();
        java.awt.geom.Rectangle2D rectangle2D28 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D20, 0.0d, 0.4d, rectangleAnchor26);
        size2D20.setHeight((double) (-237));
        org.junit.Assert.assertNotNull(blockBorder3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(rectangleConstraint7);
        org.junit.Assert.assertNotNull(rectangleConstraint9);
        org.junit.Assert.assertNotNull(size2D10);
        org.junit.Assert.assertNotNull(verticalAlignment15);
        org.junit.Assert.assertNotNull(rectangleConstraint17);
        org.junit.Assert.assertNotNull(rectangleConstraint19);
        org.junit.Assert.assertNotNull(size2D20);
        org.junit.Assert.assertNotNull(size2D23);
        org.junit.Assert.assertNotNull(rectangleAnchor26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "RectangleAnchor.LEFT" + "'", str27.equals("RectangleAnchor.LEFT"));
        org.junit.Assert.assertNotNull(rectangle2D28);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        java.awt.Font font2 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer6 = null;
        org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, paint3, (float) (-1), 0, textMeasurer6);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        multiplePiePlot8.removeChangeListener(plotChangeListener9);
        org.jfree.chart.plot.Plot plot11 = multiplePiePlot8.getParent();
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("ThreadContext", font2, (org.jfree.chart.plot.Plot) multiplePiePlot8, false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo16 = null;
        java.awt.image.BufferedImage bufferedImage17 = jFreeChart13.createBufferedImage((int) (short) 1, (int) (byte) 100, chartRenderingInfo16);
        int int18 = jFreeChart13.getSubtitleCount();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(textBlock7);
        org.junit.Assert.assertNull(plot11);
        org.junit.Assert.assertNotNull(bufferedImage17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer5 = null;
        org.jfree.chart.text.TextBlock textBlock6 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint2, (float) (-1), 0, textMeasurer5);
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine();
        textBlock6.addLine(textLine7);
        org.jfree.chart.text.TextFragment textFragment9 = textLine7.getLastTextFragment();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(textBlock6);
        org.junit.Assert.assertNull(textFragment9);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        java.awt.Color color0 = java.awt.Color.ORANGE;
        int int1 = color0.getGreen();
        java.awt.image.ColorModel colorModel2 = null;
        java.awt.Rectangle rectangle3 = null;
        org.jfree.chart.block.BlockContainer blockContainer4 = new org.jfree.chart.block.BlockContainer();
        blockContainer4.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D7 = blockContainer4.getBounds();
        java.awt.geom.AffineTransform affineTransform8 = null;
        java.awt.RenderingHints renderingHints9 = null;
        java.awt.PaintContext paintContext10 = color0.createContext(colorModel2, rectangle3, rectangle2D7, affineTransform8, renderingHints9);
        float[] floatArray11 = null;
        float[] floatArray12 = color0.getColorComponents(floatArray11);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 200 + "'", int1 == 200);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(paintContext10);
        org.junit.Assert.assertNotNull(floatArray12);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setSectionOutlinesVisible(true);
        java.awt.Paint paint4 = piePlot1.getBackgroundPaint();
        java.awt.Paint paint6 = piePlot1.getSectionOutlinePaint((java.lang.Comparable) 100.0f);
        piePlot1.setCircular(true, false);
        double double10 = piePlot1.getLabelGap();
        piePlot1.setShadowYOffset(1.05d);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot13 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.Plot plot14 = multiplePiePlot13.getParent();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent15 = null;
        multiplePiePlot13.markerChanged(markerChangeEvent15);
        java.awt.Paint paint17 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        multiplePiePlot13.setNoDataMessagePaint(paint17);
        piePlot1.setShadowPaint(paint17);
        piePlot1.setLabelLinksVisible(false);
        boolean boolean22 = piePlot1.getSimpleLabels();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent23 = null;
        piePlot1.datasetChanged(datasetChangeEvent23);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.025d + "'", double10 == 0.025d);
        org.junit.Assert.assertNull(plot14);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        boolean boolean1 = numberAxis3D0.isAutoTickUnitSelection();
        boolean boolean2 = numberAxis3D0.isVerticalTickLabels();
        numberAxis3D0.resizeRange(0.0d);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D6.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D6.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer11 = null;
        org.jfree.chart.plot.PolarPlot polarPlot12 = new org.jfree.chart.plot.PolarPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) numberAxis3D6, polarItemRenderer11);
        org.jfree.chart.plot.PlotOrientation plotOrientation13 = polarPlot12.getOrientation();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer14 = polarPlot12.getRenderer();
        boolean boolean15 = polarPlot12.isRangeZoomable();
        org.jfree.data.general.PieDataset pieDataset18 = null;
        org.jfree.chart.plot.PiePlot piePlot19 = new org.jfree.chart.plot.PiePlot(pieDataset18);
        piePlot19.setSectionOutlinesVisible(true);
        java.awt.Paint paint22 = piePlot19.getBackgroundPaint();
        java.awt.Color color24 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.image.ColorModel colorModel25 = null;
        java.awt.Rectangle rectangle26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        java.awt.geom.AffineTransform affineTransform28 = null;
        java.awt.RenderingHints renderingHints29 = null;
        java.awt.PaintContext paintContext30 = color24.createContext(colorModel25, rectangle26, rectangle2D27, affineTransform28, renderingHints29);
        piePlot19.setSectionPaint((java.lang.Comparable) (byte) 100, (java.awt.Paint) color24);
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor33 = null;
        org.jfree.chart.block.BlockContainer blockContainer36 = new org.jfree.chart.block.BlockContainer();
        blockContainer36.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D39 = blockContainer36.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double41 = categoryAxis32.getCategoryJava2DCoordinate(categoryAnchor33, (int) (byte) 10, 0, rectangle2D39, rectangleEdge40);
        piePlot19.setLegendItemShape((java.awt.Shape) rectangle2D39);
        java.awt.Point point43 = polarPlot12.translateValueThetaRadiusToJava2D((double) (short) 0, 9.223372036854776E18d, rectangle2D39);
        numberAxis3D0.setRightArrow((java.awt.Shape) rectangle2D39);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(plotOrientation13);
        org.junit.Assert.assertNull(polarItemRenderer14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(paintContext30);
        org.junit.Assert.assertNotNull(rectangle2D39);
        org.junit.Assert.assertNotNull(rectangleEdge40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(point43);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit(1.0d);
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot0);
        org.jfree.chart.block.BlockContainer blockContainer4 = new org.jfree.chart.block.BlockContainer();
        blockContainer4.setWidth((double) 10.0f);
        org.jfree.chart.block.BlockBorder blockBorder7 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = blockBorder7.getInsets();
        blockContainer4.setMargin(rectangleInsets8);
        java.lang.String str10 = blockContainer4.getID();
        legendTitle3.setWrapper(blockContainer4);
        java.awt.geom.Rectangle2D rectangle2D12 = blockContainer4.getBounds();
        double double13 = blockContainer4.getContentXOffset();
        blockContainer4.setHeight((-10.0d));
        org.junit.Assert.assertNotNull(blockBorder7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        boolean boolean0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        piePlotState1.setPieHRadius((double) (-1.0f));
        piePlotState1.setTotal((double) (byte) 10);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.Timeline timeline2 = dateAxis1.getTimeline();
        boolean boolean4 = dateAxis1.isHiddenValue((long) (byte) 1);
        org.jfree.chart.axis.Timeline timeline5 = dateAxis1.getTimeline();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.axis.AxisState axisState7 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot8.setLimit(1.0d);
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot8);
        java.awt.geom.Rectangle2D rectangle2D12 = legendTitle11.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        java.util.List list14 = dateAxis1.refreshTicks(graphics2D6, axisState7, rectangle2D12, rectangleEdge13);
        org.junit.Assert.assertNotNull(timeline2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeline5);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertNull(list14);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D1.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D1.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, polarItemRenderer6);
        numberAxis3D1.setTickMarksVisible(true);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = org.jfree.chart.util.VerticalAlignment.CENTER;
        java.awt.Paint paint3 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        boolean boolean4 = verticalAlignment2.equals((java.lang.Object) paint3);
        org.jfree.chart.block.ColumnArrangement columnArrangement7 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment1, verticalAlignment2, (double) (byte) 1, (double) (byte) -1);
        boolean boolean8 = piePlot3D0.equals((java.lang.Object) (byte) 1);
        java.awt.Paint paint9 = piePlot3D0.getLabelOutlinePaint();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor10 = piePlot3D0.getLabelDistributor();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.RingPlot ringPlot13 = new org.jfree.chart.plot.RingPlot(pieDataset12);
        java.awt.Paint paint14 = ringPlot13.getSeparatorPaint();
        double double15 = ringPlot13.getMaximumExplodePercent();
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.data.general.PieDataset pieDataset17 = null;
        org.jfree.chart.plot.PiePlot piePlot18 = new org.jfree.chart.plot.PiePlot(pieDataset17);
        piePlot18.setSectionOutlinesVisible(true);
        java.awt.Paint paint21 = piePlot18.getBackgroundPaint();
        java.awt.Color color23 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.image.ColorModel colorModel24 = null;
        java.awt.Rectangle rectangle25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        java.awt.geom.AffineTransform affineTransform27 = null;
        java.awt.RenderingHints renderingHints28 = null;
        java.awt.PaintContext paintContext29 = color23.createContext(colorModel24, rectangle25, rectangle2D26, affineTransform27, renderingHints28);
        piePlot18.setSectionPaint((java.lang.Comparable) (byte) 100, (java.awt.Paint) color23);
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor32 = null;
        org.jfree.chart.block.BlockContainer blockContainer35 = new org.jfree.chart.block.BlockContainer();
        blockContainer35.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D38 = blockContainer35.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double40 = categoryAxis31.getCategoryJava2DCoordinate(categoryAnchor32, (int) (byte) 10, 0, rectangle2D38, rectangleEdge39);
        piePlot18.setLegendItemShape((java.awt.Shape) rectangle2D38);
        org.jfree.chart.plot.PiePlot3D piePlot3D42 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D42.setBackgroundImageAlignment(1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo46 = null;
        org.jfree.chart.plot.PiePlotState piePlotState47 = ringPlot13.initialise(graphics2D16, rectangle2D38, (org.jfree.chart.plot.PiePlot) piePlot3D42, (java.lang.Integer) 100, plotRenderingInfo46);
        org.jfree.chart.plot.PolarPlot polarPlot48 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo50 = null;
        org.jfree.data.xy.XYDataset xYDataset51 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D52 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D52.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D52.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer57 = null;
        org.jfree.chart.plot.PolarPlot polarPlot58 = new org.jfree.chart.plot.PolarPlot(xYDataset51, (org.jfree.chart.axis.ValueAxis) numberAxis3D52, polarItemRenderer57);
        double double59 = polarPlot58.getMaxRadius();
        org.jfree.chart.block.BlockContainer blockContainer62 = new org.jfree.chart.block.BlockContainer();
        blockContainer62.setWidth((double) 10.0f);
        org.jfree.chart.block.BlockBorder blockBorder65 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets66 = blockBorder65.getInsets();
        blockContainer62.setMargin(rectangleInsets66);
        java.awt.Graphics2D graphics2D68 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint69 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint71 = rectangleConstraint69.toFixedWidth((double) 200);
        org.jfree.chart.util.Size2D size2D72 = blockContainer62.arrange(graphics2D68, rectangleConstraint71);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot73 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot73.setLimit(1.0d);
        org.jfree.chart.title.LegendTitle legendTitle76 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot73);
        org.jfree.chart.util.VerticalAlignment verticalAlignment77 = legendTitle76.getVerticalAlignment();
        java.awt.Graphics2D graphics2D78 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint79 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint81 = rectangleConstraint79.toFixedWidth((double) 200);
        org.jfree.chart.util.Size2D size2D82 = legendTitle76.arrange(graphics2D78, rectangleConstraint81);
        size2D82.height = 100.0f;
        org.jfree.chart.util.Size2D size2D85 = rectangleConstraint71.calculateConstrainedSize(size2D82);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor88 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.lang.String str89 = rectangleAnchor88.toString();
        java.awt.geom.Rectangle2D rectangle2D90 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D82, 0.0d, 0.4d, rectangleAnchor88);
        java.awt.Point point91 = polarPlot58.translateValueThetaRadiusToJava2D((double) 1.0f, (double) (short) 10, rectangle2D90);
        polarPlot48.zoomDomainAxes((double) 15, plotRenderingInfo50, (java.awt.geom.Point2D) point91);
        org.jfree.chart.plot.PlotState plotState93 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo94 = null;
        try {
            piePlot3D0.draw(graphics2D11, rectangle2D38, (java.awt.geom.Point2D) point91, plotState93, plotRenderingInfo94);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor10);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(paintContext29);
        org.junit.Assert.assertNotNull(rectangle2D38);
        org.junit.Assert.assertNotNull(rectangleEdge39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(piePlotState47);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 1.05d + "'", double59 == 1.05d);
        org.junit.Assert.assertNotNull(blockBorder65);
        org.junit.Assert.assertNotNull(rectangleInsets66);
        org.junit.Assert.assertNotNull(rectangleConstraint69);
        org.junit.Assert.assertNotNull(rectangleConstraint71);
        org.junit.Assert.assertNotNull(size2D72);
        org.junit.Assert.assertNotNull(verticalAlignment77);
        org.junit.Assert.assertNotNull(rectangleConstraint79);
        org.junit.Assert.assertNotNull(rectangleConstraint81);
        org.junit.Assert.assertNotNull(size2D82);
        org.junit.Assert.assertNotNull(size2D85);
        org.junit.Assert.assertNotNull(rectangleAnchor88);
        org.junit.Assert.assertTrue("'" + str89 + "' != '" + "RectangleAnchor.LEFT" + "'", str89.equals("RectangleAnchor.LEFT"));
        org.junit.Assert.assertNotNull(rectangle2D90);
        org.junit.Assert.assertNotNull(point91);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        double[] doubleArray5 = new double[] { (byte) 0, 0.2d, (-1.0d) };
        double[] doubleArray9 = new double[] { (byte) 0, 0.2d, (-1.0d) };
        double[] doubleArray13 = new double[] { (byte) 0, 0.2d, (-1.0d) };
        double[][] doubleArray14 = new double[][] { doubleArray5, doubleArray9, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("rect", "RectangleAnchor.BOTTOM_LEFT", doubleArray14);
        java.lang.Number number16 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset15);
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj18 = categoryAxis17.clone();
        categoryAxis17.setTickMarkInsideLength((float) 10L);
        double double21 = categoryAxis17.getUpperMargin();
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.Timeline timeline26 = dateAxis25.getTimeline();
        java.util.TimeZone timeZone27 = dateAxis25.getTimeZone();
        dateAxis23.setTimeZone(timeZone27);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis17, (org.jfree.chart.axis.ValueAxis) dateAxis23, categoryItemRenderer29);
        java.awt.Graphics2D graphics2D31 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        org.jfree.chart.block.BlockBorder blockBorder34 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = blockBorder34.getInsets();
        org.jfree.chart.block.BlockContainer blockContainer36 = new org.jfree.chart.block.BlockContainer();
        blockContainer36.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D39 = blockContainer36.getBounds();
        rectangleInsets35.trim(rectangle2D39);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor41 = null;
        java.awt.geom.Point2D point2D42 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D39, rectangleAnchor41);
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = new org.jfree.chart.axis.CategoryAxis();
        double double44 = categoryAxis43.getCategoryMargin();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor45 = null;
        java.awt.geom.Rectangle2D rectangle2D48 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge49 = org.jfree.chart.util.RectangleEdge.TOP;
        java.lang.String str50 = rectangleEdge49.toString();
        double double51 = categoryAxis43.getCategoryJava2DCoordinate(categoryAnchor45, (int) 'a', 1, rectangle2D48, rectangleEdge49);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo52 = null;
        try {
            org.jfree.chart.axis.AxisState axisState53 = categoryAxis17.draw(graphics2D31, 0.4d, rectangle2D33, rectangle2D39, rectangleEdge49, plotRenderingInfo52);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 0.2d + "'", number16.equals(0.2d));
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.05d + "'", double21 == 0.05d);
        org.junit.Assert.assertNotNull(timeline26);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertNotNull(blockBorder34);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertNotNull(rectangle2D39);
        org.junit.Assert.assertNotNull(point2D42);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.2d + "'", double44 == 0.2d);
        org.junit.Assert.assertNotNull(rectangleEdge49);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "RectangleEdge.TOP" + "'", str50.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (short) 100, (double) (byte) 0, (double) 0.0f, (double) '#');
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D6.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D6.resizeRange((double) 1, (double) 1);
        boolean boolean12 = unitType0.equals((java.lang.Object) numberAxis3D6);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) 1L, (double) 0.5f, 1.0d, 0.0d);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) (-1), (double) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.util.UnitType unitType4 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = new org.jfree.chart.util.RectangleInsets(unitType4, (double) (short) 100, (double) (byte) 0, (double) 0.0f, (double) '#');
        double double11 = rectangleInsets9.calculateBottomOutset((double) 1L);
        java.lang.String str12 = rectangleInsets9.toString();
        org.jfree.chart.block.BlockBorder blockBorder13 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = blockBorder13.getInsets();
        double double16 = rectangleInsets14.trimWidth((double) (byte) 10);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D17 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D17.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D17.setAutoRangeStickyZero(false);
        numberAxis3D17.setUpperBound(100.0d);
        float float24 = numberAxis3D17.getTickMarkOutsideLength();
        org.jfree.chart.block.BlockContainer blockContainer25 = new org.jfree.chart.block.BlockContainer();
        blockContainer25.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D28 = blockContainer25.getBounds();
        numberAxis3D17.setLeftArrow((java.awt.Shape) rectangle2D28);
        org.jfree.chart.entity.ChartEntity chartEntity31 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D28, "");
        java.awt.geom.Rectangle2D rectangle2D32 = rectangleInsets14.createOutsetRectangle(rectangle2D28);
        java.awt.geom.Rectangle2D rectangle2D33 = rectangleInsets9.createOutsetRectangle(rectangle2D28);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot34 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot34.setLimit(1.0d);
        org.jfree.chart.title.LegendTitle legendTitle37 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot34);
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = legendTitle37.getPosition();
        double double39 = numberAxis2.lengthToJava2D(10.0d, rectangle2D33, rectangleEdge38);
        try {
            lineBorder0.draw(graphics2D1, rectangle2D33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(unitType4);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "RectangleInsets[t=100.0,l=0.0,b=0.0,r=35.0]" + "'", str12.equals("RectangleInsets[t=100.0,l=0.0,b=0.0,r=35.0]"));
        org.junit.Assert.assertNotNull(blockBorder13);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 10.0d + "'", double16 == 10.0d);
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 1.0f + "'", float24 == 1.0f);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertNotNull(rectangle2D33);
        org.junit.Assert.assertNotNull(rectangleEdge38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 350.0d + "'", double39 == 350.0d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.Timeline timeline2 = dateAxis1.getTimeline();
        boolean boolean4 = dateAxis1.isHiddenValue((long) (byte) 1);
        org.jfree.chart.axis.Timeline timeline5 = dateAxis1.getTimeline();
        java.util.Date date6 = dateAxis1.getMinimumDate();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.Timeline timeline9 = dateAxis8.getTimeline();
        boolean boolean11 = dateAxis8.isHiddenValue((long) (byte) 1);
        dateAxis8.configure();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition13 = dateAxis8.getTickMarkPosition();
        dateAxis1.setTickMarkPosition(dateTickMarkPosition13);
        org.jfree.data.Range range15 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double17 = range15.constrain((double) (short) 1);
        org.jfree.data.Range range19 = org.jfree.data.Range.shift(range15, (double) 3);
        dateAxis1.setRange(range19);
        org.junit.Assert.assertNotNull(timeline2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeline5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeline9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition13);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertNotNull(range19);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit(1.0d);
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot0);
        org.jfree.chart.block.BlockContainer blockContainer4 = new org.jfree.chart.block.BlockContainer();
        blockContainer4.setWidth((double) 10.0f);
        org.jfree.chart.block.BlockBorder blockBorder7 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = blockBorder7.getInsets();
        blockContainer4.setMargin(rectangleInsets8);
        java.lang.String str10 = blockContainer4.getID();
        legendTitle3.setWrapper(blockContainer4);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D12 = new org.jfree.chart.axis.NumberAxis3D();
        boolean boolean13 = numberAxis3D12.isAutoTickUnitSelection();
        boolean boolean14 = numberAxis3D12.isVerticalTickLabels();
        numberAxis3D12.resizeRange(0.0d);
        boolean boolean18 = numberAxis3D12.equals((java.lang.Object) (short) -1);
        boolean boolean19 = legendTitle3.equals((java.lang.Object) numberAxis3D12);
        org.junit.Assert.assertNotNull(blockBorder7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) "RectangleInsets[t=100.0,l=0.0,b=0.0,r=35.0]", 1.0d, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        java.awt.Font font3 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint4 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer7 = null;
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("", font3, paint4, (float) (byte) 1, 100, textMeasurer7);
        java.awt.Color color9 = java.awt.Color.pink;
        int int10 = color9.getTransparency();
        int int11 = color9.getAlpha();
        org.jfree.chart.text.TextLine textLine12 = new org.jfree.chart.text.TextLine("", font3, (java.awt.Paint) color9);
        java.awt.Color color13 = java.awt.Color.pink;
        int int14 = color13.getTransparency();
        int int15 = color13.getAlpha();
        org.jfree.chart.text.TextBlock textBlock16 = org.jfree.chart.text.TextUtilities.createTextBlock("rect", font3, (java.awt.Paint) color13);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 255 + "'", int11 == 255);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 255 + "'", int15 == 255);
        org.junit.Assert.assertNotNull(textBlock16);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        blockContainer0.setWidth((double) 10.0f);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = rectangleConstraint4.toFixedWidth((double) 200);
        org.jfree.chart.util.Size2D size2D7 = blockContainer0.arrange(graphics2D3, rectangleConstraint6);
        size2D7.height = (-1.0f);
        size2D7.setWidth((double) 200);
        org.junit.Assert.assertNotNull(rectangleConstraint4);
        org.junit.Assert.assertNotNull(rectangleConstraint6);
        org.junit.Assert.assertNotNull(size2D7);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setSectionOutlinesVisible(true);
        java.awt.Paint paint6 = piePlot3.getBackgroundPaint();
        java.awt.Paint paint8 = piePlot3.getSectionOutlinePaint((java.lang.Comparable) 100.0f);
        java.awt.Stroke stroke9 = piePlot3.getLabelOutlineStroke();
        java.awt.Paint paint10 = piePlot3.getShadowPaint();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator12 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        piePlot3.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator12);
        piePlot1.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator12);
        java.text.AttributedString attributedString16 = standardPieSectionLabelGenerator12.getAttributedLabel(3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(attributedString16);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setSectionOutlinesVisible(true);
        java.awt.Paint paint4 = piePlot1.getBackgroundPaint();
        java.awt.Paint paint6 = piePlot1.getSectionOutlinePaint((java.lang.Comparable) 100.0f);
        piePlot1.setCircular(true, false);
        double double10 = piePlot1.getLabelGap();
        java.awt.Shape shape11 = piePlot1.getLegendItemShape();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.RingPlot ringPlot13 = new org.jfree.chart.plot.RingPlot(pieDataset12);
        java.awt.Paint paint14 = ringPlot13.getSeparatorPaint();
        piePlot1.setLabelBackgroundPaint(paint14);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier16 = piePlot1.getDrawingSupplier();
        java.lang.Object obj17 = piePlot1.clone();
        boolean boolean18 = piePlot1.isCircular();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.025d + "'", double10 == 0.025d);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(drawingSupplier16);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        java.awt.Paint paint0 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.Timeline timeline4 = dateAxis3.getTimeline();
        java.util.TimeZone timeZone5 = dateAxis3.getTimeZone();
        dateAxis1.setTimeZone(timeZone5);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.RingPlot ringPlot9 = new org.jfree.chart.plot.RingPlot(pieDataset8);
        java.awt.Paint paint10 = ringPlot9.getSeparatorPaint();
        double double11 = ringPlot9.getMaximumExplodePercent();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        piePlot14.setSectionOutlinesVisible(true);
        java.awt.Paint paint17 = piePlot14.getBackgroundPaint();
        java.awt.Color color19 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.image.ColorModel colorModel20 = null;
        java.awt.Rectangle rectangle21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        java.awt.geom.AffineTransform affineTransform23 = null;
        java.awt.RenderingHints renderingHints24 = null;
        java.awt.PaintContext paintContext25 = color19.createContext(colorModel20, rectangle21, rectangle2D22, affineTransform23, renderingHints24);
        piePlot14.setSectionPaint((java.lang.Comparable) (byte) 100, (java.awt.Paint) color19);
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor28 = null;
        org.jfree.chart.block.BlockContainer blockContainer31 = new org.jfree.chart.block.BlockContainer();
        blockContainer31.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D34 = blockContainer31.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double36 = categoryAxis27.getCategoryJava2DCoordinate(categoryAnchor28, (int) (byte) 10, 0, rectangle2D34, rectangleEdge35);
        piePlot14.setLegendItemShape((java.awt.Shape) rectangle2D34);
        org.jfree.chart.plot.PiePlot3D piePlot3D38 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D38.setBackgroundImageAlignment(1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo42 = null;
        org.jfree.chart.plot.PiePlotState piePlotState43 = ringPlot9.initialise(graphics2D12, rectangle2D34, (org.jfree.chart.plot.PiePlot) piePlot3D38, (java.lang.Integer) 100, plotRenderingInfo42);
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        double double45 = dateAxis1.java2DToValue(0.4d, rectangle2D34, rectangleEdge44);
        org.jfree.data.Range range46 = null;
        org.jfree.data.Range range48 = org.jfree.data.Range.expandToInclude(range46, (-1.0d));
        boolean boolean50 = range48.contains((double) 1);
        org.jfree.data.Range range53 = org.jfree.data.Range.shift(range48, (double) 100, false);
        org.jfree.data.Range range56 = org.jfree.data.Range.expand(range53, 0.0d, (double) (short) 0);
        org.jfree.data.time.DateRange dateRange57 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.data.Range range59 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange57, 0.2d);
        org.jfree.data.Range range60 = org.jfree.data.Range.combine(range53, (org.jfree.data.Range) dateRange57);
        dateAxis1.setRange(range60);
        org.junit.Assert.assertNotNull(timeline4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(paintContext25);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNotNull(rectangleEdge35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(piePlotState43);
        org.junit.Assert.assertNotNull(rectangleEdge44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 9.223372036854776E18d + "'", double45 == 9.223372036854776E18d);
        org.junit.Assert.assertNotNull(range48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(range53);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertNotNull(dateRange57);
        org.junit.Assert.assertNotNull(range59);
        org.junit.Assert.assertNotNull(range60);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setSectionOutlinesVisible(true);
        java.awt.Paint paint4 = piePlot1.getBackgroundPaint();
        java.awt.Paint paint6 = piePlot1.getSectionOutlinePaint((java.lang.Comparable) 100.0f);
        java.awt.Stroke stroke7 = piePlot1.getLabelOutlineStroke();
        java.awt.Paint paint8 = piePlot1.getShadowPaint();
        piePlot1.setShadowYOffset((double) 1.0f);
        double double11 = piePlot1.getLabelLinkMargin();
        double double12 = piePlot1.getLabelLinkMargin();
        java.awt.Paint paint13 = piePlot1.getShadowPaint();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.025d + "'", double11 == 0.025d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.025d + "'", double12 == 0.025d);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        java.awt.Paint paint2 = ringPlot1.getSeparatorPaint();
        double double3 = ringPlot1.getMaximumExplodePercent();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        piePlot6.setSectionOutlinesVisible(true);
        java.awt.Paint paint9 = piePlot6.getBackgroundPaint();
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.image.ColorModel colorModel12 = null;
        java.awt.Rectangle rectangle13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.awt.geom.AffineTransform affineTransform15 = null;
        java.awt.RenderingHints renderingHints16 = null;
        java.awt.PaintContext paintContext17 = color11.createContext(colorModel12, rectangle13, rectangle2D14, affineTransform15, renderingHints16);
        piePlot6.setSectionPaint((java.lang.Comparable) (byte) 100, (java.awt.Paint) color11);
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor20 = null;
        org.jfree.chart.block.BlockContainer blockContainer23 = new org.jfree.chart.block.BlockContainer();
        blockContainer23.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D26 = blockContainer23.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double28 = categoryAxis19.getCategoryJava2DCoordinate(categoryAnchor20, (int) (byte) 10, 0, rectangle2D26, rectangleEdge27);
        piePlot6.setLegendItemShape((java.awt.Shape) rectangle2D26);
        org.jfree.chart.plot.PiePlot3D piePlot3D30 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D30.setBackgroundImageAlignment(1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        org.jfree.chart.plot.PiePlotState piePlotState35 = ringPlot1.initialise(graphics2D4, rectangle2D26, (org.jfree.chart.plot.PiePlot) piePlot3D30, (java.lang.Integer) 100, plotRenderingInfo34);
        double double36 = piePlotState35.getPieCenterY();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo37 = piePlotState35.getInfo();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(paintContext17);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(piePlotState35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNull(plotRenderingInfo37);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getRangeCrosshairValue();
        java.awt.Stroke stroke2 = categoryPlot0.getDomainGridlineStroke();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent3 = null;
        categoryPlot0.datasetChanged(datasetChangeEvent3);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor5 = categoryPlot0.getDomainGridlinePosition();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(categoryAnchor5);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        piePlotState1.setPieHRadius((double) (-1.0f));
        piePlotState1.setPieHRadius(350.0d);
        double double6 = piePlotState1.getPieHRadius();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 350.0d + "'", double6 == 350.0d);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        boolean boolean1 = numberAxis3D0.isAutoTickUnitSelection();
        boolean boolean2 = numberAxis3D0.isTickLabelsVisible();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextLine textLine1 = null;
        textBlock0.addLine(textLine1);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = textBlock0.getLineAlignment();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        java.lang.String str5 = horizontalAlignment4.toString();
        java.lang.String str6 = horizontalAlignment4.toString();
        textBlock0.setLineAlignment(horizontalAlignment4);
        org.junit.Assert.assertNotNull(horizontalAlignment3);
        org.junit.Assert.assertNotNull(horizontalAlignment4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "HorizontalAlignment.RIGHT" + "'", str5.equals("HorizontalAlignment.RIGHT"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "HorizontalAlignment.RIGHT" + "'", str6.equals("HorizontalAlignment.RIGHT"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D0.setAutoRangeStickyZero(false);
        numberAxis3D0.setUpperBound(100.0d);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand7 = numberAxis3D0.getMarkerBand();
        double double8 = numberAxis3D0.getFixedAutoRange();
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D10.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D10.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer15 = null;
        org.jfree.chart.plot.PolarPlot polarPlot16 = new org.jfree.chart.plot.PolarPlot(xYDataset9, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, polarItemRenderer15);
        java.lang.String str17 = polarPlot16.getPlotType();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent18 = null;
        polarPlot16.datasetChanged(datasetChangeEvent18);
        java.awt.Stroke stroke20 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        polarPlot16.setRadiusGridlineStroke(stroke20);
        numberAxis3D0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) polarPlot16);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent23 = null;
        polarPlot16.datasetChanged(datasetChangeEvent23);
        boolean boolean25 = polarPlot16.isDomainZoomable();
        java.awt.Paint paint26 = polarPlot16.getAngleGridlinePaint();
        polarPlot16.setRadiusGridlinesVisible(false);
        org.junit.Assert.assertNull(markerAxisBand7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Polar Plot" + "'", str17.equals("Polar Plot"));
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(paint26);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getDomainAxisEdge((int) (byte) 1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryPlot0.getAxisOffset();
        int int4 = categoryPlot0.getWeight();
        org.jfree.chart.LegendItemCollection legendItemCollection5 = categoryPlot0.getLegendItems();
        java.awt.Stroke stroke6 = categoryPlot0.getRangeCrosshairStroke();
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(legendItemCollection5);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) blockBorder0, jFreeChart1);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = null;
        chartChangeEvent2.setType(chartChangeEventType3);
        java.awt.Font font7 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint8 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer11 = null;
        org.jfree.chart.text.TextBlock textBlock12 = org.jfree.chart.text.TextUtilities.createTextBlock("", font7, paint8, (float) (-1), 0, textMeasurer11);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot13 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener14 = null;
        multiplePiePlot13.removeChangeListener(plotChangeListener14);
        org.jfree.chart.plot.Plot plot16 = multiplePiePlot13.getParent();
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("ThreadContext", font7, (org.jfree.chart.plot.Plot) multiplePiePlot13, false);
        org.jfree.chart.title.LegendTitle legendTitle19 = jFreeChart18.getLegend();
        java.awt.Paint paint20 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        jFreeChart18.setBorderPaint(paint20);
        org.jfree.chart.event.ChartProgressListener chartProgressListener22 = null;
        jFreeChart18.removeProgressListener(chartProgressListener22);
        java.awt.Stroke stroke24 = jFreeChart18.getBorderStroke();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo29 = null;
        java.awt.image.BufferedImage bufferedImage30 = jFreeChart18.createBufferedImage(10, (int) (byte) 1, (double) (byte) 10, (double) 100, chartRenderingInfo29);
        java.awt.Paint paint31 = jFreeChart18.getBackgroundPaint();
        chartChangeEvent2.setChart(jFreeChart18);
        float float33 = jFreeChart18.getBackgroundImageAlpha();
        org.junit.Assert.assertNotNull(blockBorder0);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(textBlock12);
        org.junit.Assert.assertNull(plot16);
        org.junit.Assert.assertNull(legendTitle19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(bufferedImage30);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.5f + "'", float33 == 0.5f);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        java.util.ResourceBundle.clearCache();
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        java.awt.Font font2 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer6 = null;
        org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, paint3, (float) (-1), 0, textMeasurer6);
        java.awt.Paint paint8 = null;
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer12 = new org.jfree.chart.text.G2TextMeasurer(graphics2D11);
        try {
            org.jfree.chart.text.TextBlock textBlock13 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleAnchor.BOTTOM_LEFT", font2, paint8, (float) 100L, (int) (short) 100, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(textBlock7);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setSectionOutlinesVisible(true);
        java.awt.Paint paint4 = piePlot1.getBackgroundPaint();
        java.awt.Paint paint6 = piePlot1.getSectionOutlinePaint((java.lang.Comparable) 100.0f);
        java.awt.Stroke stroke7 = piePlot1.getLabelLinkStroke();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor8 = piePlot1.getLabelDistributor();
        try {
            org.jfree.chart.plot.PieLabelRecord pieLabelRecord10 = abstractPieLabelDistributor8.getPieLabelRecord((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor8);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        org.jfree.chart.plot.Plot plot2 = ringPlot1.getRootPlot();
        float float3 = ringPlot1.getBackgroundImageAlpha();
        java.lang.Object obj4 = ringPlot1.clone();
        ringPlot1.setInnerSeparatorExtension(45.0d);
        org.junit.Assert.assertNotNull(plot2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.5f + "'", float3 == 0.5f);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit(1.0d);
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot0);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = legendTitle3.getPosition();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent5 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle3);
        org.jfree.chart.JFreeChart jFreeChart6 = titleChangeEvent5.getChart();
        org.jfree.chart.title.Title title7 = titleChangeEvent5.getTitle();
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNull(jFreeChart6);
        org.junit.Assert.assertNotNull(title7);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        boolean boolean1 = numberAxis3D0.isAutoTickUnitSelection();
        boolean boolean2 = numberAxis3D0.isVisible();
        numberAxis3D0.setLowerBound((double) 200);
        numberAxis3D0.setLabel("");
        double double7 = numberAxis3D0.getAutoRangeMinimumSize();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0E-8d + "'", double7 == 1.0E-8d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setSectionOutlinesVisible(true);
        java.awt.Paint paint4 = piePlot1.getBackgroundPaint();
        java.awt.Paint paint6 = piePlot1.getSectionOutlinePaint((java.lang.Comparable) 100.0f);
        java.awt.Stroke stroke7 = piePlot1.getLabelLinkStroke();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D8 = new org.jfree.chart.axis.NumberAxis3D();
        boolean boolean9 = numberAxis3D8.isAutoTickUnitSelection();
        boolean boolean10 = numberAxis3D8.isVisible();
        boolean boolean11 = numberAxis3D8.isAutoRange();
        numberAxis3D8.setTickLabelsVisible(true);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit14 = numberAxis3D8.getTickUnit();
        double double15 = piePlot1.getExplodePercent((java.lang.Comparable) numberTickUnit14);
        try {
            piePlot1.setInteriorGap(350.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid 'percent' (350.0) argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(numberTickUnit14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        blockContainer0.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D3 = blockContainer0.getBounds();
        org.jfree.chart.block.Block block4 = null;
        blockContainer0.add(block4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = blockContainer0.getPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = null;
        try {
            blockContainer0.setMargin(rectangleInsets7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'margin' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D3);
        org.junit.Assert.assertNotNull(rectangleInsets6);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.Timeline timeline2 = dateAxis1.getTimeline();
        boolean boolean4 = dateAxis1.isHiddenValue((long) (byte) 1);
        org.jfree.chart.axis.Timeline timeline5 = dateAxis1.getTimeline();
        java.util.Date date6 = dateAxis1.getMaximumDate();
        dateAxis1.setRange((-1.0d), (-0.025d));
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = categoryPlot10.getDomainAxisEdge((int) (byte) 1);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = categoryPlot10.getAxisOffset();
        boolean boolean14 = dateAxis1.equals((java.lang.Object) rectangleInsets13);
        dateAxis1.setAutoRangeMinimumSize((double) 1L);
        org.junit.Assert.assertNotNull(timeline2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeline5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextLine textLine1 = null;
        textBlock0.addLine(textLine1);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = textBlock0.getLineAlignment();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = textBlock0.getLineAlignment();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor8 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.block.BlockContainer blockContainer9 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.util.Size2D size2D11 = blockContainer9.arrange(graphics2D10);
        boolean boolean12 = textBlockAnchor8.equals((java.lang.Object) blockContainer9);
        try {
            java.awt.Shape shape16 = textBlock0.calculateBounds(graphics2D5, 0.0f, 1.0f, textBlockAnchor8, (float) 100, (float) (byte) 100, 0.025d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment3);
        org.junit.Assert.assertNotNull(horizontalAlignment4);
        org.junit.Assert.assertNotNull(textBlockAnchor8);
        org.junit.Assert.assertNotNull(size2D11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getDomainAxisEdge((int) (byte) 1);
        org.jfree.chart.axis.AxisLocation axisLocation4 = categoryPlot0.getDomainAxisLocation(200);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis();
        double double6 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D15 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D15.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D15.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer20 = null;
        org.jfree.chart.plot.PolarPlot polarPlot21 = new org.jfree.chart.plot.PolarPlot(xYDataset14, (org.jfree.chart.axis.ValueAxis) numberAxis3D15, polarItemRenderer20);
        double double22 = polarPlot21.getMaxRadius();
        org.jfree.chart.block.BlockContainer blockContainer25 = new org.jfree.chart.block.BlockContainer();
        blockContainer25.setWidth((double) 10.0f);
        org.jfree.chart.block.BlockBorder blockBorder28 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = blockBorder28.getInsets();
        blockContainer25.setMargin(rectangleInsets29);
        java.awt.Graphics2D graphics2D31 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint32 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint34 = rectangleConstraint32.toFixedWidth((double) 200);
        org.jfree.chart.util.Size2D size2D35 = blockContainer25.arrange(graphics2D31, rectangleConstraint34);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot36 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot36.setLimit(1.0d);
        org.jfree.chart.title.LegendTitle legendTitle39 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot36);
        org.jfree.chart.util.VerticalAlignment verticalAlignment40 = legendTitle39.getVerticalAlignment();
        java.awt.Graphics2D graphics2D41 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint42 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint44 = rectangleConstraint42.toFixedWidth((double) 200);
        org.jfree.chart.util.Size2D size2D45 = legendTitle39.arrange(graphics2D41, rectangleConstraint44);
        size2D45.height = 100.0f;
        org.jfree.chart.util.Size2D size2D48 = rectangleConstraint34.calculateConstrainedSize(size2D45);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor51 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.lang.String str52 = rectangleAnchor51.toString();
        java.awt.geom.Rectangle2D rectangle2D53 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D45, 0.0d, 0.4d, rectangleAnchor51);
        java.awt.Point point54 = polarPlot21.translateValueThetaRadiusToJava2D((double) 1.0f, (double) (short) 10, rectangle2D53);
        polarPlot11.zoomDomainAxes((double) 15, plotRenderingInfo13, (java.awt.geom.Point2D) point54);
        categoryPlot0.zoomRangeAxes((double) (short) 100, 0.05d, plotRenderingInfo10, (java.awt.geom.Point2D) point54);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.05d + "'", double22 == 1.05d);
        org.junit.Assert.assertNotNull(blockBorder28);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(rectangleConstraint32);
        org.junit.Assert.assertNotNull(rectangleConstraint34);
        org.junit.Assert.assertNotNull(size2D35);
        org.junit.Assert.assertNotNull(verticalAlignment40);
        org.junit.Assert.assertNotNull(rectangleConstraint42);
        org.junit.Assert.assertNotNull(rectangleConstraint44);
        org.junit.Assert.assertNotNull(size2D45);
        org.junit.Assert.assertNotNull(size2D48);
        org.junit.Assert.assertNotNull(rectangleAnchor51);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "RectangleAnchor.LEFT" + "'", str52.equals("RectangleAnchor.LEFT"));
        org.junit.Assert.assertNotNull(rectangle2D53);
        org.junit.Assert.assertNotNull(point54);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit(1.0d);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        multiplePiePlot0.addChangeListener(plotChangeListener3);
        boolean boolean6 = multiplePiePlot0.equals((java.lang.Object) (short) 10);
        multiplePiePlot0.setLimit(0.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getDomainAxisEdge((int) (byte) 1);
        org.jfree.chart.axis.AxisLocation axisLocation4 = categoryPlot0.getDomainAxisLocation(200);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis();
        org.jfree.chart.axis.ValueAxis valueAxis7 = categoryPlot0.getRangeAxisForDataset(10);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        double double9 = categoryAxis8.getCategoryMargin();
        categoryAxis8.addCategoryLabelToolTip((java.lang.Comparable) 100, "TextAnchor.CENTER_RIGHT");
        java.lang.Object obj13 = categoryAxis8.clone();
        categoryAxis8.clearCategoryLabelToolTips();
        org.jfree.chart.block.BlockBorder blockBorder15 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = blockBorder15.getInsets();
        org.jfree.chart.block.BlockContainer blockContainer17 = new org.jfree.chart.block.BlockContainer();
        blockContainer17.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D20 = blockContainer17.getBounds();
        rectangleInsets16.trim(rectangle2D20);
        categoryAxis8.setLabelInsets(rectangleInsets16);
        categoryPlot0.setDomainAxis(categoryAxis8);
        org.jfree.chart.util.UnitType unitType24 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = new org.jfree.chart.util.RectangleInsets(unitType24, (double) (short) 100, (double) (byte) 0, (double) 0.0f, (double) '#');
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = new org.jfree.chart.util.RectangleInsets(unitType24, (double) (-1L), 10.0d, (double) 0.0f, 0.0d);
        java.awt.Color color35 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.block.BlockBorder blockBorder36 = new org.jfree.chart.block.BlockBorder(rectangleInsets34, (java.awt.Paint) color35);
        double double38 = rectangleInsets34.calculateTopInset((double) 10);
        categoryPlot0.setInsets(rectangleInsets34);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.2d + "'", double9 == 0.2d);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(blockBorder15);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(unitType24);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + (-1.0d) + "'", double38 == (-1.0d));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.image.ColorModel colorModel1 = null;
        java.awt.Rectangle rectangle2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.AffineTransform affineTransform4 = null;
        java.awt.RenderingHints renderingHints5 = null;
        java.awt.PaintContext paintContext6 = color0.createContext(colorModel1, rectangle2, rectangle2D3, affineTransform4, renderingHints5);
        int int7 = color0.getGreen();
        int int8 = color0.getAlpha();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paintContext6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 192 + "'", int7 == 192);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 255 + "'", int8 == 255);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getCategoryMargin();
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) 100, "TextAnchor.CENTER_RIGHT");
        categoryAxis0.configure();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions6 = categoryAxis0.getCategoryLabelPositions();
        java.lang.Object obj7 = categoryAxis0.clone();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(categoryLabelPositions6);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.util.UnitType unitType2 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = new org.jfree.chart.util.RectangleInsets(unitType2, (double) (short) 100, (double) (byte) 0, (double) 0.0f, (double) '#');
        double double9 = rectangleInsets7.calculateBottomOutset((double) 1L);
        java.lang.String str10 = rectangleInsets7.toString();
        org.jfree.chart.block.BlockBorder blockBorder11 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = blockBorder11.getInsets();
        double double14 = rectangleInsets12.trimWidth((double) (byte) 10);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D15 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D15.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D15.setAutoRangeStickyZero(false);
        numberAxis3D15.setUpperBound(100.0d);
        float float22 = numberAxis3D15.getTickMarkOutsideLength();
        org.jfree.chart.block.BlockContainer blockContainer23 = new org.jfree.chart.block.BlockContainer();
        blockContainer23.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D26 = blockContainer23.getBounds();
        numberAxis3D15.setLeftArrow((java.awt.Shape) rectangle2D26);
        org.jfree.chart.entity.ChartEntity chartEntity29 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D26, "");
        java.awt.geom.Rectangle2D rectangle2D30 = rectangleInsets12.createOutsetRectangle(rectangle2D26);
        java.awt.geom.Rectangle2D rectangle2D31 = rectangleInsets7.createOutsetRectangle(rectangle2D26);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot32 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot32.setLimit(1.0d);
        org.jfree.chart.title.LegendTitle legendTitle35 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot32);
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = legendTitle35.getPosition();
        double double37 = numberAxis0.lengthToJava2D(10.0d, rectangle2D31, rectangleEdge36);
        org.jfree.data.general.PieDataset pieDataset38 = null;
        java.lang.Comparable comparable41 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity44 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D31, pieDataset38, 200, 15, comparable41, "TextAnchor.BOTTOM_CENTER", "RectangleAnchor.LEFT");
        org.jfree.data.general.PieDataset pieDataset45 = pieSectionEntity44.getDataset();
        org.junit.Assert.assertNotNull(unitType2);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "RectangleInsets[t=100.0,l=0.0,b=0.0,r=35.0]" + "'", str10.equals("RectangleInsets[t=100.0,l=0.0,b=0.0,r=35.0]"));
        org.junit.Assert.assertNotNull(blockBorder11);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 10.0d + "'", double14 == 10.0d);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 1.0f + "'", float22 == 1.0f);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 350.0d + "'", double37 == 350.0d);
        org.junit.Assert.assertNull(pieDataset45);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setBackgroundAlpha((float) (-1));
        double double4 = piePlot1.getShadowYOffset();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator5 = piePlot1.getLegendLabelToolTipGenerator();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertNull(pieSectionLabelGenerator5);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setSectionOutlinesVisible(true);
        java.awt.Paint paint4 = piePlot1.getBackgroundPaint();
        java.awt.Paint paint6 = piePlot1.getSectionOutlinePaint((java.lang.Comparable) 100.0f);
        java.awt.Stroke stroke7 = piePlot1.getLabelOutlineStroke();
        java.awt.Paint paint8 = piePlot1.getShadowPaint();
        piePlot1.setShadowYOffset((double) 1.0f);
        double double11 = piePlot1.getLabelLinkMargin();
        double double12 = piePlot1.getLabelLinkMargin();
        java.awt.Font font13 = piePlot1.getLabelFont();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.025d + "'", double11 == 0.025d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.025d + "'", double12 == 0.025d);
        org.junit.Assert.assertNotNull(font13);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        org.jfree.chart.block.BlockBorder blockBorder1 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = blockBorder1.getInsets();
        double double4 = rectangleInsets2.trimWidth((double) (byte) 10);
        org.jfree.chart.util.UnitType unitType5 = rectangleInsets2.getUnitType();
        boolean boolean6 = strokeMap0.equals((java.lang.Object) rectangleInsets2);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D8 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D8.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D8.setAutoRangeStickyZero(false);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        piePlot14.setSectionOutlinesVisible(true);
        java.awt.Paint paint17 = piePlot14.getBackgroundPaint();
        java.awt.Paint paint19 = piePlot14.getSectionOutlinePaint((java.lang.Comparable) 100.0f);
        java.awt.Stroke stroke20 = piePlot14.getLabelLinkStroke();
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        piePlot14.setSectionOutlineStroke((java.lang.Comparable) (byte) 100, stroke22);
        numberAxis3D8.setTickMarkStroke(stroke22);
        strokeMap0.put((java.lang.Comparable) "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", stroke22);
        org.junit.Assert.assertNotNull(blockBorder1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 10.0d + "'", double4 == 10.0d);
        org.junit.Assert.assertNotNull(unitType5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNull(paint19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(stroke22);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getDomainAxisEdge((int) (byte) 1);
        org.jfree.chart.axis.AxisLocation axisLocation4 = categoryPlot0.getDomainAxisLocation(200);
        java.awt.Font font6 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color7 = java.awt.Color.PINK;
        org.jfree.chart.text.TextFragment textFragment9 = new org.jfree.chart.text.TextFragment("", font6, (java.awt.Paint) color7, (float) 1L);
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color7);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent11 = null;
        categoryPlot0.datasetChanged(datasetChangeEvent11);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit(1.0d);
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot0);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = legendTitle3.getVerticalAlignment();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = legendTitle3.getLegendItemGraphicLocation();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        legendTitle3.setItemLabelPadding(rectangleInsets6);
        double double9 = rectangleInsets6.trimHeight(1.0d);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        java.awt.Paint paint1 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker(35.0d, paint1, stroke2);
        float float4 = valueMarker3.getAlpha();
        java.awt.Paint paint6 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(35.0d, paint6, stroke7);
        float float9 = valueMarker8.getAlpha();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType10 = valueMarker8.getLabelOffsetType();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType11 = valueMarker8.getLabelOffsetType();
        valueMarker3.setLabelOffsetType(lengthAdjustmentType11);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType13 = valueMarker3.getLabelOffsetType();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1.0f + "'", float9 == 1.0f);
        org.junit.Assert.assertNotNull(lengthAdjustmentType10);
        org.junit.Assert.assertNotNull(lengthAdjustmentType11);
        org.junit.Assert.assertNotNull(lengthAdjustmentType13);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit(1.0d);
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot0);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = legendTitle3.getVerticalAlignment();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = rectangleConstraint6.toFixedWidth((double) 200);
        org.jfree.chart.util.Size2D size2D9 = legendTitle3.arrange(graphics2D5, rectangleConstraint8);
        org.jfree.chart.block.BlockBorder blockBorder10 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = blockBorder10.getInsets();
        double double13 = rectangleInsets11.trimWidth((double) (byte) 10);
        double double14 = rectangleInsets11.getBottom();
        legendTitle3.setItemLabelPadding(rectangleInsets11);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent16 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle3);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = legendTitle3.getLegendItemGraphicEdge();
        double double18 = legendTitle3.getWidth();
        org.jfree.chart.block.BlockBorder blockBorder19 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.JFreeChart jFreeChart20 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent21 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) blockBorder19, jFreeChart20);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType22 = null;
        chartChangeEvent21.setType(chartChangeEventType22);
        java.awt.Font font26 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint27 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer30 = null;
        org.jfree.chart.text.TextBlock textBlock31 = org.jfree.chart.text.TextUtilities.createTextBlock("", font26, paint27, (float) (-1), 0, textMeasurer30);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot32 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener33 = null;
        multiplePiePlot32.removeChangeListener(plotChangeListener33);
        org.jfree.chart.plot.Plot plot35 = multiplePiePlot32.getParent();
        org.jfree.chart.JFreeChart jFreeChart37 = new org.jfree.chart.JFreeChart("ThreadContext", font26, (org.jfree.chart.plot.Plot) multiplePiePlot32, false);
        org.jfree.chart.title.LegendTitle legendTitle38 = jFreeChart37.getLegend();
        java.awt.Paint paint39 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        jFreeChart37.setBorderPaint(paint39);
        org.jfree.chart.event.ChartProgressListener chartProgressListener41 = null;
        jFreeChart37.removeProgressListener(chartProgressListener41);
        java.awt.Stroke stroke43 = jFreeChart37.getBorderStroke();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo48 = null;
        java.awt.image.BufferedImage bufferedImage49 = jFreeChart37.createBufferedImage(10, (int) (byte) 1, (double) (byte) 10, (double) 100, chartRenderingInfo48);
        java.awt.Paint paint50 = jFreeChart37.getBackgroundPaint();
        chartChangeEvent21.setChart(jFreeChart37);
        legendTitle3.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart37);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor53 = legendTitle3.getLegendItemGraphicAnchor();
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(rectangleConstraint6);
        org.junit.Assert.assertNotNull(rectangleConstraint8);
        org.junit.Assert.assertNotNull(size2D9);
        org.junit.Assert.assertNotNull(blockBorder10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 10.0d + "'", double13 == 10.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(blockBorder19);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(textBlock31);
        org.junit.Assert.assertNull(plot35);
        org.junit.Assert.assertNull(legendTitle38);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(bufferedImage49);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertNotNull(rectangleAnchor53);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        java.awt.Font font0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setSectionOutlinesVisible(true);
        java.awt.Paint paint4 = piePlot1.getBackgroundPaint();
        java.awt.Paint paint6 = piePlot1.getSectionOutlinePaint((java.lang.Comparable) 100.0f);
        java.awt.Stroke stroke7 = piePlot1.getLabelOutlineStroke();
        java.awt.Paint paint8 = piePlot1.getShadowPaint();
        piePlot1.setShadowYOffset((double) 1.0f);
        double double11 = piePlot1.getLabelLinkMargin();
        piePlot1.setInteriorGap((double) 0.0f);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.025d + "'", double11 == 0.025d);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setSectionOutlinesVisible(true);
        java.awt.Paint paint6 = piePlot3.getBackgroundPaint();
        java.awt.Paint paint8 = piePlot3.getSectionOutlinePaint((java.lang.Comparable) 100.0f);
        java.awt.Stroke stroke9 = piePlot3.getLabelOutlineStroke();
        java.awt.Paint paint10 = piePlot3.getShadowPaint();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator12 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        piePlot3.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator12);
        piePlot1.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator12);
        piePlot1.setPieIndex(10);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0, waferMapRenderer1);
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer3 = null;
        waferMapPlot2.setRenderer(waferMapRenderer3);
        try {
            org.jfree.chart.LegendItemCollection legendItemCollection5 = waferMapPlot2.getLegendItems();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("ThreadContext", "RectangleEdge.TOP", "RectangleAnchor.BOTTOM_LEFT", image3, "RectangleEdge.TOP", "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "ThreadContext");
        java.util.List list8 = projectInfo7.getContributors();
        org.junit.Assert.assertNull(list8);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D1.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D1.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, polarItemRenderer6);
        double double8 = polarPlot7.getMaxRadius();
        org.jfree.chart.LegendItemCollection legendItemCollection9 = polarPlot7.getLegendItems();
        org.jfree.chart.plot.Plot plot10 = polarPlot7.getRootPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D14.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D14.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer19 = null;
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, polarItemRenderer19);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent21 = null;
        polarPlot20.datasetChanged(datasetChangeEvent21);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        org.jfree.chart.block.BlockBorder blockBorder26 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = blockBorder26.getInsets();
        org.jfree.chart.block.BlockContainer blockContainer28 = new org.jfree.chart.block.BlockContainer();
        blockContainer28.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D31 = blockContainer28.getBounds();
        rectangleInsets27.trim(rectangle2D31);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor33 = null;
        java.awt.geom.Point2D point2D34 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D31, rectangleAnchor33);
        polarPlot20.zoomDomainAxes((double) (short) 10, (double) 10.0f, plotRenderingInfo25, point2D34);
        polarPlot7.zoomRangeAxes(4.0d, plotRenderingInfo12, point2D34, false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.05d + "'", double8 == 1.05d);
        org.junit.Assert.assertNotNull(legendItemCollection9);
        org.junit.Assert.assertNotNull(plot10);
        org.junit.Assert.assertNotNull(blockBorder26);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertNotNull(point2D34);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("ChartChangeEventType.DATASET_UPDATED", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot2 = dateAxis1.getPlot();
        org.junit.Assert.assertNull(plot2);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("PlotOrientation.VERTICAL");
        boolean boolean2 = numberAxis1.isVisible();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("hi!", "", "RectangleEdge.TOP", image3, "RectangleEdge.TOP", "", "RectangleEdge.TOP");
        projectInfo7.setVersion("TextAnchor.CENTER_RIGHT");
        java.awt.Image image13 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo17 = new org.jfree.chart.ui.ProjectInfo("hi!", "", "RectangleEdge.TOP", image13, "RectangleEdge.TOP", "", "RectangleEdge.TOP");
        projectInfo17.setVersion("TextAnchor.CENTER_RIGHT");
        projectInfo7.addLibrary((org.jfree.chart.ui.Library) projectInfo17);
        java.awt.Image image21 = null;
        projectInfo7.setLogo(image21);
        java.lang.String str23 = projectInfo7.getName();
        org.jfree.data.general.PieDataset pieDataset24 = null;
        org.jfree.chart.plot.PiePlot piePlot25 = new org.jfree.chart.plot.PiePlot(pieDataset24);
        piePlot25.setSectionOutlinesVisible(true);
        java.awt.Paint paint28 = piePlot25.getBackgroundPaint();
        java.awt.Paint paint30 = piePlot25.getSectionOutlinePaint((java.lang.Comparable) 100.0f);
        java.awt.Font font33 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint34 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer37 = null;
        org.jfree.chart.text.TextBlock textBlock38 = org.jfree.chart.text.TextUtilities.createTextBlock("", font33, paint34, (float) (-1), 0, textMeasurer37);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot39 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener40 = null;
        multiplePiePlot39.removeChangeListener(plotChangeListener40);
        org.jfree.chart.plot.Plot plot42 = multiplePiePlot39.getParent();
        org.jfree.chart.JFreeChart jFreeChart44 = new org.jfree.chart.JFreeChart("ThreadContext", font33, (org.jfree.chart.plot.Plot) multiplePiePlot39, false);
        jFreeChart44.setBackgroundImageAlignment(200);
        float float47 = jFreeChart44.getBackgroundImageAlpha();
        piePlot25.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart44);
        java.util.List list49 = jFreeChart44.getSubtitles();
        projectInfo7.setContributors(list49);
        projectInfo7.addOptionalLibrary("TextAnchor.CENTER_RIGHT");
        java.lang.String str53 = projectInfo7.getInfo();
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!" + "'", str23.equals("hi!"));
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNull(paint30);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(textBlock38);
        org.junit.Assert.assertNull(plot42);
        org.junit.Assert.assertTrue("'" + float47 + "' != '" + 0.5f + "'", float47 == 0.5f);
        org.junit.Assert.assertNotNull(list49);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "RectangleEdge.TOP" + "'", str53.equals("RectangleEdge.TOP"));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        java.awt.Paint paint1 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker(35.0d, paint1, stroke2);
        float float4 = valueMarker3.getAlpha();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType5 = valueMarker3.getLabelOffsetType();
        valueMarker3.setAlpha((float) 1);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(lengthAdjustmentType5);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.expandToInclude(range0, (-1.0d));
        boolean boolean4 = range2.contains((double) 1);
        org.jfree.data.Range range7 = org.jfree.data.Range.shift(range2, (double) 100, false);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.Plot plot9 = multiplePiePlot8.getParent();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        multiplePiePlot8.markerChanged(markerChangeEvent10);
        java.lang.Comparable comparable12 = multiplePiePlot8.getAggregatedItemsKey();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent13 = null;
        multiplePiePlot8.datasetChanged(datasetChangeEvent13);
        boolean boolean15 = range2.equals((java.lang.Object) multiplePiePlot8);
        org.jfree.data.Range range17 = org.jfree.data.Range.expandToInclude(range2, (double) (-1));
        double double18 = range2.getUpperBound();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNull(plot9);
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + "Other" + "'", comparable12.equals("Other"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + (-1.0d) + "'", double18 == (-1.0d));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D0.setAutoRangeStickyZero(false);
        numberAxis3D0.setUpperBound(100.0d);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand7 = numberAxis3D0.getMarkerBand();
        double double8 = numberAxis3D0.getFixedAutoRange();
        boolean boolean9 = numberAxis3D0.isPositiveArrowVisible();
        org.junit.Assert.assertNull(markerAxisBand7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer5 = null;
        org.jfree.chart.text.TextBlock textBlock6 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint2, (float) (-1), 0, textMeasurer5);
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine();
        textBlock6.addLine(textLine7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor12 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.block.BlockContainer blockContainer13 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.util.Size2D size2D15 = blockContainer13.arrange(graphics2D14);
        boolean boolean16 = textBlockAnchor12.equals((java.lang.Object) blockContainer13);
        textBlock6.draw(graphics2D9, (float) 100, (float) 200, textBlockAnchor12);
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.Font font22 = null;
        java.awt.Font font24 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint25 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer28 = null;
        org.jfree.chart.text.TextBlock textBlock29 = org.jfree.chart.text.TextUtilities.createTextBlock("", font24, paint25, (float) (-1), 0, textMeasurer28);
        java.awt.Graphics2D graphics2D32 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer33 = new org.jfree.chart.text.G2TextMeasurer(graphics2D32);
        org.jfree.chart.text.TextBlock textBlock34 = org.jfree.chart.text.TextUtilities.createTextBlock("", font22, paint25, (float) (short) 100, (int) '4', (org.jfree.chart.text.TextMeasurer) g2TextMeasurer33);
        java.awt.Graphics2D graphics2D35 = null;
        java.awt.Font font39 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint40 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer43 = null;
        org.jfree.chart.text.TextBlock textBlock44 = org.jfree.chart.text.TextUtilities.createTextBlock("", font39, paint40, (float) (-1), 0, textMeasurer43);
        java.awt.Graphics2D graphics2D45 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor48 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        java.awt.Shape shape52 = textBlock44.calculateBounds(graphics2D45, 0.0f, (float) 255, textBlockAnchor48, (float) (short) 0, (float) (byte) -1, (double) (short) 1);
        textBlock34.draw(graphics2D35, (float) (short) 1, (float) (byte) 0, textBlockAnchor48);
        textBlock6.draw(graphics2D18, (float) (-1), (float) 10L, textBlockAnchor48, (float) 3, (float) 100, (double) 64);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(textBlock6);
        org.junit.Assert.assertNotNull(textBlockAnchor12);
        org.junit.Assert.assertNotNull(size2D15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(textBlock29);
        org.junit.Assert.assertNotNull(textBlock34);
        org.junit.Assert.assertNotNull(font39);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(textBlock44);
        org.junit.Assert.assertNotNull(textBlockAnchor48);
        org.junit.Assert.assertNotNull(shape52);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { (-1.0f), 192 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { (-1.0f), 192 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (-1.0f), 192 };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { (-1.0f), 192 };
        java.lang.Number[][] numberArray14 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10, numberArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "TextAnchor.BASELINE_CENTER", numberArray14);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getDomainAxisEdge((int) (byte) 1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryPlot0.getAxisOffset();
        boolean boolean4 = categoryPlot0.isRangeCrosshairVisible();
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot0.setRangeGridlineStroke(stroke5);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = categoryPlot0.getLegendItems();
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(legendItemCollection7);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_YELLOW;
        int int5 = color4.getBlue();
        java.awt.image.ColorModel colorModel6 = null;
        java.awt.Rectangle rectangle7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        java.awt.geom.AffineTransform affineTransform9 = null;
        java.awt.RenderingHints renderingHints10 = null;
        java.awt.PaintContext paintContext11 = color4.createContext(colorModel6, rectangle7, rectangle2D8, affineTransform9, renderingHints10);
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder((double) (-1.0f), 100.0d, 0.025d, 0.05d, (java.awt.Paint) color4);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(paintContext11);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.chart.PaintMap paintMap0 = new org.jfree.chart.PaintMap();
        java.awt.Color color2 = java.awt.Color.blue;
        paintMap0.put((java.lang.Comparable) 0.025d, (java.awt.Paint) color2);
        java.lang.Comparable comparable4 = null;
        try {
            java.awt.Paint paint5 = paintMap0.getPaint(comparable4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getDomainAxisEdge((int) (byte) 1);
        java.awt.Paint paint4 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker(35.0d, paint4, stroke5);
        float float7 = valueMarker6.getAlpha();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType8 = valueMarker6.getLabelOffsetType();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType9 = valueMarker6.getLabelOffsetType();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = valueMarker6.getLabelOffset();
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker6);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent12 = null;
        categoryPlot0.axisChanged(axisChangeEvent12);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder14 = null;
        try {
            categoryPlot0.setDatasetRenderingOrder(datasetRenderingOrder14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
        org.junit.Assert.assertNotNull(lengthAdjustmentType8);
        org.junit.Assert.assertNotNull(lengthAdjustmentType9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D1.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D1.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, polarItemRenderer6);
        boolean boolean8 = numberAxis3D1.getAutoRangeStickyZero();
        org.jfree.data.Range range9 = numberAxis3D1.getRange();
        double double10 = range9.getCentralValue();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.5d + "'", double10 == 0.5d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        java.awt.Paint paint1 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker(35.0d, paint1, stroke2);
        java.awt.Font font4 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        boolean boolean5 = valueMarker3.equals((java.lang.Object) font4);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot6.getDomainAxisEdge((int) (byte) 1);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryPlot6.getAxisOffset();
        boolean boolean10 = categoryPlot6.isRangeCrosshairVisible();
        java.awt.Stroke stroke11 = categoryPlot6.getRangeGridlineStroke();
        valueMarker3.setOutlineStroke(stroke11);
        java.lang.Class class13 = null;
        try {
            java.util.EventListener[] eventListenerArray14 = valueMarker3.getListeners(class13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        java.awt.Paint paint1 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker(35.0d, paint1, stroke2);
        float float4 = valueMarker3.getAlpha();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType5 = valueMarker3.getLabelOffsetType();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType6 = valueMarker3.getLabelOffsetType();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = valueMarker3.getLabelOffset();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = valueMarker3.getLabelAnchor();
        valueMarker3.setValue(0.5d);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(lengthAdjustmentType5);
        org.junit.Assert.assertNotNull(lengthAdjustmentType6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getCategoryMargin();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor2 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = org.jfree.chart.util.RectangleEdge.TOP;
        java.lang.String str7 = rectangleEdge6.toString();
        double double8 = categoryAxis0.getCategoryJava2DCoordinate(categoryAnchor2, (int) 'a', 1, rectangle2D5, rectangleEdge6);
        categoryAxis0.setCategoryMargin((double) ' ');
        java.lang.Comparable comparable11 = null;
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        piePlot13.setSectionOutlinesVisible(true);
        java.awt.Paint paint16 = piePlot13.getBackgroundPaint();
        java.awt.Paint paint18 = piePlot13.getSectionOutlinePaint((java.lang.Comparable) 100.0f);
        java.awt.Stroke stroke19 = piePlot13.getLabelLinkStroke();
        java.awt.Stroke stroke21 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        piePlot13.setSectionOutlineStroke((java.lang.Comparable) (byte) 100, stroke21);
        piePlot13.setSectionOutlinesVisible(false);
        java.awt.Color color26 = java.awt.Color.pink;
        piePlot13.setSectionPaint((java.lang.Comparable) 255, (java.awt.Paint) color26);
        try {
            categoryAxis0.setTickLabelPaint(comparable11, (java.awt.Paint) color26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "RectangleEdge.TOP" + "'", str7.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(color26);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit(1.0d);
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot0);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer();
        blockContainer5.setWidth((double) 10.0f);
        org.jfree.chart.block.BlockBorder blockBorder8 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = blockBorder8.getInsets();
        blockContainer5.setMargin(rectangleInsets9);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = rectangleConstraint12.toFixedWidth((double) 200);
        org.jfree.chart.util.Size2D size2D15 = blockContainer5.arrange(graphics2D11, rectangleConstraint14);
        org.jfree.chart.util.Size2D size2D16 = legendTitle3.arrange(graphics2D4, rectangleConstraint14);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = legendTitle3.getLegendItemGraphicEdge();
        org.junit.Assert.assertNotNull(blockBorder8);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(rectangleConstraint12);
        org.junit.Assert.assertNotNull(rectangleConstraint14);
        org.junit.Assert.assertNotNull(size2D15);
        org.junit.Assert.assertNotNull(size2D16);
        org.junit.Assert.assertNotNull(rectangleEdge17);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer5 = null;
        org.jfree.chart.text.TextBlock textBlock6 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint2, (float) (-1), 0, textMeasurer5);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment7 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        java.lang.String str8 = horizontalAlignment7.toString();
        textBlock6.setLineAlignment(horizontalAlignment7);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(textBlock6);
        org.junit.Assert.assertNotNull(horizontalAlignment7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "HorizontalAlignment.RIGHT" + "'", str8.equals("HorizontalAlignment.RIGHT"));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.Timeline timeline2 = dateAxis1.getTimeline();
        boolean boolean4 = dateAxis1.isHiddenValue((long) (byte) 1);
        org.jfree.chart.axis.Timeline timeline5 = dateAxis1.getTimeline();
        java.text.DateFormat dateFormat6 = null;
        dateAxis1.setDateFormatOverride(dateFormat6);
        org.junit.Assert.assertNotNull(timeline2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeline5);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge((int) (short) 0);
        boolean boolean4 = categoryPlot0.isRangeGridlinesVisible();
        categoryPlot0.setRangeCrosshairValue(2.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        blockContainer0.setWidth((double) 10.0f);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = rectangleConstraint4.toFixedWidth((double) 200);
        org.jfree.chart.util.Size2D size2D7 = blockContainer0.arrange(graphics2D3, rectangleConstraint6);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.data.Range range9 = null;
        org.jfree.data.Range range11 = org.jfree.data.Range.expandToInclude(range9, (-1.0d));
        boolean boolean13 = range11.contains((double) 1);
        org.jfree.data.Range range16 = org.jfree.data.Range.shift(range11, (double) 100, false);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint17 = rectangleConstraint8.toRangeHeight(range11);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = rectangleConstraint6.toRangeHeight(range11);
        org.jfree.data.Range range19 = rectangleConstraint6.getWidthRange();
        double double20 = rectangleConstraint6.getWidth();
        org.junit.Assert.assertNotNull(rectangleConstraint4);
        org.junit.Assert.assertNotNull(rectangleConstraint6);
        org.junit.Assert.assertNotNull(size2D7);
        org.junit.Assert.assertNotNull(rectangleConstraint8);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(rectangleConstraint17);
        org.junit.Assert.assertNotNull(rectangleConstraint18);
        org.junit.Assert.assertNull(range19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 200.0d + "'", double20 == 200.0d);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setBackgroundAlpha((float) (-1));
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint7 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer10 = null;
        org.jfree.chart.text.TextBlock textBlock11 = org.jfree.chart.text.TextUtilities.createTextBlock("", font6, paint7, (float) (-1), 0, textMeasurer10);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot12 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener13 = null;
        multiplePiePlot12.removeChangeListener(plotChangeListener13);
        org.jfree.chart.plot.Plot plot15 = multiplePiePlot12.getParent();
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("ThreadContext", font6, (org.jfree.chart.plot.Plot) multiplePiePlot12, false);
        java.util.List list18 = jFreeChart17.getSubtitles();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo21 = null;
        java.awt.image.BufferedImage bufferedImage22 = jFreeChart17.createBufferedImage((int) '4', (int) '4', chartRenderingInfo21);
        piePlot1.setBackgroundImage((java.awt.Image) bufferedImage22);
        org.jfree.chart.util.Rotation rotation24 = org.jfree.chart.util.Rotation.CLOCKWISE;
        piePlot1.setDirection(rotation24);
        double double26 = rotation24.getFactor();
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textBlock11);
        org.junit.Assert.assertNull(plot15);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertNotNull(bufferedImage22);
        org.junit.Assert.assertNotNull(rotation24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + (-1.0d) + "'", double26 == (-1.0d));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLowerMargin((double) (short) 100);
        org.jfree.chart.block.BlockBorder blockBorder5 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = blockBorder5.getInsets();
        double double8 = rectangleInsets6.trimWidth((double) (byte) 10);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D9 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D9.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D9.setAutoRangeStickyZero(false);
        numberAxis3D9.setUpperBound(100.0d);
        float float16 = numberAxis3D9.getTickMarkOutsideLength();
        org.jfree.chart.block.BlockContainer blockContainer17 = new org.jfree.chart.block.BlockContainer();
        blockContainer17.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D20 = blockContainer17.getBounds();
        numberAxis3D9.setLeftArrow((java.awt.Shape) rectangle2D20);
        org.jfree.chart.entity.ChartEntity chartEntity23 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D20, "");
        java.awt.geom.Rectangle2D rectangle2D24 = rectangleInsets6.createOutsetRectangle(rectangle2D20);
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis();
        double double26 = categoryAxis25.getCategoryMargin();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor27 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = org.jfree.chart.util.RectangleEdge.TOP;
        java.lang.String str32 = rectangleEdge31.toString();
        double double33 = categoryAxis25.getCategoryJava2DCoordinate(categoryAnchor27, (int) 'a', 1, rectangle2D30, rectangleEdge31);
        double double34 = categoryAxis0.getCategoryEnd((-1), (int) '4', rectangle2D20, rectangleEdge31);
        categoryAxis0.setVisible(false);
        java.awt.Paint paint38 = categoryAxis0.getTickLabelPaint((java.lang.Comparable) "Size2D[width=0.0, height=100.0]");
        org.junit.Assert.assertNotNull(blockBorder5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 10.0d + "'", double8 == 10.0d);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 1.0f + "'", float16 == 1.0f);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.2d + "'", double26 == 0.2d);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "RectangleEdge.TOP" + "'", str32.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(paint38);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = org.jfree.chart.util.VerticalAlignment.CENTER;
        java.awt.Paint paint3 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        boolean boolean4 = verticalAlignment2.equals((java.lang.Object) paint3);
        org.jfree.chart.block.ColumnArrangement columnArrangement7 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment1, verticalAlignment2, (double) (byte) 1, (double) (byte) -1);
        boolean boolean8 = piePlot3D0.equals((java.lang.Object) (byte) 1);
        java.awt.Paint paint9 = piePlot3D0.getLabelOutlinePaint();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor10 = piePlot3D0.getLabelDistributor();
        try {
            org.jfree.chart.plot.PieLabelRecord pieLabelRecord12 = abstractPieLabelDistributor10.getPieLabelRecord(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor10);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit(1.0d);
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot0);
        multiplePiePlot0.setAggregatedItemsKey((java.lang.Comparable) 1.0E-8d);
        java.awt.Color color6 = java.awt.Color.red;
        multiplePiePlot0.setNoDataMessagePaint((java.awt.Paint) color6);
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        java.awt.Paint paint1 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker(35.0d, paint1, stroke2);
        float float4 = valueMarker3.getAlpha();
        java.awt.Paint paint5 = valueMarker3.getPaint();
        org.jfree.chart.text.TextAnchor textAnchor6 = valueMarker3.getLabelTextAnchor();
        org.jfree.chart.text.TextAnchor textAnchor7 = null;
        try {
            valueMarker3.setLabelTextAnchor(textAnchor7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'anchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("0,0,1,1");
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name , locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getDomainAxisEdge((int) (byte) 1);
        org.jfree.chart.axis.AxisLocation axisLocation4 = categoryPlot0.getDomainAxisLocation(200);
        java.awt.Font font6 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color7 = java.awt.Color.PINK;
        org.jfree.chart.text.TextFragment textFragment9 = new org.jfree.chart.text.TextFragment("", font6, (java.awt.Paint) color7, (float) 1L);
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color7);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D14.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D14.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer19 = null;
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, polarItemRenderer19);
        double double21 = polarPlot20.getMaxRadius();
        org.jfree.chart.block.BlockContainer blockContainer24 = new org.jfree.chart.block.BlockContainer();
        blockContainer24.setWidth((double) 10.0f);
        org.jfree.chart.block.BlockBorder blockBorder27 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = blockBorder27.getInsets();
        blockContainer24.setMargin(rectangleInsets28);
        java.awt.Graphics2D graphics2D30 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint31 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint33 = rectangleConstraint31.toFixedWidth((double) 200);
        org.jfree.chart.util.Size2D size2D34 = blockContainer24.arrange(graphics2D30, rectangleConstraint33);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot35 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot35.setLimit(1.0d);
        org.jfree.chart.title.LegendTitle legendTitle38 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot35);
        org.jfree.chart.util.VerticalAlignment verticalAlignment39 = legendTitle38.getVerticalAlignment();
        java.awt.Graphics2D graphics2D40 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint41 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint43 = rectangleConstraint41.toFixedWidth((double) 200);
        org.jfree.chart.util.Size2D size2D44 = legendTitle38.arrange(graphics2D40, rectangleConstraint43);
        size2D44.height = 100.0f;
        org.jfree.chart.util.Size2D size2D47 = rectangleConstraint33.calculateConstrainedSize(size2D44);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor50 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.lang.String str51 = rectangleAnchor50.toString();
        java.awt.geom.Rectangle2D rectangle2D52 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D44, 0.0d, 0.4d, rectangleAnchor50);
        java.awt.Point point53 = polarPlot20.translateValueThetaRadiusToJava2D((double) 1.0f, (double) (short) 10, rectangle2D52);
        categoryPlot0.zoomDomainAxes((double) 'a', plotRenderingInfo12, (java.awt.geom.Point2D) point53);
        categoryPlot0.mapDatasetToRangeAxis(255, (int) (byte) 1);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.05d + "'", double21 == 1.05d);
        org.junit.Assert.assertNotNull(blockBorder27);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(rectangleConstraint31);
        org.junit.Assert.assertNotNull(rectangleConstraint33);
        org.junit.Assert.assertNotNull(size2D34);
        org.junit.Assert.assertNotNull(verticalAlignment39);
        org.junit.Assert.assertNotNull(rectangleConstraint41);
        org.junit.Assert.assertNotNull(rectangleConstraint43);
        org.junit.Assert.assertNotNull(size2D44);
        org.junit.Assert.assertNotNull(size2D47);
        org.junit.Assert.assertNotNull(rectangleAnchor50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "RectangleAnchor.LEFT" + "'", str51.equals("RectangleAnchor.LEFT"));
        org.junit.Assert.assertNotNull(rectangle2D52);
        org.junit.Assert.assertNotNull(point53);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D1.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D1.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, polarItemRenderer6);
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = polarPlot7.getOrientation();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = polarPlot7.getRenderer();
        boolean boolean10 = polarPlot7.isRangeZoomable();
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        piePlot14.setSectionOutlinesVisible(true);
        java.awt.Paint paint17 = piePlot14.getBackgroundPaint();
        java.awt.Color color19 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.image.ColorModel colorModel20 = null;
        java.awt.Rectangle rectangle21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        java.awt.geom.AffineTransform affineTransform23 = null;
        java.awt.RenderingHints renderingHints24 = null;
        java.awt.PaintContext paintContext25 = color19.createContext(colorModel20, rectangle21, rectangle2D22, affineTransform23, renderingHints24);
        piePlot14.setSectionPaint((java.lang.Comparable) (byte) 100, (java.awt.Paint) color19);
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor28 = null;
        org.jfree.chart.block.BlockContainer blockContainer31 = new org.jfree.chart.block.BlockContainer();
        blockContainer31.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D34 = blockContainer31.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double36 = categoryAxis27.getCategoryJava2DCoordinate(categoryAnchor28, (int) (byte) 10, 0, rectangle2D34, rectangleEdge35);
        piePlot14.setLegendItemShape((java.awt.Shape) rectangle2D34);
        java.awt.Point point38 = polarPlot7.translateValueThetaRadiusToJava2D((double) (short) 0, 9.223372036854776E18d, rectangle2D34);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D39 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D39.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D39.setAutoRangeStickyZero(false);
        numberAxis3D39.setLabel("ThreadContext");
        numberAxis3D39.setRange((double) 3, 10.0d);
        java.awt.Font font49 = numberAxis3D39.getLabelFont();
        polarPlot7.setAngleLabelFont(font49);
        org.jfree.chart.title.LegendTitle legendTitle51 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot7);
        java.awt.Paint paint52 = polarPlot7.getAngleGridlinePaint();
        java.awt.Paint paint53 = null;
        polarPlot7.setAngleGridlinePaint(paint53);
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertNull(polarItemRenderer9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(paintContext25);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNotNull(rectangleEdge35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(point38);
        org.junit.Assert.assertNotNull(font49);
        org.junit.Assert.assertNotNull(paint52);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor(2);
        pieLabelDistributor1.distributeLabels((double) (short) 10, (double) 2);
        java.lang.String str5 = pieLabelDistributor1.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        java.awt.Paint paint1 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker(35.0d, paint1, stroke2);
        float float4 = valueMarker3.getAlpha();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType5 = valueMarker3.getLabelOffsetType();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType6 = valueMarker3.getLabelOffsetType();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = valueMarker3.getLabelOffset();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = valueMarker3.getLabelAnchor();
        float float9 = valueMarker3.getAlpha();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(lengthAdjustmentType5);
        org.junit.Assert.assertNotNull(lengthAdjustmentType6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1.0f + "'", float9 == 1.0f);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D1.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D1.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, polarItemRenderer6);
        double double8 = polarPlot7.getMaxRadius();
        org.jfree.chart.LegendItemCollection legendItemCollection9 = polarPlot7.getLegendItems();
        org.jfree.data.xy.XYDataset xYDataset10 = polarPlot7.getDataset();
        polarPlot7.removeCornerTextItem("ChartChangeEventType.DATASET_UPDATED");
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.05d + "'", double8 == 1.05d);
        org.junit.Assert.assertNotNull(legendItemCollection9);
        org.junit.Assert.assertNull(xYDataset10);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D1.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D1.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, polarItemRenderer6);
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = polarPlot7.getOrientation();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = polarPlot7.getRenderer();
        boolean boolean10 = polarPlot7.isRangeZoomable();
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        piePlot14.setSectionOutlinesVisible(true);
        java.awt.Paint paint17 = piePlot14.getBackgroundPaint();
        java.awt.Color color19 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.image.ColorModel colorModel20 = null;
        java.awt.Rectangle rectangle21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        java.awt.geom.AffineTransform affineTransform23 = null;
        java.awt.RenderingHints renderingHints24 = null;
        java.awt.PaintContext paintContext25 = color19.createContext(colorModel20, rectangle21, rectangle2D22, affineTransform23, renderingHints24);
        piePlot14.setSectionPaint((java.lang.Comparable) (byte) 100, (java.awt.Paint) color19);
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor28 = null;
        org.jfree.chart.block.BlockContainer blockContainer31 = new org.jfree.chart.block.BlockContainer();
        blockContainer31.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D34 = blockContainer31.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double36 = categoryAxis27.getCategoryJava2DCoordinate(categoryAnchor28, (int) (byte) 10, 0, rectangle2D34, rectangleEdge35);
        piePlot14.setLegendItemShape((java.awt.Shape) rectangle2D34);
        java.awt.Point point38 = polarPlot7.translateValueThetaRadiusToJava2D((double) (short) 0, 9.223372036854776E18d, rectangle2D34);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D39 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D39.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D39.setAutoRangeStickyZero(false);
        numberAxis3D39.setLabel("ThreadContext");
        numberAxis3D39.setRange((double) 3, 10.0d);
        java.awt.Font font49 = numberAxis3D39.getLabelFont();
        polarPlot7.setAngleLabelFont(font49);
        org.jfree.chart.title.LegendTitle legendTitle51 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot7);
        java.awt.Paint paint52 = polarPlot7.getAngleGridlinePaint();
        boolean boolean53 = polarPlot7.isAngleLabelsVisible();
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertNull(polarItemRenderer9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(paintContext25);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNotNull(rectangleEdge35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(point38);
        org.junit.Assert.assertNotNull(font49);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.08d + "'", double0 == 0.08d);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        java.awt.Font font2 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer6 = null;
        org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, paint3, (float) (-1), 0, textMeasurer6);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        multiplePiePlot8.removeChangeListener(plotChangeListener9);
        org.jfree.chart.plot.Plot plot11 = multiplePiePlot8.getParent();
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("ThreadContext", font2, (org.jfree.chart.plot.Plot) multiplePiePlot8, false);
        java.util.List list14 = jFreeChart13.getSubtitles();
        org.jfree.chart.block.BlockContainer blockContainer15 = new org.jfree.chart.block.BlockContainer();
        blockContainer15.setWidth((double) 10.0f);
        org.jfree.chart.block.BlockBorder blockBorder18 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = blockBorder18.getInsets();
        blockContainer15.setMargin(rectangleInsets19);
        boolean boolean21 = jFreeChart13.equals((java.lang.Object) rectangleInsets19);
        java.awt.Paint paint22 = jFreeChart13.getBackgroundPaint();
        int int23 = jFreeChart13.getBackgroundImageAlignment();
        org.jfree.chart.title.TextTitle textTitle24 = jFreeChart13.getTitle();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(textBlock7);
        org.junit.Assert.assertNull(plot11);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(blockBorder18);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 15 + "'", int23 == 15);
        org.junit.Assert.assertNotNull(textTitle24);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("ThreadContext");
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.lang.Object obj2 = null;
        boolean boolean3 = dateAxis1.equals(obj2);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D5.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D5.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot(xYDataset4, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, polarItemRenderer10);
        org.jfree.data.Range range12 = null;
        org.jfree.data.Range range14 = org.jfree.data.Range.expandToInclude(range12, (-1.0d));
        numberAxis3D5.setRangeWithMargins(range14);
        dateAxis1.setRange(range14, true, false);
        boolean boolean20 = dateAxis1.isHiddenValue((long) (-237));
        java.util.TimeZone timeZone21 = dateAxis1.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.Timeline timeline24 = dateAxis23.getTimeline();
        boolean boolean26 = dateAxis23.isHiddenValue((long) (byte) 1);
        org.jfree.chart.axis.Timeline timeline27 = dateAxis23.getTimeline();
        java.util.Date date28 = dateAxis23.getMaximumDate();
        dateAxis1.setMinimumDate(date28);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint30 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.data.Range range31 = null;
        org.jfree.data.Range range33 = org.jfree.data.Range.expandToInclude(range31, (-1.0d));
        boolean boolean35 = range33.contains((double) 1);
        org.jfree.data.Range range38 = org.jfree.data.Range.shift(range33, (double) 100, false);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint39 = rectangleConstraint30.toRangeHeight(range33);
        boolean boolean42 = range33.intersects((double) 255, (double) 200);
        dateAxis1.setRange(range33);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNotNull(timeline24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(timeline27);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(rectangleConstraint30);
        org.junit.Assert.assertNotNull(range33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNotNull(rectangleConstraint39);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.data.general.WaferMapDataset waferMapDataset1 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer2 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot3 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset1, waferMapRenderer2);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) waferMapPlot3);
        float float5 = waferMapPlot3.getBackgroundAlpha();
        java.awt.Paint paint6 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        waferMapPlot3.setBackgroundPaint(paint6);
        java.lang.Class<?> wildcardClass8 = waferMapPlot3.getClass();
        java.net.URL uRL9 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("RectangleAnchor.BOTTOM_LEFT", (java.lang.Class) wildcardClass8);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 1.0f + "'", float5 == 1.0f);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNull(uRL9);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxisForDataset((int) (byte) 10);
        categoryPlot0.setRangeCrosshairVisible(false);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNull(categoryAxis5);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        java.awt.Font font2 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer6 = null;
        org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, paint3, (float) (-1), 0, textMeasurer6);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        multiplePiePlot8.removeChangeListener(plotChangeListener9);
        org.jfree.chart.plot.Plot plot11 = multiplePiePlot8.getParent();
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("ThreadContext", font2, (org.jfree.chart.plot.Plot) multiplePiePlot8, false);
        java.util.List list14 = jFreeChart13.getSubtitles();
        org.jfree.chart.block.BlockContainer blockContainer15 = new org.jfree.chart.block.BlockContainer();
        blockContainer15.setWidth((double) 10.0f);
        org.jfree.chart.block.BlockBorder blockBorder18 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = blockBorder18.getInsets();
        blockContainer15.setMargin(rectangleInsets19);
        boolean boolean21 = jFreeChart13.equals((java.lang.Object) rectangleInsets19);
        java.awt.Paint paint22 = jFreeChart13.getBackgroundPaint();
        org.jfree.chart.event.ChartProgressListener chartProgressListener23 = null;
        jFreeChart13.removeProgressListener(chartProgressListener23);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot26 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot26.setLimit(1.0d);
        org.jfree.chart.title.LegendTitle legendTitle29 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot26);
        java.awt.geom.Rectangle2D rectangle2D30 = legendTitle29.getBounds();
        try {
            jFreeChart13.addSubtitle((int) (short) 10, (org.jfree.chart.title.Title) legendTitle29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'index' argument is out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(textBlock7);
        org.junit.Assert.assertNull(plot11);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(blockBorder18);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(rectangle2D30);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        java.awt.Color color0 = java.awt.Color.CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.UnitType unitType1 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = new org.jfree.chart.util.RectangleInsets(unitType1, (double) (short) 100, (double) (byte) 0, (double) 0.0f, (double) '#');
        org.jfree.chart.JFreeChart jFreeChart7 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType8 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        java.lang.String str9 = chartChangeEventType8.toString();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (short) 100, jFreeChart7, chartChangeEventType8);
        boolean boolean11 = plotOrientation0.equals((java.lang.Object) chartChangeEventType8);
        java.lang.String str12 = plotOrientation0.toString();
        java.lang.String str13 = plotOrientation0.toString();
        org.junit.Assert.assertNotNull(plotOrientation0);
        org.junit.Assert.assertNotNull(unitType1);
        org.junit.Assert.assertNotNull(chartChangeEventType8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str9.equals("ChartChangeEventType.DATASET_UPDATED"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "PlotOrientation.VERTICAL" + "'", str12.equals("PlotOrientation.VERTICAL"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "PlotOrientation.VERTICAL" + "'", str13.equals("PlotOrientation.VERTICAL"));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        java.awt.Paint paint2 = ringPlot1.getSeparatorPaint();
        double double3 = ringPlot1.getMaximumExplodePercent();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        piePlot6.setSectionOutlinesVisible(true);
        java.awt.Paint paint9 = piePlot6.getBackgroundPaint();
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.image.ColorModel colorModel12 = null;
        java.awt.Rectangle rectangle13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.awt.geom.AffineTransform affineTransform15 = null;
        java.awt.RenderingHints renderingHints16 = null;
        java.awt.PaintContext paintContext17 = color11.createContext(colorModel12, rectangle13, rectangle2D14, affineTransform15, renderingHints16);
        piePlot6.setSectionPaint((java.lang.Comparable) (byte) 100, (java.awt.Paint) color11);
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor20 = null;
        org.jfree.chart.block.BlockContainer blockContainer23 = new org.jfree.chart.block.BlockContainer();
        blockContainer23.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D26 = blockContainer23.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double28 = categoryAxis19.getCategoryJava2DCoordinate(categoryAnchor20, (int) (byte) 10, 0, rectangle2D26, rectangleEdge27);
        piePlot6.setLegendItemShape((java.awt.Shape) rectangle2D26);
        org.jfree.chart.plot.PiePlot3D piePlot3D30 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D30.setBackgroundImageAlignment(1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        org.jfree.chart.plot.PiePlotState piePlotState35 = ringPlot1.initialise(graphics2D4, rectangle2D26, (org.jfree.chart.plot.PiePlot) piePlot3D30, (java.lang.Integer) 100, plotRenderingInfo34);
        ringPlot1.setSeparatorsVisible(true);
        double double38 = ringPlot1.getShadowYOffset();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(paintContext17);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(piePlotState35);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 4.0d + "'", double38 == 4.0d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (short) 100, (double) (byte) 0, (double) 0.0f, (double) '#');
        double double7 = rectangleInsets5.calculateBottomOutset((double) 1L);
        double double9 = rectangleInsets5.calculateBottomOutset(0.0d);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextLine textLine1 = null;
        textBlock0.addLine(textLine1);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = textBlock0.getLineAlignment();
        try {
            java.lang.Object obj4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) horizontalAlignment3);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment3);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getDomainAxisEdge((int) (byte) 1);
        org.jfree.chart.axis.AxisLocation axisLocation4 = categoryPlot0.getDomainAxisLocation(200);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis();
        org.jfree.chart.axis.ValueAxis valueAxis7 = categoryPlot0.getRangeAxisForDataset(10);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        double double9 = categoryAxis8.getCategoryMargin();
        categoryAxis8.addCategoryLabelToolTip((java.lang.Comparable) 100, "TextAnchor.CENTER_RIGHT");
        java.lang.Object obj13 = categoryAxis8.clone();
        categoryAxis8.clearCategoryLabelToolTips();
        org.jfree.chart.block.BlockBorder blockBorder15 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = blockBorder15.getInsets();
        org.jfree.chart.block.BlockContainer blockContainer17 = new org.jfree.chart.block.BlockContainer();
        blockContainer17.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D20 = blockContainer17.getBounds();
        rectangleInsets16.trim(rectangle2D20);
        categoryAxis8.setLabelInsets(rectangleInsets16);
        categoryPlot0.setDomainAxis(categoryAxis8);
        org.jfree.chart.util.Layer layer25 = null;
        java.util.Collection collection26 = categoryPlot0.getDomainMarkers((int) ' ', layer25);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.2d + "'", double9 == 0.2d);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(blockBorder15);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNull(collection26);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("Polar Plot", graphics2D1, 0.0f, (float) 1, (double) 0, (float) '#', (-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getDomainAxisEdge((int) (byte) 1);
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxisForDataset((int) (short) 1);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNull(categoryAxis5);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("{0}");
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        textTitle1.setBackgroundPaint((java.awt.Paint) color2);
        java.awt.Font font4 = textTitle1.getFont();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(font4);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        boolean boolean1 = numberAxis3D0.isAutoTickUnitSelection();
        boolean boolean2 = numberAxis3D0.isVerticalTickLabels();
        numberAxis3D0.resizeRange(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = numberAxis3D0.getLabelInsets();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(rectangleInsets5);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        java.awt.Font font5 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint6 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer9 = null;
        org.jfree.chart.text.TextBlock textBlock10 = org.jfree.chart.text.TextUtilities.createTextBlock("", font5, paint6, (float) (-1), 0, textMeasurer9);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener12 = null;
        multiplePiePlot11.removeChangeListener(plotChangeListener12);
        org.jfree.chart.plot.Plot plot14 = multiplePiePlot11.getParent();
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart("ThreadContext", font5, (org.jfree.chart.plot.Plot) multiplePiePlot11, false);
        java.util.List list17 = jFreeChart16.getSubtitles();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = null;
        java.awt.image.BufferedImage bufferedImage21 = jFreeChart16.createBufferedImage((int) '4', (int) '4', chartRenderingInfo20);
        org.jfree.chart.ui.ProjectInfo projectInfo25 = new org.jfree.chart.ui.ProjectInfo("hi!", "Polar Plot", "ThreadContext", (java.awt.Image) bufferedImage21, "0,0,1,1", "ChartChangeEventType.DATASET_UPDATED", "RectangleEdge.TOP");
        java.lang.String str26 = projectInfo25.getName();
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(textBlock10);
        org.junit.Assert.assertNull(plot14);
        org.junit.Assert.assertNotNull(list17);
        org.junit.Assert.assertNotNull(bufferedImage21);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "hi!" + "'", str26.equals("hi!"));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setSectionOutlinesVisible(true);
        java.awt.Paint paint4 = piePlot1.getBackgroundPaint();
        java.awt.Paint paint6 = piePlot1.getSectionOutlinePaint((java.lang.Comparable) 100.0f);
        piePlot1.setCircular(true, false);
        double double10 = piePlot1.getLabelGap();
        java.awt.Shape shape11 = piePlot1.getLegendItemShape();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.RingPlot ringPlot13 = new org.jfree.chart.plot.RingPlot(pieDataset12);
        java.awt.Paint paint14 = ringPlot13.getSeparatorPaint();
        piePlot1.setLabelBackgroundPaint(paint14);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier16 = piePlot1.getDrawingSupplier();
        java.lang.Object obj17 = piePlot1.clone();
        double double18 = piePlot1.getStartAngle();
        java.awt.Stroke stroke19 = piePlot1.getLabelLinkStroke();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.025d + "'", double10 == 0.025d);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(drawingSupplier16);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 90.0d + "'", double18 == 90.0d);
        org.junit.Assert.assertNotNull(stroke19);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextAnchor.BOTTOM_CENTER");
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D1.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D1.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, polarItemRenderer6);
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = polarPlot7.getOrientation();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = polarPlot7.getRenderer();
        java.awt.Stroke stroke10 = polarPlot7.getRadiusGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset11 = polarPlot7.getDataset();
        boolean boolean12 = polarPlot7.isRangeZoomable();
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertNull(polarItemRenderer9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNull(xYDataset11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge((int) (short) 0);
        boolean boolean4 = categoryPlot0.isRangeGridlinesVisible();
        java.awt.Paint paint7 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker(35.0d, paint7, stroke8);
        float float10 = valueMarker9.getAlpha();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType11 = valueMarker9.getLabelOffsetType();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType12 = valueMarker9.getLabelOffsetType();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = valueMarker9.getLabelOffset();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = valueMarker9.getLabelAnchor();
        org.jfree.chart.util.Layer layer15 = null;
        try {
            boolean boolean16 = categoryPlot0.removeDomainMarker((int) ' ', (org.jfree.chart.plot.Marker) valueMarker9, layer15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 1.0f + "'", float10 == 1.0f);
        org.junit.Assert.assertNotNull(lengthAdjustmentType11);
        org.junit.Assert.assertNotNull(lengthAdjustmentType12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(rectangleAnchor14);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.Library[] libraryArray1 = projectInfo0.getLibraries();
        projectInfo0.setName("");
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(libraryArray1);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.data.Range range1 = null;
        org.jfree.data.Range range3 = org.jfree.data.Range.expandToInclude(range1, (-1.0d));
        boolean boolean5 = range3.contains((double) 1);
        org.jfree.data.Range range8 = org.jfree.data.Range.shift(range3, (double) 100, false);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = rectangleConstraint0.toRangeHeight(range3);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = rectangleConstraint0.toFixedWidth((double) (short) -1);
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(rectangleConstraint9);
        org.junit.Assert.assertNotNull(rectangleConstraint11);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        java.awt.Paint paint1 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker(35.0d, paint1, stroke2);
        float float4 = valueMarker3.getAlpha();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType5 = valueMarker3.getLabelOffsetType();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType6 = valueMarker3.getLabelOffsetType();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = valueMarker3.getLabelOffset();
        java.awt.Paint paint8 = valueMarker3.getPaint();
        java.awt.Paint paint9 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        valueMarker3.setPaint(paint9);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(lengthAdjustmentType5);
        org.junit.Assert.assertNotNull(lengthAdjustmentType6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.chart.PaintMap paintMap0 = new org.jfree.chart.PaintMap();
        boolean boolean2 = paintMap0.containsKey((java.lang.Comparable) 1.0E-5d);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D4.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D4.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, polarItemRenderer9);
        numberAxis3D4.zoomRange((double) (-1), (double) 100.0f);
        double double14 = numberAxis3D4.getLowerBound();
        numberAxis3D4.setPositiveArrowVisible(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit17 = numberAxis3D4.getTickUnit();
        java.awt.Color color18 = java.awt.Color.blue;
        paintMap0.put((java.lang.Comparable) numberTickUnit17, (java.awt.Paint) color18);
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        java.awt.Color color21 = java.awt.Color.white;
        int int22 = color21.getTransparency();
        float[] floatArray29 = new float[] { (byte) 1, (-1L), '4', 100, 0L, ' ' };
        float[] floatArray30 = color21.getComponents(floatArray29);
        float[] floatArray31 = color20.getColorComponents(floatArray30);
        float[] floatArray32 = color18.getRGBComponents(floatArray30);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-1.1500000000000001d) + "'", double14 == (-1.1500000000000001d));
        org.junit.Assert.assertNotNull(numberTickUnit17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(floatArray29);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertNotNull(floatArray32);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge((int) (short) 0);
        boolean boolean4 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D6.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D6.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer11 = null;
        org.jfree.chart.plot.PolarPlot polarPlot12 = new org.jfree.chart.plot.PolarPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) numberAxis3D6, polarItemRenderer11);
        double double13 = polarPlot12.getMaxRadius();
        org.jfree.chart.LegendItemCollection legendItemCollection14 = polarPlot12.getLegendItems();
        categoryPlot0.setFixedLegendItems(legendItemCollection14);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.05d + "'", double13 == 1.05d);
        org.junit.Assert.assertNotNull(legendItemCollection14);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit(1.0d);
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot0);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = legendTitle3.getVerticalAlignment();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = rectangleConstraint6.toFixedWidth((double) 200);
        org.jfree.chart.util.Size2D size2D9 = legendTitle3.arrange(graphics2D5, rectangleConstraint8);
        java.awt.Paint paint10 = legendTitle3.getItemPaint();
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(rectangleConstraint6);
        org.junit.Assert.assertNotNull(rectangleConstraint8);
        org.junit.Assert.assertNotNull(size2D9);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (short) 100, (double) (byte) 0, (double) 0.0f, (double) '#');
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (-1L), 10.0d, (double) 0.0f, 0.0d);
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder(rectangleInsets10, (java.awt.Paint) color11);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D13 = new org.jfree.chart.axis.NumberAxis3D();
        boolean boolean14 = blockBorder12.equals((java.lang.Object) numberAxis3D13);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = null;
        try {
            numberAxis3D13.setLabelInsets(rectangleInsets15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getDomainAxisEdge((int) (byte) 1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryPlot0.getAxisOffset();
        boolean boolean4 = categoryPlot0.isRangeCrosshairVisible();
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot0.setRangeGridlineStroke(stroke5);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = categoryPlot8.getDomainAxisEdge((int) (byte) 1);
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot8.getDomainAxisLocation(200);
        org.jfree.chart.util.Layer layer13 = null;
        java.util.Collection collection14 = categoryPlot8.getDomainMarkers(layer13);
        org.jfree.chart.axis.AxisLocation axisLocation16 = categoryPlot8.getDomainAxisLocation((int) 'a');
        categoryPlot0.setDomainAxisLocation(100, axisLocation16, false);
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D20.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D20.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer25 = null;
        org.jfree.chart.plot.PolarPlot polarPlot26 = new org.jfree.chart.plot.PolarPlot(xYDataset19, (org.jfree.chart.axis.ValueAxis) numberAxis3D20, polarItemRenderer25);
        org.jfree.chart.plot.PlotOrientation plotOrientation27 = polarPlot26.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation16, plotOrientation27);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNull(collection14);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(plotOrientation27);
        org.junit.Assert.assertNotNull(rectangleEdge28);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        java.awt.Color color2 = java.awt.Color.getColor("Range[-1.0,-1.0]", (int) 'a');
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getDomainAxisEdge((int) (byte) 1);
        org.jfree.chart.axis.AxisLocation axisLocation4 = categoryPlot0.getDomainAxisLocation(200);
        org.jfree.chart.util.Layer layer5 = null;
        java.util.Collection collection6 = categoryPlot0.getDomainMarkers(layer5);
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot0.getDomainAxisLocation((int) 'a');
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace9);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNull(collection6);
        org.junit.Assert.assertNotNull(axisLocation8);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        java.awt.Font font2 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer6 = null;
        org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, paint3, (float) (-1), 0, textMeasurer6);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        multiplePiePlot8.removeChangeListener(plotChangeListener9);
        org.jfree.chart.plot.Plot plot11 = multiplePiePlot8.getParent();
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("ThreadContext", font2, (org.jfree.chart.plot.Plot) multiplePiePlot8, false);
        org.jfree.chart.title.LegendTitle legendTitle14 = jFreeChart13.getLegend();
        java.awt.Paint paint15 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        jFreeChart13.setBorderPaint(paint15);
        org.jfree.chart.event.ChartProgressListener chartProgressListener17 = null;
        jFreeChart13.removeProgressListener(chartProgressListener17);
        java.awt.Stroke stroke19 = jFreeChart13.getBorderStroke();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo24 = null;
        java.awt.image.BufferedImage bufferedImage25 = jFreeChart13.createBufferedImage(10, (int) (byte) 1, (double) (byte) 10, (double) 100, chartRenderingInfo24);
        java.awt.Paint paint26 = jFreeChart13.getBackgroundPaint();
        java.lang.Object obj27 = jFreeChart13.getTextAntiAlias();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(textBlock7);
        org.junit.Assert.assertNull(plot11);
        org.junit.Assert.assertNull(legendTitle14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(bufferedImage25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNull(obj27);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getDomainAxisEdge((int) (byte) 1);
        org.jfree.chart.axis.AxisLocation axisLocation4 = categoryPlot0.getDomainAxisLocation(200);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis();
        org.jfree.chart.axis.ValueAxis valueAxis7 = categoryPlot0.getRangeAxisForDataset(10);
        int int8 = categoryPlot0.getDomainAxisCount();
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D11.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D11.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer16 = null;
        org.jfree.chart.plot.PolarPlot polarPlot17 = new org.jfree.chart.plot.PolarPlot(xYDataset10, (org.jfree.chart.axis.ValueAxis) numberAxis3D11, polarItemRenderer16);
        numberAxis3D11.zoomRange((double) (-1), (double) 100.0f);
        categoryPlot0.setRangeAxis((int) (byte) 10, (org.jfree.chart.axis.ValueAxis) numberAxis3D11, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = categoryPlot0.getDomainAxis();
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNull(categoryAxis23);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        double double2 = categoryAxis1.getCategoryMargin();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 100, "TextAnchor.CENTER_RIGHT");
        java.awt.Font font7 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        categoryAxis1.setTickLabelFont((java.lang.Comparable) (byte) 100, font7);
        boolean boolean9 = horizontalAlignment0.equals((java.lang.Object) font7);
        java.lang.String str10 = horizontalAlignment0.toString();
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "HorizontalAlignment.RIGHT" + "'", str10.equals("HorizontalAlignment.RIGHT"));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D1.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D1.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, polarItemRenderer6);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = null;
        polarPlot7.datasetChanged(datasetChangeEvent8);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier10 = polarPlot7.getDrawingSupplier();
        polarPlot7.removeCornerTextItem("Other");
        org.junit.Assert.assertNotNull(drawingSupplier10);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        double[] doubleArray5 = new double[] { (byte) 0, 0.2d, (-1.0d) };
        double[] doubleArray9 = new double[] { (byte) 0, 0.2d, (-1.0d) };
        double[] doubleArray13 = new double[] { (byte) 0, 0.2d, (-1.0d) };
        double[][] doubleArray14 = new double[][] { doubleArray5, doubleArray9, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("rect", "RectangleAnchor.BOTTOM_LEFT", doubleArray14);
        java.lang.Number number16 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset15);
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj18 = categoryAxis17.clone();
        categoryAxis17.setTickMarkInsideLength((float) 10L);
        double double21 = categoryAxis17.getUpperMargin();
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.Timeline timeline26 = dateAxis25.getTimeline();
        java.util.TimeZone timeZone27 = dateAxis25.getTimeZone();
        dateAxis23.setTimeZone(timeZone27);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis17, (org.jfree.chart.axis.ValueAxis) dateAxis23, categoryItemRenderer29);
        java.awt.Color color31 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        categoryPlot30.setRangeCrosshairPaint((java.awt.Paint) color31);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 0.2d + "'", number16.equals(0.2d));
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.05d + "'", double21 == 0.05d);
        org.junit.Assert.assertNotNull(timeline26);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertNotNull(color31);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        int int0 = org.jfree.chart.axis.ValueAxis.MAXIMUM_TICK_COUNT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 500 + "'", int0 == 500);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setSectionOutlinesVisible(true);
        java.awt.Paint paint6 = piePlot3.getBackgroundPaint();
        java.awt.Paint paint8 = piePlot3.getSectionOutlinePaint((java.lang.Comparable) 100.0f);
        java.awt.Stroke stroke9 = piePlot3.getLabelOutlineStroke();
        java.awt.Paint paint10 = piePlot3.getShadowPaint();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator12 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        piePlot3.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator12);
        piePlot1.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator12);
        java.lang.Object obj15 = standardPieSectionLabelGenerator12.clone();
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D1.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D1.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, polarItemRenderer6);
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = polarPlot7.getOrientation();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = polarPlot7.getRenderer();
        boolean boolean10 = polarPlot7.isRangeZoomable();
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        piePlot14.setSectionOutlinesVisible(true);
        java.awt.Paint paint17 = piePlot14.getBackgroundPaint();
        java.awt.Color color19 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.image.ColorModel colorModel20 = null;
        java.awt.Rectangle rectangle21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        java.awt.geom.AffineTransform affineTransform23 = null;
        java.awt.RenderingHints renderingHints24 = null;
        java.awt.PaintContext paintContext25 = color19.createContext(colorModel20, rectangle21, rectangle2D22, affineTransform23, renderingHints24);
        piePlot14.setSectionPaint((java.lang.Comparable) (byte) 100, (java.awt.Paint) color19);
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor28 = null;
        org.jfree.chart.block.BlockContainer blockContainer31 = new org.jfree.chart.block.BlockContainer();
        blockContainer31.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D34 = blockContainer31.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double36 = categoryAxis27.getCategoryJava2DCoordinate(categoryAnchor28, (int) (byte) 10, 0, rectangle2D34, rectangleEdge35);
        piePlot14.setLegendItemShape((java.awt.Shape) rectangle2D34);
        java.awt.Point point38 = polarPlot7.translateValueThetaRadiusToJava2D((double) (short) 0, 9.223372036854776E18d, rectangle2D34);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D39 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D39.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D39.setAutoRangeStickyZero(false);
        numberAxis3D39.setLabel("ThreadContext");
        numberAxis3D39.setRange((double) 3, 10.0d);
        java.awt.Font font49 = numberAxis3D39.getLabelFont();
        polarPlot7.setAngleLabelFont(font49);
        java.awt.Paint paint51 = polarPlot7.getAngleLabelPaint();
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertNull(polarItemRenderer9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(paintContext25);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNotNull(rectangleEdge35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(point38);
        org.junit.Assert.assertNotNull(font49);
        org.junit.Assert.assertNotNull(paint51);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        piePlot5.setSectionOutlinesVisible(true);
        java.awt.Paint paint8 = piePlot5.getBackgroundPaint();
        org.jfree.chart.block.BlockBorder blockBorder9 = new org.jfree.chart.block.BlockBorder((double) (byte) 10, (double) 100L, (double) (-1), (-1.0d), paint8);
        org.jfree.chart.text.TextAnchor textAnchor10 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        boolean boolean11 = blockBorder9.equals((java.lang.Object) textAnchor10);
        java.awt.Paint paint12 = blockBorder9.getPaint();
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(textAnchor10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit(1.0d);
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot0);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = legendTitle3.getVerticalAlignment();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = legendTitle3.getLegendItemGraphicLocation();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        legendTitle3.setItemLabelPadding(rectangleInsets6);
        legendTitle3.setNotify(true);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getDomainAxisEdge((int) (byte) 1);
        org.jfree.chart.axis.AxisLocation axisLocation4 = categoryPlot0.getDomainAxisLocation(200);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis();
        double double6 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D9 = new org.jfree.chart.axis.NumberAxis3D();
        boolean boolean10 = numberAxis3D9.isAutoTickUnitSelection();
        boolean boolean11 = numberAxis3D9.isVisible();
        boolean boolean12 = numberAxis3D9.isAutoRange();
        categoryPlot0.setRangeAxis((int) (short) 100, (org.jfree.chart.axis.ValueAxis) numberAxis3D9);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        blockContainer0.setWidth((double) 10.0f);
        java.lang.String str3 = blockContainer0.getID();
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint7 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer10 = null;
        org.jfree.chart.text.TextBlock textBlock11 = org.jfree.chart.text.TextUtilities.createTextBlock("", font6, paint7, (float) (-1), 0, textMeasurer10);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot12 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener13 = null;
        multiplePiePlot12.removeChangeListener(plotChangeListener13);
        org.jfree.chart.plot.Plot plot15 = multiplePiePlot12.getParent();
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("ThreadContext", font6, (org.jfree.chart.plot.Plot) multiplePiePlot12, false);
        java.util.List list18 = jFreeChart17.getSubtitles();
        org.jfree.chart.block.BlockContainer blockContainer19 = new org.jfree.chart.block.BlockContainer();
        blockContainer19.setWidth((double) 10.0f);
        org.jfree.chart.block.BlockBorder blockBorder22 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = blockBorder22.getInsets();
        blockContainer19.setMargin(rectangleInsets23);
        boolean boolean25 = jFreeChart17.equals((java.lang.Object) rectangleInsets23);
        jFreeChart17.setBackgroundImageAlignment((int) (short) 10);
        java.awt.Paint paint28 = null;
        jFreeChart17.setBorderPaint(paint28);
        boolean boolean30 = blockContainer0.equals((java.lang.Object) jFreeChart17);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textBlock11);
        org.junit.Assert.assertNull(plot15);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertNotNull(blockBorder22);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("{0}");
        textTitle1.setExpandToFitSpace(true);
        java.lang.String str4 = textTitle1.getText();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "{0}" + "'", str4.equals("{0}"));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit(1.0d);
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot0);
        org.jfree.chart.block.BlockContainer blockContainer4 = new org.jfree.chart.block.BlockContainer();
        blockContainer4.setWidth((double) 10.0f);
        org.jfree.chart.block.BlockBorder blockBorder7 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = blockBorder7.getInsets();
        blockContainer4.setMargin(rectangleInsets8);
        java.lang.String str10 = blockContainer4.getID();
        legendTitle3.setWrapper(blockContainer4);
        java.awt.geom.Rectangle2D rectangle2D12 = blockContainer4.getBounds();
        boolean boolean13 = blockContainer4.isEmpty();
        blockContainer4.clear();
        org.junit.Assert.assertNotNull(blockBorder7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D1.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D1.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, polarItemRenderer6);
        java.lang.String str8 = polarPlot7.getPlotType();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent9 = null;
        polarPlot7.datasetChanged(datasetChangeEvent9);
        polarPlot7.setRadiusGridlinesVisible(false);
        polarPlot7.removeCornerTextItem("RectangleAnchor.LEFT");
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Polar Plot" + "'", str8.equals("Polar Plot"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getDomainAxisEdge((int) (byte) 1);
        org.jfree.chart.axis.AxisLocation axisLocation4 = categoryPlot0.getDomainAxisLocation(200);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis();
        double double6 = categoryPlot0.getRangeCrosshairValue();
        java.awt.Image image10 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo14 = new org.jfree.chart.ui.ProjectInfo("hi!", "", "RectangleEdge.TOP", image10, "RectangleEdge.TOP", "", "RectangleEdge.TOP");
        projectInfo14.setVersion("TextAnchor.CENTER_RIGHT");
        java.lang.String str17 = projectInfo14.getCopyright();
        java.lang.String str18 = projectInfo14.toString();
        boolean boolean19 = categoryPlot0.equals((java.lang.Object) projectInfo14);
        org.jfree.chart.block.BlockContainer blockContainer20 = new org.jfree.chart.block.BlockContainer();
        blockContainer20.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D23 = blockContainer20.getBounds();
        org.jfree.chart.block.Block block24 = null;
        blockContainer20.add(block24);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = blockContainer20.getPadding();
        categoryPlot0.setAxisOffset(rectangleInsets26);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "RectangleEdge.TOP" + "'", str17.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi! version TextAnchor.CENTER_RIGHT.\nRectangleEdge.TOP.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:RectangleEdge.TOP\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nRectangleEdge.TOP" + "'", str18.equals("hi! version TextAnchor.CENTER_RIGHT.\nRectangleEdge.TOP.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:RectangleEdge.TOP\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nRectangleEdge.TOP"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertNotNull(rectangleInsets26);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha((float) (short) 1);
        double double4 = piePlot1.getLabelLinkMargin();
        piePlot1.setLabelGap((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.025d + "'", double4 == 0.025d);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.lang.Object obj2 = null;
        boolean boolean3 = dateAxis1.equals(obj2);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.Timeline timeline6 = dateAxis5.getTimeline();
        java.util.TimeZone timeZone7 = dateAxis5.getTimeZone();
        dateAxis1.setTimeZone(timeZone7);
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.Timeline timeline11 = dateAxis10.getTimeline();
        boolean boolean13 = dateAxis10.isHiddenValue((long) (byte) 1);
        org.jfree.chart.axis.Timeline timeline14 = dateAxis10.getTimeline();
        java.util.Date date15 = dateAxis10.getMinimumDate();
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.plot.RingPlot ringPlot17 = new org.jfree.chart.plot.RingPlot(pieDataset16);
        java.awt.Paint paint18 = ringPlot17.getSeparatorPaint();
        double double19 = ringPlot17.getMaximumExplodePercent();
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.data.general.PieDataset pieDataset21 = null;
        org.jfree.chart.plot.PiePlot piePlot22 = new org.jfree.chart.plot.PiePlot(pieDataset21);
        piePlot22.setSectionOutlinesVisible(true);
        java.awt.Paint paint25 = piePlot22.getBackgroundPaint();
        java.awt.Color color27 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.image.ColorModel colorModel28 = null;
        java.awt.Rectangle rectangle29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        java.awt.geom.AffineTransform affineTransform31 = null;
        java.awt.RenderingHints renderingHints32 = null;
        java.awt.PaintContext paintContext33 = color27.createContext(colorModel28, rectangle29, rectangle2D30, affineTransform31, renderingHints32);
        piePlot22.setSectionPaint((java.lang.Comparable) (byte) 100, (java.awt.Paint) color27);
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor36 = null;
        org.jfree.chart.block.BlockContainer blockContainer39 = new org.jfree.chart.block.BlockContainer();
        blockContainer39.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D42 = blockContainer39.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double44 = categoryAxis35.getCategoryJava2DCoordinate(categoryAnchor36, (int) (byte) 10, 0, rectangle2D42, rectangleEdge43);
        piePlot22.setLegendItemShape((java.awt.Shape) rectangle2D42);
        org.jfree.chart.plot.PiePlot3D piePlot3D46 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D46.setBackgroundImageAlignment(1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo50 = null;
        org.jfree.chart.plot.PiePlotState piePlotState51 = ringPlot17.initialise(graphics2D20, rectangle2D42, (org.jfree.chart.plot.PiePlot) piePlot3D46, (java.lang.Integer) 100, plotRenderingInfo50);
        org.jfree.chart.plot.CategoryPlot categoryPlot52 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = categoryPlot52.getDomainAxisEdge((int) (byte) 1);
        double double55 = dateAxis1.dateToJava2D(date15, rectangle2D42, rectangleEdge54);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(timeline6);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(timeline11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(timeline14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(paintContext33);
        org.junit.Assert.assertNotNull(rectangle2D42);
        org.junit.Assert.assertNotNull(rectangleEdge43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(piePlotState51);
        org.junit.Assert.assertNotNull(rectangleEdge54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.data.Range range1 = null;
        org.jfree.data.Range range3 = org.jfree.data.Range.expandToInclude(range1, (-1.0d));
        boolean boolean5 = range3.contains((double) 1);
        org.jfree.data.Range range8 = org.jfree.data.Range.shift(range3, (double) 100, false);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = rectangleConstraint0.toRangeHeight(range3);
        org.jfree.data.Range range10 = null;
        org.jfree.data.Range range12 = org.jfree.data.Range.expandToInclude(range10, (-1.0d));
        boolean boolean14 = range12.contains((double) 1);
        org.jfree.data.Range range17 = org.jfree.data.Range.shift(range12, (double) 100, false);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot18 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.Plot plot19 = multiplePiePlot18.getParent();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent20 = null;
        multiplePiePlot18.markerChanged(markerChangeEvent20);
        java.lang.Comparable comparable22 = multiplePiePlot18.getAggregatedItemsKey();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent23 = null;
        multiplePiePlot18.datasetChanged(datasetChangeEvent23);
        boolean boolean25 = range12.equals((java.lang.Object) multiplePiePlot18);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = rectangleConstraint9.toRangeHeight(range12);
        org.jfree.data.Range range27 = rectangleConstraint9.getWidthRange();
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(rectangleConstraint9);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(plot19);
        org.junit.Assert.assertTrue("'" + comparable22 + "' != '" + "Other" + "'", comparable22.equals("Other"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint26);
        org.junit.Assert.assertNull(range27);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getCategoryMargin();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor2 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = org.jfree.chart.util.RectangleEdge.TOP;
        java.lang.String str7 = rectangleEdge6.toString();
        double double8 = categoryAxis0.getCategoryJava2DCoordinate(categoryAnchor2, (int) 'a', 1, rectangle2D5, rectangleEdge6);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor9 = null;
        org.jfree.chart.block.BlockContainer blockContainer12 = new org.jfree.chart.block.BlockContainer();
        blockContainer12.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D15 = blockContainer12.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis0.getCategoryJava2DCoordinate(categoryAnchor9, 200, (int) (short) 0, rectangle2D15, rectangleEdge16);
        categoryAxis0.setLabel("Polar Plot");
        java.awt.Paint paint21 = categoryAxis0.getTickLabelPaint((java.lang.Comparable) "{0}");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "RectangleEdge.TOP" + "'", str7.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = org.jfree.chart.util.VerticalAlignment.CENTER;
        java.awt.Paint paint3 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        boolean boolean4 = verticalAlignment2.equals((java.lang.Object) paint3);
        org.jfree.chart.block.ColumnArrangement columnArrangement7 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment1, verticalAlignment2, (double) (byte) 1, (double) (byte) -1);
        boolean boolean8 = piePlot3D0.equals((java.lang.Object) (byte) 1);
        java.awt.Paint paint9 = piePlot3D0.getLabelOutlinePaint();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor10 = piePlot3D0.getLabelDistributor();
        piePlot3D0.setCircular(false);
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor10);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        blockParams0.setTranslateY((-10.0d));
        boolean boolean3 = blockParams0.getGenerateEntities();
        boolean boolean4 = blockParams0.getGenerateEntities();
        double double5 = blockParams0.getTranslateY();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-10.0d) + "'", double5 == (-10.0d));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D1.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D1.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, polarItemRenderer6);
        java.lang.String str8 = polarPlot7.getPlotType();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent9 = null;
        polarPlot7.datasetChanged(datasetChangeEvent9);
        java.awt.Stroke stroke11 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        polarPlot7.setRadiusGridlineStroke(stroke11);
        org.jfree.chart.block.BlockContainer blockContainer13 = new org.jfree.chart.block.BlockContainer();
        blockContainer13.setWidth((double) 10.0f);
        org.jfree.chart.block.BlockBorder blockBorder16 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = blockBorder16.getInsets();
        blockContainer13.setMargin(rectangleInsets17);
        boolean boolean19 = blockContainer13.isEmpty();
        boolean boolean20 = polarPlot7.equals((java.lang.Object) blockContainer13);
        org.jfree.chart.LegendItemCollection legendItemCollection21 = polarPlot7.getLegendItems();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Polar Plot" + "'", str8.equals("Polar Plot"));
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(blockBorder16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(legendItemCollection21);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("hi!", "", "RectangleEdge.TOP", image3, "RectangleEdge.TOP", "", "RectangleEdge.TOP");
        projectInfo7.setVersion("TextAnchor.CENTER_RIGHT");
        projectInfo7.setCopyright("hi!");
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        double[] doubleArray3 = new double[] { 1.0f };
        double[][] doubleArray4 = new double[][] { doubleArray3 };
        org.jfree.data.category.CategoryDataset categoryDataset5 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("ChartEntity: tooltip = ", "hi!", doubleArray4);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot6 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset5);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(categoryDataset5);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("{0}");
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("PlotOrientation.HORIZONTAL");
        try {
            dateAxis1.setRange(0.5d, 0.025d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLowerMargin((double) (short) 100);
        categoryAxis0.setLowerMargin((double) 0);
        java.awt.Font font6 = categoryAxis0.getTickLabelFont((java.lang.Comparable) (byte) 100);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor7 = null;
        org.jfree.chart.block.BlockBorder blockBorder10 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = blockBorder10.getInsets();
        org.jfree.chart.block.BlockContainer blockContainer12 = new org.jfree.chart.block.BlockContainer();
        blockContainer12.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D15 = blockContainer12.getBounds();
        rectangleInsets11.trim(rectangle2D15);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = org.jfree.chart.util.RectangleEdge.TOP;
        double double18 = categoryAxis0.getCategoryJava2DCoordinate(categoryAnchor7, (int) (byte) 1, 64, rectangle2D15, rectangleEdge17);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(blockBorder10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = org.jfree.chart.util.VerticalAlignment.CENTER;
        java.awt.Paint paint3 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        boolean boolean4 = verticalAlignment2.equals((java.lang.Object) paint3);
        org.jfree.chart.block.ColumnArrangement columnArrangement7 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment1, verticalAlignment2, (double) (byte) 1, (double) (byte) -1);
        boolean boolean8 = piePlot3D0.equals((java.lang.Object) (byte) 1);
        java.awt.Paint paint9 = piePlot3D0.getLabelOutlinePaint();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor10 = piePlot3D0.getLabelDistributor();
        abstractPieLabelDistributor10.clear();
        org.jfree.chart.plot.PieLabelRecord pieLabelRecord12 = null;
        try {
            abstractPieLabelDistributor10.addPieLabelRecord(pieLabelRecord12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'record' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor10);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (short) 100, (double) (byte) 0, (double) 0.0f, (double) '#');
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (-1L), 10.0d, (double) 0.0f, 0.0d);
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder(rectangleInsets10, (java.awt.Paint) color11);
        double double14 = rectangleInsets10.calculateRightOutset(1.0E-5d);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot1.setLimit(1.0d);
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot1);
        org.jfree.chart.util.VerticalAlignment verticalAlignment5 = legendTitle4.getVerticalAlignment();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment5, 10.0d, 0.0d);
        columnArrangement8.clear();
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment5);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.Plot plot1 = multiplePiePlot0.getParent();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        multiplePiePlot0.markerChanged(markerChangeEvent2);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.Plot plot5 = multiplePiePlot4.getParent();
        multiplePiePlot0.setParent((org.jfree.chart.plot.Plot) multiplePiePlot4);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot4);
        try {
            org.jfree.chart.plot.CategoryPlot categoryPlot8 = jFreeChart7.getCategoryPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.MultiplePiePlot cannot be cast to org.jfree.chart.plot.CategoryPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNull(plot1);
        org.junit.Assert.assertNull(plot5);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer();
        blockContainer1.setWidth((double) 10.0f);
        org.jfree.chart.block.BlockBorder blockBorder4 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = blockBorder4.getInsets();
        blockContainer1.setMargin(rectangleInsets5);
        boolean boolean7 = blockContainer1.isEmpty();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D8 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.RangeType rangeType9 = numberAxis3D8.getRangeType();
        org.jfree.data.Range range10 = null;
        org.jfree.data.Range range12 = org.jfree.data.Range.expandToInclude(range10, (-1.0d));
        boolean boolean14 = range12.contains((double) 1);
        org.jfree.data.Range range17 = org.jfree.data.Range.shift(range12, (double) 100, false);
        numberAxis3D8.setRangeWithMargins(range17);
        columnArrangement0.add((org.jfree.chart.block.Block) blockContainer1, (java.lang.Object) numberAxis3D8);
        blockContainer1.setWidth((double) 1);
        org.junit.Assert.assertNotNull(blockBorder4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(rangeType9);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(range17);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        boolean boolean1 = numberAxis3D0.isAutoTickUnitSelection();
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        numberAxis3D0.setStandardTickUnits(tickUnitSource2);
        float float4 = numberAxis3D0.getTickMarkOutsideLength();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(tickUnitSource2);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 2.0f + "'", float4 == 2.0f);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.chart.PaintMap paintMap0 = new org.jfree.chart.PaintMap();
        boolean boolean2 = paintMap0.containsKey((java.lang.Comparable) 1.0E-5d);
        boolean boolean4 = paintMap0.containsKey((java.lang.Comparable) 1.05d);
        java.awt.Paint paint6 = paintMap0.getPaint((java.lang.Comparable) 0);
        paintMap0.clear();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(paint6);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D1.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D1.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, polarItemRenderer6);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = null;
        polarPlot7.datasetChanged(datasetChangeEvent8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        org.jfree.chart.block.BlockBorder blockBorder13 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = blockBorder13.getInsets();
        org.jfree.chart.block.BlockContainer blockContainer15 = new org.jfree.chart.block.BlockContainer();
        blockContainer15.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D18 = blockContainer15.getBounds();
        rectangleInsets14.trim(rectangle2D18);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor20 = null;
        java.awt.geom.Point2D point2D21 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D18, rectangleAnchor20);
        polarPlot7.zoomDomainAxes((double) (short) 10, (double) 10.0f, plotRenderingInfo12, point2D21);
        boolean boolean23 = polarPlot7.isOutlineVisible();
        org.junit.Assert.assertNotNull(blockBorder13);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNotNull(point2D21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.data.time.DateRange dateRange1 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.data.Range range3 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange1, 0.2d);
        boolean boolean4 = verticalAlignment0.equals((java.lang.Object) range3);
        org.junit.Assert.assertNotNull(verticalAlignment0);
        org.junit.Assert.assertNotNull(dateRange1);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.PaintMap paintMap2 = new org.jfree.chart.PaintMap();
        boolean boolean4 = paintMap2.containsKey((java.lang.Comparable) 1.0E-5d);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D6.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D6.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer11 = null;
        org.jfree.chart.plot.PolarPlot polarPlot12 = new org.jfree.chart.plot.PolarPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) numberAxis3D6, polarItemRenderer11);
        numberAxis3D6.zoomRange((double) (-1), (double) 100.0f);
        double double16 = numberAxis3D6.getLowerBound();
        numberAxis3D6.setPositiveArrowVisible(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit19 = numberAxis3D6.getTickUnit();
        java.awt.Color color20 = java.awt.Color.blue;
        paintMap2.put((java.lang.Comparable) numberTickUnit19, (java.awt.Paint) color20);
        multiplePiePlot1.setAggregatedItemsKey((java.lang.Comparable) numberTickUnit19);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-1.1500000000000001d) + "'", double16 == (-1.1500000000000001d));
        org.junit.Assert.assertNotNull(numberTickUnit19);
        org.junit.Assert.assertNotNull(color20);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        double[] doubleArray5 = new double[] { (byte) 0, 0.2d, (-1.0d) };
        double[] doubleArray9 = new double[] { (byte) 0, 0.2d, (-1.0d) };
        double[] doubleArray13 = new double[] { (byte) 0, 0.2d, (-1.0d) };
        double[][] doubleArray14 = new double[][] { doubleArray5, doubleArray9, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("rect", "RectangleAnchor.BOTTOM_LEFT", doubleArray14);
        org.jfree.data.Range range17 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset15, false);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(range17);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setSectionOutlinesVisible(true);
        java.awt.Paint paint4 = piePlot1.getBackgroundPaint();
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.image.ColorModel colorModel7 = null;
        java.awt.Rectangle rectangle8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.awt.geom.AffineTransform affineTransform10 = null;
        java.awt.RenderingHints renderingHints11 = null;
        java.awt.PaintContext paintContext12 = color6.createContext(colorModel7, rectangle8, rectangle2D9, affineTransform10, renderingHints11);
        piePlot1.setSectionPaint((java.lang.Comparable) (byte) 100, (java.awt.Paint) color6);
        org.jfree.chart.util.Rotation rotation14 = org.jfree.chart.util.Rotation.ANTICLOCKWISE;
        piePlot1.setDirection(rotation14);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paintContext12);
        org.junit.Assert.assertNotNull(rotation14);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        java.awt.Font font2 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer6 = null;
        org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, paint3, (float) (-1), 0, textMeasurer6);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        multiplePiePlot8.removeChangeListener(plotChangeListener9);
        org.jfree.chart.plot.Plot plot11 = multiplePiePlot8.getParent();
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("ThreadContext", font2, (org.jfree.chart.plot.Plot) multiplePiePlot8, false);
        java.util.List list14 = jFreeChart13.getSubtitles();
        org.jfree.chart.block.BlockContainer blockContainer15 = new org.jfree.chart.block.BlockContainer();
        blockContainer15.setWidth((double) 10.0f);
        org.jfree.chart.block.BlockBorder blockBorder18 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = blockBorder18.getInsets();
        blockContainer15.setMargin(rectangleInsets19);
        boolean boolean21 = jFreeChart13.equals((java.lang.Object) rectangleInsets19);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo24 = null;
        try {
            java.awt.image.BufferedImage bufferedImage25 = jFreeChart13.createBufferedImage(0, (int) (byte) 1, chartRenderingInfo24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (0) and height (1) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(textBlock7);
        org.junit.Assert.assertNull(plot11);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(blockBorder18);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D1.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D1.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, polarItemRenderer6);
        java.lang.String str8 = polarPlot7.getPlotType();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent9 = null;
        polarPlot7.datasetChanged(datasetChangeEvent9);
        java.awt.Stroke stroke11 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        polarPlot7.setRadiusGridlineStroke(stroke11);
        polarPlot7.setAngleLabelsVisible(false);
        java.awt.Paint paint15 = polarPlot7.getRadiusGridlinePaint();
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        polarPlot7.setAngleGridlinePaint((java.awt.Paint) color16);
        boolean boolean18 = polarPlot7.isAngleLabelsVisible();
        polarPlot7.zoom(50.4d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Polar Plot" + "'", str8.equals("Polar Plot"));
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj1 = objectList0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLowerMargin((double) (short) 100);
        org.jfree.chart.block.BlockBorder blockBorder5 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = blockBorder5.getInsets();
        double double8 = rectangleInsets6.trimWidth((double) (byte) 10);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D9 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D9.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D9.setAutoRangeStickyZero(false);
        numberAxis3D9.setUpperBound(100.0d);
        float float16 = numberAxis3D9.getTickMarkOutsideLength();
        org.jfree.chart.block.BlockContainer blockContainer17 = new org.jfree.chart.block.BlockContainer();
        blockContainer17.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D20 = blockContainer17.getBounds();
        numberAxis3D9.setLeftArrow((java.awt.Shape) rectangle2D20);
        org.jfree.chart.entity.ChartEntity chartEntity23 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D20, "");
        java.awt.geom.Rectangle2D rectangle2D24 = rectangleInsets6.createOutsetRectangle(rectangle2D20);
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis();
        double double26 = categoryAxis25.getCategoryMargin();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor27 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = org.jfree.chart.util.RectangleEdge.TOP;
        java.lang.String str32 = rectangleEdge31.toString();
        double double33 = categoryAxis25.getCategoryJava2DCoordinate(categoryAnchor27, (int) 'a', 1, rectangle2D30, rectangleEdge31);
        double double34 = categoryAxis0.getCategoryEnd((-1), (int) '4', rectangle2D20, rectangleEdge31);
        categoryAxis0.removeCategoryLabelToolTip((java.lang.Comparable) 255);
        org.junit.Assert.assertNotNull(blockBorder5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 10.0d + "'", double8 == 10.0d);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 1.0f + "'", float16 == 1.0f);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.2d + "'", double26 == 0.2d);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "RectangleEdge.TOP" + "'", str32.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D1.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D1.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, polarItemRenderer6);
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = polarPlot7.getOrientation();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = polarPlot7.getRenderer();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D17 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D17.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D17.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer22 = null;
        org.jfree.chart.plot.PolarPlot polarPlot23 = new org.jfree.chart.plot.PolarPlot(xYDataset16, (org.jfree.chart.axis.ValueAxis) numberAxis3D17, polarItemRenderer22);
        double double24 = polarPlot23.getMaxRadius();
        org.jfree.chart.block.BlockContainer blockContainer27 = new org.jfree.chart.block.BlockContainer();
        blockContainer27.setWidth((double) 10.0f);
        org.jfree.chart.block.BlockBorder blockBorder30 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = blockBorder30.getInsets();
        blockContainer27.setMargin(rectangleInsets31);
        java.awt.Graphics2D graphics2D33 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint34 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint36 = rectangleConstraint34.toFixedWidth((double) 200);
        org.jfree.chart.util.Size2D size2D37 = blockContainer27.arrange(graphics2D33, rectangleConstraint36);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot38 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot38.setLimit(1.0d);
        org.jfree.chart.title.LegendTitle legendTitle41 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot38);
        org.jfree.chart.util.VerticalAlignment verticalAlignment42 = legendTitle41.getVerticalAlignment();
        java.awt.Graphics2D graphics2D43 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint44 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint46 = rectangleConstraint44.toFixedWidth((double) 200);
        org.jfree.chart.util.Size2D size2D47 = legendTitle41.arrange(graphics2D43, rectangleConstraint46);
        size2D47.height = 100.0f;
        org.jfree.chart.util.Size2D size2D50 = rectangleConstraint36.calculateConstrainedSize(size2D47);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor53 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.lang.String str54 = rectangleAnchor53.toString();
        java.awt.geom.Rectangle2D rectangle2D55 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D47, 0.0d, 0.4d, rectangleAnchor53);
        java.awt.Point point56 = polarPlot23.translateValueThetaRadiusToJava2D((double) 1.0f, (double) (short) 10, rectangle2D55);
        polarPlot13.zoomDomainAxes((double) 15, plotRenderingInfo15, (java.awt.geom.Point2D) point56);
        polarPlot7.zoomRangeAxes((double) 1L, (double) (-1L), plotRenderingInfo12, (java.awt.geom.Point2D) point56);
        java.awt.Font font59 = polarPlot7.getAngleLabelFont();
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertNull(polarItemRenderer9);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.05d + "'", double24 == 1.05d);
        org.junit.Assert.assertNotNull(blockBorder30);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(rectangleConstraint34);
        org.junit.Assert.assertNotNull(rectangleConstraint36);
        org.junit.Assert.assertNotNull(size2D37);
        org.junit.Assert.assertNotNull(verticalAlignment42);
        org.junit.Assert.assertNotNull(rectangleConstraint44);
        org.junit.Assert.assertNotNull(rectangleConstraint46);
        org.junit.Assert.assertNotNull(size2D47);
        org.junit.Assert.assertNotNull(size2D50);
        org.junit.Assert.assertNotNull(rectangleAnchor53);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "RectangleAnchor.LEFT" + "'", str54.equals("RectangleAnchor.LEFT"));
        org.junit.Assert.assertNotNull(rectangle2D55);
        org.junit.Assert.assertNotNull(point56);
        org.junit.Assert.assertNotNull(font59);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = org.jfree.chart.util.VerticalAlignment.CENTER;
        java.awt.Paint paint3 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        boolean boolean4 = verticalAlignment2.equals((java.lang.Object) paint3);
        org.jfree.chart.block.ColumnArrangement columnArrangement7 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment1, verticalAlignment2, (double) (byte) 1, (double) (byte) -1);
        boolean boolean8 = chartChangeEventType0.equals((java.lang.Object) verticalAlignment2);
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        piePlot10.setSectionOutlinesVisible(true);
        java.awt.Paint paint13 = piePlot10.getBackgroundPaint();
        java.awt.Paint paint15 = piePlot10.getSectionOutlinePaint((java.lang.Comparable) 100.0f);
        java.awt.Font font18 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint19 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer22 = null;
        org.jfree.chart.text.TextBlock textBlock23 = org.jfree.chart.text.TextUtilities.createTextBlock("", font18, paint19, (float) (-1), 0, textMeasurer22);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot24 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener25 = null;
        multiplePiePlot24.removeChangeListener(plotChangeListener25);
        org.jfree.chart.plot.Plot plot27 = multiplePiePlot24.getParent();
        org.jfree.chart.JFreeChart jFreeChart29 = new org.jfree.chart.JFreeChart("ThreadContext", font18, (org.jfree.chart.plot.Plot) multiplePiePlot24, false);
        jFreeChart29.setBackgroundImageAlignment(200);
        float float32 = jFreeChart29.getBackgroundImageAlpha();
        piePlot10.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart29);
        boolean boolean34 = jFreeChart29.isBorderVisible();
        boolean boolean35 = chartChangeEventType0.equals((java.lang.Object) jFreeChart29);
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(paint15);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(textBlock23);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertTrue("'" + float32 + "' != '" + 0.5f + "'", float32 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit(1.0d);
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot0);
        org.jfree.chart.block.BlockContainer blockContainer4 = new org.jfree.chart.block.BlockContainer();
        blockContainer4.setWidth((double) 10.0f);
        org.jfree.chart.block.BlockBorder blockBorder7 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = blockBorder7.getInsets();
        blockContainer4.setMargin(rectangleInsets8);
        java.lang.String str10 = blockContainer4.getID();
        legendTitle3.setWrapper(blockContainer4);
        java.awt.geom.Rectangle2D rectangle2D12 = blockContainer4.getBounds();
        boolean boolean13 = blockContainer4.isEmpty();
        org.jfree.chart.block.BlockContainer blockContainer14 = new org.jfree.chart.block.BlockContainer();
        blockContainer14.setWidth((double) 10.0f);
        org.jfree.chart.block.BlockBorder blockBorder17 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = blockBorder17.getInsets();
        blockContainer14.setMargin(rectangleInsets18);
        java.lang.String str20 = blockContainer14.getID();
        org.jfree.chart.block.Arrangement arrangement21 = blockContainer14.getArrangement();
        blockContainer4.setArrangement(arrangement21);
        org.jfree.chart.block.BlockParams blockParams23 = new org.jfree.chart.block.BlockParams();
        double double24 = blockParams23.getTranslateX();
        boolean boolean25 = blockContainer4.equals((java.lang.Object) blockParams23);
        org.jfree.chart.block.Arrangement arrangement26 = blockContainer4.getArrangement();
        org.junit.Assert.assertNotNull(blockBorder7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(blockBorder17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(arrangement21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(arrangement26);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit(1.0d);
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot0);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = legendTitle3.getVerticalAlignment();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = rectangleConstraint6.toFixedWidth((double) 200);
        org.jfree.chart.util.Size2D size2D9 = legendTitle3.arrange(graphics2D5, rectangleConstraint8);
        double double10 = size2D9.height;
        java.lang.Object obj11 = size2D9.clone();
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(rectangleConstraint6);
        org.junit.Assert.assertNotNull(rectangleConstraint8);
        org.junit.Assert.assertNotNull(size2D9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D1.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D1.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, polarItemRenderer6);
        java.lang.String str8 = polarPlot7.getPlotType();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent9 = null;
        polarPlot7.datasetChanged(datasetChangeEvent9);
        polarPlot7.setRadiusGridlinesVisible(false);
        boolean boolean13 = polarPlot7.isRadiusGridlinesVisible();
        polarPlot7.clearCornerTextItems();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Polar Plot" + "'", str8.equals("Polar Plot"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke1 = lineBorder0.getStroke();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            lineBorder0.draw(graphics2D2, rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.Timeline timeline2 = dateAxis1.getTimeline();
        boolean boolean4 = dateAxis1.isHiddenValue((long) (byte) 1);
        org.jfree.chart.axis.Timeline timeline5 = dateAxis1.getTimeline();
        java.util.Date date6 = dateAxis1.getMaximumDate();
        java.lang.Object obj7 = dateAxis1.clone();
        double[] doubleArray13 = new double[] { (byte) 0, 0.2d, (-1.0d) };
        double[] doubleArray17 = new double[] { (byte) 0, 0.2d, (-1.0d) };
        double[] doubleArray21 = new double[] { (byte) 0, 0.2d, (-1.0d) };
        double[][] doubleArray22 = new double[][] { doubleArray13, doubleArray17, doubleArray21 };
        org.jfree.data.category.CategoryDataset categoryDataset23 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("rect", "RectangleAnchor.BOTTOM_LEFT", doubleArray22);
        java.lang.Number number24 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset23);
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj26 = categoryAxis25.clone();
        categoryAxis25.setTickMarkInsideLength((float) 10L);
        double double29 = categoryAxis25.getUpperMargin();
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.Timeline timeline34 = dateAxis33.getTimeline();
        java.util.TimeZone timeZone35 = dateAxis33.getTimeZone();
        dateAxis31.setTimeZone(timeZone35);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis25, (org.jfree.chart.axis.ValueAxis) dateAxis31, categoryItemRenderer37);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition39 = dateAxis31.getTickMarkPosition();
        dateAxis1.setTickMarkPosition(dateTickMarkPosition39);
        org.junit.Assert.assertNotNull(timeline2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeline5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(categoryDataset23);
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + 0.2d + "'", number24.equals(0.2d));
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.05d + "'", double29 == 0.05d);
        org.junit.Assert.assertNotNull(timeline34);
        org.junit.Assert.assertNotNull(timeZone35);
        org.junit.Assert.assertNotNull(dateTickMarkPosition39);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getCategoryMargin();
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) 100, "TextAnchor.CENTER_RIGHT");
        categoryAxis0.configure();
        double double6 = categoryAxis0.getLowerMargin();
        java.awt.Font font8 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        categoryAxis0.setTickLabelFont((java.lang.Comparable) 'a', font8);
        categoryAxis0.setUpperMargin((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
        org.junit.Assert.assertNotNull(font8);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.Plot plot1 = multiplePiePlot0.getParent();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        multiplePiePlot0.markerChanged(markerChangeEvent2);
        boolean boolean4 = multiplePiePlot0.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart5 = multiplePiePlot0.getPieChart();
        try {
            org.jfree.chart.plot.XYPlot xYPlot6 = jFreeChart5.getXYPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.PiePlot cannot be cast to org.jfree.chart.plot.XYPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNull(plot1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(jFreeChart5);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("hi!", "", "RectangleEdge.TOP", image3, "RectangleEdge.TOP", "", "RectangleEdge.TOP");
        projectInfo7.setVersion("TextAnchor.CENTER_RIGHT");
        org.jfree.chart.ui.Library[] libraryArray10 = projectInfo7.getLibraries();
        org.junit.Assert.assertNotNull(libraryArray10);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getDomainAxisEdge((int) (byte) 1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryPlot0.getAxisOffset();
        boolean boolean4 = categoryPlot0.isRangeCrosshairVisible();
        java.awt.Stroke stroke5 = categoryPlot0.getRangeGridlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D10.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D10.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer15 = null;
        org.jfree.chart.plot.PolarPlot polarPlot16 = new org.jfree.chart.plot.PolarPlot(xYDataset9, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, polarItemRenderer15);
        double double17 = polarPlot16.getMaxRadius();
        org.jfree.chart.block.BlockContainer blockContainer20 = new org.jfree.chart.block.BlockContainer();
        blockContainer20.setWidth((double) 10.0f);
        org.jfree.chart.block.BlockBorder blockBorder23 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = blockBorder23.getInsets();
        blockContainer20.setMargin(rectangleInsets24);
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint27 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint29 = rectangleConstraint27.toFixedWidth((double) 200);
        org.jfree.chart.util.Size2D size2D30 = blockContainer20.arrange(graphics2D26, rectangleConstraint29);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot31 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot31.setLimit(1.0d);
        org.jfree.chart.title.LegendTitle legendTitle34 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot31);
        org.jfree.chart.util.VerticalAlignment verticalAlignment35 = legendTitle34.getVerticalAlignment();
        java.awt.Graphics2D graphics2D36 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint37 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint39 = rectangleConstraint37.toFixedWidth((double) 200);
        org.jfree.chart.util.Size2D size2D40 = legendTitle34.arrange(graphics2D36, rectangleConstraint39);
        size2D40.height = 100.0f;
        org.jfree.chart.util.Size2D size2D43 = rectangleConstraint29.calculateConstrainedSize(size2D40);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor46 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.lang.String str47 = rectangleAnchor46.toString();
        java.awt.geom.Rectangle2D rectangle2D48 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D40, 0.0d, 0.4d, rectangleAnchor46);
        java.awt.Point point49 = polarPlot16.translateValueThetaRadiusToJava2D((double) 1.0f, (double) (short) 10, rectangle2D48);
        categoryPlot0.zoomRangeAxes(49.66059027777778d, (double) 15, plotRenderingInfo8, (java.awt.geom.Point2D) point49);
        java.awt.Paint paint51 = categoryPlot0.getDomainGridlinePaint();
        java.awt.Paint paint54 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke55 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker56 = new org.jfree.chart.plot.ValueMarker(35.0d, paint54, stroke55);
        org.jfree.chart.block.BlockBorder blockBorder57 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets58 = blockBorder57.getInsets();
        org.jfree.chart.block.BlockContainer blockContainer59 = new org.jfree.chart.block.BlockContainer();
        blockContainer59.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D62 = blockContainer59.getBounds();
        rectangleInsets58.trim(rectangle2D62);
        valueMarker56.setLabelOffset(rectangleInsets58);
        org.jfree.chart.util.Layer layer65 = null;
        try {
            boolean boolean66 = categoryPlot0.removeDomainMarker(10, (org.jfree.chart.plot.Marker) valueMarker56, layer65);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.05d + "'", double17 == 1.05d);
        org.junit.Assert.assertNotNull(blockBorder23);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(rectangleConstraint27);
        org.junit.Assert.assertNotNull(rectangleConstraint29);
        org.junit.Assert.assertNotNull(size2D30);
        org.junit.Assert.assertNotNull(verticalAlignment35);
        org.junit.Assert.assertNotNull(rectangleConstraint37);
        org.junit.Assert.assertNotNull(rectangleConstraint39);
        org.junit.Assert.assertNotNull(size2D40);
        org.junit.Assert.assertNotNull(size2D43);
        org.junit.Assert.assertNotNull(rectangleAnchor46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "RectangleAnchor.LEFT" + "'", str47.equals("RectangleAnchor.LEFT"));
        org.junit.Assert.assertNotNull(rectangle2D48);
        org.junit.Assert.assertNotNull(point49);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNotNull(blockBorder57);
        org.junit.Assert.assertNotNull(rectangleInsets58);
        org.junit.Assert.assertNotNull(rectangle2D62);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("{0}");
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        textTitle1.setBackgroundPaint((java.awt.Paint) color2);
        boolean boolean4 = textTitle1.getExpandToFitSpace();
        textTitle1.setToolTipText("PlotOrientation.HORIZONTAL");
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getDomainAxisEdge((int) (byte) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray3 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot0.setRenderers(categoryItemRendererArray3);
        categoryPlot0.clearDomainAxes();
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(categoryItemRendererArray3);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getDomainAxisEdge((int) (byte) 1);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D3.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D3.setAutoRangeStickyZero(false);
        numberAxis3D3.setUpperBound(100.0d);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand10 = numberAxis3D3.getMarkerBand();
        java.awt.Shape shape11 = numberAxis3D3.getLeftArrow();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis3D3.setTickUnit(numberTickUnit12, false, true);
        int int16 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D3);
        java.awt.Shape shape17 = null;
        try {
            numberAxis3D3.setRightArrow(shape17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrow' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNull(markerAxisBand10);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.Plot plot1 = multiplePiePlot0.getParent();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        multiplePiePlot0.markerChanged(markerChangeEvent2);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.Plot plot5 = multiplePiePlot4.getParent();
        multiplePiePlot0.setParent((org.jfree.chart.plot.Plot) multiplePiePlot4);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot4);
        double double8 = multiplePiePlot4.getLimit();
        org.junit.Assert.assertNull(plot1);
        org.junit.Assert.assertNull(plot5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor(3);
        pieLabelDistributor1.clear();
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D0.clearCategoryLabelToolTips();
        java.lang.Object obj2 = categoryAxis3D0.clone();
        java.awt.Paint paint3 = categoryAxis3D0.getLabelPaint();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        piePlot5.setBackgroundAlpha((float) (-1));
        java.awt.Font font10 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint11 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer14 = null;
        org.jfree.chart.text.TextBlock textBlock15 = org.jfree.chart.text.TextUtilities.createTextBlock("", font10, paint11, (float) (-1), 0, textMeasurer14);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot16 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener17 = null;
        multiplePiePlot16.removeChangeListener(plotChangeListener17);
        org.jfree.chart.plot.Plot plot19 = multiplePiePlot16.getParent();
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("ThreadContext", font10, (org.jfree.chart.plot.Plot) multiplePiePlot16, false);
        java.util.List list22 = jFreeChart21.getSubtitles();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo25 = null;
        java.awt.image.BufferedImage bufferedImage26 = jFreeChart21.createBufferedImage((int) '4', (int) '4', chartRenderingInfo25);
        piePlot5.setBackgroundImage((java.awt.Image) bufferedImage26);
        org.jfree.chart.ui.ProjectInfo projectInfo31 = new org.jfree.chart.ui.ProjectInfo("Size2D[width=0.0, height=100.0]", "Range[-1.0,-1.0]", "{0}", (java.awt.Image) bufferedImage26, "hi!", "Other", "ChartEntity: tooltip = ");
        waferMapPlot0.setBackgroundImage((java.awt.Image) bufferedImage26);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(textBlock15);
        org.junit.Assert.assertNull(plot19);
        org.junit.Assert.assertNotNull(list22);
        org.junit.Assert.assertNotNull(bufferedImage26);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setSectionOutlinesVisible(true);
        double double4 = piePlot1.getInteriorGap();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator5 = piePlot1.getLegendLabelGenerator();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.08d + "'", double4 == 0.08d);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator5);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getDomainAxisEdge((int) (byte) 1);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.Timeline timeline5 = dateAxis4.getTimeline();
        boolean boolean7 = dateAxis4.isHiddenValue((long) (byte) 1);
        org.jfree.chart.axis.Timeline timeline8 = dateAxis4.getTimeline();
        java.util.Date date9 = dateAxis4.getMaximumDate();
        org.jfree.data.Range range10 = null;
        org.jfree.data.Range range12 = org.jfree.data.Range.expandToInclude(range10, (-1.0d));
        boolean boolean14 = range12.contains((double) 1);
        org.jfree.data.Range range17 = org.jfree.data.Range.shift(range12, (double) 100, false);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot18 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.Plot plot19 = multiplePiePlot18.getParent();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent20 = null;
        multiplePiePlot18.markerChanged(markerChangeEvent20);
        java.lang.Comparable comparable22 = multiplePiePlot18.getAggregatedItemsKey();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent23 = null;
        multiplePiePlot18.datasetChanged(datasetChangeEvent23);
        boolean boolean25 = range12.equals((java.lang.Object) multiplePiePlot18);
        org.jfree.data.Range range27 = org.jfree.data.Range.expandToInclude(range12, (double) (-1));
        dateAxis4.setRange(range12);
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis4);
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.Timeline timeline34 = dateAxis33.getTimeline();
        java.util.TimeZone timeZone35 = dateAxis33.getTimeZone();
        dateAxis31.setTimeZone(timeZone35);
        dateAxis4.setTimeZone(timeZone35);
        org.jfree.chart.util.UnitType unitType39 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = new org.jfree.chart.util.RectangleInsets(unitType39, (double) (short) 100, (double) (byte) 0, (double) 0.0f, (double) '#');
        double double46 = rectangleInsets44.calculateBottomOutset((double) 1L);
        java.lang.String str47 = rectangleInsets44.toString();
        org.jfree.chart.block.BlockBorder blockBorder48 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets49 = blockBorder48.getInsets();
        double double51 = rectangleInsets49.trimWidth((double) (byte) 10);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D52 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D52.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D52.setAutoRangeStickyZero(false);
        numberAxis3D52.setUpperBound(100.0d);
        float float59 = numberAxis3D52.getTickMarkOutsideLength();
        org.jfree.chart.block.BlockContainer blockContainer60 = new org.jfree.chart.block.BlockContainer();
        blockContainer60.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D63 = blockContainer60.getBounds();
        numberAxis3D52.setLeftArrow((java.awt.Shape) rectangle2D63);
        org.jfree.chart.entity.ChartEntity chartEntity66 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D63, "");
        java.awt.geom.Rectangle2D rectangle2D67 = rectangleInsets49.createOutsetRectangle(rectangle2D63);
        java.awt.geom.Rectangle2D rectangle2D68 = rectangleInsets44.createOutsetRectangle(rectangle2D63);
        org.jfree.chart.axis.CategoryAxis categoryAxis69 = new org.jfree.chart.axis.CategoryAxis();
        double double70 = categoryAxis69.getCategoryMargin();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor71 = null;
        java.awt.geom.Rectangle2D rectangle2D74 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge75 = org.jfree.chart.util.RectangleEdge.TOP;
        java.lang.String str76 = rectangleEdge75.toString();
        double double77 = categoryAxis69.getCategoryJava2DCoordinate(categoryAnchor71, (int) 'a', 1, rectangle2D74, rectangleEdge75);
        org.jfree.data.general.PieDataset pieDataset78 = null;
        org.jfree.chart.plot.PiePlot piePlot79 = new org.jfree.chart.plot.PiePlot(pieDataset78);
        piePlot79.setSectionOutlinesVisible(true);
        java.awt.Paint paint82 = piePlot79.getBackgroundPaint();
        java.awt.Paint paint84 = piePlot79.getSectionOutlinePaint((java.lang.Comparable) 100.0f);
        boolean boolean85 = rectangleEdge75.equals((java.lang.Object) piePlot79);
        double double86 = dateAxis4.java2DToValue((double) 'a', rectangle2D63, rectangleEdge75);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(timeline5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(timeline8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(plot19);
        org.junit.Assert.assertTrue("'" + comparable22 + "' != '" + "Other" + "'", comparable22.equals("Other"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertNotNull(timeline34);
        org.junit.Assert.assertNotNull(timeZone35);
        org.junit.Assert.assertNotNull(unitType39);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "RectangleInsets[t=100.0,l=0.0,b=0.0,r=35.0]" + "'", str47.equals("RectangleInsets[t=100.0,l=0.0,b=0.0,r=35.0]"));
        org.junit.Assert.assertNotNull(blockBorder48);
        org.junit.Assert.assertNotNull(rectangleInsets49);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 10.0d + "'", double51 == 10.0d);
        org.junit.Assert.assertTrue("'" + float59 + "' != '" + 1.0f + "'", float59 == 1.0f);
        org.junit.Assert.assertNotNull(rectangle2D63);
        org.junit.Assert.assertNotNull(rectangle2D67);
        org.junit.Assert.assertNotNull(rectangle2D68);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.2d + "'", double70 == 0.2d);
        org.junit.Assert.assertNotNull(rectangleEdge75);
        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "RectangleEdge.TOP" + "'", str76.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
        org.junit.Assert.assertNotNull(paint82);
        org.junit.Assert.assertNull(paint84);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 0.0d + "'", double86 == 0.0d);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (short) 100, (double) (byte) 0, (double) 0.0f, (double) '#');
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (-1L), 10.0d, (double) 0.0f, 0.0d);
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder(rectangleInsets10, (java.awt.Paint) color11);
        double double14 = rectangleInsets10.calculateLeftInset((double) 255);
        org.jfree.chart.util.UnitType unitType15 = rectangleInsets10.getUnitType();
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 10.0d + "'", double14 == 10.0d);
        org.junit.Assert.assertNotNull(unitType15);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        java.awt.Font font2 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer6 = null;
        org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, paint3, (float) (-1), 0, textMeasurer6);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        multiplePiePlot8.removeChangeListener(plotChangeListener9);
        org.jfree.chart.plot.Plot plot11 = multiplePiePlot8.getParent();
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("ThreadContext", font2, (org.jfree.chart.plot.Plot) multiplePiePlot8, false);
        java.util.List list14 = jFreeChart13.getSubtitles();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        java.awt.image.BufferedImage bufferedImage18 = jFreeChart13.createBufferedImage((int) '4', (int) '4', chartRenderingInfo17);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot19 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot19.setLimit(1.0d);
        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot19);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = legendTitle22.getPosition();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent24 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle22);
        jFreeChart13.removeSubtitle((org.jfree.chart.title.Title) legendTitle22);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(textBlock7);
        org.junit.Assert.assertNull(plot11);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(bufferedImage18);
        org.junit.Assert.assertNotNull(rectangleEdge23);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.lang.Object obj2 = null;
        boolean boolean3 = dateAxis1.equals(obj2);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D7.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D7.setAutoRangeStickyZero(false);
        numberAxis3D7.setUpperBound(100.0d);
        float float14 = numberAxis3D7.getTickMarkOutsideLength();
        org.jfree.chart.block.BlockContainer blockContainer15 = new org.jfree.chart.block.BlockContainer();
        blockContainer15.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D18 = blockContainer15.getBounds();
        numberAxis3D7.setLeftArrow((java.awt.Shape) rectangle2D18);
        org.jfree.chart.entity.ChartEntity chartEntity21 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D18, "");
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        try {
            org.jfree.chart.axis.AxisState axisState24 = dateAxis1.draw(graphics2D4, 2.0d, rectangle2D6, rectangle2D18, rectangleEdge22, plotRenderingInfo23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 1.0f + "'", float14 == 1.0f);
        org.junit.Assert.assertNotNull(rectangle2D18);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        boolean boolean1 = numberAxis3D0.isAutoTickUnitSelection();
        boolean boolean2 = numberAxis3D0.isVerticalTickLabels();
        numberAxis3D0.resizeRange(0.0d);
        org.jfree.data.Range range5 = null;
        org.jfree.data.Range range7 = org.jfree.data.Range.expandToInclude(range5, (-1.0d));
        boolean boolean9 = range7.contains((double) 1);
        org.jfree.data.Range range12 = org.jfree.data.Range.shift(range7, (double) 100, false);
        double double13 = range7.getLowerBound();
        org.jfree.data.Range range16 = org.jfree.data.Range.expand(range7, (double) '4', (double) 64);
        numberAxis3D0.setRange(range16, true, true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-1.0d) + "'", double13 == (-1.0d));
        org.junit.Assert.assertNotNull(range16);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D1.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D1.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, polarItemRenderer6);
        double double8 = polarPlot7.getMaxRadius();
        org.jfree.chart.LegendItemCollection legendItemCollection9 = polarPlot7.getLegendItems();
        java.awt.Paint paint10 = polarPlot7.getRadiusGridlinePaint();
        polarPlot7.setBackgroundImageAlignment(0);
        java.awt.Stroke stroke13 = null;
        polarPlot7.setRadiusGridlineStroke(stroke13);
        java.awt.Font font15 = polarPlot7.getAngleLabelFont();
        double double16 = polarPlot7.getMaxRadius();
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.05d + "'", double8 == 1.05d);
        org.junit.Assert.assertNotNull(legendItemCollection9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.05d + "'", double16 == 1.05d);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        boolean boolean1 = numberAxis3D0.isAutoTickUnitSelection();
        boolean boolean2 = numberAxis3D0.isVisible();
        numberAxis3D0.setLowerBound((double) 200);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.AxisState axisState6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.LEFT;
        try {
            java.util.List list9 = numberAxis3D0.refreshTicks(graphics2D5, axisState6, rectangle2D7, rectangleEdge8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(rectangleEdge8);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setBackgroundAlpha((float) (-1));
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint7 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer10 = null;
        org.jfree.chart.text.TextBlock textBlock11 = org.jfree.chart.text.TextUtilities.createTextBlock("", font6, paint7, (float) (-1), 0, textMeasurer10);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot12 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener13 = null;
        multiplePiePlot12.removeChangeListener(plotChangeListener13);
        org.jfree.chart.plot.Plot plot15 = multiplePiePlot12.getParent();
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("ThreadContext", font6, (org.jfree.chart.plot.Plot) multiplePiePlot12, false);
        java.util.List list18 = jFreeChart17.getSubtitles();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo21 = null;
        java.awt.image.BufferedImage bufferedImage22 = jFreeChart17.createBufferedImage((int) '4', (int) '4', chartRenderingInfo21);
        piePlot1.setBackgroundImage((java.awt.Image) bufferedImage22);
        org.jfree.chart.util.Rotation rotation24 = org.jfree.chart.util.Rotation.CLOCKWISE;
        piePlot1.setDirection(rotation24);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator26 = piePlot1.getURLGenerator();
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textBlock11);
        org.junit.Assert.assertNull(plot15);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertNotNull(bufferedImage22);
        org.junit.Assert.assertNotNull(rotation24);
        org.junit.Assert.assertNull(pieURLGenerator26);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getDomainAxisEdge((int) (byte) 1);
        org.jfree.chart.axis.AxisLocation axisLocation4 = categoryPlot0.getDomainAxisLocation(200);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis();
        double double6 = categoryPlot0.getRangeCrosshairValue();
        java.awt.Image image10 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo14 = new org.jfree.chart.ui.ProjectInfo("hi!", "", "RectangleEdge.TOP", image10, "RectangleEdge.TOP", "", "RectangleEdge.TOP");
        projectInfo14.setVersion("TextAnchor.CENTER_RIGHT");
        java.lang.String str17 = projectInfo14.getCopyright();
        java.lang.String str18 = projectInfo14.toString();
        boolean boolean19 = categoryPlot0.equals((java.lang.Object) projectInfo14);
        java.awt.Stroke stroke20 = categoryPlot0.getRangeCrosshairStroke();
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "RectangleEdge.TOP" + "'", str17.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi! version TextAnchor.CENTER_RIGHT.\nRectangleEdge.TOP.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:RectangleEdge.TOP\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nRectangleEdge.TOP" + "'", str18.equals("hi! version TextAnchor.CENTER_RIGHT.\nRectangleEdge.TOP.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:RectangleEdge.TOP\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nRectangleEdge.TOP"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.StrokeMap strokeMap1 = new org.jfree.chart.StrokeMap();
        org.jfree.chart.block.BlockBorder blockBorder2 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = blockBorder2.getInsets();
        double double5 = rectangleInsets3.trimWidth((double) (byte) 10);
        org.jfree.chart.util.UnitType unitType6 = rectangleInsets3.getUnitType();
        boolean boolean7 = strokeMap1.equals((java.lang.Object) rectangleInsets3);
        java.util.Date date8 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.Stroke stroke9 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        strokeMap1.put((java.lang.Comparable) date8, stroke9);
        int int11 = objectList0.indexOf((java.lang.Object) strokeMap1);
        org.junit.Assert.assertNotNull(blockBorder2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 10.0d + "'", double5 == 10.0d);
        org.junit.Assert.assertNotNull(unitType6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getDomainAxisEdge((int) (byte) 1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryPlot0.getAxisOffset();
        boolean boolean4 = categoryPlot0.isRangeCrosshairVisible();
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot0.setRangeGridlineStroke(stroke5);
        double double7 = categoryPlot0.getAnchorValue();
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getDomainAxisEdge((int) (byte) 1);
        org.jfree.chart.axis.AxisLocation axisLocation4 = categoryPlot0.getDomainAxisLocation(200);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis();
        org.jfree.chart.axis.ValueAxis valueAxis7 = categoryPlot0.getRangeAxisForDataset(10);
        int int8 = categoryPlot0.getDomainAxisCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = categoryPlot10.getDomainAxisEdge((int) (byte) 1);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = categoryPlot10.getAxisOffset();
        boolean boolean14 = categoryPlot10.isRangeCrosshairVisible();
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot10.setRangeGridlineStroke(stroke15);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = categoryPlot18.getDomainAxisEdge((int) (byte) 1);
        org.jfree.chart.axis.AxisLocation axisLocation22 = categoryPlot18.getDomainAxisLocation(200);
        org.jfree.chart.util.Layer layer23 = null;
        java.util.Collection collection24 = categoryPlot18.getDomainMarkers(layer23);
        org.jfree.chart.axis.AxisLocation axisLocation26 = categoryPlot18.getDomainAxisLocation((int) 'a');
        categoryPlot10.setDomainAxisLocation(100, axisLocation26, false);
        categoryPlot0.setRangeAxisLocation(255, axisLocation26, true);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertNotNull(axisLocation26);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getDomainAxisEdge((int) (byte) 1);
        org.jfree.chart.axis.AxisLocation axisLocation4 = categoryPlot0.getDomainAxisLocation(200);
        org.jfree.chart.util.Layer layer5 = null;
        java.util.Collection collection6 = categoryPlot0.getDomainMarkers(layer5);
        categoryPlot0.clearRangeMarkers(500);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNull(collection6);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getDomainAxisEdge((int) (byte) 1);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.Timeline timeline5 = dateAxis4.getTimeline();
        boolean boolean7 = dateAxis4.isHiddenValue((long) (byte) 1);
        org.jfree.chart.axis.Timeline timeline8 = dateAxis4.getTimeline();
        java.util.Date date9 = dateAxis4.getMaximumDate();
        org.jfree.data.Range range10 = null;
        org.jfree.data.Range range12 = org.jfree.data.Range.expandToInclude(range10, (-1.0d));
        boolean boolean14 = range12.contains((double) 1);
        org.jfree.data.Range range17 = org.jfree.data.Range.shift(range12, (double) 100, false);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot18 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.Plot plot19 = multiplePiePlot18.getParent();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent20 = null;
        multiplePiePlot18.markerChanged(markerChangeEvent20);
        java.lang.Comparable comparable22 = multiplePiePlot18.getAggregatedItemsKey();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent23 = null;
        multiplePiePlot18.datasetChanged(datasetChangeEvent23);
        boolean boolean25 = range12.equals((java.lang.Object) multiplePiePlot18);
        org.jfree.data.Range range27 = org.jfree.data.Range.expandToInclude(range12, (double) (-1));
        dateAxis4.setRange(range12);
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis4);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D30 = new org.jfree.chart.axis.NumberAxis3D();
        boolean boolean31 = numberAxis3D30.isNegativeArrowVisible();
        numberAxis3D30.setUpperBound((double) 200);
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis3D30);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(timeline5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(timeline8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(plot19);
        org.junit.Assert.assertTrue("'" + comparable22 + "' != '" + "Other" + "'", comparable22.equals("Other"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setSectionOutlinesVisible(true);
        java.awt.Paint paint4 = piePlot1.getBackgroundPaint();
        java.awt.Paint paint6 = piePlot1.getSectionOutlinePaint((java.lang.Comparable) 100.0f);
        java.awt.Stroke stroke7 = piePlot1.getLabelOutlineStroke();
        java.awt.Paint paint8 = piePlot1.getShadowPaint();
        piePlot1.setShadowYOffset((double) 1.0f);
        piePlot1.setShadowXOffset(9.223372036854776E18d);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        polarPlot0.setAngleGridlineStroke(stroke1);
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        objectList0.clear();
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("{0}");
        boolean boolean2 = textTitle1.getExpandToFitSpace();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getCategoryMargin();
        double double2 = categoryAxis0.getLowerMargin();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions3 = categoryAxis0.getCategoryLabelPositions();
        categoryAxis0.setTickLabelsVisible(false);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(categoryLabelPositions3);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setSectionOutlinesVisible(true);
        java.awt.Paint paint4 = piePlot1.getBackgroundPaint();
        java.awt.Paint paint6 = piePlot1.getSectionOutlinePaint((java.lang.Comparable) 100.0f);
        piePlot1.setCircular(false, false);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = piePlot1.getLegendItems();
        double double11 = piePlot1.getStartAngle();
        java.lang.Object obj12 = piePlot1.clone();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(legendItemCollection10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 90.0d + "'", double11 == 90.0d);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D0.setAutoRangeStickyZero(false);
        numberAxis3D0.setUpperBound(100.0d);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand7 = numberAxis3D0.getMarkerBand();
        double double8 = numberAxis3D0.getFixedAutoRange();
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D10.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D10.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer15 = null;
        org.jfree.chart.plot.PolarPlot polarPlot16 = new org.jfree.chart.plot.PolarPlot(xYDataset9, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, polarItemRenderer15);
        java.lang.String str17 = polarPlot16.getPlotType();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent18 = null;
        polarPlot16.datasetChanged(datasetChangeEvent18);
        java.awt.Stroke stroke20 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        polarPlot16.setRadiusGridlineStroke(stroke20);
        numberAxis3D0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) polarPlot16);
        java.awt.Font font23 = numberAxis3D0.getLabelFont();
        org.junit.Assert.assertNull(markerAxisBand7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Polar Plot" + "'", str17.equals("Polar Plot"));
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(font23);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D1.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D1.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, polarItemRenderer6);
        double double8 = polarPlot7.getMaxRadius();
        org.jfree.chart.LegendItemCollection legendItemCollection9 = polarPlot7.getLegendItems();
        org.jfree.chart.plot.Plot plot10 = polarPlot7.getRootPlot();
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        polarPlot7.setRadiusGridlineStroke(stroke11);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.05d + "'", double8 == 1.05d);
        org.junit.Assert.assertNotNull(legendItemCollection9);
        org.junit.Assert.assertNotNull(plot10);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        org.jfree.chart.text.TextFragment textFragment1 = null;
        textLine0.removeFragment(textFragment1);
        org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("Other");
        textLine0.addFragment(textFragment4);
        org.jfree.chart.text.TextFragment textFragment6 = textLine0.getFirstTextFragment();
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.Paint paint9 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker(35.0d, paint9, stroke10);
        java.awt.Font font12 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        boolean boolean13 = valueMarker11.equals((java.lang.Object) font12);
        org.jfree.chart.text.TextAnchor textAnchor14 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        valueMarker11.setLabelTextAnchor(textAnchor14);
        try {
            float float16 = textFragment6.calculateBaselineOffset(graphics2D7, textAnchor14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textFragment6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(textAnchor14);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape2 = dateAxis1.getRightArrow();
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D();
        boolean boolean3 = numberAxis3D2.isAutoTickUnitSelection();
        boolean boolean4 = numberAxis3D2.isVerticalTickLabels();
        numberAxis3D2.resizeRange(0.0d);
        boolean boolean7 = ringPlot1.equals((java.lang.Object) 0.0d);
        double double8 = ringPlot1.getLabelLinkMargin();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator9 = ringPlot1.getLegendLabelGenerator();
        ringPlot1.setSectionDepth((double) 100L);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.util.UnitType unitType13 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = new org.jfree.chart.util.RectangleInsets(unitType13, (double) (short) 100, (double) (byte) 0, (double) 0.0f, (double) '#');
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = new org.jfree.chart.util.RectangleInsets(unitType13, (double) (-1L), 10.0d, (double) 0.0f, 0.0d);
        double double25 = rectangleInsets23.trimWidth((double) (byte) 0);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D26 = new org.jfree.chart.axis.NumberAxis3D();
        boolean boolean27 = numberAxis3D26.isAutoTickUnitSelection();
        boolean boolean28 = numberAxis3D26.isVisible();
        boolean boolean29 = numberAxis3D26.isAutoRange();
        numberAxis3D26.setTickLabelsVisible(true);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit32 = numberAxis3D26.getTickUnit();
        org.jfree.chart.block.BlockBorder blockBorder34 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = blockBorder34.getInsets();
        double double37 = rectangleInsets35.trimWidth((double) (byte) 10);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D38 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D38.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D38.setAutoRangeStickyZero(false);
        numberAxis3D38.setUpperBound(100.0d);
        float float45 = numberAxis3D38.getTickMarkOutsideLength();
        org.jfree.chart.block.BlockContainer blockContainer46 = new org.jfree.chart.block.BlockContainer();
        blockContainer46.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D49 = blockContainer46.getBounds();
        numberAxis3D38.setLeftArrow((java.awt.Shape) rectangle2D49);
        org.jfree.chart.entity.ChartEntity chartEntity52 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D49, "");
        java.awt.geom.Rectangle2D rectangle2D53 = rectangleInsets35.createOutsetRectangle(rectangle2D49);
        org.jfree.chart.axis.CategoryAxis categoryAxis54 = new org.jfree.chart.axis.CategoryAxis();
        double double55 = categoryAxis54.getCategoryMargin();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor56 = null;
        java.awt.geom.Rectangle2D rectangle2D59 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge60 = org.jfree.chart.util.RectangleEdge.TOP;
        java.lang.String str61 = rectangleEdge60.toString();
        double double62 = categoryAxis54.getCategoryJava2DCoordinate(categoryAnchor56, (int) 'a', 1, rectangle2D59, rectangleEdge60);
        org.jfree.data.general.PieDataset pieDataset63 = null;
        org.jfree.chart.plot.PiePlot piePlot64 = new org.jfree.chart.plot.PiePlot(pieDataset63);
        piePlot64.setSectionOutlinesVisible(true);
        java.awt.Paint paint67 = piePlot64.getBackgroundPaint();
        java.awt.Paint paint69 = piePlot64.getSectionOutlinePaint((java.lang.Comparable) 100.0f);
        boolean boolean70 = rectangleEdge60.equals((java.lang.Object) piePlot64);
        double double71 = numberAxis3D26.java2DToValue(9.223372036854776E18d, rectangle2D49, rectangleEdge60);
        rectangleInsets23.trim(rectangle2D49);
        org.jfree.data.general.PieDataset pieDataset73 = null;
        org.jfree.chart.plot.PiePlot piePlot74 = new org.jfree.chart.plot.PiePlot(pieDataset73);
        piePlot74.setSectionOutlinesVisible(true);
        java.awt.Paint paint77 = piePlot74.getBackgroundPaint();
        java.awt.Paint paint79 = piePlot74.getSectionOutlinePaint((java.lang.Comparable) 100.0f);
        java.awt.Stroke stroke80 = piePlot74.getLabelLinkStroke();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D81 = new org.jfree.chart.axis.NumberAxis3D();
        boolean boolean82 = numberAxis3D81.isAutoTickUnitSelection();
        boolean boolean83 = numberAxis3D81.isVisible();
        boolean boolean84 = numberAxis3D81.isAutoRange();
        numberAxis3D81.setTickLabelsVisible(true);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit87 = numberAxis3D81.getTickUnit();
        double double88 = piePlot74.getExplodePercent((java.lang.Comparable) numberTickUnit87);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo90 = null;
        org.jfree.chart.plot.PiePlotState piePlotState91 = ringPlot1.initialise(graphics2D12, rectangle2D49, piePlot74, (java.lang.Integer) 3, plotRenderingInfo90);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.025d + "'", double8 == 0.025d);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator9);
        org.junit.Assert.assertNotNull(unitType13);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + (-10.0d) + "'", double25 == (-10.0d));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(numberTickUnit32);
        org.junit.Assert.assertNotNull(blockBorder34);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 10.0d + "'", double37 == 10.0d);
        org.junit.Assert.assertTrue("'" + float45 + "' != '" + 1.0f + "'", float45 == 1.0f);
        org.junit.Assert.assertNotNull(rectangle2D49);
        org.junit.Assert.assertNotNull(rectangle2D53);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.2d + "'", double55 == 0.2d);
        org.junit.Assert.assertNotNull(rectangleEdge60);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "RectangleEdge.TOP" + "'", str61.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertNotNull(paint67);
        org.junit.Assert.assertNull(paint69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + Double.POSITIVE_INFINITY + "'", double71 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(paint77);
        org.junit.Assert.assertNull(paint79);
        org.junit.Assert.assertNotNull(stroke80);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + true + "'", boolean83 == true);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
        org.junit.Assert.assertNotNull(numberTickUnit87);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 0.0d + "'", double88 == 0.0d);
        org.junit.Assert.assertNotNull(piePlotState91);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getDomainAxisEdge((int) (byte) 1);
        org.jfree.chart.axis.AxisLocation axisLocation4 = categoryPlot0.getDomainAxisLocation(200);
        org.jfree.chart.util.Layer layer5 = null;
        java.util.Collection collection6 = categoryPlot0.getDomainMarkers(layer5);
        categoryPlot0.setRangeCrosshairValue(0.025d);
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D10.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D10.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer15 = null;
        org.jfree.chart.plot.PolarPlot polarPlot16 = new org.jfree.chart.plot.PolarPlot(xYDataset9, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, polarItemRenderer15);
        numberAxis3D10.zoomRange((double) (-1), (double) 100.0f);
        int int20 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D10);
        org.jfree.chart.util.SortOrder sortOrder21 = null;
        try {
            categoryPlot0.setRowRenderingOrder(sortOrder21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNull(collection6);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit(1.0d);
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot0);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = legendTitle3.getVerticalAlignment();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = rectangleConstraint6.toFixedWidth((double) 200);
        org.jfree.chart.util.Size2D size2D9 = legendTitle3.arrange(graphics2D5, rectangleConstraint8);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = legendTitle3.getLegendItemGraphicAnchor();
        double double11 = legendTitle3.getWidth();
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(rectangleConstraint6);
        org.junit.Assert.assertNotNull(rectangleConstraint8);
        org.junit.Assert.assertNotNull(size2D9);
        org.junit.Assert.assertNotNull(rectangleAnchor10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setSectionOutlinesVisible(true);
        java.awt.Paint paint4 = piePlot1.getBackgroundPaint();
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.image.ColorModel colorModel7 = null;
        java.awt.Rectangle rectangle8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.awt.geom.AffineTransform affineTransform10 = null;
        java.awt.RenderingHints renderingHints11 = null;
        java.awt.PaintContext paintContext12 = color6.createContext(colorModel7, rectangle8, rectangle2D9, affineTransform10, renderingHints11);
        piePlot1.setSectionPaint((java.lang.Comparable) (byte) 100, (java.awt.Paint) color6);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor15 = null;
        org.jfree.chart.block.BlockContainer blockContainer18 = new org.jfree.chart.block.BlockContainer();
        blockContainer18.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D21 = blockContainer18.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double23 = categoryAxis14.getCategoryJava2DCoordinate(categoryAnchor15, (int) (byte) 10, 0, rectangle2D21, rectangleEdge22);
        piePlot1.setLegendItemShape((java.awt.Shape) rectangle2D21);
        org.jfree.data.general.PieDataset pieDataset25 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity31 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D21, pieDataset25, (int) (byte) -1, (int) (short) 100, (java.lang.Comparable) (-1.0f), "Pie Plot", "hi!");
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paintContext12);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("Size2D[width=0.0, height=100.0]");
        textTitle1.setExpandToFitSpace(true);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        java.awt.Font font2 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer6 = null;
        org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, paint3, (float) (-1), 0, textMeasurer6);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        multiplePiePlot8.removeChangeListener(plotChangeListener9);
        org.jfree.chart.plot.Plot plot11 = multiplePiePlot8.getParent();
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("ThreadContext", font2, (org.jfree.chart.plot.Plot) multiplePiePlot8, false);
        jFreeChart13.setBackgroundImageAlignment(200);
        float float16 = jFreeChart13.getBackgroundImageAlpha();
        jFreeChart13.setBackgroundImageAlpha((float) (short) 0);
        java.awt.RenderingHints renderingHints19 = null;
        try {
            jFreeChart13.setRenderingHints(renderingHints19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: RenderingHints given are null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(textBlock7);
        org.junit.Assert.assertNull(plot11);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 0.5f + "'", float16 == 0.5f);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        java.awt.Font font2 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer6 = null;
        org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, paint3, (float) (-1), 0, textMeasurer6);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        multiplePiePlot8.removeChangeListener(plotChangeListener9);
        org.jfree.chart.plot.Plot plot11 = multiplePiePlot8.getParent();
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("ThreadContext", font2, (org.jfree.chart.plot.Plot) multiplePiePlot8, false);
        jFreeChart13.setBackgroundImageAlignment(200);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = jFreeChart13.getPadding();
        double double18 = rectangleInsets16.calculateLeftOutset(10.0d);
        double double20 = rectangleInsets16.calculateBottomInset(1.0d);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(textBlock7);
        org.junit.Assert.assertNull(plot11);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("Range[-1.0,-1.0]", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setBackgroundImageAlignment(1);
        piePlot3D0.setLabelGap((double) 100.0f);
        piePlot3D0.setLabelGap(1.0E-8d);
        double double7 = piePlot3D0.getDepthFactor();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.12d + "'", double7 == 0.12d);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D1.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D1.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, polarItemRenderer6);
        double double8 = polarPlot7.getMaxRadius();
        org.jfree.chart.LegendItemCollection legendItemCollection9 = polarPlot7.getLegendItems();
        org.jfree.chart.plot.Plot plot10 = polarPlot7.getRootPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = categoryPlot11.getDomainAxisEdge((int) (byte) 1);
        org.jfree.chart.axis.AxisLocation axisLocation15 = categoryPlot11.getDomainAxisLocation(200);
        java.awt.Font font17 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color18 = java.awt.Color.PINK;
        org.jfree.chart.text.TextFragment textFragment20 = new org.jfree.chart.text.TextFragment("", font17, (java.awt.Paint) color18, (float) 1L);
        categoryPlot11.setRangeCrosshairPaint((java.awt.Paint) color18);
        polarPlot7.setParent((org.jfree.chart.plot.Plot) categoryPlot11);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.05d + "'", double8 == 1.05d);
        org.junit.Assert.assertNotNull(legendItemCollection9);
        org.junit.Assert.assertNotNull(plot10);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(color18);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        java.awt.Paint paint2 = ringPlot1.getSeparatorPaint();
        double double3 = ringPlot1.getMaximumExplodePercent();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        piePlot6.setSectionOutlinesVisible(true);
        java.awt.Paint paint9 = piePlot6.getBackgroundPaint();
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.image.ColorModel colorModel12 = null;
        java.awt.Rectangle rectangle13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.awt.geom.AffineTransform affineTransform15 = null;
        java.awt.RenderingHints renderingHints16 = null;
        java.awt.PaintContext paintContext17 = color11.createContext(colorModel12, rectangle13, rectangle2D14, affineTransform15, renderingHints16);
        piePlot6.setSectionPaint((java.lang.Comparable) (byte) 100, (java.awt.Paint) color11);
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor20 = null;
        org.jfree.chart.block.BlockContainer blockContainer23 = new org.jfree.chart.block.BlockContainer();
        blockContainer23.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D26 = blockContainer23.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double28 = categoryAxis19.getCategoryJava2DCoordinate(categoryAnchor20, (int) (byte) 10, 0, rectangle2D26, rectangleEdge27);
        piePlot6.setLegendItemShape((java.awt.Shape) rectangle2D26);
        org.jfree.chart.plot.PiePlot3D piePlot3D30 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D30.setBackgroundImageAlignment(1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        org.jfree.chart.plot.PiePlotState piePlotState35 = ringPlot1.initialise(graphics2D4, rectangle2D26, (org.jfree.chart.plot.PiePlot) piePlot3D30, (java.lang.Integer) 100, plotRenderingInfo34);
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = piePlot3D30.getSimpleLabelOffset();
        java.awt.Paint paint37 = piePlot3D30.getLabelLinkPaint();
        java.awt.Graphics2D graphics2D38 = null;
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        java.awt.geom.Point2D point2D40 = null;
        org.jfree.chart.plot.PlotState plotState41 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo42 = null;
        try {
            piePlot3D30.draw(graphics2D38, rectangle2D39, point2D40, plotState41, plotRenderingInfo42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(paintContext17);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(piePlotState35);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertNotNull(paint37);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D1.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D1.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, polarItemRenderer6);
        boolean boolean8 = numberAxis3D1.getAutoRangeStickyZero();
        org.jfree.data.Range range9 = numberAxis3D1.getRange();
        try {
            numberAxis3D1.setRange((double) 'a', (double) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (97.0) <= upper (0.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(range9);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = rectangleConstraint0.toFixedWidth((double) 200);
        double double3 = rectangleConstraint2.getHeight();
        java.lang.String str4 = rectangleConstraint2.toString();
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertNotNull(rectangleConstraint2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=200.0, height=0.0]" + "'", str4.equals("RectangleConstraint[LengthConstraintType.FIXED: width=200.0, height=0.0]"));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        boolean boolean1 = numberAxis3D0.isAutoTickUnitSelection();
        boolean boolean2 = numberAxis3D0.isVerticalTickLabels();
        numberAxis3D0.resizeRange(0.0d);
        double double5 = numberAxis3D0.getUpperMargin();
        numberAxis3D0.resizeRange(35.0d);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getDomainAxisEdge((int) (byte) 1);
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray5 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer4 };
        categoryPlot0.setRenderers(categoryItemRendererArray5);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(categoryItemRendererArray5);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getDomainAxisEdge((int) (byte) 1);
        org.jfree.chart.axis.AxisLocation axisLocation4 = categoryPlot0.getDomainAxisLocation(200);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis();
        double double6 = categoryPlot0.getRangeCrosshairValue();
        java.awt.Image image10 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo14 = new org.jfree.chart.ui.ProjectInfo("hi!", "", "RectangleEdge.TOP", image10, "RectangleEdge.TOP", "", "RectangleEdge.TOP");
        projectInfo14.setVersion("TextAnchor.CENTER_RIGHT");
        java.lang.String str17 = projectInfo14.getCopyright();
        java.lang.String str18 = projectInfo14.toString();
        boolean boolean19 = categoryPlot0.equals((java.lang.Object) projectInfo14);
        categoryPlot0.setDrawSharedDomainAxis(true);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "RectangleEdge.TOP" + "'", str17.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi! version TextAnchor.CENTER_RIGHT.\nRectangleEdge.TOP.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:RectangleEdge.TOP\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nRectangleEdge.TOP" + "'", str18.equals("hi! version TextAnchor.CENTER_RIGHT.\nRectangleEdge.TOP.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:RectangleEdge.TOP\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nRectangleEdge.TOP"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.setTickMarkOutsideLength((float) (short) 1);
        java.awt.Paint paint3 = numberAxis3D0.getAxisLinePaint();
        numberAxis3D0.setAutoRange(true);
        numberAxis3D0.setAutoRangeMinimumSize(0.4d);
        java.awt.Paint paint8 = numberAxis3D0.getTickLabelPaint();
        boolean boolean9 = numberAxis3D0.isPositiveArrowVisible();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        java.awt.Paint paint1 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker(35.0d, paint1, stroke2);
        org.jfree.chart.block.BlockBorder blockBorder4 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = blockBorder4.getInsets();
        org.jfree.chart.block.BlockContainer blockContainer6 = new org.jfree.chart.block.BlockContainer();
        blockContainer6.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D9 = blockContainer6.getBounds();
        rectangleInsets5.trim(rectangle2D9);
        valueMarker3.setLabelOffset(rectangleInsets5);
        java.lang.String str12 = valueMarker3.getLabel();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(blockBorder4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(rectangle2D9);
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.Plot plot1 = multiplePiePlot0.getParent();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        multiplePiePlot0.markerChanged(markerChangeEvent2);
        boolean boolean4 = multiplePiePlot0.isOutlineVisible();
        float float5 = multiplePiePlot0.getBackgroundImageAlpha();
        org.junit.Assert.assertNull(plot1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.5f + "'", float5 == 0.5f);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D0.clearCategoryLabelToolTips();
        java.awt.Paint paint2 = categoryAxis3D0.getTickLabelPaint();
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        java.awt.Paint paint2 = ringPlot1.getSeparatorPaint();
        double double3 = ringPlot1.getMaximumExplodePercent();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        piePlot6.setSectionOutlinesVisible(true);
        java.awt.Paint paint9 = piePlot6.getBackgroundPaint();
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.image.ColorModel colorModel12 = null;
        java.awt.Rectangle rectangle13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.awt.geom.AffineTransform affineTransform15 = null;
        java.awt.RenderingHints renderingHints16 = null;
        java.awt.PaintContext paintContext17 = color11.createContext(colorModel12, rectangle13, rectangle2D14, affineTransform15, renderingHints16);
        piePlot6.setSectionPaint((java.lang.Comparable) (byte) 100, (java.awt.Paint) color11);
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor20 = null;
        org.jfree.chart.block.BlockContainer blockContainer23 = new org.jfree.chart.block.BlockContainer();
        blockContainer23.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D26 = blockContainer23.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double28 = categoryAxis19.getCategoryJava2DCoordinate(categoryAnchor20, (int) (byte) 10, 0, rectangle2D26, rectangleEdge27);
        piePlot6.setLegendItemShape((java.awt.Shape) rectangle2D26);
        org.jfree.chart.plot.PiePlot3D piePlot3D30 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D30.setBackgroundImageAlignment(1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        org.jfree.chart.plot.PiePlotState piePlotState35 = ringPlot1.initialise(graphics2D4, rectangle2D26, (org.jfree.chart.plot.PiePlot) piePlot3D30, (java.lang.Integer) 100, plotRenderingInfo34);
        ringPlot1.setSeparatorsVisible(true);
        double double38 = ringPlot1.getSectionDepth();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(paintContext17);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(piePlotState35);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.2d + "'", double38 == 0.2d);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.chart.PaintMap paintMap0 = new org.jfree.chart.PaintMap();
        boolean boolean2 = paintMap0.containsKey((java.lang.Comparable) 1.0E-5d);
        boolean boolean4 = paintMap0.containsKey((java.lang.Comparable) 1.05d);
        java.awt.Paint paint6 = paintMap0.getPaint((java.lang.Comparable) 0);
        java.lang.Comparable comparable7 = null;
        java.awt.Color color8 = java.awt.Color.black;
        try {
            paintMap0.put(comparable7, (java.awt.Paint) color8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        java.awt.Paint paint1 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker(35.0d, paint1, stroke2);
        float float4 = valueMarker3.getAlpha();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType5 = valueMarker3.getLabelOffsetType();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType6 = valueMarker3.getLabelOffsetType();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = valueMarker3.getLabelOffset();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = valueMarker3.getLabelAnchor();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot9 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot9.setLimit(1.0d);
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot9);
        org.jfree.chart.block.BlockContainer blockContainer13 = new org.jfree.chart.block.BlockContainer();
        blockContainer13.setWidth((double) 10.0f);
        org.jfree.chart.block.BlockBorder blockBorder16 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = blockBorder16.getInsets();
        blockContainer13.setMargin(rectangleInsets17);
        java.lang.String str19 = blockContainer13.getID();
        legendTitle12.setWrapper(blockContainer13);
        java.awt.geom.Rectangle2D rectangle2D21 = blockContainer13.getBounds();
        boolean boolean22 = blockContainer13.isEmpty();
        org.jfree.chart.block.BlockContainer blockContainer23 = new org.jfree.chart.block.BlockContainer();
        blockContainer23.setWidth((double) 10.0f);
        org.jfree.chart.block.BlockBorder blockBorder26 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = blockBorder26.getInsets();
        blockContainer23.setMargin(rectangleInsets27);
        java.lang.String str29 = blockContainer23.getID();
        org.jfree.chart.block.Arrangement arrangement30 = blockContainer23.getArrangement();
        blockContainer13.setArrangement(arrangement30);
        boolean boolean32 = rectangleAnchor8.equals((java.lang.Object) blockContainer13);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(lengthAdjustmentType5);
        org.junit.Assert.assertNotNull(lengthAdjustmentType6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertNotNull(blockBorder16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(blockBorder26);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(arrangement30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getCategoryMargin();
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) 100, "TextAnchor.CENTER_RIGHT");
        java.awt.Font font6 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        categoryAxis0.setTickLabelFont((java.lang.Comparable) (byte) 100, font6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.util.UnitType unitType12 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = new org.jfree.chart.util.RectangleInsets(unitType12, (double) (short) 100, (double) (byte) 0, (double) 0.0f, (double) '#');
        double double19 = rectangleInsets17.calculateBottomOutset((double) 1L);
        java.lang.String str20 = rectangleInsets17.toString();
        org.jfree.chart.block.BlockBorder blockBorder21 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = blockBorder21.getInsets();
        double double24 = rectangleInsets22.trimWidth((double) (byte) 10);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D25 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D25.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D25.setAutoRangeStickyZero(false);
        numberAxis3D25.setUpperBound(100.0d);
        float float32 = numberAxis3D25.getTickMarkOutsideLength();
        org.jfree.chart.block.BlockContainer blockContainer33 = new org.jfree.chart.block.BlockContainer();
        blockContainer33.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D36 = blockContainer33.getBounds();
        numberAxis3D25.setLeftArrow((java.awt.Shape) rectangle2D36);
        org.jfree.chart.entity.ChartEntity chartEntity39 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D36, "");
        java.awt.geom.Rectangle2D rectangle2D40 = rectangleInsets22.createOutsetRectangle(rectangle2D36);
        java.awt.geom.Rectangle2D rectangle2D41 = rectangleInsets17.createOutsetRectangle(rectangle2D36);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot42 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot42.setLimit(1.0d);
        org.jfree.chart.title.LegendTitle legendTitle45 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot42);
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = legendTitle45.getPosition();
        double double47 = numberAxis10.lengthToJava2D(10.0d, rectangle2D41, rectangleEdge46);
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = org.jfree.chart.util.RectangleEdge.TOP;
        boolean boolean49 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge48);
        double double50 = categoryAxis0.getCategoryStart((int) 'a', 64, rectangle2D41, rectangleEdge48);
        boolean boolean51 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge48);
        boolean boolean52 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge48);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(unitType12);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "RectangleInsets[t=100.0,l=0.0,b=0.0,r=35.0]" + "'", str20.equals("RectangleInsets[t=100.0,l=0.0,b=0.0,r=35.0]"));
        org.junit.Assert.assertNotNull(blockBorder21);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 10.0d + "'", double24 == 10.0d);
        org.junit.Assert.assertTrue("'" + float32 + "' != '" + 1.0f + "'", float32 == 1.0f);
        org.junit.Assert.assertNotNull(rectangle2D36);
        org.junit.Assert.assertNotNull(rectangle2D40);
        org.junit.Assert.assertNotNull(rectangle2D41);
        org.junit.Assert.assertNotNull(rectangleEdge46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 350.0d + "'", double47 == 350.0d);
        org.junit.Assert.assertNotNull(rectangleEdge48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 49.66059027777778d + "'", double50 == 49.66059027777778d);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D0.setAutoRangeStickyZero(false);
        numberAxis3D0.setLabel("ThreadContext");
        numberAxis3D0.setRange((double) 3, 10.0d);
        org.jfree.chart.axis.TickUnitSource tickUnitSource10 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        numberAxis3D0.setStandardTickUnits(tickUnitSource10);
        org.junit.Assert.assertNotNull(tickUnitSource10);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        java.awt.Paint paint1 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker(35.0d, paint1, stroke2);
        float float4 = valueMarker3.getAlpha();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType5 = valueMarker3.getLabelOffsetType();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType6 = valueMarker3.getLabelOffsetType();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = valueMarker3.getLabelOffset();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = valueMarker3.getLabelAnchor();
        double double9 = valueMarker3.getValue();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(lengthAdjustmentType5);
        org.junit.Assert.assertNotNull(lengthAdjustmentType6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 35.0d + "'", double9 == 35.0d);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        java.awt.Paint paint2 = ringPlot1.getSeparatorPaint();
        double double3 = ringPlot1.getMaximumExplodePercent();
        double double4 = ringPlot1.getInnerSeparatorExtension();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2d + "'", double4 == 0.2d);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot1.setLimit(1.0d);
        multiplePiePlot0.setParent((org.jfree.chart.plot.Plot) multiplePiePlot1);
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        boolean boolean6 = multiplePiePlot1.equals((java.lang.Object) color5);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        float[] floatArray8 = null;
        float[] floatArray9 = color7.getRGBComponents(floatArray8);
        float[] floatArray10 = color5.getComponents(floatArray8);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("hi!", "", "RectangleEdge.TOP", image3, "RectangleEdge.TOP", "", "RectangleEdge.TOP");
        projectInfo7.setVersion("TextAnchor.CENTER_RIGHT");
        java.awt.Image image13 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo17 = new org.jfree.chart.ui.ProjectInfo("hi!", "", "RectangleEdge.TOP", image13, "RectangleEdge.TOP", "", "RectangleEdge.TOP");
        projectInfo17.setVersion("TextAnchor.CENTER_RIGHT");
        projectInfo7.addLibrary((org.jfree.chart.ui.Library) projectInfo17);
        java.lang.String str21 = projectInfo17.getName();
        projectInfo17.setLicenceText("");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent24 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) projectInfo17);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D1.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D1.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, polarItemRenderer6);
        java.lang.String str8 = polarPlot7.getPlotType();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent9 = null;
        polarPlot7.datasetChanged(datasetChangeEvent9);
        java.awt.Stroke stroke11 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        polarPlot7.setRadiusGridlineStroke(stroke11);
        polarPlot7.setAngleLabelsVisible(false);
        java.awt.Paint paint15 = polarPlot7.getRadiusGridlinePaint();
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        polarPlot7.setAngleGridlinePaint((java.awt.Paint) color16);
        polarPlot7.clearCornerTextItems();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Polar Plot" + "'", str8.equals("Polar Plot"));
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(color16);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.Timeline timeline2 = dateAxis1.getTimeline();
        boolean boolean4 = dateAxis1.isHiddenValue((long) (byte) 1);
        org.jfree.chart.axis.Timeline timeline5 = dateAxis1.getTimeline();
        java.util.Date date6 = dateAxis1.getMaximumDate();
        dateAxis1.setRange((-1.0d), (-0.025d));
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = categoryPlot10.getDomainAxisEdge((int) (byte) 1);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = categoryPlot10.getAxisOffset();
        boolean boolean14 = dateAxis1.equals((java.lang.Object) rectangleInsets13);
        dateAxis1.setAutoRangeMinimumSize((double) 192, false);
        dateAxis1.setAutoTickUnitSelection(true, false);
        org.junit.Assert.assertNotNull(timeline2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeline5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("PlotOrientation.VERTICAL");
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha((float) (short) 1);
        double double4 = piePlot1.getLabelLinkMargin();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator5 = piePlot1.getLegendLabelURLGenerator();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.025d + "'", double4 == 0.025d);
        org.junit.Assert.assertNull(pieURLGenerator5);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.Timeline timeline2 = dateAxis1.getTimeline();
        boolean boolean4 = dateAxis1.isHiddenValue((long) (byte) 1);
        org.jfree.chart.axis.Timeline timeline5 = dateAxis1.getTimeline();
        java.util.Date date6 = dateAxis1.getMaximumDate();
        dateAxis1.setRange((-1.0d), (-0.025d));
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = categoryPlot10.getDomainAxisEdge((int) (byte) 1);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = categoryPlot10.getAxisOffset();
        boolean boolean14 = dateAxis1.equals((java.lang.Object) rectangleInsets13);
        org.jfree.chart.axis.DateTickUnit dateTickUnit15 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date16 = dateAxis1.calculateLowestVisibleTickValue(dateTickUnit15);
        org.junit.Assert.assertNotNull(timeline2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeline5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTickUnit15);
        org.junit.Assert.assertNotNull(date16);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        java.awt.Color color0 = java.awt.Color.YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getDomainAxisEdge((int) (byte) 1);
        org.jfree.chart.axis.AxisLocation axisLocation4 = categoryPlot0.getDomainAxisLocation(200);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis();
        org.jfree.chart.axis.ValueAxis valueAxis7 = categoryPlot0.getRangeAxisForDataset(10);
        int int8 = categoryPlot0.getDomainAxisCount();
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D11.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D11.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer16 = null;
        org.jfree.chart.plot.PolarPlot polarPlot17 = new org.jfree.chart.plot.PolarPlot(xYDataset10, (org.jfree.chart.axis.ValueAxis) numberAxis3D11, polarItemRenderer16);
        numberAxis3D11.zoomRange((double) (-1), (double) 100.0f);
        categoryPlot0.setRangeAxis((int) (byte) 10, (org.jfree.chart.axis.ValueAxis) numberAxis3D11, false);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D24 = new org.jfree.chart.axis.NumberAxis3D("RectangleAnchor.LEFT");
        numberAxis3D24.resizeRange((double) 0);
        int int27 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D24);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        java.lang.String str1 = licences0.getLGPL();
        java.lang.String str2 = licences0.getLGPL();
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setSectionOutlinesVisible(true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent4 = null;
        piePlot1.axisChanged(axisChangeEvent4);
        double double6 = piePlot1.getLabelGap();
        piePlot1.setLabelLinkMargin((double) 10L);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.025d + "'", double6 == 0.025d);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D3.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D3.setAutoRangeStickyZero(false);
        numberAxis3D3.setUpperBound(100.0d);
        float float10 = numberAxis3D3.getTickMarkOutsideLength();
        org.jfree.chart.block.BlockContainer blockContainer11 = new org.jfree.chart.block.BlockContainer();
        blockContainer11.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D14 = blockContainer11.getBounds();
        numberAxis3D3.setLeftArrow((java.awt.Shape) rectangle2D14);
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.plot.PiePlot piePlot17 = new org.jfree.chart.plot.PiePlot(pieDataset16);
        piePlot17.setSectionOutlinesVisible(true);
        java.awt.Paint paint20 = piePlot17.getBackgroundPaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        org.jfree.chart.plot.PiePlotState piePlotState23 = ringPlot1.initialise(graphics2D2, rectangle2D14, piePlot17, (java.lang.Integer) 3, plotRenderingInfo22);
        ringPlot1.setSectionDepth(0.0d);
        int int26 = ringPlot1.getPieIndex();
        ringPlot1.setOuterSeparatorExtension((-0.025d));
        double double29 = ringPlot1.getInnerSeparatorExtension();
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 1.0f + "'", float10 == 1.0f);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(piePlotState23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.2d + "'", double29 == 0.2d);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.Size2D size2D2 = blockContainer0.arrange(graphics2D1);
        size2D2.width = (short) -1;
        org.junit.Assert.assertNotNull(size2D2);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot1.getPieChart();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot4.setLimit(1.0d);
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot4);
        java.lang.Object obj8 = legendTitle7.clone();
        org.jfree.chart.util.UnitType unitType9 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = new org.jfree.chart.util.RectangleInsets(unitType9, (double) (short) 100, (double) (byte) 0, (double) 0.0f, (double) '#');
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = new org.jfree.chart.util.RectangleInsets(unitType9, (double) (-1L), 10.0d, (double) 0.0f, 0.0d);
        double double21 = rectangleInsets19.trimWidth((double) (byte) 0);
        legendTitle7.setPadding(rectangleInsets19);
        jFreeChart2.addSubtitle((int) (byte) 0, (org.jfree.chart.title.Title) legendTitle7);
        org.junit.Assert.assertNotNull(jFreeChart2);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(unitType9);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + (-10.0d) + "'", double21 == (-10.0d));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.util.UnitType unitType2 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = new org.jfree.chart.util.RectangleInsets(unitType2, (double) (short) 100, (double) (byte) 0, (double) 0.0f, (double) '#');
        double double9 = rectangleInsets7.calculateBottomOutset((double) 1L);
        java.lang.String str10 = rectangleInsets7.toString();
        org.jfree.chart.block.BlockBorder blockBorder11 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = blockBorder11.getInsets();
        double double14 = rectangleInsets12.trimWidth((double) (byte) 10);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D15 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D15.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D15.setAutoRangeStickyZero(false);
        numberAxis3D15.setUpperBound(100.0d);
        float float22 = numberAxis3D15.getTickMarkOutsideLength();
        org.jfree.chart.block.BlockContainer blockContainer23 = new org.jfree.chart.block.BlockContainer();
        blockContainer23.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D26 = blockContainer23.getBounds();
        numberAxis3D15.setLeftArrow((java.awt.Shape) rectangle2D26);
        org.jfree.chart.entity.ChartEntity chartEntity29 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D26, "");
        java.awt.geom.Rectangle2D rectangle2D30 = rectangleInsets12.createOutsetRectangle(rectangle2D26);
        java.awt.geom.Rectangle2D rectangle2D31 = rectangleInsets7.createOutsetRectangle(rectangle2D26);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot32 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot32.setLimit(1.0d);
        org.jfree.chart.title.LegendTitle legendTitle35 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot32);
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = legendTitle35.getPosition();
        double double37 = numberAxis0.lengthToJava2D(10.0d, rectangle2D31, rectangleEdge36);
        org.jfree.data.general.PieDataset pieDataset38 = null;
        java.lang.Comparable comparable41 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity44 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D31, pieDataset38, 200, 15, comparable41, "TextAnchor.BOTTOM_CENTER", "RectangleAnchor.LEFT");
        java.lang.Comparable comparable45 = pieSectionEntity44.getSectionKey();
        java.lang.Comparable comparable46 = pieSectionEntity44.getSectionKey();
        int int47 = pieSectionEntity44.getPieIndex();
        pieSectionEntity44.setSectionIndex(0);
        org.junit.Assert.assertNotNull(unitType2);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "RectangleInsets[t=100.0,l=0.0,b=0.0,r=35.0]" + "'", str10.equals("RectangleInsets[t=100.0,l=0.0,b=0.0,r=35.0]"));
        org.junit.Assert.assertNotNull(blockBorder11);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 10.0d + "'", double14 == 10.0d);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 1.0f + "'", float22 == 1.0f);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 350.0d + "'", double37 == 350.0d);
        org.junit.Assert.assertNull(comparable45);
        org.junit.Assert.assertNull(comparable46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 200 + "'", int47 == 200);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setSectionOutlinesVisible(true);
        java.awt.Paint paint4 = piePlot1.getBackgroundPaint();
        java.awt.Paint paint6 = piePlot1.getSectionOutlinePaint((java.lang.Comparable) 100.0f);
        piePlot1.setCircular(false, false);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = piePlot1.getLegendItems();
        double double11 = piePlot1.getStartAngle();
        piePlot1.setShadowXOffset(45.0d);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(legendItemCollection10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 90.0d + "'", double11 == 90.0d);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setSectionOutlinesVisible(true);
        double double4 = piePlot1.getInteriorGap();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        piePlot1.setDataset(pieDataset5);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.08d + "'", double4 == 0.08d);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getDomainAxisEdge((int) (byte) 1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryPlot0.getAxisOffset();
        categoryPlot0.clearRangeMarkers((int) (short) 1);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color1 = color0.darker();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("rect", "RectangleEdge.TOP", "ChartEntity: tooltip = ", "RectangleAnchor.LEFT", "VerticalAlignment.CENTER");
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.expandToInclude(range0, (-1.0d));
        boolean boolean4 = range2.contains((double) 1);
        org.jfree.data.Range range7 = org.jfree.data.Range.shift(range2, (double) 100, false);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.Plot plot9 = multiplePiePlot8.getParent();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        multiplePiePlot8.markerChanged(markerChangeEvent10);
        java.lang.Comparable comparable12 = multiplePiePlot8.getAggregatedItemsKey();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent13 = null;
        multiplePiePlot8.datasetChanged(datasetChangeEvent13);
        boolean boolean15 = range2.equals((java.lang.Object) multiplePiePlot8);
        org.jfree.data.Range range17 = org.jfree.data.Range.expandToInclude(range2, (double) (-1));
        double double18 = range17.getLowerBound();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNull(plot9);
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + "Other" + "'", comparable12.equals("Other"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + (-1.0d) + "'", double18 == (-1.0d));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getDomainAxisEdge((int) (byte) 1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryPlot0.getAxisOffset();
        boolean boolean4 = categoryPlot0.isRangeCrosshairVisible();
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot0.setRangeGridlineStroke(stroke5);
        boolean boolean7 = categoryPlot0.isDomainZoomable();
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D3.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D3.setAutoRangeStickyZero(false);
        numberAxis3D3.setUpperBound(100.0d);
        float float10 = numberAxis3D3.getTickMarkOutsideLength();
        org.jfree.chart.block.BlockContainer blockContainer11 = new org.jfree.chart.block.BlockContainer();
        blockContainer11.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D14 = blockContainer11.getBounds();
        numberAxis3D3.setLeftArrow((java.awt.Shape) rectangle2D14);
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.plot.PiePlot piePlot17 = new org.jfree.chart.plot.PiePlot(pieDataset16);
        piePlot17.setSectionOutlinesVisible(true);
        java.awt.Paint paint20 = piePlot17.getBackgroundPaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        org.jfree.chart.plot.PiePlotState piePlotState23 = ringPlot1.initialise(graphics2D2, rectangle2D14, piePlot17, (java.lang.Integer) 3, plotRenderingInfo22);
        ringPlot1.setSectionDepth(0.0d);
        ringPlot1.setLabelLinksVisible(false);
        java.awt.Paint paint28 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        ringPlot1.setLabelShadowPaint(paint28);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 1.0f + "'", float10 == 1.0f);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(piePlotState23);
        org.junit.Assert.assertNotNull(paint28);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit(1.0d);
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot0);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = legendTitle3.getVerticalAlignment();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = rectangleConstraint6.toFixedWidth((double) 200);
        org.jfree.chart.util.Size2D size2D9 = legendTitle3.arrange(graphics2D5, rectangleConstraint8);
        org.jfree.chart.block.BlockBorder blockBorder10 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = blockBorder10.getInsets();
        double double13 = rectangleInsets11.trimWidth((double) (byte) 10);
        double double14 = rectangleInsets11.getBottom();
        legendTitle3.setItemLabelPadding(rectangleInsets11);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent16 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle3);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = legendTitle3.getLegendItemGraphicEdge();
        double double18 = legendTitle3.getContentYOffset();
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = legendTitle3.getLegendItemGraphicEdge();
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(rectangleConstraint6);
        org.junit.Assert.assertNotNull(rectangleConstraint8);
        org.junit.Assert.assertNotNull(size2D9);
        org.junit.Assert.assertNotNull(blockBorder10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 10.0d + "'", double13 == 10.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleEdge19);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        java.awt.Color color0 = java.awt.Color.darkGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getDomainAxisEdge((int) (byte) 1);
        org.jfree.chart.axis.AxisLocation axisLocation4 = categoryPlot0.getDomainAxisLocation(200);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis();
        java.util.List list6 = categoryPlot0.getAnnotations();
        java.util.Collection collection7 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list6);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(collection7);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (short) 100, (double) (byte) 0, (double) 0.0f, (double) '#');
        double double7 = rectangleInsets5.calculateBottomOutset((double) 1L);
        java.lang.String str8 = rectangleInsets5.toString();
        org.jfree.chart.block.BlockBorder blockBorder9 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = blockBorder9.getInsets();
        double double12 = rectangleInsets10.trimWidth((double) (byte) 10);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D13 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D13.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D13.setAutoRangeStickyZero(false);
        numberAxis3D13.setUpperBound(100.0d);
        float float20 = numberAxis3D13.getTickMarkOutsideLength();
        org.jfree.chart.block.BlockContainer blockContainer21 = new org.jfree.chart.block.BlockContainer();
        blockContainer21.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D24 = blockContainer21.getBounds();
        numberAxis3D13.setLeftArrow((java.awt.Shape) rectangle2D24);
        org.jfree.chart.entity.ChartEntity chartEntity27 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D24, "");
        java.awt.geom.Rectangle2D rectangle2D28 = rectangleInsets10.createOutsetRectangle(rectangle2D24);
        java.awt.geom.Rectangle2D rectangle2D29 = rectangleInsets5.createOutsetRectangle(rectangle2D24);
        org.jfree.chart.entity.ChartEntity chartEntity30 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D24);
        java.lang.String str31 = chartEntity30.getShapeCoords();
        java.lang.String str32 = chartEntity30.getShapeType();
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "RectangleInsets[t=100.0,l=0.0,b=0.0,r=35.0]" + "'", str8.equals("RectangleInsets[t=100.0,l=0.0,b=0.0,r=35.0]"));
        org.junit.Assert.assertNotNull(blockBorder9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 10.0d + "'", double12 == 10.0d);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 1.0f + "'", float20 == 1.0f);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "0,0,1,1" + "'", str31.equals("0,0,1,1"));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "rect" + "'", str32.equals("rect"));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("hi!", "", "RectangleEdge.TOP", image3, "RectangleEdge.TOP", "", "RectangleEdge.TOP");
        java.awt.Image image8 = null;
        projectInfo7.setLogo(image8);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        java.awt.Font font5 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint6 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer9 = null;
        org.jfree.chart.text.TextBlock textBlock10 = org.jfree.chart.text.TextUtilities.createTextBlock("", font5, paint6, (float) (-1), 0, textMeasurer9);
        org.jfree.chart.block.BlockBorder blockBorder11 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, (double) (byte) 10, (double) 10L, (double) 255, paint6);
        java.awt.Paint paint12 = blockBorder11.getPaint();
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(textBlock10);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        org.jfree.chart.block.BlockBorder blockBorder1 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = blockBorder1.getInsets();
        double double4 = rectangleInsets2.trimWidth((double) (byte) 10);
        org.jfree.chart.util.UnitType unitType5 = rectangleInsets2.getUnitType();
        boolean boolean6 = strokeMap0.equals((java.lang.Object) rectangleInsets2);
        boolean boolean8 = strokeMap0.containsKey((java.lang.Comparable) "");
        java.lang.Object obj9 = strokeMap0.clone();
        org.junit.Assert.assertNotNull(blockBorder1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 10.0d + "'", double4 == 10.0d);
        org.junit.Assert.assertNotNull(unitType5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setSectionOutlinesVisible(true);
        java.awt.Paint paint4 = piePlot1.getBackgroundPaint();
        java.awt.Paint paint6 = piePlot1.getSectionOutlinePaint((java.lang.Comparable) 100.0f);
        java.awt.Stroke stroke7 = piePlot1.getLabelLinkStroke();
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        piePlot1.setSectionOutlineStroke((java.lang.Comparable) (byte) 100, stroke9);
        piePlot1.setSectionOutlinesVisible(false);
        java.awt.Paint paint13 = piePlot1.getOutlinePaint();
        boolean boolean14 = piePlot1.getIgnoreNullValues();
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        try {
            piePlot1.drawOutline(graphics2D15, rectangle2D16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setSectionOutlinesVisible(true);
        java.awt.Paint paint4 = piePlot1.getBackgroundPaint();
        java.awt.Paint paint6 = piePlot1.getSectionOutlinePaint((java.lang.Comparable) 100.0f);
        piePlot1.setCircular(true, false);
        double double10 = piePlot1.getLabelGap();
        piePlot1.setShadowYOffset(1.05d);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot13 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.Plot plot14 = multiplePiePlot13.getParent();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent15 = null;
        multiplePiePlot13.markerChanged(markerChangeEvent15);
        java.awt.Paint paint17 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        multiplePiePlot13.setNoDataMessagePaint(paint17);
        piePlot1.setShadowPaint(paint17);
        piePlot1.setLabelLinksVisible(false);
        boolean boolean22 = piePlot1.getSimpleLabels();
        double double23 = piePlot1.getLabelLinkMargin();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.025d + "'", double10 == 0.025d);
        org.junit.Assert.assertNull(plot14);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.025d + "'", double23 == 0.025d);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setSectionOutlinesVisible(true);
        java.awt.Paint paint4 = piePlot1.getBackgroundPaint();
        java.awt.Paint paint6 = piePlot1.getSectionOutlinePaint((java.lang.Comparable) 100.0f);
        piePlot1.setCircular(true, false);
        double double10 = piePlot1.getLabelGap();
        java.awt.Shape shape11 = piePlot1.getLegendItemShape();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.RingPlot ringPlot13 = new org.jfree.chart.plot.RingPlot(pieDataset12);
        java.awt.Paint paint14 = ringPlot13.getSeparatorPaint();
        piePlot1.setLabelBackgroundPaint(paint14);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier16 = piePlot1.getDrawingSupplier();
        org.jfree.chart.block.LineBorder lineBorder17 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke18 = lineBorder17.getStroke();
        piePlot1.setLabelLinkStroke(stroke18);
        java.awt.Image image20 = piePlot1.getBackgroundImage();
        double double21 = piePlot1.getShadowXOffset();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.025d + "'", double10 == 0.025d);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(drawingSupplier16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNull(image20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 4.0d + "'", double21 == 4.0d);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        double[] doubleArray5 = new double[] { (byte) 0, 0.2d, (-1.0d) };
        double[] doubleArray9 = new double[] { (byte) 0, 0.2d, (-1.0d) };
        double[] doubleArray13 = new double[] { (byte) 0, 0.2d, (-1.0d) };
        double[][] doubleArray14 = new double[][] { doubleArray5, doubleArray9, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("rect", "RectangleAnchor.BOTTOM_LEFT", doubleArray14);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset15);
        double double17 = range16.getLowerBound();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-1.0d) + "'", double17 == (-1.0d));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit(1.0d);
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot0);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = legendTitle3.getVerticalAlignment();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = legendTitle3.getLegendItemGraphicLocation();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        legendTitle3.setItemLabelPadding(rectangleInsets6);
        double double8 = legendTitle3.getContentYOffset();
        java.awt.Paint paint9 = null;
        try {
            legendTitle3.setItemPaint(paint9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.Timeline timeline2 = dateAxis1.getTimeline();
        boolean boolean4 = dateAxis1.isHiddenValue((long) (byte) 1);
        dateAxis1.configure();
        dateAxis1.setAutoRange(false);
        org.junit.Assert.assertNotNull(timeline2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        java.lang.String str1 = textBlockAnchor0.toString();
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextBlockAnchor.BOTTOM_RIGHT" + "'", str1.equals("TextBlockAnchor.BOTTOM_RIGHT"));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        java.awt.Color color0 = java.awt.Color.MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("PlotOrientation.VERTICAL");
        boolean boolean2 = numberAxis1.getAutoRangeStickyZero();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getRangeCrosshairValue();
        categoryPlot0.setRangeCrosshairVisible(false);
        java.lang.Object obj4 = categoryPlot0.clone();
        boolean boolean5 = categoryPlot0.isRangeZoomable();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getDomainAxisEdge((int) (byte) 1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryPlot0.getAxisOffset();
        boolean boolean4 = categoryPlot0.isRangeCrosshairVisible();
        java.awt.Stroke stroke5 = categoryPlot0.getRangeGridlineStroke();
        java.awt.Paint paint7 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker(35.0d, paint7, stroke8);
        float float10 = valueMarker9.getAlpha();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType11 = valueMarker9.getLabelOffsetType();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType12 = valueMarker9.getLabelOffsetType();
        org.jfree.chart.util.Layer layer13 = null;
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker9, layer13);
        double[] doubleArray20 = new double[] { (byte) 0, 0.2d, (-1.0d) };
        double[] doubleArray24 = new double[] { (byte) 0, 0.2d, (-1.0d) };
        double[] doubleArray28 = new double[] { (byte) 0, 0.2d, (-1.0d) };
        double[][] doubleArray29 = new double[][] { doubleArray20, doubleArray24, doubleArray28 };
        org.jfree.data.category.CategoryDataset categoryDataset30 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("rect", "RectangleAnchor.BOTTOM_LEFT", doubleArray29);
        org.jfree.data.Range range31 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset30);
        categoryPlot0.setDataset(categoryDataset30);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 1.0f + "'", float10 == 1.0f);
        org.junit.Assert.assertNotNull(lengthAdjustmentType11);
        org.junit.Assert.assertNotNull(lengthAdjustmentType12);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(categoryDataset30);
        org.junit.Assert.assertNotNull(range31);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        java.awt.Paint paint1 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker(35.0d, paint1, stroke2);
        org.jfree.chart.block.BlockBorder blockBorder4 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = blockBorder4.getInsets();
        org.jfree.chart.block.BlockContainer blockContainer6 = new org.jfree.chart.block.BlockContainer();
        blockContainer6.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D9 = blockContainer6.getBounds();
        rectangleInsets5.trim(rectangle2D9);
        valueMarker3.setLabelOffset(rectangleInsets5);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType12 = valueMarker3.getLabelOffsetType();
        org.jfree.chart.text.TextAnchor textAnchor13 = valueMarker3.getLabelTextAnchor();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = valueMarker3.getLabelOffset();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(blockBorder4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(rectangle2D9);
        org.junit.Assert.assertNotNull(lengthAdjustmentType12);
        org.junit.Assert.assertNotNull(textAnchor13);
        org.junit.Assert.assertNotNull(rectangleInsets14);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        java.awt.Color color0 = java.awt.Color.green;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.util.UnitType unitType2 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = new org.jfree.chart.util.RectangleInsets(unitType2, (double) (short) 100, (double) (byte) 0, (double) 0.0f, (double) '#');
        double double9 = rectangleInsets7.calculateBottomOutset((double) 1L);
        java.lang.String str10 = rectangleInsets7.toString();
        org.jfree.chart.block.BlockBorder blockBorder11 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = blockBorder11.getInsets();
        double double14 = rectangleInsets12.trimWidth((double) (byte) 10);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D15 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D15.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D15.setAutoRangeStickyZero(false);
        numberAxis3D15.setUpperBound(100.0d);
        float float22 = numberAxis3D15.getTickMarkOutsideLength();
        org.jfree.chart.block.BlockContainer blockContainer23 = new org.jfree.chart.block.BlockContainer();
        blockContainer23.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D26 = blockContainer23.getBounds();
        numberAxis3D15.setLeftArrow((java.awt.Shape) rectangle2D26);
        org.jfree.chart.entity.ChartEntity chartEntity29 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D26, "");
        java.awt.geom.Rectangle2D rectangle2D30 = rectangleInsets12.createOutsetRectangle(rectangle2D26);
        java.awt.geom.Rectangle2D rectangle2D31 = rectangleInsets7.createOutsetRectangle(rectangle2D26);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot32 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot32.setLimit(1.0d);
        org.jfree.chart.title.LegendTitle legendTitle35 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot32);
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = legendTitle35.getPosition();
        double double37 = numberAxis0.lengthToJava2D(10.0d, rectangle2D31, rectangleEdge36);
        org.jfree.data.general.PieDataset pieDataset38 = null;
        java.lang.Comparable comparable41 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity44 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D31, pieDataset38, 200, 15, comparable41, "TextAnchor.BOTTOM_CENTER", "RectangleAnchor.LEFT");
        java.lang.Comparable comparable45 = pieSectionEntity44.getSectionKey();
        java.lang.Comparable comparable46 = pieSectionEntity44.getSectionKey();
        int int47 = pieSectionEntity44.getSectionIndex();
        org.junit.Assert.assertNotNull(unitType2);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "RectangleInsets[t=100.0,l=0.0,b=0.0,r=35.0]" + "'", str10.equals("RectangleInsets[t=100.0,l=0.0,b=0.0,r=35.0]"));
        org.junit.Assert.assertNotNull(blockBorder11);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 10.0d + "'", double14 == 10.0d);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 1.0f + "'", float22 == 1.0f);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 350.0d + "'", double37 == 350.0d);
        org.junit.Assert.assertNull(comparable45);
        org.junit.Assert.assertNull(comparable46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 15 + "'", int47 == 15);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getDomainAxisEdge((int) (byte) 1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryPlot0.getAxisOffset();
        categoryPlot0.clearDomainAxes();
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D1.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D1.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, polarItemRenderer6);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = null;
        polarPlot7.datasetChanged(datasetChangeEvent8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        org.jfree.chart.block.BlockBorder blockBorder13 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = blockBorder13.getInsets();
        org.jfree.chart.block.BlockContainer blockContainer15 = new org.jfree.chart.block.BlockContainer();
        blockContainer15.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D18 = blockContainer15.getBounds();
        rectangleInsets14.trim(rectangle2D18);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor20 = null;
        java.awt.geom.Point2D point2D21 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D18, rectangleAnchor20);
        polarPlot7.zoomDomainAxes((double) (short) 10, (double) 10.0f, plotRenderingInfo12, point2D21);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer23 = polarPlot7.getRenderer();
        org.junit.Assert.assertNotNull(blockBorder13);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNotNull(point2D21);
        org.junit.Assert.assertNull(polarItemRenderer23);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("Rotation.CLOCKWISE");
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        org.jfree.chart.text.TextFragment textFragment1 = textLine0.getLastTextFragment();
        org.junit.Assert.assertNull(textFragment1);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getDomainAxisEdge((int) (byte) 1);
        org.jfree.chart.axis.AxisLocation axisLocation4 = categoryPlot0.getDomainAxisLocation(200);
        org.jfree.chart.util.Layer layer5 = null;
        java.util.Collection collection6 = categoryPlot0.getDomainMarkers(layer5);
        categoryPlot0.setRangeCrosshairValue(0.025d);
        java.awt.Paint paint11 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke12 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker(35.0d, paint11, stroke12);
        float float14 = valueMarker13.getAlpha();
        org.jfree.chart.util.Layer layer15 = null;
        try {
            boolean boolean16 = categoryPlot0.removeDomainMarker((int) '4', (org.jfree.chart.plot.Marker) valueMarker13, layer15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNull(collection6);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 1.0f + "'", float14 == 1.0f);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.Plot plot1 = multiplePiePlot0.getParent();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        multiplePiePlot0.markerChanged(markerChangeEvent2);
        java.lang.Comparable comparable4 = multiplePiePlot0.getAggregatedItemsKey();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        multiplePiePlot0.datasetChanged(datasetChangeEvent5);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = null;
        multiplePiePlot0.datasetChanged(datasetChangeEvent7);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        multiplePiePlot0.setDataset(categoryDataset9);
        java.lang.Comparable comparable11 = multiplePiePlot0.getAggregatedItemsKey();
        org.junit.Assert.assertNull(plot1);
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + "Other" + "'", comparable4.equals("Other"));
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + "Other" + "'", comparable11.equals("Other"));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D0.setAutoRangeStickyZero(false);
        numberAxis3D0.setLabel("ThreadContext");
        numberAxis3D0.setRange((double) 3, 10.0d);
        java.awt.Shape shape10 = numberAxis3D0.getDownArrow();
        java.awt.Font font12 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint13 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer16 = null;
        org.jfree.chart.text.TextBlock textBlock17 = org.jfree.chart.text.TextUtilities.createTextBlock("", font12, paint13, (float) (-1), 0, textMeasurer16);
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor21 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        java.awt.Shape shape25 = textBlock17.calculateBounds(graphics2D18, 0.0f, (float) 255, textBlockAnchor21, (float) (short) 0, (float) (byte) -1, (double) (short) 1);
        numberAxis3D0.setRightArrow(shape25);
        org.jfree.data.Range range27 = null;
        org.jfree.data.Range range29 = org.jfree.data.Range.expandToInclude(range27, (-1.0d));
        boolean boolean31 = range29.contains((double) 1);
        org.jfree.data.Range range34 = org.jfree.data.Range.shift(range29, (double) 100, false);
        org.jfree.data.Range range37 = org.jfree.data.Range.expand(range34, 0.0d, (double) (short) 0);
        numberAxis3D0.setRange(range34, false, false);
        boolean boolean41 = numberAxis3D0.isTickMarksVisible();
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(textBlock17);
        org.junit.Assert.assertNotNull(textBlockAnchor21);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(range34);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("{0}");
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        textTitle1.setBackgroundPaint((java.awt.Paint) color2);
        boolean boolean4 = textTitle1.getExpandToFitSpace();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D7.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D7.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer12 = null;
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) numberAxis3D7, polarItemRenderer12);
        double double14 = polarPlot13.getMaxRadius();
        org.jfree.chart.block.BlockContainer blockContainer17 = new org.jfree.chart.block.BlockContainer();
        blockContainer17.setWidth((double) 10.0f);
        org.jfree.chart.block.BlockBorder blockBorder20 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = blockBorder20.getInsets();
        blockContainer17.setMargin(rectangleInsets21);
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint24 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = rectangleConstraint24.toFixedWidth((double) 200);
        org.jfree.chart.util.Size2D size2D27 = blockContainer17.arrange(graphics2D23, rectangleConstraint26);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot28 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot28.setLimit(1.0d);
        org.jfree.chart.title.LegendTitle legendTitle31 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot28);
        org.jfree.chart.util.VerticalAlignment verticalAlignment32 = legendTitle31.getVerticalAlignment();
        java.awt.Graphics2D graphics2D33 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint34 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint36 = rectangleConstraint34.toFixedWidth((double) 200);
        org.jfree.chart.util.Size2D size2D37 = legendTitle31.arrange(graphics2D33, rectangleConstraint36);
        size2D37.height = 100.0f;
        org.jfree.chart.util.Size2D size2D40 = rectangleConstraint26.calculateConstrainedSize(size2D37);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor43 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.lang.String str44 = rectangleAnchor43.toString();
        java.awt.geom.Rectangle2D rectangle2D45 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D37, 0.0d, 0.4d, rectangleAnchor43);
        java.awt.Point point46 = polarPlot13.translateValueThetaRadiusToJava2D((double) 1.0f, (double) (short) 10, rectangle2D45);
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        double double48 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D45, rectangleEdge47);
        org.jfree.chart.plot.CategoryPlot categoryPlot49 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge51 = categoryPlot49.getDomainAxisEdge((int) (byte) 1);
        org.jfree.chart.axis.AxisLocation axisLocation53 = categoryPlot49.getDomainAxisLocation(200);
        boolean boolean54 = categoryPlot49.isRangeCrosshairLockedOnData();
        java.lang.Object obj55 = textTitle1.draw(graphics2D5, rectangle2D45, (java.lang.Object) boolean54);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.05d + "'", double14 == 1.05d);
        org.junit.Assert.assertNotNull(blockBorder20);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(rectangleConstraint24);
        org.junit.Assert.assertNotNull(rectangleConstraint26);
        org.junit.Assert.assertNotNull(size2D27);
        org.junit.Assert.assertNotNull(verticalAlignment32);
        org.junit.Assert.assertNotNull(rectangleConstraint34);
        org.junit.Assert.assertNotNull(rectangleConstraint36);
        org.junit.Assert.assertNotNull(size2D37);
        org.junit.Assert.assertNotNull(size2D40);
        org.junit.Assert.assertNotNull(rectangleAnchor43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "RectangleAnchor.LEFT" + "'", str44.equals("RectangleAnchor.LEFT"));
        org.junit.Assert.assertNotNull(rectangle2D45);
        org.junit.Assert.assertNotNull(point46);
        org.junit.Assert.assertNotNull(rectangleEdge47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 50.4d + "'", double48 == 50.4d);
        org.junit.Assert.assertNotNull(rectangleEdge51);
        org.junit.Assert.assertNotNull(axisLocation53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertNull(obj55);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.jfree.data.general.WaferMapDataset waferMapDataset2 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer3 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot4 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset2, waferMapRenderer3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) waferMapPlot4);
        float float6 = waferMapPlot4.getBackgroundAlpha();
        java.awt.Paint paint7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        waferMapPlot4.setBackgroundPaint(paint7);
        java.lang.Class<?> wildcardClass9 = waferMapPlot4.getClass();
        java.net.URL uRL10 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", (java.lang.Class) wildcardClass9);
        java.io.InputStream inputStream11 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("{0}", (java.lang.Class) wildcardClass9);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNull(uRL10);
        org.junit.Assert.assertNull(inputStream11);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        boolean boolean2 = numberAxis3D1.isAutoTickUnitSelection();
        boolean boolean3 = numberAxis3D1.isVerticalTickLabels();
        java.awt.Shape shape4 = numberAxis3D1.getLeftArrow();
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D6.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D6.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer11 = null;
        org.jfree.chart.plot.PolarPlot polarPlot12 = new org.jfree.chart.plot.PolarPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) numberAxis3D6, polarItemRenderer11);
        org.jfree.data.Range range13 = null;
        org.jfree.data.Range range15 = org.jfree.data.Range.expandToInclude(range13, (-1.0d));
        numberAxis3D6.setRangeWithMargins(range15);
        numberAxis3D1.setRange(range15);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer18 = null;
        org.jfree.chart.plot.PolarPlot polarPlot19 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, polarItemRenderer18);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer20 = polarPlot19.getRenderer();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNull(polarItemRenderer20);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getDomainAxisEdge((int) (byte) 1);
        org.jfree.chart.axis.AxisLocation axisLocation4 = categoryPlot0.getDomainAxisLocation(200);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot6.getDomainAxisEdge((int) (byte) 1);
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot6.getDomainAxisLocation(200);
        categoryPlot0.setRangeAxisLocation(64, axisLocation10, true);
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = categoryPlot0.getRangeAxisEdge(2);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = categoryPlot0.getRenderer(255);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertNull(categoryItemRenderer16);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("{0}");
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        textTitle1.setBackgroundPaint((java.awt.Paint) color2);
        boolean boolean4 = textTitle1.getExpandToFitSpace();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D7.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D7.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer12 = null;
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) numberAxis3D7, polarItemRenderer12);
        double double14 = polarPlot13.getMaxRadius();
        org.jfree.chart.block.BlockContainer blockContainer17 = new org.jfree.chart.block.BlockContainer();
        blockContainer17.setWidth((double) 10.0f);
        org.jfree.chart.block.BlockBorder blockBorder20 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = blockBorder20.getInsets();
        blockContainer17.setMargin(rectangleInsets21);
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint24 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = rectangleConstraint24.toFixedWidth((double) 200);
        org.jfree.chart.util.Size2D size2D27 = blockContainer17.arrange(graphics2D23, rectangleConstraint26);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot28 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot28.setLimit(1.0d);
        org.jfree.chart.title.LegendTitle legendTitle31 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot28);
        org.jfree.chart.util.VerticalAlignment verticalAlignment32 = legendTitle31.getVerticalAlignment();
        java.awt.Graphics2D graphics2D33 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint34 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint36 = rectangleConstraint34.toFixedWidth((double) 200);
        org.jfree.chart.util.Size2D size2D37 = legendTitle31.arrange(graphics2D33, rectangleConstraint36);
        size2D37.height = 100.0f;
        org.jfree.chart.util.Size2D size2D40 = rectangleConstraint26.calculateConstrainedSize(size2D37);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor43 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.lang.String str44 = rectangleAnchor43.toString();
        java.awt.geom.Rectangle2D rectangle2D45 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D37, 0.0d, 0.4d, rectangleAnchor43);
        java.awt.Point point46 = polarPlot13.translateValueThetaRadiusToJava2D((double) 1.0f, (double) (short) 10, rectangle2D45);
        textTitle1.draw(graphics2D5, rectangle2D45);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.05d + "'", double14 == 1.05d);
        org.junit.Assert.assertNotNull(blockBorder20);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(rectangleConstraint24);
        org.junit.Assert.assertNotNull(rectangleConstraint26);
        org.junit.Assert.assertNotNull(size2D27);
        org.junit.Assert.assertNotNull(verticalAlignment32);
        org.junit.Assert.assertNotNull(rectangleConstraint34);
        org.junit.Assert.assertNotNull(rectangleConstraint36);
        org.junit.Assert.assertNotNull(size2D37);
        org.junit.Assert.assertNotNull(size2D40);
        org.junit.Assert.assertNotNull(rectangleAnchor43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "RectangleAnchor.LEFT" + "'", str44.equals("RectangleAnchor.LEFT"));
        org.junit.Assert.assertNotNull(rectangle2D45);
        org.junit.Assert.assertNotNull(point46);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextLine textLine1 = textBlock0.getLastLine();
        org.junit.Assert.assertNull(textLine1);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.lang.Object obj2 = null;
        boolean boolean3 = dateAxis1.equals(obj2);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.Timeline timeline6 = dateAxis5.getTimeline();
        java.util.TimeZone timeZone7 = dateAxis5.getTimeZone();
        dateAxis1.setTimeZone(timeZone7);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition9 = dateAxis1.getTickMarkPosition();
        boolean boolean10 = dateAxis1.isVerticalTickLabels();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(timeline6);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(dateTickMarkPosition9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }
}

