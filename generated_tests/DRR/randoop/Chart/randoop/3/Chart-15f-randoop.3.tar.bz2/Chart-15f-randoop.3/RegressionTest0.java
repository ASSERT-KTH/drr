import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        java.awt.Font font1 = null;
        java.awt.Paint paint2 = null;
        try {
            org.jfree.chart.text.TextFragment textFragment3 = new org.jfree.chart.text.TextFragment("RectangleEdge.TOP", font1, paint2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("", timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.ChartEntity chartEntity1 = new org.jfree.chart.entity.ChartEntity(shape0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) 1.0d, 0.2d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.KeyToGroupMap keyToGroupMap1 = null;
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset0, keyToGroupMap1);
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        java.lang.String str5 = textAnchor4.toString();
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("hi!", graphics2D1, (float) (short) 10, 10.0f, textAnchor4, (double) '4', (float) 0L, 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "TextAnchor.CENTER_RIGHT" + "'", str5.equals("TextAnchor.CENTER_RIGHT"));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        java.awt.Shape shape0 = null;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        try {
            org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, (int) (byte) 10, (int) (byte) -1, (java.lang.Comparable) (-1L), "", "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        java.awt.Color color1 = java.awt.Color.getColor("");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        java.awt.Paint paint0 = null;
        java.awt.Stroke stroke1 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = null;
        try {
            org.jfree.chart.block.LineBorder lineBorder3 = new org.jfree.chart.block.LineBorder(paint0, stroke1, rectangleInsets2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        java.lang.String str0 = org.jfree.chart.ui.Licences.LGPL;
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.color.ColorSpace colorSpace1 = null;
        float[] floatArray4 = new float[] { 10.0f, (byte) -1 };
        try {
            float[] floatArray5 = color0.getColorComponents(colorSpace1, floatArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray4);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        java.util.Collection collection0 = null;
        try {
            java.util.Collection collection1 = org.jfree.chart.util.ObjectUtilities.deepClone(collection0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'collection' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        java.awt.Color color0 = java.awt.Color.white;
        java.awt.color.ColorSpace colorSpace1 = null;
        float[] floatArray2 = new float[] {};
        try {
            float[] floatArray3 = color0.getComponents(colorSpace1, floatArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray2);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockBorder0.getInsets();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            rectangleInsets1.trim(rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockBorder0);
        org.junit.Assert.assertNotNull(rectangleInsets1);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        java.awt.Color color2 = java.awt.Color.getColor("TextAnchor.CENTER_RIGHT", (int) (byte) -1);
        int int3 = color2.getRGB();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        java.awt.Color color0 = java.awt.Color.RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockBorder0.getInsets();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType3 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType4 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = rectangleInsets1.createAdjustedRectangle(rectangle2D2, lengthAdjustmentType3, lengthAdjustmentType4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(blockBorder0);
        org.junit.Assert.assertNotNull(rectangleInsets1);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        java.lang.Comparable[] comparableArray3 = new java.lang.Comparable[] { ' ', (-1), "Other" };
        java.lang.Comparable[] comparableArray4 = new java.lang.Comparable[] {};
        double[] doubleArray11 = new double[] { (byte) 1, (short) 1, 10, 10L, 10, (short) 1 };
        double[] doubleArray18 = new double[] { (byte) 1, (short) 1, 10, 10L, 10, (short) 1 };
        double[] doubleArray25 = new double[] { (byte) 1, (short) 1, 10, 10L, 10, (short) 1 };
        double[] doubleArray32 = new double[] { (byte) 1, (short) 1, 10, 10L, 10, (short) 1 };
        double[] doubleArray39 = new double[] { (byte) 1, (short) 1, 10, 10L, 10, (short) 1 };
        double[] doubleArray46 = new double[] { (byte) 1, (short) 1, 10, 10L, 10, (short) 1 };
        double[][] doubleArray47 = new double[][] { doubleArray11, doubleArray18, doubleArray25, doubleArray32, doubleArray39, doubleArray46 };
        try {
            org.jfree.data.category.CategoryDataset categoryDataset48 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray3, comparableArray4, doubleArray47);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of row keys does not match the number of rows in the data array.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray3);
        org.junit.Assert.assertNotNull(comparableArray4);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        java.lang.String str0 = org.jfree.chart.ui.Licences.GPL;
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset0, (java.lang.Comparable) 10.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setOutlineVisible(false);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        java.awt.Color color0 = java.awt.Color.white;
        int int1 = color0.getGreen();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset0, (java.lang.Comparable) "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_VERTICAL_TICK_LABELS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        java.awt.Color color0 = java.awt.Color.GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

//    @Test
//    public void test037() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test037");
//        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
//        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
//    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) (byte) 100, (-1.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        java.lang.ClassLoader classLoader0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
        org.junit.Assert.assertNull(classLoader0);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(xYDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("TextAnchor.CENTER_RIGHT", "", "ThreadContext", "hi!");
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape0, "Other", "RectangleEdge.TOP");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("TextAnchor.CENTER_RIGHT", "ChartChangeEventType.DATASET_UPDATED");
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockBorder0.getInsets();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = rectangleInsets1.createInsetRectangle(rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(blockBorder0);
        org.junit.Assert.assertNotNull(rectangleInsets1);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockBorder0.getInsets();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = rectangleInsets1.createInsetRectangle(rectangle2D2, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(blockBorder0);
        org.junit.Assert.assertNotNull(rectangleInsets1);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.data.KeyedValues keyedValues1 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) "", keyedValues1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowData' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("Other", graphics2D1, 0.0f, (float) (short) 100, 100.0d, (float) 10L, (float) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        java.awt.Paint paint0 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        try {
            org.jfree.data.Range range2 = new org.jfree.data.Range((double) (byte) 100, (double) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (100.0) <= upper (-1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, (double) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLowerMargin((double) (short) 100);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = org.jfree.chart.util.RectangleEdge.LEFT;
        try {
            double double7 = categoryAxis0.getCategoryMiddle(0, (int) (short) 1, rectangle2D5, rectangleEdge6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge6);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) blockBorder0, jFreeChart1);
        org.jfree.chart.JFreeChart jFreeChart3 = null;
        chartChangeEvent2.setChart(jFreeChart3);
        org.junit.Assert.assertNotNull(blockBorder0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.plot.Plot plot3 = multiplePiePlot0.getParent();
        try {
            java.awt.Paint paint4 = plot3.getOutlinePaint();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(plot3);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation1);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        java.lang.Class class1 = null;
        java.lang.Class class2 = null;
        java.lang.Object obj3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ThreadContext", class1, class2);
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        java.awt.Paint paint0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        java.awt.Color color1 = java.awt.Color.GRAY;
        java.awt.Color color2 = java.awt.Color.getColor("RectangleEdge.TOP", color1);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        java.lang.ClassLoader classLoader0 = null;
        try {
            java.util.ResourceBundle.clearCache(classLoader0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit(1.0d);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        multiplePiePlot0.addChangeListener(plotChangeListener3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        multiplePiePlot0.drawBackgroundImage(graphics2D5, rectangle2D6);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextLine textLine1 = null;
        textBlock0.addLine(textLine1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor6 = null;
        try {
            java.awt.Shape shape10 = textBlock0.calculateBounds(graphics2D3, (float) 'a', (float) ' ', textBlockAnchor6, 0.0f, (float) 0, (double) 255);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("Other", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockBorder0.getInsets();
        java.lang.String str2 = rectangleInsets1.toString();
        org.junit.Assert.assertNotNull(blockBorder0);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str2.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_INSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0 == 0.0f);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        java.awt.Color color0 = java.awt.Color.cyan;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        int int0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALIGNMENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        boolean boolean4 = numberAxis3D3.isAutoTickUnitSelection();
        boolean boolean5 = numberAxis3D3.isVerticalTickLabels();
        try {
            java.lang.Object obj6 = blockContainer0.draw(graphics2D1, rectangle2D2, (java.lang.Object) boolean5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        java.awt.Color color0 = java.awt.Color.pink;
        int int1 = color0.getRed();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (short) 100, (double) (byte) 0, (double) 0.0f, (double) '#');
        double double7 = rectangleInsets5.calculateBottomOutset((double) 1L);
        java.lang.String str8 = rectangleInsets5.toString();
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D10 = rectangleInsets5.createInsetRectangle(rectangle2D9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "RectangleInsets[t=100.0,l=0.0,b=0.0,r=35.0]" + "'", str8.equals("RectangleInsets[t=100.0,l=0.0,b=0.0,r=35.0]"));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        boolean boolean1 = numberAxis3D0.isNegativeArrowVisible();
        org.jfree.data.Range range2 = null;
        org.jfree.data.Range range4 = org.jfree.data.Range.expandToInclude(range2, (-1.0d));
        try {
            numberAxis3D0.setRangeWithMargins(range2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(range4);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.Plot plot1 = multiplePiePlot0.getParent();
        java.awt.Color color2 = java.awt.Color.GRAY;
        try {
            plot1.setBackgroundPaint((java.awt.Paint) color2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(plot1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D0.resizeRange((double) 1, (double) 1);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot7 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot7.setLimit(1.0d);
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        multiplePiePlot7.addChangeListener(plotChangeListener10);
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = org.jfree.chart.util.RectangleEdge.LEFT;
        java.lang.Object obj14 = null;
        boolean boolean15 = rectangleEdge13.equals(obj14);
        org.jfree.chart.axis.AxisSpace axisSpace16 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace17 = numberAxis3D0.reserveSpace(graphics2D6, (org.jfree.chart.plot.Plot) multiplePiePlot7, rectangle2D12, rectangleEdge13, axisSpace16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        boolean boolean1 = blockParams0.getGenerateEntities();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit(1.0d);
        multiplePiePlot0.setLimit((double) 255);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("TextAnchor.CENTER_RIGHT", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("ThreadContext", graphics2D1, (double) (byte) 10, (float) 255, (float) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("ThreadContext");
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        boolean boolean1 = numberAxis3D0.isAutoTickUnitSelection();
        boolean boolean2 = numberAxis3D0.isVisible();
        try {
            numberAxis3D0.zoomRange((double) (byte) 100, (double) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (100.0) <= upper (35.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("hi!", "", "RectangleEdge.TOP", image3, "RectangleEdge.TOP", "", "RectangleEdge.TOP");
        projectInfo7.setVersion("TextAnchor.CENTER_RIGHT");
        java.awt.Image image13 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo17 = new org.jfree.chart.ui.ProjectInfo("hi!", "", "RectangleEdge.TOP", image13, "RectangleEdge.TOP", "", "RectangleEdge.TOP");
        projectInfo17.setVersion("TextAnchor.CENTER_RIGHT");
        projectInfo7.addLibrary((org.jfree.chart.ui.Library) projectInfo17);
        java.lang.String str21 = projectInfo17.getLicenceName();
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        int int3 = java.awt.Color.HSBtoRGB((float) 10, 0.0f, (float) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot1.getPieChart();
        int int3 = jFreeChart2.getSubtitleCount();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer();
        blockContainer5.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D8 = blockContainer5.getBounds();
        try {
            jFreeChart2.draw(graphics2D4, rectangle2D8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(rectangle2D8);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        java.awt.Font font2 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer6 = null;
        org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, paint3, (float) (-1), 0, textMeasurer6);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        multiplePiePlot8.removeChangeListener(plotChangeListener9);
        org.jfree.chart.plot.Plot plot11 = multiplePiePlot8.getParent();
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("ThreadContext", font2, (org.jfree.chart.plot.Plot) multiplePiePlot8, false);
        org.jfree.chart.title.LegendTitle legendTitle14 = jFreeChart13.getLegend();
        try {
            org.jfree.chart.plot.XYPlot xYPlot15 = jFreeChart13.getXYPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.MultiplePiePlot cannot be cast to org.jfree.chart.plot.XYPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(textBlock7);
        org.junit.Assert.assertNull(plot11);
        org.junit.Assert.assertNull(legendTitle14);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        java.awt.Stroke stroke2 = strokeMap0.getStroke((java.lang.Comparable) 10.0f);
        org.junit.Assert.assertNull(stroke2);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABELS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.chart.title.Title title0 = null;
        try {
            org.jfree.chart.event.TitleChangeEvent titleChangeEvent1 = new org.jfree.chart.event.TitleChangeEvent(title0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        java.awt.Font font2 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer6 = null;
        org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, paint3, (float) (-1), 0, textMeasurer6);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        multiplePiePlot8.removeChangeListener(plotChangeListener9);
        org.jfree.chart.plot.Plot plot11 = multiplePiePlot8.getParent();
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("ThreadContext", font2, (org.jfree.chart.plot.Plot) multiplePiePlot8, false);
        org.jfree.chart.title.LegendTitle legendTitle14 = jFreeChart13.getLegend();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent15 = null;
        try {
            jFreeChart13.plotChanged(plotChangeEvent15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(textBlock7);
        org.junit.Assert.assertNull(plot11);
        org.junit.Assert.assertNull(legendTitle14);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        blockContainer0.setWidth((double) 10.0f);
        org.jfree.chart.block.BlockBorder blockBorder3 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = blockBorder3.getInsets();
        blockContainer0.setMargin(rectangleInsets4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor8 = null;
        org.jfree.chart.block.BlockContainer blockContainer11 = new org.jfree.chart.block.BlockContainer();
        blockContainer11.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D14 = blockContainer11.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double16 = categoryAxis7.getCategoryJava2DCoordinate(categoryAnchor8, (int) (byte) 10, 0, rectangle2D14, rectangleEdge15);
        try {
            blockContainer0.draw(graphics2D6, rectangle2D14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockBorder3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.block.BlockContainer blockContainer2 = new org.jfree.chart.block.BlockContainer();
        blockContainer2.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D5 = blockContainer2.getBounds();
        try {
            blockBorder0.draw(graphics2D1, rectangle2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockBorder0);
        org.junit.Assert.assertNotNull(rectangle2D5);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_FINISHED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_STARTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.Plot plot1 = multiplePiePlot0.getParent();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        multiplePiePlot0.markerChanged(markerChangeEvent2);
        java.lang.Comparable comparable4 = multiplePiePlot0.getAggregatedItemsKey();
        try {
            multiplePiePlot0.setBackgroundImageAlpha(10.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(plot1);
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + "Other" + "'", comparable4.equals("Other"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        java.lang.Object obj1 = null;
        boolean boolean2 = columnArrangement0.equals(obj1);
        org.jfree.chart.block.BlockContainer blockContainer3 = new org.jfree.chart.block.BlockContainer();
        blockContainer3.setWidth((double) 10.0f);
        org.jfree.chart.block.BlockBorder blockBorder6 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = blockBorder6.getInsets();
        blockContainer3.setMargin(rectangleInsets7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = null;
        try {
            org.jfree.chart.util.Size2D size2D11 = columnArrangement0.arrange(blockContainer3, graphics2D9, rectangleConstraint10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(blockBorder6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        java.awt.Font font2 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer6 = null;
        org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, paint3, (float) (-1), 0, textMeasurer6);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        multiplePiePlot8.removeChangeListener(plotChangeListener9);
        org.jfree.chart.plot.Plot plot11 = multiplePiePlot8.getParent();
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("ThreadContext", font2, (org.jfree.chart.plot.Plot) multiplePiePlot8, false);
        org.jfree.chart.title.LegendTitle legendTitle14 = jFreeChart13.getLegend();
        try {
            org.jfree.chart.title.Title title16 = jFreeChart13.getSubtitle((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(textBlock7);
        org.junit.Assert.assertNull(plot11);
        org.junit.Assert.assertNull(legendTitle14);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        java.lang.Comparable[] comparableArray0 = null;
        java.lang.Comparable[] comparableArray3 = new java.lang.Comparable[] { 100.0f, (byte) 10 };
        double[] doubleArray10 = new double[] { 1L, (byte) 0, 100, (byte) -1, (byte) 0, (short) 1 };
        double[] doubleArray17 = new double[] { 1L, (byte) 0, 100, (byte) -1, (byte) 0, (short) 1 };
        double[] doubleArray24 = new double[] { 1L, (byte) 0, 100, (byte) -1, (byte) 0, (short) 1 };
        double[] doubleArray31 = new double[] { 1L, (byte) 0, 100, (byte) -1, (byte) 0, (short) 1 };
        double[][] doubleArray32 = new double[][] { doubleArray10, doubleArray17, doubleArray24, doubleArray31 };
        try {
            org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray0, comparableArray3, doubleArray32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowKeys' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_STICKY_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("hi!", "", "RectangleEdge.TOP", image3, "RectangleEdge.TOP", "", "RectangleEdge.TOP");
        projectInfo7.setVersion("TextAnchor.CENTER_RIGHT");
        java.awt.Image image13 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo17 = new org.jfree.chart.ui.ProjectInfo("hi!", "", "RectangleEdge.TOP", image13, "RectangleEdge.TOP", "", "RectangleEdge.TOP");
        projectInfo17.setVersion("TextAnchor.CENTER_RIGHT");
        projectInfo7.addLibrary((org.jfree.chart.ui.Library) projectInfo17);
        java.awt.Image image21 = projectInfo17.getLogo();
        org.junit.Assert.assertNull(image21);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        boolean boolean1 = numberAxis3D0.isAutoTickUnitSelection();
        boolean boolean2 = numberAxis3D0.isVisible();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = null;
        try {
            numberAxis3D0.setTickUnit(numberTickUnit3, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unit' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) "RectangleInsets[t=100.0,l=0.0,b=0.0,r=35.0]", 10.0d, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        blockContainer0.setWidth((double) 10.0f);
        org.jfree.chart.block.BlockBorder blockBorder3 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = blockBorder3.getInsets();
        blockContainer0.setMargin(rectangleInsets4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D7.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D7.setAutoRangeStickyZero(false);
        numberAxis3D7.setUpperBound(100.0d);
        float float14 = numberAxis3D7.getTickMarkOutsideLength();
        org.jfree.chart.block.BlockContainer blockContainer15 = new org.jfree.chart.block.BlockContainer();
        blockContainer15.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D18 = blockContainer15.getBounds();
        numberAxis3D7.setLeftArrow((java.awt.Shape) rectangle2D18);
        try {
            blockContainer0.draw(graphics2D6, rectangle2D18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockBorder3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 1.0f + "'", float14 == 1.0f);
        org.junit.Assert.assertNotNull(rectangle2D18);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor10 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        java.awt.Shape shape11 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", graphics2D5, 0.0f, 0.0f, textAnchor8, (double) 100L, textAnchor10);
        org.jfree.chart.text.TextAnchor textAnchor13 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("RectangleInsets[t=100.0,l=0.0,b=0.0,r=35.0]", graphics2D1, 0.0f, 0.0f, textAnchor10, (double) 10.0f, textAnchor13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertNotNull(textAnchor10);
        org.junit.Assert.assertNull(shape11);
        org.junit.Assert.assertNotNull(textAnchor13);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset0, (double) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setSectionOutlinesVisible(true);
        java.awt.Paint paint4 = piePlot1.getBackgroundPaint();
        java.awt.Paint paint6 = piePlot1.getSectionOutlinePaint((java.lang.Comparable) 100.0f);
        piePlot1.setCircular(true, false);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator10 = piePlot1.getToolTipGenerator();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNull(pieToolTipGenerator10);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.lang.String str1 = rectangleAnchor0.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleAnchor.BOTTOM_LEFT" + "'", str1.equals("RectangleAnchor.BOTTOM_LEFT"));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha((float) (short) 1);
        double double4 = piePlot1.getLabelLinkMargin();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor5 = null;
        try {
            piePlot1.setLabelDistributor(abstractPieLabelDistributor5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'distributor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.025d + "'", double4 == 0.025d);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("hi!", "", "RectangleEdge.TOP", image3, "RectangleEdge.TOP", "", "RectangleEdge.TOP");
        projectInfo7.setVersion("TextAnchor.CENTER_RIGHT");
        java.awt.Image image13 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo17 = new org.jfree.chart.ui.ProjectInfo("hi!", "", "RectangleEdge.TOP", image13, "RectangleEdge.TOP", "", "RectangleEdge.TOP");
        projectInfo17.setVersion("TextAnchor.CENTER_RIGHT");
        projectInfo7.addLibrary((org.jfree.chart.ui.Library) projectInfo17);
        org.jfree.chart.ui.Library[] libraryArray21 = projectInfo7.getOptionalLibraries();
        org.junit.Assert.assertNotNull(libraryArray21);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        java.lang.Object obj1 = strokeMap0.clone();
        strokeMap0.clear();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D0.setAutoRangeStickyZero(false);
        numberAxis3D0.setUpperBound(100.0d);
        float float7 = numberAxis3D0.getTickMarkOutsideLength();
        org.jfree.chart.block.BlockContainer blockContainer8 = new org.jfree.chart.block.BlockContainer();
        blockContainer8.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D11 = blockContainer8.getBounds();
        numberAxis3D0.setLeftArrow((java.awt.Shape) rectangle2D11);
        org.jfree.chart.entity.ChartEntity chartEntity14 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D11, "");
        java.lang.Object obj15 = chartEntity14.clone();
        java.lang.String str16 = chartEntity14.getShapeType();
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "rect" + "'", str16.equals("rect"));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        java.awt.Font font0 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (short) 100, (double) (byte) 0, (double) 0.0f, (double) '#');
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (-1L), 10.0d, (double) 0.0f, 0.0d);
        double double12 = rectangleInsets10.calculateTopInset((double) 0L);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.0d) + "'", double12 == (-1.0d));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation1);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setSectionOutlinesVisible(true);
        java.awt.Paint paint4 = piePlot1.getBackgroundPaint();
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder(paint4);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.getUseFontMetricsGetStringBounds();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("rect", "TextAnchor.CENTER_RIGHT", "ThreadContext", "RectangleEdge.TOP");
        org.jfree.chart.ui.Library[] libraryArray5 = basicProjectInfo4.getLibraries();
        org.junit.Assert.assertNotNull(libraryArray5);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset0, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) 3, (double) '4', rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor3);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.CENTER;
        java.awt.Paint paint1 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        boolean boolean2 = verticalAlignment0.equals((java.lang.Object) paint1);
        java.lang.String str3 = verticalAlignment0.toString();
        org.junit.Assert.assertNotNull(verticalAlignment0);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "VerticalAlignment.CENTER" + "'", str3.equals("VerticalAlignment.CENTER"));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.junit.Assert.assertNotNull(plotOrientation0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D0.setAutoRangeStickyZero(false);
        numberAxis3D0.setUpperBound(100.0d);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand7 = numberAxis3D0.getMarkerBand();
        numberAxis3D0.setLabel("RectangleInsets[t=100.0,l=0.0,b=0.0,r=35.0]");
        org.junit.Assert.assertNull(markerAxisBand7);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D1.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D1.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, polarItemRenderer6);
        double double8 = polarPlot7.getMaxRadius();
        org.jfree.chart.axis.TickUnit tickUnit9 = null;
        try {
            polarPlot7.setAngleTickUnit(tickUnit9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unit' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.05d + "'", double8 == 1.05d);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D0.setAutoRangeStickyZero(false);
        numberAxis3D0.setUpperBound(100.0d);
        float float7 = numberAxis3D0.getTickMarkOutsideLength();
        org.jfree.chart.block.BlockContainer blockContainer8 = new org.jfree.chart.block.BlockContainer();
        blockContainer8.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D11 = blockContainer8.getBounds();
        numberAxis3D0.setLeftArrow((java.awt.Shape) rectangle2D11);
        org.jfree.chart.entity.ChartEntity chartEntity14 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D11, "");
        chartEntity14.setURLText("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
        org.junit.Assert.assertNotNull(rectangle2D11);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_INVERTED;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        java.awt.Color color2 = java.awt.Color.getColor("TextAnchor.CENTER_RIGHT", (int) (byte) -1);
        int int3 = color2.getAlpha();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 255 + "'", int3 == 255);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        java.util.Locale locale1 = null;
        java.lang.Class class2 = null;
        java.lang.ClassLoader classLoader3 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class2);
        java.util.ResourceBundle.Control control4 = null;
        try {
            java.util.ResourceBundle resourceBundle5 = java.util.ResourceBundle.getBundle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", locale1, classLoader3, control4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(classLoader3);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.THREAD_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        java.awt.Color color1 = java.awt.Color.getColor("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D1.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D1.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, polarItemRenderer6);
        double double8 = polarPlot7.getMaxRadius();
        org.jfree.chart.LegendItemCollection legendItemCollection9 = polarPlot7.getLegendItems();
        try {
            org.jfree.chart.LegendItem legendItem11 = legendItemCollection9.get((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.05d + "'", double8 == 1.05d);
        org.junit.Assert.assertNotNull(legendItemCollection9);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        java.awt.Color color0 = java.awt.Color.yellow;
        float[] floatArray3 = new float[] { 0.5f, (-1) };
        try {
            float[] floatArray4 = color0.getComponents(floatArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray3);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        blockContainer0.setWidth((double) 10.0f);
        org.jfree.chart.block.BlockBorder blockBorder3 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = blockBorder3.getInsets();
        blockContainer0.setMargin(rectangleInsets4);
        org.jfree.chart.block.BlockContainer blockContainer6 = new org.jfree.chart.block.BlockContainer();
        blockContainer6.setWidth((double) 10.0f);
        org.jfree.chart.block.BlockBorder blockBorder9 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = blockBorder9.getInsets();
        blockContainer6.setMargin(rectangleInsets10);
        blockContainer0.setMargin(rectangleInsets10);
        org.junit.Assert.assertNotNull(blockBorder3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(blockBorder9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        float[] floatArray1 = null;
        float[] floatArray2 = color0.getRGBComponents(floatArray1);
        int int3 = color0.getAlpha();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 255 + "'", int3 == 255);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset0, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("hi!", "", "RectangleEdge.TOP", image3, "RectangleEdge.TOP", "", "RectangleEdge.TOP");
        projectInfo7.setVersion("TextAnchor.CENTER_RIGHT");
        java.awt.Image image13 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo17 = new org.jfree.chart.ui.ProjectInfo("hi!", "", "RectangleEdge.TOP", image13, "RectangleEdge.TOP", "", "RectangleEdge.TOP");
        projectInfo17.setVersion("TextAnchor.CENTER_RIGHT");
        projectInfo7.addLibrary((org.jfree.chart.ui.Library) projectInfo17);
        java.awt.Image image21 = null;
        projectInfo7.setLogo(image21);
        projectInfo7.addOptionalLibrary("rect");
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        java.awt.Font font2 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer6 = null;
        org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, paint3, (float) (-1), 0, textMeasurer6);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        multiplePiePlot8.removeChangeListener(plotChangeListener9);
        org.jfree.chart.plot.Plot plot11 = multiplePiePlot8.getParent();
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("ThreadContext", font2, (org.jfree.chart.plot.Plot) multiplePiePlot8, false);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D15 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D15.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D15.setAutoRangeStickyZero(false);
        numberAxis3D15.setUpperBound(100.0d);
        float float22 = numberAxis3D15.getTickMarkOutsideLength();
        org.jfree.chart.block.BlockContainer blockContainer23 = new org.jfree.chart.block.BlockContainer();
        blockContainer23.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D26 = blockContainer23.getBounds();
        numberAxis3D15.setLeftArrow((java.awt.Shape) rectangle2D26);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo28 = null;
        try {
            jFreeChart13.draw(graphics2D14, rectangle2D26, chartRenderingInfo28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(textBlock7);
        org.junit.Assert.assertNull(plot11);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 1.0f + "'", float22 == 1.0f);
        org.junit.Assert.assertNotNull(rectangle2D26);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType1 = rectangleConstraint0.getWidthConstraintType();
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertNotNull(lengthConstraintType1);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("hi!", "", "RectangleEdge.TOP", image3, "RectangleEdge.TOP", "", "RectangleEdge.TOP");
        projectInfo7.setVersion("TextAnchor.CENTER_RIGHT");
        projectInfo7.setInfo("RectangleInsets[t=100.0,l=0.0,b=0.0,r=35.0]");
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setSectionOutlinesVisible(true);
        java.awt.Paint paint4 = piePlot1.getBackgroundPaint();
        piePlot1.setOutlineVisible(false);
        try {
            piePlot1.setBackgroundImageAlpha((float) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(false);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.Plot plot1 = multiplePiePlot0.getParent();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        multiplePiePlot0.markerChanged(markerChangeEvent2);
        java.lang.Comparable comparable4 = multiplePiePlot0.getAggregatedItemsKey();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        multiplePiePlot0.datasetChanged(datasetChangeEvent5);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = null;
        multiplePiePlot0.datasetChanged(datasetChangeEvent7);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent9 = null;
        multiplePiePlot0.notifyListeners(plotChangeEvent9);
        org.junit.Assert.assertNull(plot1);
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + "Other" + "'", comparable4.equals("Other"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        java.awt.Font font3 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint4 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer7 = null;
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("", font3, paint4, (float) (-1), 0, textMeasurer7);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot9 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        multiplePiePlot9.removeChangeListener(plotChangeListener10);
        org.jfree.chart.plot.Plot plot12 = multiplePiePlot9.getParent();
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("ThreadContext", font3, (org.jfree.chart.plot.Plot) multiplePiePlot9, false);
        java.awt.Paint paint15 = null;
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer19 = new org.jfree.chart.text.G2TextMeasurer(graphics2D18);
        try {
            org.jfree.chart.text.TextBlock textBlock20 = org.jfree.chart.text.TextUtilities.createTextBlock("Other", font3, paint15, (float) ' ', 2, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertNull(plot12);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        java.awt.Font font2 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer6 = null;
        org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, paint3, (float) (-1), 0, textMeasurer6);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        multiplePiePlot8.removeChangeListener(plotChangeListener9);
        org.jfree.chart.plot.Plot plot11 = multiplePiePlot8.getParent();
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("ThreadContext", font2, (org.jfree.chart.plot.Plot) multiplePiePlot8, false);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D15 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D15.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D15.setAutoRangeStickyZero(false);
        numberAxis3D15.setUpperBound(100.0d);
        float float22 = numberAxis3D15.getTickMarkOutsideLength();
        org.jfree.chart.block.BlockContainer blockContainer23 = new org.jfree.chart.block.BlockContainer();
        blockContainer23.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D26 = blockContainer23.getBounds();
        numberAxis3D15.setLeftArrow((java.awt.Shape) rectangle2D26);
        org.jfree.chart.entity.ChartEntity chartEntity29 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D26, "");
        java.awt.geom.Point2D point2D30 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo31 = null;
        try {
            jFreeChart13.draw(graphics2D14, rectangle2D26, point2D30, chartRenderingInfo31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(textBlock7);
        org.junit.Assert.assertNull(plot11);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 1.0f + "'", float22 == 1.0f);
        org.junit.Assert.assertNotNull(rectangle2D26);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_TICK_UNIT_SELECTION;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        int int3 = java.awt.Color.HSBtoRGB((float) (short) -1, 10.0f, (float) 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-237) + "'", int3 == (-237));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        boolean boolean1 = numberAxis3D0.isAutoTickUnitSelection();
        boolean boolean2 = numberAxis3D0.isVerticalTickLabels();
        double double3 = numberAxis3D0.getLowerMargin();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("VerticalAlignment.CENTER", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("ThreadContext", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("ChartChangeEventType.DATASET_UPDATED");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name ChartChangeEventType.DATASET_UPDATED, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        blockContainer0.setWidth((double) 10.0f);
        org.jfree.chart.block.BlockBorder blockBorder3 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = blockBorder3.getInsets();
        blockContainer0.setMargin(rectangleInsets4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = rectangleConstraint7.toFixedWidth((double) 200);
        org.jfree.chart.util.Size2D size2D10 = blockContainer0.arrange(graphics2D6, rectangleConstraint9);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = rectangleConstraint9.toFixedHeight(0.0d);
        org.junit.Assert.assertNotNull(blockBorder3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(rectangleConstraint7);
        org.junit.Assert.assertNotNull(rectangleConstraint9);
        org.junit.Assert.assertNotNull(size2D10);
        org.junit.Assert.assertNotNull(rectangleConstraint12);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(true);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        blockContainer0.setWidth((double) 10.0f);
        org.jfree.chart.block.BlockBorder blockBorder3 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = blockBorder3.getInsets();
        blockContainer0.setMargin(rectangleInsets4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = rectangleConstraint7.toFixedWidth((double) 200);
        org.jfree.chart.util.Size2D size2D10 = blockContainer0.arrange(graphics2D6, rectangleConstraint9);
        size2D10.setWidth((double) (-1));
        org.junit.Assert.assertNotNull(blockBorder3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(rectangleConstraint7);
        org.junit.Assert.assertNotNull(rectangleConstraint9);
        org.junit.Assert.assertNotNull(size2D10);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (short) 100, (double) (byte) 0, (double) 0.0f, (double) '#');
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (-1L), 10.0d, (double) 0.0f, 0.0d);
        double double12 = rectangleInsets10.trimWidth((double) (byte) 0);
        double double13 = rectangleInsets10.getTop();
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-10.0d) + "'", double12 == (-10.0d));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-1.0d) + "'", double13 == (-1.0d));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Font font3 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint4 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer7 = null;
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("", font3, paint4, (float) (-1), 0, textMeasurer7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor12 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        java.awt.Shape shape16 = textBlock8.calculateBounds(graphics2D9, 0.0f, (float) 255, textBlockAnchor12, (float) (short) 0, (float) (byte) -1, (double) (short) 1);
        piePlot1.setLegendItemShape(shape16);
        java.awt.Shape shape18 = piePlot1.getLegendItemShape();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertNotNull(textBlockAnchor12);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(shape18);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Font font3 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint4 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer7 = null;
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("", font3, paint4, (float) (-1), 0, textMeasurer7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor12 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        java.awt.Shape shape16 = textBlock8.calculateBounds(graphics2D9, 0.0f, (float) 255, textBlockAnchor12, (float) (short) 0, (float) (byte) -1, (double) (short) 1);
        piePlot1.setLegendItemShape(shape16);
        org.jfree.chart.util.Rotation rotation18 = null;
        try {
            piePlot1.setDirection(rotation18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'direction' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertNotNull(textBlockAnchor12);
        org.junit.Assert.assertNotNull(shape16);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        double double0 = org.jfree.chart.plot.PiePlot.MAX_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.4d + "'", double0 == 0.4d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setSectionOutlinesVisible(true);
        java.awt.Paint paint4 = piePlot1.getBackgroundPaint();
        java.awt.Paint paint6 = piePlot1.getSectionOutlinePaint((java.lang.Comparable) 100.0f);
        java.awt.Font font9 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint10 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer13 = null;
        org.jfree.chart.text.TextBlock textBlock14 = org.jfree.chart.text.TextUtilities.createTextBlock("", font9, paint10, (float) (-1), 0, textMeasurer13);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot15 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        multiplePiePlot15.removeChangeListener(plotChangeListener16);
        org.jfree.chart.plot.Plot plot18 = multiplePiePlot15.getParent();
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("ThreadContext", font9, (org.jfree.chart.plot.Plot) multiplePiePlot15, false);
        jFreeChart20.setBackgroundImageAlignment(200);
        float float23 = jFreeChart20.getBackgroundImageAlpha();
        piePlot1.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart20);
        int int25 = jFreeChart20.getSubtitleCount();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(textBlock14);
        org.junit.Assert.assertNull(plot18);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 0.5f + "'", float23 == 0.5f);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot1.getPieChart();
        int int3 = jFreeChart2.getSubtitleCount();
        jFreeChart2.setTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        org.jfree.chart.title.LegendTitle legendTitle6 = null;
        try {
            jFreeChart2.addLegend(legendTitle6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'subtitle' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D0.setAutoRangeStickyZero(false);
        numberAxis3D0.setUpperBound(100.0d);
        float float7 = numberAxis3D0.getTickMarkOutsideLength();
        boolean boolean8 = numberAxis3D0.isInverted();
        java.awt.Shape shape9 = numberAxis3D0.getRightArrow();
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(shape9);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        blockContainer0.setWidth((double) 10.0f);
        org.jfree.chart.block.BlockBorder blockBorder3 = new org.jfree.chart.block.BlockBorder();
        boolean boolean4 = blockContainer0.equals((java.lang.Object) blockBorder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        piePlot11.setSectionOutlinesVisible(true);
        java.awt.Paint paint14 = piePlot11.getBackgroundPaint();
        org.jfree.chart.block.BlockBorder blockBorder15 = new org.jfree.chart.block.BlockBorder((double) (byte) 10, (double) 100L, (double) (-1), (-1.0d), paint14);
        org.jfree.chart.text.TextAnchor textAnchor16 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        boolean boolean17 = blockBorder15.equals((java.lang.Object) textAnchor16);
        java.awt.Shape shape18 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", graphics2D1, 0.0f, (float) 'a', textAnchor4, (double) 10.0f, textAnchor16);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(textAnchor16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(shape18);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int1 = color0.getBlue();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 64 + "'", int1 == 64);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer1 = new org.jfree.chart.text.G2TextMeasurer(graphics2D0);
        try {
            float float5 = g2TextMeasurer1.getStringWidth("RectangleEdge.TOP", (int) (byte) 1, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        java.awt.Color color0 = java.awt.Color.gray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        java.awt.Font font1 = null;
        java.awt.Font font3 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint4 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer7 = null;
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("", font3, paint4, (float) (-1), 0, textMeasurer7);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer12 = new org.jfree.chart.text.G2TextMeasurer(graphics2D11);
        org.jfree.chart.text.TextBlock textBlock13 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint4, (float) (short) 100, (int) '4', (org.jfree.chart.text.TextMeasurer) g2TextMeasurer12);
        try {
            float float17 = g2TextMeasurer12.getStringWidth("Other", (int) (byte) 0, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertNotNull(textBlock13);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot1.getPieChart();
        int int3 = jFreeChart2.getSubtitleCount();
        jFreeChart2.setTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        double double7 = categoryAxis6.getCategoryMargin();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor8 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = org.jfree.chart.util.RectangleEdge.TOP;
        java.lang.String str13 = rectangleEdge12.toString();
        double double14 = categoryAxis6.getCategoryJava2DCoordinate(categoryAnchor8, (int) 'a', 1, rectangle2D11, rectangleEdge12);
        categoryAxis6.setCategoryLabelPositionOffset((int) (short) 100);
        categoryAxis6.setLowerMargin((double) 0.0f);
        try {
            jFreeChart2.setTextAntiAlias((java.lang.Object) categoryAxis6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: org.jfree.chart.axis.CategoryAxis@0 incompatible with Text-specific antialiasing enable key");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.2d + "'", double7 == 0.2d);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "RectangleEdge.TOP" + "'", str13.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setSectionOutlinesVisible(true);
        java.awt.Paint paint6 = piePlot3.getBackgroundPaint();
        java.awt.Paint paint8 = piePlot3.getSectionOutlinePaint((java.lang.Comparable) 100.0f);
        java.awt.Stroke stroke9 = piePlot3.getLabelLinkStroke();
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        piePlot3.setSectionOutlineStroke((java.lang.Comparable) (byte) 100, stroke11);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D13 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D13.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D13.setAutoRangeStickyZero(false);
        numberAxis3D13.setUpperBound(100.0d);
        float float20 = numberAxis3D13.getTickMarkOutsideLength();
        org.jfree.chart.block.BlockContainer blockContainer21 = new org.jfree.chart.block.BlockContainer();
        blockContainer21.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D24 = blockContainer21.getBounds();
        numberAxis3D13.setLeftArrow((java.awt.Shape) rectangle2D24);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = org.jfree.chart.util.RectangleEdge.LEFT;
        java.lang.Object obj27 = null;
        boolean boolean28 = rectangleEdge26.equals(obj27);
        boolean boolean29 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge26);
        org.jfree.chart.axis.AxisSpace axisSpace30 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace31 = numberAxis0.reserveSpace(graphics2D1, (org.jfree.chart.plot.Plot) piePlot3, rectangle2D24, rectangleEdge26, axisSpace30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 1.0f + "'", float20 == 1.0f);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.Timeline timeline2 = dateAxis1.getTimeline();
        java.util.TimeZone timeZone3 = dateAxis1.getTimeZone();
        java.util.Date date4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor6 = null;
        org.jfree.chart.block.BlockContainer blockContainer9 = new org.jfree.chart.block.BlockContainer();
        blockContainer9.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D12 = blockContainer9.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double14 = categoryAxis5.getCategoryJava2DCoordinate(categoryAnchor6, (int) (byte) 10, 0, rectangle2D12, rectangleEdge13);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot15 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot15.setLimit(1.0d);
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot15);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = legendTitle18.getPosition();
        try {
            double double20 = dateAxis1.dateToJava2D(date4, rectangle2D12, rectangleEdge19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeline2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge19);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getCategoryMargin();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor2 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = org.jfree.chart.util.RectangleEdge.TOP;
        java.lang.String str7 = rectangleEdge6.toString();
        double double8 = categoryAxis0.getCategoryJava2DCoordinate(categoryAnchor2, (int) 'a', 1, rectangle2D5, rectangleEdge6);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D11.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D11.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer16 = null;
        org.jfree.chart.plot.PolarPlot polarPlot17 = new org.jfree.chart.plot.PolarPlot(xYDataset10, (org.jfree.chart.axis.ValueAxis) numberAxis3D11, polarItemRenderer16);
        org.jfree.chart.plot.PlotOrientation plotOrientation18 = polarPlot17.getOrientation();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer19 = polarPlot17.getRenderer();
        org.jfree.data.general.PieDataset pieDataset20 = null;
        org.jfree.chart.plot.RingPlot ringPlot21 = new org.jfree.chart.plot.RingPlot(pieDataset20);
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D23 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D23.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D23.setAutoRangeStickyZero(false);
        numberAxis3D23.setUpperBound(100.0d);
        float float30 = numberAxis3D23.getTickMarkOutsideLength();
        org.jfree.chart.block.BlockContainer blockContainer31 = new org.jfree.chart.block.BlockContainer();
        blockContainer31.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D34 = blockContainer31.getBounds();
        numberAxis3D23.setLeftArrow((java.awt.Shape) rectangle2D34);
        org.jfree.data.general.PieDataset pieDataset36 = null;
        org.jfree.chart.plot.PiePlot piePlot37 = new org.jfree.chart.plot.PiePlot(pieDataset36);
        piePlot37.setSectionOutlinesVisible(true);
        java.awt.Paint paint40 = piePlot37.getBackgroundPaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo42 = null;
        org.jfree.chart.plot.PiePlotState piePlotState43 = ringPlot21.initialise(graphics2D22, rectangle2D34, piePlot37, (java.lang.Integer) 3, plotRenderingInfo42);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot44 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot44.setLimit(1.0d);
        org.jfree.chart.title.LegendTitle legendTitle47 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot44);
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = legendTitle47.getPosition();
        org.jfree.chart.axis.AxisSpace axisSpace49 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace50 = categoryAxis0.reserveSpace(graphics2D9, (org.jfree.chart.plot.Plot) polarPlot17, rectangle2D34, rectangleEdge48, axisSpace49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "RectangleEdge.TOP" + "'", str7.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(plotOrientation18);
        org.junit.Assert.assertNull(polarItemRenderer19);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 1.0f + "'", float30 == 1.0f);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(piePlotState43);
        org.junit.Assert.assertNotNull(rectangleEdge48);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("hi!", graphics2D1, (float) 2, (float) 100, (double) 1L, (float) 255, (float) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLowerMargin((double) (short) 100);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.Plot plot5 = multiplePiePlot4.getParent();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent6 = null;
        multiplePiePlot4.markerChanged(markerChangeEvent6);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.Plot plot9 = multiplePiePlot8.getParent();
        multiplePiePlot4.setParent((org.jfree.chart.plot.Plot) multiplePiePlot8);
        org.jfree.chart.util.TableOrder tableOrder11 = multiplePiePlot8.getDataExtractOrder();
        org.jfree.chart.util.UnitType unitType12 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = new org.jfree.chart.util.RectangleInsets(unitType12, (double) (short) 100, (double) (byte) 0, (double) 0.0f, (double) '#');
        double double19 = rectangleInsets17.calculateBottomOutset((double) 1L);
        java.lang.String str20 = rectangleInsets17.toString();
        org.jfree.chart.block.BlockBorder blockBorder21 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = blockBorder21.getInsets();
        double double24 = rectangleInsets22.trimWidth((double) (byte) 10);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D25 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D25.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D25.setAutoRangeStickyZero(false);
        numberAxis3D25.setUpperBound(100.0d);
        float float32 = numberAxis3D25.getTickMarkOutsideLength();
        org.jfree.chart.block.BlockContainer blockContainer33 = new org.jfree.chart.block.BlockContainer();
        blockContainer33.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D36 = blockContainer33.getBounds();
        numberAxis3D25.setLeftArrow((java.awt.Shape) rectangle2D36);
        org.jfree.chart.entity.ChartEntity chartEntity39 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D36, "");
        java.awt.geom.Rectangle2D rectangle2D40 = rectangleInsets22.createOutsetRectangle(rectangle2D36);
        java.awt.geom.Rectangle2D rectangle2D41 = rectangleInsets17.createOutsetRectangle(rectangle2D36);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot42 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot42.setLimit(1.0d);
        org.jfree.chart.title.LegendTitle legendTitle45 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot42);
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = legendTitle45.getPosition();
        org.jfree.chart.axis.AxisSpace axisSpace47 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace48 = categoryAxis0.reserveSpace(graphics2D3, (org.jfree.chart.plot.Plot) multiplePiePlot8, rectangle2D36, rectangleEdge46, axisSpace47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(plot5);
        org.junit.Assert.assertNull(plot9);
        org.junit.Assert.assertNotNull(tableOrder11);
        org.junit.Assert.assertNotNull(unitType12);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "RectangleInsets[t=100.0,l=0.0,b=0.0,r=35.0]" + "'", str20.equals("RectangleInsets[t=100.0,l=0.0,b=0.0,r=35.0]"));
        org.junit.Assert.assertNotNull(blockBorder21);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 10.0d + "'", double24 == 10.0d);
        org.junit.Assert.assertTrue("'" + float32 + "' != '" + 1.0f + "'", float32 == 1.0f);
        org.junit.Assert.assertNotNull(rectangle2D36);
        org.junit.Assert.assertNotNull(rectangle2D40);
        org.junit.Assert.assertNotNull(rectangle2D41);
        org.junit.Assert.assertNotNull(rectangleEdge46);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D1.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D1.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, polarItemRenderer6);
        double double8 = polarPlot7.getMaxRadius();
        org.jfree.chart.LegendItemCollection legendItemCollection9 = polarPlot7.getLegendItems();
        java.awt.Paint paint10 = polarPlot7.getRadiusGridlinePaint();
        polarPlot7.setBackgroundImageAlignment(0);
        java.lang.String str13 = polarPlot7.getPlotType();
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.05d + "'", double8 == 1.05d);
        org.junit.Assert.assertNotNull(legendItemCollection9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Polar Plot" + "'", str13.equals("Polar Plot"));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-8d + "'", double0 == 1.0E-8d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        java.awt.Font font2 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer6 = null;
        org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, paint3, (float) (-1), 0, textMeasurer6);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        multiplePiePlot8.removeChangeListener(plotChangeListener9);
        org.jfree.chart.plot.Plot plot11 = multiplePiePlot8.getParent();
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("ThreadContext", font2, (org.jfree.chart.plot.Plot) multiplePiePlot8, false);
        org.jfree.chart.title.LegendTitle legendTitle14 = jFreeChart13.getLegend();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        try {
            java.awt.image.BufferedImage bufferedImage18 = jFreeChart13.createBufferedImage((int) (short) -1, 0, chartRenderingInfo17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (-1) and height (0) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(textBlock7);
        org.junit.Assert.assertNull(plot11);
        org.junit.Assert.assertNull(legendTitle14);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) "VerticalAlignment.CENTER", (double) 0.0f, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        blockContainer0.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D3 = blockContainer0.getBounds();
        blockContainer0.setHeight((double) (short) 100);
        org.junit.Assert.assertNotNull(rectangle2D3);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        java.awt.Font font2 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer6 = null;
        org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, paint3, (float) (-1), 0, textMeasurer6);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        multiplePiePlot8.removeChangeListener(plotChangeListener9);
        org.jfree.chart.plot.Plot plot11 = multiplePiePlot8.getParent();
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("ThreadContext", font2, (org.jfree.chart.plot.Plot) multiplePiePlot8, false);
        java.awt.Paint paint14 = jFreeChart13.getBorderPaint();
        jFreeChart13.setNotify(false);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(textBlock7);
        org.junit.Assert.assertNull(plot11);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        boolean boolean2 = textBlockAnchor0.equals((java.lang.Object) 15);
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.RangeType rangeType1 = numberAxis3D0.getRangeType();
        java.lang.String str2 = numberAxis3D0.getLabelToolTip();
        java.awt.Paint paint3 = numberAxis3D0.getTickMarkPaint();
        org.junit.Assert.assertNotNull(rangeType1);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor(10, 64, (int) (byte) 100);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.Timeline timeline2 = dateAxis1.getTimeline();
        java.util.TimeZone timeZone3 = dateAxis1.getTimeZone();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition4 = null;
        try {
            dateAxis1.setTickMarkPosition(dateTickMarkPosition4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeline2);
        org.junit.Assert.assertNotNull(timeZone3);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        java.lang.Object obj0 = null;
        java.awt.Font font3 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint4 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer7 = null;
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("", font3, paint4, (float) (-1), 0, textMeasurer7);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot9 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        multiplePiePlot9.removeChangeListener(plotChangeListener10);
        org.jfree.chart.plot.Plot plot12 = multiplePiePlot9.getParent();
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("ThreadContext", font3, (org.jfree.chart.plot.Plot) multiplePiePlot9, false);
        org.jfree.chart.title.LegendTitle legendTitle15 = jFreeChart14.getLegend();
        java.awt.Paint paint16 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        jFreeChart14.setBorderPaint(paint16);
        java.util.List list18 = jFreeChart14.getSubtitles();
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent19 = new org.jfree.chart.event.ChartChangeEvent(obj0, jFreeChart14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertNull(plot12);
        org.junit.Assert.assertNull(legendTitle15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(list18);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setSectionOutlinesVisible(true);
        java.awt.Paint paint4 = piePlot1.getBackgroundPaint();
        java.awt.Paint paint6 = piePlot1.getSectionOutlinePaint((java.lang.Comparable) 100.0f);
        java.awt.Stroke stroke7 = piePlot1.getLabelLinkStroke();
        java.lang.Comparable comparable8 = null;
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        try {
            piePlot1.setSectionOutlineStroke(comparable8, stroke9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.Plot plot2 = multiplePiePlot1.getParent();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        multiplePiePlot1.markerChanged(markerChangeEvent3);
        java.awt.Paint paint5 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        multiplePiePlot1.setNoDataMessagePaint(paint5);
        categoryAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) multiplePiePlot1);
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getCategoryMargin();
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) 100, "TextAnchor.CENTER_RIGHT");
        java.awt.Paint paint6 = categoryAxis0.getTickLabelPaint((java.lang.Comparable) "ThreadContext");
        java.lang.Object obj7 = categoryAxis0.clone();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (short) 100, (double) (byte) 0, (double) 0.0f, (double) '#');
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        java.lang.String str8 = chartChangeEventType7.toString();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent9 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (short) 100, jFreeChart6, chartChangeEventType7);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType10 = chartChangeEvent9.getType();
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertNotNull(chartChangeEventType7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str8.equals("ChartChangeEventType.DATASET_UPDATED"));
        org.junit.Assert.assertNotNull(chartChangeEventType10);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        java.awt.Font font2 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer6 = null;
        org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, paint3, (float) (-1), 0, textMeasurer6);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        multiplePiePlot8.removeChangeListener(plotChangeListener9);
        org.jfree.chart.plot.Plot plot11 = multiplePiePlot8.getParent();
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("ThreadContext", font2, (org.jfree.chart.plot.Plot) multiplePiePlot8, false);
        jFreeChart13.setBackgroundImageAlignment(200);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.data.general.PieDataset pieDataset17 = null;
        org.jfree.chart.plot.RingPlot ringPlot18 = new org.jfree.chart.plot.RingPlot(pieDataset17);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D20.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D20.setAutoRangeStickyZero(false);
        numberAxis3D20.setUpperBound(100.0d);
        float float27 = numberAxis3D20.getTickMarkOutsideLength();
        org.jfree.chart.block.BlockContainer blockContainer28 = new org.jfree.chart.block.BlockContainer();
        blockContainer28.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D31 = blockContainer28.getBounds();
        numberAxis3D20.setLeftArrow((java.awt.Shape) rectangle2D31);
        org.jfree.data.general.PieDataset pieDataset33 = null;
        org.jfree.chart.plot.PiePlot piePlot34 = new org.jfree.chart.plot.PiePlot(pieDataset33);
        piePlot34.setSectionOutlinesVisible(true);
        java.awt.Paint paint37 = piePlot34.getBackgroundPaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        org.jfree.chart.plot.PiePlotState piePlotState40 = ringPlot18.initialise(graphics2D19, rectangle2D31, piePlot34, (java.lang.Integer) 3, plotRenderingInfo39);
        java.awt.geom.Point2D point2D41 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo42 = null;
        try {
            jFreeChart13.draw(graphics2D16, rectangle2D31, point2D41, chartRenderingInfo42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(textBlock7);
        org.junit.Assert.assertNull(plot11);
        org.junit.Assert.assertTrue("'" + float27 + "' != '" + 1.0f + "'", float27 == 1.0f);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(piePlotState40);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = org.jfree.chart.util.VerticalAlignment.CENTER;
        java.awt.Paint paint3 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        boolean boolean4 = verticalAlignment2.equals((java.lang.Object) paint3);
        org.jfree.chart.block.ColumnArrangement columnArrangement7 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment1, verticalAlignment2, (double) (byte) 1, (double) (byte) -1);
        boolean boolean8 = piePlot3D0.equals((java.lang.Object) (byte) 1);
        boolean boolean9 = piePlot3D0.getIgnoreZeroValues();
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = rectangleConstraint0.toFixedWidth((double) 200);
        org.jfree.data.Range range3 = rectangleConstraint2.getHeightRange();
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertNotNull(rectangleConstraint2);
        org.junit.Assert.assertNull(range3);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.CLASS_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ClassContext" + "'", str0.equals("ClassContext"));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_LOWER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D1.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D1.setAutoRangeStickyZero(false);
        numberAxis3D1.setLabel("ThreadContext");
        numberAxis3D1.setRange((double) 3, 10.0d);
        java.awt.Font font11 = numberAxis3D1.getLabelFont();
        java.awt.Color color14 = java.awt.Color.getColor("", 0);
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_YELLOW;
        int int16 = color15.getBlue();
        java.awt.color.ColorSpace colorSpace17 = color15.getColorSpace();
        float[] floatArray18 = null;
        float[] floatArray19 = color14.getComponents(colorSpace17, floatArray18);
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer22 = new org.jfree.chart.text.G2TextMeasurer(graphics2D21);
        try {
            org.jfree.chart.text.TextBlock textBlock23 = org.jfree.chart.text.TextUtilities.createTextBlock("Other", font11, (java.awt.Paint) color14, (float) '#', (org.jfree.chart.text.TextMeasurer) g2TextMeasurer22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(colorSpace17);
        org.junit.Assert.assertNotNull(floatArray19);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setSectionOutlinesVisible(true);
        java.awt.Paint paint4 = piePlot1.getBackgroundPaint();
        java.awt.Paint paint6 = piePlot1.getSectionOutlinePaint((java.lang.Comparable) 100.0f);
        java.awt.Font font9 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint10 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer13 = null;
        org.jfree.chart.text.TextBlock textBlock14 = org.jfree.chart.text.TextUtilities.createTextBlock("", font9, paint10, (float) (-1), 0, textMeasurer13);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot15 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        multiplePiePlot15.removeChangeListener(plotChangeListener16);
        org.jfree.chart.plot.Plot plot18 = multiplePiePlot15.getParent();
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("ThreadContext", font9, (org.jfree.chart.plot.Plot) multiplePiePlot15, false);
        jFreeChart20.setBackgroundImageAlignment(200);
        float float23 = jFreeChart20.getBackgroundImageAlpha();
        piePlot1.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart20);
        boolean boolean25 = jFreeChart20.isNotify();
        try {
            org.jfree.chart.title.Title title27 = jFreeChart20.getSubtitle(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(textBlock14);
        org.junit.Assert.assertNull(plot18);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 0.5f + "'", float23 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit(1.0d);
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot0);
        java.lang.Object obj4 = legendTitle3.clone();
        java.awt.Font font5 = legendTitle3.getItemFont();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D1.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D1.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, polarItemRenderer6);
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = polarPlot7.getOrientation();
        java.awt.Font font9 = polarPlot7.getAngleLabelFont();
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertNotNull(font9);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_UPPER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        piePlot5.setSectionOutlinesVisible(true);
        java.awt.Paint paint8 = piePlot5.getBackgroundPaint();
        org.jfree.chart.block.BlockBorder blockBorder9 = new org.jfree.chart.block.BlockBorder((double) (byte) 10, (double) 100L, (double) (-1), (-1.0d), paint8);
        org.jfree.chart.text.TextAnchor textAnchor10 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        boolean boolean11 = blockBorder9.equals((java.lang.Object) textAnchor10);
        java.lang.String str12 = textAnchor10.toString();
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(textAnchor10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "TextAnchor.BASELINE_CENTER" + "'", str12.equals("TextAnchor.BASELINE_CENTER"));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("Other");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        try {
            textFragment1.draw(graphics2D2, (float) 10, (float) 3, textAnchor5, (float) (short) 100, 10.0f, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor5);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        boolean boolean0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = rectangleConstraint0.toFixedWidth((double) 200);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = rectangleConstraint0.toUnconstrainedHeight();
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertNotNull(rectangleConstraint2);
        org.junit.Assert.assertNotNull(rectangleConstraint3);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("hi!", "", "RectangleEdge.TOP", image3, "RectangleEdge.TOP", "", "RectangleEdge.TOP");
        projectInfo7.setVersion("TextAnchor.CENTER_RIGHT");
        java.awt.Image image13 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo17 = new org.jfree.chart.ui.ProjectInfo("hi!", "", "RectangleEdge.TOP", image13, "RectangleEdge.TOP", "", "RectangleEdge.TOP");
        projectInfo17.setVersion("TextAnchor.CENTER_RIGHT");
        projectInfo7.addLibrary((org.jfree.chart.ui.Library) projectInfo17);
        java.awt.Image image21 = null;
        projectInfo7.setLogo(image21);
        java.lang.String str23 = projectInfo7.getName();
        java.util.List list24 = projectInfo7.getContributors();
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!" + "'", str23.equals("hi!"));
        org.junit.Assert.assertNull(list24);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        java.awt.Color color0 = java.awt.Color.BLACK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockBorder0.getInsets();
        double double3 = rectangleInsets1.trimWidth((double) (byte) 10);
        double double5 = rectangleInsets1.calculateTopInset((double) (-1L));
        org.junit.Assert.assertNotNull(blockBorder0);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.data.function.Function2D function2D0 = null;
        try {
            org.jfree.data.xy.XYDataset xYDataset5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, (double) 0L, (double) 15, 64, (java.lang.Comparable) "ClassContext");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, 0.025d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("ThreadContext", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer5 = null;
        org.jfree.chart.text.TextBlock textBlock6 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint2, (float) (byte) 1, 100, textMeasurer5);
        org.jfree.chart.text.TextLine textLine7 = null;
        textBlock6.addLine(textLine7);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.Font font13 = null;
        java.awt.Font font15 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint16 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer19 = null;
        org.jfree.chart.text.TextBlock textBlock20 = org.jfree.chart.text.TextUtilities.createTextBlock("", font15, paint16, (float) (-1), 0, textMeasurer19);
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer24 = new org.jfree.chart.text.G2TextMeasurer(graphics2D23);
        org.jfree.chart.text.TextBlock textBlock25 = org.jfree.chart.text.TextUtilities.createTextBlock("", font13, paint16, (float) (short) 100, (int) '4', (org.jfree.chart.text.TextMeasurer) g2TextMeasurer24);
        java.awt.Graphics2D graphics2D26 = null;
        java.awt.Font font30 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint31 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer34 = null;
        org.jfree.chart.text.TextBlock textBlock35 = org.jfree.chart.text.TextUtilities.createTextBlock("", font30, paint31, (float) (-1), 0, textMeasurer34);
        java.awt.Graphics2D graphics2D36 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor39 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        java.awt.Shape shape43 = textBlock35.calculateBounds(graphics2D36, 0.0f, (float) 255, textBlockAnchor39, (float) (short) 0, (float) (byte) -1, (double) (short) 1);
        textBlock25.draw(graphics2D26, (float) (short) 1, (float) (byte) 0, textBlockAnchor39);
        java.awt.Graphics2D graphics2D45 = null;
        java.awt.Font font49 = null;
        java.awt.Font font51 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint52 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer55 = null;
        org.jfree.chart.text.TextBlock textBlock56 = org.jfree.chart.text.TextUtilities.createTextBlock("", font51, paint52, (float) (-1), 0, textMeasurer55);
        java.awt.Graphics2D graphics2D59 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer60 = new org.jfree.chart.text.G2TextMeasurer(graphics2D59);
        org.jfree.chart.text.TextBlock textBlock61 = org.jfree.chart.text.TextUtilities.createTextBlock("", font49, paint52, (float) (short) 100, (int) '4', (org.jfree.chart.text.TextMeasurer) g2TextMeasurer60);
        java.awt.Graphics2D graphics2D62 = null;
        java.awt.Font font66 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint67 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer70 = null;
        org.jfree.chart.text.TextBlock textBlock71 = org.jfree.chart.text.TextUtilities.createTextBlock("", font66, paint67, (float) (-1), 0, textMeasurer70);
        java.awt.Graphics2D graphics2D72 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor75 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        java.awt.Shape shape79 = textBlock71.calculateBounds(graphics2D72, 0.0f, (float) 255, textBlockAnchor75, (float) (short) 0, (float) (byte) -1, (double) (short) 1);
        textBlock61.draw(graphics2D62, (float) (short) 1, (float) (byte) 0, textBlockAnchor75);
        textBlock25.draw(graphics2D45, (float) (byte) 0, (float) 15, textBlockAnchor75);
        try {
            textBlock6.draw(graphics2D9, (float) (short) 1, (float) (short) 0, textBlockAnchor75, (float) (byte) 1, (float) (-237), 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(textBlock6);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(textBlock20);
        org.junit.Assert.assertNotNull(textBlock25);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(textBlock35);
        org.junit.Assert.assertNotNull(textBlockAnchor39);
        org.junit.Assert.assertNotNull(shape43);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertNotNull(textBlock56);
        org.junit.Assert.assertNotNull(textBlock61);
        org.junit.Assert.assertNotNull(font66);
        org.junit.Assert.assertNotNull(paint67);
        org.junit.Assert.assertNotNull(textBlock71);
        org.junit.Assert.assertNotNull(textBlockAnchor75);
        org.junit.Assert.assertNotNull(shape79);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        blockContainer0.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D3 = blockContainer0.getBounds();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot5 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot5.setLimit(1.0d);
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot5);
        org.jfree.chart.util.VerticalAlignment verticalAlignment9 = legendTitle8.getVerticalAlignment();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint11.toFixedWidth((double) 200);
        org.jfree.chart.util.Size2D size2D14 = legendTitle8.arrange(graphics2D10, rectangleConstraint13);
        org.jfree.chart.util.Size2D size2D15 = blockContainer0.arrange(graphics2D4, rectangleConstraint13);
        org.junit.Assert.assertNotNull(rectangle2D3);
        org.junit.Assert.assertNotNull(verticalAlignment9);
        org.junit.Assert.assertNotNull(rectangleConstraint11);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(size2D14);
        org.junit.Assert.assertNotNull(size2D15);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        java.awt.Color color0 = java.awt.Color.white;
        java.awt.Color color3 = java.awt.Color.getColor("", 0);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_YELLOW;
        int int5 = color4.getBlue();
        java.awt.color.ColorSpace colorSpace6 = color4.getColorSpace();
        float[] floatArray7 = null;
        float[] floatArray8 = color3.getComponents(colorSpace6, floatArray7);
        float[] floatArray9 = color0.getComponents(floatArray8);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(colorSpace6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("RectangleAnchor.BOTTOM_LEFT", graphics2D1, (float) (-1L), (float) '4', 0.0d, (float) (byte) 0, (float) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit(1.0d);
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot0);
        org.jfree.chart.block.BlockContainer blockContainer4 = new org.jfree.chart.block.BlockContainer();
        blockContainer4.setWidth((double) 10.0f);
        org.jfree.chart.block.BlockBorder blockBorder7 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = blockBorder7.getInsets();
        blockContainer4.setMargin(rectangleInsets8);
        java.lang.String str10 = blockContainer4.getID();
        legendTitle3.setWrapper(blockContainer4);
        java.awt.geom.Rectangle2D rectangle2D12 = blockContainer4.getBounds();
        java.awt.Paint paint14 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke15 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker(35.0d, paint14, stroke15);
        org.jfree.chart.block.BlockBorder blockBorder17 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = blockBorder17.getInsets();
        org.jfree.chart.block.BlockContainer blockContainer19 = new org.jfree.chart.block.BlockContainer();
        blockContainer19.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D22 = blockContainer19.getBounds();
        rectangleInsets18.trim(rectangle2D22);
        valueMarker16.setLabelOffset(rectangleInsets18);
        blockContainer4.setMargin(rectangleInsets18);
        org.junit.Assert.assertNotNull(blockBorder7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(blockBorder17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(rectangle2D22);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setSectionOutlinesVisible(true);
        java.awt.Paint paint4 = piePlot1.getBackgroundPaint();
        java.awt.Paint paint6 = piePlot1.getSectionOutlinePaint((java.lang.Comparable) 100.0f);
        java.awt.Stroke stroke7 = piePlot1.getLabelOutlineStroke();
        java.awt.Paint paint8 = piePlot1.getShadowPaint();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator10 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        piePlot1.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator10);
        boolean boolean12 = piePlot1.getSimpleLabels();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        java.awt.Font font2 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer6 = null;
        org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, paint3, (float) (-1), 0, textMeasurer6);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        multiplePiePlot8.removeChangeListener(plotChangeListener9);
        org.jfree.chart.plot.Plot plot11 = multiplePiePlot8.getParent();
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("ThreadContext", font2, (org.jfree.chart.plot.Plot) multiplePiePlot8, false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo16 = null;
        java.awt.image.BufferedImage bufferedImage17 = jFreeChart13.createBufferedImage((int) (short) 1, (int) (byte) 100, chartRenderingInfo16);
        java.awt.RenderingHints renderingHints18 = null;
        try {
            jFreeChart13.setRenderingHints(renderingHints18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: RenderingHints given are null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(textBlock7);
        org.junit.Assert.assertNull(plot11);
        org.junit.Assert.assertNotNull(bufferedImage17);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.block.BlockContainer blockContainer2 = new org.jfree.chart.block.BlockContainer();
        blockContainer2.setWidth((double) 10.0f);
        org.jfree.chart.block.BlockBorder blockBorder5 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = blockBorder5.getInsets();
        blockContainer2.setMargin(rectangleInsets6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = rectangleConstraint9.toFixedWidth((double) 200);
        org.jfree.chart.util.Size2D size2D12 = blockContainer2.arrange(graphics2D8, rectangleConstraint11);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot13 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot13.setLimit(1.0d);
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot13);
        org.jfree.chart.util.VerticalAlignment verticalAlignment17 = legendTitle16.getVerticalAlignment();
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint19 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = rectangleConstraint19.toFixedWidth((double) 200);
        org.jfree.chart.util.Size2D size2D22 = legendTitle16.arrange(graphics2D18, rectangleConstraint21);
        size2D22.height = 100.0f;
        org.jfree.chart.util.Size2D size2D25 = rectangleConstraint11.calculateConstrainedSize(size2D22);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor28 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.lang.String str29 = rectangleAnchor28.toString();
        java.awt.geom.Rectangle2D rectangle2D30 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D22, 0.0d, 0.4d, rectangleAnchor28);
        org.jfree.data.xy.XYDataset xYDataset31 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D32 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D32.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D32.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer37 = null;
        org.jfree.chart.plot.PolarPlot polarPlot38 = new org.jfree.chart.plot.PolarPlot(xYDataset31, (org.jfree.chart.axis.ValueAxis) numberAxis3D32, polarItemRenderer37);
        double double39 = polarPlot38.getMaxRadius();
        org.jfree.chart.block.BlockContainer blockContainer42 = new org.jfree.chart.block.BlockContainer();
        blockContainer42.setWidth((double) 10.0f);
        org.jfree.chart.block.BlockBorder blockBorder45 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets46 = blockBorder45.getInsets();
        blockContainer42.setMargin(rectangleInsets46);
        java.awt.Graphics2D graphics2D48 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint49 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint51 = rectangleConstraint49.toFixedWidth((double) 200);
        org.jfree.chart.util.Size2D size2D52 = blockContainer42.arrange(graphics2D48, rectangleConstraint51);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot53 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot53.setLimit(1.0d);
        org.jfree.chart.title.LegendTitle legendTitle56 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot53);
        org.jfree.chart.util.VerticalAlignment verticalAlignment57 = legendTitle56.getVerticalAlignment();
        java.awt.Graphics2D graphics2D58 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint59 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint61 = rectangleConstraint59.toFixedWidth((double) 200);
        org.jfree.chart.util.Size2D size2D62 = legendTitle56.arrange(graphics2D58, rectangleConstraint61);
        size2D62.height = 100.0f;
        org.jfree.chart.util.Size2D size2D65 = rectangleConstraint51.calculateConstrainedSize(size2D62);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor68 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.lang.String str69 = rectangleAnchor68.toString();
        java.awt.geom.Rectangle2D rectangle2D70 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D62, 0.0d, 0.4d, rectangleAnchor68);
        java.awt.Point point71 = polarPlot38.translateValueThetaRadiusToJava2D((double) 1.0f, (double) (short) 10, rectangle2D70);
        org.jfree.chart.plot.PlotState plotState72 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo73 = null;
        try {
            multiplePiePlot0.draw(graphics2D1, rectangle2D30, (java.awt.geom.Point2D) point71, plotState72, plotRenderingInfo73);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockBorder5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(rectangleConstraint9);
        org.junit.Assert.assertNotNull(rectangleConstraint11);
        org.junit.Assert.assertNotNull(size2D12);
        org.junit.Assert.assertNotNull(verticalAlignment17);
        org.junit.Assert.assertNotNull(rectangleConstraint19);
        org.junit.Assert.assertNotNull(rectangleConstraint21);
        org.junit.Assert.assertNotNull(size2D22);
        org.junit.Assert.assertNotNull(size2D25);
        org.junit.Assert.assertNotNull(rectangleAnchor28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "RectangleAnchor.LEFT" + "'", str29.equals("RectangleAnchor.LEFT"));
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 1.05d + "'", double39 == 1.05d);
        org.junit.Assert.assertNotNull(blockBorder45);
        org.junit.Assert.assertNotNull(rectangleInsets46);
        org.junit.Assert.assertNotNull(rectangleConstraint49);
        org.junit.Assert.assertNotNull(rectangleConstraint51);
        org.junit.Assert.assertNotNull(size2D52);
        org.junit.Assert.assertNotNull(verticalAlignment57);
        org.junit.Assert.assertNotNull(rectangleConstraint59);
        org.junit.Assert.assertNotNull(rectangleConstraint61);
        org.junit.Assert.assertNotNull(size2D62);
        org.junit.Assert.assertNotNull(size2D65);
        org.junit.Assert.assertNotNull(rectangleAnchor68);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "RectangleAnchor.LEFT" + "'", str69.equals("RectangleAnchor.LEFT"));
        org.junit.Assert.assertNotNull(rectangle2D70);
        org.junit.Assert.assertNotNull(point71);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setSectionOutlinesVisible(true);
        java.awt.Paint paint4 = piePlot1.getBackgroundPaint();
        java.awt.Paint paint6 = piePlot1.getSectionOutlinePaint((java.lang.Comparable) 100.0f);
        piePlot1.setCircular(true, false);
        double double10 = piePlot1.getLabelGap();
        java.awt.Shape shape11 = piePlot1.getLegendItemShape();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.RingPlot ringPlot13 = new org.jfree.chart.plot.RingPlot(pieDataset12);
        java.awt.Paint paint14 = ringPlot13.getSeparatorPaint();
        piePlot1.setLabelBackgroundPaint(paint14);
        java.awt.Font font18 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint19 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer22 = null;
        org.jfree.chart.text.TextBlock textBlock23 = org.jfree.chart.text.TextUtilities.createTextBlock("", font18, paint19, (float) (-1), 0, textMeasurer22);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot24 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener25 = null;
        multiplePiePlot24.removeChangeListener(plotChangeListener25);
        org.jfree.chart.plot.Plot plot27 = multiplePiePlot24.getParent();
        org.jfree.chart.JFreeChart jFreeChart29 = new org.jfree.chart.JFreeChart("ThreadContext", font18, (org.jfree.chart.plot.Plot) multiplePiePlot24, false);
        java.awt.Paint paint30 = jFreeChart29.getBorderPaint();
        piePlot1.setBaseSectionPaint(paint30);
        java.awt.Paint paint32 = piePlot1.getLabelOutlinePaint();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.025d + "'", double10 == 0.025d);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(textBlock23);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(paint32);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font2 = categoryAxis0.getTickLabelFont((java.lang.Comparable) (short) 100);
        org.junit.Assert.assertNotNull(font2);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit(1.0d);
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot0);
        java.lang.Object obj4 = legendTitle3.clone();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D5.setTickMarkOutsideLength((float) (short) 1);
        java.awt.Paint paint8 = numberAxis3D5.getAxisLinePaint();
        legendTitle3.setBackgroundPaint(paint8);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D0.setAutoRangeStickyZero(false);
        numberAxis3D0.setUpperBound(100.0d);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand7 = numberAxis3D0.getMarkerBand();
        double double8 = numberAxis3D0.getFixedAutoRange();
        org.jfree.data.Range range9 = null;
        try {
            numberAxis3D0.setRange(range9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(markerAxisBand7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        boolean boolean2 = chartChangeEventType0.equals((java.lang.Object) "TextAnchor.BASELINE_CENTER");
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.plot.Plot plot3 = multiplePiePlot0.getParent();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        multiplePiePlot0.notifyListeners(plotChangeEvent4);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent6 = null;
        multiplePiePlot0.markerChanged(markerChangeEvent6);
        org.junit.Assert.assertNull(plot3);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        java.awt.Font font2 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer6 = null;
        org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, paint3, (float) (-1), 0, textMeasurer6);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        multiplePiePlot8.removeChangeListener(plotChangeListener9);
        org.jfree.chart.plot.Plot plot11 = multiplePiePlot8.getParent();
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("ThreadContext", font2, (org.jfree.chart.plot.Plot) multiplePiePlot8, false);
        org.jfree.chart.title.LegendTitle legendTitle14 = jFreeChart13.getLegend();
        java.awt.Paint paint15 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        jFreeChart13.setBorderPaint(paint15);
        org.jfree.chart.event.ChartProgressListener chartProgressListener17 = null;
        jFreeChart13.removeProgressListener(chartProgressListener17);
        java.awt.Stroke stroke19 = jFreeChart13.getBorderStroke();
        org.jfree.chart.event.ChartProgressListener chartProgressListener20 = null;
        jFreeChart13.addProgressListener(chartProgressListener20);
        try {
            org.jfree.chart.plot.CategoryPlot categoryPlot22 = jFreeChart13.getCategoryPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.MultiplePiePlot cannot be cast to org.jfree.chart.plot.CategoryPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(textBlock7);
        org.junit.Assert.assertNull(plot11);
        org.junit.Assert.assertNull(legendTitle14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(stroke19);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLowerMargin((double) (short) 100);
        org.jfree.chart.block.BlockBorder blockBorder5 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = blockBorder5.getInsets();
        double double8 = rectangleInsets6.trimWidth((double) (byte) 10);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D9 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D9.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D9.setAutoRangeStickyZero(false);
        numberAxis3D9.setUpperBound(100.0d);
        float float16 = numberAxis3D9.getTickMarkOutsideLength();
        org.jfree.chart.block.BlockContainer blockContainer17 = new org.jfree.chart.block.BlockContainer();
        blockContainer17.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D20 = blockContainer17.getBounds();
        numberAxis3D9.setLeftArrow((java.awt.Shape) rectangle2D20);
        org.jfree.chart.entity.ChartEntity chartEntity23 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D20, "");
        java.awt.geom.Rectangle2D rectangle2D24 = rectangleInsets6.createOutsetRectangle(rectangle2D20);
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis();
        double double26 = categoryAxis25.getCategoryMargin();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor27 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = org.jfree.chart.util.RectangleEdge.TOP;
        java.lang.String str32 = rectangleEdge31.toString();
        double double33 = categoryAxis25.getCategoryJava2DCoordinate(categoryAnchor27, (int) 'a', 1, rectangle2D30, rectangleEdge31);
        double double34 = categoryAxis0.getCategoryEnd((-1), (int) '4', rectangle2D20, rectangleEdge31);
        org.jfree.data.general.PieDataset pieDataset35 = null;
        org.jfree.chart.plot.PiePlot piePlot36 = new org.jfree.chart.plot.PiePlot(pieDataset35);
        piePlot36.setSectionOutlinesVisible(true);
        java.awt.Paint paint39 = piePlot36.getBackgroundPaint();
        categoryAxis0.setTickMarkPaint(paint39);
        org.junit.Assert.assertNotNull(blockBorder5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 10.0d + "'", double8 == 10.0d);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 1.0f + "'", float16 == 1.0f);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.2d + "'", double26 == 0.2d);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "RectangleEdge.TOP" + "'", str32.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(paint39);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        java.awt.Font font2 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer6 = null;
        org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, paint3, (float) (-1), 0, textMeasurer6);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        multiplePiePlot8.removeChangeListener(plotChangeListener9);
        org.jfree.chart.plot.Plot plot11 = multiplePiePlot8.getParent();
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("ThreadContext", font2, (org.jfree.chart.plot.Plot) multiplePiePlot8, false);
        java.util.List list14 = jFreeChart13.getSubtitles();
        java.awt.RenderingHints renderingHints15 = null;
        try {
            jFreeChart13.setRenderingHints(renderingHints15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: RenderingHints given are null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(textBlock7);
        org.junit.Assert.assertNull(plot11);
        org.junit.Assert.assertNotNull(list14);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        boolean boolean1 = numberAxis3D0.isAutoTickUnitSelection();
        boolean boolean2 = numberAxis3D0.isVisible();
        boolean boolean3 = numberAxis3D0.isAutoRange();
        numberAxis3D0.setVisible(true);
        boolean boolean6 = numberAxis3D0.isInverted();
        java.lang.Object obj7 = numberAxis3D0.clone();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        double[] doubleArray5 = new double[] { (byte) 0, 0.2d, (-1.0d) };
        double[] doubleArray9 = new double[] { (byte) 0, 0.2d, (-1.0d) };
        double[] doubleArray13 = new double[] { (byte) 0, 0.2d, (-1.0d) };
        double[][] doubleArray14 = new double[][] { doubleArray5, doubleArray9, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("rect", "RectangleAnchor.BOTTOM_LEFT", doubleArray14);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset15);
        try {
            org.jfree.data.general.PieDataset pieDataset18 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset15, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 3");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(range16);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", graphics2D1, 0.0f, (float) (byte) -1, (double) 1.0f, (float) 100, (float) 3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.Plot plot3 = multiplePiePlot2.getParent();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent4 = null;
        multiplePiePlot2.markerChanged(markerChangeEvent4);
        java.lang.Comparable comparable6 = multiplePiePlot2.getAggregatedItemsKey();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = null;
        multiplePiePlot2.datasetChanged(datasetChangeEvent7);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("ClassContext", (org.jfree.chart.plot.Plot) multiplePiePlot2);
        boolean boolean10 = multiplePiePlot0.equals((java.lang.Object) jFreeChart9);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + "Other" + "'", comparable6.equals("Other"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_MINIMUM_ARC_ANGLE_TO_DRAW;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-5d + "'", double0 == 1.0E-5d);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (short) 100, (double) (byte) 0, (double) 0.0f, (double) '#');
        double double7 = rectangleInsets5.calculateBottomOutset((double) 1L);
        double double9 = rectangleInsets5.calculateBottomOutset((double) 10L);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getCategoryMargin();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor2 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = org.jfree.chart.util.RectangleEdge.TOP;
        java.lang.String str7 = rectangleEdge6.toString();
        double double8 = categoryAxis0.getCategoryJava2DCoordinate(categoryAnchor2, (int) 'a', 1, rectangle2D5, rectangleEdge6);
        categoryAxis0.setCategoryMargin((double) ' ');
        categoryAxis0.removeCategoryLabelToolTip((java.lang.Comparable) (byte) 0);
        java.awt.Stroke stroke13 = categoryAxis0.getAxisLineStroke();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "RectangleEdge.TOP" + "'", str7.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setSectionOutlinesVisible(true);
        java.awt.Paint paint4 = piePlot1.getBackgroundPaint();
        java.awt.Paint paint6 = piePlot1.getSectionOutlinePaint((java.lang.Comparable) 100.0f);
        piePlot1.setCircular(true, false);
        double double10 = piePlot1.getLabelGap();
        java.awt.Shape shape11 = piePlot1.getLegendItemShape();
        double double12 = piePlot1.getShadowYOffset();
        double double13 = piePlot1.getLabelLinkMargin();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.025d + "'", double10 == 0.025d);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 4.0d + "'", double12 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.025d + "'", double13 == 0.025d);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.Timeline timeline2 = dateAxis1.getTimeline();
        boolean boolean4 = dateAxis1.isHiddenValue((long) (byte) 1);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.Timeline timeline7 = dateAxis6.getTimeline();
        boolean boolean9 = dateAxis6.isHiddenValue((long) (byte) 1);
        org.jfree.chart.axis.Timeline timeline10 = dateAxis6.getTimeline();
        java.util.Date date11 = dateAxis6.getMaximumDate();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.Timeline timeline14 = dateAxis13.getTimeline();
        boolean boolean16 = dateAxis13.isHiddenValue((long) (byte) 1);
        org.jfree.chart.axis.Timeline timeline17 = dateAxis13.getTimeline();
        java.util.Date date18 = dateAxis13.getMaximumDate();
        try {
            dateAxis1.setRange(date11, date18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeline2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeline7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(timeline10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeline14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(timeline17);
        org.junit.Assert.assertNotNull(date18);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D1.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D1.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, polarItemRenderer6);
        numberAxis3D1.zoomRange((double) (-1), (double) 100.0f);
        double double11 = numberAxis3D1.getLowerBound();
        java.awt.Shape shape12 = numberAxis3D1.getDownArrow();
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.1500000000000001d) + "'", double11 == (-1.1500000000000001d));
        org.junit.Assert.assertNotNull(shape12);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setSectionOutlinesVisible(true);
        java.awt.Paint paint4 = piePlot1.getBackgroundPaint();
        java.awt.Paint paint6 = piePlot1.getSectionOutlinePaint((java.lang.Comparable) 100.0f);
        java.awt.Stroke stroke7 = piePlot1.getLabelLinkStroke();
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        piePlot1.setSectionOutlineStroke((java.lang.Comparable) (byte) 100, stroke9);
        piePlot1.setSectionOutlinesVisible(false);
        java.awt.Paint paint13 = piePlot1.getOutlinePaint();
        java.awt.Paint paint14 = piePlot1.getLabelShadowPaint();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.data.Range range1 = null;
        org.jfree.data.Range range3 = org.jfree.data.Range.expandToInclude(range1, (-1.0d));
        boolean boolean5 = range3.contains((double) 1);
        org.jfree.data.Range range8 = org.jfree.data.Range.shift(range3, (double) 100, false);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot9 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.Plot plot10 = multiplePiePlot9.getParent();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent11 = null;
        multiplePiePlot9.markerChanged(markerChangeEvent11);
        java.lang.Comparable comparable13 = multiplePiePlot9.getAggregatedItemsKey();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent14 = null;
        multiplePiePlot9.datasetChanged(datasetChangeEvent14);
        boolean boolean16 = range3.equals((java.lang.Object) multiplePiePlot9);
        org.jfree.data.Range range18 = org.jfree.data.Range.expandToInclude(range3, (double) (-1));
        org.jfree.chart.block.LengthConstraintType lengthConstraintType19 = null;
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("hi!");
        java.lang.Object obj23 = null;
        boolean boolean24 = dateAxis22.equals(obj23);
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D26 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D26.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D26.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer31 = null;
        org.jfree.chart.plot.PolarPlot polarPlot32 = new org.jfree.chart.plot.PolarPlot(xYDataset25, (org.jfree.chart.axis.ValueAxis) numberAxis3D26, polarItemRenderer31);
        org.jfree.data.Range range33 = null;
        org.jfree.data.Range range35 = org.jfree.data.Range.expandToInclude(range33, (-1.0d));
        numberAxis3D26.setRangeWithMargins(range35);
        dateAxis22.setRange(range35, true, false);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType40 = org.jfree.chart.block.LengthConstraintType.FIXED;
        try {
            org.jfree.chart.block.RectangleConstraint rectangleConstraint41 = new org.jfree.chart.block.RectangleConstraint((double) (byte) -1, range18, lengthConstraintType19, (double) (short) 10, range35, lengthConstraintType40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'widthType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNull(plot10);
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + "Other" + "'", comparable13.equals("Other"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertNotNull(lengthConstraintType40);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D0.setAutoRangeStickyZero(false);
        numberAxis3D0.setUpperBound(100.0d);
        numberAxis3D0.setAutoTickUnitSelection(false);
        java.awt.Font font9 = numberAxis3D0.getTickLabelFont();
        numberAxis3D0.setPositiveArrowVisible(true);
        org.junit.Assert.assertNotNull(font9);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_YELLOW;
        int int1 = color0.getBlue();
        java.awt.image.ColorModel colorModel2 = null;
        java.awt.Rectangle rectangle3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.awt.geom.AffineTransform affineTransform5 = null;
        java.awt.RenderingHints renderingHints6 = null;
        java.awt.PaintContext paintContext7 = color0.createContext(colorModel2, rectangle3, rectangle2D4, affineTransform5, renderingHints6);
        int int8 = color0.getAlpha();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(paintContext7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 255 + "'", int8 == 255);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setBackgroundAlpha((float) (-1));
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        piePlot6.setSectionOutlinesVisible(true);
        java.awt.Paint paint9 = piePlot6.getBackgroundPaint();
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.image.ColorModel colorModel12 = null;
        java.awt.Rectangle rectangle13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.awt.geom.AffineTransform affineTransform15 = null;
        java.awt.RenderingHints renderingHints16 = null;
        java.awt.PaintContext paintContext17 = color11.createContext(colorModel12, rectangle13, rectangle2D14, affineTransform15, renderingHints16);
        piePlot6.setSectionPaint((java.lang.Comparable) (byte) 100, (java.awt.Paint) color11);
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor20 = null;
        org.jfree.chart.block.BlockContainer blockContainer23 = new org.jfree.chart.block.BlockContainer();
        blockContainer23.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D26 = blockContainer23.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double28 = categoryAxis19.getCategoryJava2DCoordinate(categoryAnchor20, (int) (byte) 10, 0, rectangle2D26, rectangleEdge27);
        piePlot6.setLegendItemShape((java.awt.Shape) rectangle2D26);
        piePlot1.drawBackgroundImage(graphics2D4, rectangle2D26);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(paintContext17);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        textBlock0.draw(graphics2D1, (float) (byte) -1, (float) 0, textBlockAnchor4);
        org.junit.Assert.assertNotNull(textBlockAnchor4);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.CLOCKWISE;
        java.lang.String str1 = rotation0.toString();
        org.junit.Assert.assertNotNull(rotation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Rotation.CLOCKWISE" + "'", str1.equals("Rotation.CLOCKWISE"));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setSectionOutlinesVisible(true);
        java.awt.Paint paint4 = piePlot1.getBackgroundPaint();
        java.awt.Paint paint6 = piePlot1.getSectionOutlinePaint((java.lang.Comparable) 100.0f);
        java.awt.Stroke stroke7 = piePlot1.getLabelOutlineStroke();
        java.awt.Paint paint8 = piePlot1.getShadowPaint();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator10 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        piePlot1.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator10);
        java.lang.Object obj12 = standardPieSectionLabelGenerator10.clone();
        java.lang.String str13 = standardPieSectionLabelGenerator10.getLabelFormat();
        java.text.NumberFormat numberFormat14 = standardPieSectionLabelGenerator10.getNumberFormat();
        java.text.NumberFormat numberFormat15 = standardPieSectionLabelGenerator10.getNumberFormat();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(numberFormat14);
        org.junit.Assert.assertNotNull(numberFormat15);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("HorizontalAlignment.RIGHT", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine();
        org.jfree.chart.text.TextFragment textFragment2 = null;
        textLine1.removeFragment(textFragment2);
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("Other");
        textLine1.addFragment(textFragment5);
        textLine0.removeFragment(textFragment5);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.Plot plot1 = multiplePiePlot0.getParent();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        multiplePiePlot0.markerChanged(markerChangeEvent2);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.Plot plot5 = multiplePiePlot4.getParent();
        multiplePiePlot0.setParent((org.jfree.chart.plot.Plot) multiplePiePlot4);
        double[] doubleArray12 = new double[] { (byte) 0, 0.2d, (-1.0d) };
        double[] doubleArray16 = new double[] { (byte) 0, 0.2d, (-1.0d) };
        double[] doubleArray20 = new double[] { (byte) 0, 0.2d, (-1.0d) };
        double[][] doubleArray21 = new double[][] { doubleArray12, doubleArray16, doubleArray20 };
        org.jfree.data.category.CategoryDataset categoryDataset22 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("rect", "RectangleAnchor.BOTTOM_LEFT", doubleArray21);
        multiplePiePlot0.setDataset(categoryDataset22);
        try {
            org.jfree.data.general.PieDataset pieDataset25 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset22, (java.lang.Comparable) 255);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(plot1);
        org.junit.Assert.assertNull(plot5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(categoryDataset22);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("RectangleInsets[t=100.0,l=0.0,b=0.0,r=35.0]", graphics2D1, (double) (short) 100, (float) 3, 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        blockParams0.setTranslateY((double) 0.0f);
        double double3 = blockParams0.getTranslateY();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(0.0d, (double) 0.5f);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        boolean boolean1 = numberAxis3D0.isNegativeArrowVisible();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot3.setLimit(1.0d);
        multiplePiePlot2.setParent((org.jfree.chart.plot.Plot) multiplePiePlot3);
        numberAxis3D0.setPlot((org.jfree.chart.plot.Plot) multiplePiePlot3);
        numberAxis3D0.setAutoRangeMinimumSize((double) 15, false);
        float float11 = numberAxis3D0.getTickMarkInsideLength();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.0f + "'", float11 == 0.0f);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("RectangleAnchor.LEFT");
        numberAxis3D1.setRangeAboutValue(0.0d, 0.05d);
        double double5 = numberAxis3D1.getLowerBound();
        numberAxis3D1.setAxisLineVisible(false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-0.025d) + "'", double5 == (-0.025d));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLowerMargin((double) (short) 100);
        categoryAxis0.setLowerMargin((double) 0);
        java.awt.Font font6 = categoryAxis0.getTickLabelFont((java.lang.Comparable) (byte) 100);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.util.UnitType unitType9 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = new org.jfree.chart.util.RectangleInsets(unitType9, (double) (short) 100, (double) (byte) 0, (double) 0.0f, (double) '#');
        double double16 = rectangleInsets14.calculateBottomOutset((double) 1L);
        java.lang.String str17 = rectangleInsets14.toString();
        org.jfree.chart.block.BlockBorder blockBorder18 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = blockBorder18.getInsets();
        double double21 = rectangleInsets19.trimWidth((double) (byte) 10);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D22 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D22.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D22.setAutoRangeStickyZero(false);
        numberAxis3D22.setUpperBound(100.0d);
        float float29 = numberAxis3D22.getTickMarkOutsideLength();
        org.jfree.chart.block.BlockContainer blockContainer30 = new org.jfree.chart.block.BlockContainer();
        blockContainer30.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D33 = blockContainer30.getBounds();
        numberAxis3D22.setLeftArrow((java.awt.Shape) rectangle2D33);
        org.jfree.chart.entity.ChartEntity chartEntity36 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D33, "");
        java.awt.geom.Rectangle2D rectangle2D37 = rectangleInsets19.createOutsetRectangle(rectangle2D33);
        java.awt.geom.Rectangle2D rectangle2D38 = rectangleInsets14.createOutsetRectangle(rectangle2D33);
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot40 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot40.setLimit(1.0d);
        org.jfree.chart.title.LegendTitle legendTitle43 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot40);
        org.jfree.chart.util.VerticalAlignment verticalAlignment44 = legendTitle43.getVerticalAlignment();
        java.awt.Graphics2D graphics2D45 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint46 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint48 = rectangleConstraint46.toFixedWidth((double) 200);
        org.jfree.chart.util.Size2D size2D49 = legendTitle43.arrange(graphics2D45, rectangleConstraint48);
        org.jfree.chart.block.BlockBorder blockBorder50 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets51 = blockBorder50.getInsets();
        double double53 = rectangleInsets51.trimWidth((double) (byte) 10);
        double double54 = rectangleInsets51.getBottom();
        legendTitle43.setItemLabelPadding(rectangleInsets51);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent56 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle43);
        org.jfree.chart.util.RectangleEdge rectangleEdge57 = legendTitle43.getLegendItemGraphicEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo58 = null;
        try {
            org.jfree.chart.axis.AxisState axisState59 = categoryAxis0.draw(graphics2D7, (double) '#', rectangle2D33, rectangle2D39, rectangleEdge57, plotRenderingInfo58);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(unitType9);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "RectangleInsets[t=100.0,l=0.0,b=0.0,r=35.0]" + "'", str17.equals("RectangleInsets[t=100.0,l=0.0,b=0.0,r=35.0]"));
        org.junit.Assert.assertNotNull(blockBorder18);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 10.0d + "'", double21 == 10.0d);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 1.0f + "'", float29 == 1.0f);
        org.junit.Assert.assertNotNull(rectangle2D33);
        org.junit.Assert.assertNotNull(rectangle2D37);
        org.junit.Assert.assertNotNull(rectangle2D38);
        org.junit.Assert.assertNotNull(verticalAlignment44);
        org.junit.Assert.assertNotNull(rectangleConstraint46);
        org.junit.Assert.assertNotNull(rectangleConstraint48);
        org.junit.Assert.assertNotNull(size2D49);
        org.junit.Assert.assertNotNull(blockBorder50);
        org.junit.Assert.assertNotNull(rectangleInsets51);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 10.0d + "'", double53 == 10.0d);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge57);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0, waferMapRenderer1);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent3 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) waferMapPlot2);
        float float4 = waferMapPlot2.getBackgroundAlpha();
        org.jfree.data.general.WaferMapDataset waferMapDataset5 = null;
        waferMapPlot2.setDataset(waferMapDataset5);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit(1.0d);
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot0);
        org.jfree.chart.plot.Plot plot4 = multiplePiePlot0.getRootPlot();
        org.junit.Assert.assertNotNull(plot4);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        java.awt.Font font2 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer6 = null;
        org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, paint3, (float) (-1), 0, textMeasurer6);
        java.awt.Paint paint8 = null;
        java.awt.Font font12 = null;
        java.awt.Font font14 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint15 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer18 = null;
        org.jfree.chart.text.TextBlock textBlock19 = org.jfree.chart.text.TextUtilities.createTextBlock("", font14, paint15, (float) (-1), 0, textMeasurer18);
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer23 = new org.jfree.chart.text.G2TextMeasurer(graphics2D22);
        org.jfree.chart.text.TextBlock textBlock24 = org.jfree.chart.text.TextUtilities.createTextBlock("", font12, paint15, (float) (short) 100, (int) '4', (org.jfree.chart.text.TextMeasurer) g2TextMeasurer23);
        try {
            org.jfree.chart.text.TextBlock textBlock25 = org.jfree.chart.text.TextUtilities.createTextBlock("TextAnchor.BASELINE_CENTER", font2, paint8, 0.0f, (int) '#', (org.jfree.chart.text.TextMeasurer) g2TextMeasurer23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(textBlock7);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(textBlock19);
        org.junit.Assert.assertNotNull(textBlock24);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D1.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D1.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, polarItemRenderer6);
        java.lang.String str8 = polarPlot7.getPlotType();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent9 = null;
        polarPlot7.datasetChanged(datasetChangeEvent9);
        java.awt.Font font13 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint14 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer17 = null;
        org.jfree.chart.text.TextBlock textBlock18 = org.jfree.chart.text.TextUtilities.createTextBlock("", font13, paint14, (float) (-1), 0, textMeasurer17);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot19 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener20 = null;
        multiplePiePlot19.removeChangeListener(plotChangeListener20);
        org.jfree.chart.plot.Plot plot22 = multiplePiePlot19.getParent();
        org.jfree.chart.JFreeChart jFreeChart24 = new org.jfree.chart.JFreeChart("ThreadContext", font13, (org.jfree.chart.plot.Plot) multiplePiePlot19, false);
        jFreeChart24.setBackgroundImageAlignment(200);
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent27 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) datasetChangeEvent9, jFreeChart24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Polar Plot" + "'", str8.equals("Polar Plot"));
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(textBlock18);
        org.junit.Assert.assertNull(plot22);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        double[] doubleArray5 = new double[] { (byte) 0, 0.2d, (-1.0d) };
        double[] doubleArray9 = new double[] { (byte) 0, 0.2d, (-1.0d) };
        double[] doubleArray13 = new double[] { (byte) 0, 0.2d, (-1.0d) };
        double[][] doubleArray14 = new double[][] { doubleArray5, doubleArray9, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("rect", "RectangleAnchor.BOTTOM_LEFT", doubleArray14);
        try {
            org.jfree.data.general.PieDataset pieDataset17 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset15, (java.lang.Comparable) 64);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        boolean boolean1 = numberAxis3D0.isAutoTickUnitSelection();
        boolean boolean2 = numberAxis3D0.isVerticalTickLabels();
        numberAxis3D0.setAutoTickUnitSelection(false, false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setSectionOutlinesVisible(true);
        java.awt.Paint paint4 = piePlot1.getBackgroundPaint();
        java.awt.Paint paint6 = piePlot1.getSectionOutlinePaint((java.lang.Comparable) 100.0f);
        java.awt.Stroke stroke7 = piePlot1.getLabelLinkStroke();
        int int8 = piePlot1.getBackgroundImageAlignment();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 15 + "'", int8 == 15);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        blockContainer0.setWidth((double) 10.0f);
        org.jfree.chart.block.BlockBorder blockBorder3 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = blockBorder3.getInsets();
        blockContainer0.setMargin(rectangleInsets4);
        double double6 = blockContainer0.getHeight();
        org.junit.Assert.assertNotNull(blockBorder3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.RangeType rangeType1 = numberAxis3D0.getRangeType();
        numberAxis3D0.setFixedDimension((double) (-1));
        org.jfree.data.general.WaferMapDataset waferMapDataset4 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer5 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot6 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset4, waferMapRenderer5);
        waferMapPlot6.setForegroundAlpha(0.0f);
        java.awt.Paint paint9 = null;
        waferMapPlot6.setOutlinePaint(paint9);
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer11 = null;
        waferMapPlot6.setRenderer(waferMapRenderer11);
        numberAxis3D0.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot6);
        org.junit.Assert.assertNotNull(rangeType1);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        java.awt.Font font2 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer6 = null;
        org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, paint3, (float) (-1), 0, textMeasurer6);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        multiplePiePlot8.removeChangeListener(plotChangeListener9);
        org.jfree.chart.plot.Plot plot11 = multiplePiePlot8.getParent();
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("ThreadContext", font2, (org.jfree.chart.plot.Plot) multiplePiePlot8, false);
        org.jfree.chart.event.ChartChangeListener chartChangeListener14 = null;
        try {
            jFreeChart13.addChangeListener(chartChangeListener14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(textBlock7);
        org.junit.Assert.assertNull(plot11);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("RectangleAnchor.LEFT");
        numberAxis3D1.setRangeAboutValue(0.0d, 0.05d);
        double double5 = numberAxis3D1.getLowerBound();
        numberAxis3D1.setInverted(false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-0.025d) + "'", double5 == (-0.025d));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = null;
        org.jfree.chart.block.BlockContainer blockContainer4 = new org.jfree.chart.block.BlockContainer();
        blockContainer4.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D7 = blockContainer4.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        try {
            double double9 = categoryAxis3D0.getCategoryJava2DCoordinate(categoryAnchor1, 10, 15, rectangle2D7, rectangleEdge8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        java.awt.Font font2 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer6 = null;
        org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, paint3, (float) (-1), 0, textMeasurer6);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        multiplePiePlot8.removeChangeListener(plotChangeListener9);
        org.jfree.chart.plot.Plot plot11 = multiplePiePlot8.getParent();
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("ThreadContext", font2, (org.jfree.chart.plot.Plot) multiplePiePlot8, false);
        org.jfree.chart.title.LegendTitle legendTitle14 = jFreeChart13.getLegend();
        java.awt.Paint paint15 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        jFreeChart13.setBorderPaint(paint15);
        float float17 = jFreeChart13.getBackgroundImageAlpha();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(textBlock7);
        org.junit.Assert.assertNull(plot11);
        org.junit.Assert.assertNull(legendTitle14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.5f + "'", float17 == 0.5f);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_START_ANGLE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 90.0d + "'", double0 == 90.0d);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor10 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D5, (float) (byte) 100, (float) 100L, textAnchor8, (-1.1500000000000001d), textAnchor10);
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D1, (float) (short) 0, (float) (byte) -1, textAnchor10, (-1.0d), (float) 3, 100.0f);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertNotNull(textAnchor10);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit(1.0d);
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot0);
        org.jfree.data.category.CategoryDataset categoryDataset4 = multiplePiePlot0.getDataset();
        org.junit.Assert.assertNull(categoryDataset4);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        boolean boolean1 = numberAxis3D0.isAutoTickUnitSelection();
        boolean boolean2 = numberAxis3D0.isVisible();
        boolean boolean3 = numberAxis3D0.isAutoRange();
        numberAxis3D0.setVisible(true);
        boolean boolean6 = numberAxis3D0.isInverted();
        java.lang.String str7 = numberAxis3D0.getLabel();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.Timeline timeline2 = dateAxis1.getTimeline();
        boolean boolean4 = dateAxis1.isHiddenValue((long) (byte) 1);
        org.jfree.chart.axis.Timeline timeline5 = dateAxis1.getTimeline();
        java.util.Date date6 = dateAxis1.getMinimumDate();
        java.util.Date date7 = null;
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D9 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D9.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D9.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer14 = null;
        org.jfree.chart.plot.PolarPlot polarPlot15 = new org.jfree.chart.plot.PolarPlot(xYDataset8, (org.jfree.chart.axis.ValueAxis) numberAxis3D9, polarItemRenderer14);
        double double16 = polarPlot15.getMaxRadius();
        org.jfree.chart.block.BlockContainer blockContainer19 = new org.jfree.chart.block.BlockContainer();
        blockContainer19.setWidth((double) 10.0f);
        org.jfree.chart.block.BlockBorder blockBorder22 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = blockBorder22.getInsets();
        blockContainer19.setMargin(rectangleInsets23);
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint28 = rectangleConstraint26.toFixedWidth((double) 200);
        org.jfree.chart.util.Size2D size2D29 = blockContainer19.arrange(graphics2D25, rectangleConstraint28);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot30 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot30.setLimit(1.0d);
        org.jfree.chart.title.LegendTitle legendTitle33 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot30);
        org.jfree.chart.util.VerticalAlignment verticalAlignment34 = legendTitle33.getVerticalAlignment();
        java.awt.Graphics2D graphics2D35 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint36 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint38 = rectangleConstraint36.toFixedWidth((double) 200);
        org.jfree.chart.util.Size2D size2D39 = legendTitle33.arrange(graphics2D35, rectangleConstraint38);
        size2D39.height = 100.0f;
        org.jfree.chart.util.Size2D size2D42 = rectangleConstraint28.calculateConstrainedSize(size2D39);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor45 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.lang.String str46 = rectangleAnchor45.toString();
        java.awt.geom.Rectangle2D rectangle2D47 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D39, 0.0d, 0.4d, rectangleAnchor45);
        java.awt.Point point48 = polarPlot15.translateValueThetaRadiusToJava2D((double) 1.0f, (double) (short) 10, rectangle2D47);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot49 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot49.setLimit(1.0d);
        org.jfree.chart.title.LegendTitle legendTitle52 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot49);
        org.jfree.chart.util.RectangleEdge rectangleEdge53 = legendTitle52.getPosition();
        try {
            double double54 = dateAxis1.dateToJava2D(date7, rectangle2D47, rectangleEdge53);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeline2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeline5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.05d + "'", double16 == 1.05d);
        org.junit.Assert.assertNotNull(blockBorder22);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(rectangleConstraint26);
        org.junit.Assert.assertNotNull(rectangleConstraint28);
        org.junit.Assert.assertNotNull(size2D29);
        org.junit.Assert.assertNotNull(verticalAlignment34);
        org.junit.Assert.assertNotNull(rectangleConstraint36);
        org.junit.Assert.assertNotNull(rectangleConstraint38);
        org.junit.Assert.assertNotNull(size2D39);
        org.junit.Assert.assertNotNull(size2D42);
        org.junit.Assert.assertNotNull(rectangleAnchor45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "RectangleAnchor.LEFT" + "'", str46.equals("RectangleAnchor.LEFT"));
        org.junit.Assert.assertNotNull(rectangle2D47);
        org.junit.Assert.assertNotNull(point48);
        org.junit.Assert.assertNotNull(rectangleEdge53);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Paint paint2 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        categoryAxis3D0.setTickLabelPaint((java.lang.Comparable) '#', paint2);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit(1.0d);
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot0);
        java.lang.Object obj4 = legendTitle3.clone();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        java.awt.Font font8 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint9 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer12 = null;
        org.jfree.chart.text.TextBlock textBlock13 = org.jfree.chart.text.TextUtilities.createTextBlock("", font8, paint9, (float) (-1), 0, textMeasurer12);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor17 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        java.awt.Shape shape21 = textBlock13.calculateBounds(graphics2D14, 0.0f, (float) 255, textBlockAnchor17, (float) (short) 0, (float) (byte) -1, (double) (short) 1);
        piePlot6.setLegendItemShape(shape21);
        java.awt.Shape shape23 = piePlot6.getLegendItemShape();
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D25 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D25.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D25.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer30 = null;
        org.jfree.chart.plot.PolarPlot polarPlot31 = new org.jfree.chart.plot.PolarPlot(xYDataset24, (org.jfree.chart.axis.ValueAxis) numberAxis3D25, polarItemRenderer30);
        java.lang.String str32 = polarPlot31.getPlotType();
        org.jfree.data.general.PieDataset pieDataset33 = null;
        org.jfree.chart.plot.RingPlot ringPlot34 = new org.jfree.chart.plot.RingPlot(pieDataset33);
        org.jfree.chart.plot.Plot plot35 = ringPlot34.getRootPlot();
        org.jfree.chart.LegendItemSource[] legendItemSourceArray36 = new org.jfree.chart.LegendItemSource[] { piePlot6, polarPlot31, plot35 };
        legendTitle3.setSources(legendItemSourceArray36);
        double double38 = legendTitle3.getContentYOffset();
        java.awt.Graphics2D graphics2D39 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot40 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot40.setLimit(1.0d);
        org.jfree.chart.title.LegendTitle legendTitle43 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot40);
        org.jfree.chart.block.BlockContainer blockContainer44 = new org.jfree.chart.block.BlockContainer();
        blockContainer44.setWidth((double) 10.0f);
        org.jfree.chart.block.BlockBorder blockBorder47 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = blockBorder47.getInsets();
        blockContainer44.setMargin(rectangleInsets48);
        java.lang.String str50 = blockContainer44.getID();
        legendTitle43.setWrapper(blockContainer44);
        java.awt.geom.Rectangle2D rectangle2D52 = blockContainer44.getBounds();
        java.awt.Image image56 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo60 = new org.jfree.chart.ui.ProjectInfo("hi!", "", "RectangleEdge.TOP", image56, "RectangleEdge.TOP", "", "RectangleEdge.TOP");
        projectInfo60.setVersion("TextAnchor.CENTER_RIGHT");
        java.awt.Image image66 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo70 = new org.jfree.chart.ui.ProjectInfo("hi!", "", "RectangleEdge.TOP", image66, "RectangleEdge.TOP", "", "RectangleEdge.TOP");
        projectInfo70.setVersion("TextAnchor.CENTER_RIGHT");
        projectInfo60.addLibrary((org.jfree.chart.ui.Library) projectInfo70);
        java.awt.Image image74 = null;
        projectInfo60.setLogo(image74);
        try {
            java.lang.Object obj76 = legendTitle3.draw(graphics2D39, rectangle2D52, (java.lang.Object) image74);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(textBlock13);
        org.junit.Assert.assertNotNull(textBlockAnchor17);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Polar Plot" + "'", str32.equals("Polar Plot"));
        org.junit.Assert.assertNotNull(plot35);
        org.junit.Assert.assertNotNull(legendItemSourceArray36);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 1.0d + "'", double38 == 1.0d);
        org.junit.Assert.assertNotNull(blockBorder47);
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertNull(str50);
        org.junit.Assert.assertNotNull(rectangle2D52);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        double double0 = org.jfree.chart.plot.PolarPlot.DEFAULT_ANGLE_TICK_UNIT_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 45.0d + "'", double0 == 45.0d);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D0.setAutoRangeStickyZero(false);
        numberAxis3D0.setUpperBound(100.0d);
        float float7 = numberAxis3D0.getTickMarkOutsideLength();
        org.jfree.chart.block.BlockContainer blockContainer8 = new org.jfree.chart.block.BlockContainer();
        blockContainer8.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D11 = blockContainer8.getBounds();
        numberAxis3D0.setLeftArrow((java.awt.Shape) rectangle2D11);
        org.jfree.chart.entity.ChartEntity chartEntity14 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D11, "");
        java.lang.Object obj15 = chartEntity14.clone();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D16 = new org.jfree.chart.axis.NumberAxis3D();
        boolean boolean17 = numberAxis3D16.isAutoTickUnitSelection();
        boolean boolean18 = numberAxis3D16.isVerticalTickLabels();
        java.awt.Shape shape19 = numberAxis3D16.getLeftArrow();
        chartEntity14.setArea(shape19);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(shape19);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D0.setAutoRangeStickyZero(false);
        numberAxis3D0.setUpperBound(100.0d);
        float float7 = numberAxis3D0.getTickMarkOutsideLength();
        numberAxis3D0.setLabel("ThreadContext");
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setSectionOutlinesVisible(true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent4 = null;
        piePlot1.axisChanged(axisChangeEvent4);
        double double6 = piePlot1.getMinimumArcAngleToDraw();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0E-5d + "'", double6 == 1.0E-5d);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.chart.PaintMap paintMap0 = new org.jfree.chart.PaintMap();
        java.lang.Object obj1 = paintMap0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.plot.Plot plot3 = multiplePiePlot0.getParent();
        org.jfree.data.category.CategoryDataset categoryDataset4 = multiplePiePlot0.getDataset();
        java.lang.Comparable comparable5 = multiplePiePlot0.getAggregatedItemsKey();
        double[] doubleArray11 = new double[] { (byte) 0, 0.2d, (-1.0d) };
        double[] doubleArray15 = new double[] { (byte) 0, 0.2d, (-1.0d) };
        double[] doubleArray19 = new double[] { (byte) 0, 0.2d, (-1.0d) };
        double[][] doubleArray20 = new double[][] { doubleArray11, doubleArray15, doubleArray19 };
        org.jfree.data.category.CategoryDataset categoryDataset21 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("rect", "RectangleAnchor.BOTTOM_LEFT", doubleArray20);
        java.lang.Number number22 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset21);
        multiplePiePlot0.setDataset(categoryDataset21);
        org.jfree.data.Range range25 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset21, false);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNull(categoryDataset4);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + "Other" + "'", comparable5.equals("Other"));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(categoryDataset21);
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + 0.2d + "'", number22.equals(0.2d));
        org.junit.Assert.assertNotNull(range25);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = org.jfree.chart.util.VerticalAlignment.CENTER;
        java.awt.Paint paint3 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        boolean boolean4 = verticalAlignment2.equals((java.lang.Object) paint3);
        org.jfree.chart.block.ColumnArrangement columnArrangement7 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment1, verticalAlignment2, (double) (byte) 1, (double) (byte) -1);
        boolean boolean8 = piePlot3D0.equals((java.lang.Object) (byte) 1);
        java.awt.Paint paint9 = piePlot3D0.getLabelOutlinePaint();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor10 = piePlot3D0.getLabelDistributor();
        abstractPieLabelDistributor10.clear();
        int int12 = abstractPieLabelDistributor10.getItemCount();
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("Other");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.text.TextAnchor textAnchor3 = null;
        try {
            float float4 = textFragment1.calculateBaselineOffset(graphics2D2, textAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D1, (double) 64, (float) (short) 10, (float) 0L);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        float float0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.5f + "'", float0 == 0.5f);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getCategoryMargin();
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) 100, "TextAnchor.CENTER_RIGHT");
        categoryAxis0.configure();
        java.awt.Paint paint6 = categoryAxis0.getAxisLinePaint();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot1.getPieChart();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot3.setLimit(1.0d);
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot3);
        java.lang.Object obj7 = legendTitle6.clone();
        jFreeChart2.removeSubtitle((org.jfree.chart.title.Title) legendTitle6);
        java.awt.Paint paint9 = jFreeChart2.getBackgroundPaint();
        org.junit.Assert.assertNotNull(jFreeChart2);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNull(paint9);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.data.Range range1 = null;
        org.jfree.data.Range range3 = org.jfree.data.Range.expandToInclude(range1, (-1.0d));
        boolean boolean5 = range3.contains((double) 1);
        org.jfree.data.Range range8 = org.jfree.data.Range.shift(range3, (double) 100, false);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot9 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.Plot plot10 = multiplePiePlot9.getParent();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent11 = null;
        multiplePiePlot9.markerChanged(markerChangeEvent11);
        java.lang.Comparable comparable13 = multiplePiePlot9.getAggregatedItemsKey();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent14 = null;
        multiplePiePlot9.datasetChanged(datasetChangeEvent14);
        boolean boolean16 = range3.equals((java.lang.Object) multiplePiePlot9);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType17 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.data.Range range19 = null;
        org.jfree.data.Range range21 = org.jfree.data.Range.expandToInclude(range19, (-1.0d));
        boolean boolean23 = range21.contains((double) 1);
        org.jfree.data.Range range26 = org.jfree.data.Range.shift(range21, (double) 100, false);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot27 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.Plot plot28 = multiplePiePlot27.getParent();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent29 = null;
        multiplePiePlot27.markerChanged(markerChangeEvent29);
        java.lang.Comparable comparable31 = multiplePiePlot27.getAggregatedItemsKey();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent32 = null;
        multiplePiePlot27.datasetChanged(datasetChangeEvent32);
        boolean boolean34 = range21.equals((java.lang.Object) multiplePiePlot27);
        org.jfree.data.Range range36 = org.jfree.data.Range.expandToInclude(range21, (double) (-1));
        org.jfree.data.Range range38 = org.jfree.data.Range.shift(range21, (double) (byte) 1);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType39 = null;
        try {
            org.jfree.chart.block.RectangleConstraint rectangleConstraint40 = new org.jfree.chart.block.RectangleConstraint(1.05d, range3, lengthConstraintType17, (double) 1, range38, lengthConstraintType39);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'heightType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNull(plot10);
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + "Other" + "'", comparable13.equals("Other"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(lengthConstraintType17);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertNull(plot28);
        org.junit.Assert.assertTrue("'" + comparable31 + "' != '" + "Other" + "'", comparable31.equals("Other"));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(range36);
        org.junit.Assert.assertNotNull(range38);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        java.awt.Image image0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE;
        org.junit.Assert.assertNull(image0);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer5 = null;
        org.jfree.chart.text.TextBlock textBlock6 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint2, (float) (-1), 0, textMeasurer5);
        org.jfree.chart.text.TextLine textLine7 = textBlock6.getLastLine();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(textBlock6);
        org.junit.Assert.assertNull(textLine7);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setSectionOutlinesVisible(true);
        java.awt.Paint paint4 = piePlot1.getBackgroundPaint();
        java.awt.Paint paint6 = piePlot1.getSectionOutlinePaint((java.lang.Comparable) 100.0f);
        java.awt.Stroke stroke7 = piePlot1.getLabelOutlineStroke();
        java.awt.Paint paint8 = piePlot1.getShadowPaint();
        piePlot1.setShadowYOffset((double) 1.0f);
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        piePlot12.setSectionOutlinesVisible(true);
        java.awt.Paint paint15 = piePlot12.getBackgroundPaint();
        java.awt.Paint paint17 = piePlot12.getSectionOutlinePaint((java.lang.Comparable) 100.0f);
        java.awt.Stroke stroke18 = piePlot12.getLabelLinkStroke();
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        piePlot12.setSectionOutlineStroke((java.lang.Comparable) (byte) 100, stroke20);
        piePlot12.setSectionOutlinesVisible(false);
        java.awt.Color color27 = java.awt.Color.getHSBColor((float) 3, (float) (short) 100, (float) (short) 10);
        piePlot12.setBaseSectionPaint((java.awt.Paint) color27);
        piePlot1.setShadowPaint((java.awt.Paint) color27);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color27);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) blockBorder0, jFreeChart1);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = null;
        chartChangeEvent2.setType(chartChangeEventType3);
        java.awt.Font font7 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint8 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer11 = null;
        org.jfree.chart.text.TextBlock textBlock12 = org.jfree.chart.text.TextUtilities.createTextBlock("", font7, paint8, (float) (-1), 0, textMeasurer11);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot13 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener14 = null;
        multiplePiePlot13.removeChangeListener(plotChangeListener14);
        org.jfree.chart.plot.Plot plot16 = multiplePiePlot13.getParent();
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("ThreadContext", font7, (org.jfree.chart.plot.Plot) multiplePiePlot13, false);
        org.jfree.chart.title.LegendTitle legendTitle19 = jFreeChart18.getLegend();
        java.awt.Paint paint20 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        jFreeChart18.setBorderPaint(paint20);
        org.jfree.chart.event.ChartProgressListener chartProgressListener22 = null;
        jFreeChart18.removeProgressListener(chartProgressListener22);
        java.awt.Stroke stroke24 = jFreeChart18.getBorderStroke();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo29 = null;
        java.awt.image.BufferedImage bufferedImage30 = jFreeChart18.createBufferedImage(10, (int) (byte) 1, (double) (byte) 10, (double) 100, chartRenderingInfo29);
        java.awt.Paint paint31 = jFreeChart18.getBackgroundPaint();
        chartChangeEvent2.setChart(jFreeChart18);
        org.jfree.chart.block.BlockBorder blockBorder33 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = blockBorder33.getInsets();
        double double36 = rectangleInsets34.trimWidth((double) (byte) 10);
        org.jfree.chart.util.UnitType unitType37 = rectangleInsets34.getUnitType();
        double double38 = rectangleInsets34.getRight();
        jFreeChart18.setPadding(rectangleInsets34);
        org.junit.Assert.assertNotNull(blockBorder0);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(textBlock12);
        org.junit.Assert.assertNull(plot16);
        org.junit.Assert.assertNull(legendTitle19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(bufferedImage30);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(blockBorder33);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 10.0d + "'", double36 == 10.0d);
        org.junit.Assert.assertNotNull(unitType37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        java.awt.Font font2 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer6 = null;
        org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, paint3, (float) (-1), 0, textMeasurer6);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        multiplePiePlot8.removeChangeListener(plotChangeListener9);
        org.jfree.chart.plot.Plot plot11 = multiplePiePlot8.getParent();
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("ThreadContext", font2, (org.jfree.chart.plot.Plot) multiplePiePlot8, false);
        org.jfree.chart.title.LegendTitle legendTitle14 = jFreeChart13.getLegend();
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D17 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D17.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D17.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer22 = null;
        org.jfree.chart.plot.PolarPlot polarPlot23 = new org.jfree.chart.plot.PolarPlot(xYDataset16, (org.jfree.chart.axis.ValueAxis) numberAxis3D17, polarItemRenderer22);
        double double24 = polarPlot23.getMaxRadius();
        org.jfree.chart.block.BlockContainer blockContainer27 = new org.jfree.chart.block.BlockContainer();
        blockContainer27.setWidth((double) 10.0f);
        org.jfree.chart.block.BlockBorder blockBorder30 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = blockBorder30.getInsets();
        blockContainer27.setMargin(rectangleInsets31);
        java.awt.Graphics2D graphics2D33 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint34 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint36 = rectangleConstraint34.toFixedWidth((double) 200);
        org.jfree.chart.util.Size2D size2D37 = blockContainer27.arrange(graphics2D33, rectangleConstraint36);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot38 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot38.setLimit(1.0d);
        org.jfree.chart.title.LegendTitle legendTitle41 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot38);
        org.jfree.chart.util.VerticalAlignment verticalAlignment42 = legendTitle41.getVerticalAlignment();
        java.awt.Graphics2D graphics2D43 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint44 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint46 = rectangleConstraint44.toFixedWidth((double) 200);
        org.jfree.chart.util.Size2D size2D47 = legendTitle41.arrange(graphics2D43, rectangleConstraint46);
        size2D47.height = 100.0f;
        org.jfree.chart.util.Size2D size2D50 = rectangleConstraint36.calculateConstrainedSize(size2D47);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor53 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.lang.String str54 = rectangleAnchor53.toString();
        java.awt.geom.Rectangle2D rectangle2D55 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D47, 0.0d, 0.4d, rectangleAnchor53);
        java.awt.Point point56 = polarPlot23.translateValueThetaRadiusToJava2D((double) 1.0f, (double) (short) 10, rectangle2D55);
        try {
            jFreeChart13.draw(graphics2D15, rectangle2D55);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(textBlock7);
        org.junit.Assert.assertNull(plot11);
        org.junit.Assert.assertNull(legendTitle14);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.05d + "'", double24 == 1.05d);
        org.junit.Assert.assertNotNull(blockBorder30);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(rectangleConstraint34);
        org.junit.Assert.assertNotNull(rectangleConstraint36);
        org.junit.Assert.assertNotNull(size2D37);
        org.junit.Assert.assertNotNull(verticalAlignment42);
        org.junit.Assert.assertNotNull(rectangleConstraint44);
        org.junit.Assert.assertNotNull(rectangleConstraint46);
        org.junit.Assert.assertNotNull(size2D47);
        org.junit.Assert.assertNotNull(size2D50);
        org.junit.Assert.assertNotNull(rectangleAnchor53);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "RectangleAnchor.LEFT" + "'", str54.equals("RectangleAnchor.LEFT"));
        org.junit.Assert.assertNotNull(rectangle2D55);
        org.junit.Assert.assertNotNull(point56);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getCategoryMargin();
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) 100, "TextAnchor.CENTER_RIGHT");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions5 = null;
        try {
            categoryAxis0.setCategoryLabelPositions(categoryLabelPositions5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'positions' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.data.KeyedValues keyedValues1 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) 100L, keyedValues1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowData' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        java.lang.Object obj0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.Plot plot3 = multiplePiePlot2.getParent();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent4 = null;
        multiplePiePlot2.markerChanged(markerChangeEvent4);
        java.lang.Comparable comparable6 = multiplePiePlot2.getAggregatedItemsKey();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = null;
        multiplePiePlot2.datasetChanged(datasetChangeEvent7);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("ClassContext", (org.jfree.chart.plot.Plot) multiplePiePlot2);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType10 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent11 = new org.jfree.chart.event.ChartChangeEvent(obj0, jFreeChart9, chartChangeEventType10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + "Other" + "'", comparable6.equals("Other"));
        org.junit.Assert.assertNotNull(chartChangeEventType10);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        blockContainer0.setWidth((double) 10.0f);
        org.jfree.chart.block.BlockBorder blockBorder3 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = blockBorder3.getInsets();
        blockContainer0.setMargin(rectangleInsets4);
        boolean boolean6 = blockContainer0.isEmpty();
        java.lang.Object obj7 = blockContainer0.clone();
        org.junit.Assert.assertNotNull(blockBorder3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        boolean boolean1 = numberAxis3D0.isAutoTickUnitSelection();
        boolean boolean2 = numberAxis3D0.isVerticalTickLabels();
        java.awt.Shape shape3 = numberAxis3D0.getLeftArrow();
        java.awt.Font font4 = numberAxis3D0.getTickLabelFont();
        java.awt.Paint paint5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        numberAxis3D0.setTickLabelPaint(paint5);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setSectionOutlinesVisible(true);
        double double4 = piePlot1.getMinimumArcAngleToDraw();
        java.lang.Object obj5 = piePlot1.clone();
        org.jfree.chart.util.UnitType unitType6 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = new org.jfree.chart.util.RectangleInsets(unitType6, (double) (short) 100, (double) (byte) 0, (double) 0.0f, (double) '#');
        double double13 = rectangleInsets11.calculateBottomOutset((double) 1L);
        piePlot1.setInsets(rectangleInsets11, false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-5d + "'", double4 == 1.0E-5d);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(unitType6);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        boolean boolean1 = numberAxis3D0.isNegativeArrowVisible();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot3.setLimit(1.0d);
        multiplePiePlot2.setParent((org.jfree.chart.plot.Plot) multiplePiePlot3);
        numberAxis3D0.setPlot((org.jfree.chart.plot.Plot) multiplePiePlot3);
        java.awt.Paint paint9 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.LineBorder lineBorder10 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke11 = lineBorder10.getStroke();
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) 10, paint9, stroke11);
        multiplePiePlot3.setOutlineStroke(stroke11);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        boolean boolean1 = numberAxis3D0.isNegativeArrowVisible();
        numberAxis3D0.setInverted(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("RectangleAnchor.LEFT", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D3.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D3.setAutoRangeStickyZero(false);
        numberAxis3D3.setUpperBound(100.0d);
        float float10 = numberAxis3D3.getTickMarkOutsideLength();
        org.jfree.chart.block.BlockContainer blockContainer11 = new org.jfree.chart.block.BlockContainer();
        blockContainer11.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D14 = blockContainer11.getBounds();
        numberAxis3D3.setLeftArrow((java.awt.Shape) rectangle2D14);
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.plot.PiePlot piePlot17 = new org.jfree.chart.plot.PiePlot(pieDataset16);
        piePlot17.setSectionOutlinesVisible(true);
        java.awt.Paint paint20 = piePlot17.getBackgroundPaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        org.jfree.chart.plot.PiePlotState piePlotState23 = ringPlot1.initialise(graphics2D2, rectangle2D14, piePlot17, (java.lang.Integer) 3, plotRenderingInfo22);
        ringPlot1.setMinimumArcAngleToDraw((double) (byte) 100);
        java.awt.Paint paint26 = ringPlot1.getSeparatorPaint();
        ringPlot1.setSimpleLabels(true);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 1.0f + "'", float10 == 1.0f);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(piePlotState23);
        org.junit.Assert.assertNotNull(paint26);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_DOMAIN_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D0.setAutoRangeStickyZero(false);
        numberAxis3D0.setLabel("ThreadContext");
        numberAxis3D0.setAutoRangeStickyZero(true);
        java.awt.Paint paint9 = numberAxis3D0.getTickLabelPaint();
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit(1.0d);
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot0);
        org.jfree.chart.block.BlockContainer blockContainer4 = new org.jfree.chart.block.BlockContainer();
        blockContainer4.setWidth((double) 10.0f);
        org.jfree.chart.block.BlockBorder blockBorder7 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = blockBorder7.getInsets();
        blockContainer4.setMargin(rectangleInsets8);
        java.lang.String str10 = blockContainer4.getID();
        legendTitle3.setWrapper(blockContainer4);
        java.awt.geom.Rectangle2D rectangle2D12 = blockContainer4.getBounds();
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.util.UnitType unitType14 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = new org.jfree.chart.util.RectangleInsets(unitType14, (double) (short) 100, (double) (byte) 0, (double) 0.0f, (double) '#');
        double double21 = rectangleInsets19.calculateBottomOutset((double) 1L);
        java.lang.String str22 = rectangleInsets19.toString();
        org.jfree.chart.block.BlockBorder blockBorder23 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = blockBorder23.getInsets();
        double double26 = rectangleInsets24.trimWidth((double) (byte) 10);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D27 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D27.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D27.setAutoRangeStickyZero(false);
        numberAxis3D27.setUpperBound(100.0d);
        float float34 = numberAxis3D27.getTickMarkOutsideLength();
        org.jfree.chart.block.BlockContainer blockContainer35 = new org.jfree.chart.block.BlockContainer();
        blockContainer35.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D38 = blockContainer35.getBounds();
        numberAxis3D27.setLeftArrow((java.awt.Shape) rectangle2D38);
        org.jfree.chart.entity.ChartEntity chartEntity41 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D38, "");
        java.awt.geom.Rectangle2D rectangle2D42 = rectangleInsets24.createOutsetRectangle(rectangle2D38);
        java.awt.geom.Rectangle2D rectangle2D43 = rectangleInsets19.createOutsetRectangle(rectangle2D38);
        org.jfree.chart.entity.ChartEntity chartEntity44 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D38);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType45 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment46 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment47 = org.jfree.chart.util.VerticalAlignment.CENTER;
        java.awt.Paint paint48 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        boolean boolean49 = verticalAlignment47.equals((java.lang.Object) paint48);
        org.jfree.chart.block.ColumnArrangement columnArrangement52 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment46, verticalAlignment47, (double) (byte) 1, (double) (byte) -1);
        boolean boolean53 = chartChangeEventType45.equals((java.lang.Object) verticalAlignment47);
        try {
            java.lang.Object obj54 = blockContainer4.draw(graphics2D13, rectangle2D38, (java.lang.Object) chartChangeEventType45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockBorder7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertNotNull(unitType14);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "RectangleInsets[t=100.0,l=0.0,b=0.0,r=35.0]" + "'", str22.equals("RectangleInsets[t=100.0,l=0.0,b=0.0,r=35.0]"));
        org.junit.Assert.assertNotNull(blockBorder23);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 10.0d + "'", double26 == 10.0d);
        org.junit.Assert.assertTrue("'" + float34 + "' != '" + 1.0f + "'", float34 == 1.0f);
        org.junit.Assert.assertNotNull(rectangle2D38);
        org.junit.Assert.assertNotNull(rectangle2D42);
        org.junit.Assert.assertNotNull(rectangle2D43);
        org.junit.Assert.assertNotNull(chartChangeEventType45);
        org.junit.Assert.assertNotNull(horizontalAlignment46);
        org.junit.Assert.assertNotNull(verticalAlignment47);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (short) 100, (double) (byte) 0, (double) 0.0f, (double) '#');
        double double7 = rectangleInsets5.calculateBottomOutset((double) 1L);
        double double8 = rectangleInsets5.getRight();
        double double9 = rectangleInsets5.getLeft();
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 35.0d + "'", double8 == 35.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        boolean boolean1 = numberAxis3D0.isNegativeArrowVisible();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot3.setLimit(1.0d);
        multiplePiePlot2.setParent((org.jfree.chart.plot.Plot) multiplePiePlot3);
        numberAxis3D0.setPlot((org.jfree.chart.plot.Plot) multiplePiePlot3);
        double double8 = numberAxis3D0.getLowerMargin();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        java.awt.Font font5 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint6 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer9 = null;
        org.jfree.chart.text.TextBlock textBlock10 = org.jfree.chart.text.TextUtilities.createTextBlock("", font5, paint6, (float) (-1), 0, textMeasurer9);
        org.jfree.chart.block.BlockBorder blockBorder11 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, (double) (byte) 10, (double) 10L, (double) 255, paint6);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment12 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment13 = org.jfree.chart.util.VerticalAlignment.CENTER;
        java.awt.Paint paint14 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        boolean boolean15 = verticalAlignment13.equals((java.lang.Object) paint14);
        org.jfree.chart.block.ColumnArrangement columnArrangement18 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment12, verticalAlignment13, (double) (byte) 1, (double) (byte) -1);
        java.lang.String str19 = horizontalAlignment12.toString();
        boolean boolean20 = blockBorder11.equals((java.lang.Object) str19);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(textBlock10);
        org.junit.Assert.assertNotNull(horizontalAlignment12);
        org.junit.Assert.assertNotNull(verticalAlignment13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "HorizontalAlignment.RIGHT" + "'", str19.equals("HorizontalAlignment.RIGHT"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        org.jfree.data.general.PieDataset pieDataset2 = null;
        try {
            java.text.AttributedString attributedString4 = standardPieSectionLabelGenerator1.generateAttributedSectionLabel(pieDataset2, (java.lang.Comparable) 1.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        java.awt.Font font2 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer6 = null;
        org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, paint3, (float) (-1), 0, textMeasurer6);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        multiplePiePlot8.removeChangeListener(plotChangeListener9);
        org.jfree.chart.plot.Plot plot11 = multiplePiePlot8.getParent();
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("ThreadContext", font2, (org.jfree.chart.plot.Plot) multiplePiePlot8, false);
        java.util.List list14 = jFreeChart13.getSubtitles();
        org.jfree.chart.block.BlockContainer blockContainer15 = new org.jfree.chart.block.BlockContainer();
        blockContainer15.setWidth((double) 10.0f);
        org.jfree.chart.block.BlockBorder blockBorder18 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = blockBorder18.getInsets();
        blockContainer15.setMargin(rectangleInsets19);
        boolean boolean21 = jFreeChart13.equals((java.lang.Object) rectangleInsets19);
        jFreeChart13.setBackgroundImageAlignment((int) (short) 10);
        boolean boolean25 = jFreeChart13.equals((java.lang.Object) "0,0,1,1");
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(textBlock7);
        org.junit.Assert.assertNull(plot11);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(blockBorder18);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D1, (double) (-1L), 0.0f, (float) (byte) 0);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        java.awt.Font font2 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer6 = null;
        org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, paint3, (float) (-1), 0, textMeasurer6);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        multiplePiePlot8.removeChangeListener(plotChangeListener9);
        org.jfree.chart.plot.Plot plot11 = multiplePiePlot8.getParent();
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("ThreadContext", font2, (org.jfree.chart.plot.Plot) multiplePiePlot8, false);
        java.awt.Paint paint14 = jFreeChart13.getBorderPaint();
        boolean boolean15 = jFreeChart13.getAntiAlias();
        jFreeChart13.setBackgroundImageAlpha((float) 255);
        try {
            org.jfree.chart.plot.XYPlot xYPlot18 = jFreeChart13.getXYPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.MultiplePiePlot cannot be cast to org.jfree.chart.plot.XYPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(textBlock7);
        org.junit.Assert.assertNull(plot11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D3.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D3.setAutoRangeStickyZero(false);
        numberAxis3D3.setUpperBound(100.0d);
        float float10 = numberAxis3D3.getTickMarkOutsideLength();
        org.jfree.chart.block.BlockContainer blockContainer11 = new org.jfree.chart.block.BlockContainer();
        blockContainer11.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D14 = blockContainer11.getBounds();
        numberAxis3D3.setLeftArrow((java.awt.Shape) rectangle2D14);
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.plot.PiePlot piePlot17 = new org.jfree.chart.plot.PiePlot(pieDataset16);
        piePlot17.setSectionOutlinesVisible(true);
        java.awt.Paint paint20 = piePlot17.getBackgroundPaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        org.jfree.chart.plot.PiePlotState piePlotState23 = ringPlot1.initialise(graphics2D2, rectangle2D14, piePlot17, (java.lang.Integer) 3, plotRenderingInfo22);
        ringPlot1.setSectionDepth(0.0d);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator26 = null;
        ringPlot1.setLabelGenerator(pieSectionLabelGenerator26);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 1.0f + "'", float10 == 1.0f);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(piePlotState23);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = null;
        try {
            categoryPlot0.setRangeAxisLocation(axisLocation1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        java.lang.String str1 = numberAxis3D0.getLabelToolTip();
        numberAxis3D0.setUpperMargin((double) '#');
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit(1.0d);
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot0);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = legendTitle3.getPosition();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent5 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle3);
        java.lang.Object obj6 = legendTitle3.clone();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis8.setLowerMargin((double) (short) 100);
        org.jfree.chart.block.BlockBorder blockBorder13 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = blockBorder13.getInsets();
        double double16 = rectangleInsets14.trimWidth((double) (byte) 10);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D17 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D17.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D17.setAutoRangeStickyZero(false);
        numberAxis3D17.setUpperBound(100.0d);
        float float24 = numberAxis3D17.getTickMarkOutsideLength();
        org.jfree.chart.block.BlockContainer blockContainer25 = new org.jfree.chart.block.BlockContainer();
        blockContainer25.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D28 = blockContainer25.getBounds();
        numberAxis3D17.setLeftArrow((java.awt.Shape) rectangle2D28);
        org.jfree.chart.entity.ChartEntity chartEntity31 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D28, "");
        java.awt.geom.Rectangle2D rectangle2D32 = rectangleInsets14.createOutsetRectangle(rectangle2D28);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis();
        double double34 = categoryAxis33.getCategoryMargin();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor35 = null;
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = org.jfree.chart.util.RectangleEdge.TOP;
        java.lang.String str40 = rectangleEdge39.toString();
        double double41 = categoryAxis33.getCategoryJava2DCoordinate(categoryAnchor35, (int) 'a', 1, rectangle2D38, rectangleEdge39);
        double double42 = categoryAxis8.getCategoryEnd((-1), (int) '4', rectangle2D28, rectangleEdge39);
        org.jfree.chart.plot.PlotOrientation plotOrientation43 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.UnitType unitType44 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets49 = new org.jfree.chart.util.RectangleInsets(unitType44, (double) (short) 100, (double) (byte) 0, (double) 0.0f, (double) '#');
        org.jfree.chart.JFreeChart jFreeChart50 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType51 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        java.lang.String str52 = chartChangeEventType51.toString();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent53 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (short) 100, jFreeChart50, chartChangeEventType51);
        boolean boolean54 = plotOrientation43.equals((java.lang.Object) chartChangeEventType51);
        java.lang.String str55 = plotOrientation43.toString();
        try {
            java.lang.Object obj56 = legendTitle3.draw(graphics2D7, rectangle2D28, (java.lang.Object) plotOrientation43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(blockBorder13);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 10.0d + "'", double16 == 10.0d);
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 1.0f + "'", float24 == 1.0f);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.2d + "'", double34 == 0.2d);
        org.junit.Assert.assertNotNull(rectangleEdge39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "RectangleEdge.TOP" + "'", str40.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(plotOrientation43);
        org.junit.Assert.assertNotNull(unitType44);
        org.junit.Assert.assertNotNull(chartChangeEventType51);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str52.equals("ChartChangeEventType.DATASET_UPDATED"));
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "PlotOrientation.VERTICAL" + "'", str55.equals("PlotOrientation.VERTICAL"));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setSectionOutlinesVisible(true);
        java.awt.Paint paint4 = piePlot1.getBackgroundPaint();
        java.awt.Paint paint6 = piePlot1.getSectionOutlinePaint((java.lang.Comparable) 100.0f);
        piePlot1.setCircular(true, false);
        double double10 = piePlot1.getLabelGap();
        java.awt.Shape shape11 = piePlot1.getLegendItemShape();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.RingPlot ringPlot13 = new org.jfree.chart.plot.RingPlot(pieDataset12);
        java.awt.Paint paint14 = ringPlot13.getSeparatorPaint();
        piePlot1.setLabelBackgroundPaint(paint14);
        piePlot1.setSimpleLabels(false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.025d + "'", double10 == 0.025d);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setSectionOutlinesVisible(true);
        java.awt.Paint paint4 = piePlot1.getBackgroundPaint();
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.image.ColorModel colorModel7 = null;
        java.awt.Rectangle rectangle8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.awt.geom.AffineTransform affineTransform10 = null;
        java.awt.RenderingHints renderingHints11 = null;
        java.awt.PaintContext paintContext12 = color6.createContext(colorModel7, rectangle8, rectangle2D9, affineTransform10, renderingHints11);
        piePlot1.setSectionPaint((java.lang.Comparable) (byte) 100, (java.awt.Paint) color6);
        java.awt.Font font16 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint17 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer20 = null;
        org.jfree.chart.text.TextBlock textBlock21 = org.jfree.chart.text.TextUtilities.createTextBlock("", font16, paint17, (float) (-1), 0, textMeasurer20);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot22 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener23 = null;
        multiplePiePlot22.removeChangeListener(plotChangeListener23);
        org.jfree.chart.plot.Plot plot25 = multiplePiePlot22.getParent();
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart("ThreadContext", font16, (org.jfree.chart.plot.Plot) multiplePiePlot22, false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo30 = null;
        java.awt.image.BufferedImage bufferedImage31 = jFreeChart27.createBufferedImage((int) (short) 1, (int) (byte) 100, chartRenderingInfo30);
        piePlot1.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart27);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paintContext12);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(textBlock21);
        org.junit.Assert.assertNull(plot25);
        org.junit.Assert.assertNotNull(bufferedImage31);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        blockContainer0.setWidth((double) 10.0f);
        org.jfree.chart.block.BlockBorder blockBorder3 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = blockBorder3.getInsets();
        blockContainer0.setMargin(rectangleInsets4);
        java.lang.String str6 = blockContainer0.getID();
        org.jfree.chart.block.Arrangement arrangement7 = blockContainer0.getArrangement();
        org.jfree.chart.util.UnitType unitType8 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = new org.jfree.chart.util.RectangleInsets(unitType8, (double) (short) 100, (double) (byte) 0, (double) 0.0f, (double) '#');
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = new org.jfree.chart.util.RectangleInsets(unitType8, (double) (-1L), 10.0d, (double) 0.0f, 0.0d);
        blockContainer0.setPadding(rectangleInsets18);
        double double20 = rectangleInsets18.getTop();
        org.junit.Assert.assertNotNull(blockBorder3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(arrangement7);
        org.junit.Assert.assertNotNull(unitType8);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + (-1.0d) + "'", double20 == (-1.0d));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        java.lang.String str1 = licences0.getGPL();
        java.lang.String str2 = licences0.getLGPL();
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D0.setAutoRangeStickyZero(false);
        numberAxis3D0.setUpperBound(100.0d);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand7 = numberAxis3D0.getMarkerBand();
        double double8 = numberAxis3D0.getFixedAutoRange();
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D10.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D10.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer15 = null;
        org.jfree.chart.plot.PolarPlot polarPlot16 = new org.jfree.chart.plot.PolarPlot(xYDataset9, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, polarItemRenderer15);
        java.lang.String str17 = polarPlot16.getPlotType();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent18 = null;
        polarPlot16.datasetChanged(datasetChangeEvent18);
        java.awt.Stroke stroke20 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        polarPlot16.setRadiusGridlineStroke(stroke20);
        numberAxis3D0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) polarPlot16);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent23 = null;
        polarPlot16.datasetChanged(datasetChangeEvent23);
        boolean boolean25 = polarPlot16.isDomainZoomable();
        polarPlot16.clearCornerTextItems();
        org.junit.Assert.assertNull(markerAxisBand7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Polar Plot" + "'", str17.equals("Polar Plot"));
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D0.setAutoRangeStickyZero(false);
        numberAxis3D0.setUpperBound(100.0d);
        java.awt.Font font7 = numberAxis3D0.getTickLabelFont();
        org.junit.Assert.assertNotNull(font7);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        boolean boolean1 = numberAxis3D0.isAutoTickUnitSelection();
        boolean boolean2 = numberAxis3D0.isVisible();
        boolean boolean3 = numberAxis3D0.isAutoRange();
        numberAxis3D0.setTickLabelsVisible(true);
        numberAxis3D0.setVerticalTickLabels(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextLine textLine1 = null;
        textBlock0.addLine(textLine1);
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine();
        textBlock0.addLine(textLine3);
        java.awt.Paint paint7 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker(35.0d, paint7, stroke8);
        java.awt.Font font10 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        boolean boolean11 = valueMarker9.equals((java.lang.Object) font10);
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D13 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D13.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D13.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer18 = null;
        org.jfree.chart.plot.PolarPlot polarPlot19 = new org.jfree.chart.plot.PolarPlot(xYDataset12, (org.jfree.chart.axis.ValueAxis) numberAxis3D13, polarItemRenderer18);
        double double20 = polarPlot19.getMaxRadius();
        org.jfree.chart.LegendItemCollection legendItemCollection21 = polarPlot19.getLegendItems();
        java.awt.Paint paint22 = polarPlot19.getRadiusGridlinePaint();
        textBlock0.addLine("hi!", font10, paint22);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.05d + "'", double20 == 1.05d);
        org.junit.Assert.assertNotNull(legendItemCollection21);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("HorizontalAlignment.RIGHT", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        java.lang.Comparable[] comparableArray4 = new java.lang.Comparable[] { "ChartEntity: tooltip = ", 10.0f, (-1L), 1.0f };
        java.lang.Comparable[] comparableArray5 = new java.lang.Comparable[] {};
        double[] doubleArray11 = new double[] { (byte) 0, 0.2d, (-1.0d) };
        double[] doubleArray15 = new double[] { (byte) 0, 0.2d, (-1.0d) };
        double[] doubleArray19 = new double[] { (byte) 0, 0.2d, (-1.0d) };
        double[][] doubleArray20 = new double[][] { doubleArray11, doubleArray15, doubleArray19 };
        org.jfree.data.category.CategoryDataset categoryDataset21 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("rect", "RectangleAnchor.BOTTOM_LEFT", doubleArray20);
        try {
            org.jfree.data.category.CategoryDataset categoryDataset22 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray4, comparableArray5, doubleArray20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of row keys does not match the number of rows in the data array.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray4);
        org.junit.Assert.assertNotNull(comparableArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(categoryDataset21);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.lang.Object obj2 = null;
        boolean boolean3 = dateAxis1.equals(obj2);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D5.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D5.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot(xYDataset4, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, polarItemRenderer10);
        org.jfree.data.Range range12 = null;
        org.jfree.data.Range range14 = org.jfree.data.Range.expandToInclude(range12, (-1.0d));
        numberAxis3D5.setRangeWithMargins(range14);
        dateAxis1.setRange(range14, true, false);
        boolean boolean20 = dateAxis1.isHiddenValue((long) (-237));
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.axis.AxisState axisState22 = null;
        org.jfree.chart.util.UnitType unitType23 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = new org.jfree.chart.util.RectangleInsets(unitType23, (double) (short) 100, (double) (byte) 0, (double) 0.0f, (double) '#');
        double double30 = rectangleInsets28.calculateBottomOutset((double) 1L);
        java.lang.String str31 = rectangleInsets28.toString();
        org.jfree.chart.block.BlockBorder blockBorder32 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = blockBorder32.getInsets();
        double double35 = rectangleInsets33.trimWidth((double) (byte) 10);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D36 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D36.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D36.setAutoRangeStickyZero(false);
        numberAxis3D36.setUpperBound(100.0d);
        float float43 = numberAxis3D36.getTickMarkOutsideLength();
        org.jfree.chart.block.BlockContainer blockContainer44 = new org.jfree.chart.block.BlockContainer();
        blockContainer44.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D47 = blockContainer44.getBounds();
        numberAxis3D36.setLeftArrow((java.awt.Shape) rectangle2D47);
        org.jfree.chart.entity.ChartEntity chartEntity50 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D47, "");
        java.awt.geom.Rectangle2D rectangle2D51 = rectangleInsets33.createOutsetRectangle(rectangle2D47);
        java.awt.geom.Rectangle2D rectangle2D52 = rectangleInsets28.createOutsetRectangle(rectangle2D47);
        org.jfree.chart.entity.ChartEntity chartEntity53 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D47);
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = org.jfree.chart.util.RectangleEdge.LEFT;
        java.lang.Object obj55 = null;
        boolean boolean56 = rectangleEdge54.equals(obj55);
        boolean boolean57 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge54);
        try {
            java.util.List list58 = dateAxis1.refreshTicks(graphics2D21, axisState22, rectangle2D47, rectangleEdge54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(unitType23);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "RectangleInsets[t=100.0,l=0.0,b=0.0,r=35.0]" + "'", str31.equals("RectangleInsets[t=100.0,l=0.0,b=0.0,r=35.0]"));
        org.junit.Assert.assertNotNull(blockBorder32);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 10.0d + "'", double35 == 10.0d);
        org.junit.Assert.assertTrue("'" + float43 + "' != '" + 1.0f + "'", float43 == 1.0f);
        org.junit.Assert.assertNotNull(rectangle2D47);
        org.junit.Assert.assertNotNull(rectangle2D51);
        org.junit.Assert.assertNotNull(rectangle2D52);
        org.junit.Assert.assertNotNull(rectangleEdge54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        boolean boolean1 = numberAxis3D0.isAutoTickUnitSelection();
        boolean boolean2 = numberAxis3D0.isVerticalTickLabels();
        numberAxis3D0.resizeRange(0.0d);
        double double5 = numberAxis3D0.getUpperMargin();
        double double6 = numberAxis3D0.getLabelAngle();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        java.awt.Font font2 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer6 = null;
        org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, paint3, (float) (-1), 0, textMeasurer6);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        multiplePiePlot8.removeChangeListener(plotChangeListener9);
        org.jfree.chart.plot.Plot plot11 = multiplePiePlot8.getParent();
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("ThreadContext", font2, (org.jfree.chart.plot.Plot) multiplePiePlot8, false);
        jFreeChart13.setBackgroundImageAlignment(200);
        jFreeChart13.setAntiAlias(true);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(textBlock7);
        org.junit.Assert.assertNull(plot11);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.lang.String str1 = polarPlot0.getPlotType();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Polar Plot" + "'", str1.equals("Polar Plot"));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setSectionOutlinesVisible(true);
        double double4 = piePlot1.getMinimumArcAngleToDraw();
        java.lang.Object obj5 = piePlot1.clone();
        piePlot1.setIgnoreNullValues(true);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-5d + "'", double4 == 1.0E-5d);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D1.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D1.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, polarItemRenderer6);
        java.lang.String str8 = polarPlot7.getPlotType();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent9 = null;
        polarPlot7.datasetChanged(datasetChangeEvent9);
        java.awt.Stroke stroke11 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        polarPlot7.setRadiusGridlineStroke(stroke11);
        polarPlot7.setAngleLabelsVisible(false);
        polarPlot7.setRadiusGridlinesVisible(false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Polar Plot" + "'", str8.equals("Polar Plot"));
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color2 = java.awt.Color.PINK;
        org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("", font1, (java.awt.Paint) color2, (float) 1L);
        java.awt.Font font7 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint8 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer11 = null;
        org.jfree.chart.text.TextBlock textBlock12 = org.jfree.chart.text.TextUtilities.createTextBlock("", font7, paint8, (float) (-1), 0, textMeasurer11);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot13 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener14 = null;
        multiplePiePlot13.removeChangeListener(plotChangeListener14);
        org.jfree.chart.plot.Plot plot16 = multiplePiePlot13.getParent();
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("ThreadContext", font7, (org.jfree.chart.plot.Plot) multiplePiePlot13, false);
        boolean boolean19 = textFragment4.equals((java.lang.Object) "ThreadContext");
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(textBlock12);
        org.junit.Assert.assertNull(plot16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit(1.0d);
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot0);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = legendTitle3.getVerticalAlignment();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = rectangleConstraint6.toFixedWidth((double) 200);
        org.jfree.chart.util.Size2D size2D9 = legendTitle3.arrange(graphics2D5, rectangleConstraint8);
        org.jfree.chart.block.BlockBorder blockBorder10 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = blockBorder10.getInsets();
        double double13 = rectangleInsets11.trimWidth((double) (byte) 10);
        double double14 = rectangleInsets11.getBottom();
        legendTitle3.setItemLabelPadding(rectangleInsets11);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent16 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle3);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = legendTitle3.getLegendItemGraphicEdge();
        double double18 = legendTitle3.getWidth();
        org.jfree.chart.block.BlockBorder blockBorder19 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.JFreeChart jFreeChart20 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent21 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) blockBorder19, jFreeChart20);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType22 = null;
        chartChangeEvent21.setType(chartChangeEventType22);
        java.awt.Font font26 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint27 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer30 = null;
        org.jfree.chart.text.TextBlock textBlock31 = org.jfree.chart.text.TextUtilities.createTextBlock("", font26, paint27, (float) (-1), 0, textMeasurer30);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot32 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener33 = null;
        multiplePiePlot32.removeChangeListener(plotChangeListener33);
        org.jfree.chart.plot.Plot plot35 = multiplePiePlot32.getParent();
        org.jfree.chart.JFreeChart jFreeChart37 = new org.jfree.chart.JFreeChart("ThreadContext", font26, (org.jfree.chart.plot.Plot) multiplePiePlot32, false);
        org.jfree.chart.title.LegendTitle legendTitle38 = jFreeChart37.getLegend();
        java.awt.Paint paint39 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        jFreeChart37.setBorderPaint(paint39);
        org.jfree.chart.event.ChartProgressListener chartProgressListener41 = null;
        jFreeChart37.removeProgressListener(chartProgressListener41);
        java.awt.Stroke stroke43 = jFreeChart37.getBorderStroke();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo48 = null;
        java.awt.image.BufferedImage bufferedImage49 = jFreeChart37.createBufferedImage(10, (int) (byte) 1, (double) (byte) 10, (double) 100, chartRenderingInfo48);
        java.awt.Paint paint50 = jFreeChart37.getBackgroundPaint();
        chartChangeEvent21.setChart(jFreeChart37);
        legendTitle3.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart37);
        org.jfree.chart.util.RectangleInsets rectangleInsets53 = legendTitle3.getLegendItemGraphicPadding();
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(rectangleConstraint6);
        org.junit.Assert.assertNotNull(rectangleConstraint8);
        org.junit.Assert.assertNotNull(size2D9);
        org.junit.Assert.assertNotNull(blockBorder10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 10.0d + "'", double13 == 10.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(blockBorder19);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(textBlock31);
        org.junit.Assert.assertNull(plot35);
        org.junit.Assert.assertNull(legendTitle38);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(bufferedImage49);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertNotNull(rectangleInsets53);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setSectionOutlinesVisible(true);
        java.awt.Paint paint4 = piePlot1.getBackgroundPaint();
        java.awt.Paint paint6 = piePlot1.getSectionOutlinePaint((java.lang.Comparable) 100.0f);
        java.awt.Stroke stroke7 = piePlot1.getLabelLinkStroke();
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        piePlot1.setSectionOutlineStroke((java.lang.Comparable) (byte) 100, stroke9);
        piePlot1.setSectionOutlinesVisible(false);
        java.awt.Paint paint13 = piePlot1.getOutlinePaint();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator14 = null;
        piePlot1.setLegendLabelURLGenerator(pieURLGenerator14);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLowerMargin((double) (short) 100);
        categoryAxis0.setLowerMargin((double) 0);
        categoryAxis0.removeCategoryLabelToolTip((java.lang.Comparable) 350.0d);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D0.setAutoRangeStickyZero(false);
        numberAxis3D0.setLabel("ThreadContext");
        numberAxis3D0.setRange((double) 3, 10.0d);
        java.awt.Shape shape10 = numberAxis3D0.getDownArrow();
        numberAxis3D0.setLowerMargin((double) ' ');
        org.junit.Assert.assertNotNull(shape10);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        java.awt.Color color0 = java.awt.Color.BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent1 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent1);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0, waferMapRenderer1);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent3 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) waferMapPlot2);
        org.jfree.data.general.WaferMapDataset waferMapDataset4 = waferMapPlot2.getDataset();
        org.junit.Assert.assertNull(waferMapDataset4);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("hi!", "", "RectangleEdge.TOP", image3, "RectangleEdge.TOP", "", "RectangleEdge.TOP");
        projectInfo7.setVersion("TextAnchor.CENTER_RIGHT");
        java.awt.Image image13 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo17 = new org.jfree.chart.ui.ProjectInfo("hi!", "", "RectangleEdge.TOP", image13, "RectangleEdge.TOP", "", "RectangleEdge.TOP");
        projectInfo17.setVersion("TextAnchor.CENTER_RIGHT");
        projectInfo7.addLibrary((org.jfree.chart.ui.Library) projectInfo17);
        boolean boolean22 = projectInfo7.equals((java.lang.Object) 0.025d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D4.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D4.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, polarItemRenderer9);
        double double11 = polarPlot10.getMaxRadius();
        org.jfree.chart.block.BlockContainer blockContainer14 = new org.jfree.chart.block.BlockContainer();
        blockContainer14.setWidth((double) 10.0f);
        org.jfree.chart.block.BlockBorder blockBorder17 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = blockBorder17.getInsets();
        blockContainer14.setMargin(rectangleInsets18);
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint23 = rectangleConstraint21.toFixedWidth((double) 200);
        org.jfree.chart.util.Size2D size2D24 = blockContainer14.arrange(graphics2D20, rectangleConstraint23);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot25 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot25.setLimit(1.0d);
        org.jfree.chart.title.LegendTitle legendTitle28 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot25);
        org.jfree.chart.util.VerticalAlignment verticalAlignment29 = legendTitle28.getVerticalAlignment();
        java.awt.Graphics2D graphics2D30 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint31 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint33 = rectangleConstraint31.toFixedWidth((double) 200);
        org.jfree.chart.util.Size2D size2D34 = legendTitle28.arrange(graphics2D30, rectangleConstraint33);
        size2D34.height = 100.0f;
        org.jfree.chart.util.Size2D size2D37 = rectangleConstraint23.calculateConstrainedSize(size2D34);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor40 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.lang.String str41 = rectangleAnchor40.toString();
        java.awt.geom.Rectangle2D rectangle2D42 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D34, 0.0d, 0.4d, rectangleAnchor40);
        java.awt.Point point43 = polarPlot10.translateValueThetaRadiusToJava2D((double) 1.0f, (double) (short) 10, rectangle2D42);
        polarPlot0.zoomDomainAxes((double) 15, plotRenderingInfo2, (java.awt.geom.Point2D) point43);
        boolean boolean45 = polarPlot0.isAngleGridlinesVisible();
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.05d + "'", double11 == 1.05d);
        org.junit.Assert.assertNotNull(blockBorder17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(rectangleConstraint21);
        org.junit.Assert.assertNotNull(rectangleConstraint23);
        org.junit.Assert.assertNotNull(size2D24);
        org.junit.Assert.assertNotNull(verticalAlignment29);
        org.junit.Assert.assertNotNull(rectangleConstraint31);
        org.junit.Assert.assertNotNull(rectangleConstraint33);
        org.junit.Assert.assertNotNull(size2D34);
        org.junit.Assert.assertNotNull(size2D37);
        org.junit.Assert.assertNotNull(rectangleAnchor40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "RectangleAnchor.LEFT" + "'", str41.equals("RectangleAnchor.LEFT"));
        org.junit.Assert.assertNotNull(rectangle2D42);
        org.junit.Assert.assertNotNull(point43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getCategoryMargin();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor2 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = org.jfree.chart.util.RectangleEdge.TOP;
        java.lang.String str7 = rectangleEdge6.toString();
        double double8 = categoryAxis0.getCategoryJava2DCoordinate(categoryAnchor2, (int) 'a', 1, rectangle2D5, rectangleEdge6);
        categoryAxis0.setCategoryMargin((double) ' ');
        categoryAxis0.removeCategoryLabelToolTip((java.lang.Comparable) (byte) 0);
        java.lang.String str14 = categoryAxis0.getCategoryLabelToolTip((java.lang.Comparable) (-1.0d));
        java.lang.Object obj15 = categoryAxis0.clone();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "RectangleEdge.TOP" + "'", str7.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getDomainAxisEdge((int) (byte) 1);
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        try {
            categoryPlot0.addDomainMarker((int) (short) 1, categoryMarker4, layer5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge2);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("ChartEntity: tooltip = ", "TextAnchor.BOTTOM_CENTER", "RectangleEdge.TOP", "");
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D1.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D1.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, polarItemRenderer6);
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = polarPlot7.getOrientation();
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        polarPlot7.drawBackgroundImage(graphics2D9, rectangle2D10);
        polarPlot7.setAngleLabelsVisible(false);
        org.junit.Assert.assertNotNull(plotOrientation8);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(1.0d);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        blockContainer0.setWidth((double) 10.0f);
        org.jfree.chart.block.BlockBorder blockBorder3 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = blockBorder3.getInsets();
        blockContainer0.setMargin(rectangleInsets4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = rectangleConstraint7.toFixedWidth((double) 200);
        org.jfree.chart.util.Size2D size2D10 = blockContainer0.arrange(graphics2D6, rectangleConstraint9);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot11.setLimit(1.0d);
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot11);
        org.jfree.chart.util.VerticalAlignment verticalAlignment15 = legendTitle14.getVerticalAlignment();
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint17 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint19 = rectangleConstraint17.toFixedWidth((double) 200);
        org.jfree.chart.util.Size2D size2D20 = legendTitle14.arrange(graphics2D16, rectangleConstraint19);
        size2D20.height = 100.0f;
        org.jfree.chart.util.Size2D size2D23 = rectangleConstraint9.calculateConstrainedSize(size2D20);
        java.lang.String str24 = size2D20.toString();
        org.junit.Assert.assertNotNull(blockBorder3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(rectangleConstraint7);
        org.junit.Assert.assertNotNull(rectangleConstraint9);
        org.junit.Assert.assertNotNull(size2D10);
        org.junit.Assert.assertNotNull(verticalAlignment15);
        org.junit.Assert.assertNotNull(rectangleConstraint17);
        org.junit.Assert.assertNotNull(rectangleConstraint19);
        org.junit.Assert.assertNotNull(size2D20);
        org.junit.Assert.assertNotNull(size2D23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Size2D[width=0.0, height=100.0]" + "'", str24.equals("Size2D[width=0.0, height=100.0]"));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D1.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D1.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, polarItemRenderer6);
        double double8 = polarPlot7.getMaxRadius();
        org.jfree.chart.LegendItemCollection legendItemCollection9 = polarPlot7.getLegendItems();
        java.awt.Paint paint10 = polarPlot7.getRadiusGridlinePaint();
        polarPlot7.setBackgroundImageAlignment(0);
        java.awt.Font font14 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint15 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer18 = null;
        org.jfree.chart.text.TextBlock textBlock19 = org.jfree.chart.text.TextUtilities.createTextBlock("", font14, paint15, (float) (-1), 0, textMeasurer18);
        boolean boolean20 = polarPlot7.equals((java.lang.Object) "");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D21 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D21.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D21.setAutoRangeStickyZero(false);
        numberAxis3D21.setUpperBound(100.0d);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand28 = numberAxis3D21.getMarkerBand();
        java.awt.Shape shape29 = numberAxis3D21.getLeftArrow();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit30 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis3D21.setTickUnit(numberTickUnit30, false, true);
        polarPlot7.setAngleTickUnit((org.jfree.chart.axis.TickUnit) numberTickUnit30);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.05d + "'", double8 == 1.05d);
        org.junit.Assert.assertNotNull(legendItemCollection9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(textBlock19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(markerAxisBand28);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(numberTickUnit30);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        boolean boolean1 = numberAxis3D0.isAutoTickUnitSelection();
        boolean boolean2 = numberAxis3D0.isVisible();
        org.jfree.data.Range range3 = numberAxis3D0.getRange();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(range3);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D0.setAutoRangeStickyZero(false);
        numberAxis3D0.setLabel("ThreadContext");
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = numberAxis3D0.getLabelInsets();
        double double9 = rectangleInsets7.calculateBottomOutset(0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 3.0d + "'", double9 == 3.0d);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.Size2D size2D2 = blockContainer0.arrange(graphics2D1);
        java.lang.String str3 = size2D2.toString();
        org.junit.Assert.assertNotNull(size2D2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Size2D[width=0.0, height=0.0]" + "'", str3.equals("Size2D[width=0.0, height=0.0]"));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        java.awt.Color color0 = java.awt.Color.magenta;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) (-1.0f), (double) 0L, (double) (-1), (double) (-1.0f));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) (byte) 1, (int) 'a', (int) (short) 1);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D0.setAutoRangeStickyZero(false);
        numberAxis3D0.setUpperBound(100.0d);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand7 = null;
        numberAxis3D0.setMarkerBand(markerAxisBand7);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        java.awt.Color color3 = java.awt.Color.getColor("", 0);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_YELLOW;
        int int5 = color4.getBlue();
        java.awt.color.ColorSpace colorSpace6 = color4.getColorSpace();
        float[] floatArray7 = null;
        float[] floatArray8 = color3.getComponents(colorSpace6, floatArray7);
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_YELLOW;
        int int10 = color9.getBlue();
        java.awt.image.ColorModel colorModel11 = null;
        java.awt.Rectangle rectangle12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.AffineTransform affineTransform14 = null;
        java.awt.RenderingHints renderingHints15 = null;
        java.awt.PaintContext paintContext16 = color9.createContext(colorModel11, rectangle12, rectangle2D13, affineTransform14, renderingHints15);
        java.awt.Color color19 = java.awt.Color.getColor("", 0);
        java.awt.Color color20 = org.jfree.chart.ChartColor.DARK_YELLOW;
        int int21 = color20.getBlue();
        java.awt.color.ColorSpace colorSpace22 = color20.getColorSpace();
        float[] floatArray23 = null;
        float[] floatArray24 = color19.getComponents(colorSpace22, floatArray23);
        float[] floatArray30 = new float[] { '4', '4', 1.0f, '4', 10.0f };
        float[] floatArray31 = color9.getComponents(colorSpace22, floatArray30);
        java.awt.Color color34 = java.awt.Color.getColor("", 0);
        java.awt.Color color35 = org.jfree.chart.ChartColor.DARK_YELLOW;
        int int36 = color35.getBlue();
        java.awt.color.ColorSpace colorSpace37 = color35.getColorSpace();
        float[] floatArray38 = null;
        float[] floatArray39 = color34.getComponents(colorSpace37, floatArray38);
        float[] floatArray40 = color3.getComponents(colorSpace22, floatArray38);
        boolean boolean41 = horizontalAlignment0.equals((java.lang.Object) floatArray40);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(colorSpace6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(paintContext16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(colorSpace22);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(colorSpace37);
        org.junit.Assert.assertNotNull(floatArray39);
        org.junit.Assert.assertNotNull(floatArray40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D3.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D3.setAutoRangeStickyZero(false);
        numberAxis3D3.setUpperBound(100.0d);
        float float10 = numberAxis3D3.getTickMarkOutsideLength();
        org.jfree.chart.block.BlockContainer blockContainer11 = new org.jfree.chart.block.BlockContainer();
        blockContainer11.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D14 = blockContainer11.getBounds();
        numberAxis3D3.setLeftArrow((java.awt.Shape) rectangle2D14);
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.plot.PiePlot piePlot17 = new org.jfree.chart.plot.PiePlot(pieDataset16);
        piePlot17.setSectionOutlinesVisible(true);
        java.awt.Paint paint20 = piePlot17.getBackgroundPaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        org.jfree.chart.plot.PiePlotState piePlotState23 = ringPlot1.initialise(graphics2D2, rectangle2D14, piePlot17, (java.lang.Integer) 3, plotRenderingInfo22);
        ringPlot1.setSectionDepth(0.0d);
        ringPlot1.setLabelLinksVisible(false);
        boolean boolean28 = ringPlot1.getSeparatorsVisible();
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 1.0f + "'", float10 == 1.0f);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(piePlotState23);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = org.jfree.chart.util.VerticalAlignment.CENTER;
        java.awt.Paint paint3 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        boolean boolean4 = verticalAlignment2.equals((java.lang.Object) paint3);
        org.jfree.chart.block.ColumnArrangement columnArrangement7 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment1, verticalAlignment2, (double) (byte) 1, (double) (byte) -1);
        boolean boolean8 = chartChangeEventType0.equals((java.lang.Object) verticalAlignment2);
        java.awt.Font font10 = null;
        java.awt.Font font12 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint13 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer16 = null;
        org.jfree.chart.text.TextBlock textBlock17 = org.jfree.chart.text.TextUtilities.createTextBlock("", font12, paint13, (float) (-1), 0, textMeasurer16);
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer21 = new org.jfree.chart.text.G2TextMeasurer(graphics2D20);
        org.jfree.chart.text.TextBlock textBlock22 = org.jfree.chart.text.TextUtilities.createTextBlock("", font10, paint13, (float) (short) 100, (int) '4', (org.jfree.chart.text.TextMeasurer) g2TextMeasurer21);
        boolean boolean23 = chartChangeEventType0.equals((java.lang.Object) textBlock22);
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(textBlock17);
        org.junit.Assert.assertNotNull(textBlock22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D1.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D1.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, polarItemRenderer6);
        double double8 = polarPlot7.getMaxRadius();
        org.jfree.chart.LegendItemCollection legendItemCollection9 = polarPlot7.getLegendItems();
        try {
            org.jfree.chart.LegendItem legendItem11 = legendItemCollection9.get((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.05d + "'", double8 == 1.05d);
        org.junit.Assert.assertNotNull(legendItemCollection9);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("ChartEntity: tooltip = ", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setSectionOutlinesVisible(true);
        java.awt.Paint paint4 = piePlot1.getBackgroundPaint();
        piePlot1.setOutlineVisible(false);
        boolean boolean7 = piePlot1.getSimpleLabels();
        java.awt.Font font8 = piePlot1.getLabelFont();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(font8);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setSectionOutlinesVisible(true);
        java.awt.Paint paint4 = piePlot1.getBackgroundPaint();
        java.awt.Paint paint6 = piePlot1.getSectionOutlinePaint((java.lang.Comparable) 100.0f);
        java.awt.Stroke stroke7 = piePlot1.getLabelOutlineStroke();
        java.awt.Paint paint8 = piePlot1.getShadowPaint();
        piePlot1.setShadowYOffset((double) 1.0f);
        double double11 = piePlot1.getLabelLinkMargin();
        double double12 = piePlot1.getLabelLinkMargin();
        java.awt.Paint paint13 = piePlot1.getLabelLinkPaint();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.025d + "'", double11 == 0.025d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.025d + "'", double12 == 0.025d);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        java.awt.Paint paint1 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker(35.0d, paint1, stroke2);
        float float4 = valueMarker3.getAlpha();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType5 = valueMarker3.getLabelOffsetType();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType6 = valueMarker3.getLabelOffsetType();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = valueMarker3.getLabelOffset();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = valueMarker3.getLabelAnchor();
        java.lang.Object obj9 = valueMarker3.clone();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(lengthAdjustmentType5);
        org.junit.Assert.assertNotNull(lengthAdjustmentType6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("hi!", "", "RectangleEdge.TOP", image3, "RectangleEdge.TOP", "", "RectangleEdge.TOP");
        projectInfo7.setVersion("TextAnchor.CENTER_RIGHT");
        java.lang.String str10 = projectInfo7.getInfo();
        java.lang.String str11 = projectInfo7.getCopyright();
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "RectangleEdge.TOP" + "'", str10.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "RectangleEdge.TOP" + "'", str11.equals("RectangleEdge.TOP"));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D0.setAutoRangeStickyZero(false);
        numberAxis3D0.setUpperBound(100.0d);
        float float7 = numberAxis3D0.getTickMarkOutsideLength();
        org.jfree.chart.block.BlockContainer blockContainer8 = new org.jfree.chart.block.BlockContainer();
        blockContainer8.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D11 = blockContainer8.getBounds();
        numberAxis3D0.setLeftArrow((java.awt.Shape) rectangle2D11);
        org.jfree.chart.entity.ChartEntity chartEntity14 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D11, "");
        java.lang.Object obj15 = chartEntity14.clone();
        java.lang.String str16 = chartEntity14.toString();
        java.lang.String str17 = chartEntity14.getURLText();
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "ChartEntity: tooltip = " + "'", str16.equals("ChartEntity: tooltip = "));
        org.junit.Assert.assertNull(str17);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot1.getPieChart();
        int int3 = jFreeChart2.getSubtitleCount();
        java.awt.Stroke stroke4 = jFreeChart2.getBorderStroke();
        org.junit.Assert.assertNotNull(jFreeChart2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = org.jfree.chart.util.VerticalAlignment.CENTER;
        java.awt.Paint paint3 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        boolean boolean4 = verticalAlignment2.equals((java.lang.Object) paint3);
        org.jfree.chart.block.ColumnArrangement columnArrangement7 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment1, verticalAlignment2, (double) (byte) 1, (double) (byte) -1);
        boolean boolean8 = piePlot3D0.equals((java.lang.Object) (byte) 1);
        java.awt.Paint paint9 = piePlot3D0.getLabelOutlinePaint();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor10 = piePlot3D0.getLabelDistributor();
        piePlot3D0.setShadowXOffset(0.05d);
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor10);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.chart.block.BlockResult blockResult0 = new org.jfree.chart.block.BlockResult();
        org.jfree.chart.entity.EntityCollection entityCollection1 = null;
        blockResult0.setEntityCollection(entityCollection1);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setSectionOutlinesVisible(true);
        java.awt.Paint paint4 = piePlot1.getBackgroundPaint();
        java.awt.Paint paint6 = piePlot1.getSectionOutlinePaint((java.lang.Comparable) 100.0f);
        java.awt.Font font9 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint10 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer13 = null;
        org.jfree.chart.text.TextBlock textBlock14 = org.jfree.chart.text.TextUtilities.createTextBlock("", font9, paint10, (float) (-1), 0, textMeasurer13);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot15 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        multiplePiePlot15.removeChangeListener(plotChangeListener16);
        org.jfree.chart.plot.Plot plot18 = multiplePiePlot15.getParent();
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("ThreadContext", font9, (org.jfree.chart.plot.Plot) multiplePiePlot15, false);
        jFreeChart20.setBackgroundImageAlignment(200);
        float float23 = jFreeChart20.getBackgroundImageAlpha();
        piePlot1.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart20);
        jFreeChart20.setTitle("VerticalAlignment.CENTER");
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(textBlock14);
        org.junit.Assert.assertNull(plot18);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 0.5f + "'", float23 == 0.5f);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        blockContainer0.setWidth((double) 10.0f);
        org.jfree.chart.block.BlockBorder blockBorder3 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = blockBorder3.getInsets();
        blockContainer0.setMargin(rectangleInsets4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = rectangleConstraint7.toFixedWidth((double) 200);
        org.jfree.chart.util.Size2D size2D10 = blockContainer0.arrange(graphics2D6, rectangleConstraint9);
        size2D10.height = 0.0d;
        org.junit.Assert.assertNotNull(blockBorder3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(rectangleConstraint7);
        org.junit.Assert.assertNotNull(rectangleConstraint9);
        org.junit.Assert.assertNotNull(size2D10);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.util.UnitType unitType2 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = new org.jfree.chart.util.RectangleInsets(unitType2, (double) (short) 100, (double) (byte) 0, (double) 0.0f, (double) '#');
        double double9 = rectangleInsets7.calculateBottomOutset((double) 1L);
        java.lang.String str10 = rectangleInsets7.toString();
        org.jfree.chart.block.BlockBorder blockBorder11 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = blockBorder11.getInsets();
        double double14 = rectangleInsets12.trimWidth((double) (byte) 10);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D15 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D15.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D15.setAutoRangeStickyZero(false);
        numberAxis3D15.setUpperBound(100.0d);
        float float22 = numberAxis3D15.getTickMarkOutsideLength();
        org.jfree.chart.block.BlockContainer blockContainer23 = new org.jfree.chart.block.BlockContainer();
        blockContainer23.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D26 = blockContainer23.getBounds();
        numberAxis3D15.setLeftArrow((java.awt.Shape) rectangle2D26);
        org.jfree.chart.entity.ChartEntity chartEntity29 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D26, "");
        java.awt.geom.Rectangle2D rectangle2D30 = rectangleInsets12.createOutsetRectangle(rectangle2D26);
        java.awt.geom.Rectangle2D rectangle2D31 = rectangleInsets7.createOutsetRectangle(rectangle2D26);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot32 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot32.setLimit(1.0d);
        org.jfree.chart.title.LegendTitle legendTitle35 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot32);
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = legendTitle35.getPosition();
        double double37 = numberAxis0.lengthToJava2D(10.0d, rectangle2D31, rectangleEdge36);
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = new org.jfree.chart.util.RectangleInsets();
        numberAxis0.setTickLabelInsets(rectangleInsets38);
        org.junit.Assert.assertNotNull(unitType2);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "RectangleInsets[t=100.0,l=0.0,b=0.0,r=35.0]" + "'", str10.equals("RectangleInsets[t=100.0,l=0.0,b=0.0,r=35.0]"));
        org.junit.Assert.assertNotNull(blockBorder11);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 10.0d + "'", double14 == 10.0d);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 1.0f + "'", float22 == 1.0f);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 350.0d + "'", double37 == 350.0d);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("hi!", graphics2D1, (float) 200, 0.5f, (double) (-1), 0.0f, (float) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D0.setAutoRangeStickyZero(false);
        numberAxis3D0.setUpperBound(100.0d);
        float float7 = numberAxis3D0.getTickMarkOutsideLength();
        boolean boolean8 = numberAxis3D0.isInverted();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D9 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D9.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D9.setAutoRangeStickyZero(false);
        numberAxis3D9.setUpperBound(100.0d);
        float float16 = numberAxis3D9.getTickMarkOutsideLength();
        org.jfree.chart.block.BlockContainer blockContainer17 = new org.jfree.chart.block.BlockContainer();
        blockContainer17.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D20 = blockContainer17.getBounds();
        numberAxis3D9.setLeftArrow((java.awt.Shape) rectangle2D20);
        org.jfree.chart.entity.ChartEntity chartEntity23 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D20, "");
        numberAxis3D0.setDownArrow((java.awt.Shape) rectangle2D20);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 1.0f + "'", float16 == 1.0f);
        org.junit.Assert.assertNotNull(rectangle2D20);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setSectionOutlinesVisible(true);
        java.awt.Paint paint4 = piePlot1.getBackgroundPaint();
        java.awt.Paint paint6 = piePlot1.getSectionOutlinePaint((java.lang.Comparable) 100.0f);
        java.awt.Stroke stroke7 = piePlot1.getLabelLinkStroke();
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        piePlot1.setSectionOutlineStroke((java.lang.Comparable) (byte) 100, stroke9);
        piePlot1.setSectionOutlinesVisible(false);
        java.awt.Color color16 = java.awt.Color.getHSBColor((float) 3, (float) (short) 100, (float) (short) 10);
        piePlot1.setBaseSectionPaint((java.awt.Paint) color16);
        org.jfree.data.general.PieDataset pieDataset19 = null;
        org.jfree.chart.plot.RingPlot ringPlot20 = new org.jfree.chart.plot.RingPlot(pieDataset19);
        java.awt.Paint paint21 = ringPlot20.getSeparatorPaint();
        piePlot1.setSectionPaint((java.lang.Comparable) 10.0f, paint21);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("RectangleAnchor.BOTTOM_LEFT");
        numberAxis3D1.setFixedAutoRange(0.4d);
        boolean boolean4 = numberAxis3D1.isVisible();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        java.awt.Font font2 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer6 = null;
        org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, paint3, (float) (-1), 0, textMeasurer6);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        multiplePiePlot8.removeChangeListener(plotChangeListener9);
        org.jfree.chart.plot.Plot plot11 = multiplePiePlot8.getParent();
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("ThreadContext", font2, (org.jfree.chart.plot.Plot) multiplePiePlot8, false);
        org.jfree.chart.title.LegendTitle legendTitle14 = jFreeChart13.getLegend();
        java.awt.Paint paint15 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        jFreeChart13.setBorderPaint(paint15);
        java.util.List list17 = jFreeChart13.getSubtitles();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = null;
        java.awt.image.BufferedImage bufferedImage21 = jFreeChart13.createBufferedImage(192, (int) '#', chartRenderingInfo20);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(textBlock7);
        org.junit.Assert.assertNull(plot11);
        org.junit.Assert.assertNull(legendTitle14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(list17);
        org.junit.Assert.assertNotNull(bufferedImage21);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getDomainAxisEdge((int) (byte) 1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryPlot0.getAxisOffset();
        categoryPlot0.setRangeGridlinesVisible(true);
        java.awt.Stroke stroke6 = null;
        try {
            categoryPlot0.setDomainGridlineStroke(stroke6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        double[] doubleArray7 = new double[] { (byte) 0, 0.2d, (-1.0d) };
        double[] doubleArray11 = new double[] { (byte) 0, 0.2d, (-1.0d) };
        double[] doubleArray15 = new double[] { (byte) 0, 0.2d, (-1.0d) };
        double[][] doubleArray16 = new double[][] { doubleArray7, doubleArray11, doubleArray15 };
        org.jfree.data.category.CategoryDataset categoryDataset17 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("rect", "RectangleAnchor.BOTTOM_LEFT", doubleArray16);
        org.jfree.data.category.CategoryDataset categoryDataset18 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Polar Plot", "", doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(categoryDataset17);
        org.junit.Assert.assertNotNull(categoryDataset18);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setSectionOutlinesVisible(true);
        java.awt.Paint paint4 = piePlot1.getBackgroundPaint();
        java.awt.Paint paint6 = piePlot1.getSectionOutlinePaint((java.lang.Comparable) 100.0f);
        piePlot1.setCircular(true, false);
        piePlot1.setBackgroundImageAlignment(0);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(paint6);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D1.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D1.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, polarItemRenderer6);
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = polarPlot7.getOrientation();
        java.lang.String str9 = plotOrientation8.toString();
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str9.equals("PlotOrientation.HORIZONTAL"));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        java.awt.Font font2 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer6 = null;
        org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, paint3, (float) (-1), 0, textMeasurer6);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        multiplePiePlot8.removeChangeListener(plotChangeListener9);
        org.jfree.chart.plot.Plot plot11 = multiplePiePlot8.getParent();
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("ThreadContext", font2, (org.jfree.chart.plot.Plot) multiplePiePlot8, false);
        org.jfree.chart.title.LegendTitle legendTitle14 = jFreeChart13.getLegend();
        java.awt.Paint paint15 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        jFreeChart13.setBorderPaint(paint15);
        org.jfree.chart.event.ChartProgressListener chartProgressListener17 = null;
        jFreeChart13.removeProgressListener(chartProgressListener17);
        java.awt.Stroke stroke19 = jFreeChart13.getBorderStroke();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo24 = null;
        java.awt.image.BufferedImage bufferedImage25 = jFreeChart13.createBufferedImage(10, (int) (byte) 1, (double) (byte) 10, (double) 100, chartRenderingInfo24);
        java.awt.Paint paint26 = jFreeChart13.getBackgroundPaint();
        org.jfree.chart.event.ChartProgressListener chartProgressListener27 = null;
        jFreeChart13.removeProgressListener(chartProgressListener27);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(textBlock7);
        org.junit.Assert.assertNull(plot11);
        org.junit.Assert.assertNull(legendTitle14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(bufferedImage25);
        org.junit.Assert.assertNotNull(paint26);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_INCLUDES_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setSectionOutlinesVisible(true);
        java.awt.Paint paint4 = piePlot1.getBackgroundPaint();
        java.awt.Paint paint6 = piePlot1.getSectionOutlinePaint((java.lang.Comparable) 100.0f);
        piePlot1.setCircular(true, false);
        double double10 = piePlot1.getLabelGap();
        java.awt.Shape shape11 = piePlot1.getLegendItemShape();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.RingPlot ringPlot13 = new org.jfree.chart.plot.RingPlot(pieDataset12);
        java.awt.Paint paint14 = ringPlot13.getSeparatorPaint();
        piePlot1.setLabelBackgroundPaint(paint14);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier16 = piePlot1.getDrawingSupplier();
        piePlot1.setStartAngle((double) 100L);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.025d + "'", double10 == 0.025d);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(drawingSupplier16);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot1.setLimit(1.0d);
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot1);
        java.awt.geom.Rectangle2D rectangle2D5 = legendTitle4.getBounds();
        rectangleInsets0.trim(rectangle2D5);
        double double8 = rectangleInsets0.calculateLeftInset(3.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("ThreadContext");
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.RendererState rendererState1 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo0);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setSectionOutlinesVisible(true);
        java.awt.Paint paint4 = piePlot1.getBackgroundPaint();
        java.awt.Paint paint6 = piePlot1.getSectionOutlinePaint((java.lang.Comparable) 100.0f);
        java.awt.Stroke stroke7 = piePlot1.getLabelLinkStroke();
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        piePlot1.setSectionOutlineStroke((java.lang.Comparable) (byte) 100, stroke9);
        piePlot1.setSectionOutlinesVisible(false);
        org.jfree.chart.plot.Plot plot13 = piePlot1.getRootPlot();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(plot13);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.plot.Plot plot3 = multiplePiePlot0.getParent();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        multiplePiePlot0.notifyListeners(plotChangeEvent4);
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        multiplePiePlot0.removeChangeListener(plotChangeListener6);
        java.awt.Font font8 = multiplePiePlot0.getNoDataMessageFont();
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(font8);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockBorder0.getInsets();
        double double3 = rectangleInsets1.calculateTopOutset((double) (byte) -1);
        org.junit.Assert.assertNotNull(blockBorder0);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D0.setAutoRangeStickyZero(false);
        numberAxis3D0.setLabel("ThreadContext");
        numberAxis3D0.setRange((double) 3, 10.0d);
        java.awt.Shape shape10 = numberAxis3D0.getDownArrow();
        java.awt.Font font12 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint13 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer16 = null;
        org.jfree.chart.text.TextBlock textBlock17 = org.jfree.chart.text.TextUtilities.createTextBlock("", font12, paint13, (float) (-1), 0, textMeasurer16);
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor21 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        java.awt.Shape shape25 = textBlock17.calculateBounds(graphics2D18, 0.0f, (float) 255, textBlockAnchor21, (float) (short) 0, (float) (byte) -1, (double) (short) 1);
        numberAxis3D0.setRightArrow(shape25);
        numberAxis3D0.setLowerMargin((double) '#');
        org.jfree.chart.axis.TickUnitSource tickUnitSource29 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        numberAxis3D0.setStandardTickUnits(tickUnitSource29);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(textBlock17);
        org.junit.Assert.assertNotNull(textBlockAnchor21);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(tickUnitSource29);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.Plot plot1 = multiplePiePlot0.getParent();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        multiplePiePlot0.markerChanged(markerChangeEvent2);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.Plot plot5 = multiplePiePlot4.getParent();
        multiplePiePlot0.setParent((org.jfree.chart.plot.Plot) multiplePiePlot4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        multiplePiePlot0.axisChanged(axisChangeEvent7);
        org.junit.Assert.assertNull(plot1);
        org.junit.Assert.assertNull(plot5);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit(1.0d);
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot0);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = legendTitle3.getVerticalAlignment();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = rectangleConstraint6.toFixedWidth((double) 200);
        org.jfree.chart.util.Size2D size2D9 = legendTitle3.arrange(graphics2D5, rectangleConstraint8);
        org.jfree.chart.block.BlockBorder blockBorder10 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = blockBorder10.getInsets();
        double double13 = rectangleInsets11.trimWidth((double) (byte) 10);
        double double14 = rectangleInsets11.getBottom();
        legendTitle3.setItemLabelPadding(rectangleInsets11);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent16 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle3);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = legendTitle3.getLegendItemGraphicEdge();
        java.awt.Paint paint18 = legendTitle3.getBackgroundPaint();
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(rectangleConstraint6);
        org.junit.Assert.assertNotNull(rectangleConstraint8);
        org.junit.Assert.assertNotNull(size2D9);
        org.junit.Assert.assertNotNull(blockBorder10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 10.0d + "'", double13 == 10.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNull(paint18);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D1.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D1.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, polarItemRenderer6);
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = polarPlot7.getOrientation();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = polarPlot7.getRenderer();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D10.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D10.resizeRange((double) 1, (double) 1);
        numberAxis3D10.setVisible(true);
        org.jfree.data.Range range18 = polarPlot7.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D10);
        org.jfree.chart.LegendItemCollection legendItemCollection19 = polarPlot7.getLegendItems();
        polarPlot7.zoom(45.0d);
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertNull(polarItemRenderer9);
        org.junit.Assert.assertNull(range18);
        org.junit.Assert.assertNotNull(legendItemCollection19);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setBackgroundAlpha((float) (-1));
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint7 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer10 = null;
        org.jfree.chart.text.TextBlock textBlock11 = org.jfree.chart.text.TextUtilities.createTextBlock("", font6, paint7, (float) (-1), 0, textMeasurer10);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot12 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener13 = null;
        multiplePiePlot12.removeChangeListener(plotChangeListener13);
        org.jfree.chart.plot.Plot plot15 = multiplePiePlot12.getParent();
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("ThreadContext", font6, (org.jfree.chart.plot.Plot) multiplePiePlot12, false);
        java.util.List list18 = jFreeChart17.getSubtitles();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo21 = null;
        java.awt.image.BufferedImage bufferedImage22 = jFreeChart17.createBufferedImage((int) '4', (int) '4', chartRenderingInfo21);
        piePlot1.setBackgroundImage((java.awt.Image) bufferedImage22);
        org.jfree.chart.util.Rotation rotation24 = org.jfree.chart.util.Rotation.CLOCKWISE;
        piePlot1.setDirection(rotation24);
        piePlot1.setSectionOutlinesVisible(true);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textBlock11);
        org.junit.Assert.assertNull(plot15);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertNotNull(bufferedImage22);
        org.junit.Assert.assertNotNull(rotation24);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        blockParams0.setTranslateY((double) 0.0f);
        boolean boolean3 = blockParams0.getGenerateEntities();
        double double4 = blockParams0.getTranslateX();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setSectionOutlinesVisible(true);
        java.awt.Paint paint4 = piePlot1.getBackgroundPaint();
        java.awt.Paint paint6 = piePlot1.getSectionOutlinePaint((java.lang.Comparable) 100.0f);
        java.awt.Stroke stroke7 = piePlot1.getLabelLinkStroke();
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        piePlot1.setSectionOutlineStroke((java.lang.Comparable) (byte) 100, stroke9);
        piePlot1.setSectionOutlinesVisible(false);
        java.awt.Paint paint13 = piePlot1.getOutlinePaint();
        boolean boolean14 = piePlot1.getIgnoreNullValues();
        java.awt.Paint paint15 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        piePlot1.setBaseSectionOutlinePaint(paint15);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D0.clearCategoryLabelToolTips();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D4.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D4.setAutoRangeStickyZero(false);
        numberAxis3D4.setUpperBound(100.0d);
        float float11 = numberAxis3D4.getTickMarkOutsideLength();
        org.jfree.chart.block.BlockContainer blockContainer12 = new org.jfree.chart.block.BlockContainer();
        blockContainer12.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D15 = blockContainer12.getBounds();
        numberAxis3D4.setLeftArrow((java.awt.Shape) rectangle2D15);
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis17.setLowerMargin((double) (short) 100);
        categoryAxis17.setLowerMargin((double) 0);
        java.awt.Font font23 = categoryAxis17.getTickLabelFont((java.lang.Comparable) (byte) 100);
        double double24 = categoryAxis17.getLowerMargin();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor25 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D28 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.RangeType rangeType29 = numberAxis3D28.getRangeType();
        org.jfree.data.general.PieDataset pieDataset30 = null;
        org.jfree.chart.plot.PiePlot piePlot31 = new org.jfree.chart.plot.PiePlot(pieDataset30);
        piePlot31.setSectionOutlinesVisible(true);
        java.awt.Paint paint34 = piePlot31.getBackgroundPaint();
        java.awt.Color color36 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.image.ColorModel colorModel37 = null;
        java.awt.Rectangle rectangle38 = null;
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        java.awt.geom.AffineTransform affineTransform40 = null;
        java.awt.RenderingHints renderingHints41 = null;
        java.awt.PaintContext paintContext42 = color36.createContext(colorModel37, rectangle38, rectangle2D39, affineTransform40, renderingHints41);
        piePlot31.setSectionPaint((java.lang.Comparable) (byte) 100, (java.awt.Paint) color36);
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor45 = null;
        org.jfree.chart.block.BlockContainer blockContainer48 = new org.jfree.chart.block.BlockContainer();
        blockContainer48.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D51 = blockContainer48.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge52 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double53 = categoryAxis44.getCategoryJava2DCoordinate(categoryAnchor45, (int) (byte) 10, 0, rectangle2D51, rectangleEdge52);
        piePlot31.setLegendItemShape((java.awt.Shape) rectangle2D51);
        numberAxis3D28.setRightArrow((java.awt.Shape) rectangle2D51);
        org.jfree.chart.util.RectangleEdge rectangleEdge56 = org.jfree.chart.util.RectangleEdge.TOP;
        double double57 = categoryAxis17.getCategoryJava2DCoordinate(categoryAnchor25, 2, (int) (short) 100, rectangle2D51, rectangleEdge56);
        org.jfree.chart.axis.CategoryAxis categoryAxis58 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis58.setLowerMargin((double) (short) 100);
        org.jfree.chart.block.BlockBorder blockBorder63 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets64 = blockBorder63.getInsets();
        double double66 = rectangleInsets64.trimWidth((double) (byte) 10);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D67 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D67.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D67.setAutoRangeStickyZero(false);
        numberAxis3D67.setUpperBound(100.0d);
        float float74 = numberAxis3D67.getTickMarkOutsideLength();
        org.jfree.chart.block.BlockContainer blockContainer75 = new org.jfree.chart.block.BlockContainer();
        blockContainer75.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D78 = blockContainer75.getBounds();
        numberAxis3D67.setLeftArrow((java.awt.Shape) rectangle2D78);
        org.jfree.chart.entity.ChartEntity chartEntity81 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D78, "");
        java.awt.geom.Rectangle2D rectangle2D82 = rectangleInsets64.createOutsetRectangle(rectangle2D78);
        org.jfree.chart.axis.CategoryAxis categoryAxis83 = new org.jfree.chart.axis.CategoryAxis();
        double double84 = categoryAxis83.getCategoryMargin();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor85 = null;
        java.awt.geom.Rectangle2D rectangle2D88 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge89 = org.jfree.chart.util.RectangleEdge.TOP;
        java.lang.String str90 = rectangleEdge89.toString();
        double double91 = categoryAxis83.getCategoryJava2DCoordinate(categoryAnchor85, (int) 'a', 1, rectangle2D88, rectangleEdge89);
        double double92 = categoryAxis58.getCategoryEnd((-1), (int) '4', rectangle2D78, rectangleEdge89);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo93 = null;
        try {
            org.jfree.chart.axis.AxisState axisState94 = categoryAxis3D0.draw(graphics2D2, (double) (byte) 0, rectangle2D15, rectangle2D51, rectangleEdge89, plotRenderingInfo93);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 1.0f + "'", float11 == 1.0f);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(rangeType29);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(paintContext42);
        org.junit.Assert.assertNotNull(rectangle2D51);
        org.junit.Assert.assertNotNull(rectangleEdge52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertNotNull(blockBorder63);
        org.junit.Assert.assertNotNull(rectangleInsets64);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 10.0d + "'", double66 == 10.0d);
        org.junit.Assert.assertTrue("'" + float74 + "' != '" + 1.0f + "'", float74 == 1.0f);
        org.junit.Assert.assertNotNull(rectangle2D78);
        org.junit.Assert.assertNotNull(rectangle2D82);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 0.2d + "'", double84 == 0.2d);
        org.junit.Assert.assertNotNull(rectangleEdge89);
        org.junit.Assert.assertTrue("'" + str90 + "' != '" + "RectangleEdge.TOP" + "'", str90.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 0.0d + "'", double91 == 0.0d);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 0.0d + "'", double92 == 0.0d);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.Timeline timeline2 = dateAxis1.getTimeline();
        boolean boolean4 = dateAxis1.isHiddenValue((long) (byte) 1);
        org.jfree.chart.axis.Timeline timeline5 = dateAxis1.getTimeline();
        org.jfree.chart.axis.Timeline timeline6 = dateAxis1.getTimeline();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.data.Range range8 = null;
        org.jfree.data.Range range10 = org.jfree.data.Range.expandToInclude(range8, (-1.0d));
        boolean boolean12 = range10.contains((double) 1);
        org.jfree.data.Range range15 = org.jfree.data.Range.shift(range10, (double) 100, false);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = rectangleConstraint7.toRangeHeight(range10);
        dateAxis1.setRange(range10);
        org.junit.Assert.assertNotNull(timeline2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeline5);
        org.junit.Assert.assertNotNull(timeline6);
        org.junit.Assert.assertNotNull(rectangleConstraint7);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNotNull(rectangleConstraint16);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setSectionOutlinesVisible(true);
        java.awt.Paint paint6 = piePlot3.getBackgroundPaint();
        java.awt.Paint paint8 = piePlot3.getSectionOutlinePaint((java.lang.Comparable) 100.0f);
        java.awt.Stroke stroke9 = piePlot3.getLabelOutlineStroke();
        java.awt.Paint paint10 = piePlot3.getShadowPaint();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator12 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        piePlot3.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator12);
        piePlot1.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator12);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot15 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot15.setLimit(1.0d);
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot15);
        org.jfree.chart.util.VerticalAlignment verticalAlignment19 = legendTitle18.getVerticalAlignment();
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint23 = rectangleConstraint21.toFixedWidth((double) 200);
        org.jfree.chart.util.Size2D size2D24 = legendTitle18.arrange(graphics2D20, rectangleConstraint23);
        size2D24.height = 100.0f;
        boolean boolean27 = standardPieSectionLabelGenerator12.equals((java.lang.Object) 100.0f);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(verticalAlignment19);
        org.junit.Assert.assertNotNull(rectangleConstraint21);
        org.junit.Assert.assertNotNull(rectangleConstraint23);
        org.junit.Assert.assertNotNull(size2D24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        java.awt.Font font2 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer6 = null;
        org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, paint3, (float) (-1), 0, textMeasurer6);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        multiplePiePlot8.removeChangeListener(plotChangeListener9);
        org.jfree.chart.plot.Plot plot11 = multiplePiePlot8.getParent();
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("ThreadContext", font2, (org.jfree.chart.plot.Plot) multiplePiePlot8, false);
        org.jfree.chart.title.LegendTitle legendTitle14 = jFreeChart13.getLegend();
        boolean boolean15 = jFreeChart13.isBorderVisible();
        jFreeChart13.setNotify(true);
        int int18 = jFreeChart13.getBackgroundImageAlignment();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(textBlock7);
        org.junit.Assert.assertNull(plot11);
        org.junit.Assert.assertNull(legendTitle14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 15 + "'", int18 == 15);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        blockContainer0.setWidth((double) 10.0f);
        org.jfree.chart.block.BlockBorder blockBorder3 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = blockBorder3.getInsets();
        blockContainer0.setMargin(rectangleInsets4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = rectangleConstraint7.toFixedWidth((double) 200);
        org.jfree.chart.util.Size2D size2D10 = blockContainer0.arrange(graphics2D6, rectangleConstraint9);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot11.setLimit(1.0d);
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot11);
        org.jfree.chart.util.VerticalAlignment verticalAlignment15 = legendTitle14.getVerticalAlignment();
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint17 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint19 = rectangleConstraint17.toFixedWidth((double) 200);
        org.jfree.chart.util.Size2D size2D20 = legendTitle14.arrange(graphics2D16, rectangleConstraint19);
        size2D20.height = 100.0f;
        org.jfree.chart.util.Size2D size2D23 = rectangleConstraint9.calculateConstrainedSize(size2D20);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.lang.String str27 = rectangleAnchor26.toString();
        java.awt.geom.Rectangle2D rectangle2D28 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D20, 0.0d, 0.4d, rectangleAnchor26);
        java.awt.Font font30 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint31 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer34 = null;
        org.jfree.chart.text.TextBlock textBlock35 = org.jfree.chart.text.TextUtilities.createTextBlock("", font30, paint31, (float) (-1), 0, textMeasurer34);
        java.awt.Graphics2D graphics2D36 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor39 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape43 = textBlock35.calculateBounds(graphics2D36, (float) 'a', (float) 255, textBlockAnchor39, (float) (short) 10, 0.0f, (double) (-237));
        boolean boolean44 = rectangleAnchor26.equals((java.lang.Object) textBlock35);
        org.junit.Assert.assertNotNull(blockBorder3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(rectangleConstraint7);
        org.junit.Assert.assertNotNull(rectangleConstraint9);
        org.junit.Assert.assertNotNull(size2D10);
        org.junit.Assert.assertNotNull(verticalAlignment15);
        org.junit.Assert.assertNotNull(rectangleConstraint17);
        org.junit.Assert.assertNotNull(rectangleConstraint19);
        org.junit.Assert.assertNotNull(size2D20);
        org.junit.Assert.assertNotNull(size2D23);
        org.junit.Assert.assertNotNull(rectangleAnchor26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "RectangleAnchor.LEFT" + "'", str27.equals("RectangleAnchor.LEFT"));
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(textBlock35);
        org.junit.Assert.assertNotNull(textBlockAnchor39);
        org.junit.Assert.assertNotNull(shape43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit(1.0d);
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot0);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = legendTitle3.getPosition();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent5 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle3);
        org.jfree.chart.JFreeChart jFreeChart6 = titleChangeEvent5.getChart();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = titleChangeEvent5.getType();
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNull(jFreeChart6);
        org.junit.Assert.assertNotNull(chartChangeEventType7);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.CLOCKWISE;
        double double1 = rotation0.getFactor();
        org.junit.Assert.assertNotNull(rotation0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.data.KeyedValues keyedValues1 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) 1.05d, keyedValues1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowData' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.chart.block.BlockResult blockResult0 = new org.jfree.chart.block.BlockResult();
        org.jfree.chart.entity.EntityCollection entityCollection1 = blockResult0.getEntityCollection();
        org.junit.Assert.assertNull(entityCollection1);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D0.setAutoRangeStickyZero(false);
        numberAxis3D0.setUpperBound(100.0d);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand7 = numberAxis3D0.getMarkerBand();
        java.awt.Shape shape8 = numberAxis3D0.getLeftArrow();
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        piePlot10.setSectionOutlinesVisible(true);
        java.awt.Paint paint13 = piePlot10.getBackgroundPaint();
        java.awt.Paint paint15 = piePlot10.getSectionOutlinePaint((java.lang.Comparable) 100.0f);
        java.awt.Stroke stroke16 = piePlot10.getLabelLinkStroke();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D17 = new org.jfree.chart.axis.NumberAxis3D();
        boolean boolean18 = numberAxis3D17.isAutoTickUnitSelection();
        boolean boolean19 = numberAxis3D17.isVisible();
        boolean boolean20 = numberAxis3D17.isAutoRange();
        numberAxis3D17.setTickLabelsVisible(true);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit23 = numberAxis3D17.getTickUnit();
        double double24 = piePlot10.getExplodePercent((java.lang.Comparable) numberTickUnit23);
        numberAxis3D0.setTickUnit(numberTickUnit23, false, false);
        org.junit.Assert.assertNull(markerAxisBand7);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(paint15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(numberTickUnit23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getDomainAxisEdge((int) (byte) 1);
        org.jfree.chart.axis.AxisLocation axisLocation4 = categoryPlot0.getDomainAxisLocation(200);
        java.awt.Font font6 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color7 = java.awt.Color.PINK;
        org.jfree.chart.text.TextFragment textFragment9 = new org.jfree.chart.text.TextFragment("", font6, (java.awt.Paint) color7, (float) 1L);
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        categoryPlot0.setRenderer((int) '4', categoryItemRenderer12);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        java.awt.Paint paint1 = blockBorder0.getPaint();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.util.UnitType unitType3 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = new org.jfree.chart.util.RectangleInsets(unitType3, (double) (short) 100, (double) (byte) 0, (double) 0.0f, (double) '#');
        double double10 = rectangleInsets8.calculateBottomOutset((double) 1L);
        java.lang.String str11 = rectangleInsets8.toString();
        org.jfree.chart.block.BlockBorder blockBorder12 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = blockBorder12.getInsets();
        double double15 = rectangleInsets13.trimWidth((double) (byte) 10);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D16 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D16.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D16.setAutoRangeStickyZero(false);
        numberAxis3D16.setUpperBound(100.0d);
        float float23 = numberAxis3D16.getTickMarkOutsideLength();
        org.jfree.chart.block.BlockContainer blockContainer24 = new org.jfree.chart.block.BlockContainer();
        blockContainer24.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D27 = blockContainer24.getBounds();
        numberAxis3D16.setLeftArrow((java.awt.Shape) rectangle2D27);
        org.jfree.chart.entity.ChartEntity chartEntity30 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D27, "");
        java.awt.geom.Rectangle2D rectangle2D31 = rectangleInsets13.createOutsetRectangle(rectangle2D27);
        java.awt.geom.Rectangle2D rectangle2D32 = rectangleInsets8.createOutsetRectangle(rectangle2D27);
        try {
            blockBorder0.draw(graphics2D2, rectangle2D27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockBorder0);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(unitType3);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "RectangleInsets[t=100.0,l=0.0,b=0.0,r=35.0]" + "'", str11.equals("RectangleInsets[t=100.0,l=0.0,b=0.0,r=35.0]"));
        org.junit.Assert.assertNotNull(blockBorder12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 10.0d + "'", double15 == 10.0d);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 1.0f + "'", float23 == 1.0f);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertNotNull(rectangle2D32);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setSectionOutlinesVisible(true);
        java.awt.Paint paint4 = piePlot1.getBackgroundPaint();
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.image.ColorModel colorModel7 = null;
        java.awt.Rectangle rectangle8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.awt.geom.AffineTransform affineTransform10 = null;
        java.awt.RenderingHints renderingHints11 = null;
        java.awt.PaintContext paintContext12 = color6.createContext(colorModel7, rectangle8, rectangle2D9, affineTransform10, renderingHints11);
        piePlot1.setSectionPaint((java.lang.Comparable) (byte) 100, (java.awt.Paint) color6);
        boolean boolean14 = piePlot1.getLabelLinksVisible();
        double double15 = piePlot1.getMaximumExplodePercent();
        double double16 = piePlot1.getShadowXOffset();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paintContext12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 4.0d + "'", double16 == 4.0d);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        java.awt.Paint paint2 = ringPlot1.getSeparatorPaint();
        double double3 = ringPlot1.getMaximumExplodePercent();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        piePlot6.setSectionOutlinesVisible(true);
        java.awt.Paint paint9 = piePlot6.getBackgroundPaint();
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.image.ColorModel colorModel12 = null;
        java.awt.Rectangle rectangle13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.awt.geom.AffineTransform affineTransform15 = null;
        java.awt.RenderingHints renderingHints16 = null;
        java.awt.PaintContext paintContext17 = color11.createContext(colorModel12, rectangle13, rectangle2D14, affineTransform15, renderingHints16);
        piePlot6.setSectionPaint((java.lang.Comparable) (byte) 100, (java.awt.Paint) color11);
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor20 = null;
        org.jfree.chart.block.BlockContainer blockContainer23 = new org.jfree.chart.block.BlockContainer();
        blockContainer23.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D26 = blockContainer23.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double28 = categoryAxis19.getCategoryJava2DCoordinate(categoryAnchor20, (int) (byte) 10, 0, rectangle2D26, rectangleEdge27);
        piePlot6.setLegendItemShape((java.awt.Shape) rectangle2D26);
        org.jfree.chart.plot.PiePlot3D piePlot3D30 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D30.setBackgroundImageAlignment(1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        org.jfree.chart.plot.PiePlotState piePlotState35 = ringPlot1.initialise(graphics2D4, rectangle2D26, (org.jfree.chart.plot.PiePlot) piePlot3D30, (java.lang.Integer) 100, plotRenderingInfo34);
        boolean boolean36 = ringPlot1.isCircular();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(paintContext17);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(piePlotState35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getDomainAxisEdge((int) (byte) 1);
        org.jfree.chart.axis.AxisLocation axisLocation4 = categoryPlot0.getDomainAxisLocation(200);
        org.jfree.chart.util.Layer layer5 = null;
        java.util.Collection collection6 = categoryPlot0.getDomainMarkers(layer5);
        java.awt.Paint paint9 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker(35.0d, paint9, stroke10);
        float float12 = valueMarker11.getAlpha();
        org.jfree.chart.text.TextAnchor textAnchor13 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        java.lang.String str14 = textAnchor13.toString();
        valueMarker11.setLabelTextAnchor(textAnchor13);
        org.jfree.chart.util.Layer layer16 = null;
        try {
            boolean boolean17 = categoryPlot0.removeRangeMarker(10, (org.jfree.chart.plot.Marker) valueMarker11, layer16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNull(collection6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 1.0f + "'", float12 == 1.0f);
        org.junit.Assert.assertNotNull(textAnchor13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "TextAnchor.BOTTOM_CENTER" + "'", str14.equals("TextAnchor.BOTTOM_CENTER"));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        java.lang.String str0 = org.jfree.chart.labels.StandardPieSectionLabelGenerator.DEFAULT_SECTION_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        java.awt.Stroke stroke2 = strokeMap0.getStroke((java.lang.Comparable) (-1L));
        java.awt.Stroke stroke4 = strokeMap0.getStroke((java.lang.Comparable) 10.0d);
        org.junit.Assert.assertNull(stroke2);
        org.junit.Assert.assertNull(stroke4);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D(0.0d, 1.0d);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getCategoryMargin();
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) 100, "TextAnchor.CENTER_RIGHT");
        java.lang.Object obj5 = categoryAxis0.clone();
        java.awt.Paint paint7 = categoryAxis0.getTickLabelPaint((java.lang.Comparable) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setSectionOutlinesVisible(true);
        java.awt.Paint paint6 = piePlot3.getBackgroundPaint();
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.image.ColorModel colorModel9 = null;
        java.awt.Rectangle rectangle10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        java.awt.geom.AffineTransform affineTransform12 = null;
        java.awt.RenderingHints renderingHints13 = null;
        java.awt.PaintContext paintContext14 = color8.createContext(colorModel9, rectangle10, rectangle2D11, affineTransform12, renderingHints13);
        piePlot3.setSectionPaint((java.lang.Comparable) (byte) 100, (java.awt.Paint) color8);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor17 = null;
        org.jfree.chart.block.BlockContainer blockContainer20 = new org.jfree.chart.block.BlockContainer();
        blockContainer20.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D23 = blockContainer20.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double25 = categoryAxis16.getCategoryJava2DCoordinate(categoryAnchor17, (int) (byte) 10, 0, rectangle2D23, rectangleEdge24);
        piePlot3.setLegendItemShape((java.awt.Shape) rectangle2D23);
        piePlotState1.setLinkArea(rectangle2D23);
        piePlotState1.setTotal((double) (short) 1);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paintContext14);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        double[] doubleArray5 = new double[] { (byte) 0, 0.2d, (-1.0d) };
        double[] doubleArray9 = new double[] { (byte) 0, 0.2d, (-1.0d) };
        double[] doubleArray13 = new double[] { (byte) 0, 0.2d, (-1.0d) };
        double[][] doubleArray14 = new double[][] { doubleArray5, doubleArray9, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("rect", "RectangleAnchor.BOTTOM_LEFT", doubleArray14);
        try {
            org.jfree.data.general.PieDataset pieDataset17 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset15, (java.lang.Comparable) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("RectangleAnchor.LEFT");
        numberAxis3D1.resizeRange((double) 0);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis6.setLowerMargin((double) (short) 100);
        org.jfree.chart.block.BlockBorder blockBorder11 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = blockBorder11.getInsets();
        double double14 = rectangleInsets12.trimWidth((double) (byte) 10);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D15 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D15.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D15.setAutoRangeStickyZero(false);
        numberAxis3D15.setUpperBound(100.0d);
        float float22 = numberAxis3D15.getTickMarkOutsideLength();
        org.jfree.chart.block.BlockContainer blockContainer23 = new org.jfree.chart.block.BlockContainer();
        blockContainer23.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D26 = blockContainer23.getBounds();
        numberAxis3D15.setLeftArrow((java.awt.Shape) rectangle2D26);
        org.jfree.chart.entity.ChartEntity chartEntity29 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D26, "");
        java.awt.geom.Rectangle2D rectangle2D30 = rectangleInsets12.createOutsetRectangle(rectangle2D26);
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = new org.jfree.chart.axis.CategoryAxis();
        double double32 = categoryAxis31.getCategoryMargin();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor33 = null;
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = org.jfree.chart.util.RectangleEdge.TOP;
        java.lang.String str38 = rectangleEdge37.toString();
        double double39 = categoryAxis31.getCategoryJava2DCoordinate(categoryAnchor33, (int) 'a', 1, rectangle2D36, rectangleEdge37);
        double double40 = categoryAxis6.getCategoryEnd((-1), (int) '4', rectangle2D26, rectangleEdge37);
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor43 = null;
        org.jfree.chart.block.BlockContainer blockContainer46 = new org.jfree.chart.block.BlockContainer();
        blockContainer46.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D49 = blockContainer46.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge50 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double51 = categoryAxis42.getCategoryJava2DCoordinate(categoryAnchor43, (int) (byte) 10, 0, rectangle2D49, rectangleEdge50);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo52 = null;
        try {
            org.jfree.chart.axis.AxisState axisState53 = numberAxis3D1.draw(graphics2D4, (double) 'a', rectangle2D26, rectangle2D41, rectangleEdge50, plotRenderingInfo52);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockBorder11);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 10.0d + "'", double14 == 10.0d);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 1.0f + "'", float22 == 1.0f);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.2d + "'", double32 == 0.2d);
        org.junit.Assert.assertNotNull(rectangleEdge37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "RectangleEdge.TOP" + "'", str38.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D49);
        org.junit.Assert.assertNotNull(rectangleEdge50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        blockContainer0.setWidth((double) 10.0f);
        double double3 = blockContainer0.getWidth();
        java.util.List list4 = blockContainer0.getBlocks();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
        org.junit.Assert.assertNotNull(list4);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getDomainAxisEdge((int) (byte) 1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryPlot0.getAxisOffset();
        java.awt.Stroke stroke4 = null;
        try {
            categoryPlot0.setDomainGridlineStroke(stroke4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setBackgroundImageAlignment(1);
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        piePlot4.setSectionOutlinesVisible(true);
        java.awt.Paint paint7 = piePlot4.getBackgroundPaint();
        java.awt.Paint paint9 = piePlot4.getSectionOutlinePaint((java.lang.Comparable) 100.0f);
        piePlot4.setCircular(true, false);
        double double13 = piePlot4.getLabelGap();
        piePlot4.setShadowYOffset(1.05d);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot16 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.Plot plot17 = multiplePiePlot16.getParent();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent18 = null;
        multiplePiePlot16.markerChanged(markerChangeEvent18);
        java.awt.Paint paint20 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        multiplePiePlot16.setNoDataMessagePaint(paint20);
        piePlot4.setShadowPaint(paint20);
        java.awt.Stroke stroke23 = piePlot4.getLabelOutlineStroke();
        piePlot3D0.setOutlineStroke(stroke23);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.025d + "'", double13 == 0.025d);
        org.junit.Assert.assertNull(plot17);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(stroke23);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        java.awt.Color color0 = java.awt.Color.PINK;
        java.awt.Color color1 = java.awt.Color.white;
        int int2 = color1.getTransparency();
        float[] floatArray9 = new float[] { (byte) 1, (-1L), '4', 100, 0L, ' ' };
        float[] floatArray10 = color1.getComponents(floatArray9);
        float[] floatArray11 = color0.getColorComponents(floatArray9);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getDomainAxisEdge((int) (byte) 1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryPlot0.getAxisOffset();
        boolean boolean4 = categoryPlot0.isRangeCrosshairVisible();
        java.awt.Stroke stroke5 = categoryPlot0.getRangeGridlineStroke();
        categoryPlot0.configureRangeAxes();
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor(2);
        try {
            org.jfree.chart.plot.PieLabelRecord pieLabelRecord3 = pieLabelDistributor1.getPieLabelRecord((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D3.setTickMarkOutsideLength((float) (short) 1);
        numberAxis3D3.setAutoRangeStickyZero(false);
        numberAxis3D3.setUpperBound(100.0d);
        float float10 = numberAxis3D3.getTickMarkOutsideLength();
        org.jfree.chart.block.BlockContainer blockContainer11 = new org.jfree.chart.block.BlockContainer();
        blockContainer11.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D14 = blockContainer11.getBounds();
        numberAxis3D3.setLeftArrow((java.awt.Shape) rectangle2D14);
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.plot.PiePlot piePlot17 = new org.jfree.chart.plot.PiePlot(pieDataset16);
        piePlot17.setSectionOutlinesVisible(true);
        java.awt.Paint paint20 = piePlot17.getBackgroundPaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        org.jfree.chart.plot.PiePlotState piePlotState23 = ringPlot1.initialise(graphics2D2, rectangle2D14, piePlot17, (java.lang.Integer) 3, plotRenderingInfo22);
        ringPlot1.setSectionDepth(0.0d);
        java.awt.Paint paint26 = ringPlot1.getBaseSectionPaint();
        ringPlot1.setOuterSeparatorExtension((double) 1.0f);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 1.0f + "'", float10 == 1.0f);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(piePlotState23);
        org.junit.Assert.assertNotNull(paint26);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        piePlot1.setOutlinePaint((java.awt.Paint) color2);
        piePlot1.setSimpleLabels(false);
        piePlot1.setForegroundAlpha((float) 0L);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit(1.0d);
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot0);
        multiplePiePlot0.setAggregatedItemsKey((java.lang.Comparable) 1.0E-8d);
        org.jfree.chart.util.TableOrder tableOrder6 = multiplePiePlot0.getDataExtractOrder();
        org.junit.Assert.assertNotNull(tableOrder6);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.lang.Object obj2 = null;
        boolean boolean3 = dateAxis1.equals(obj2);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.Timeline timeline6 = dateAxis5.getTimeline();
        java.util.TimeZone timeZone7 = dateAxis5.getTimeZone();
        dateAxis1.setTimeZone(timeZone7);
        java.text.DateFormat dateFormat9 = null;
        dateAxis1.setDateFormatOverride(dateFormat9);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(timeline6);
        org.junit.Assert.assertNotNull(timeZone7);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        java.awt.Color color2 = java.awt.Color.getColor("VerticalAlignment.CENTER", 3);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        boolean boolean1 = numberAxis3D0.isAutoTickUnitSelection();
        boolean boolean2 = numberAxis3D0.isVerticalTickLabels();
        numberAxis3D0.resizeRange(0.0d);
        boolean boolean6 = numberAxis3D0.equals((java.lang.Object) (short) -1);
        numberAxis3D0.setInverted(true);
        java.lang.Object obj9 = numberAxis3D0.clone();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("PlotOrientation.VERTICAL");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = numberAxis1.getMarkerBand();
        org.junit.Assert.assertNull(markerAxisBand2);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        java.awt.Paint paint1 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker(35.0d, paint1, stroke2);
        org.jfree.chart.block.BlockBorder blockBorder4 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = blockBorder4.getInsets();
        org.jfree.chart.block.BlockContainer blockContainer6 = new org.jfree.chart.block.BlockContainer();
        blockContainer6.setWidth((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D9 = blockContainer6.getBounds();
        rectangleInsets5.trim(rectangle2D9);
        valueMarker3.setLabelOffset(rectangleInsets5);
        double double13 = rectangleInsets5.calculateRightOutset((double) 0L);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(blockBorder4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(rectangle2D9);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setSectionOutlinesVisible(true);
        java.awt.Paint paint4 = piePlot1.getBackgroundPaint();
        piePlot1.setOutlineVisible(false);
        piePlot1.setIgnoreNullValues(false);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.chart.ui.Licences licences0 = new org.jfree.chart.ui.Licences();
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.Timeline timeline2 = dateAxis1.getTimeline();
        boolean boolean4 = dateAxis1.isHiddenValue((long) (byte) 1);
        org.jfree.chart.axis.Timeline timeline5 = dateAxis1.getTimeline();
        java.util.Date date6 = dateAxis1.getMaximumDate();
        java.util.Date date7 = dateAxis1.getMaximumDate();
        org.junit.Assert.assertNotNull(timeline2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeline5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        java.awt.Font font2 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer6 = null;
        org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, paint3, (float) (-1), 0, textMeasurer6);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        multiplePiePlot8.removeChangeListener(plotChangeListener9);
        org.jfree.chart.plot.Plot plot11 = multiplePiePlot8.getParent();
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("ThreadContext", font2, (org.jfree.chart.plot.Plot) multiplePiePlot8, false);
        java.util.List list14 = jFreeChart13.getSubtitles();
        try {
            org.jfree.chart.title.Title title16 = jFreeChart13.getSubtitle(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(textBlock7);
        org.junit.Assert.assertNull(plot11);
        org.junit.Assert.assertNotNull(list14);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        java.lang.Class class0 = null;
        java.lang.ClassLoader classLoader1 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class0);
        java.util.ResourceBundle.clearCache(classLoader1);
        org.junit.Assert.assertNotNull(classLoader1);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit(1.0d);
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot0);
        java.awt.Paint paint4 = legendTitle3.getItemPaint();
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj1 = categoryAxis0.clone();
        categoryAxis0.setTickMarkInsideLength((float) 10L);
        double double4 = categoryAxis0.getUpperMargin();
        categoryAxis0.setCategoryMargin(0.025d);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        boolean boolean1 = numberAxis3D0.isAutoTickUnitSelection();
        boolean boolean2 = numberAxis3D0.isVisible();
        numberAxis3D0.setLowerBound((double) 200);
        java.awt.Color color5 = java.awt.Color.white;
        numberAxis3D0.setTickMarkPaint((java.awt.Paint) color5);
        numberAxis3D0.setTickLabelsVisible(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        blockParams0.setTranslateY((-10.0d));
        blockParams0.setTranslateY((double) (short) 1);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        blockParams0.setTranslateY((double) 0.0f);
        boolean boolean3 = blockParams0.getGenerateEntities();
        blockParams0.setTranslateY((double) (short) 100);
        blockParams0.setTranslateX((-0.025d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        blockContainer0.setWidth((double) 10.0f);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = rectangleConstraint4.toFixedWidth((double) 200);
        org.jfree.chart.util.Size2D size2D7 = blockContainer0.arrange(graphics2D3, rectangleConstraint6);
        boolean boolean8 = blockContainer0.isEmpty();
        org.junit.Assert.assertNotNull(rectangleConstraint4);
        org.junit.Assert.assertNotNull(rectangleConstraint6);
        org.junit.Assert.assertNotNull(size2D7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getCategoryMargin();
        double double2 = categoryAxis0.getLowerMargin();
        java.awt.Stroke stroke3 = categoryAxis0.getAxisLineStroke();
        categoryAxis0.clearCategoryLabelToolTips();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit(1.0d);
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot0);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = legendTitle3.getPosition();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent5 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle3);
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.UnitType unitType7 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = new org.jfree.chart.util.RectangleInsets(unitType7, (double) (short) 100, (double) (byte) 0, (double) 0.0f, (double) '#');
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType14 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        java.lang.String str15 = chartChangeEventType14.toString();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent16 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (short) 100, jFreeChart13, chartChangeEventType14);
        boolean boolean17 = plotOrientation6.equals((java.lang.Object) chartChangeEventType14);
        titleChangeEvent5.setType(chartChangeEventType14);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(plotOrientation6);
        org.junit.Assert.assertNotNull(unitType7);
        org.junit.Assert.assertNotNull(chartChangeEventType14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str15.equals("ChartChangeEventType.DATASET_UPDATED"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer1 = new org.jfree.chart.text.G2TextMeasurer(graphics2D0);
        try {
            float float5 = g2TextMeasurer1.getStringWidth("ChartChangeEventType.DATASET_UPDATED", (int) (byte) 10, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }
}

