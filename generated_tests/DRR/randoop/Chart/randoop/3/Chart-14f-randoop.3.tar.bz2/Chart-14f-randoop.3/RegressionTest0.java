import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        java.lang.Class class0 = null;
        java.util.Date date1 = null;
        java.util.TimeZone timeZone2 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date1, timeZone2);
        org.junit.Assert.assertNull(regularTimePeriod3);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        java.lang.String str1 = textAnchor0.toString();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str1.equals("TextAnchor.BASELINE_LEFT"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation3 = xYPlot0.getOrientation();
        org.jfree.chart.plot.Marker marker5 = null;
        org.jfree.chart.util.Layer layer6 = null;
        try {
            boolean boolean8 = xYPlot0.removeRangeMarker(1, marker5, layer6, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation3);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_DOMAIN_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        org.jfree.data.RangeType rangeType2 = null;
        try {
            numberAxis1.setRangeType(rangeType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rangeType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        float[] floatArray3 = new float[] { (-1.0f), (short) 100 };
        try {
            float[] floatArray4 = color0.getRGBComponents(floatArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray3);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        java.awt.Stroke stroke2 = null;
        try {
            xYPlot0.setRangeZeroBaselineStroke(stroke2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.awt.Paint paint2 = numberAxis1.getLabelPaint();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        xYPlot4.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = xYPlot4.getOrientation();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace11 = numberAxis1.reserveSpace(graphics2D3, (org.jfree.chart.plot.Plot) xYPlot4, rectangle2D8, rectangleEdge9, axisSpace10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(plotOrientation7);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        boolean boolean2 = xYPlot0.isRangeGridlinesVisible();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder3 = null;
        try {
            xYPlot0.setDatasetRenderingOrder(datasetRenderingOrder3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            rectangleInsets0.trim(rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int3 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis2);
        org.jfree.data.RangeType rangeType4 = null;
        try {
            numberAxis2.setRangeType(rangeType4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rangeType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        java.awt.Color color1 = java.awt.Color.LIGHT_GRAY;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Color color5 = java.awt.Color.getColor("hi!", 0);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot6.setDomainGridlineStroke(stroke7);
        try {
            org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) 0, (java.awt.Paint) color1, stroke2, (java.awt.Paint) color5, stroke7, (float) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D2 = rectangleInsets0.createInsetRectangle(rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) (short) -1, (double) (byte) 0, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor3);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker5 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color3, stroke4);
        java.awt.Paint paint6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryMarker5.setLabelPaint(paint6);
        xYPlot0.setDomainZeroBaselinePaint(paint6);
        java.awt.Stroke stroke9 = xYPlot0.getDomainZeroBaselineStroke();
        org.jfree.chart.plot.Marker marker10 = null;
        try {
            boolean boolean11 = xYPlot0.removeRangeMarker(marker10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str2 = numberAxis1.getLabel();
        java.lang.String str3 = numberAxis1.getLabel();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit4 = null;
        try {
            numberAxis1.setTickUnit(numberTickUnit4, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unit' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str2.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str3.equals("TextAnchor.BASELINE_LEFT"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int3 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis2);
        java.awt.Shape shape4 = null;
        try {
            numberAxis2.setUpArrow(shape4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrow' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color1, stroke2);
        float[] floatArray5 = new float[] { 10.0f };
        try {
            float[] floatArray6 = color1.getRGBComponents(floatArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(floatArray5);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str2 = numberAxis1.getLabel();
        java.awt.Paint paint3 = null;
        try {
            numberAxis1.setLabelPaint(paint3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str2.equals("TextAnchor.BASELINE_LEFT"));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot0.setDomainGridlineStroke(stroke1);
        float float3 = xYPlot0.getBackgroundAlpha();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int6 = xYPlot3.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis5);
        numberAxis5.setLowerBound((double) (short) 10);
        xYPlot0.setDomainAxis((int) (byte) 1, (org.jfree.chart.axis.ValueAxis) numberAxis5, true);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int15 = xYPlot12.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis14);
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = null;
        org.jfree.chart.axis.AxisSpace axisSpace18 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace19 = numberAxis5.reserveSpace(graphics2D11, (org.jfree.chart.plot.Plot) xYPlot12, rectangle2D16, rectangleEdge17, axisSpace18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_INSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0 == 0.0f);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        boolean boolean0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        xYPlot0.setRenderer((int) (byte) 1, xYItemRenderer4);
        java.awt.Stroke stroke6 = null;
        try {
            xYPlot0.setDomainCrosshairStroke(stroke6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation3 = xYPlot0.getOrientation();
        java.awt.geom.Point2D point2D4 = null;
        try {
            xYPlot0.setQuadrantOrigin(point2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'origin' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation3);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) '#', 0, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Blue");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.LEFT;
        boolean boolean2 = rectangleAnchor0.equals((java.lang.Object) 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color2, stroke3);
        xYPlot0.setBackgroundPaint((java.awt.Paint) color2);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        xYPlot0.setRenderer(6, xYItemRenderer7);
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        xYPlot0.removeChangeListener(plotChangeListener9);
        org.jfree.chart.axis.ValueAxis valueAxis12 = xYPlot0.getRangeAxisForDataset((int) (short) 0);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = null;
        try {
            xYPlot0.setDatasetRenderingOrder(datasetRenderingOrder13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(valueAxis12);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str1 = xYPlot0.getNoDataMessage();
        xYPlot0.configureRangeAxes();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.awt.geom.Point2D point2D5 = null;
        org.jfree.chart.plot.PlotState plotState6 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        try {
            xYPlot0.draw(graphics2D3, rectangle2D4, point2D5, plotState6, plotRenderingInfo7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int3 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis2);
        org.jfree.chart.LegendItemCollection legendItemCollection4 = xYPlot0.getFixedLegendItems();
        java.awt.Paint paint5 = xYPlot0.getRangeGridlinePaint();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNull(legendItemCollection4);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.awt.Paint paint2 = numberAxis1.getLabelPaint();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = numberAxis1.valueToJava2D(0.0d, rectangle2D4, rectangleEdge5);
        try {
            numberAxis1.setRange(100.0d, 1.0E-8d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (100.0) <= upper (1.0E-8).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        java.awt.Color color1 = java.awt.Color.getColor("DatasetRenderingOrder.REVERSE");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.junit.Assert.assertNotNull(plotOrientation0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int6 = xYPlot3.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis5);
        numberAxis5.setLowerBound((double) (short) 10);
        xYPlot0.setDomainAxis((int) (byte) 1, (org.jfree.chart.axis.ValueAxis) numberAxis5, true);
        java.awt.Paint paint11 = null;
        try {
            xYPlot0.setDomainGridlinePaint(paint11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        java.awt.Color color0 = java.awt.Color.orange;
        int int1 = color0.getTransparency();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        boolean boolean2 = xYPlot0.isRangeGridlinesVisible();
        java.awt.Color color5 = java.awt.Color.getColor("hi!", 0);
        xYPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color5);
        java.lang.Object obj7 = xYPlot0.clone();
        boolean boolean8 = xYPlot0.isRangeCrosshairVisible();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double1 = rectangleInsets0.getTop();
        double double3 = rectangleInsets0.calculateBottomInset((double) '4');
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        xYPlot0.setRenderer((int) (byte) 1, xYItemRenderer4);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int9 = xYPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis8);
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis8);
        org.jfree.data.RangeType rangeType11 = null;
        try {
            numberAxis8.setRangeType(rangeType11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rangeType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation3 = xYPlot0.getOrientation();
        java.lang.String str4 = plotOrientation3.toString();
        java.lang.String str5 = plotOrientation3.toString();
        org.junit.Assert.assertNotNull(plotOrientation3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "PlotOrientation.VERTICAL" + "'", str4.equals("PlotOrientation.VERTICAL"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "PlotOrientation.VERTICAL" + "'", str5.equals("PlotOrientation.VERTICAL"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        boolean boolean2 = xYPlot0.isRangeGridlinesVisible();
        java.awt.Color color5 = java.awt.Color.getColor("hi!", 0);
        xYPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color5);
        org.jfree.chart.axis.ValueAxis valueAxis7 = xYPlot0.getDomainAxis();
        org.jfree.chart.axis.AxisLocation axisLocation8 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot0.setRangeAxisLocation(axisLocation8, true);
        java.lang.String str11 = axisLocation8.toString();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "AxisLocation.TOP_OR_LEFT" + "'", str11.equals("AxisLocation.TOP_OR_LEFT"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        java.awt.Color color1 = java.awt.Color.getColor("AxisLocation.TOP_OR_LEFT");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color1, stroke2);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color5, stroke6);
        categoryMarker3.setLabelPaint((java.awt.Paint) color5);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker3);
        org.jfree.chart.plot.Marker marker10 = markerChangeEvent9.getMarker();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType11 = markerChangeEvent9.getType();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(marker10);
        org.junit.Assert.assertNotNull(chartChangeEventType11);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.color.ColorSpace colorSpace1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        xYPlot2.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = xYPlot2.getOrientation();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.awt.Paint paint8 = numberAxis7.getLabelPaint();
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = numberAxis7.valueToJava2D(0.0d, rectangle2D10, rectangleEdge11);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray13 = new org.jfree.chart.axis.ValueAxis[] { numberAxis7 };
        xYPlot2.setDomainAxes(valueAxisArray13);
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker19 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color17, stroke18);
        xYPlot15.setBackgroundPaint((java.awt.Paint) color17);
        xYPlot2.setRangeCrosshairPaint((java.awt.Paint) color17);
        float[] floatArray26 = new float[] { (byte) 1, 10L, 100.0f, 100.0f };
        float[] floatArray27 = color17.getComponents(floatArray26);
        try {
            float[] floatArray28 = color0.getColorComponents(colorSpace1, floatArray26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(valueAxisArray13);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertNotNull(floatArray27);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int4 = xYPlot1.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3);
        java.awt.Stroke stroke5 = numberAxis3.getAxisLineStroke();
        numberAxis3.setVisible(false);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.awt.Paint paint10 = numberAxis9.getLabelPaint();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis9, xYItemRenderer11);
        numberAxis9.setRangeWithMargins((double) 10.0f, (double) (byte) 100);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("SeriesRenderingOrder.FORWARD", timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D2 = rectangleInsets0.createOutsetRectangle(rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str2 = numberAxis1.getLabel();
        java.lang.String str3 = numberAxis1.getLabel();
        java.awt.Stroke stroke4 = null;
        try {
            numberAxis1.setAxisLineStroke(stroke4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str2.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str3.equals("TextAnchor.BASELINE_LEFT"));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color2);
        org.jfree.data.RangeType rangeType4 = null;
        try {
            numberAxis1.setRangeType(rangeType4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rangeType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str2 = numberAxis1.getLabel();
        numberAxis1.setFixedDimension((double) (-1L));
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint8 = xYPlot7.getDomainZeroBaselinePaint();
        boolean boolean9 = xYPlot7.isRangeGridlinesVisible();
        java.awt.Color color12 = java.awt.Color.getColor("hi!", 0);
        xYPlot7.setRangeZeroBaselinePaint((java.awt.Paint) color12);
        java.lang.Object obj14 = xYPlot7.clone();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = xYPlot7.getRangeAxisEdge();
        try {
            double double16 = numberAxis1.java2DToValue((double) 1, rectangle2D6, rectangleEdge15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str2.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_INCLUDES_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color2, stroke3);
        xYPlot0.setBackgroundPaint((java.awt.Paint) color2);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        xYPlot0.setRenderer(6, xYItemRenderer7);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot0.getRangeMarkers((int) ' ', layer10);
        xYPlot0.setOutlineVisible(true);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(collection11);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        java.awt.Color color0 = java.awt.Color.pink;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color2, stroke3);
        xYPlot0.setBackgroundPaint((java.awt.Paint) color2);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        xYPlot0.setRenderer(6, xYItemRenderer7);
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        xYPlot0.removeChangeListener(plotChangeListener9);
        org.jfree.chart.axis.ValueAxis valueAxis12 = xYPlot0.getRangeAxisForDataset((int) (short) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        xYPlot0.setAxisOffset(rectangleInsets13);
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        java.awt.geom.Point2D point2D17 = null;
        org.jfree.chart.plot.PlotState plotState18 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        try {
            xYPlot0.draw(graphics2D15, rectangle2D16, point2D17, plotState18, plotRenderingInfo19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str2 = numberAxis1.getLabel();
        java.lang.String str3 = numberAxis1.getLabel();
        java.awt.Paint paint4 = numberAxis1.getAxisLinePaint();
        java.awt.Shape shape5 = numberAxis1.getRightArrow();
        try {
            numberAxis1.setRangeWithMargins(0.05d, (double) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (0.05) <= upper (0.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str2.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str3.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        java.awt.Color color0 = java.awt.Color.GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot0.setDomainGridlineStroke(stroke1);
        java.awt.Stroke stroke3 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        xYPlot0.setRangeGridlineStroke(stroke3);
        org.jfree.data.xy.XYDataset xYDataset6 = xYPlot0.getDataset(0);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(xYDataset6);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint3 = xYPlot2.getDomainZeroBaselinePaint();
        boolean boolean4 = day0.equals((java.lang.Object) paint3);
        java.util.Calendar calendar5 = null;
        try {
            day0.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color2, stroke3);
        xYPlot0.setBackgroundPaint((java.awt.Paint) color2);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        xYPlot0.setRenderer(6, xYItemRenderer7);
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        xYPlot0.removeChangeListener(plotChangeListener9);
        java.awt.Stroke stroke11 = xYPlot0.getDomainGridlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        xYPlot0.zoomDomainAxes((double) 100, (double) 8, plotRenderingInfo14, point2D15);
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        int int18 = xYPlot0.indexOf(xYDataset17);
        xYPlot0.configureRangeAxes();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        try {
            java.awt.Color color1 = java.awt.Color.decode("DatasetRenderingOrder.REVERSE");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"DatasetRenderingOrder.REVERSE\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double1 = rectangleInsets0.getTop();
        double double3 = rectangleInsets0.trimWidth((double) 0);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-8.0d) + "'", double3 == (-8.0d));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color2, stroke3);
        xYPlot0.setBackgroundPaint((java.awt.Paint) color2);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        xYPlot0.setRenderer(6, xYItemRenderer7);
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        xYPlot0.removeChangeListener(plotChangeListener9);
        org.jfree.chart.util.Layer layer11 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection12 = xYPlot0.getDomainMarkers(layer11);
        org.jfree.chart.axis.AxisSpace axisSpace13 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace13, false);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(layer11);
        org.junit.Assert.assertNull(collection12);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = day0.getMiddleMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int3 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        xYPlot0.removeChangeListener(plotChangeListener4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.awt.geom.Point2D point2D3 = null;
        org.jfree.chart.plot.PlotState plotState4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        try {
            categoryPlot0.draw(graphics2D1, rectangle2D2, point2D3, plotState4, plotRenderingInfo5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color2);
        numberAxis1.setLowerBound(0.0d);
        double double6 = numberAxis1.getFixedDimension();
        java.awt.Font font7 = numberAxis1.getLabelFont();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(font7);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        boolean boolean2 = xYPlot0.isRangeGridlinesVisible();
        java.awt.Color color5 = java.awt.Color.getColor("hi!", 0);
        xYPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color5);
        org.jfree.chart.axis.ValueAxis valueAxis7 = xYPlot0.getDomainAxis();
        org.jfree.chart.axis.AxisLocation axisLocation8 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot0.setRangeAxisLocation(axisLocation8, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        xYPlot0.zoomRangeAxes(0.0d, plotRenderingInfo12, point2D13, true);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNotNull(axisLocation8);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color2, stroke3);
        xYPlot0.setBackgroundPaint((java.awt.Paint) color2);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        xYPlot0.setRenderer(6, xYItemRenderer7);
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        xYPlot0.removeChangeListener(plotChangeListener9);
        org.jfree.chart.axis.ValueAxis valueAxis12 = xYPlot0.getRangeAxisForDataset((int) (short) 0);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis14 = xYPlot0.getRangeAxisForDataset(6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 6 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(valueAxis12);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D2 = rectangleInsets0.createOutsetRectangle(rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        java.awt.color.ColorSpace colorSpace1 = null;
        java.awt.Color color2 = java.awt.Color.RED;
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        xYPlot3.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = xYPlot3.getOrientation();
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.awt.Paint paint9 = numberAxis8.getLabelPaint();
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        double double13 = numberAxis8.valueToJava2D(0.0d, rectangle2D11, rectangleEdge12);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] { numberAxis8 };
        xYPlot3.setDomainAxes(valueAxisArray14);
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color18, stroke19);
        xYPlot16.setBackgroundPaint((java.awt.Paint) color18);
        xYPlot3.setRangeCrosshairPaint((java.awt.Paint) color18);
        float[] floatArray27 = new float[] { (byte) 1, 10L, 100.0f, 100.0f };
        float[] floatArray28 = color18.getComponents(floatArray27);
        float[] floatArray29 = color2.getRGBComponents(floatArray28);
        try {
            float[] floatArray30 = color0.getComponents(colorSpace1, floatArray28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(plotOrientation6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(valueAxisArray14);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(floatArray27);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertNotNull(floatArray29);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color2, stroke3);
        xYPlot0.setBackgroundPaint((java.awt.Paint) color2);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        xYPlot0.setRenderer(6, xYItemRenderer7);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot0.getRangeMarkers((int) ' ', layer10);
        org.jfree.chart.plot.Marker marker12 = null;
        org.jfree.chart.util.Layer layer13 = null;
        try {
            boolean boolean14 = xYPlot0.removeRangeMarker(marker12, layer13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(collection11);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=0,g=0,b=128]");
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int6 = xYPlot3.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis5);
        numberAxis5.setLowerBound((double) (short) 10);
        xYPlot0.setDomainAxis((int) (byte) 1, (org.jfree.chart.axis.ValueAxis) numberAxis5, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double12 = rectangleInsets11.getTop();
        java.lang.String str13 = rectangleInsets11.toString();
        xYPlot0.setInsets(rectangleInsets11, true);
        double double17 = rectangleInsets11.calculateBottomInset((double) (-1.0f));
        double double19 = rectangleInsets11.calculateRightOutset((double) (byte) 10);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str13.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 2.0d + "'", double17 == 2.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 4.0d + "'", double19 == 4.0d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        java.awt.Color color0 = java.awt.Color.green;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color1, stroke2);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color5, stroke6);
        categoryMarker3.setLabelPaint((java.awt.Paint) color5);
        java.awt.Font font9 = categoryMarker3.getLabelFont();
        org.jfree.chart.text.TextAnchor textAnchor10 = null;
        try {
            categoryMarker3.setLabelTextAnchor(textAnchor10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'anchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(font9);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color6, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color10, stroke11);
        categoryMarker8.setLabelPaint((java.awt.Paint) color10);
        org.jfree.chart.util.Layer layer14 = null;
        categoryPlot0.addRangeMarker((int) (short) 1, (org.jfree.chart.plot.Marker) categoryMarker8, layer14, false);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray17 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot0.setDomainAxes(categoryAxisArray17);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        int int20 = categoryPlot0.getIndexOf(categoryItemRenderer19);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = categoryPlot0.getDomainAxis(100);
        org.jfree.chart.util.SortOrder sortOrder23 = org.jfree.chart.util.SortOrder.DESCENDING;
        boolean boolean25 = sortOrder23.equals((java.lang.Object) 1);
        categoryPlot0.setRowRenderingOrder(sortOrder23);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(categoryAxisArray17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNull(categoryAxis22);
        org.junit.Assert.assertNotNull(sortOrder23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color2, stroke3);
        xYPlot0.setBackgroundPaint((java.awt.Paint) color2);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        xYPlot0.setRenderer(6, xYItemRenderer7);
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        xYPlot0.removeChangeListener(plotChangeListener9);
        java.awt.Stroke stroke11 = xYPlot0.getDomainZeroBaselineStroke();
        xYPlot0.setRangeCrosshairLockedOnData(true);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.awt.Paint paint2 = numberAxis1.getLabelPaint();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = numberAxis1.valueToJava2D(0.0d, rectangle2D4, rectangleEdge5);
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = numberAxis1.java2DToValue((double) 0L, rectangle2D8, rectangleEdge9);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double12 = rectangleInsets11.getTop();
        double double14 = rectangleInsets11.calculateBottomOutset((double) 1);
        numberAxis1.setLabelInsets(rectangleInsets11);
        numberAxis1.resizeRange((double) 100, (double) 10.0f);
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker23 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color21, stroke22);
        xYPlot19.setBackgroundPaint((java.awt.Paint) color21);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        xYPlot19.setRenderer(6, xYItemRenderer26);
        org.jfree.chart.util.Layer layer29 = null;
        java.util.Collection collection30 = xYPlot19.getRangeMarkers((int) ' ', layer29);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder31 = xYPlot19.getDatasetRenderingOrder();
        xYPlot19.setRangeZeroBaselineVisible(false);
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot19);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 2.0d + "'", double14 == 2.0d);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNull(collection30);
        org.junit.Assert.assertNotNull(datasetRenderingOrder31);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        xYPlot0.setDomainAxis(12, valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color8, stroke9);
        xYPlot6.setBackgroundPaint((java.awt.Paint) color8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        xYPlot6.setRenderer(6, xYItemRenderer13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        xYPlot6.removeChangeListener(plotChangeListener15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection18 = xYPlot6.getDomainMarkers(layer17);
        java.util.Collection collection19 = xYPlot0.getDomainMarkers(0, layer17);
        org.jfree.chart.event.PlotChangeListener plotChangeListener20 = null;
        xYPlot0.removeChangeListener(plotChangeListener20);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation22 = null;
        try {
            boolean boolean23 = xYPlot0.removeAnnotation(xYAnnotation22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertNull(collection19);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        int int0 = org.jfree.chart.axis.ValueAxis.MAXIMUM_TICK_COUNT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 500 + "'", int0 == 500);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int3 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis2);
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color6, stroke7);
        xYPlot4.setBackgroundPaint((java.awt.Paint) color6);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        xYPlot4.setRenderer(6, xYItemRenderer11);
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = xYPlot4.getRangeMarkers((int) ' ', layer14);
        boolean boolean16 = numberAxis2.hasListener((java.util.EventListener) xYPlot4);
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color18, stroke19);
        java.awt.Paint paint21 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryMarker20.setLabelPaint(paint21);
        java.awt.Font font23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryMarker20.setLabelFont(font23);
        numberAxis2.setTickLabelFont(font23);
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot();
        xYPlot26.setRangeCrosshairLockedOnData(false);
        xYPlot26.setDomainCrosshairLockedOnData(false);
        numberAxis2.setPlot((org.jfree.chart.plot.Plot) xYPlot26);
        int int32 = xYPlot26.getSeriesCount();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        java.awt.Color color0 = java.awt.Color.CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str2 = numberAxis1.getLabel();
        java.lang.String str3 = numberAxis1.getLabel();
        java.awt.Paint paint4 = numberAxis1.getAxisLinePaint();
        boolean boolean5 = numberAxis1.isTickLabelsVisible();
        numberAxis1.setAutoRange(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis1.getLabelInsets();
        double double10 = rectangleInsets8.calculateBottomOutset((double) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str2.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str3.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.0d + "'", double10 == 3.0d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str2 = numberAxis1.getLabel();
        java.lang.String str3 = numberAxis1.getLabel();
        numberAxis1.setRange((double) (-1.0f), (double) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str2.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str3.equals("TextAnchor.BASELINE_LEFT"));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color1, stroke2);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color5, stroke6);
        categoryMarker3.setLabelPaint((java.awt.Paint) color5);
        int int9 = color5.getRed();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double1 = rectangleInsets0.getTop();
        double double3 = rectangleInsets0.calculateBottomOutset((double) 1);
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = rectangleInsets0.createOutsetRectangle(rectangle2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int6 = xYPlot3.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis5);
        numberAxis5.setLowerBound((double) (short) 10);
        xYPlot0.setDomainAxis((int) (byte) 1, (org.jfree.chart.axis.ValueAxis) numberAxis5, true);
        try {
            java.awt.Paint paint12 = xYPlot0.getQuadrantPaint((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (100) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        java.util.List list7 = categoryPlot0.getCategoriesForAxis(categoryAxis6);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int11 = xYPlot8.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        java.awt.Stroke stroke12 = numberAxis10.getAxisLineStroke();
        numberAxis10.setVisible(false);
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker19 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color17, stroke18);
        xYPlot15.setBackgroundPaint((java.awt.Paint) color17);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        xYPlot15.setRenderer(6, xYItemRenderer22);
        org.jfree.chart.event.PlotChangeListener plotChangeListener24 = null;
        xYPlot15.removeChangeListener(plotChangeListener24);
        java.awt.Stroke stroke26 = xYPlot15.getDomainZeroBaselineStroke();
        numberAxis10.setTickMarkStroke(stroke26);
        categoryPlot0.setRangeCrosshairStroke(stroke26);
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation30 = null;
        try {
            boolean boolean31 = categoryPlot0.removeAnnotation(categoryAnnotation30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke26);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color2, stroke3);
        xYPlot0.setBackgroundPaint((java.awt.Paint) color2);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        xYPlot0.setRenderer(6, xYItemRenderer7);
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        xYPlot0.removeChangeListener(plotChangeListener9);
        java.awt.Stroke stroke11 = xYPlot0.getDomainGridlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        xYPlot0.zoomDomainAxes((double) 100, (double) 8, plotRenderingInfo14, point2D15);
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        int int18 = xYPlot0.indexOf(xYDataset17);
        xYPlot0.setRangeCrosshairVisible(false);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis22 = xYPlot0.getRangeAxisForDataset(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 3 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color2, stroke3);
        xYPlot0.setBackgroundPaint((java.awt.Paint) color2);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        xYPlot0.setRenderer(6, xYItemRenderer7);
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        xYPlot0.removeChangeListener(plotChangeListener9);
        org.jfree.chart.axis.ValueAxis valueAxis12 = xYPlot0.getRangeAxisForDataset((int) (short) 0);
        xYPlot0.clearDomainMarkers();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(valueAxis12);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint3 = xYPlot2.getDomainZeroBaselinePaint();
        boolean boolean4 = day0.equals((java.lang.Object) paint3);
        java.util.Date date5 = day0.getStart();
        java.util.TimeZone timeZone6 = null;
        try {
            org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date5, timeZone6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis(0);
        categoryPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor8 = null;
        try {
            categoryPlot0.setDomainGridlinePosition(categoryAnchor8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryAxis5);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        boolean boolean2 = xYPlot0.isRangeGridlinesVisible();
        java.awt.Color color5 = java.awt.Color.getColor("hi!", 0);
        xYPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint8 = xYPlot7.getDomainZeroBaselinePaint();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color10, stroke11);
        java.awt.Paint paint13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryMarker12.setLabelPaint(paint13);
        xYPlot7.setDomainZeroBaselinePaint(paint13);
        java.awt.Stroke stroke16 = xYPlot7.getDomainZeroBaselineStroke();
        xYPlot0.setParent((org.jfree.chart.plot.Plot) xYPlot7);
        xYPlot7.setRangeCrosshairVisible(false);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation20 = null;
        try {
            xYPlot7.addAnnotation(xYAnnotation20, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color2, stroke3);
        xYPlot0.setBackgroundPaint((java.awt.Paint) color2);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        xYPlot0.setRenderer(6, xYItemRenderer7);
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        xYPlot0.removeChangeListener(plotChangeListener9);
        org.jfree.chart.axis.ValueAxis valueAxis12 = xYPlot0.getRangeAxisForDataset((int) (short) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        xYPlot0.setAxisOffset(rectangleInsets13);
        java.awt.Color color16 = org.jfree.chart.ChartColor.DARK_RED;
        try {
            xYPlot0.setQuadrantPaint((int) (short) 100, (java.awt.Paint) color16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (100) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(color16);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        java.awt.Paint paint2 = xYPlot0.getDomainGridlinePaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        xYPlot2.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        xYPlot2.setRenderer((int) (byte) 1, xYItemRenderer6);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color9, stroke10);
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryMarker11.setLabelPaint(paint12);
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color16, stroke17);
        xYPlot14.setBackgroundPaint((java.awt.Paint) color16);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        xYPlot14.setRenderer(6, xYItemRenderer21);
        org.jfree.chart.event.PlotChangeListener plotChangeListener23 = null;
        xYPlot14.removeChangeListener(plotChangeListener23);
        org.jfree.chart.util.Layer layer25 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection26 = xYPlot14.getDomainMarkers(layer25);
        boolean boolean28 = layer25.equals((java.lang.Object) "SeriesRenderingOrder.FORWARD");
        boolean boolean29 = xYPlot2.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker11, layer25);
        java.util.Collection collection30 = categoryPlot0.getDomainMarkers(0, layer25);
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = categoryPlot0.getDomainAxis((int) '4');
        org.jfree.chart.axis.AxisLocation axisLocation34 = null;
        try {
            categoryPlot0.setRangeAxisLocation(axisLocation34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(layer25);
        org.junit.Assert.assertNull(collection26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNull(collection30);
        org.junit.Assert.assertNull(categoryAxis33);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int3 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis2);
        java.awt.Stroke stroke4 = numberAxis2.getAxisLineStroke();
        boolean boolean5 = numberAxis2.isNegativeArrowVisible();
        org.jfree.data.general.Dataset dataset6 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) numberAxis2, dataset6);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand8 = numberAxis2.getMarkerBand();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(markerAxisBand8);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color2, stroke3);
        xYPlot0.setBackgroundPaint((java.awt.Paint) color2);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        xYPlot0.setRenderer(6, xYItemRenderer7);
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        xYPlot0.removeChangeListener(plotChangeListener9);
        org.jfree.chart.axis.ValueAxis valueAxis12 = xYPlot0.getRangeAxisForDataset((int) (short) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        xYPlot0.setAxisOffset(rectangleInsets13);
        java.awt.Paint paint15 = xYPlot0.getDomainCrosshairPaint();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker5 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color3, stroke4);
        org.jfree.chart.util.Layer layer6 = null;
        xYPlot0.addRangeMarker(4, (org.jfree.chart.plot.Marker) categoryMarker5, layer6);
        org.jfree.data.general.Dataset dataset9 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent10 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) 100, dataset9);
        xYPlot0.datasetChanged(datasetChangeEvent10);
        org.jfree.data.general.DatasetGroup datasetGroup12 = xYPlot0.getDatasetGroup();
        int int13 = xYPlot0.getRangeAxisCount();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(datasetGroup12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot0.setDomainGridlineStroke(stroke1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        xYPlot0.zoomDomainAxes(100.0d, plotRenderingInfo4, point2D5, false);
        xYPlot0.setForegroundAlpha((float) (-1));
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color2, stroke3);
        xYPlot0.setBackgroundPaint((java.awt.Paint) color2);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        xYPlot0.setRenderer(6, xYItemRenderer7);
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        xYPlot0.removeChangeListener(plotChangeListener9);
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        xYPlot11.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = xYPlot11.getOrientation();
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.awt.Paint paint17 = numberAxis16.getLabelPaint();
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = numberAxis16.valueToJava2D(0.0d, rectangle2D19, rectangleEdge20);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray22 = new org.jfree.chart.axis.ValueAxis[] { numberAxis16 };
        xYPlot11.setDomainAxes(valueAxisArray22);
        xYPlot0.setRangeAxes(valueAxisArray22);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis26 = xYPlot0.getDomainAxisForDataset(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 10 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(valueAxisArray22);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str2 = numberAxis1.getLabel();
        numberAxis1.setVisible(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis1.setTickUnit(numberTickUnit5, false, false);
        numberAxis1.setAxisLineVisible(false);
        numberAxis1.setAutoTickUnitSelection(true);
        double double13 = numberAxis1.getFixedDimension();
        boolean boolean14 = numberAxis1.isVisible();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str2.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(numberTickUnit5);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double1 = rectangleInsets0.getTop();
        java.lang.String str2 = rectangleInsets0.toString();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D6 = rectangleInsets0.createOutsetRectangle(rectangle2D3, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str2.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str1 = xYPlot0.getNoDataMessage();
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        xYPlot0.setDataset(0, xYDataset3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot5.setDomainGridlineStroke(stroke6);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        xYPlot5.setRangeGridlineStroke(stroke8);
        xYPlot0.setOutlineStroke(stroke8);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        xYPlot0.drawAnnotations(graphics2D11, rectangle2D12, plotRenderingInfo13);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(0.0d);
        double double2 = valueMarker1.getValue();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = valueMarker1.getLabelAnchor();
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color6, stroke7);
        xYPlot4.setBackgroundPaint((java.awt.Paint) color6);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        xYPlot4.setRenderer(6, xYItemRenderer11);
        org.jfree.chart.event.PlotChangeListener plotChangeListener13 = null;
        xYPlot4.removeChangeListener(plotChangeListener13);
        java.awt.Stroke stroke15 = xYPlot4.getDomainZeroBaselineStroke();
        valueMarker1.addChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot4);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color6, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color10, stroke11);
        categoryMarker8.setLabelPaint((java.awt.Paint) color10);
        org.jfree.chart.util.Layer layer14 = null;
        categoryPlot0.addRangeMarker((int) (short) 1, (org.jfree.chart.plot.Marker) categoryMarker8, layer14, false);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray17 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot0.setDomainAxes(categoryAxisArray17);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        int int20 = categoryPlot0.getIndexOf(categoryItemRenderer19);
        categoryPlot0.setRangeGridlinesVisible(true);
        categoryPlot0.clearAnnotations();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation24 = null;
        try {
            categoryPlot0.addAnnotation(categoryAnnotation24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(categoryAxisArray17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        java.awt.Color color2 = java.awt.Color.getColor("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]", 11);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        java.awt.Color color0 = java.awt.Color.GRAY;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setAnchorValue((double) (-1L), true);
        categoryPlot1.setRangeCrosshairVisible(true);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color10, stroke11);
        org.jfree.chart.util.Layer layer13 = null;
        xYPlot7.addRangeMarker(4, (org.jfree.chart.plot.Marker) categoryMarker12, layer13);
        java.awt.Font font15 = categoryMarker12.getLabelFont();
        java.awt.Paint paint16 = categoryMarker12.getPaint();
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean18 = categoryPlot1.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker12, layer17);
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        java.util.List list20 = categoryPlot1.getCategoriesForAxis(categoryAxis19);
        boolean boolean21 = color0.equals((java.lang.Object) categoryAxis19);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor(500, 1, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Red");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_STICKY_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color2, stroke3);
        xYPlot0.setBackgroundPaint((java.awt.Paint) color2);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        xYPlot0.setRenderer(6, xYItemRenderer7);
        xYPlot0.configureRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot0.setDataset(0, xYDataset11);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color2, stroke3);
        xYPlot0.setBackgroundPaint((java.awt.Paint) color2);
        xYPlot0.setOutlineVisible(false);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        numberAxis9.setTickLabelPaint((java.awt.Paint) color10);
        xYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis9);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        xYPlot0.setDataset(xYDataset13);
        xYPlot0.clearDomainMarkers();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str2 = numberAxis1.getLabel();
        boolean boolean3 = numberAxis1.isAutoRange();
        boolean boolean4 = numberAxis1.isNegativeArrowVisible();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str7 = numberAxis6.getLabel();
        numberAxis6.setVisible(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit10 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis6.setTickUnit(numberTickUnit10, false, false);
        numberAxis6.setAxisLineVisible(false);
        numberAxis6.setAutoTickUnitSelection(true);
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint19 = xYPlot18.getDomainZeroBaselinePaint();
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker23 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color21, stroke22);
        java.awt.Paint paint24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryMarker23.setLabelPaint(paint24);
        xYPlot18.setDomainZeroBaselinePaint(paint24);
        java.awt.Stroke stroke27 = xYPlot18.getDomainZeroBaselineStroke();
        numberAxis6.setAxisLineStroke(stroke27);
        java.awt.Shape shape29 = numberAxis6.getRightArrow();
        numberAxis1.setRightArrow(shape29);
        java.awt.Graphics2D graphics2D31 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        try {
            org.jfree.chart.axis.AxisState axisState37 = numberAxis1.draw(graphics2D31, (double) 8, rectangle2D33, rectangle2D34, rectangleEdge35, plotRenderingInfo36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str2.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str7.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(numberTickUnit10);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(shape29);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        boolean boolean2 = xYPlot0.isRangeGridlinesVisible();
        java.awt.Color color5 = java.awt.Color.getColor("hi!", 0);
        xYPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color5);
        org.jfree.chart.axis.ValueAxis valueAxis7 = xYPlot0.getDomainAxis();
        org.jfree.chart.plot.Plot plot8 = xYPlot0.getParent();
        org.jfree.data.general.Dataset dataset10 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent11 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) 100, dataset10);
        xYPlot0.datasetChanged(datasetChangeEvent11);
        java.lang.Object obj13 = datasetChangeEvent11.getSource();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertTrue("'" + obj13 + "' != '" + 100 + "'", obj13.equals(100));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

//    @Test
//    public void test152() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test152");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        int int2 = day0.getDayOfMonth();
//        java.util.Calendar calendar3 = null;
//        try {
//            day0.peg(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker5 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color3, stroke4);
        org.jfree.chart.util.Layer layer6 = null;
        xYPlot0.addRangeMarker(4, (org.jfree.chart.plot.Marker) categoryMarker5, layer6);
        java.awt.Paint paint8 = null;
        categoryMarker5.setOutlinePaint(paint8);
        categoryMarker5.setDrawAsLine(true);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double1 = rectangleInsets0.getRight();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            rectangleInsets0.trim(rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.awt.Paint paint2 = numberAxis1.getLabelPaint();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = numberAxis1.valueToJava2D(0.0d, rectangle2D4, rectangleEdge5);
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = numberAxis1.java2DToValue((double) 0L, rectangle2D8, rectangleEdge9);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double12 = rectangleInsets11.getTop();
        double double14 = rectangleInsets11.calculateBottomOutset((double) 1);
        numberAxis1.setLabelInsets(rectangleInsets11);
        double double16 = rectangleInsets11.getBottom();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 2.0d + "'", double14 == 2.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 2.0d + "'", double16 == 2.0d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        xYPlot2.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        xYPlot2.setRenderer((int) (byte) 1, xYItemRenderer6);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color9, stroke10);
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryMarker11.setLabelPaint(paint12);
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color16, stroke17);
        xYPlot14.setBackgroundPaint((java.awt.Paint) color16);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        xYPlot14.setRenderer(6, xYItemRenderer21);
        org.jfree.chart.event.PlotChangeListener plotChangeListener23 = null;
        xYPlot14.removeChangeListener(plotChangeListener23);
        org.jfree.chart.util.Layer layer25 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection26 = xYPlot14.getDomainMarkers(layer25);
        boolean boolean28 = layer25.equals((java.lang.Object) "SeriesRenderingOrder.FORWARD");
        boolean boolean29 = xYPlot2.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker11, layer25);
        java.util.Collection collection30 = categoryPlot0.getDomainMarkers(0, layer25);
        java.awt.Graphics2D graphics2D31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        boolean boolean35 = categoryPlot0.render(graphics2D31, rectangle2D32, 0, plotRenderingInfo34);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(layer25);
        org.junit.Assert.assertNull(collection26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNull(collection30);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) 0L, (float) (short) 10, (float) 12);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker5 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color3, stroke4);
        org.jfree.chart.util.Layer layer6 = null;
        xYPlot0.addRangeMarker(4, (org.jfree.chart.plot.Marker) categoryMarker5, layer6);
        org.jfree.data.general.Dataset dataset9 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent10 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) 100, dataset9);
        xYPlot0.datasetChanged(datasetChangeEvent10);
        org.jfree.data.general.DatasetGroup datasetGroup12 = xYPlot0.getDatasetGroup();
        org.jfree.chart.event.PlotChangeListener plotChangeListener13 = null;
        xYPlot0.addChangeListener(plotChangeListener13);
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = numberAxis16.getLabelInsets();
        double double19 = rectangleInsets17.calculateBottomOutset((double) (-1));
        xYPlot0.setAxisOffset(rectangleInsets17);
        double double22 = rectangleInsets17.extendWidth(0.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(datasetGroup12);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 3.0d + "'", double19 == 3.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 6.0d + "'", double22 == 6.0d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str2 = numberAxis1.getLabel();
        java.lang.String str3 = numberAxis1.getLabel();
        java.awt.Paint paint4 = numberAxis1.getAxisLinePaint();
        boolean boolean5 = numberAxis1.isTickLabelsVisible();
        numberAxis1.resizeRange((double) (-1.0f), (double) 100);
        float float9 = numberAxis1.getTickMarkOutsideLength();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str2.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str3.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 2.0f + "'", float9 == 2.0f);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double1 = rectangleInsets0.getTop();
        double double3 = rectangleInsets0.calculateBottomOutset((double) 1);
        double double5 = rectangleInsets0.calculateRightInset((double) (byte) 0);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color2);
        numberAxis1.setLowerBound(0.0d);
        boolean boolean6 = numberAxis1.isPositiveArrowVisible();
        numberAxis1.setRangeAboutValue((double) 13, (double) 13);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor(100, (-1), 255);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Green");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int3 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis2);
        numberAxis2.setLowerBound((double) (short) 10);
        boolean boolean6 = numberAxis2.isTickMarksVisible();
        try {
            numberAxis2.setRangeWithMargins((double) 255, (double) (-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (255.0) <= upper (-1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_TICK_UNIT_SELECTION;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color6, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color10, stroke11);
        categoryMarker8.setLabelPaint((java.awt.Paint) color10);
        org.jfree.chart.util.Layer layer14 = null;
        categoryPlot0.addRangeMarker((int) (short) 1, (org.jfree.chart.plot.Marker) categoryMarker8, layer14, false);
        categoryPlot0.setDomainGridlinesVisible(false);
        java.awt.Stroke stroke19 = null;
        try {
            categoryPlot0.setDomainGridlineStroke(stroke19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        java.awt.Color color0 = java.awt.Color.GRAY;
        java.lang.String str1 = color0.toString();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java.awt.Color[r=128,g=128,b=128]" + "'", str1.equals("java.awt.Color[r=128,g=128,b=128]"));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation3 = xYPlot0.getOrientation();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation4 = null;
        try {
            xYPlot0.addAnnotation(xYAnnotation4, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation3);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        java.util.TimeZone timeZone0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        xYPlot0.setDataset(xYDataset3);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        xYPlot0.setRangeAxis((int) (short) 1, valueAxis6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        try {
            xYPlot0.drawBackground(graphics2D8, rectangle2D9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        xYPlot0.setRenderer((int) (byte) 1, xYItemRenderer4);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color7, stroke8);
        java.awt.Paint paint10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryMarker9.setLabelPaint(paint10);
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker16 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color14, stroke15);
        xYPlot12.setBackgroundPaint((java.awt.Paint) color14);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        xYPlot12.setRenderer(6, xYItemRenderer19);
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        xYPlot12.removeChangeListener(plotChangeListener21);
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection24 = xYPlot12.getDomainMarkers(layer23);
        boolean boolean26 = layer23.equals((java.lang.Object) "SeriesRenderingOrder.FORWARD");
        boolean boolean27 = xYPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker9, layer23);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = xYPlot0.getRenderer((int) (byte) 1);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(xYItemRenderer29);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int4 = xYPlot1.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3);
        org.jfree.chart.LegendItemCollection legendItemCollection5 = xYPlot1.getFixedLegendItems();
        boolean boolean6 = textAnchor0.equals((java.lang.Object) xYPlot1);
        xYPlot1.setRangeCrosshairValue(0.0d);
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNull(legendItemCollection5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation6 = categoryPlot0.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot0.getRangeAxis((int) '4');
        categoryPlot0.setAnchorValue((double) (-1L));
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryPlot0.setRangeCrosshairStroke(stroke11);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation13 = null;
        try {
            categoryPlot0.addAnnotation(categoryAnnotation13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int6 = xYPlot3.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis5);
        numberAxis5.setLowerBound((double) (short) 10);
        xYPlot0.setDomainAxis((int) (byte) 1, (org.jfree.chart.axis.ValueAxis) numberAxis5, true);
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker16 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color14, stroke15);
        xYPlot12.setBackgroundPaint((java.awt.Paint) color14);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        xYPlot12.setRenderer(6, xYItemRenderer19);
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        xYPlot12.removeChangeListener(plotChangeListener21);
        java.awt.Stroke stroke23 = xYPlot12.getDomainZeroBaselineStroke();
        xYPlot11.setRangeGridlineStroke(stroke23);
        xYPlot11.setRangeCrosshairVisible(true);
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint28 = xYPlot27.getDomainZeroBaselinePaint();
        boolean boolean29 = xYPlot27.isRangeGridlinesVisible();
        org.jfree.chart.axis.AxisLocation axisLocation30 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot27.setRangeAxisLocation(axisLocation30);
        xYPlot11.setDomainAxisLocation(axisLocation30, true);
        java.awt.Stroke stroke34 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot11.setOutlineStroke(stroke34);
        xYPlot0.setRangeGridlineStroke(stroke34);
        java.awt.Stroke stroke37 = xYPlot0.getDomainZeroBaselineStroke();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(axisLocation30);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(stroke37);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color2, stroke3);
        xYPlot0.setBackgroundPaint((java.awt.Paint) color2);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        xYPlot0.setRenderer(6, xYItemRenderer7);
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        xYPlot0.removeChangeListener(plotChangeListener9);
        java.awt.Stroke stroke11 = xYPlot0.getDomainGridlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        xYPlot0.zoomDomainAxes((double) 100, (double) 8, plotRenderingInfo14, point2D15);
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot0.getRangeAxisLocation();
        org.jfree.chart.axis.AxisLocation axisLocation18 = xYPlot0.getRangeAxisLocation();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(axisLocation18);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int3 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis2);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier4 = xYPlot0.getDrawingSupplier();
        int int5 = xYPlot0.getWeight();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(drawingSupplier4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation6 = categoryPlot0.getDomainAxisLocation();
        org.jfree.chart.plot.Marker marker8 = null;
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.FOREGROUND;
        try {
            boolean boolean10 = categoryPlot0.removeRangeMarker(0, marker8, layer9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(layer9);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        java.awt.Color color1 = java.awt.Color.getColor("hi!");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        boolean boolean2 = xYPlot0.isRangeGridlinesVisible();
        java.awt.Color color5 = java.awt.Color.getColor("hi!", 0);
        xYPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color5);
        org.jfree.chart.axis.ValueAxis valueAxis7 = xYPlot0.getDomainAxis();
        org.jfree.chart.plot.Plot plot8 = xYPlot0.getParent();
        org.jfree.data.general.Dataset dataset10 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent11 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) 100, dataset10);
        xYPlot0.datasetChanged(datasetChangeEvent11);
        org.jfree.data.general.Dataset dataset13 = datasetChangeEvent11.getDataset();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNull(dataset13);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int3 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis2);
        java.awt.Stroke stroke4 = numberAxis2.getAxisLineStroke();
        boolean boolean5 = numberAxis2.isNegativeArrowVisible();
        org.jfree.data.Range range6 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis2.setRangeWithMargins(range6);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit8 = numberAxis2.getTickUnit();
        boolean boolean9 = numberAxis2.isPositiveArrowVisible();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(numberTickUnit8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        java.lang.String str1 = textAnchor0.toString();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextAnchor.HALF_ASCENT_LEFT" + "'", str1.equals("TextAnchor.HALF_ASCENT_LEFT"));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int3 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis2);
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color6, stroke7);
        xYPlot4.setBackgroundPaint((java.awt.Paint) color6);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        xYPlot4.setRenderer(6, xYItemRenderer11);
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = xYPlot4.getRangeMarkers((int) ' ', layer14);
        boolean boolean16 = numberAxis2.hasListener((java.util.EventListener) xYPlot4);
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color18, stroke19);
        java.awt.Paint paint21 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryMarker20.setLabelPaint(paint21);
        java.awt.Font font23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryMarker20.setLabelFont(font23);
        numberAxis2.setTickLabelFont(font23);
        double double26 = numberAxis2.getLowerBound();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color6, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color10, stroke11);
        categoryMarker8.setLabelPaint((java.awt.Paint) color10);
        org.jfree.chart.util.Layer layer14 = null;
        categoryPlot0.addRangeMarker((int) (short) 1, (org.jfree.chart.plot.Marker) categoryMarker8, layer14, false);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray17 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot0.setDomainAxes(categoryAxisArray17);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        int int20 = categoryPlot0.getIndexOf(categoryItemRenderer19);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = categoryPlot0.getDomainAxis(100);
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.plot.CategoryMarker categoryMarker24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot();
        xYPlot27.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = null;
        xYPlot27.setRenderer((int) (byte) 1, xYItemRenderer31);
        java.awt.Color color34 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke35 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker36 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color34, stroke35);
        java.awt.Paint paint37 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryMarker36.setLabelPaint(paint37);
        org.jfree.chart.plot.XYPlot xYPlot39 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color41 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke42 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker43 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color41, stroke42);
        xYPlot39.setBackgroundPaint((java.awt.Paint) color41);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer46 = null;
        xYPlot39.setRenderer(6, xYItemRenderer46);
        org.jfree.chart.event.PlotChangeListener plotChangeListener48 = null;
        xYPlot39.removeChangeListener(plotChangeListener48);
        org.jfree.chart.util.Layer layer50 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection51 = xYPlot39.getDomainMarkers(layer50);
        boolean boolean53 = layer50.equals((java.lang.Object) "SeriesRenderingOrder.FORWARD");
        boolean boolean54 = xYPlot27.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker36, layer50);
        java.util.Collection collection55 = categoryPlot25.getDomainMarkers(0, layer50);
        try {
            categoryPlot0.addDomainMarker(categoryMarker24, layer50);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(categoryAxisArray17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNull(categoryAxis22);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(layer50);
        org.junit.Assert.assertNull(collection51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNull(collection55);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color2, stroke3);
        xYPlot0.setBackgroundPaint((java.awt.Paint) color2);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        xYPlot0.setRenderer(6, xYItemRenderer7);
        java.awt.Paint paint9 = xYPlot0.getRangeZeroBaselinePaint();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainZoomable();
        org.jfree.chart.axis.AxisSpace axisSpace2 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace2, true);
        org.jfree.chart.axis.AxisLocation axisLocation5 = null;
        try {
            categoryPlot0.setDomainAxisLocation(axisLocation5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str2 = numberAxis1.getLabel();
        numberAxis1.setAutoRange(true);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.AxisState axisState6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue((double) (-1L), true);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = categoryPlot8.getDomainAxis(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        java.util.List list15 = categoryPlot8.getCategoriesForAxis(categoryAxis14);
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int19 = xYPlot16.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis18);
        java.awt.Stroke stroke20 = numberAxis18.getAxisLineStroke();
        numberAxis18.setVisible(false);
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke26 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker27 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color25, stroke26);
        xYPlot23.setBackgroundPaint((java.awt.Paint) color25);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        xYPlot23.setRenderer(6, xYItemRenderer30);
        org.jfree.chart.event.PlotChangeListener plotChangeListener32 = null;
        xYPlot23.removeChangeListener(plotChangeListener32);
        java.awt.Stroke stroke34 = xYPlot23.getDomainZeroBaselineStroke();
        numberAxis18.setTickMarkStroke(stroke34);
        categoryPlot8.setRangeCrosshairStroke(stroke34);
        boolean boolean37 = categoryPlot8.isRangeCrosshairVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = categoryPlot8.getRangeAxisEdge(10);
        try {
            java.util.List list40 = numberAxis1.refreshTicks(graphics2D5, axisState6, rectangle2D7, rectangleEdge39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str2.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNull(categoryAxis13);
        org.junit.Assert.assertNotNull(list15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(rectangleEdge39);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        java.awt.Color color1 = java.awt.Color.getColor("java.awt.Color[r=192,g=192,b=192]");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color2, stroke3);
        xYPlot0.setBackgroundPaint((java.awt.Paint) color2);
        xYPlot0.setOutlineVisible(false);
        java.awt.Stroke stroke8 = xYPlot0.getRangeGridlineStroke();
        boolean boolean9 = xYPlot0.isRangeCrosshairLockedOnData();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        int int1 = color0.getBlue();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 128 + "'", int1 == 128);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color1, stroke2);
        categoryMarker3.setDrawAsLine(false);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.LEFT;
        categoryMarker3.setLabelAnchor(rectangleAnchor6);
        java.awt.Color color10 = java.awt.Color.getColor("hi!", 0);
        categoryMarker3.setPaint((java.awt.Paint) color10);
        int int12 = color10.getRed();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        java.awt.Paint[] paintArray0 = null;
        java.awt.Paint[] paintArray1 = null;
        java.awt.Paint[] paintArray2 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray3 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.awt.Stroke stroke4 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint6 = xYPlot5.getDomainZeroBaselinePaint();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color8, stroke9);
        java.awt.Paint paint11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryMarker10.setLabelPaint(paint11);
        xYPlot5.setDomainZeroBaselinePaint(paint11);
        java.awt.Stroke stroke14 = xYPlot5.getDomainZeroBaselineStroke();
        java.awt.Stroke stroke15 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker21 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color19, stroke20);
        xYPlot17.setBackgroundPaint((java.awt.Paint) color19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        xYPlot17.setRenderer(6, xYItemRenderer24);
        org.jfree.chart.event.PlotChangeListener plotChangeListener26 = null;
        xYPlot17.removeChangeListener(plotChangeListener26);
        java.awt.Stroke stroke28 = xYPlot17.getDomainZeroBaselineStroke();
        java.awt.Stroke[] strokeArray29 = new java.awt.Stroke[] { stroke4, stroke14, stroke15, stroke16, stroke28 };
        java.awt.Stroke[] strokeArray30 = new java.awt.Stroke[] {};
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str33 = numberAxis32.getLabel();
        java.lang.String str34 = numberAxis32.getLabel();
        java.awt.Paint paint35 = numberAxis32.getAxisLinePaint();
        java.awt.Shape shape36 = numberAxis32.getRightArrow();
        org.jfree.chart.axis.NumberAxis numberAxis38 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str39 = numberAxis38.getLabel();
        java.lang.String str40 = numberAxis38.getLabel();
        java.awt.Paint paint41 = numberAxis38.getAxisLinePaint();
        java.awt.Shape shape42 = numberAxis38.getRightArrow();
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str45 = numberAxis44.getLabel();
        java.lang.String str46 = numberAxis44.getLabel();
        java.awt.Paint paint47 = numberAxis44.getAxisLinePaint();
        java.awt.Shape shape48 = numberAxis44.getRightArrow();
        org.jfree.chart.axis.NumberAxis numberAxis50 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str51 = numberAxis50.getLabel();
        java.lang.String str52 = numberAxis50.getLabel();
        java.awt.Paint paint53 = numberAxis50.getAxisLinePaint();
        java.awt.Shape shape54 = numberAxis50.getRightArrow();
        java.awt.Shape[] shapeArray55 = new java.awt.Shape[] { shape36, shape42, shape48, shape54 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier56 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray2, paintArray3, strokeArray29, strokeArray30, shapeArray55);
        java.awt.Paint paint58 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.plot.XYPlot xYPlot59 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke60 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot59.setDomainGridlineStroke(stroke60);
        org.jfree.chart.plot.ValueMarker valueMarker62 = new org.jfree.chart.plot.ValueMarker(0.0d, paint58, stroke60);
        java.awt.Stroke[] strokeArray63 = new java.awt.Stroke[] { stroke60 };
        java.awt.Shape[] shapeArray64 = null;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier65 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, strokeArray30, strokeArray63, shapeArray64);
        java.awt.Paint paint66 = defaultDrawingSupplier65.getNextFillPaint();
        try {
            java.awt.Shape shape67 = defaultDrawingSupplier65.getNextShape();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertNotNull(paintArray3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(strokeArray29);
        org.junit.Assert.assertNotNull(strokeArray30);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str33.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str34.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str39.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str40.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str45.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str46.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(shape48);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str51.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str52.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint53);
        org.junit.Assert.assertNotNull(shape54);
        org.junit.Assert.assertNotNull(shapeArray55);
        org.junit.Assert.assertNotNull(paint58);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertNotNull(strokeArray63);
        org.junit.Assert.assertNotNull(paint66);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int3 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis2);
        java.awt.Stroke stroke4 = numberAxis2.getAxisLineStroke();
        numberAxis2.setVisible(false);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color9, stroke10);
        xYPlot7.setBackgroundPaint((java.awt.Paint) color9);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        xYPlot7.setRenderer(6, xYItemRenderer14);
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        xYPlot7.removeChangeListener(plotChangeListener16);
        java.awt.Stroke stroke18 = xYPlot7.getDomainZeroBaselineStroke();
        numberAxis2.setTickMarkStroke(stroke18);
        java.awt.Paint paint20 = numberAxis2.getAxisLinePaint();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color2, stroke3);
        xYPlot0.setBackgroundPaint((java.awt.Paint) color2);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        xYPlot0.setRenderer(6, xYItemRenderer7);
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        xYPlot0.removeChangeListener(plotChangeListener9);
        java.awt.Stroke stroke11 = xYPlot0.getDomainGridlineStroke();
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray12 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot0.setRenderers(xYItemRendererArray12);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(xYItemRendererArray12);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int3 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis2);
        java.awt.Stroke stroke4 = numberAxis2.getAxisLineStroke();
        boolean boolean5 = numberAxis2.isNegativeArrowVisible();
        org.jfree.data.Range range6 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis2.setRangeWithMargins(range6);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit8 = numberAxis2.getTickUnit();
        boolean boolean9 = numberAxis2.isAutoTickUnitSelection();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(numberTickUnit8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        double double0 = org.jfree.chart.axis.DateAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE_IN_MILLISECONDS;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.0d + "'", double0 == 2.0d);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairLockedOnData(false);
        xYPlot0.setDomainCrosshairLockedOnData(false);
        boolean boolean5 = xYPlot0.isRangeGridlinesVisible();
        java.awt.Paint paint6 = xYPlot0.getRangeGridlinePaint();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation6 = categoryPlot0.getDomainAxisLocation();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation7 = null;
        try {
            boolean boolean9 = categoryPlot0.removeAnnotation(categoryAnnotation7, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation6);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker5 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color3, stroke4);
        java.awt.Paint paint6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryMarker5.setLabelPaint(paint6);
        xYPlot0.setDomainZeroBaselinePaint(paint6);
        java.awt.Stroke stroke9 = xYPlot0.getDomainZeroBaselineStroke();
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker15 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color13, stroke14);
        org.jfree.chart.util.Layer layer16 = null;
        xYPlot10.addRangeMarker(4, (org.jfree.chart.plot.Marker) categoryMarker15, layer16);
        java.awt.Font font18 = categoryMarker15.getLabelFont();
        xYPlot0.setNoDataMessageFont(font18);
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        xYPlot0.setDataset(xYDataset20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot0.getRangeAxis((int) (byte) 10);
        boolean boolean24 = xYPlot0.isRangeZoomable();
        int int25 = xYPlot0.getWeight();
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str29 = numberAxis28.getLabel();
        numberAxis28.setVisible(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit32 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis28.setTickUnit(numberTickUnit32, false, false);
        numberAxis28.setAxisLineVisible(false);
        boolean boolean38 = numberAxis28.isVerticalTickLabels();
        numberAxis28.setLabel("DatasetRenderingOrder.REVERSE");
        xYPlot0.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis28, true);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str29.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(numberTickUnit32);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color1, stroke2);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color5, stroke6);
        categoryMarker3.setLabelPaint((java.awt.Paint) color5);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker3);
        org.jfree.chart.plot.Marker marker10 = markerChangeEvent9.getMarker();
        org.jfree.chart.plot.Marker marker11 = markerChangeEvent9.getMarker();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(marker10);
        org.junit.Assert.assertNotNull(marker11);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double1 = rectangleInsets0.getRight();
        org.jfree.chart.util.UnitType unitType2 = rectangleInsets0.getUnitType();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(unitType2);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color1, stroke2);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color5, stroke6);
        categoryMarker3.setLabelPaint((java.awt.Paint) color5);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker3);
        java.lang.String str10 = markerChangeEvent9.toString();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int3 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis2);
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color6, stroke7);
        xYPlot4.setBackgroundPaint((java.awt.Paint) color6);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        xYPlot4.setRenderer(6, xYItemRenderer11);
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = xYPlot4.getRangeMarkers((int) ' ', layer14);
        boolean boolean16 = numberAxis2.hasListener((java.util.EventListener) xYPlot4);
        java.lang.Object obj17 = numberAxis2.clone();
        boolean boolean18 = numberAxis2.isAutoTickUnitSelection();
        boolean boolean19 = numberAxis2.isAutoTickUnitSelection();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int6 = xYPlot3.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis5);
        numberAxis5.setLowerBound((double) (short) 10);
        xYPlot0.setDomainAxis((int) (byte) 1, (org.jfree.chart.axis.ValueAxis) numberAxis5, true);
        try {
            numberAxis5.setAutoRangeMinimumSize((double) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint3 = xYPlot2.getDomainZeroBaselinePaint();
        boolean boolean4 = day0.equals((java.lang.Object) paint3);
        java.util.Date date5 = day0.getStart();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = day0.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color2, stroke3);
        xYPlot0.setBackgroundPaint((java.awt.Paint) color2);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        xYPlot0.setRenderer(6, xYItemRenderer7);
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        xYPlot0.removeChangeListener(plotChangeListener9);
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        xYPlot11.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = xYPlot11.getOrientation();
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.awt.Paint paint17 = numberAxis16.getLabelPaint();
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = numberAxis16.valueToJava2D(0.0d, rectangle2D19, rectangleEdge20);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray22 = new org.jfree.chart.axis.ValueAxis[] { numberAxis16 };
        xYPlot11.setDomainAxes(valueAxisArray22);
        xYPlot0.setRangeAxes(valueAxisArray22);
        org.jfree.chart.LegendItemCollection legendItemCollection25 = xYPlot0.getLegendItems();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(valueAxisArray22);
        org.junit.Assert.assertNotNull(legendItemCollection25);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABELS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        java.util.List list7 = categoryPlot0.getCategoriesForAxis(categoryAxis6);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int11 = xYPlot8.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        java.awt.Stroke stroke12 = numberAxis10.getAxisLineStroke();
        numberAxis10.setVisible(false);
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker19 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color17, stroke18);
        xYPlot15.setBackgroundPaint((java.awt.Paint) color17);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        xYPlot15.setRenderer(6, xYItemRenderer22);
        org.jfree.chart.event.PlotChangeListener plotChangeListener24 = null;
        xYPlot15.removeChangeListener(plotChangeListener24);
        java.awt.Stroke stroke26 = xYPlot15.getDomainZeroBaselineStroke();
        numberAxis10.setTickMarkStroke(stroke26);
        categoryPlot0.setRangeCrosshairStroke(stroke26);
        boolean boolean29 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation30 = null;
        try {
            categoryPlot0.addAnnotation(categoryAnnotation30, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color2, stroke3);
        xYPlot0.setBackgroundPaint((java.awt.Paint) color2);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        xYPlot0.setRenderer(6, xYItemRenderer7);
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        xYPlot0.removeChangeListener(plotChangeListener9);
        org.jfree.chart.axis.ValueAxis valueAxis12 = xYPlot0.getRangeAxisForDataset((int) (short) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        xYPlot0.setAxisOffset(rectangleInsets13);
        java.awt.Color color15 = java.awt.Color.blue;
        xYPlot0.setOutlinePaint((java.awt.Paint) color15);
        java.awt.color.ColorSpace colorSpace17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        xYPlot18.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation21 = xYPlot18.getOrientation();
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.awt.Paint paint24 = numberAxis23.getLabelPaint();
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = null;
        double double28 = numberAxis23.valueToJava2D(0.0d, rectangle2D26, rectangleEdge27);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray29 = new org.jfree.chart.axis.ValueAxis[] { numberAxis23 };
        xYPlot18.setDomainAxes(valueAxisArray29);
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke34 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker35 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color33, stroke34);
        xYPlot31.setBackgroundPaint((java.awt.Paint) color33);
        xYPlot18.setRangeCrosshairPaint((java.awt.Paint) color33);
        float[] floatArray42 = new float[] { (byte) 1, 10L, 100.0f, 100.0f };
        float[] floatArray43 = color33.getComponents(floatArray42);
        try {
            float[] floatArray44 = color15.getColorComponents(colorSpace17, floatArray43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(plotOrientation21);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(valueAxisArray29);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(floatArray42);
        org.junit.Assert.assertNotNull(floatArray43);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        java.awt.Color color3 = java.awt.Color.getHSBColor(0.0f, 100.0f, (float) ' ');
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        int int1 = color0.getRGB();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-16744448) + "'", int1 == (-16744448));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.lang.String str1 = rectangleAnchor0.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleAnchor.BOTTOM" + "'", str1.equals("RectangleAnchor.BOTTOM"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        java.awt.Color color2 = java.awt.Color.getColor("", (int) (byte) 100);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        java.util.List list7 = categoryPlot0.getCategoriesForAxis(categoryAxis6);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int11 = xYPlot8.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        java.awt.Stroke stroke12 = numberAxis10.getAxisLineStroke();
        numberAxis10.setVisible(false);
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker19 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color17, stroke18);
        xYPlot15.setBackgroundPaint((java.awt.Paint) color17);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        xYPlot15.setRenderer(6, xYItemRenderer22);
        org.jfree.chart.event.PlotChangeListener plotChangeListener24 = null;
        xYPlot15.removeChangeListener(plotChangeListener24);
        java.awt.Stroke stroke26 = xYPlot15.getDomainZeroBaselineStroke();
        numberAxis10.setTickMarkStroke(stroke26);
        categoryPlot0.setRangeCrosshairStroke(stroke26);
        java.awt.Stroke stroke29 = categoryPlot0.getDomainGridlineStroke();
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(stroke29);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color6, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color10, stroke11);
        categoryMarker8.setLabelPaint((java.awt.Paint) color10);
        org.jfree.chart.util.Layer layer14 = null;
        categoryPlot0.addRangeMarker((int) (short) 1, (org.jfree.chart.plot.Marker) categoryMarker8, layer14, false);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray17 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot0.setDomainAxes(categoryAxisArray17);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        int int20 = categoryPlot0.getIndexOf(categoryItemRenderer19);
        categoryPlot0.setRangeGridlinesVisible(true);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        try {
            int int24 = categoryPlot0.getDomainAxisIndex(categoryAxis23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(categoryAxisArray17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int3 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis2);
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color6, stroke7);
        xYPlot4.setBackgroundPaint((java.awt.Paint) color6);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        xYPlot4.setRenderer(6, xYItemRenderer11);
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = xYPlot4.getRangeMarkers((int) ' ', layer14);
        boolean boolean16 = numberAxis2.hasListener((java.util.EventListener) xYPlot4);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray17 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot4.setRenderers(xYItemRendererArray17);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(xYItemRendererArray17);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_VERTICAL_TICK_LABELS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        xYPlot0.setDomainAxis(12, valueAxis3);
        boolean boolean5 = xYPlot0.isRangeZoomable();
        double double6 = xYPlot0.getDomainCrosshairValue();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double1 = rectangleInsets0.getTop();
        java.lang.String str2 = rectangleInsets0.toString();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            rectangleInsets0.trim(rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str2.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = numberAxis1.getLabelInsets();
        boolean boolean3 = numberAxis1.isNegativeArrowVisible();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int3 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis2);
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color6, stroke7);
        xYPlot4.setBackgroundPaint((java.awt.Paint) color6);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        xYPlot4.setRenderer(6, xYItemRenderer11);
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = xYPlot4.getRangeMarkers((int) ' ', layer14);
        boolean boolean16 = numberAxis2.hasListener((java.util.EventListener) xYPlot4);
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color18, stroke19);
        java.awt.Paint paint21 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryMarker20.setLabelPaint(paint21);
        java.awt.Font font23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryMarker20.setLabelFont(font23);
        numberAxis2.setTickLabelFont(font23);
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot();
        xYPlot26.setRangeCrosshairLockedOnData(false);
        xYPlot26.setDomainCrosshairLockedOnData(false);
        numberAxis2.setPlot((org.jfree.chart.plot.Plot) xYPlot26);
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot34.setAnchorValue((double) (-1L), true);
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = categoryPlot34.getDomainAxis(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = null;
        java.util.List list41 = categoryPlot34.getCategoriesForAxis(categoryAxis40);
        org.jfree.chart.plot.XYPlot xYPlot42 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int45 = xYPlot42.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis44);
        java.awt.Stroke stroke46 = numberAxis44.getAxisLineStroke();
        numberAxis44.setVisible(false);
        org.jfree.chart.plot.XYPlot xYPlot49 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color51 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke52 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker53 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color51, stroke52);
        xYPlot49.setBackgroundPaint((java.awt.Paint) color51);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer56 = null;
        xYPlot49.setRenderer(6, xYItemRenderer56);
        org.jfree.chart.event.PlotChangeListener plotChangeListener58 = null;
        xYPlot49.removeChangeListener(plotChangeListener58);
        java.awt.Stroke stroke60 = xYPlot49.getDomainZeroBaselineStroke();
        numberAxis44.setTickMarkStroke(stroke60);
        categoryPlot34.setRangeCrosshairStroke(stroke60);
        boolean boolean63 = categoryPlot34.isRangeCrosshairVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge65 = categoryPlot34.getRangeAxisEdge(10);
        try {
            double double66 = numberAxis2.lengthToJava2D((double) (short) 10, rectangle2D33, rectangleEdge65);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNull(categoryAxis39);
        org.junit.Assert.assertNotNull(list41);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(rectangleEdge65);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        java.awt.Color color1 = java.awt.Color.getColor("");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker5 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color3, stroke4);
        java.awt.Paint paint6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryMarker5.setLabelPaint(paint6);
        xYPlot0.setDomainZeroBaselinePaint(paint6);
        java.awt.Stroke stroke9 = xYPlot0.getDomainZeroBaselineStroke();
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker15 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color13, stroke14);
        org.jfree.chart.util.Layer layer16 = null;
        xYPlot10.addRangeMarker(4, (org.jfree.chart.plot.Marker) categoryMarker15, layer16);
        java.awt.Font font18 = categoryMarker15.getLabelFont();
        xYPlot0.setNoDataMessageFont(font18);
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        xYPlot0.setDataset(xYDataset20);
        java.awt.Paint paint22 = xYPlot0.getDomainGridlinePaint();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        xYPlot0.setRenderer(0, xYItemRenderer24);
        xYPlot0.setBackgroundImageAlpha((float) 1);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color2, stroke3);
        xYPlot0.setBackgroundPaint((java.awt.Paint) color2);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str9 = numberAxis8.getLabel();
        numberAxis8.setVisible(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis8.setTickUnit(numberTickUnit12, false, false);
        numberAxis8.setAxisLineVisible(false);
        numberAxis8.setAutoTickUnitSelection(true);
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint21 = xYPlot20.getDomainZeroBaselinePaint();
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker25 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color23, stroke24);
        java.awt.Paint paint26 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryMarker25.setLabelPaint(paint26);
        xYPlot20.setDomainZeroBaselinePaint(paint26);
        java.awt.Stroke stroke29 = xYPlot20.getDomainZeroBaselineStroke();
        numberAxis8.setAxisLineStroke(stroke29);
        xYPlot0.setRangeAxis((int) (short) 0, (org.jfree.chart.axis.ValueAxis) numberAxis8);
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str34 = numberAxis33.getLabel();
        java.lang.String str35 = numberAxis33.getLabel();
        java.awt.Paint paint36 = numberAxis33.getAxisLinePaint();
        numberAxis8.setLabelPaint(paint36);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str9.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str34.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str35.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint36);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        boolean boolean2 = xYPlot0.isRangeGridlinesVisible();
        java.awt.Color color5 = java.awt.Color.getColor("hi!", 0);
        xYPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color5);
        java.lang.Object obj7 = xYPlot0.clone();
        java.awt.Paint paint8 = xYPlot0.getDomainTickBandPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = xYPlot0.getRangeAxisEdge((int) 'a');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        int int12 = xYPlot0.getIndexOf(xYItemRenderer11);
        java.awt.Image image13 = null;
        xYPlot0.setBackgroundImage(image13);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(0.0d);
        double double2 = valueMarker1.getValue();
        java.awt.Paint paint4 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot5.setDomainGridlineStroke(stroke6);
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, paint4, stroke6);
        java.awt.Font font9 = valueMarker8.getLabelFont();
        valueMarker1.setLabelFont(font9);
        double double11 = valueMarker1.getValue();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color1, stroke2);
        java.awt.Paint paint4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryMarker3.setLabelPaint(paint4);
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryMarker3.setLabelFont(font6);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str10 = numberAxis9.getLabel();
        java.lang.String str11 = numberAxis9.getLabel();
        java.awt.Paint paint12 = numberAxis9.getAxisLinePaint();
        categoryMarker3.setLabelPaint(paint12);
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color16, stroke17);
        xYPlot14.setBackgroundPaint((java.awt.Paint) color16);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        xYPlot14.setRenderer(6, xYItemRenderer21);
        org.jfree.chart.event.PlotChangeListener plotChangeListener23 = null;
        xYPlot14.removeChangeListener(plotChangeListener23);
        java.awt.Paint paint25 = xYPlot14.getRangeTickBandPaint();
        categoryMarker3.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot14);
        xYPlot14.setRangeCrosshairVisible(true);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str10.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str11.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNull(paint25);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color2, stroke3);
        xYPlot0.setBackgroundPaint((java.awt.Paint) color2);
        xYPlot0.setOutlineVisible(false);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color11, stroke12);
        org.jfree.chart.util.Layer layer14 = null;
        xYPlot8.addRangeMarker(4, (org.jfree.chart.plot.Marker) categoryMarker13, layer14);
        java.awt.Color color16 = java.awt.Color.BLACK;
        categoryMarker13.setPaint((java.awt.Paint) color16);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent18 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker13);
        java.lang.String str19 = categoryMarker13.getLabel();
        java.awt.Paint paint20 = categoryMarker13.getOutlinePaint();
        xYPlot0.setRangeGridlinePaint(paint20);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_LOWER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int3 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis2);
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color6, stroke7);
        xYPlot4.setBackgroundPaint((java.awt.Paint) color6);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        xYPlot4.setRenderer(6, xYItemRenderer11);
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = xYPlot4.getRangeMarkers((int) ' ', layer14);
        boolean boolean16 = numberAxis2.hasListener((java.util.EventListener) xYPlot4);
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color18, stroke19);
        java.awt.Paint paint21 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryMarker20.setLabelPaint(paint21);
        java.awt.Font font23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryMarker20.setLabelFont(font23);
        numberAxis2.setTickLabelFont(font23);
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot();
        xYPlot26.setRangeCrosshairLockedOnData(false);
        xYPlot26.setDomainCrosshairLockedOnData(false);
        numberAxis2.setPlot((org.jfree.chart.plot.Plot) xYPlot26);
        java.util.EventListener eventListener32 = null;
        boolean boolean33 = numberAxis2.hasListener(eventListener32);
        numberAxis2.setTickMarkOutsideLength((float) 6);
        org.jfree.chart.plot.Plot plot36 = null;
        numberAxis2.setPlot(plot36);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color2, stroke3);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color6, stroke7);
        categoryMarker4.setLabelPaint((java.awt.Paint) color6);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        categoryMarker4.setLabelAnchor(rectangleAnchor10);
        try {
            java.awt.geom.Point2D point2D12 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rectangleAnchor10);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int3 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis2);
        double double4 = numberAxis2.getFixedAutoRange();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis2.setTickUnit(numberTickUnit5);
        double double7 = numberAxis2.getAutoRangeMinimumSize();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(numberTickUnit5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0E-8d + "'", double7 == 1.0E-8d);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D2 = rectangleInsets0.createOutsetRectangle(rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color2, stroke3);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Stroke stroke7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 128, (java.awt.Paint) color2, stroke5, (java.awt.Paint) color6, stroke7, 0.0f);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        numberAxis1.centerRange((double) 9);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int3 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis2);
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color6, stroke7);
        xYPlot4.setBackgroundPaint((java.awt.Paint) color6);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        xYPlot4.setRenderer(6, xYItemRenderer11);
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = xYPlot4.getRangeMarkers((int) ' ', layer14);
        boolean boolean16 = numberAxis2.hasListener((java.util.EventListener) xYPlot4);
        java.lang.Object obj17 = numberAxis2.clone();
        boolean boolean18 = numberAxis2.isAutoRange();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color2);
        boolean boolean4 = numberAxis1.isAxisLineVisible();
        double double5 = numberAxis1.getFixedAutoRange();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation6 = categoryPlot0.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot0.getRangeAxis((int) '4');
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.axis.AxisLocation axisLocation11 = categoryPlot0.getRangeAxisLocation(100);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(axisLocation11);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double1 = rectangleInsets0.getTop();
        java.lang.String str2 = rectangleInsets0.toString();
        double double3 = rectangleInsets0.getLeft();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str2.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.ASCENDING;
        org.junit.Assert.assertNotNull(sortOrder0);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str2 = numberAxis1.getLabel();
        java.lang.String str3 = numberAxis1.getLabel();
        java.awt.Paint paint4 = numberAxis1.getAxisLinePaint();
        numberAxis1.configure();
        boolean boolean6 = numberAxis1.isTickMarksVisible();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str2.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str3.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int3 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis2);
        java.awt.Stroke stroke4 = numberAxis2.getAxisLineStroke();
        numberAxis2.setVisible(false);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color9, stroke10);
        xYPlot7.setBackgroundPaint((java.awt.Paint) color9);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        xYPlot7.setRenderer(6, xYItemRenderer14);
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        xYPlot7.removeChangeListener(plotChangeListener16);
        java.awt.Stroke stroke18 = xYPlot7.getDomainZeroBaselineStroke();
        numberAxis2.setTickMarkStroke(stroke18);
        numberAxis2.setLabelToolTip("UnitType.RELATIVE");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = numberAxis1.getLabelInsets();
        java.awt.Font font3 = numberAxis1.getLabelFont();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(font3);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int3 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis2);
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color6, stroke7);
        xYPlot4.setBackgroundPaint((java.awt.Paint) color6);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        xYPlot4.setRenderer(6, xYItemRenderer11);
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = xYPlot4.getRangeMarkers((int) ' ', layer14);
        boolean boolean16 = numberAxis2.hasListener((java.util.EventListener) xYPlot4);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent17 = null;
        xYPlot4.notifyListeners(plotChangeEvent17);
        java.lang.String str19 = xYPlot4.getNoDataMessage();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(str19);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 0L, 0.0d, (double) 6, (double) (-1L));
        double double6 = rectangleInsets4.trimWidth((double) 9);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 10.0d + "'", double6 == 10.0d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        int int3 = java.awt.Color.HSBtoRGB(0.0f, (float) 10L, (float) (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16056329) + "'", int3 == (-16056329));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker5 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color3, stroke4);
        xYPlot1.setBackgroundPaint((java.awt.Paint) color3);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        xYPlot1.setRenderer(6, xYItemRenderer8);
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        xYPlot1.removeChangeListener(plotChangeListener10);
        java.awt.Stroke stroke12 = xYPlot1.getDomainZeroBaselineStroke();
        xYPlot0.setRangeGridlineStroke(stroke12);
        xYPlot0.configureDomainAxes();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str1 = xYPlot0.getNoDataMessage();
        xYPlot0.configureRangeAxes();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation3 = null;
        try {
            xYPlot0.addAnnotation(xYAnnotation3, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        java.awt.Color color0 = java.awt.Color.LIGHT_GRAY;
        java.lang.String str1 = color0.toString();
        int int2 = color0.getBlue();
        java.awt.color.ColorSpace colorSpace3 = null;
        float[] floatArray4 = null;
        try {
            float[] floatArray5 = color0.getColorComponents(colorSpace3, floatArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java.awt.Color[r=192,g=192,b=192]" + "'", str1.equals("java.awt.Color[r=192,g=192,b=192]"));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 192 + "'", int2 == 192);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str2 = numberAxis1.getLabel();
        java.lang.String str3 = numberAxis1.getLabel();
        try {
            numberAxis1.setAutoRangeMinimumSize((double) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str2.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str3.equals("TextAnchor.BASELINE_LEFT"));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int3 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis2);
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color6, stroke7);
        xYPlot4.setBackgroundPaint((java.awt.Paint) color6);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        xYPlot4.setRenderer(6, xYItemRenderer11);
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = xYPlot4.getRangeMarkers((int) ' ', layer14);
        boolean boolean16 = numberAxis2.hasListener((java.util.EventListener) xYPlot4);
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color18, stroke19);
        java.awt.Paint paint21 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryMarker20.setLabelPaint(paint21);
        java.awt.Font font23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryMarker20.setLabelFont(font23);
        numberAxis2.setTickLabelFont(font23);
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot();
        xYPlot26.setRangeCrosshairLockedOnData(false);
        xYPlot26.setDomainCrosshairLockedOnData(false);
        numberAxis2.setPlot((org.jfree.chart.plot.Plot) xYPlot26);
        numberAxis2.setAutoRangeMinimumSize((double) 2);
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint37 = xYPlot36.getDomainZeroBaselinePaint();
        boolean boolean38 = xYPlot36.isRangeGridlinesVisible();
        java.awt.Color color41 = java.awt.Color.getColor("hi!", 0);
        xYPlot36.setRangeZeroBaselinePaint((java.awt.Paint) color41);
        java.lang.Object obj43 = xYPlot36.clone();
        java.awt.Paint paint44 = xYPlot36.getDomainTickBandPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = xYPlot36.getRangeAxisEdge((int) 'a');
        try {
            double double47 = numberAxis2.valueToJava2D(0.0d, rectangle2D35, rectangleEdge46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(obj43);
        org.junit.Assert.assertNull(paint44);
        org.junit.Assert.assertNotNull(rectangleEdge46);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color2, stroke3);
        xYPlot0.setBackgroundPaint((java.awt.Paint) color2);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str9 = numberAxis8.getLabel();
        numberAxis8.setVisible(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis8.setTickUnit(numberTickUnit12, false, false);
        numberAxis8.setAxisLineVisible(false);
        numberAxis8.setAutoTickUnitSelection(true);
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint21 = xYPlot20.getDomainZeroBaselinePaint();
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker25 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color23, stroke24);
        java.awt.Paint paint26 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryMarker25.setLabelPaint(paint26);
        xYPlot20.setDomainZeroBaselinePaint(paint26);
        java.awt.Stroke stroke29 = xYPlot20.getDomainZeroBaselineStroke();
        numberAxis8.setAxisLineStroke(stroke29);
        xYPlot0.setRangeAxis((int) (short) 0, (org.jfree.chart.axis.ValueAxis) numberAxis8);
        java.awt.Color color32 = java.awt.Color.PINK;
        xYPlot0.setDomainZeroBaselinePaint((java.awt.Paint) color32);
        java.awt.Graphics2D graphics2D34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        try {
            xYPlot0.drawBackground(graphics2D34, rectangle2D35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str9.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(color32);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color2, stroke3);
        xYPlot0.setBackgroundPaint((java.awt.Paint) color2);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        xYPlot0.setRenderer(6, xYItemRenderer7);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot0.getRangeMarkers((int) ' ', layer10);
        boolean boolean12 = xYPlot0.isDomainZoomable();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        java.util.List list7 = categoryPlot0.getCategoriesForAxis(categoryAxis6);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int11 = xYPlot8.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        java.awt.Stroke stroke12 = numberAxis10.getAxisLineStroke();
        numberAxis10.setVisible(false);
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker19 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color17, stroke18);
        xYPlot15.setBackgroundPaint((java.awt.Paint) color17);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        xYPlot15.setRenderer(6, xYItemRenderer22);
        org.jfree.chart.event.PlotChangeListener plotChangeListener24 = null;
        xYPlot15.removeChangeListener(plotChangeListener24);
        java.awt.Stroke stroke26 = xYPlot15.getDomainZeroBaselineStroke();
        numberAxis10.setTickMarkStroke(stroke26);
        categoryPlot0.setRangeCrosshairStroke(stroke26);
        org.jfree.chart.axis.AxisSpace axisSpace29 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace29);
        java.util.List list31 = categoryPlot0.getAnnotations();
        org.jfree.chart.plot.CategoryMarker categoryMarker32 = null;
        try {
            categoryPlot0.addDomainMarker(categoryMarker32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(list31);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color6, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color10, stroke11);
        categoryMarker8.setLabelPaint((java.awt.Paint) color10);
        org.jfree.chart.util.Layer layer14 = null;
        categoryPlot0.addRangeMarker((int) (short) 1, (org.jfree.chart.plot.Marker) categoryMarker8, layer14, false);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray17 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot0.setDomainAxes(categoryAxisArray17);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        int int20 = categoryPlot0.getIndexOf(categoryItemRenderer19);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = categoryPlot0.getDomainAxis(100);
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = categoryPlot0.getRendererForDataset(categoryDataset23);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(categoryAxisArray17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNull(categoryAxis22);
        org.junit.Assert.assertNull(categoryItemRenderer24);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str2 = numberAxis1.getLabel();
        java.lang.String str3 = numberAxis1.getLabel();
        boolean boolean4 = numberAxis1.getAutoRangeIncludesZero();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str2.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str3.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

//    @Test
//    public void test267() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test267");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        int int2 = day0.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.next();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = day0.getFirstMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        xYPlot0.zoomRangeAxes(0.0d, plotRenderingInfo4, point2D5, true);
        java.awt.Paint paint8 = null;
        try {
            xYPlot0.setRangeZeroBaselinePaint(paint8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str1 = xYPlot0.getNoDataMessage();
        xYPlot0.configureRangeAxes();
        xYPlot0.clearRangeAxes();
        java.awt.Paint paint4 = xYPlot0.getDomainZeroBaselinePaint();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int3 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        xYPlot0.setRangeCrosshairPaint((java.awt.Paint) color4);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int10 = xYPlot7.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis9);
        java.awt.Stroke stroke11 = numberAxis9.getAxisLineStroke();
        boolean boolean12 = numberAxis9.isNegativeArrowVisible();
        xYPlot0.setDomainAxis((int) (short) 10, (org.jfree.chart.axis.ValueAxis) numberAxis9, true);
        float float15 = xYPlot0.getForegroundAlpha();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 1.0f + "'", float15 == 1.0f);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = categoryPlot0.getDomainAxis();
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = null;
        try {
            categoryPlot0.addDomainMarker(categoryMarker3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(categoryAxis2);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str2 = numberAxis1.getLabel();
        numberAxis1.setAutoRange(true);
        org.jfree.chart.JFreeChart jFreeChart5 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType6 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        java.lang.String str7 = chartChangeEventType6.toString();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) numberAxis1, jFreeChart5, chartChangeEventType6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str2.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(chartChangeEventType6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str7.equals("ChartChangeEventType.DATASET_UPDATED"));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int5 = xYPlot2.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis4);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color8, stroke9);
        xYPlot6.setBackgroundPaint((java.awt.Paint) color8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        xYPlot6.setRenderer(6, xYItemRenderer13);
        org.jfree.chart.util.Layer layer16 = null;
        java.util.Collection collection17 = xYPlot6.getRangeMarkers((int) ' ', layer16);
        boolean boolean18 = numberAxis4.hasListener((java.util.EventListener) xYPlot6);
        java.lang.Object obj19 = numberAxis4.clone();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis4, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        java.lang.String str23 = sortOrder22.toString();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNull(collection17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "SortOrder.ASCENDING" + "'", str23.equals("SortOrder.ASCENDING"));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str1 = xYPlot0.getNoDataMessage();
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        xYPlot0.setDataset(0, xYDataset3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot5.setDomainGridlineStroke(stroke6);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        xYPlot5.setRangeGridlineStroke(stroke8);
        xYPlot0.setOutlineStroke(stroke8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = xYPlot0.getRenderer(2);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder13 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        xYPlot0.setSeriesRenderingOrder(seriesRenderingOrder13);
        java.awt.Paint paint15 = null;
        try {
            xYPlot0.setRangeGridlinePaint(paint15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(xYItemRenderer12);
        org.junit.Assert.assertNotNull(seriesRenderingOrder13);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color9, stroke10);
        org.jfree.chart.util.Layer layer12 = null;
        xYPlot6.addRangeMarker(4, (org.jfree.chart.plot.Marker) categoryMarker11, layer12);
        java.awt.Font font14 = categoryMarker11.getLabelFont();
        java.awt.Paint paint15 = categoryMarker11.getPaint();
        org.jfree.chart.util.Layer layer16 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean17 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker11, layer16);
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str21 = numberAxis20.getLabel();
        java.lang.String str22 = numberAxis20.getLabel();
        java.awt.Paint paint23 = numberAxis20.getAxisLinePaint();
        boolean boolean24 = numberAxis20.isTickLabelsVisible();
        numberAxis20.setAutoRange(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = numberAxis20.getLabelInsets();
        java.awt.Stroke stroke28 = numberAxis20.getAxisLineStroke();
        int int29 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis20);
        java.awt.Stroke stroke30 = categoryPlot0.getRangeGridlineStroke();
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke33 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker34 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color32, stroke33);
        java.awt.Paint paint35 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryMarker34.setLabelPaint(paint35);
        org.jfree.chart.axis.NumberAxis numberAxis38 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.awt.Color color39 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        numberAxis38.setTickLabelPaint((java.awt.Paint) color39);
        java.lang.String str41 = color39.toString();
        categoryMarker34.setOutlinePaint((java.awt.Paint) color39);
        boolean boolean43 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker34);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(layer16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str21.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str22.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "java.awt.Color[r=0,g=0,b=128]" + "'", str41.equals("java.awt.Color[r=0,g=0,b=128]"));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        java.awt.Color color5 = java.awt.Color.RED;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        xYPlot6.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation9 = xYPlot6.getOrientation();
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.awt.Paint paint12 = numberAxis11.getLabelPaint();
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        double double16 = numberAxis11.valueToJava2D(0.0d, rectangle2D14, rectangleEdge15);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray17 = new org.jfree.chart.axis.ValueAxis[] { numberAxis11 };
        xYPlot6.setDomainAxes(valueAxisArray17);
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker23 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color21, stroke22);
        xYPlot19.setBackgroundPaint((java.awt.Paint) color21);
        xYPlot6.setRangeCrosshairPaint((java.awt.Paint) color21);
        float[] floatArray30 = new float[] { (byte) 1, 10L, 100.0f, 100.0f };
        float[] floatArray31 = color21.getComponents(floatArray30);
        float[] floatArray32 = color5.getRGBComponents(floatArray31);
        float[] floatArray33 = java.awt.Color.RGBtoHSB((int) (byte) 1, (int) (byte) 1, 0, floatArray32);
        float[] floatArray34 = color1.getRGBComponents(floatArray32);
        float[] floatArray35 = color0.getColorComponents(floatArray32);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(plotOrientation9);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(valueAxisArray17);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertNotNull(floatArray35);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        java.awt.Color color0 = java.awt.Color.YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        java.util.List list7 = categoryPlot0.getCategoriesForAxis(categoryAxis6);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int11 = xYPlot8.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        java.awt.Stroke stroke12 = numberAxis10.getAxisLineStroke();
        numberAxis10.setVisible(false);
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker19 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color17, stroke18);
        xYPlot15.setBackgroundPaint((java.awt.Paint) color17);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        xYPlot15.setRenderer(6, xYItemRenderer22);
        org.jfree.chart.event.PlotChangeListener plotChangeListener24 = null;
        xYPlot15.removeChangeListener(plotChangeListener24);
        java.awt.Stroke stroke26 = xYPlot15.getDomainZeroBaselineStroke();
        numberAxis10.setTickMarkStroke(stroke26);
        categoryPlot0.setRangeCrosshairStroke(stroke26);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        java.awt.geom.Point2D point2D31 = null;
        categoryPlot0.zoomDomainAxes(0.0d, plotRenderingInfo30, point2D31, false);
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str36 = numberAxis35.getLabel();
        boolean boolean37 = numberAxis35.isAutoRange();
        boolean boolean38 = numberAxis35.isNegativeArrowVisible();
        org.jfree.chart.axis.NumberAxis numberAxis40 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str41 = numberAxis40.getLabel();
        numberAxis40.setVisible(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit44 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis40.setTickUnit(numberTickUnit44, false, false);
        numberAxis40.setAxisLineVisible(false);
        numberAxis40.setAutoTickUnitSelection(true);
        org.jfree.chart.plot.XYPlot xYPlot52 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint53 = xYPlot52.getDomainZeroBaselinePaint();
        java.awt.Color color55 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke56 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker57 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color55, stroke56);
        java.awt.Paint paint58 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryMarker57.setLabelPaint(paint58);
        xYPlot52.setDomainZeroBaselinePaint(paint58);
        java.awt.Stroke stroke61 = xYPlot52.getDomainZeroBaselineStroke();
        numberAxis40.setAxisLineStroke(stroke61);
        java.awt.Shape shape63 = numberAxis40.getRightArrow();
        numberAxis35.setRightArrow(shape63);
        int int65 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis35);
        org.jfree.chart.axis.CategoryAxis categoryAxis67 = null;
        categoryPlot0.setDomainAxis((int) ' ', categoryAxis67);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str36.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str41.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(numberTickUnit44);
        org.junit.Assert.assertNotNull(paint53);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertNotNull(paint58);
        org.junit.Assert.assertNotNull(stroke61);
        org.junit.Assert.assertNotNull(shape63);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-1) + "'", int65 == (-1));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int6 = xYPlot3.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis5);
        numberAxis5.setLowerBound((double) (short) 10);
        xYPlot0.setDomainAxis((int) (byte) 1, (org.jfree.chart.axis.ValueAxis) numberAxis5, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double12 = rectangleInsets11.getTop();
        java.lang.String str13 = rectangleInsets11.toString();
        xYPlot0.setInsets(rectangleInsets11, true);
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D19 = rectangleInsets11.createInsetRectangle(rectangle2D16, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str13.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation6 = categoryPlot0.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot0.getRangeAxis((int) '4');
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.plot.Marker marker10 = null;
        try {
            categoryPlot0.addRangeMarker(marker10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertNotNull(axisLocation9);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        java.util.List list7 = categoryPlot0.getCategoriesForAxis(categoryAxis6);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int11 = xYPlot8.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        java.awt.Stroke stroke12 = numberAxis10.getAxisLineStroke();
        numberAxis10.setVisible(false);
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker19 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color17, stroke18);
        xYPlot15.setBackgroundPaint((java.awt.Paint) color17);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        xYPlot15.setRenderer(6, xYItemRenderer22);
        org.jfree.chart.event.PlotChangeListener plotChangeListener24 = null;
        xYPlot15.removeChangeListener(plotChangeListener24);
        java.awt.Stroke stroke26 = xYPlot15.getDomainZeroBaselineStroke();
        numberAxis10.setTickMarkStroke(stroke26);
        categoryPlot0.setRangeCrosshairStroke(stroke26);
        org.jfree.chart.axis.AxisSpace axisSpace29 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace29);
        org.jfree.chart.axis.AxisLocation axisLocation31 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder32 = categoryPlot0.getDatasetRenderingOrder();
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertNotNull(datasetRenderingOrder32);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        boolean boolean2 = xYPlot0.isRangeGridlinesVisible();
        java.awt.Color color5 = java.awt.Color.getColor("hi!", 0);
        xYPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color5);
        org.jfree.chart.axis.ValueAxis valueAxis7 = xYPlot0.getDomainAxis();
        org.jfree.chart.plot.Plot plot8 = xYPlot0.getParent();
        try {
            java.awt.Paint paint9 = plot8.getOutlinePaint();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNull(plot8);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint2 = xYPlot1.getDomainZeroBaselinePaint();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color4, stroke5);
        java.awt.Paint paint7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryMarker6.setLabelPaint(paint7);
        xYPlot1.setDomainZeroBaselinePaint(paint7);
        java.awt.Stroke stroke10 = xYPlot1.getDomainZeroBaselineStroke();
        boolean boolean11 = rectangleAnchor0.equals((java.lang.Object) stroke10);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        java.awt.Color color0 = java.awt.Color.white;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str2 = numberAxis1.getLabel();
        java.lang.String str3 = numberAxis1.getLabel();
        java.awt.Paint paint4 = numberAxis1.getAxisLinePaint();
        java.awt.Shape shape5 = numberAxis1.getRightArrow();
        boolean boolean6 = numberAxis1.isAutoRange();
        numberAxis1.setLabelURL("AxisLocation.TOP_OR_LEFT");
        org.jfree.data.Range range9 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis1.setRange(range9, false, true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str2.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str3.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(range9);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color9, stroke10);
        org.jfree.chart.util.Layer layer12 = null;
        xYPlot6.addRangeMarker(4, (org.jfree.chart.plot.Marker) categoryMarker11, layer12);
        java.awt.Font font14 = categoryMarker11.getLabelFont();
        java.awt.Paint paint15 = categoryMarker11.getPaint();
        org.jfree.chart.util.Layer layer16 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean17 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker11, layer16);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        java.util.List list19 = categoryPlot0.getCategoriesForAxis(categoryAxis18);
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker(0.0d);
        double double22 = valueMarker21.getValue();
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str25 = numberAxis24.getLabel();
        java.lang.String str26 = numberAxis24.getLabel();
        java.awt.Paint paint27 = numberAxis24.getAxisLinePaint();
        boolean boolean28 = valueMarker21.equals((java.lang.Object) paint27);
        java.awt.Color color29 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        boolean boolean30 = valueMarker21.equals((java.lang.Object) color29);
        java.awt.Paint paint31 = valueMarker21.getLabelPaint();
        boolean boolean32 = categoryPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker21);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(layer16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str25.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str26.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str2 = numberAxis1.getLabel();
        numberAxis1.setVisible(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis1.setTickUnit(numberTickUnit5, false, false);
        boolean boolean9 = numberAxis1.isAutoRange();
        numberAxis1.setLowerMargin((double) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str2.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(numberTickUnit5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color2, stroke3);
        xYPlot0.setBackgroundPaint((java.awt.Paint) color2);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        xYPlot0.setRenderer(6, xYItemRenderer7);
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        xYPlot0.removeChangeListener(plotChangeListener9);
        org.jfree.chart.util.Layer layer11 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection12 = xYPlot0.getDomainMarkers(layer11);
        int int13 = xYPlot0.getRangeAxisCount();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str16 = numberAxis15.getLabel();
        java.lang.String str17 = numberAxis15.getLabel();
        java.awt.Paint paint18 = numberAxis15.getAxisLinePaint();
        boolean boolean19 = numberAxis15.isTickLabelsVisible();
        java.awt.Font font20 = numberAxis15.getTickLabelFont();
        java.awt.Color color21 = java.awt.Color.blue;
        numberAxis15.setLabelPaint((java.awt.Paint) color21);
        org.jfree.data.Range range23 = xYPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis15);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder24 = xYPlot0.getSeriesRenderingOrder();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(layer11);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str16.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str17.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNull(range23);
        org.junit.Assert.assertNotNull(seriesRenderingOrder24);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int4 = xYPlot1.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3);
        org.jfree.chart.LegendItemCollection legendItemCollection5 = xYPlot1.getFixedLegendItems();
        boolean boolean6 = textAnchor0.equals((java.lang.Object) xYPlot1);
        org.jfree.chart.axis.ValueAxis valueAxis7 = xYPlot1.getRangeAxis();
        xYPlot1.zoom((double) 4);
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNull(legendItemCollection5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(valueAxis7);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        java.awt.Paint[] paintArray0 = null;
        java.awt.Paint[] paintArray1 = null;
        java.awt.Paint[] paintArray2 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray3 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.awt.Stroke stroke4 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint6 = xYPlot5.getDomainZeroBaselinePaint();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color8, stroke9);
        java.awt.Paint paint11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryMarker10.setLabelPaint(paint11);
        xYPlot5.setDomainZeroBaselinePaint(paint11);
        java.awt.Stroke stroke14 = xYPlot5.getDomainZeroBaselineStroke();
        java.awt.Stroke stroke15 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker21 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color19, stroke20);
        xYPlot17.setBackgroundPaint((java.awt.Paint) color19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        xYPlot17.setRenderer(6, xYItemRenderer24);
        org.jfree.chart.event.PlotChangeListener plotChangeListener26 = null;
        xYPlot17.removeChangeListener(plotChangeListener26);
        java.awt.Stroke stroke28 = xYPlot17.getDomainZeroBaselineStroke();
        java.awt.Stroke[] strokeArray29 = new java.awt.Stroke[] { stroke4, stroke14, stroke15, stroke16, stroke28 };
        java.awt.Stroke[] strokeArray30 = new java.awt.Stroke[] {};
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str33 = numberAxis32.getLabel();
        java.lang.String str34 = numberAxis32.getLabel();
        java.awt.Paint paint35 = numberAxis32.getAxisLinePaint();
        java.awt.Shape shape36 = numberAxis32.getRightArrow();
        org.jfree.chart.axis.NumberAxis numberAxis38 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str39 = numberAxis38.getLabel();
        java.lang.String str40 = numberAxis38.getLabel();
        java.awt.Paint paint41 = numberAxis38.getAxisLinePaint();
        java.awt.Shape shape42 = numberAxis38.getRightArrow();
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str45 = numberAxis44.getLabel();
        java.lang.String str46 = numberAxis44.getLabel();
        java.awt.Paint paint47 = numberAxis44.getAxisLinePaint();
        java.awt.Shape shape48 = numberAxis44.getRightArrow();
        org.jfree.chart.axis.NumberAxis numberAxis50 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str51 = numberAxis50.getLabel();
        java.lang.String str52 = numberAxis50.getLabel();
        java.awt.Paint paint53 = numberAxis50.getAxisLinePaint();
        java.awt.Shape shape54 = numberAxis50.getRightArrow();
        java.awt.Shape[] shapeArray55 = new java.awt.Shape[] { shape36, shape42, shape48, shape54 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier56 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray2, paintArray3, strokeArray29, strokeArray30, shapeArray55);
        java.awt.Paint paint58 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.plot.XYPlot xYPlot59 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke60 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot59.setDomainGridlineStroke(stroke60);
        org.jfree.chart.plot.ValueMarker valueMarker62 = new org.jfree.chart.plot.ValueMarker(0.0d, paint58, stroke60);
        java.awt.Stroke[] strokeArray63 = new java.awt.Stroke[] { stroke60 };
        java.awt.Shape[] shapeArray64 = null;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier65 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, strokeArray30, strokeArray63, shapeArray64);
        java.awt.Stroke stroke66 = defaultDrawingSupplier65.getNextOutlineStroke();
        try {
            java.awt.Stroke stroke67 = defaultDrawingSupplier65.getNextStroke();
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertNotNull(paintArray3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(strokeArray29);
        org.junit.Assert.assertNotNull(strokeArray30);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str33.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str34.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str39.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str40.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str45.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str46.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(shape48);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str51.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str52.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint53);
        org.junit.Assert.assertNotNull(shape54);
        org.junit.Assert.assertNotNull(shapeArray55);
        org.junit.Assert.assertNotNull(paint58);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertNotNull(strokeArray63);
        org.junit.Assert.assertNotNull(stroke66);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        java.util.List list7 = categoryPlot0.getCategoriesForAxis(categoryAxis6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=192,g=192,b=192]");
        categoryPlot0.setDomainAxis(categoryAxis9);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.axis.AxisState axisState12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot14.setAnchorValue((double) (-1L), true);
        categoryPlot14.setRangeCrosshairVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation20 = categoryPlot14.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis22 = categoryPlot14.getRangeAxis((int) '4');
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke27 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker28 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color26, stroke27);
        xYPlot24.setBackgroundPaint((java.awt.Paint) color26);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = null;
        xYPlot24.setRenderer(6, xYItemRenderer31);
        org.jfree.chart.event.PlotChangeListener plotChangeListener33 = null;
        xYPlot24.removeChangeListener(plotChangeListener33);
        java.awt.Stroke stroke35 = xYPlot24.getDomainZeroBaselineStroke();
        xYPlot23.setRangeGridlineStroke(stroke35);
        xYPlot23.setRangeCrosshairVisible(true);
        org.jfree.chart.plot.XYPlot xYPlot39 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint40 = xYPlot39.getDomainZeroBaselinePaint();
        boolean boolean41 = xYPlot39.isRangeGridlinesVisible();
        org.jfree.chart.axis.AxisLocation axisLocation42 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot39.setRangeAxisLocation(axisLocation42);
        xYPlot23.setDomainAxisLocation(axisLocation42, true);
        categoryPlot14.setDomainAxisLocation(axisLocation42, true);
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot();
        xYPlot48.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation51 = xYPlot48.getOrientation();
        java.lang.String str52 = plotOrientation51.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge53 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation42, plotOrientation51);
        try {
            java.util.List list54 = categoryAxis9.refreshTicks(graphics2D11, axisState12, rectangle2D13, rectangleEdge53);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertNull(valueAxis22);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(axisLocation42);
        org.junit.Assert.assertNotNull(plotOrientation51);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "PlotOrientation.VERTICAL" + "'", str52.equals("PlotOrientation.VERTICAL"));
        org.junit.Assert.assertNotNull(rectangleEdge53);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation3 = xYPlot0.getOrientation();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate5 = day4.getSerialDate();
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint7 = xYPlot6.getDomainZeroBaselinePaint();
        boolean boolean8 = day4.equals((java.lang.Object) paint7);
        java.util.Date date9 = day4.getStart();
        boolean boolean10 = plotOrientation3.equals((java.lang.Object) date9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean13 = plotOrientation3.equals((java.lang.Object) "hi!");
        org.junit.Assert.assertNotNull(plotOrientation3);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        java.util.List list7 = categoryPlot0.getCategoriesForAxis(categoryAxis6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=192,g=192,b=192]");
        categoryPlot0.setDomainAxis(categoryAxis9);
        java.lang.Comparable comparable12 = null;
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint17 = xYPlot16.getDomainZeroBaselinePaint();
        boolean boolean18 = xYPlot16.isRangeGridlinesVisible();
        java.awt.Color color21 = java.awt.Color.getColor("hi!", 0);
        xYPlot16.setRangeZeroBaselinePaint((java.awt.Paint) color21);
        java.lang.Object obj23 = xYPlot16.clone();
        java.awt.Paint paint24 = xYPlot16.getDomainTickBandPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = xYPlot16.getRangeAxisEdge((int) 'a');
        try {
            double double27 = categoryAxis9.getCategorySeriesMiddle((java.lang.Comparable) "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]", comparable12, categoryDataset13, (double) 7, rectangle2D15, rectangleEdge26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertNull(paint24);
        org.junit.Assert.assertNotNull(rectangleEdge26);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        xYPlot0.setRenderer((int) (byte) 1, xYItemRenderer4);
        double double6 = xYPlot0.getRangeCrosshairValue();
        xYPlot0.clearDomainMarkers(9);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation6 = categoryPlot0.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot0.getRangeAxis((int) '4');
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot0.getRangeAxisLocation();
        categoryPlot0.setRangeGridlinesVisible(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        categoryPlot0.setRenderer(categoryItemRenderer12, false);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertNotNull(axisLocation9);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        java.awt.Color color0 = java.awt.Color.BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        boolean boolean2 = xYPlot0.isRangeGridlinesVisible();
        org.jfree.chart.axis.AxisLocation axisLocation3 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot0.setRangeAxisLocation(axisLocation3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color8, stroke9);
        org.jfree.chart.util.Layer layer11 = null;
        xYPlot5.addRangeMarker(4, (org.jfree.chart.plot.Marker) categoryMarker10, layer11);
        java.awt.Font font13 = categoryMarker10.getLabelFont();
        java.awt.Paint paint14 = categoryMarker10.getPaint();
        xYPlot0.setNoDataMessagePaint(paint14);
        java.awt.Paint paint16 = xYPlot0.getBackgroundPaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder17 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot0.setDatasetRenderingOrder(datasetRenderingOrder17);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(datasetRenderingOrder17);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color2, stroke3);
        xYPlot0.setBackgroundPaint((java.awt.Paint) color2);
        xYPlot0.setOutlineVisible(false);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        numberAxis9.setTickLabelPaint((java.awt.Paint) color10);
        xYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis9);
        xYPlot0.mapDatasetToDomainAxis((int) '#', (int) (byte) 0);
        org.jfree.chart.axis.ValueAxis valueAxis17 = xYPlot0.getDomainAxis((-1));
        java.awt.Paint paint18 = null;
        try {
            xYPlot0.setRangeZeroBaselinePaint(paint18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNull(valueAxis17);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_OUTSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 2.0f + "'", float0 == 2.0f);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker5 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color3, stroke4);
        xYPlot1.setBackgroundPaint((java.awt.Paint) color3);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        xYPlot1.setRenderer(6, xYItemRenderer8);
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        xYPlot1.removeChangeListener(plotChangeListener10);
        java.awt.Stroke stroke12 = xYPlot1.getDomainZeroBaselineStroke();
        xYPlot0.setRangeGridlineStroke(stroke12);
        xYPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint17 = xYPlot16.getDomainZeroBaselinePaint();
        boolean boolean18 = xYPlot16.isRangeGridlinesVisible();
        org.jfree.chart.axis.AxisLocation axisLocation19 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot16.setRangeAxisLocation(axisLocation19);
        xYPlot0.setDomainAxisLocation(axisLocation19, true);
        java.awt.Stroke stroke23 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setOutlineStroke(stroke23);
        double double25 = xYPlot0.getRangeCrosshairValue();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int3 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis2);
        java.awt.Stroke stroke4 = numberAxis2.getAxisLineStroke();
        numberAxis2.setAutoTickUnitSelection(false, false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-8d + "'", double0 == 1.0E-8d);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int6 = xYPlot3.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis5);
        numberAxis5.setLowerBound((double) (short) 10);
        xYPlot0.setDomainAxis((int) (byte) 1, (org.jfree.chart.axis.ValueAxis) numberAxis5, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double12 = rectangleInsets11.getTop();
        java.lang.String str13 = rectangleInsets11.toString();
        xYPlot0.setInsets(rectangleInsets11, true);
        double double17 = rectangleInsets11.calculateBottomInset((double) (-1.0f));
        double double19 = rectangleInsets11.extendHeight((double) 8);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str13.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 2.0d + "'", double17 == 2.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 12.0d + "'", double19 == 12.0d);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color2, stroke3);
        xYPlot0.setBackgroundPaint((java.awt.Paint) color2);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        xYPlot0.setRenderer(6, xYItemRenderer7);
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        xYPlot0.removeChangeListener(plotChangeListener9);
        java.awt.Stroke stroke11 = xYPlot0.getDomainGridlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        xYPlot0.zoomDomainAxes((double) 100, (double) 8, plotRenderingInfo14, point2D15);
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        int int18 = xYPlot0.indexOf(xYDataset17);
        xYPlot0.setRangeCrosshairVisible(false);
        int int21 = xYPlot0.getWeight();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color6, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color10, stroke11);
        categoryMarker8.setLabelPaint((java.awt.Paint) color10);
        org.jfree.chart.util.Layer layer14 = null;
        categoryPlot0.addRangeMarker((int) (short) 1, (org.jfree.chart.plot.Marker) categoryMarker8, layer14, false);
        categoryPlot0.setDomainGridlinesVisible(false);
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker25 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color23, stroke24);
        xYPlot21.setBackgroundPaint((java.awt.Paint) color23);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        xYPlot21.setRenderer(6, xYItemRenderer28);
        org.jfree.chart.event.PlotChangeListener plotChangeListener30 = null;
        xYPlot21.removeChangeListener(plotChangeListener30);
        java.awt.Stroke stroke32 = xYPlot21.getDomainZeroBaselineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor36 = null;
        java.awt.geom.Point2D point2D37 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D35, rectangleAnchor36);
        xYPlot21.zoomRangeAxes(2.0d, plotRenderingInfo34, point2D37, true);
        org.jfree.chart.plot.PlotState plotState40 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo41 = null;
        try {
            categoryPlot0.draw(graphics2D19, rectangle2D20, point2D37, plotState40, plotRenderingInfo41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(point2D37);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj2 = objectList0.get(0);
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        xYPlot3.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        xYPlot3.setRenderer((int) (byte) 1, xYItemRenderer7);
        double double9 = xYPlot3.getRangeCrosshairValue();
        int int10 = objectList0.indexOf((java.lang.Object) xYPlot3);
        int int11 = objectList0.size();
        org.junit.Assert.assertNull(obj2);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj1 = objectList0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color2, stroke3);
        xYPlot0.setBackgroundPaint((java.awt.Paint) color2);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        xYPlot0.setRenderer(6, xYItemRenderer7);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot0.getRangeMarkers((int) ' ', layer10);
        org.jfree.data.xy.XYDataset xYDataset13 = xYPlot0.getDataset(4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        try {
            xYPlot0.handleClick(8, 9, plotRenderingInfo16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNull(xYDataset13);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=192,g=192,b=192]");
        float float2 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        xYPlot4.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = xYPlot4.getOrientation();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.awt.Paint paint10 = numberAxis9.getLabelPaint();
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        double double14 = numberAxis9.valueToJava2D(0.0d, rectangle2D12, rectangleEdge13);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray15 = new org.jfree.chart.axis.ValueAxis[] { numberAxis9 };
        xYPlot4.setDomainAxes(valueAxisArray15);
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker21 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color19, stroke20);
        xYPlot17.setBackgroundPaint((java.awt.Paint) color19);
        xYPlot4.setRangeCrosshairPaint((java.awt.Paint) color19);
        java.awt.Paint paint24 = xYPlot4.getRangeTickBandPaint();
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke29 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker30 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color28, stroke29);
        xYPlot26.setBackgroundPaint((java.awt.Paint) color28);
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str35 = numberAxis34.getLabel();
        numberAxis34.setVisible(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit38 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis34.setTickUnit(numberTickUnit38, false, false);
        numberAxis34.setAxisLineVisible(false);
        numberAxis34.setAutoTickUnitSelection(true);
        org.jfree.chart.plot.XYPlot xYPlot46 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint47 = xYPlot46.getDomainZeroBaselinePaint();
        java.awt.Color color49 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke50 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker51 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color49, stroke50);
        java.awt.Paint paint52 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryMarker51.setLabelPaint(paint52);
        xYPlot46.setDomainZeroBaselinePaint(paint52);
        java.awt.Stroke stroke55 = xYPlot46.getDomainZeroBaselineStroke();
        numberAxis34.setAxisLineStroke(stroke55);
        xYPlot26.setRangeAxis((int) (short) 0, (org.jfree.chart.axis.ValueAxis) numberAxis34);
        org.jfree.chart.util.RectangleEdge rectangleEdge58 = xYPlot26.getDomainAxisEdge();
        org.jfree.chart.axis.AxisSpace axisSpace59 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace60 = categoryAxis1.reserveSpace(graphics2D3, (org.jfree.chart.plot.Plot) xYPlot4, rectangle2D25, rectangleEdge58, axisSpace59);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(plotOrientation7);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(valueAxisArray15);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNull(paint24);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str35.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(numberTickUnit38);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNotNull(rectangleEdge58);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        xYPlot2.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        xYPlot2.setRenderer((int) (byte) 1, xYItemRenderer6);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color9, stroke10);
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryMarker11.setLabelPaint(paint12);
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color16, stroke17);
        xYPlot14.setBackgroundPaint((java.awt.Paint) color16);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        xYPlot14.setRenderer(6, xYItemRenderer21);
        org.jfree.chart.event.PlotChangeListener plotChangeListener23 = null;
        xYPlot14.removeChangeListener(plotChangeListener23);
        org.jfree.chart.util.Layer layer25 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection26 = xYPlot14.getDomainMarkers(layer25);
        boolean boolean28 = layer25.equals((java.lang.Object) "SeriesRenderingOrder.FORWARD");
        boolean boolean29 = xYPlot2.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker11, layer25);
        java.util.Collection collection30 = categoryPlot0.getDomainMarkers(0, layer25);
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint34 = xYPlot33.getDomainZeroBaselinePaint();
        java.awt.Color color36 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke37 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker38 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color36, stroke37);
        java.awt.Paint paint39 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryMarker38.setLabelPaint(paint39);
        xYPlot33.setDomainZeroBaselinePaint(paint39);
        java.awt.Stroke stroke42 = xYPlot33.getDomainZeroBaselineStroke();
        org.jfree.chart.plot.XYPlot xYPlot43 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color46 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke47 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker48 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color46, stroke47);
        org.jfree.chart.util.Layer layer49 = null;
        xYPlot43.addRangeMarker(4, (org.jfree.chart.plot.Marker) categoryMarker48, layer49);
        java.awt.Font font51 = categoryMarker48.getLabelFont();
        xYPlot33.setNoDataMessageFont(font51);
        org.jfree.data.xy.XYDataset xYDataset53 = null;
        xYPlot33.setDataset(xYDataset53);
        java.awt.Color color56 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke57 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker58 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color56, stroke57);
        org.jfree.data.general.Dataset dataset60 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent61 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) 100, dataset60);
        boolean boolean62 = categoryMarker58.equals((java.lang.Object) 100);
        xYPlot33.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker58);
        java.awt.Color color64 = java.awt.Color.orange;
        categoryMarker58.setOutlinePaint((java.awt.Paint) color64);
        org.jfree.chart.util.Layer layer66 = null;
        try {
            categoryPlot0.addDomainMarker((int) ' ', categoryMarker58, layer66, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(layer25);
        org.junit.Assert.assertNull(collection26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNull(collection30);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(color64);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color1, stroke2);
        java.awt.Paint paint4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryMarker3.setLabelPaint(paint4);
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryMarker3.setLabelFont(font6);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str10 = numberAxis9.getLabel();
        java.lang.String str11 = numberAxis9.getLabel();
        java.awt.Paint paint12 = numberAxis9.getAxisLinePaint();
        categoryMarker3.setLabelPaint(paint12);
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color16, stroke17);
        xYPlot14.setBackgroundPaint((java.awt.Paint) color16);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        xYPlot14.setRenderer(6, xYItemRenderer21);
        org.jfree.chart.event.PlotChangeListener plotChangeListener23 = null;
        xYPlot14.removeChangeListener(plotChangeListener23);
        java.awt.Paint paint25 = xYPlot14.getRangeTickBandPaint();
        categoryMarker3.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot14);
        java.awt.Color color27 = java.awt.Color.red;
        categoryMarker3.setOutlinePaint((java.awt.Paint) color27);
        java.awt.Font font29 = categoryMarker3.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = categoryMarker3.getLabelOffset();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str10.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str11.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNull(paint25);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNotNull(rectangleInsets30);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int4 = xYPlot1.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3);
        java.awt.Stroke stroke5 = numberAxis3.getAxisLineStroke();
        numberAxis3.setVisible(false);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.awt.Paint paint10 = numberAxis9.getLabelPaint();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis9, xYItemRenderer11);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder13 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        java.lang.String str14 = seriesRenderingOrder13.toString();
        java.lang.String str15 = seriesRenderingOrder13.toString();
        xYPlot12.setSeriesRenderingOrder(seriesRenderingOrder13);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(seriesRenderingOrder13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "SeriesRenderingOrder.FORWARD" + "'", str14.equals("SeriesRenderingOrder.FORWARD"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "SeriesRenderingOrder.FORWARD" + "'", str15.equals("SeriesRenderingOrder.FORWARD"));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int3 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis2);
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color6, stroke7);
        xYPlot4.setBackgroundPaint((java.awt.Paint) color6);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        xYPlot4.setRenderer(6, xYItemRenderer11);
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = xYPlot4.getRangeMarkers((int) ' ', layer14);
        boolean boolean16 = numberAxis2.hasListener((java.util.EventListener) xYPlot4);
        xYPlot4.setWeight(9);
        org.jfree.chart.plot.Marker marker20 = null;
        org.jfree.chart.util.Layer layer21 = org.jfree.chart.util.Layer.FOREGROUND;
        try {
            xYPlot4.addRangeMarker((int) (byte) -1, marker20, layer21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(layer21);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker5 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color3, stroke4);
        java.awt.Paint paint6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryMarker5.setLabelPaint(paint6);
        xYPlot0.setDomainZeroBaselinePaint(paint6);
        java.awt.Stroke stroke9 = xYPlot0.getDomainZeroBaselineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int15 = xYPlot12.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis14);
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color18, stroke19);
        xYPlot16.setBackgroundPaint((java.awt.Paint) color18);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = null;
        xYPlot16.setRenderer(6, xYItemRenderer23);
        org.jfree.chart.util.Layer layer26 = null;
        java.util.Collection collection27 = xYPlot16.getRangeMarkers((int) ' ', layer26);
        boolean boolean28 = numberAxis14.hasListener((java.util.EventListener) xYPlot16);
        java.lang.Object obj29 = numberAxis14.clone();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) numberAxis14, categoryItemRenderer30);
        int int32 = xYPlot0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis14);
        java.awt.Stroke stroke33 = xYPlot0.getRangeCrosshairStroke();
        org.jfree.chart.axis.AxisLocation axisLocation35 = xYPlot0.getDomainAxisLocation(0);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(collection27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(obj29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(axisLocation35);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color2, stroke3);
        xYPlot0.setBackgroundPaint((java.awt.Paint) color2);
        xYPlot0.setOutlineVisible(false);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        numberAxis9.setTickLabelPaint((java.awt.Paint) color10);
        xYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis9);
        numberAxis9.setFixedDimension((double) 'a');
        java.lang.String str15 = numberAxis9.getLabelURL();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNull(str15);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        java.awt.Color color0 = java.awt.Color.RED;
        java.awt.color.ColorSpace colorSpace1 = null;
        java.awt.Color color5 = java.awt.Color.RED;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        xYPlot6.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation9 = xYPlot6.getOrientation();
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.awt.Paint paint12 = numberAxis11.getLabelPaint();
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        double double16 = numberAxis11.valueToJava2D(0.0d, rectangle2D14, rectangleEdge15);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray17 = new org.jfree.chart.axis.ValueAxis[] { numberAxis11 };
        xYPlot6.setDomainAxes(valueAxisArray17);
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker23 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color21, stroke22);
        xYPlot19.setBackgroundPaint((java.awt.Paint) color21);
        xYPlot6.setRangeCrosshairPaint((java.awt.Paint) color21);
        float[] floatArray30 = new float[] { (byte) 1, 10L, 100.0f, 100.0f };
        float[] floatArray31 = color21.getComponents(floatArray30);
        float[] floatArray32 = color5.getRGBComponents(floatArray31);
        float[] floatArray33 = java.awt.Color.RGBtoHSB((int) (byte) 1, (int) (byte) 1, 0, floatArray32);
        try {
            float[] floatArray34 = color0.getColorComponents(colorSpace1, floatArray33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(plotOrientation9);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(valueAxisArray17);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(floatArray33);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color9, stroke10);
        org.jfree.chart.util.Layer layer12 = null;
        xYPlot6.addRangeMarker(4, (org.jfree.chart.plot.Marker) categoryMarker11, layer12);
        java.awt.Font font14 = categoryMarker11.getLabelFont();
        java.awt.Paint paint15 = categoryMarker11.getPaint();
        org.jfree.chart.util.Layer layer16 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean17 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker11, layer16);
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str21 = numberAxis20.getLabel();
        java.lang.String str22 = numberAxis20.getLabel();
        java.awt.Paint paint23 = numberAxis20.getAxisLinePaint();
        boolean boolean24 = numberAxis20.isTickLabelsVisible();
        numberAxis20.setAutoRange(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = numberAxis20.getLabelInsets();
        java.awt.Stroke stroke28 = numberAxis20.getAxisLineStroke();
        int int29 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis20);
        java.awt.Stroke stroke30 = categoryPlot0.getRangeGridlineStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection31 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.util.SortOrder sortOrder32 = categoryPlot0.getColumnRenderingOrder();
        java.awt.Paint paint33 = categoryPlot0.getNoDataMessagePaint();
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(layer16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str21.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str22.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNull(legendItemCollection31);
        org.junit.Assert.assertNotNull(sortOrder32);
        org.junit.Assert.assertNotNull(paint33);
    }

//    @Test
//    public void test323() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test323");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        int int2 = day0.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.next();
//        java.util.Calendar calendar4 = null;
//        try {
//            day0.peg(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker5 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color3, stroke4);
        java.awt.Paint paint6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryMarker5.setLabelPaint(paint6);
        xYPlot0.setDomainZeroBaselinePaint(paint6);
        java.awt.Stroke stroke9 = xYPlot0.getDomainZeroBaselineStroke();
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker15 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color13, stroke14);
        org.jfree.chart.util.Layer layer16 = null;
        xYPlot10.addRangeMarker(4, (org.jfree.chart.plot.Marker) categoryMarker15, layer16);
        java.awt.Font font18 = categoryMarker15.getLabelFont();
        xYPlot0.setNoDataMessageFont(font18);
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        xYPlot0.setDataset(xYDataset20);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent22 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot0);
        java.awt.Paint paint23 = xYPlot0.getRangeGridlinePaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(paint23);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker5 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color3, stroke4);
        java.awt.Paint paint6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryMarker5.setLabelPaint(paint6);
        xYPlot0.setDomainZeroBaselinePaint(paint6);
        java.awt.Stroke stroke9 = xYPlot0.getDomainZeroBaselineStroke();
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker15 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color13, stroke14);
        org.jfree.chart.util.Layer layer16 = null;
        xYPlot10.addRangeMarker(4, (org.jfree.chart.plot.Marker) categoryMarker15, layer16);
        java.awt.Font font18 = categoryMarker15.getLabelFont();
        xYPlot0.setNoDataMessageFont(font18);
        java.awt.Stroke stroke20 = xYPlot0.getDomainGridlineStroke();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis(0);
        categoryPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        categoryPlot0.setRenderer(0, categoryItemRenderer9, false);
        categoryPlot0.configureDomainAxes();
        java.awt.Stroke stroke13 = categoryPlot0.getRangeCrosshairStroke();
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int3 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis2);
        numberAxis2.setLowerBound((double) (short) 10);
        numberAxis2.setNegativeArrowVisible(false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color1, stroke2);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color5, stroke6);
        categoryMarker3.setLabelPaint((java.awt.Paint) color5);
        java.awt.Font font9 = categoryMarker3.getLabelFont();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker3);
        org.jfree.chart.text.TextAnchor textAnchor11 = categoryMarker3.getLabelTextAnchor();
        java.lang.Comparable comparable12 = categoryMarker3.getKey();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(textAnchor11);
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + "" + "'", comparable12.equals(""));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairLockedOnData(false);
        xYPlot0.setDomainCrosshairLockedOnData(false);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = xYPlot5.getOrientation();
        java.lang.String str9 = plotOrientation8.toString();
        xYPlot0.setOrientation(plotOrientation8);
        org.jfree.chart.axis.ValueAxis valueAxis12 = xYPlot0.getDomainAxis((int) (short) 0);
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "PlotOrientation.VERTICAL" + "'", str9.equals("PlotOrientation.VERTICAL"));
        org.junit.Assert.assertNull(valueAxis12);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int3 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis2);
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color6, stroke7);
        xYPlot4.setBackgroundPaint((java.awt.Paint) color6);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        xYPlot4.setRenderer(6, xYItemRenderer11);
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = xYPlot4.getRangeMarkers((int) ' ', layer14);
        boolean boolean16 = numberAxis2.hasListener((java.util.EventListener) xYPlot4);
        java.lang.Object obj17 = numberAxis2.clone();
        boolean boolean18 = numberAxis2.isAutoTickUnitSelection();
        boolean boolean19 = numberAxis2.isAutoRange();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str2 = numberAxis1.getLabel();
        numberAxis1.setVisible(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis1.setTickUnit(numberTickUnit5, false, false);
        numberAxis1.setAxisLineVisible(false);
        numberAxis1.setAutoTickUnitSelection(true);
        double double13 = numberAxis1.getFixedDimension();
        boolean boolean14 = numberAxis1.getAutoRangeIncludesZero();
        numberAxis1.setTickMarkInsideLength((float) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str2.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(numberTickUnit5);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        boolean boolean2 = xYPlot0.isRangeGridlinesVisible();
        java.awt.Color color5 = java.awt.Color.getColor("hi!", 0);
        xYPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color5);
        org.jfree.chart.axis.ValueAxis valueAxis7 = xYPlot0.getDomainAxis();
        org.jfree.chart.axis.AxisLocation axisLocation8 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot0.setRangeAxisLocation(axisLocation8, true);
        java.awt.Stroke stroke11 = null;
        try {
            xYPlot0.setRangeCrosshairStroke(stroke11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNotNull(axisLocation8);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 500, 0.0d, (double) (byte) 0, (double) 10);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.axis.AxisSpace axisSpace3 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace3, true);
        org.jfree.chart.axis.AxisLocation axisLocation6 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.axis.AxisLocation axisLocation7 = axisLocation6.getOpposite();
        xYPlot0.setDomainAxisLocation(axisLocation7, false);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(axisLocation7);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        java.lang.String str1 = color0.toString();
        int int2 = color0.getTransparency();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java.awt.Color[r=64,g=255,b=64]" + "'", str1.equals("java.awt.Color[r=64,g=255,b=64]"));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str2 = numberAxis1.getLabel();
        numberAxis1.setVisible(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis1.setTickUnit(numberTickUnit5, false, false);
        numberAxis1.setAxisLineVisible(false);
        numberAxis1.setAutoTickUnitSelection(true);
        boolean boolean13 = numberAxis1.isTickLabelsVisible();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str2.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(numberTickUnit5);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int3 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis2);
        java.awt.Stroke stroke4 = numberAxis2.getAxisLineStroke();
        boolean boolean5 = numberAxis2.isNegativeArrowVisible();
        org.jfree.data.general.Dataset dataset6 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) numberAxis2, dataset6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        numberAxis2.setAxisLinePaint((java.awt.Paint) color8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        boolean boolean2 = xYPlot0.isRangeGridlinesVisible();
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        xYPlot3.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        xYPlot3.setRenderer((int) (byte) 1, xYItemRenderer7);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        xYPlot3.setRangeGridlineStroke(stroke9);
        xYPlot0.setRangeZeroBaselineStroke(stroke9);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder12 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        java.lang.String str13 = datasetRenderingOrder12.toString();
        java.lang.String str14 = datasetRenderingOrder12.toString();
        xYPlot0.setDatasetRenderingOrder(datasetRenderingOrder12);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(datasetRenderingOrder12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "DatasetRenderingOrder.REVERSE" + "'", str13.equals("DatasetRenderingOrder.REVERSE"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "DatasetRenderingOrder.REVERSE" + "'", str14.equals("DatasetRenderingOrder.REVERSE"));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        java.awt.Paint paint0 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str2 = numberAxis1.getLabel();
        numberAxis1.setVisible(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis1.setTickUnit(numberTickUnit5, false, false);
        numberAxis1.setAxisLineVisible(false);
        numberAxis1.setAutoTickUnitSelection(true);
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint14 = xYPlot13.getDomainZeroBaselinePaint();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color16, stroke17);
        java.awt.Paint paint19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryMarker18.setLabelPaint(paint19);
        xYPlot13.setDomainZeroBaselinePaint(paint19);
        java.awt.Stroke stroke22 = xYPlot13.getDomainZeroBaselineStroke();
        numberAxis1.setAxisLineStroke(stroke22);
        numberAxis1.setLabelURL("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        double double26 = numberAxis1.getLowerBound();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str2.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(numberTickUnit5);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        boolean boolean2 = xYPlot0.isRangeGridlinesVisible();
        java.awt.Color color5 = java.awt.Color.getColor("hi!", 0);
        xYPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color5);
        org.jfree.chart.axis.ValueAxis valueAxis7 = xYPlot0.getDomainAxis();
        org.jfree.chart.plot.Plot plot8 = xYPlot0.getParent();
        org.jfree.data.general.Dataset dataset10 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent11 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) 100, dataset10);
        xYPlot0.datasetChanged(datasetChangeEvent11);
        java.awt.Stroke stroke13 = xYPlot0.getRangeCrosshairStroke();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis(0);
        categoryPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis10 = categoryPlot0.getRangeAxis(9);
        double double11 = categoryPlot0.getRangeCrosshairValue();
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.awt.Paint paint2 = numberAxis1.getLabelPaint();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = numberAxis1.valueToJava2D(0.0d, rectangle2D4, rectangleEdge5);
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = numberAxis1.java2DToValue((double) 0L, rectangle2D8, rectangleEdge9);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double12 = rectangleInsets11.getTop();
        double double14 = rectangleInsets11.calculateBottomOutset((double) 1);
        numberAxis1.setLabelInsets(rectangleInsets11);
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str18 = numberAxis17.getLabel();
        java.lang.String str19 = numberAxis17.getLabel();
        java.awt.Paint paint20 = numberAxis17.getAxisLinePaint();
        java.awt.Shape shape21 = numberAxis17.getRightArrow();
        boolean boolean22 = numberAxis17.isAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str25 = numberAxis24.getLabel();
        java.lang.String str26 = numberAxis24.getLabel();
        java.awt.Paint paint27 = numberAxis24.getAxisLinePaint();
        java.awt.Shape shape28 = numberAxis24.getRightArrow();
        numberAxis17.setDownArrow(shape28);
        numberAxis1.setLeftArrow(shape28);
        numberAxis1.setVerticalTickLabels(false);
        double double33 = numberAxis1.getFixedDimension();
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int37 = xYPlot34.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis36);
        java.awt.Stroke stroke38 = numberAxis36.getAxisLineStroke();
        boolean boolean39 = numberAxis36.isNegativeArrowVisible();
        org.jfree.data.Range range40 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis36.setRangeWithMargins(range40);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit42 = numberAxis36.getTickUnit();
        numberAxis1.setTickUnit(numberTickUnit42, false, true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 2.0d + "'", double14 == 2.0d);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str18.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str19.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str25.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str26.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(range40);
        org.junit.Assert.assertNotNull(numberTickUnit42);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        java.util.List list7 = categoryPlot0.getCategoriesForAxis(categoryAxis6);
        java.awt.Stroke stroke8 = null;
        try {
            categoryPlot0.setDomainGridlineStroke(stroke8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(list7);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color9, stroke10);
        org.jfree.chart.util.Layer layer12 = null;
        xYPlot6.addRangeMarker(4, (org.jfree.chart.plot.Marker) categoryMarker11, layer12);
        java.awt.Font font14 = categoryMarker11.getLabelFont();
        java.awt.Paint paint15 = categoryMarker11.getPaint();
        org.jfree.chart.util.Layer layer16 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean17 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker11, layer16);
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str21 = numberAxis20.getLabel();
        java.lang.String str22 = numberAxis20.getLabel();
        java.awt.Paint paint23 = numberAxis20.getAxisLinePaint();
        boolean boolean24 = numberAxis20.isTickLabelsVisible();
        numberAxis20.setAutoRange(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = numberAxis20.getLabelInsets();
        java.awt.Stroke stroke28 = numberAxis20.getAxisLineStroke();
        int int29 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis20);
        java.awt.Paint paint30 = null;
        try {
            categoryPlot0.setRangeGridlinePaint(paint30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(layer16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str21.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str22.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        boolean boolean2 = xYPlot0.isRangeGridlinesVisible();
        java.awt.Color color5 = java.awt.Color.getColor("hi!", 0);
        xYPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color5);
        org.jfree.chart.axis.ValueAxis valueAxis7 = xYPlot0.getDomainAxis();
        java.awt.Color color8 = java.awt.Color.WHITE;
        xYPlot0.setOutlinePaint((java.awt.Paint) color8);
        java.awt.color.ColorSpace colorSpace10 = null;
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        xYPlot12.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation15 = xYPlot12.getOrientation();
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.awt.Paint paint18 = numberAxis17.getLabelPaint();
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = null;
        double double22 = numberAxis17.valueToJava2D(0.0d, rectangle2D20, rectangleEdge21);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray23 = new org.jfree.chart.axis.ValueAxis[] { numberAxis17 };
        xYPlot12.setDomainAxes(valueAxisArray23);
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke28 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker29 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color27, stroke28);
        xYPlot25.setBackgroundPaint((java.awt.Paint) color27);
        xYPlot12.setRangeCrosshairPaint((java.awt.Paint) color27);
        float[] floatArray36 = new float[] { (byte) 1, 10L, 100.0f, 100.0f };
        float[] floatArray37 = color27.getComponents(floatArray36);
        float[] floatArray38 = color11.getComponents(floatArray36);
        try {
            float[] floatArray39 = color8.getColorComponents(colorSpace10, floatArray36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(plotOrientation15);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(valueAxisArray23);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(floatArray36);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertNotNull(floatArray38);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainZoomable();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int7 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color10, stroke11);
        xYPlot8.setBackgroundPaint((java.awt.Paint) color10);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        xYPlot8.setRenderer(6, xYItemRenderer15);
        org.jfree.chart.util.Layer layer18 = null;
        java.util.Collection collection19 = xYPlot8.getRangeMarkers((int) ' ', layer18);
        boolean boolean20 = numberAxis6.hasListener((java.util.EventListener) xYPlot8);
        java.lang.Object obj21 = numberAxis6.clone();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis6, categoryItemRenderer22);
        org.jfree.chart.util.SortOrder sortOrder24 = categoryPlot23.getRowRenderingOrder();
        categoryPlot0.setColumnRenderingOrder(sortOrder24);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray26 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot0.setRenderers(categoryItemRendererArray26);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(collection19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(sortOrder24);
        org.junit.Assert.assertNotNull(categoryItemRendererArray26);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj2 = objectList0.get(0);
        java.lang.Object obj4 = objectList0.get(192);
        org.junit.Assert.assertNull(obj2);
        org.junit.Assert.assertNull(obj4);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        java.awt.Color color3 = java.awt.Color.orange;
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.Color color8 = java.awt.Color.RED;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        xYPlot9.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation12 = xYPlot9.getOrientation();
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.awt.Paint paint15 = numberAxis14.getLabelPaint();
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = null;
        double double19 = numberAxis14.valueToJava2D(0.0d, rectangle2D17, rectangleEdge18);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray20 = new org.jfree.chart.axis.ValueAxis[] { numberAxis14 };
        xYPlot9.setDomainAxes(valueAxisArray20);
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke25 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color24, stroke25);
        xYPlot22.setBackgroundPaint((java.awt.Paint) color24);
        xYPlot9.setRangeCrosshairPaint((java.awt.Paint) color24);
        float[] floatArray33 = new float[] { (byte) 1, 10L, 100.0f, 100.0f };
        float[] floatArray34 = color24.getComponents(floatArray33);
        float[] floatArray35 = color8.getRGBComponents(floatArray34);
        float[] floatArray36 = java.awt.Color.RGBtoHSB((int) (byte) 1, (int) (byte) 1, 0, floatArray35);
        float[] floatArray37 = color4.getRGBColorComponents(floatArray36);
        float[] floatArray38 = color3.getComponents(floatArray36);
        float[] floatArray39 = java.awt.Color.RGBtoHSB((int) '4', 12, 100, floatArray38);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(plotOrientation12);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(valueAxisArray20);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertNotNull(floatArray35);
        org.junit.Assert.assertNotNull(floatArray36);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertNotNull(floatArray38);
        org.junit.Assert.assertNotNull(floatArray39);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        xYPlot0.setRenderer((int) (byte) 1, xYItemRenderer4);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int9 = xYPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis8);
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color16, stroke17);
        xYPlot14.setBackgroundPaint((java.awt.Paint) color16);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        xYPlot14.setRenderer(6, xYItemRenderer21);
        org.jfree.chart.event.PlotChangeListener plotChangeListener23 = null;
        xYPlot14.removeChangeListener(plotChangeListener23);
        java.awt.Stroke stroke25 = xYPlot14.getDomainZeroBaselineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor29 = null;
        java.awt.geom.Point2D point2D30 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D28, rectangleAnchor29);
        xYPlot14.zoomRangeAxes(2.0d, plotRenderingInfo27, point2D30, true);
        try {
            xYPlot0.zoomDomainAxes((double) 175, (double) 12, plotRenderingInfo13, point2D30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (183.75) <= upper (12.600000000000001).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(point2D30);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        java.util.List list7 = categoryPlot0.getCategoriesForAxis(categoryAxis6);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int11 = xYPlot8.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        java.awt.Stroke stroke12 = numberAxis10.getAxisLineStroke();
        numberAxis10.setVisible(false);
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker19 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color17, stroke18);
        xYPlot15.setBackgroundPaint((java.awt.Paint) color17);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        xYPlot15.setRenderer(6, xYItemRenderer22);
        org.jfree.chart.event.PlotChangeListener plotChangeListener24 = null;
        xYPlot15.removeChangeListener(plotChangeListener24);
        java.awt.Stroke stroke26 = xYPlot15.getDomainZeroBaselineStroke();
        numberAxis10.setTickMarkStroke(stroke26);
        categoryPlot0.setRangeCrosshairStroke(stroke26);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        java.awt.geom.Point2D point2D31 = null;
        categoryPlot0.zoomDomainAxes(0.0d, plotRenderingInfo30, point2D31, false);
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str36 = numberAxis35.getLabel();
        boolean boolean37 = numberAxis35.isAutoRange();
        boolean boolean38 = numberAxis35.isNegativeArrowVisible();
        org.jfree.chart.axis.NumberAxis numberAxis40 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str41 = numberAxis40.getLabel();
        numberAxis40.setVisible(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit44 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis40.setTickUnit(numberTickUnit44, false, false);
        numberAxis40.setAxisLineVisible(false);
        numberAxis40.setAutoTickUnitSelection(true);
        org.jfree.chart.plot.XYPlot xYPlot52 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint53 = xYPlot52.getDomainZeroBaselinePaint();
        java.awt.Color color55 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke56 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker57 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color55, stroke56);
        java.awt.Paint paint58 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryMarker57.setLabelPaint(paint58);
        xYPlot52.setDomainZeroBaselinePaint(paint58);
        java.awt.Stroke stroke61 = xYPlot52.getDomainZeroBaselineStroke();
        numberAxis40.setAxisLineStroke(stroke61);
        java.awt.Shape shape63 = numberAxis40.getRightArrow();
        numberAxis35.setRightArrow(shape63);
        int int65 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis35);
        java.awt.Graphics2D graphics2D66 = null;
        java.awt.geom.Rectangle2D rectangle2D67 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo69 = null;
        boolean boolean70 = categoryPlot0.render(graphics2D66, rectangle2D67, 0, plotRenderingInfo69);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str36.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str41.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(numberTickUnit44);
        org.junit.Assert.assertNotNull(paint53);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertNotNull(paint58);
        org.junit.Assert.assertNotNull(stroke61);
        org.junit.Assert.assertNotNull(shape63);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-1) + "'", int65 == (-1));
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker5 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color3, stroke4);
        java.awt.Paint paint6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryMarker5.setLabelPaint(paint6);
        xYPlot0.setDomainZeroBaselinePaint(paint6);
        java.awt.Stroke stroke9 = xYPlot0.getDomainZeroBaselineStroke();
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker15 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color13, stroke14);
        org.jfree.chart.util.Layer layer16 = null;
        xYPlot10.addRangeMarker(4, (org.jfree.chart.plot.Marker) categoryMarker15, layer16);
        java.awt.Font font18 = categoryMarker15.getLabelFont();
        xYPlot0.setNoDataMessageFont(font18);
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        xYPlot0.setDataset(xYDataset20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot0.getRangeAxis((int) (byte) 10);
        boolean boolean24 = xYPlot0.isRangeZoomable();
        int int25 = xYPlot0.getWeight();
        xYPlot0.setDomainCrosshairValue((double) 12);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color2, stroke3);
        xYPlot0.setBackgroundPaint((java.awt.Paint) color2);
        xYPlot0.setOutlineVisible(false);
        java.awt.Stroke stroke8 = xYPlot0.getRangeGridlineStroke();
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str12 = numberAxis11.getLabel();
        numberAxis11.setVisible(false);
        xYPlot0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis11, true);
        org.jfree.data.RangeType rangeType17 = numberAxis11.getRangeType();
        double double18 = numberAxis11.getLabelAngle();
        numberAxis11.setTickMarksVisible(false);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str12.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(rangeType17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation6 = categoryPlot0.getDomainAxisLocation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot0.zoomRangeAxes((double) (-1), (-8.0d), plotRenderingInfo9, point2D10);
        categoryPlot0.setRangeCrosshairVisible(true);
        org.junit.Assert.assertNotNull(axisLocation6);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = null;
        xYPlot0.setRenderer(192, xYItemRenderer2);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint2 = xYPlot1.getDomainZeroBaselinePaint();
        boolean boolean3 = xYPlot1.isRangeGridlinesVisible();
        java.awt.Color color6 = java.awt.Color.getColor("hi!", 0);
        xYPlot1.setRangeZeroBaselinePaint((java.awt.Paint) color6);
        org.jfree.chart.axis.ValueAxis valueAxis8 = xYPlot1.getDomainAxis();
        org.jfree.chart.plot.Plot plot9 = xYPlot1.getParent();
        org.jfree.data.general.Dataset dataset11 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) 100, dataset11);
        xYPlot1.datasetChanged(datasetChangeEvent12);
        xYPlot0.datasetChanged(datasetChangeEvent12);
        xYPlot0.setDomainCrosshairLockedOnData(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder17 = xYPlot0.getDatasetRenderingOrder();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertNull(plot9);
        org.junit.Assert.assertNotNull(datasetRenderingOrder17);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color2, stroke3);
        xYPlot0.setBackgroundPaint((java.awt.Paint) color2);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str9 = numberAxis8.getLabel();
        numberAxis8.setVisible(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis8.setTickUnit(numberTickUnit12, false, false);
        numberAxis8.setAxisLineVisible(false);
        numberAxis8.setAutoTickUnitSelection(true);
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint21 = xYPlot20.getDomainZeroBaselinePaint();
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker25 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color23, stroke24);
        java.awt.Paint paint26 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryMarker25.setLabelPaint(paint26);
        xYPlot20.setDomainZeroBaselinePaint(paint26);
        java.awt.Stroke stroke29 = xYPlot20.getDomainZeroBaselineStroke();
        numberAxis8.setAxisLineStroke(stroke29);
        xYPlot0.setRangeAxis((int) (short) 0, (org.jfree.chart.axis.ValueAxis) numberAxis8);
        java.awt.Color color32 = java.awt.Color.PINK;
        xYPlot0.setDomainZeroBaselinePaint((java.awt.Paint) color32);
        boolean boolean34 = xYPlot0.isRangeCrosshairVisible();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str9.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.data.category.CategoryDataset categoryDataset6 = categoryPlot0.getDataset();
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        xYPlot9.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        xYPlot9.setRenderer((int) (byte) 1, xYItemRenderer13);
        double double15 = xYPlot9.getRangeCrosshairValue();
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int19 = xYPlot16.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis18);
        boolean boolean20 = xYPlot9.equals((java.lang.Object) xYPlot16);
        xYPlot9.setForegroundAlpha((float) 10L);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = null;
        java.awt.geom.Point2D point2D27 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D25, rectangleAnchor26);
        xYPlot9.zoomRangeAxes((double) 128, plotRenderingInfo24, point2D27, true);
        org.jfree.chart.plot.PlotState plotState30 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        try {
            categoryPlot0.draw(graphics2D7, rectangle2D8, point2D27, plotState30, plotRenderingInfo31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryDataset6);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(point2D27);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color6, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color10, stroke11);
        categoryMarker8.setLabelPaint((java.awt.Paint) color10);
        org.jfree.chart.util.Layer layer14 = null;
        categoryPlot0.addRangeMarker((int) (short) 1, (org.jfree.chart.plot.Marker) categoryMarker8, layer14, false);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray17 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot0.setDomainAxes(categoryAxisArray17);
        java.lang.String str19 = categoryPlot0.getPlotType();
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = categoryPlot0.getRendererForDataset(categoryDataset20);
        categoryPlot0.setDomainGridlinesVisible(false);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(categoryAxisArray17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Category Plot" + "'", str19.equals("Category Plot"));
        org.junit.Assert.assertNull(categoryItemRenderer21);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeMarkers();
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.lang.String str1 = rectangleAnchor0.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleAnchor.BOTTOM_LEFT" + "'", str1.equals("RectangleAnchor.BOTTOM_LEFT"));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str2 = numberAxis1.getLabel();
        numberAxis1.setVisible(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis1.setTickUnit(numberTickUnit5, false, false);
        numberAxis1.setLabelURL("SeriesRenderingOrder.FORWARD");
        double double11 = numberAxis1.getLabelAngle();
        java.lang.String str12 = numberAxis1.getLabelURL();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str2.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(numberTickUnit5);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "SeriesRenderingOrder.FORWARD" + "'", str12.equals("SeriesRenderingOrder.FORWARD"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int6 = xYPlot3.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis5);
        numberAxis5.setLowerBound((double) (short) 10);
        xYPlot0.setDomainAxis((int) (byte) 1, (org.jfree.chart.axis.ValueAxis) numberAxis5, true);
        java.awt.Paint paint11 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint13 = xYPlot12.getDomainZeroBaselinePaint();
        boolean boolean14 = xYPlot12.isRangeGridlinesVisible();
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot12.setRangeAxisLocation(axisLocation15);
        xYPlot0.setRangeAxisLocation(axisLocation15);
        org.jfree.chart.axis.AxisSpace axisSpace18 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace18);
        java.awt.Paint paint20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYPlot0.setDomainGridlinePaint(paint20);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color2);
        numberAxis1.setLowerBound(0.0d);
        double double6 = numberAxis1.getFixedDimension();
        java.awt.Stroke stroke7 = numberAxis1.getAxisLineStroke();
        boolean boolean8 = numberAxis1.isVerticalTickLabels();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int3 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis2);
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color6, stroke7);
        xYPlot4.setBackgroundPaint((java.awt.Paint) color6);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        xYPlot4.setRenderer(6, xYItemRenderer11);
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = xYPlot4.getRangeMarkers((int) ' ', layer14);
        boolean boolean16 = numberAxis2.hasListener((java.util.EventListener) xYPlot4);
        numberAxis2.setVerticalTickLabels(true);
        boolean boolean19 = numberAxis2.getAutoRangeIncludesZero();
        java.awt.Paint paint20 = numberAxis2.getLabelPaint();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color1, stroke2);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color5, stroke6);
        categoryMarker3.setLabelPaint((java.awt.Paint) color5);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker3);
        org.jfree.chart.plot.Marker marker10 = markerChangeEvent9.getMarker();
        java.awt.Paint paint12 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot13.setDomainGridlineStroke(stroke14);
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker(0.0d, paint12, stroke14);
        java.awt.Font font17 = valueMarker16.getLabelFont();
        marker10.setLabelFont(font17);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(marker10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(font17);
    }

//    @Test
//    public void test372() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test372");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
//        java.awt.Paint paint3 = xYPlot2.getDomainZeroBaselinePaint();
//        boolean boolean4 = day0.equals((java.lang.Object) paint3);
//        int int5 = day0.getMonth();
//        int int6 = day0.getYear();
//        long long7 = day0.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertNotNull(paint3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560452399999L + "'", long7 == 1560452399999L);
//    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker5 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color3, stroke4);
        org.jfree.chart.util.Layer layer6 = null;
        xYPlot0.addRangeMarker(4, (org.jfree.chart.plot.Marker) categoryMarker5, layer6);
        xYPlot0.setDomainCrosshairVisible(true);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str13 = numberAxis12.getLabel();
        numberAxis12.setVisible(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit16 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis12.setTickUnit(numberTickUnit16, false, false);
        numberAxis12.setAxisLineVisible(false);
        numberAxis12.setAutoTickUnitSelection(true);
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint25 = xYPlot24.getDomainZeroBaselinePaint();
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke28 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker29 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color27, stroke28);
        java.awt.Paint paint30 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryMarker29.setLabelPaint(paint30);
        xYPlot24.setDomainZeroBaselinePaint(paint30);
        java.awt.Stroke stroke33 = xYPlot24.getDomainZeroBaselineStroke();
        numberAxis12.setAxisLineStroke(stroke33);
        numberAxis12.setLabelToolTip("UnitType.RELATIVE");
        double double37 = numberAxis12.getUpperMargin();
        xYPlot0.setDomainAxis(192, (org.jfree.chart.axis.ValueAxis) numberAxis12, false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str13.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(numberTickUnit16);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.05d + "'", double37 == 0.05d);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = numberAxis1.getLabelInsets();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D6 = rectangleInsets2.createInsetRectangle(rectangle2D3, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        java.util.List list7 = categoryPlot0.getCategoriesForAxis(categoryAxis6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot0.getRenderer(3);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.setAnchorValue((double) (-1L), true);
        categoryPlot10.clearDomainAxes();
        boolean boolean15 = categoryPlot0.equals((java.lang.Object) categoryPlot10);
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint18 = xYPlot17.getDomainZeroBaselinePaint();
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        xYPlot17.setDomainAxis(12, valueAxis20);
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke26 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker27 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color25, stroke26);
        xYPlot23.setBackgroundPaint((java.awt.Paint) color25);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        xYPlot23.setRenderer(6, xYItemRenderer30);
        org.jfree.chart.event.PlotChangeListener plotChangeListener32 = null;
        xYPlot23.removeChangeListener(plotChangeListener32);
        org.jfree.chart.util.Layer layer34 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection35 = xYPlot23.getDomainMarkers(layer34);
        java.util.Collection collection36 = xYPlot17.getDomainMarkers(0, layer34);
        java.util.Collection collection37 = categoryPlot0.getDomainMarkers((int) (byte) -1, layer34);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertNull(categoryItemRenderer9);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(layer34);
        org.junit.Assert.assertNull(collection35);
        org.junit.Assert.assertNull(collection36);
        org.junit.Assert.assertNull(collection37);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker5 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color3, stroke4);
        xYPlot1.setBackgroundPaint((java.awt.Paint) color3);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str10 = numberAxis9.getLabel();
        numberAxis9.setVisible(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit13 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis9.setTickUnit(numberTickUnit13, false, false);
        numberAxis9.setAxisLineVisible(false);
        numberAxis9.setAutoTickUnitSelection(true);
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint22 = xYPlot21.getDomainZeroBaselinePaint();
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke25 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color24, stroke25);
        java.awt.Paint paint27 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryMarker26.setLabelPaint(paint27);
        xYPlot21.setDomainZeroBaselinePaint(paint27);
        java.awt.Stroke stroke30 = xYPlot21.getDomainZeroBaselineStroke();
        numberAxis9.setAxisLineStroke(stroke30);
        xYPlot1.setRangeAxis((int) (short) 0, (org.jfree.chart.axis.ValueAxis) numberAxis9);
        org.jfree.chart.axis.TickUnitSource tickUnitSource33 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        numberAxis9.setStandardTickUnits(tickUnitSource33);
        int int35 = objectList0.indexOf((java.lang.Object) numberAxis9);
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = new org.jfree.chart.util.RectangleInsets();
        boolean boolean37 = objectList0.equals((java.lang.Object) rectangleInsets36);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str10.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(numberTickUnit13);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(tickUnitSource33);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        boolean boolean2 = xYPlot0.isRangeGridlinesVisible();
        org.jfree.chart.axis.AxisLocation axisLocation3 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot0.setRangeAxisLocation(axisLocation3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color8, stroke9);
        org.jfree.chart.util.Layer layer11 = null;
        xYPlot5.addRangeMarker(4, (org.jfree.chart.plot.Marker) categoryMarker10, layer11);
        java.awt.Font font13 = categoryMarker10.getLabelFont();
        java.awt.Paint paint14 = categoryMarker10.getPaint();
        xYPlot0.setNoDataMessagePaint(paint14);
        xYPlot0.clearDomainAxes();
        java.awt.Image image17 = null;
        xYPlot0.setBackgroundImage(image17);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str2 = numberAxis1.getLabel();
        java.lang.String str3 = numberAxis1.getLabel();
        java.awt.Paint paint4 = numberAxis1.getAxisLinePaint();
        boolean boolean5 = numberAxis1.isTickLabelsVisible();
        java.awt.Font font6 = numberAxis1.getTickLabelFont();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint10 = xYPlot9.getDomainZeroBaselinePaint();
        boolean boolean11 = xYPlot9.isRangeGridlinesVisible();
        java.awt.Color color14 = java.awt.Color.getColor("hi!", 0);
        xYPlot9.setRangeZeroBaselinePaint((java.awt.Paint) color14);
        java.lang.Object obj16 = xYPlot9.clone();
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = xYPlot9.getRangeAxisEdge();
        try {
            double double18 = numberAxis1.valueToJava2D((double) 11, rectangle2D8, rectangleEdge17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str2.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str3.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(rectangleEdge17);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str2 = numberAxis1.getLabel();
        boolean boolean3 = numberAxis1.isAutoRange();
        org.jfree.data.Range range4 = null;
        try {
            numberAxis1.setRange(range4, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str2.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairLockedOnData(false);
        xYPlot0.setRangeCrosshairValue((double) 255, false);
        xYPlot0.setRangeCrosshairLockedOnData(false);
        xYPlot0.clearDomainMarkers(0);
        java.awt.Paint paint10 = null;
        try {
            xYPlot0.setRangeGridlinePaint(paint10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        java.awt.Paint[] paintArray0 = null;
        java.awt.Paint[] paintArray1 = null;
        java.awt.Paint[] paintArray2 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray3 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.awt.Stroke stroke4 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint6 = xYPlot5.getDomainZeroBaselinePaint();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color8, stroke9);
        java.awt.Paint paint11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryMarker10.setLabelPaint(paint11);
        xYPlot5.setDomainZeroBaselinePaint(paint11);
        java.awt.Stroke stroke14 = xYPlot5.getDomainZeroBaselineStroke();
        java.awt.Stroke stroke15 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker21 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color19, stroke20);
        xYPlot17.setBackgroundPaint((java.awt.Paint) color19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        xYPlot17.setRenderer(6, xYItemRenderer24);
        org.jfree.chart.event.PlotChangeListener plotChangeListener26 = null;
        xYPlot17.removeChangeListener(plotChangeListener26);
        java.awt.Stroke stroke28 = xYPlot17.getDomainZeroBaselineStroke();
        java.awt.Stroke[] strokeArray29 = new java.awt.Stroke[] { stroke4, stroke14, stroke15, stroke16, stroke28 };
        java.awt.Stroke[] strokeArray30 = new java.awt.Stroke[] {};
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str33 = numberAxis32.getLabel();
        java.lang.String str34 = numberAxis32.getLabel();
        java.awt.Paint paint35 = numberAxis32.getAxisLinePaint();
        java.awt.Shape shape36 = numberAxis32.getRightArrow();
        org.jfree.chart.axis.NumberAxis numberAxis38 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str39 = numberAxis38.getLabel();
        java.lang.String str40 = numberAxis38.getLabel();
        java.awt.Paint paint41 = numberAxis38.getAxisLinePaint();
        java.awt.Shape shape42 = numberAxis38.getRightArrow();
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str45 = numberAxis44.getLabel();
        java.lang.String str46 = numberAxis44.getLabel();
        java.awt.Paint paint47 = numberAxis44.getAxisLinePaint();
        java.awt.Shape shape48 = numberAxis44.getRightArrow();
        org.jfree.chart.axis.NumberAxis numberAxis50 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str51 = numberAxis50.getLabel();
        java.lang.String str52 = numberAxis50.getLabel();
        java.awt.Paint paint53 = numberAxis50.getAxisLinePaint();
        java.awt.Shape shape54 = numberAxis50.getRightArrow();
        java.awt.Shape[] shapeArray55 = new java.awt.Shape[] { shape36, shape42, shape48, shape54 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier56 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray2, paintArray3, strokeArray29, strokeArray30, shapeArray55);
        java.awt.Paint paint58 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.plot.XYPlot xYPlot59 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke60 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot59.setDomainGridlineStroke(stroke60);
        org.jfree.chart.plot.ValueMarker valueMarker62 = new org.jfree.chart.plot.ValueMarker(0.0d, paint58, stroke60);
        java.awt.Stroke[] strokeArray63 = new java.awt.Stroke[] { stroke60 };
        java.awt.Shape[] shapeArray64 = null;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier65 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, strokeArray30, strokeArray63, shapeArray64);
        java.awt.Paint paint66 = defaultDrawingSupplier65.getNextFillPaint();
        java.lang.Object obj67 = defaultDrawingSupplier65.clone();
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertNotNull(paintArray3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(strokeArray29);
        org.junit.Assert.assertNotNull(strokeArray30);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str33.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str34.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str39.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str40.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str45.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str46.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(shape48);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str51.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str52.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint53);
        org.junit.Assert.assertNotNull(shape54);
        org.junit.Assert.assertNotNull(shapeArray55);
        org.junit.Assert.assertNotNull(paint58);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertNotNull(strokeArray63);
        org.junit.Assert.assertNotNull(paint66);
        org.junit.Assert.assertNotNull(obj67);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation3 = xYPlot0.getOrientation();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.awt.Paint paint6 = numberAxis5.getLabelPaint();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = numberAxis5.valueToJava2D(0.0d, rectangle2D8, rectangleEdge9);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray11 = new org.jfree.chart.axis.ValueAxis[] { numberAxis5 };
        xYPlot0.setDomainAxes(valueAxisArray11);
        xYPlot0.clearRangeMarkers();
        org.junit.Assert.assertNotNull(plotOrientation3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(valueAxisArray11);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str2 = numberAxis1.getLabel();
        boolean boolean3 = numberAxis1.isAutoRange();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        numberAxis1.setTickMarkPaint((java.awt.Paint) color4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str2.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color2, stroke3);
        xYPlot0.setBackgroundPaint((java.awt.Paint) color2);
        xYPlot0.setOutlineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        xYPlot0.setRenderer(9, xYItemRenderer9, false);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.util.List list14 = null;
        xYPlot0.drawDomainTickBands(graphics2D12, rectangle2D13, list14);
        int int16 = xYPlot0.getWeight();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int3 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis2);
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color6, stroke7);
        xYPlot4.setBackgroundPaint((java.awt.Paint) color6);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        xYPlot4.setRenderer(6, xYItemRenderer11);
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = xYPlot4.getRangeMarkers((int) ' ', layer14);
        boolean boolean16 = numberAxis2.hasListener((java.util.EventListener) xYPlot4);
        java.lang.String str17 = numberAxis2.getLabelURL();
        org.jfree.data.RangeType rangeType18 = numberAxis2.getRangeType();
        numberAxis2.setAutoRangeStickyZero(true);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(rangeType18);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str3 = numberAxis2.getLabel();
        numberAxis2.setVisible(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit6 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis2.setTickUnit(numberTickUnit6, false, false);
        numberAxis2.setLabelURL("SeriesRenderingOrder.FORWARD");
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker16 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color14, stroke15);
        xYPlot12.setBackgroundPaint((java.awt.Paint) color14);
        xYPlot12.setOutlineVisible(false);
        java.awt.Stroke stroke20 = xYPlot12.getRangeGridlineStroke();
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str24 = numberAxis23.getLabel();
        numberAxis23.setVisible(false);
        xYPlot12.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis23, true);
        org.jfree.data.RangeType rangeType29 = numberAxis23.getRangeType();
        double double30 = numberAxis23.getLabelAngle();
        numberAxis23.setTickMarkOutsideLength((float) (byte) 10);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = null;
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis23, xYItemRenderer33);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str3.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(numberTickUnit6);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str24.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(rangeType29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainZoomable();
        org.jfree.chart.axis.AxisSpace axisSpace2 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace2, true);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.setRangeCrosshairLockedOnData(false);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        xYPlot5.setDataset(xYDataset8);
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.awt.Paint paint12 = numberAxis11.getLabelPaint();
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        double double16 = numberAxis11.valueToJava2D(0.0d, rectangle2D14, rectangleEdge15);
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = null;
        double double20 = numberAxis11.java2DToValue((double) 0L, rectangle2D18, rectangleEdge19);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double22 = rectangleInsets21.getTop();
        double double24 = rectangleInsets21.calculateBottomOutset((double) 1);
        numberAxis11.setLabelInsets(rectangleInsets21);
        numberAxis11.resizeRange((double) 100, (double) 10.0f);
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color31 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke32 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker33 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color31, stroke32);
        xYPlot29.setBackgroundPaint((java.awt.Paint) color31);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer36 = null;
        xYPlot29.setRenderer(6, xYItemRenderer36);
        org.jfree.chart.util.Layer layer39 = null;
        java.util.Collection collection40 = xYPlot29.getRangeMarkers((int) ' ', layer39);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder41 = xYPlot29.getDatasetRenderingOrder();
        xYPlot29.setRangeZeroBaselineVisible(false);
        numberAxis11.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot29);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray45 = new org.jfree.chart.axis.ValueAxis[] { numberAxis11 };
        xYPlot5.setDomainAxes(valueAxisArray45);
        categoryPlot0.setRangeAxes(valueAxisArray45);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 2.0d + "'", double22 == 2.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 2.0d + "'", double24 == 2.0d);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNull(collection40);
        org.junit.Assert.assertNotNull(datasetRenderingOrder41);
        org.junit.Assert.assertNotNull(valueAxisArray45);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation3 = xYPlot0.getOrientation();
        boolean boolean4 = xYPlot0.isDomainZoomable();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str8 = numberAxis7.getLabel();
        java.lang.String str9 = numberAxis7.getLabel();
        java.awt.Paint paint10 = numberAxis7.getAxisLinePaint();
        java.awt.Shape shape11 = numberAxis7.getRightArrow();
        boolean boolean12 = numberAxis7.isAutoRange();
        xYPlot0.setRangeAxis(8, (org.jfree.chart.axis.ValueAxis) numberAxis7);
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = xYPlot0.getRendererForDataset(xYDataset14);
        org.junit.Assert.assertNotNull(plotOrientation3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str8.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str9.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(xYItemRenderer15);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int3 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis2);
        numberAxis2.setLowerBound((double) (short) 10);
        boolean boolean6 = numberAxis2.isTickMarksVisible();
        float float7 = numberAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str10 = numberAxis9.getLabel();
        numberAxis9.setVisible(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit13 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis9.setTickUnit(numberTickUnit13, false, false);
        numberAxis9.setAxisLineVisible(false);
        numberAxis9.setAutoTickUnitSelection(true);
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint22 = xYPlot21.getDomainZeroBaselinePaint();
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke25 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color24, stroke25);
        java.awt.Paint paint27 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryMarker26.setLabelPaint(paint27);
        xYPlot21.setDomainZeroBaselinePaint(paint27);
        java.awt.Stroke stroke30 = xYPlot21.getDomainZeroBaselineStroke();
        numberAxis9.setAxisLineStroke(stroke30);
        java.awt.Shape shape32 = numberAxis9.getRightArrow();
        numberAxis2.setDownArrow(shape32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str10.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(numberTickUnit13);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(shape32);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        java.util.List list7 = categoryPlot0.getCategoriesForAxis(categoryAxis6);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int11 = xYPlot8.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        java.awt.Stroke stroke12 = numberAxis10.getAxisLineStroke();
        numberAxis10.setVisible(false);
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker19 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color17, stroke18);
        xYPlot15.setBackgroundPaint((java.awt.Paint) color17);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        xYPlot15.setRenderer(6, xYItemRenderer22);
        org.jfree.chart.event.PlotChangeListener plotChangeListener24 = null;
        xYPlot15.removeChangeListener(plotChangeListener24);
        java.awt.Stroke stroke26 = xYPlot15.getDomainZeroBaselineStroke();
        numberAxis10.setTickMarkStroke(stroke26);
        categoryPlot0.setRangeCrosshairStroke(stroke26);
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = categoryPlot0.getDomainAxisEdge(11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = categoryPlot0.getRenderer();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer32 = null;
        categoryPlot0.setRenderer(categoryItemRenderer32, true);
        java.awt.Graphics2D graphics2D35 = null;
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        org.jfree.chart.plot.XYPlot xYPlot37 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint38 = xYPlot37.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis42 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int43 = xYPlot40.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis42);
        numberAxis42.setLowerBound((double) (short) 10);
        xYPlot37.setDomainAxis((int) (byte) 1, (org.jfree.chart.axis.ValueAxis) numberAxis42, true);
        java.awt.Paint paint48 = xYPlot37.getDomainZeroBaselinePaint();
        org.jfree.chart.axis.AxisSpace axisSpace49 = null;
        xYPlot37.setFixedRangeAxisSpace(axisSpace49);
        org.jfree.chart.plot.XYPlot xYPlot51 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke52 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot51.setDomainGridlineStroke(stroke52);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo55 = null;
        java.awt.geom.Point2D point2D56 = null;
        xYPlot51.zoomDomainAxes(100.0d, plotRenderingInfo55, point2D56, false);
        java.awt.Stroke stroke59 = xYPlot51.getDomainCrosshairStroke();
        xYPlot37.setRangeZeroBaselineStroke(stroke59);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer61 = xYPlot37.getRenderer();
        org.jfree.data.xy.XYDataset xYDataset62 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer63 = xYPlot37.getRendererForDataset(xYDataset62);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo65 = null;
        java.awt.geom.Rectangle2D rectangle2D66 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor67 = null;
        java.awt.geom.Point2D point2D68 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D66, rectangleAnchor67);
        xYPlot37.zoomDomainAxes((double) 4, plotRenderingInfo65, point2D68);
        org.jfree.chart.plot.PlotState plotState70 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo71 = null;
        try {
            categoryPlot0.draw(graphics2D35, rectangle2D36, point2D68, plotState70, plotRenderingInfo71);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertNull(categoryItemRenderer31);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertNull(xYItemRenderer61);
        org.junit.Assert.assertNull(xYItemRenderer63);
        org.junit.Assert.assertNotNull(point2D68);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color6, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color10, stroke11);
        categoryMarker8.setLabelPaint((java.awt.Paint) color10);
        org.jfree.chart.util.Layer layer14 = null;
        categoryPlot0.addRangeMarker((int) (short) 1, (org.jfree.chart.plot.Marker) categoryMarker8, layer14, false);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray17 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot0.setDomainAxes(categoryAxisArray17);
        java.lang.String str19 = categoryPlot0.getPlotType();
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = categoryPlot0.getRendererForDataset(categoryDataset20);
        int int22 = categoryPlot0.getDatasetCount();
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(categoryAxisArray17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Category Plot" + "'", str19.equals("Category Plot"));
        org.junit.Assert.assertNull(categoryItemRenderer21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int6 = xYPlot3.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis5);
        numberAxis5.setLowerBound((double) (short) 10);
        xYPlot0.setDomainAxis((int) (byte) 1, (org.jfree.chart.axis.ValueAxis) numberAxis5, true);
        java.awt.Paint paint11 = xYPlot0.getDomainZeroBaselinePaint();
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        xYPlot0.setQuadrantPaint((int) (byte) 1, (java.awt.Paint) color13);
        org.jfree.chart.plot.Plot plot15 = xYPlot0.getParent();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNull(plot15);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double1 = rectangleInsets0.getTop();
        java.lang.String str2 = rectangleInsets0.toString();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType4 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        java.lang.Object obj5 = null;
        boolean boolean6 = lengthAdjustmentType4.equals(obj5);
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker((double) 'a');
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType9 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        java.lang.Object obj10 = null;
        boolean boolean11 = lengthAdjustmentType9.equals(obj10);
        valueMarker8.setLabelOffsetType(lengthAdjustmentType9);
        try {
            java.awt.geom.Rectangle2D rectangle2D13 = rectangleInsets0.createAdjustedRectangle(rectangle2D3, lengthAdjustmentType4, lengthAdjustmentType9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str2.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
        org.junit.Assert.assertNotNull(lengthAdjustmentType4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(lengthAdjustmentType9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, 12.0d, (double) (short) 10, (-8.0d), (double) '4');
        org.junit.Assert.assertNotNull(unitType0);
    }

//    @Test
//    public void test395() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test395");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        int int2 = day0.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
//        long long4 = day0.getLastMillisecond();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = day0.getFirstMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560495599999L + "'", long4 == 1560495599999L);
//    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        categoryPlot0.setRangeCrosshairVisible(true);
        categoryPlot0.setDrawSharedDomainAxis(false);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot0.getRendererForDataset(categoryDataset8);
        org.junit.Assert.assertNull(categoryItemRenderer9);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int3 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis2);
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color6, stroke7);
        xYPlot4.setBackgroundPaint((java.awt.Paint) color6);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        xYPlot4.setRenderer(6, xYItemRenderer11);
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = xYPlot4.getRangeMarkers((int) ' ', layer14);
        boolean boolean16 = numberAxis2.hasListener((java.util.EventListener) xYPlot4);
        java.lang.Object obj17 = numberAxis2.clone();
        boolean boolean18 = numberAxis2.isAutoTickUnitSelection();
        java.awt.Stroke stroke19 = numberAxis2.getTickMarkStroke();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(stroke19);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int3 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis2);
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color6, stroke7);
        xYPlot4.setBackgroundPaint((java.awt.Paint) color6);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        xYPlot4.setRenderer(6, xYItemRenderer11);
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = xYPlot4.getRangeMarkers((int) ' ', layer14);
        boolean boolean16 = numberAxis2.hasListener((java.util.EventListener) xYPlot4);
        java.awt.Paint paint17 = xYPlot4.getRangeZeroBaselinePaint();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent18 = null;
        xYPlot4.rendererChanged(rendererChangeEvent18);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        java.lang.String str1 = datasetRenderingOrder0.toString();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.awt.Paint paint4 = numberAxis3.getLabelPaint();
        boolean boolean5 = datasetRenderingOrder0.equals((java.lang.Object) numberAxis3);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint7 = xYPlot6.getDomainZeroBaselinePaint();
        boolean boolean8 = xYPlot6.isRangeGridlinesVisible();
        java.awt.Color color11 = java.awt.Color.getColor("hi!", 0);
        xYPlot6.setRangeZeroBaselinePaint((java.awt.Paint) color11);
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint14 = xYPlot13.getDomainZeroBaselinePaint();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color16, stroke17);
        java.awt.Paint paint19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryMarker18.setLabelPaint(paint19);
        xYPlot13.setDomainZeroBaselinePaint(paint19);
        java.awt.Stroke stroke22 = xYPlot13.getDomainZeroBaselineStroke();
        xYPlot6.setParent((org.jfree.chart.plot.Plot) xYPlot13);
        boolean boolean24 = datasetRenderingOrder0.equals((java.lang.Object) xYPlot6);
        boolean boolean25 = xYPlot6.isRangeCrosshairVisible();
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DatasetRenderingOrder.REVERSE" + "'", str1.equals("DatasetRenderingOrder.REVERSE"));
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color6, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color10, stroke11);
        categoryMarker8.setLabelPaint((java.awt.Paint) color10);
        org.jfree.chart.util.Layer layer14 = null;
        categoryPlot0.addRangeMarker((int) (short) 1, (org.jfree.chart.plot.Marker) categoryMarker8, layer14, false);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray17 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot0.setDomainAxes(categoryAxisArray17);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        int int20 = categoryPlot0.getIndexOf(categoryItemRenderer19);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = categoryPlot0.getDomainAxis(100);
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.axis.AxisLocation axisLocation25 = categoryPlot0.getRangeAxisLocation((int) '#');
        org.jfree.chart.axis.AxisSpace axisSpace26 = categoryPlot0.getFixedRangeAxisSpace();
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(categoryAxisArray17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNull(categoryAxis22);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertNull(axisSpace26);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        java.util.List list7 = categoryPlot0.getCategoriesForAxis(categoryAxis6);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int11 = xYPlot8.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        java.awt.Stroke stroke12 = numberAxis10.getAxisLineStroke();
        numberAxis10.setVisible(false);
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker19 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color17, stroke18);
        xYPlot15.setBackgroundPaint((java.awt.Paint) color17);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        xYPlot15.setRenderer(6, xYItemRenderer22);
        org.jfree.chart.event.PlotChangeListener plotChangeListener24 = null;
        xYPlot15.removeChangeListener(plotChangeListener24);
        java.awt.Stroke stroke26 = xYPlot15.getDomainZeroBaselineStroke();
        numberAxis10.setTickMarkStroke(stroke26);
        categoryPlot0.setRangeCrosshairStroke(stroke26);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        java.awt.geom.Point2D point2D31 = null;
        categoryPlot0.zoomDomainAxes(0.0d, plotRenderingInfo30, point2D31, false);
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str36 = numberAxis35.getLabel();
        boolean boolean37 = numberAxis35.isAutoRange();
        boolean boolean38 = numberAxis35.isNegativeArrowVisible();
        org.jfree.chart.axis.NumberAxis numberAxis40 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str41 = numberAxis40.getLabel();
        numberAxis40.setVisible(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit44 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis40.setTickUnit(numberTickUnit44, false, false);
        numberAxis40.setAxisLineVisible(false);
        numberAxis40.setAutoTickUnitSelection(true);
        org.jfree.chart.plot.XYPlot xYPlot52 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint53 = xYPlot52.getDomainZeroBaselinePaint();
        java.awt.Color color55 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke56 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker57 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color55, stroke56);
        java.awt.Paint paint58 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryMarker57.setLabelPaint(paint58);
        xYPlot52.setDomainZeroBaselinePaint(paint58);
        java.awt.Stroke stroke61 = xYPlot52.getDomainZeroBaselineStroke();
        numberAxis40.setAxisLineStroke(stroke61);
        java.awt.Shape shape63 = numberAxis40.getRightArrow();
        numberAxis35.setRightArrow(shape63);
        int int65 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis35);
        org.jfree.chart.plot.XYPlot xYPlot66 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke67 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot66.setDomainGridlineStroke(stroke67);
        java.awt.Stroke stroke69 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        xYPlot66.setRangeGridlineStroke(stroke69);
        categoryPlot0.setDomainGridlineStroke(stroke69);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str36.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str41.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(numberTickUnit44);
        org.junit.Assert.assertNotNull(paint53);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertNotNull(paint58);
        org.junit.Assert.assertNotNull(stroke61);
        org.junit.Assert.assertNotNull(shape63);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-1) + "'", int65 == (-1));
        org.junit.Assert.assertNotNull(stroke67);
        org.junit.Assert.assertNotNull(stroke69);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation6 = categoryPlot0.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot0.getRangeAxis((int) '4');
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation10 = null;
        try {
            boolean boolean11 = categoryPlot0.removeAnnotation(categoryAnnotation10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertNotNull(axisLocation9);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color1, stroke2);
        java.awt.Paint paint4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryMarker3.setLabelPaint(paint4);
        java.awt.Paint paint6 = null;
        categoryMarker3.setOutlinePaint(paint6);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        boolean boolean2 = xYPlot0.isRangeGridlinesVisible();
        org.jfree.chart.axis.AxisLocation axisLocation3 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot0.setRangeAxisLocation(axisLocation3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color8, stroke9);
        org.jfree.chart.util.Layer layer11 = null;
        xYPlot5.addRangeMarker(4, (org.jfree.chart.plot.Marker) categoryMarker10, layer11);
        java.awt.Font font13 = categoryMarker10.getLabelFont();
        java.awt.Paint paint14 = categoryMarker10.getPaint();
        xYPlot0.setNoDataMessagePaint(paint14);
        org.jfree.chart.plot.Marker marker16 = null;
        try {
            boolean boolean17 = xYPlot0.removeRangeMarker(marker16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int3 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis2);
        numberAxis2.setLowerBound((double) (short) 10);
        boolean boolean6 = numberAxis2.isTickMarksVisible();
        numberAxis2.setLowerMargin((double) 100);
        double double9 = numberAxis2.getAutoRangeMinimumSize();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0E-8d + "'", double9 == 1.0E-8d);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color2, stroke3);
        xYPlot0.setBackgroundPaint((java.awt.Paint) color2);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        xYPlot0.setRenderer(6, xYItemRenderer7);
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        xYPlot0.removeChangeListener(plotChangeListener9);
        xYPlot0.setRangeZeroBaselineVisible(true);
        xYPlot0.clearRangeMarkers(8);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int6 = xYPlot3.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis5);
        numberAxis5.setLowerBound((double) (short) 10);
        xYPlot0.setDomainAxis((int) (byte) 1, (org.jfree.chart.axis.ValueAxis) numberAxis5, true);
        java.awt.Paint paint11 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.axis.AxisSpace axisSpace12 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace12);
        float float14 = xYPlot0.getBackgroundAlpha();
        xYPlot0.setRangeZeroBaselineVisible(false);
        java.awt.Stroke stroke17 = xYPlot0.getRangeCrosshairStroke();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 1.0f + "'", float14 == 1.0f);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        boolean boolean2 = xYPlot0.isRangeGridlinesVisible();
        java.awt.Color color5 = java.awt.Color.getColor("hi!", 0);
        xYPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color5);
        org.jfree.chart.axis.ValueAxis valueAxis7 = xYPlot0.getDomainAxis();
        org.jfree.chart.plot.Plot plot8 = xYPlot0.getParent();
        java.awt.Image image9 = null;
        try {
            plot8.setBackgroundImage(image9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNull(plot8);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        java.util.List list7 = categoryPlot0.getCategoriesForAxis(categoryAxis6);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int11 = xYPlot8.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        java.awt.Stroke stroke12 = numberAxis10.getAxisLineStroke();
        numberAxis10.setVisible(false);
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker19 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color17, stroke18);
        xYPlot15.setBackgroundPaint((java.awt.Paint) color17);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        xYPlot15.setRenderer(6, xYItemRenderer22);
        org.jfree.chart.event.PlotChangeListener plotChangeListener24 = null;
        xYPlot15.removeChangeListener(plotChangeListener24);
        java.awt.Stroke stroke26 = xYPlot15.getDomainZeroBaselineStroke();
        numberAxis10.setTickMarkStroke(stroke26);
        categoryPlot0.setRangeCrosshairStroke(stroke26);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        java.awt.geom.Point2D point2D31 = null;
        categoryPlot0.zoomDomainAxes(0.0d, plotRenderingInfo30, point2D31, false);
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str36 = numberAxis35.getLabel();
        boolean boolean37 = numberAxis35.isAutoRange();
        boolean boolean38 = numberAxis35.isNegativeArrowVisible();
        org.jfree.chart.axis.NumberAxis numberAxis40 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str41 = numberAxis40.getLabel();
        numberAxis40.setVisible(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit44 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis40.setTickUnit(numberTickUnit44, false, false);
        numberAxis40.setAxisLineVisible(false);
        numberAxis40.setAutoTickUnitSelection(true);
        org.jfree.chart.plot.XYPlot xYPlot52 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint53 = xYPlot52.getDomainZeroBaselinePaint();
        java.awt.Color color55 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke56 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker57 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color55, stroke56);
        java.awt.Paint paint58 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryMarker57.setLabelPaint(paint58);
        xYPlot52.setDomainZeroBaselinePaint(paint58);
        java.awt.Stroke stroke61 = xYPlot52.getDomainZeroBaselineStroke();
        numberAxis40.setAxisLineStroke(stroke61);
        java.awt.Shape shape63 = numberAxis40.getRightArrow();
        numberAxis35.setRightArrow(shape63);
        int int65 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis35);
        org.jfree.chart.util.RectangleEdge rectangleEdge66 = categoryPlot0.getDomainAxisEdge();
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str36.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str41.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(numberTickUnit44);
        org.junit.Assert.assertNotNull(paint53);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertNotNull(paint58);
        org.junit.Assert.assertNotNull(stroke61);
        org.junit.Assert.assertNotNull(shape63);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-1) + "'", int65 == (-1));
        org.junit.Assert.assertNotNull(rectangleEdge66);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        java.awt.Color color0 = java.awt.Color.cyan;
        org.jfree.data.general.Dataset dataset1 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent2 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) color0, dataset1);
        org.jfree.data.general.Dataset dataset3 = datasetChangeEvent2.getDataset();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNull(dataset3);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int3 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        xYPlot0.setRangeCrosshairPaint((java.awt.Paint) color4);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        xYPlot6.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation9 = xYPlot6.getOrientation();
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.awt.Paint paint12 = numberAxis11.getLabelPaint();
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        double double16 = numberAxis11.valueToJava2D(0.0d, rectangle2D14, rectangleEdge15);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray17 = new org.jfree.chart.axis.ValueAxis[] { numberAxis11 };
        xYPlot6.setDomainAxes(valueAxisArray17);
        xYPlot0.setRangeAxes(valueAxisArray17);
        java.awt.Paint paint20 = xYPlot0.getDomainGridlinePaint();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(plotOrientation9);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(valueAxisArray17);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color2, stroke3);
        xYPlot0.setBackgroundPaint((java.awt.Paint) color2);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        xYPlot0.setRenderer(6, xYItemRenderer7);
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        xYPlot0.removeChangeListener(plotChangeListener9);
        org.jfree.chart.util.Layer layer11 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection12 = xYPlot0.getDomainMarkers(layer11);
        int int13 = xYPlot0.getRangeAxisCount();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str16 = numberAxis15.getLabel();
        java.lang.String str17 = numberAxis15.getLabel();
        java.awt.Paint paint18 = numberAxis15.getAxisLinePaint();
        boolean boolean19 = numberAxis15.isTickLabelsVisible();
        java.awt.Font font20 = numberAxis15.getTickLabelFont();
        java.awt.Color color21 = java.awt.Color.blue;
        numberAxis15.setLabelPaint((java.awt.Paint) color21);
        org.jfree.data.Range range23 = xYPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis15);
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int27 = xYPlot24.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis26);
        double double28 = numberAxis26.getFixedAutoRange();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit29 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis26.setTickUnit(numberTickUnit29);
        numberAxis15.setTickUnit(numberTickUnit29, false, false);
        numberAxis15.setInverted(true);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(layer11);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str16.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str17.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNull(range23);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(numberTickUnit29);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        int int1 = color0.getBlue();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str2 = numberAxis1.getLabel();
        numberAxis1.setVisible(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis1.setTickUnit(numberTickUnit5, false, false);
        numberAxis1.setAxisLineVisible(false);
        numberAxis1.setAutoTickUnitSelection(true);
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint14 = xYPlot13.getDomainZeroBaselinePaint();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color16, stroke17);
        java.awt.Paint paint19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryMarker18.setLabelPaint(paint19);
        xYPlot13.setDomainZeroBaselinePaint(paint19);
        java.awt.Stroke stroke22 = xYPlot13.getDomainZeroBaselineStroke();
        numberAxis1.setAxisLineStroke(stroke22);
        numberAxis1.setLabelURL("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        float float26 = numberAxis1.getTickMarkOutsideLength();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str2.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(numberTickUnit5);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 2.0f + "'", float26 == 2.0f);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str2 = numberAxis1.getLabel();
        java.lang.String str3 = numberAxis1.getLabel();
        java.awt.Paint paint4 = numberAxis1.getAxisLinePaint();
        java.awt.Shape shape5 = numberAxis1.getRightArrow();
        boolean boolean6 = numberAxis1.isAutoRange();
        boolean boolean7 = numberAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.awt.Paint paint10 = numberAxis9.getLabelPaint();
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        double double14 = numberAxis9.valueToJava2D(0.0d, rectangle2D12, rectangleEdge13);
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = null;
        double double18 = numberAxis9.java2DToValue((double) 0L, rectangle2D16, rectangleEdge17);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double20 = rectangleInsets19.getTop();
        double double22 = rectangleInsets19.calculateBottomOutset((double) 1);
        numberAxis9.setLabelInsets(rectangleInsets19);
        double double25 = rectangleInsets19.calculateBottomInset((double) 0);
        numberAxis1.setLabelInsets(rectangleInsets19);
        java.awt.Graphics2D graphics2D27 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot();
        xYPlot31.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation34 = xYPlot31.getOrientation();
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.awt.Paint paint37 = numberAxis36.getLabelPaint();
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = null;
        double double41 = numberAxis36.valueToJava2D(0.0d, rectangle2D39, rectangleEdge40);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray42 = new org.jfree.chart.axis.ValueAxis[] { numberAxis36 };
        xYPlot31.setDomainAxes(valueAxisArray42);
        org.jfree.chart.plot.XYPlot xYPlot44 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color46 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke47 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker48 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color46, stroke47);
        xYPlot44.setBackgroundPaint((java.awt.Paint) color46);
        xYPlot31.setRangeCrosshairPaint((java.awt.Paint) color46);
        org.jfree.chart.util.RectangleEdge rectangleEdge52 = xYPlot31.getRangeAxisEdge(0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo53 = null;
        try {
            org.jfree.chart.axis.AxisState axisState54 = numberAxis1.draw(graphics2D27, 0.0d, rectangle2D29, rectangle2D30, rectangleEdge52, plotRenderingInfo53);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str2.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str3.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 2.0d + "'", double20 == 2.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 2.0d + "'", double22 == 2.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 2.0d + "'", double25 == 2.0d);
        org.junit.Assert.assertNotNull(plotOrientation34);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(valueAxisArray42);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(rectangleEdge52);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        boolean boolean2 = xYPlot0.isRangeGridlinesVisible();
        java.awt.Color color5 = java.awt.Color.getColor("hi!", 0);
        xYPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color5);
        org.jfree.chart.axis.ValueAxis valueAxis7 = xYPlot0.getDomainAxis();
        org.jfree.chart.axis.AxisLocation axisLocation8 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot0.setRangeAxisLocation(axisLocation8, true);
        java.awt.Paint paint11 = xYPlot0.getRangeTickBandPaint();
        boolean boolean12 = xYPlot0.isDomainCrosshairVisible();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj2 = objectList0.get(0);
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        xYPlot3.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        xYPlot3.setRenderer((int) (byte) 1, xYItemRenderer7);
        double double9 = xYPlot3.getRangeCrosshairValue();
        int int10 = objectList0.indexOf((java.lang.Object) xYPlot3);
        java.lang.Object obj11 = objectList0.clone();
        java.lang.Object obj13 = objectList0.get(8);
        org.junit.Assert.assertNull(obj2);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNull(obj13);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainZoomable();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        categoryPlot0.zoomRangeAxes((double) 8, plotRenderingInfo3, point2D4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.Color color10 = java.awt.Color.RED;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        xYPlot11.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = xYPlot11.getOrientation();
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.awt.Paint paint17 = numberAxis16.getLabelPaint();
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = numberAxis16.valueToJava2D(0.0d, rectangle2D19, rectangleEdge20);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray22 = new org.jfree.chart.axis.ValueAxis[] { numberAxis16 };
        xYPlot11.setDomainAxes(valueAxisArray22);
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke27 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker28 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color26, stroke27);
        xYPlot24.setBackgroundPaint((java.awt.Paint) color26);
        xYPlot11.setRangeCrosshairPaint((java.awt.Paint) color26);
        float[] floatArray35 = new float[] { (byte) 1, 10L, 100.0f, 100.0f };
        float[] floatArray36 = color26.getComponents(floatArray35);
        float[] floatArray37 = color10.getRGBComponents(floatArray36);
        float[] floatArray38 = java.awt.Color.RGBtoHSB((int) (byte) 1, (int) (byte) 1, 0, floatArray37);
        float[] floatArray39 = color6.getRGBColorComponents(floatArray38);
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo43 = null;
        java.awt.geom.Point2D point2D44 = null;
        categoryPlot0.zoomDomainAxes(2.0d, (double) '#', plotRenderingInfo43, point2D44);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(valueAxisArray22);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(floatArray35);
        org.junit.Assert.assertNotNull(floatArray36);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertNotNull(floatArray38);
        org.junit.Assert.assertNotNull(floatArray39);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int3 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis2);
        java.awt.Stroke stroke4 = numberAxis2.getAxisLineStroke();
        numberAxis2.setVisible(false);
        java.awt.Paint paint7 = numberAxis2.getAxisLinePaint();
        java.awt.Shape shape8 = numberAxis2.getLeftArrow();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(shape8);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color9, stroke10);
        org.jfree.chart.util.Layer layer12 = null;
        xYPlot6.addRangeMarker(4, (org.jfree.chart.plot.Marker) categoryMarker11, layer12);
        java.awt.Font font14 = categoryMarker11.getLabelFont();
        java.awt.Paint paint15 = categoryMarker11.getPaint();
        org.jfree.chart.util.Layer layer16 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean17 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker11, layer16);
        categoryPlot0.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = categoryPlot0.getDomainAxisEdge(3);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(layer16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(rectangleEdge21);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str2 = numberAxis1.getLabel();
        numberAxis1.setVisible(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis1.setTickUnit(numberTickUnit5, false, false);
        numberAxis1.setAxisLineVisible(false);
        numberAxis1.setAutoTickUnitSelection(true);
        double double13 = numberAxis1.getFixedDimension();
        boolean boolean14 = numberAxis1.getAutoRangeIncludesZero();
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        xYPlot15.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        xYPlot15.setRenderer((int) (byte) 1, xYItemRenderer19);
        double double21 = xYPlot15.getRangeCrosshairValue();
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int25 = xYPlot22.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis24);
        boolean boolean26 = xYPlot15.equals((java.lang.Object) xYPlot22);
        xYPlot15.setForegroundAlpha((float) 10L);
        numberAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot15);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str2.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(numberTickUnit5);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        java.util.List list7 = categoryPlot0.getCategoriesForAxis(categoryAxis6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot0.getRenderer(3);
        int int10 = categoryPlot0.getWeight();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor11 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        categoryPlot0.setDomainGridlinePosition(categoryAnchor11);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertNull(categoryItemRenderer9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(categoryAnchor11);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str1 = xYPlot0.getNoDataMessage();
        xYPlot0.configureRangeAxes();
        xYPlot0.clearRangeAxes();
        org.jfree.chart.axis.ValueAxis valueAxis5 = xYPlot0.getRangeAxisForDataset(0);
        xYPlot0.configureDomainAxes();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNull(valueAxis5);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        java.util.List list7 = categoryPlot0.getCategoriesForAxis(categoryAxis6);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int11 = xYPlot8.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        java.awt.Stroke stroke12 = numberAxis10.getAxisLineStroke();
        numberAxis10.setVisible(false);
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker19 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color17, stroke18);
        xYPlot15.setBackgroundPaint((java.awt.Paint) color17);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        xYPlot15.setRenderer(6, xYItemRenderer22);
        org.jfree.chart.event.PlotChangeListener plotChangeListener24 = null;
        xYPlot15.removeChangeListener(plotChangeListener24);
        java.awt.Stroke stroke26 = xYPlot15.getDomainZeroBaselineStroke();
        numberAxis10.setTickMarkStroke(stroke26);
        categoryPlot0.setRangeCrosshairStroke(stroke26);
        org.jfree.chart.axis.AxisSpace axisSpace29 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace29);
        org.jfree.chart.axis.AxisLocation axisLocation31 = categoryPlot0.getRangeAxisLocation();
        categoryPlot0.clearRangeMarkers();
        java.awt.Stroke stroke33 = categoryPlot0.getRangeCrosshairStroke();
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertNotNull(stroke33);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str2 = numberAxis1.getLabel();
        numberAxis1.setVisible(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis1.setTickUnit(numberTickUnit5, false, false);
        numberAxis1.setAxisLineVisible(false);
        numberAxis1.setLabelToolTip("TextAnchor.HALF_ASCENT_LEFT");
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = numberAxis1.getLabelInsets();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str2.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(numberTickUnit5);
        org.junit.Assert.assertNotNull(rectangleInsets13);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        java.util.List list7 = categoryPlot0.getCategoriesForAxis(categoryAxis6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        boolean boolean12 = categoryPlot0.render(graphics2D8, rectangle2D9, (-1), plotRenderingInfo11);
        categoryPlot0.clearAnnotations();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor14 = org.jfree.chart.axis.CategoryAnchor.END;
        categoryPlot0.setDomainGridlinePosition(categoryAnchor14);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot16.setAnchorValue((double) (-1L), true);
        java.awt.Paint paint20 = categoryPlot16.getDomainGridlinePaint();
        categoryPlot0.setDomainGridlinePaint(paint20);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(categoryAnchor14);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str2 = numberAxis1.getLabel();
        java.lang.String str3 = numberAxis1.getLabel();
        java.awt.Paint paint4 = numberAxis1.getAxisLinePaint();
        numberAxis1.centerRange(0.0d);
        numberAxis1.setVisible(false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str2.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str3.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str2 = numberAxis1.getLabel();
        numberAxis1.setVisible(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis1.setTickUnit(numberTickUnit5, false, false);
        boolean boolean9 = numberAxis1.isAutoRange();
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str11 = xYPlot10.getNoDataMessage();
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        xYPlot10.setDataset(0, xYDataset13);
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke16 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot15.setDomainGridlineStroke(stroke16);
        java.awt.Stroke stroke18 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        xYPlot15.setRangeGridlineStroke(stroke18);
        xYPlot10.setOutlineStroke(stroke18);
        numberAxis1.setAxisLineStroke(stroke18);
        numberAxis1.setUpperMargin((double) 128);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str2.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(numberTickUnit5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(0.0d);
        double double2 = valueMarker1.getValue();
        valueMarker1.setValue((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker5 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color3, stroke4);
        java.awt.Paint paint6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryMarker5.setLabelPaint(paint6);
        xYPlot0.setDomainZeroBaselinePaint(paint6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot9.setAnchorValue((double) (-1L), true);
        categoryPlot9.setRangeCrosshairVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation15 = categoryPlot9.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis17 = categoryPlot9.getRangeAxis((int) '4');
        categoryPlot9.setAnchorValue((double) (-1L));
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryPlot9.setRangeCrosshairStroke(stroke20);
        xYPlot0.setOutlineStroke(stroke20);
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke26 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker27 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color25, stroke26);
        xYPlot23.setBackgroundPaint((java.awt.Paint) color25);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        xYPlot23.setRenderer(6, xYItemRenderer30);
        xYPlot23.configureRangeAxes();
        java.awt.Paint paint33 = xYPlot23.getRangeTickBandPaint();
        java.awt.Color color35 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke36 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker37 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color35, stroke36);
        org.jfree.data.general.Dataset dataset39 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent40 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) 100, dataset39);
        boolean boolean41 = categoryMarker37.equals((java.lang.Object) 100);
        org.jfree.chart.util.Layer layer42 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot23.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker37, layer42);
        boolean boolean44 = xYPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker37);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNull(valueAxis17);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNull(paint33);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(layer42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color2, stroke3);
        xYPlot0.setBackgroundPaint((java.awt.Paint) color2);
        xYPlot0.setOutlineVisible(false);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        numberAxis9.setTickLabelPaint((java.awt.Paint) color10);
        xYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis9);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        xYPlot0.drawBackgroundImage(graphics2D13, rectangle2D14);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = xYPlot0.getRangeAxisEdge();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(rectangleEdge16);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        java.util.List list7 = categoryPlot0.getCategoriesForAxis(categoryAxis6);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int11 = xYPlot8.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        java.awt.Stroke stroke12 = numberAxis10.getAxisLineStroke();
        numberAxis10.setVisible(false);
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker19 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color17, stroke18);
        xYPlot15.setBackgroundPaint((java.awt.Paint) color17);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        xYPlot15.setRenderer(6, xYItemRenderer22);
        org.jfree.chart.event.PlotChangeListener plotChangeListener24 = null;
        xYPlot15.removeChangeListener(plotChangeListener24);
        java.awt.Stroke stroke26 = xYPlot15.getDomainZeroBaselineStroke();
        numberAxis10.setTickMarkStroke(stroke26);
        categoryPlot0.setRangeCrosshairStroke(stroke26);
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int32 = xYPlot29.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis31);
        org.jfree.chart.LegendItemCollection legendItemCollection33 = xYPlot29.getFixedLegendItems();
        xYPlot29.setDomainCrosshairLockedOnData(false);
        xYPlot29.configureRangeAxes();
        java.awt.Stroke stroke37 = xYPlot29.getRangeCrosshairStroke();
        categoryPlot0.setRangeCrosshairStroke(stroke37);
        float float39 = categoryPlot0.getForegroundAlpha();
        int int40 = categoryPlot0.getDatasetCount();
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNull(legendItemCollection33);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertTrue("'" + float39 + "' != '" + 1.0f + "'", float39 == 1.0f);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int6 = xYPlot3.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis5);
        numberAxis5.setLowerBound((double) (short) 10);
        xYPlot0.setDomainAxis((int) (byte) 1, (org.jfree.chart.axis.ValueAxis) numberAxis5, true);
        java.awt.Paint paint11 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint13 = xYPlot12.getDomainZeroBaselinePaint();
        boolean boolean14 = xYPlot12.isRangeGridlinesVisible();
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot12.setRangeAxisLocation(axisLocation15);
        xYPlot0.setRangeAxisLocation(axisLocation15);
        org.jfree.chart.axis.AxisSpace axisSpace18 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace18);
        xYPlot0.clearRangeAxes();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(axisLocation15);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        java.util.List list7 = categoryPlot0.getCategoriesForAxis(categoryAxis6);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int11 = xYPlot8.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        java.awt.Stroke stroke12 = numberAxis10.getAxisLineStroke();
        numberAxis10.setVisible(false);
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker19 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color17, stroke18);
        xYPlot15.setBackgroundPaint((java.awt.Paint) color17);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        xYPlot15.setRenderer(6, xYItemRenderer22);
        org.jfree.chart.event.PlotChangeListener plotChangeListener24 = null;
        xYPlot15.removeChangeListener(plotChangeListener24);
        java.awt.Stroke stroke26 = xYPlot15.getDomainZeroBaselineStroke();
        numberAxis10.setTickMarkStroke(stroke26);
        categoryPlot0.setRangeCrosshairStroke(stroke26);
        org.jfree.chart.plot.CategoryMarker categoryMarker30 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "PlotOrientation.VERTICAL");
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker30);
        categoryPlot0.clearDomainAxes();
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke26);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color9, stroke10);
        org.jfree.chart.util.Layer layer12 = null;
        xYPlot6.addRangeMarker(4, (org.jfree.chart.plot.Marker) categoryMarker11, layer12);
        java.awt.Font font14 = categoryMarker11.getLabelFont();
        java.awt.Paint paint15 = categoryMarker11.getPaint();
        org.jfree.chart.util.Layer layer16 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean17 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker11, layer16);
        categoryPlot0.setRangeCrosshairLockedOnData(true);
        java.awt.Paint paint20 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = categoryPlot0.getDomainAxis();
        categoryPlot0.setAnchorValue((double) (byte) 0, false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(layer16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNull(categoryAxis21);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint2 = xYPlot1.getDomainZeroBaselinePaint();
        boolean boolean3 = xYPlot1.isRangeGridlinesVisible();
        java.awt.Color color6 = java.awt.Color.getColor("hi!", 0);
        xYPlot1.setRangeZeroBaselinePaint((java.awt.Paint) color6);
        org.jfree.chart.axis.ValueAxis valueAxis8 = xYPlot1.getDomainAxis();
        org.jfree.chart.plot.Plot plot9 = xYPlot1.getParent();
        org.jfree.data.general.Dataset dataset11 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) 100, dataset11);
        xYPlot1.datasetChanged(datasetChangeEvent12);
        xYPlot0.datasetChanged(datasetChangeEvent12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        xYPlot0.zoomDomainAxes((double) (short) 100, plotRenderingInfo16, point2D17);
        xYPlot0.setDomainCrosshairValue((double) (short) 10);
        java.awt.Paint paint21 = xYPlot0.getRangeTickBandPaint();
        java.awt.Paint[] paintArray22 = null;
        java.awt.Paint[] paintArray23 = null;
        java.awt.Paint[] paintArray24 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray25 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.awt.Stroke stroke26 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint28 = xYPlot27.getDomainZeroBaselinePaint();
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke31 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker32 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color30, stroke31);
        java.awt.Paint paint33 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryMarker32.setLabelPaint(paint33);
        xYPlot27.setDomainZeroBaselinePaint(paint33);
        java.awt.Stroke stroke36 = xYPlot27.getDomainZeroBaselineStroke();
        java.awt.Stroke stroke37 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke38 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.XYPlot xYPlot39 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color41 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke42 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker43 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color41, stroke42);
        xYPlot39.setBackgroundPaint((java.awt.Paint) color41);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer46 = null;
        xYPlot39.setRenderer(6, xYItemRenderer46);
        org.jfree.chart.event.PlotChangeListener plotChangeListener48 = null;
        xYPlot39.removeChangeListener(plotChangeListener48);
        java.awt.Stroke stroke50 = xYPlot39.getDomainZeroBaselineStroke();
        java.awt.Stroke[] strokeArray51 = new java.awt.Stroke[] { stroke26, stroke36, stroke37, stroke38, stroke50 };
        java.awt.Stroke[] strokeArray52 = new java.awt.Stroke[] {};
        org.jfree.chart.axis.NumberAxis numberAxis54 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str55 = numberAxis54.getLabel();
        java.lang.String str56 = numberAxis54.getLabel();
        java.awt.Paint paint57 = numberAxis54.getAxisLinePaint();
        java.awt.Shape shape58 = numberAxis54.getRightArrow();
        org.jfree.chart.axis.NumberAxis numberAxis60 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str61 = numberAxis60.getLabel();
        java.lang.String str62 = numberAxis60.getLabel();
        java.awt.Paint paint63 = numberAxis60.getAxisLinePaint();
        java.awt.Shape shape64 = numberAxis60.getRightArrow();
        org.jfree.chart.axis.NumberAxis numberAxis66 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str67 = numberAxis66.getLabel();
        java.lang.String str68 = numberAxis66.getLabel();
        java.awt.Paint paint69 = numberAxis66.getAxisLinePaint();
        java.awt.Shape shape70 = numberAxis66.getRightArrow();
        org.jfree.chart.axis.NumberAxis numberAxis72 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str73 = numberAxis72.getLabel();
        java.lang.String str74 = numberAxis72.getLabel();
        java.awt.Paint paint75 = numberAxis72.getAxisLinePaint();
        java.awt.Shape shape76 = numberAxis72.getRightArrow();
        java.awt.Shape[] shapeArray77 = new java.awt.Shape[] { shape58, shape64, shape70, shape76 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier78 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray24, paintArray25, strokeArray51, strokeArray52, shapeArray77);
        java.awt.Paint paint80 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.plot.XYPlot xYPlot81 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke82 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot81.setDomainGridlineStroke(stroke82);
        org.jfree.chart.plot.ValueMarker valueMarker84 = new org.jfree.chart.plot.ValueMarker(0.0d, paint80, stroke82);
        java.awt.Stroke[] strokeArray85 = new java.awt.Stroke[] { stroke82 };
        java.awt.Shape[] shapeArray86 = null;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier87 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray22, paintArray23, strokeArray52, strokeArray85, shapeArray86);
        java.awt.Stroke stroke88 = defaultDrawingSupplier87.getNextOutlineStroke();
        xYPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier87);
        try {
            java.awt.Stroke stroke90 = defaultDrawingSupplier87.getNextStroke();
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertNull(plot9);
        org.junit.Assert.assertNull(paint21);
        org.junit.Assert.assertNotNull(paintArray24);
        org.junit.Assert.assertNotNull(paintArray25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(strokeArray51);
        org.junit.Assert.assertNotNull(strokeArray52);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str55.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str56.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertNotNull(shape58);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str61.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str62.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint63);
        org.junit.Assert.assertNotNull(shape64);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str67.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str68.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint69);
        org.junit.Assert.assertNotNull(shape70);
        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str73.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str74.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint75);
        org.junit.Assert.assertNotNull(shape76);
        org.junit.Assert.assertNotNull(shapeArray77);
        org.junit.Assert.assertNotNull(paint80);
        org.junit.Assert.assertNotNull(stroke82);
        org.junit.Assert.assertNotNull(strokeArray85);
        org.junit.Assert.assertNotNull(stroke88);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        java.util.List list7 = categoryPlot0.getCategoriesForAxis(categoryAxis6);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int11 = xYPlot8.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        java.awt.Stroke stroke12 = numberAxis10.getAxisLineStroke();
        numberAxis10.setVisible(false);
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker19 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color17, stroke18);
        xYPlot15.setBackgroundPaint((java.awt.Paint) color17);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        xYPlot15.setRenderer(6, xYItemRenderer22);
        org.jfree.chart.event.PlotChangeListener plotChangeListener24 = null;
        xYPlot15.removeChangeListener(plotChangeListener24);
        java.awt.Stroke stroke26 = xYPlot15.getDomainZeroBaselineStroke();
        numberAxis10.setTickMarkStroke(stroke26);
        categoryPlot0.setRangeCrosshairStroke(stroke26);
        org.jfree.chart.axis.AxisSpace axisSpace29 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace29);
        org.jfree.data.category.CategoryDataset categoryDataset32 = categoryPlot0.getDataset(11);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNull(categoryDataset32);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color2, stroke3);
        xYPlot0.setBackgroundPaint((java.awt.Paint) color2);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        xYPlot0.setRenderer(6, xYItemRenderer7);
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        xYPlot0.removeChangeListener(plotChangeListener9);
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        xYPlot11.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = xYPlot11.getOrientation();
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.awt.Paint paint17 = numberAxis16.getLabelPaint();
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = numberAxis16.valueToJava2D(0.0d, rectangle2D19, rectangleEdge20);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray22 = new org.jfree.chart.axis.ValueAxis[] { numberAxis16 };
        xYPlot11.setDomainAxes(valueAxisArray22);
        xYPlot0.setRangeAxes(valueAxisArray22);
        xYPlot0.setDomainCrosshairValue((double) 0L, false);
        java.util.List list28 = xYPlot0.getAnnotations();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(valueAxisArray22);
        org.junit.Assert.assertNotNull(list28);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        java.util.List list7 = categoryPlot0.getCategoriesForAxis(categoryAxis6);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int11 = xYPlot8.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        java.awt.Stroke stroke12 = numberAxis10.getAxisLineStroke();
        numberAxis10.setVisible(false);
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker19 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color17, stroke18);
        xYPlot15.setBackgroundPaint((java.awt.Paint) color17);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        xYPlot15.setRenderer(6, xYItemRenderer22);
        org.jfree.chart.event.PlotChangeListener plotChangeListener24 = null;
        xYPlot15.removeChangeListener(plotChangeListener24);
        java.awt.Stroke stroke26 = xYPlot15.getDomainZeroBaselineStroke();
        numberAxis10.setTickMarkStroke(stroke26);
        categoryPlot0.setRangeCrosshairStroke(stroke26);
        org.jfree.chart.axis.AxisSpace axisSpace29 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace29);
        java.lang.Object obj31 = null;
        boolean boolean32 = categoryPlot0.equals(obj31);
        org.jfree.chart.axis.AxisLocation axisLocation34 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.axis.AxisLocation axisLocation35 = axisLocation34.getOpposite();
        categoryPlot0.setDomainAxisLocation((int) 'a', axisLocation34, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor38 = categoryPlot0.getDomainGridlinePosition();
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertNotNull(categoryAnchor38);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color2, stroke3);
        xYPlot0.setBackgroundPaint((java.awt.Paint) color2);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        xYPlot0.setRenderer(6, xYItemRenderer7);
        xYPlot0.configureRangeAxes();
        java.awt.Paint paint10 = xYPlot0.getRangeTickBandPaint();
        double double11 = xYPlot0.getDomainCrosshairValue();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color2, stroke3);
        xYPlot0.setBackgroundPaint((java.awt.Paint) color2);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        xYPlot0.setRenderer(6, xYItemRenderer7);
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        xYPlot0.removeChangeListener(plotChangeListener9);
        org.jfree.chart.axis.ValueAxis valueAxis12 = xYPlot0.getRangeAxisForDataset((int) (short) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        xYPlot0.setAxisOffset(rectangleInsets13);
        double double15 = rectangleInsets13.getLeft();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 4.0d + "'", double15 == 4.0d);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.resizeRange((double) (short) 100, (double) 6);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str6 = numberAxis5.getLabel();
        java.lang.String str7 = numberAxis5.getLabel();
        java.awt.Paint paint8 = numberAxis5.getAxisLinePaint();
        boolean boolean9 = numberAxis5.isTickLabelsVisible();
        numberAxis5.setVerticalTickLabels(false);
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int15 = xYPlot12.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis14);
        java.awt.Stroke stroke16 = numberAxis14.getAxisLineStroke();
        boolean boolean17 = numberAxis14.isNegativeArrowVisible();
        org.jfree.data.Range range18 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis14.setRangeWithMargins(range18);
        numberAxis5.setRange(range18);
        numberAxis0.setRangeWithMargins(range18, false, false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str6.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str7.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(range18);
    }

//    @Test
//    public void test446() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test446");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
//        java.awt.Paint paint3 = xYPlot2.getDomainZeroBaselinePaint();
//        boolean boolean4 = day0.equals((java.lang.Object) paint3);
//        int int5 = day0.getMonth();
//        int int6 = day0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day0.next();
//        long long8 = day0.getLastMillisecond();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertNotNull(paint3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560495599999L + "'", long8 == 1560495599999L);
//    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        int int3 = java.awt.Color.HSBtoRGB((float) 2, (float) (short) 10, (float) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-555) + "'", int3 == (-555));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Stroke stroke2 = null;
        try {
            org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (-1L), (java.awt.Paint) color1, stroke2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int3 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis2);
        numberAxis2.setLowerBound((double) (short) 10);
        boolean boolean6 = numberAxis2.isTickMarksVisible();
        float float7 = numberAxis2.getTickMarkInsideLength();
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color11, stroke12);
        org.jfree.chart.util.Layer layer14 = null;
        xYPlot8.addRangeMarker(4, (org.jfree.chart.plot.Marker) categoryMarker13, layer14);
        org.jfree.data.general.Dataset dataset17 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent18 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) 100, dataset17);
        xYPlot8.datasetChanged(datasetChangeEvent18);
        org.jfree.data.general.DatasetGroup datasetGroup20 = xYPlot8.getDatasetGroup();
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        xYPlot8.addChangeListener(plotChangeListener21);
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = numberAxis24.getLabelInsets();
        double double27 = rectangleInsets25.calculateBottomOutset((double) (-1));
        xYPlot8.setAxisOffset(rectangleInsets25);
        java.awt.Paint paint29 = xYPlot8.getRangeGridlinePaint();
        numberAxis2.setLabelPaint(paint29);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNull(datasetGroup20);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 3.0d + "'", double27 == 3.0d);
        org.junit.Assert.assertNotNull(paint29);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis(0);
        categoryPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        categoryPlot0.setRenderer(0, categoryItemRenderer9, false);
        categoryPlot0.configureDomainAxes();
        categoryPlot0.clearRangeAxes();
        org.junit.Assert.assertNull(categoryAxis5);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("EXPAND");
        try {
            dateAxis1.zoomRange((double) 255, (-1.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (255.0) <= upper (-1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.resizeRange((double) (short) 100, (double) 6);
        boolean boolean4 = numberAxis0.isVisible();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        boolean boolean2 = xYPlot0.isRangeGridlinesVisible();
        java.awt.Color color5 = java.awt.Color.getColor("hi!", 0);
        xYPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint8 = xYPlot7.getDomainZeroBaselinePaint();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color10, stroke11);
        java.awt.Paint paint13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryMarker12.setLabelPaint(paint13);
        xYPlot7.setDomainZeroBaselinePaint(paint13);
        java.awt.Stroke stroke16 = xYPlot7.getDomainZeroBaselineStroke();
        xYPlot0.setParent((org.jfree.chart.plot.Plot) xYPlot7);
        xYPlot7.setRangeCrosshairVisible(false);
        java.awt.Paint paint20 = xYPlot7.getNoDataMessagePaint();
        boolean boolean21 = xYPlot7.isSubplot();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainZoomable();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int7 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color10, stroke11);
        xYPlot8.setBackgroundPaint((java.awt.Paint) color10);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        xYPlot8.setRenderer(6, xYItemRenderer15);
        org.jfree.chart.util.Layer layer18 = null;
        java.util.Collection collection19 = xYPlot8.getRangeMarkers((int) ' ', layer18);
        boolean boolean20 = numberAxis6.hasListener((java.util.EventListener) xYPlot8);
        java.lang.Object obj21 = numberAxis6.clone();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis6, categoryItemRenderer22);
        org.jfree.chart.util.SortOrder sortOrder24 = categoryPlot23.getRowRenderingOrder();
        categoryPlot0.setColumnRenderingOrder(sortOrder24);
        try {
            categoryPlot0.zoom((double) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(collection19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(sortOrder24);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        java.awt.Stroke stroke0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int6 = xYPlot3.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis5);
        numberAxis5.setLowerBound((double) (short) 10);
        xYPlot0.setDomainAxis((int) (byte) 1, (org.jfree.chart.axis.ValueAxis) numberAxis5, true);
        java.awt.Paint paint11 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.axis.AxisSpace axisSpace12 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace12);
        float float14 = xYPlot0.getBackgroundAlpha();
        org.jfree.data.xy.XYDataset xYDataset15 = xYPlot0.getDataset();
        java.awt.Paint paint16 = null;
        xYPlot0.setDomainTickBandPaint(paint16);
        int int18 = xYPlot0.getBackgroundImageAlignment();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 1.0f + "'", float14 == 1.0f);
        org.junit.Assert.assertNull(xYDataset15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 15 + "'", int18 == 15);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj1 = defaultDrawingSupplier0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        boolean boolean2 = xYPlot0.isRangeGridlinesVisible();
        java.awt.Color color5 = java.awt.Color.getColor("hi!", 0);
        xYPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color5);
        java.lang.Object obj7 = xYPlot0.clone();
        java.awt.Paint paint8 = xYPlot0.getDomainTickBandPaint();
        java.awt.Paint paint9 = xYPlot0.getRangeTickBandPaint();
        double double10 = xYPlot0.getRangeCrosshairValue();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color6, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color10, stroke11);
        categoryMarker8.setLabelPaint((java.awt.Paint) color10);
        org.jfree.chart.util.Layer layer14 = null;
        categoryPlot0.addRangeMarker((int) (short) 1, (org.jfree.chart.plot.Marker) categoryMarker8, layer14, false);
        categoryPlot0.setDomainGridlinesVisible(false);
        org.jfree.chart.axis.ValueAxis valueAxis19 = categoryPlot0.getRangeAxis();
        int int20 = categoryPlot0.getDomainAxisCount();
        org.jfree.chart.plot.Plot plot21 = categoryPlot0.getRootPlot();
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(valueAxis19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(plot21);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        numberAxis1.centerRange((double) (short) 100);
        numberAxis1.setFixedDimension((double) 8);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = numberAxis1.getMarkerBand();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = numberAxis1.getTickLabelInsets();
        org.junit.Assert.assertNull(markerAxisBand6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((-16056329), 10, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Red");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        java.util.List list7 = categoryPlot0.getCategoriesForAxis(categoryAxis6);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int11 = xYPlot8.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        java.awt.Stroke stroke12 = numberAxis10.getAxisLineStroke();
        numberAxis10.setVisible(false);
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker19 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color17, stroke18);
        xYPlot15.setBackgroundPaint((java.awt.Paint) color17);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        xYPlot15.setRenderer(6, xYItemRenderer22);
        org.jfree.chart.event.PlotChangeListener plotChangeListener24 = null;
        xYPlot15.removeChangeListener(plotChangeListener24);
        java.awt.Stroke stroke26 = xYPlot15.getDomainZeroBaselineStroke();
        numberAxis10.setTickMarkStroke(stroke26);
        categoryPlot0.setRangeCrosshairStroke(stroke26);
        org.jfree.chart.axis.AxisSpace axisSpace29 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace29);
        org.jfree.chart.axis.AxisSpace axisSpace31 = categoryPlot0.getFixedDomainAxisSpace();
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNull(axisSpace31);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        java.awt.Paint paint1 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot2.setDomainGridlineStroke(stroke3);
        org.jfree.chart.plot.ValueMarker valueMarker5 = new org.jfree.chart.plot.ValueMarker(0.0d, paint1, stroke3);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint7 = xYPlot6.getDomainZeroBaselinePaint();
        boolean boolean8 = xYPlot6.isRangeGridlinesVisible();
        java.awt.Color color11 = java.awt.Color.getColor("hi!", 0);
        xYPlot6.setRangeZeroBaselinePaint((java.awt.Paint) color11);
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint14 = xYPlot13.getDomainZeroBaselinePaint();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color16, stroke17);
        java.awt.Paint paint19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryMarker18.setLabelPaint(paint19);
        xYPlot13.setDomainZeroBaselinePaint(paint19);
        java.awt.Stroke stroke22 = xYPlot13.getDomainZeroBaselineStroke();
        xYPlot6.setParent((org.jfree.chart.plot.Plot) xYPlot13);
        valueMarker5.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot6);
        java.awt.Paint paint25 = valueMarker5.getLabelPaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint25);
    }

//    @Test
//    public void test464() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test464");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
//        int int2 = day1.getMonth();
//        java.lang.String str3 = day1.toString();
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color2, stroke3);
        xYPlot0.setBackgroundPaint((java.awt.Paint) color2);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        xYPlot0.setRenderer(6, xYItemRenderer7);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot0.getRangeMarkers((int) ' ', layer10);
        java.awt.Stroke stroke12 = xYPlot0.getDomainCrosshairStroke();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("EXPAND");
        org.jfree.data.Range range2 = null;
        try {
            dateAxis1.setRange(range2, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color9, stroke10);
        org.jfree.chart.util.Layer layer12 = null;
        xYPlot6.addRangeMarker(4, (org.jfree.chart.plot.Marker) categoryMarker11, layer12);
        java.awt.Font font14 = categoryMarker11.getLabelFont();
        java.awt.Paint paint15 = categoryMarker11.getPaint();
        org.jfree.chart.util.Layer layer16 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean17 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker11, layer16);
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str21 = numberAxis20.getLabel();
        java.lang.String str22 = numberAxis20.getLabel();
        java.awt.Paint paint23 = numberAxis20.getAxisLinePaint();
        boolean boolean24 = numberAxis20.isTickLabelsVisible();
        numberAxis20.setAutoRange(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = numberAxis20.getLabelInsets();
        java.awt.Stroke stroke28 = numberAxis20.getAxisLineStroke();
        int int29 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis20);
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double32 = rectangleInsets30.trimWidth((double) 10);
        categoryPlot0.setInsets(rectangleInsets30, true);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(layer16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str21.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str22.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 10.0d + "'", double32 == 10.0d);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = categoryPlot0.getDomainAxis();
        org.jfree.chart.LegendItemCollection legendItemCollection3 = categoryPlot0.getLegendItems();
        java.awt.Paint paint4 = categoryPlot0.getRangeCrosshairPaint();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(categoryAxis2);
        org.junit.Assert.assertNotNull(legendItemCollection3);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker5 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color3, stroke4);
        xYPlot1.setBackgroundPaint((java.awt.Paint) color3);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        xYPlot1.setRenderer(6, xYItemRenderer8);
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        xYPlot1.removeChangeListener(plotChangeListener10);
        java.awt.Stroke stroke12 = xYPlot1.getDomainZeroBaselineStroke();
        xYPlot0.setRangeGridlineStroke(stroke12);
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot14.setDomainGridlineStroke(stroke15);
        java.awt.Stroke stroke17 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        xYPlot14.setRangeGridlineStroke(stroke17);
        xYPlot0.setDomainGridlineStroke(stroke17);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str2 = numberAxis1.getLabel();
        java.lang.String str3 = numberAxis1.getLabel();
        java.awt.Paint paint4 = numberAxis1.getAxisLinePaint();
        boolean boolean5 = numberAxis1.isTickLabelsVisible();
        numberAxis1.setAutoRange(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis1.getLabelInsets();
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint12 = xYPlot11.getDomainZeroBaselinePaint();
        boolean boolean13 = xYPlot11.isRangeGridlinesVisible();
        java.awt.Color color16 = java.awt.Color.getColor("hi!", 0);
        xYPlot11.setRangeZeroBaselinePaint((java.awt.Paint) color16);
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint19 = xYPlot18.getDomainZeroBaselinePaint();
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker23 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color21, stroke22);
        java.awt.Paint paint24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryMarker23.setLabelPaint(paint24);
        xYPlot18.setDomainZeroBaselinePaint(paint24);
        java.awt.Stroke stroke27 = xYPlot18.getDomainZeroBaselineStroke();
        xYPlot11.setParent((org.jfree.chart.plot.Plot) xYPlot18);
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = xYPlot18.getDomainAxisEdge();
        try {
            double double30 = numberAxis1.valueToJava2D((double) (-16744448), rectangle2D10, rectangleEdge29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str2.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str3.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(rectangleEdge29);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str2 = numberAxis1.getLabel();
        java.lang.String str3 = numberAxis1.getLabel();
        java.awt.Paint paint4 = numberAxis1.getAxisLinePaint();
        numberAxis1.centerRange(0.0d);
        numberAxis1.centerRange(0.0d);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str2.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str3.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.awt.Paint paint2 = numberAxis1.getLabelPaint();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = numberAxis1.valueToJava2D(0.0d, rectangle2D4, rectangleEdge5);
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = numberAxis1.java2DToValue((double) 0L, rectangle2D8, rectangleEdge9);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double12 = rectangleInsets11.getTop();
        double double14 = rectangleInsets11.calculateBottomOutset((double) 1);
        numberAxis1.setLabelInsets(rectangleInsets11);
        numberAxis1.resizeRange((double) 100, (double) 10.0f);
        numberAxis1.setRange((double) 0, 6.0d);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 2.0d + "'", double14 == 2.0d);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color2);
        double double4 = numberAxis1.getAutoRangeMinimumSize();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str7 = numberAxis6.getLabel();
        numberAxis6.setVisible(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit10 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis6.setTickUnit(numberTickUnit10, false, false);
        numberAxis6.setAxisLineVisible(false);
        numberAxis6.setAutoTickUnitSelection(true);
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint19 = xYPlot18.getDomainZeroBaselinePaint();
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker23 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color21, stroke22);
        java.awt.Paint paint24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryMarker23.setLabelPaint(paint24);
        xYPlot18.setDomainZeroBaselinePaint(paint24);
        java.awt.Stroke stroke27 = xYPlot18.getDomainZeroBaselineStroke();
        numberAxis6.setAxisLineStroke(stroke27);
        java.awt.Shape shape29 = numberAxis6.getRightArrow();
        numberAxis1.setRightArrow(shape29);
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot33.setAnchorValue((double) (-1L), true);
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = categoryPlot33.getDomainAxis(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = null;
        java.util.List list40 = categoryPlot33.getCategoriesForAxis(categoryAxis39);
        org.jfree.chart.plot.XYPlot xYPlot41 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis43 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int44 = xYPlot41.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis43);
        java.awt.Stroke stroke45 = numberAxis43.getAxisLineStroke();
        numberAxis43.setVisible(false);
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color50 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke51 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker52 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color50, stroke51);
        xYPlot48.setBackgroundPaint((java.awt.Paint) color50);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer55 = null;
        xYPlot48.setRenderer(6, xYItemRenderer55);
        org.jfree.chart.event.PlotChangeListener plotChangeListener57 = null;
        xYPlot48.removeChangeListener(plotChangeListener57);
        java.awt.Stroke stroke59 = xYPlot48.getDomainZeroBaselineStroke();
        numberAxis43.setTickMarkStroke(stroke59);
        categoryPlot33.setRangeCrosshairStroke(stroke59);
        org.jfree.chart.util.RectangleEdge rectangleEdge63 = categoryPlot33.getDomainAxisEdge(11);
        try {
            double double64 = numberAxis1.valueToJava2D((double) 128, rectangle2D32, rectangleEdge63);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-8d + "'", double4 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str7.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(numberTickUnit10);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNull(categoryAxis38);
        org.junit.Assert.assertNotNull(list40);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertNotNull(rectangleEdge63);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        boolean boolean2 = xYPlot0.isRangeGridlinesVisible();
        java.awt.Color color5 = java.awt.Color.getColor("hi!", 0);
        xYPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color5);
        org.jfree.chart.axis.ValueAxis valueAxis7 = xYPlot0.getDomainAxis();
        org.jfree.chart.plot.Plot plot8 = xYPlot0.getParent();
        try {
            java.awt.Paint paint9 = plot8.getNoDataMessagePaint();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNull(plot8);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int3 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis2);
        java.awt.Stroke stroke4 = numberAxis2.getAxisLineStroke();
        numberAxis2.setVisible(false);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color9, stroke10);
        xYPlot7.setBackgroundPaint((java.awt.Paint) color9);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        xYPlot7.setRenderer(6, xYItemRenderer14);
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        xYPlot7.removeChangeListener(plotChangeListener16);
        java.awt.Stroke stroke18 = xYPlot7.getDomainZeroBaselineStroke();
        numberAxis2.setTickMarkStroke(stroke18);
        org.jfree.chart.axis.TickUnitSource tickUnitSource20 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        numberAxis2.setStandardTickUnits(tickUnitSource20);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(tickUnitSource20);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color6, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color10, stroke11);
        categoryMarker8.setLabelPaint((java.awt.Paint) color10);
        org.jfree.chart.util.Layer layer14 = null;
        categoryPlot0.addRangeMarker((int) (short) 1, (org.jfree.chart.plot.Marker) categoryMarker8, layer14, false);
        categoryPlot0.setDomainGridlinesVisible(false);
        org.jfree.chart.axis.ValueAxis valueAxis19 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker25 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color23, stroke24);
        org.jfree.chart.util.Layer layer26 = null;
        xYPlot20.addRangeMarker(4, (org.jfree.chart.plot.Marker) categoryMarker25, layer26);
        java.awt.Font font28 = categoryMarker25.getLabelFont();
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker25);
        java.awt.Font font30 = categoryMarker25.getLabelFont();
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(valueAxis19);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(font30);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int6 = xYPlot3.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis5);
        numberAxis5.setLowerBound((double) (short) 10);
        xYPlot0.setDomainAxis((int) (byte) 1, (org.jfree.chart.axis.ValueAxis) numberAxis5, true);
        java.awt.Paint paint11 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint13 = xYPlot12.getDomainZeroBaselinePaint();
        boolean boolean14 = xYPlot12.isRangeGridlinesVisible();
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot12.setRangeAxisLocation(axisLocation15);
        xYPlot0.setRangeAxisLocation(axisLocation15);
        xYPlot0.mapDatasetToRangeAxis(15, 255);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(axisLocation15);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        boolean boolean2 = xYPlot0.isRangeGridlinesVisible();
        java.awt.Color color5 = java.awt.Color.getColor("hi!", 0);
        xYPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint8 = xYPlot7.getDomainZeroBaselinePaint();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color10, stroke11);
        java.awt.Paint paint13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryMarker12.setLabelPaint(paint13);
        xYPlot7.setDomainZeroBaselinePaint(paint13);
        java.awt.Stroke stroke16 = xYPlot7.getDomainZeroBaselineStroke();
        xYPlot0.setParent((org.jfree.chart.plot.Plot) xYPlot7);
        xYPlot7.setBackgroundImageAlpha(0.0f);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("SeriesRenderingOrder.FORWARD");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int3 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis2);
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color6, stroke7);
        xYPlot4.setBackgroundPaint((java.awt.Paint) color6);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        xYPlot4.setRenderer(6, xYItemRenderer11);
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = xYPlot4.getRangeMarkers((int) ' ', layer14);
        boolean boolean16 = numberAxis2.hasListener((java.util.EventListener) xYPlot4);
        java.lang.Object obj17 = numberAxis2.clone();
        boolean boolean18 = numberAxis2.isAutoTickUnitSelection();
        numberAxis2.resizeRange((double) 7, 1.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color1, stroke2);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color5, stroke6);
        categoryMarker3.setLabelPaint((java.awt.Paint) color5);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker3);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryMarker3.getLabelOffset();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets10);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=192,g=192,b=192]");
        float float2 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint8 = xYPlot7.getDomainZeroBaselinePaint();
        boolean boolean9 = xYPlot7.isRangeGridlinesVisible();
        java.awt.Color color12 = java.awt.Color.getColor("hi!", 0);
        xYPlot7.setRangeZeroBaselinePaint((java.awt.Paint) color12);
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint15 = xYPlot14.getDomainZeroBaselinePaint();
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker19 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color17, stroke18);
        java.awt.Paint paint20 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryMarker19.setLabelPaint(paint20);
        xYPlot14.setDomainZeroBaselinePaint(paint20);
        java.awt.Stroke stroke23 = xYPlot14.getDomainZeroBaselineStroke();
        xYPlot7.setParent((org.jfree.chart.plot.Plot) xYPlot14);
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = xYPlot14.getDomainAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        try {
            org.jfree.chart.axis.AxisState axisState27 = categoryAxis1.draw(graphics2D3, (double) 3, rectangle2D5, rectangle2D6, rectangleEdge25, plotRenderingInfo26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(rectangleEdge25);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = numberAxis1.getLabelInsets();
        double double4 = rectangleInsets2.extendWidth(0.0d);
        double double6 = rectangleInsets2.calculateLeftOutset(0.0d);
        double double8 = rectangleInsets2.calculateTopOutset((double) 1560452399999L);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 6.0d + "'", double4 == 6.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.0d + "'", double6 == 3.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 3.0d + "'", double8 == 3.0d);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        categoryPlot0.setRangeCrosshairVisible(true);
        categoryPlot0.clearRangeMarkers(11);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=192,g=192,b=192]");
        float float10 = categoryAxis9.getMaximumCategoryLabelWidthRatio();
        java.util.List list11 = categoryPlot0.getCategoriesForAxis(categoryAxis9);
        categoryPlot0.setAnchorValue(0.0d);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
        org.junit.Assert.assertNotNull(list11);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation3 = xYPlot0.getOrientation();
        boolean boolean5 = plotOrientation3.equals((java.lang.Object) (-1L));
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color7, stroke8);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color11, stroke12);
        categoryMarker9.setLabelPaint((java.awt.Paint) color11);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType15 = categoryMarker9.getLabelOffsetType();
        boolean boolean16 = plotOrientation3.equals((java.lang.Object) lengthAdjustmentType15);
        java.lang.String str17 = lengthAdjustmentType15.toString();
        org.junit.Assert.assertNotNull(plotOrientation3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(lengthAdjustmentType15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "EXPAND" + "'", str17.equals("EXPAND"));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj2 = objectList0.get(0);
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        xYPlot3.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        xYPlot3.setRenderer((int) (byte) 1, xYItemRenderer7);
        double double9 = xYPlot3.getRangeCrosshairValue();
        int int10 = objectList0.indexOf((java.lang.Object) xYPlot3);
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        xYPlot3.setDataset((int) (byte) 1, xYDataset12);
        org.junit.Assert.assertNull(obj2);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (byte) 10);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, 13, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color6, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color10, stroke11);
        categoryMarker8.setLabelPaint((java.awt.Paint) color10);
        org.jfree.chart.util.Layer layer14 = null;
        categoryPlot0.addRangeMarker((int) (short) 1, (org.jfree.chart.plot.Marker) categoryMarker8, layer14, false);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray17 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot0.setDomainAxes(categoryAxisArray17);
        java.lang.String str19 = categoryPlot0.getPlotType();
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = categoryPlot0.getRendererForDataset(categoryDataset20);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = categoryPlot0.getDomainAxis((int) ' ');
        float float24 = categoryPlot0.getBackgroundAlpha();
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(categoryAxisArray17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Category Plot" + "'", str19.equals("Category Plot"));
        org.junit.Assert.assertNull(categoryItemRenderer21);
        org.junit.Assert.assertNull(categoryAxis23);
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 1.0f + "'", float24 == 1.0f);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        java.util.List list7 = categoryPlot0.getCategoriesForAxis(categoryAxis6);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int11 = xYPlot8.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        java.awt.Stroke stroke12 = numberAxis10.getAxisLineStroke();
        numberAxis10.setVisible(false);
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker19 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color17, stroke18);
        xYPlot15.setBackgroundPaint((java.awt.Paint) color17);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        xYPlot15.setRenderer(6, xYItemRenderer22);
        org.jfree.chart.event.PlotChangeListener plotChangeListener24 = null;
        xYPlot15.removeChangeListener(plotChangeListener24);
        java.awt.Stroke stroke26 = xYPlot15.getDomainZeroBaselineStroke();
        numberAxis10.setTickMarkStroke(stroke26);
        categoryPlot0.setRangeCrosshairStroke(stroke26);
        boolean boolean29 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = categoryPlot0.getRangeAxisEdge(10);
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = null;
        categoryPlot0.setDomainAxis(categoryAxis32);
        java.awt.Color color34 = java.awt.Color.darkGray;
        int int35 = color34.getAlpha();
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color34);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent37 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color34);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 255 + "'", int35 == 255);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        java.util.List list7 = categoryPlot0.getCategoriesForAxis(categoryAxis6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = categoryPlot0.getDataset();
        categoryPlot0.setAnchorValue((-1.0d));
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertNull(categoryDataset8);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis(0);
        categoryPlot0.clearDomainMarkers((-16744448));
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str10 = numberAxis9.getLabel();
        java.lang.String str11 = numberAxis9.getLabel();
        java.awt.Paint paint12 = numberAxis9.getAxisLinePaint();
        boolean boolean13 = numberAxis9.isTickLabelsVisible();
        java.awt.Font font14 = numberAxis9.getTickLabelFont();
        java.awt.Color color15 = java.awt.Color.blue;
        numberAxis9.setLabelPaint((java.awt.Paint) color15);
        java.awt.Stroke stroke17 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        numberAxis9.setTickMarkStroke(stroke17);
        categoryPlot0.setOutlineStroke(stroke17);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str10.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str11.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        xYPlot0.setDataset(xYDataset3);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.awt.Paint paint7 = numberAxis6.getLabelPaint();
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        double double11 = numberAxis6.valueToJava2D(0.0d, rectangle2D9, rectangleEdge10);
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = null;
        double double15 = numberAxis6.java2DToValue((double) 0L, rectangle2D13, rectangleEdge14);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double17 = rectangleInsets16.getTop();
        double double19 = rectangleInsets16.calculateBottomOutset((double) 1);
        numberAxis6.setLabelInsets(rectangleInsets16);
        numberAxis6.resizeRange((double) 100, (double) 10.0f);
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke27 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker28 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color26, stroke27);
        xYPlot24.setBackgroundPaint((java.awt.Paint) color26);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = null;
        xYPlot24.setRenderer(6, xYItemRenderer31);
        org.jfree.chart.util.Layer layer34 = null;
        java.util.Collection collection35 = xYPlot24.getRangeMarkers((int) ' ', layer34);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder36 = xYPlot24.getDatasetRenderingOrder();
        xYPlot24.setRangeZeroBaselineVisible(false);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot24);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray40 = new org.jfree.chart.axis.ValueAxis[] { numberAxis6 };
        xYPlot0.setDomainAxes(valueAxisArray40);
        java.awt.Image image42 = null;
        xYPlot0.setBackgroundImage(image42);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 2.0d + "'", double17 == 2.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 2.0d + "'", double19 == 2.0d);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNull(collection35);
        org.junit.Assert.assertNotNull(datasetRenderingOrder36);
        org.junit.Assert.assertNotNull(valueAxisArray40);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int6 = xYPlot3.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis5);
        numberAxis5.setLowerBound((double) (short) 10);
        xYPlot0.setDomainAxis((int) (byte) 1, (org.jfree.chart.axis.ValueAxis) numberAxis5, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double12 = rectangleInsets11.getTop();
        java.lang.String str13 = rectangleInsets11.toString();
        xYPlot0.setInsets(rectangleInsets11, true);
        java.awt.Stroke stroke16 = xYPlot0.getDomainGridlineStroke();
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke21 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color20, stroke21);
        xYPlot18.setBackgroundPaint((java.awt.Paint) color20);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer25 = null;
        xYPlot18.setRenderer(6, xYItemRenderer25);
        org.jfree.chart.event.PlotChangeListener plotChangeListener27 = null;
        xYPlot18.removeChangeListener(plotChangeListener27);
        org.jfree.chart.util.Layer layer29 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection30 = xYPlot18.getDomainMarkers(layer29);
        boolean boolean32 = layer29.equals((java.lang.Object) "SeriesRenderingOrder.FORWARD");
        java.util.Collection collection33 = xYPlot0.getRangeMarkers(0, layer29);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str13.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(layer29);
        org.junit.Assert.assertNull(collection30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNull(collection33);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color2, stroke3);
        xYPlot0.setBackgroundPaint((java.awt.Paint) color2);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        xYPlot0.setRenderer(6, xYItemRenderer7);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot0.getRangeMarkers((int) ' ', layer10);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder12 = xYPlot0.getDatasetRenderingOrder();
        xYPlot0.setDomainCrosshairVisible(false);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(datasetRenderingOrder12);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color2, stroke3);
        xYPlot0.setBackgroundPaint((java.awt.Paint) color2);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        xYPlot0.setRenderer(6, xYItemRenderer7);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot0.getRangeMarkers((int) ' ', layer10);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder12 = xYPlot0.getDatasetRenderingOrder();
        xYPlot0.clearRangeMarkers();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(datasetRenderingOrder12);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color4, stroke5);
        org.jfree.chart.util.Layer layer7 = null;
        xYPlot1.addRangeMarker(4, (org.jfree.chart.plot.Marker) categoryMarker6, layer7);
        java.awt.Font font9 = categoryMarker6.getLabelFont();
        java.awt.Paint paint10 = categoryMarker6.getPaint();
        boolean boolean11 = rectangleAnchor0.equals((java.lang.Object) categoryMarker6);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }
}

