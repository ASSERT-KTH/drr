import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation3 = xYPlot0.getOrientation();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.awt.Paint paint6 = numberAxis5.getLabelPaint();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = numberAxis5.valueToJava2D(0.0d, rectangle2D8, rectangleEdge9);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray11 = new org.jfree.chart.axis.ValueAxis[] { numberAxis5 };
        xYPlot0.setDomainAxes(valueAxisArray11);
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke16 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker17 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color15, stroke16);
        xYPlot13.setBackgroundPaint((java.awt.Paint) color15);
        xYPlot0.setRangeCrosshairPaint((java.awt.Paint) color15);
        java.awt.Paint paint20 = xYPlot0.getRangeTickBandPaint();
        xYPlot0.setDomainGridlinesVisible(true);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier23 = xYPlot0.getDrawingSupplier();
        xYPlot0.clearRangeMarkers((int) (byte) 10);
        org.junit.Assert.assertNotNull(plotOrientation3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(valueAxisArray11);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNull(paint20);
        org.junit.Assert.assertNotNull(drawingSupplier23);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("EXPAND");
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        xYPlot2.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = xYPlot2.getOrientation();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint9 = xYPlot8.getDomainZeroBaselinePaint();
        boolean boolean10 = day6.equals((java.lang.Object) paint9);
        java.util.Date date11 = day6.getStart();
        boolean boolean12 = plotOrientation5.equals((java.lang.Object) date11);
        dateAxis1.setMinimumDate(date11);
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot();
        xYPlot14.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = xYPlot14.getOrientation();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate19 = day18.getSerialDate();
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint21 = xYPlot20.getDomainZeroBaselinePaint();
        boolean boolean22 = day18.equals((java.lang.Object) paint21);
        java.util.Date date23 = day18.getStart();
        boolean boolean24 = plotOrientation17.equals((java.lang.Object) date23);
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot();
        xYPlot25.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation28 = xYPlot25.getOrientation();
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate30 = day29.getSerialDate();
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint32 = xYPlot31.getDomainZeroBaselinePaint();
        boolean boolean33 = day29.equals((java.lang.Object) paint32);
        java.util.Date date34 = day29.getStart();
        boolean boolean35 = plotOrientation28.equals((java.lang.Object) date34);
        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date34, timeZone36);
        try {
            dateAxis1.setRange(date23, date34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(plotOrientation17);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(plotOrientation28);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(timeZone36);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str2 = numberAxis1.getLabel();
        numberAxis1.setVisible(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis1.setTickUnit(numberTickUnit5, false, false);
        numberAxis1.setLabelURL("SeriesRenderingOrder.FORWARD");
        numberAxis1.setTickMarkOutsideLength((float) 13);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str2.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(numberTickUnit5);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        java.util.List list7 = categoryPlot0.getCategoriesForAxis(categoryAxis6);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int11 = xYPlot8.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        java.awt.Stroke stroke12 = numberAxis10.getAxisLineStroke();
        numberAxis10.setVisible(false);
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker19 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color17, stroke18);
        xYPlot15.setBackgroundPaint((java.awt.Paint) color17);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        xYPlot15.setRenderer(6, xYItemRenderer22);
        org.jfree.chart.event.PlotChangeListener plotChangeListener24 = null;
        xYPlot15.removeChangeListener(plotChangeListener24);
        java.awt.Stroke stroke26 = xYPlot15.getDomainZeroBaselineStroke();
        numberAxis10.setTickMarkStroke(stroke26);
        categoryPlot0.setRangeCrosshairStroke(stroke26);
        boolean boolean29 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = categoryPlot0.getRangeAxisEdge(10);
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = null;
        categoryPlot0.setDomainAxis(categoryAxis32);
        java.awt.Color color34 = java.awt.Color.darkGray;
        int int35 = color34.getAlpha();
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color34);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = categoryPlot0.getRenderer();
        org.jfree.chart.plot.XYPlot xYPlot38 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint39 = xYPlot38.getDomainZeroBaselinePaint();
        java.awt.Color color41 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke42 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker43 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color41, stroke42);
        java.awt.Paint paint44 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryMarker43.setLabelPaint(paint44);
        xYPlot38.setDomainZeroBaselinePaint(paint44);
        java.awt.Stroke stroke47 = xYPlot38.getDomainZeroBaselineStroke();
        categoryPlot0.setDomainGridlineStroke(stroke47);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 255 + "'", int35 == 255);
        org.junit.Assert.assertNull(categoryItemRenderer37);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(stroke47);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.DESCENDING;
        java.lang.String str1 = sortOrder0.toString();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker5 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color3, stroke4);
        org.jfree.data.general.Dataset dataset7 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) 100, dataset7);
        boolean boolean9 = categoryMarker5.equals((java.lang.Object) 100);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        categoryMarker5.setPaint((java.awt.Paint) color10);
        boolean boolean12 = sortOrder0.equals((java.lang.Object) categoryMarker5);
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SortOrder.DESCENDING" + "'", str1.equals("SortOrder.DESCENDING"));
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        java.util.List list7 = categoryPlot0.getCategoriesForAxis(categoryAxis6);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int11 = xYPlot8.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        java.awt.Stroke stroke12 = numberAxis10.getAxisLineStroke();
        numberAxis10.setVisible(false);
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker19 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color17, stroke18);
        xYPlot15.setBackgroundPaint((java.awt.Paint) color17);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        xYPlot15.setRenderer(6, xYItemRenderer22);
        org.jfree.chart.event.PlotChangeListener plotChangeListener24 = null;
        xYPlot15.removeChangeListener(plotChangeListener24);
        java.awt.Stroke stroke26 = xYPlot15.getDomainZeroBaselineStroke();
        numberAxis10.setTickMarkStroke(stroke26);
        categoryPlot0.setRangeCrosshairStroke(stroke26);
        org.jfree.chart.plot.CategoryMarker categoryMarker30 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "PlotOrientation.VERTICAL");
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker30);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        try {
            categoryPlot0.handleClick(128, 255, plotRenderingInfo34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke26);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color2, stroke3);
        xYPlot0.setBackgroundPaint((java.awt.Paint) color2);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        xYPlot0.setRenderer(6, xYItemRenderer7);
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        xYPlot0.removeChangeListener(plotChangeListener9);
        java.awt.Stroke stroke11 = xYPlot0.getDomainGridlineStroke();
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        xYPlot12.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        xYPlot12.setRenderer((int) (byte) 1, xYItemRenderer16);
        org.jfree.chart.LegendItemCollection legendItemCollection18 = xYPlot12.getFixedLegendItems();
        boolean boolean19 = xYPlot0.equals((java.lang.Object) legendItemCollection18);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(legendItemCollection18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        java.util.List list7 = categoryPlot0.getCategoriesForAxis(categoryAxis6);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int11 = xYPlot8.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        java.awt.Stroke stroke12 = numberAxis10.getAxisLineStroke();
        numberAxis10.setVisible(false);
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker19 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color17, stroke18);
        xYPlot15.setBackgroundPaint((java.awt.Paint) color17);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        xYPlot15.setRenderer(6, xYItemRenderer22);
        org.jfree.chart.event.PlotChangeListener plotChangeListener24 = null;
        xYPlot15.removeChangeListener(plotChangeListener24);
        java.awt.Stroke stroke26 = xYPlot15.getDomainZeroBaselineStroke();
        numberAxis10.setTickMarkStroke(stroke26);
        categoryPlot0.setRangeCrosshairStroke(stroke26);
        org.jfree.chart.axis.AxisSpace axisSpace29 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace29);
        org.jfree.chart.axis.AxisLocation axisLocation31 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.axis.AxisSpace axisSpace32 = categoryPlot0.getFixedDomainAxisSpace();
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertNull(axisSpace32);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color9, stroke10);
        org.jfree.chart.util.Layer layer12 = null;
        xYPlot6.addRangeMarker(4, (org.jfree.chart.plot.Marker) categoryMarker11, layer12);
        java.awt.Font font14 = categoryMarker11.getLabelFont();
        java.awt.Paint paint15 = categoryMarker11.getPaint();
        org.jfree.chart.util.Layer layer16 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean17 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker11, layer16);
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str21 = numberAxis20.getLabel();
        java.lang.String str22 = numberAxis20.getLabel();
        java.awt.Paint paint23 = numberAxis20.getAxisLinePaint();
        boolean boolean24 = numberAxis20.isTickLabelsVisible();
        numberAxis20.setAutoRange(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = numberAxis20.getLabelInsets();
        java.awt.Stroke stroke28 = numberAxis20.getAxisLineStroke();
        int int29 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis20);
        java.awt.Stroke stroke30 = categoryPlot0.getRangeGridlineStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection31 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.util.SortOrder sortOrder32 = categoryPlot0.getColumnRenderingOrder();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = null;
        categoryPlot0.setRenderer(6, categoryItemRenderer34);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(layer16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str21.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str22.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNull(legendItemCollection31);
        org.junit.Assert.assertNotNull(sortOrder32);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.junit.Assert.assertNotNull(plotOrientation0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int3 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        xYPlot0.setRangeCrosshairPaint((java.awt.Paint) color4);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int10 = xYPlot7.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis9);
        java.awt.Stroke stroke11 = numberAxis9.getAxisLineStroke();
        boolean boolean12 = numberAxis9.isNegativeArrowVisible();
        xYPlot0.setDomainAxis((int) (short) 10, (org.jfree.chart.axis.ValueAxis) numberAxis9, true);
        java.awt.Paint paint15 = numberAxis9.getLabelPaint();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.axis.AxisLocation axisLocation1 = axisLocation0.getOpposite();
        java.lang.String str2 = axisLocation1.toString();
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str2.equals("AxisLocation.BOTTOM_OR_RIGHT"));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        boolean boolean2 = xYPlot0.isRangeGridlinesVisible();
        org.jfree.chart.axis.AxisLocation axisLocation3 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot0.setRangeAxisLocation(axisLocation3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color8, stroke9);
        org.jfree.chart.util.Layer layer11 = null;
        xYPlot5.addRangeMarker(4, (org.jfree.chart.plot.Marker) categoryMarker10, layer11);
        java.awt.Font font13 = categoryMarker10.getLabelFont();
        java.awt.Paint paint14 = categoryMarker10.getPaint();
        xYPlot0.setNoDataMessagePaint(paint14);
        java.awt.Paint paint16 = xYPlot0.getBackgroundPaint();
        org.jfree.chart.axis.AxisLocation axisLocation18 = null;
        xYPlot0.setDomainAxisLocation((int) (byte) 10, axisLocation18);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation20 = null;
        try {
            xYPlot0.addAnnotation(xYAnnotation20, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color2, stroke3);
        xYPlot0.setBackgroundPaint((java.awt.Paint) color2);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        xYPlot0.setRenderer(6, xYItemRenderer7);
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        xYPlot0.removeChangeListener(plotChangeListener9);
        java.awt.Stroke stroke11 = xYPlot0.getDomainZeroBaselineStroke();
        org.jfree.chart.plot.Plot plot12 = xYPlot0.getParent();
        xYPlot0.setWeight(12);
        xYPlot0.clearRangeAxes();
        java.awt.Paint paint16 = xYPlot0.getRangeGridlinePaint();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent17 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYPlot0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(plot12);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str2 = numberAxis1.getLabel();
        numberAxis1.setVisible(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis1.setTickUnit(numberTickUnit5, false, false);
        numberAxis1.setLabelURL("SeriesRenderingOrder.FORWARD");
        boolean boolean11 = numberAxis1.isAutoTickUnitSelection();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str14 = numberAxis13.getLabel();
        java.lang.String str15 = numberAxis13.getLabel();
        java.awt.Paint paint16 = numberAxis13.getAxisLinePaint();
        java.awt.Shape shape17 = numberAxis13.getRightArrow();
        numberAxis1.setDownArrow(shape17);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit19 = numberAxis1.getTickUnit();
        numberAxis1.centerRange((double) 9);
        double double22 = numberAxis1.getFixedAutoRange();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str2.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(numberTickUnit5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str14.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str15.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(numberTickUnit19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot0.setDomainGridlineStroke(stroke1);
        xYPlot0.setRangeCrosshairValue((double) 100L, false);
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color2, stroke3);
        xYPlot0.setBackgroundPaint((java.awt.Paint) color2);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        xYPlot0.setRenderer(6, xYItemRenderer7);
        xYPlot0.configureRangeAxes();
        double double10 = xYPlot0.getRangeCrosshairValue();
        xYPlot0.setDomainCrosshairVisible(false);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color2, stroke3);
        xYPlot0.setBackgroundPaint((java.awt.Paint) color2);
        xYPlot0.setOutlineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        xYPlot0.setRenderer(9, xYItemRenderer9, false);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.util.List list14 = null;
        xYPlot0.drawDomainTickBands(graphics2D12, rectangle2D13, list14);
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        xYPlot0.setDomainTickBandPaint((java.awt.Paint) color16);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation18 = null;
        try {
            xYPlot0.addAnnotation(xYAnnotation18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(color16);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker5 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color3, stroke4);
        org.jfree.chart.util.Layer layer6 = null;
        xYPlot0.addRangeMarker(4, (org.jfree.chart.plot.Marker) categoryMarker5, layer6);
        java.awt.Color color8 = java.awt.Color.BLACK;
        categoryMarker5.setPaint((java.awt.Paint) color8);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker5);
        java.lang.String str11 = markerChangeEvent10.toString();
        org.jfree.chart.JFreeChart jFreeChart12 = null;
        markerChangeEvent10.setChart(jFreeChart12);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        java.util.List list7 = categoryPlot0.getCategoriesForAxis(categoryAxis6);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int11 = xYPlot8.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        java.awt.Stroke stroke12 = numberAxis10.getAxisLineStroke();
        numberAxis10.setVisible(false);
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker19 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color17, stroke18);
        xYPlot15.setBackgroundPaint((java.awt.Paint) color17);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        xYPlot15.setRenderer(6, xYItemRenderer22);
        org.jfree.chart.event.PlotChangeListener plotChangeListener24 = null;
        xYPlot15.removeChangeListener(plotChangeListener24);
        java.awt.Stroke stroke26 = xYPlot15.getDomainZeroBaselineStroke();
        numberAxis10.setTickMarkStroke(stroke26);
        categoryPlot0.setRangeCrosshairStroke(stroke26);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        java.awt.geom.Point2D point2D31 = null;
        categoryPlot0.zoomDomainAxes(0.0d, plotRenderingInfo30, point2D31, false);
        org.jfree.chart.axis.AxisLocation axisLocation34 = categoryPlot0.getDomainAxisLocation();
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(axisLocation34);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot0.setDomainGridlineStroke(stroke1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        xYPlot0.zoomDomainAxes(100.0d, plotRenderingInfo4, point2D5, false);
        java.awt.Stroke stroke8 = xYPlot0.getRangeZeroBaselineStroke();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color1, stroke2);
        java.awt.Paint paint4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryMarker3.setLabelPaint(paint4);
        org.jfree.chart.text.TextAnchor textAnchor6 = categoryMarker3.getLabelTextAnchor();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("UnitType.RELATIVE");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        int int1 = color0.getGreen();
        int int2 = color0.getAlpha();
        java.awt.image.ColorModel colorModel3 = null;
        java.awt.Rectangle rectangle4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.AffineTransform affineTransform6 = null;
        java.awt.RenderingHints renderingHints7 = null;
        java.awt.PaintContext paintContext8 = color0.createContext(colorModel3, rectangle4, rectangle2D5, affineTransform6, renderingHints7);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 255 + "'", int2 == 255);
        org.junit.Assert.assertNotNull(paintContext8);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation3 = xYPlot0.getOrientation();
        java.lang.String str4 = plotOrientation3.toString();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.setAnchorValue((double) (-1L), true);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot5.getDomainAxis(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        java.util.List list12 = categoryPlot5.getCategoriesForAxis(categoryAxis11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = categoryPlot5.getRenderer(3);
        org.jfree.chart.util.SortOrder sortOrder15 = categoryPlot5.getRowRenderingOrder();
        boolean boolean16 = plotOrientation3.equals((java.lang.Object) sortOrder15);
        org.junit.Assert.assertNotNull(plotOrientation3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "PlotOrientation.VERTICAL" + "'", str4.equals("PlotOrientation.VERTICAL"));
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertNull(categoryItemRenderer14);
        org.junit.Assert.assertNotNull(sortOrder15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int3 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        xYPlot0.setRangeCrosshairPaint((java.awt.Paint) color4);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color8, stroke9);
        xYPlot6.setBackgroundPaint((java.awt.Paint) color8);
        xYPlot6.setOutlineVisible(false);
        java.awt.Stroke stroke14 = xYPlot6.getRangeGridlineStroke();
        xYPlot0.setOutlineStroke(stroke14);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str19 = numberAxis18.getLabel();
        java.lang.String str20 = numberAxis18.getLabel();
        java.awt.Paint paint21 = numberAxis18.getAxisLinePaint();
        boolean boolean22 = numberAxis18.isTickLabelsVisible();
        numberAxis18.setVerticalTickLabels(false);
        xYPlot0.setRangeAxis(192, (org.jfree.chart.axis.ValueAxis) numberAxis18, true);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str19.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str20.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str2 = numberAxis1.getLabel();
        numberAxis1.setFixedDimension((double) (-1L));
        numberAxis1.setPositiveArrowVisible(false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str2.equals("TextAnchor.BASELINE_LEFT"));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation6 = categoryPlot0.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot0.getRangeAxis((int) '4');
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot0.getDomainAxis(175);
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent12 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot0, jFreeChart11);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=192,g=192,b=192]");
        java.lang.String str15 = categoryAxis14.getLabel();
        java.util.List list16 = categoryPlot0.getCategoriesForAxis(categoryAxis14);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "java.awt.Color[r=192,g=192,b=192]" + "'", str15.equals("java.awt.Color[r=192,g=192,b=192]"));
        org.junit.Assert.assertNotNull(list16);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        xYPlot0.setDomainAxis(12, valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color8, stroke9);
        xYPlot6.setBackgroundPaint((java.awt.Paint) color8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        xYPlot6.setRenderer(6, xYItemRenderer13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        xYPlot6.removeChangeListener(plotChangeListener15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection18 = xYPlot6.getDomainMarkers(layer17);
        java.util.Collection collection19 = xYPlot0.getDomainMarkers(0, layer17);
        org.jfree.chart.event.PlotChangeListener plotChangeListener20 = null;
        xYPlot0.removeChangeListener(plotChangeListener20);
        boolean boolean22 = xYPlot0.isDomainGridlinesVisible();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent23 = null;
        xYPlot0.rendererChanged(rendererChangeEvent23);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertNull(collection19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        java.lang.String str1 = unitType0.toString();
        java.lang.Object obj2 = null;
        boolean boolean3 = unitType0.equals(obj2);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UnitType.RELATIVE" + "'", str1.equals("UnitType.RELATIVE"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=192,g=192,b=192]");
        float float2 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis1.getCategoryMiddle(100, 13, rectangle2D5, rectangleEdge6);
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) (short) -1);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.axis.AxisState axisState11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        try {
            java.util.List list14 = categoryAxis1.refreshTicks(graphics2D10, axisState11, rectangle2D12, rectangleEdge13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int4 = xYPlot1.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3);
        org.jfree.chart.LegendItemCollection legendItemCollection5 = xYPlot1.getFixedLegendItems();
        boolean boolean6 = textAnchor0.equals((java.lang.Object) xYPlot1);
        org.jfree.chart.axis.ValueAxis valueAxis7 = xYPlot1.getRangeAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        int int9 = xYPlot1.getIndexOf(xYItemRenderer8);
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNull(legendItemCollection5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        java.util.List list7 = categoryPlot0.getCategoriesForAxis(categoryAxis6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        boolean boolean12 = categoryPlot0.render(graphics2D8, rectangle2D9, (-1), plotRenderingInfo11);
        categoryPlot0.clearAnnotations();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor14 = org.jfree.chart.axis.CategoryAnchor.END;
        categoryPlot0.setDomainGridlinePosition(categoryAnchor14);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot16.setAnchorValue((double) (-1L), true);
        categoryPlot16.setRangeCrosshairVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation22 = categoryPlot16.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis24 = categoryPlot16.getRangeAxis((int) '4');
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke29 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker30 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color28, stroke29);
        xYPlot26.setBackgroundPaint((java.awt.Paint) color28);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = null;
        xYPlot26.setRenderer(6, xYItemRenderer33);
        org.jfree.chart.event.PlotChangeListener plotChangeListener35 = null;
        xYPlot26.removeChangeListener(plotChangeListener35);
        java.awt.Stroke stroke37 = xYPlot26.getDomainZeroBaselineStroke();
        xYPlot25.setRangeGridlineStroke(stroke37);
        xYPlot25.setRangeCrosshairVisible(true);
        org.jfree.chart.plot.XYPlot xYPlot41 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint42 = xYPlot41.getDomainZeroBaselinePaint();
        boolean boolean43 = xYPlot41.isRangeGridlinesVisible();
        org.jfree.chart.axis.AxisLocation axisLocation44 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot41.setRangeAxisLocation(axisLocation44);
        xYPlot25.setDomainAxisLocation(axisLocation44, true);
        categoryPlot16.setDomainAxisLocation(axisLocation44, true);
        java.lang.String str50 = axisLocation44.toString();
        categoryPlot0.setDomainAxisLocation(axisLocation44, false);
        org.jfree.chart.util.SortOrder sortOrder53 = org.jfree.chart.util.SortOrder.DESCENDING;
        boolean boolean55 = sortOrder53.equals((java.lang.Object) 1);
        categoryPlot0.setColumnRenderingOrder(sortOrder53);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(categoryAnchor14);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertNull(valueAxis24);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(axisLocation44);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "AxisLocation.TOP_OR_LEFT" + "'", str50.equals("AxisLocation.TOP_OR_LEFT"));
        org.junit.Assert.assertNotNull(sortOrder53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int3 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis2);
        double double4 = numberAxis2.getFixedAutoRange();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis2.setTickUnit(numberTickUnit5);
        numberAxis2.setAxisLineVisible(false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(numberTickUnit5);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.awt.Paint paint2 = numberAxis1.getLabelPaint();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = numberAxis1.valueToJava2D(0.0d, rectangle2D4, rectangleEdge5);
        numberAxis1.setNegativeArrowVisible(false);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        xYPlot2.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        xYPlot2.setRenderer((int) (byte) 1, xYItemRenderer6);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color9, stroke10);
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryMarker11.setLabelPaint(paint12);
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color16, stroke17);
        xYPlot14.setBackgroundPaint((java.awt.Paint) color16);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        xYPlot14.setRenderer(6, xYItemRenderer21);
        org.jfree.chart.event.PlotChangeListener plotChangeListener23 = null;
        xYPlot14.removeChangeListener(plotChangeListener23);
        org.jfree.chart.util.Layer layer25 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection26 = xYPlot14.getDomainMarkers(layer25);
        boolean boolean28 = layer25.equals((java.lang.Object) "SeriesRenderingOrder.FORWARD");
        boolean boolean29 = xYPlot2.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker11, layer25);
        java.util.Collection collection30 = categoryPlot0.getDomainMarkers(0, layer25);
        categoryPlot0.setRangeCrosshairVisible(true);
        java.awt.Stroke stroke33 = categoryPlot0.getRangeCrosshairStroke();
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(layer25);
        org.junit.Assert.assertNull(collection26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNull(collection30);
        org.junit.Assert.assertNotNull(stroke33);
    }

//    @Test
//    public void test037() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test037");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
//        java.awt.Paint paint3 = xYPlot2.getDomainZeroBaselinePaint();
//        boolean boolean4 = day0.equals((java.lang.Object) paint3);
//        java.util.Date date5 = day0.getStart();
//        java.lang.String str6 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day0.previous();
//        org.jfree.data.time.SerialDate serialDate8 = day0.getSerialDate();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertNotNull(paint3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(serialDate8);
//    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainZoomable();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int7 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color10, stroke11);
        xYPlot8.setBackgroundPaint((java.awt.Paint) color10);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        xYPlot8.setRenderer(6, xYItemRenderer15);
        org.jfree.chart.util.Layer layer18 = null;
        java.util.Collection collection19 = xYPlot8.getRangeMarkers((int) ' ', layer18);
        boolean boolean20 = numberAxis6.hasListener((java.util.EventListener) xYPlot8);
        java.lang.Object obj21 = numberAxis6.clone();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis6, categoryItemRenderer22);
        org.jfree.chart.util.SortOrder sortOrder24 = categoryPlot23.getRowRenderingOrder();
        categoryPlot0.setColumnRenderingOrder(sortOrder24);
        org.jfree.chart.axis.ValueAxis valueAxis26 = categoryPlot0.getRangeAxis();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(collection19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(sortOrder24);
        org.junit.Assert.assertNull(valueAxis26);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color2, stroke3);
        xYPlot0.setBackgroundPaint((java.awt.Paint) color2);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        xYPlot0.setRenderer(6, xYItemRenderer7);
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        xYPlot0.removeChangeListener(plotChangeListener9);
        org.jfree.chart.axis.ValueAxis valueAxis12 = xYPlot0.getRangeAxisForDataset((int) (short) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        xYPlot0.setAxisOffset(rectangleInsets13);
        org.jfree.chart.util.Layer layer16 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection17 = xYPlot0.getDomainMarkers(0, layer16);
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        xYPlot0.setDataset(3, xYDataset19);
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke23 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker24 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color22, stroke23);
        categoryMarker24.setDrawAsLine(false);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor27 = org.jfree.chart.util.RectangleAnchor.LEFT;
        categoryMarker24.setLabelAnchor(rectangleAnchor27);
        java.awt.Color color31 = java.awt.Color.getColor("hi!", 0);
        categoryMarker24.setPaint((java.awt.Paint) color31);
        boolean boolean33 = xYPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker24);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(layer16);
        org.junit.Assert.assertNull(collection17);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(rectangleAnchor27);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation6 = categoryPlot0.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot0.getRangeAxis((int) '4');
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.axis.AxisLocation axisLocation10 = axisLocation9.getOpposite();
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(axisLocation10);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int5 = xYPlot2.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis4);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color8, stroke9);
        xYPlot6.setBackgroundPaint((java.awt.Paint) color8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        xYPlot6.setRenderer(6, xYItemRenderer13);
        org.jfree.chart.util.Layer layer16 = null;
        java.util.Collection collection17 = xYPlot6.getRangeMarkers((int) ' ', layer16);
        boolean boolean18 = numberAxis4.hasListener((java.util.EventListener) xYPlot6);
        java.lang.Object obj19 = numberAxis4.clone();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis4, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        categoryPlot21.mapDatasetToRangeAxis(10, 6);
        categoryPlot21.configureDomainAxes();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNull(collection17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertNotNull(sortOrder22);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        boolean boolean2 = xYPlot0.isRangeGridlinesVisible();
        java.awt.Color color5 = java.awt.Color.getColor("hi!", 0);
        xYPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color5);
        org.jfree.chart.axis.ValueAxis valueAxis7 = xYPlot0.getDomainAxis();
        java.awt.Color color8 = java.awt.Color.WHITE;
        xYPlot0.setOutlinePaint((java.awt.Paint) color8);
        java.awt.color.ColorSpace colorSpace10 = null;
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker(0.0d);
        double double13 = valueMarker12.getValue();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str16 = numberAxis15.getLabel();
        java.lang.String str17 = numberAxis15.getLabel();
        java.awt.Paint paint18 = numberAxis15.getAxisLinePaint();
        boolean boolean19 = valueMarker12.equals((java.lang.Object) paint18);
        java.awt.Color color20 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        boolean boolean21 = valueMarker12.equals((java.lang.Object) color20);
        java.awt.Color color22 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        java.awt.Color color26 = java.awt.Color.RED;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot();
        xYPlot27.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation30 = xYPlot27.getOrientation();
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.awt.Paint paint33 = numberAxis32.getLabelPaint();
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = null;
        double double37 = numberAxis32.valueToJava2D(0.0d, rectangle2D35, rectangleEdge36);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray38 = new org.jfree.chart.axis.ValueAxis[] { numberAxis32 };
        xYPlot27.setDomainAxes(valueAxisArray38);
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color42 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke43 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker44 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color42, stroke43);
        xYPlot40.setBackgroundPaint((java.awt.Paint) color42);
        xYPlot27.setRangeCrosshairPaint((java.awt.Paint) color42);
        float[] floatArray51 = new float[] { (byte) 1, 10L, 100.0f, 100.0f };
        float[] floatArray52 = color42.getComponents(floatArray51);
        float[] floatArray53 = color26.getRGBComponents(floatArray52);
        float[] floatArray54 = java.awt.Color.RGBtoHSB((int) (byte) 1, (int) (byte) 1, 0, floatArray53);
        float[] floatArray55 = color22.getRGBComponents(floatArray53);
        float[] floatArray56 = color20.getColorComponents(floatArray55);
        try {
            float[] floatArray57 = color8.getComponents(colorSpace10, floatArray55);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str16.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str17.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(plotOrientation30);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(valueAxisArray38);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(floatArray51);
        org.junit.Assert.assertNotNull(floatArray52);
        org.junit.Assert.assertNotNull(floatArray53);
        org.junit.Assert.assertNotNull(floatArray54);
        org.junit.Assert.assertNotNull(floatArray55);
        org.junit.Assert.assertNotNull(floatArray56);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) '4', 500, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Green");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        org.jfree.chart.util.SortOrder sortOrder4 = org.jfree.chart.util.SortOrder.DESCENDING;
        boolean boolean6 = sortOrder4.equals((java.lang.Object) 1);
        categoryPlot0.setColumnRenderingOrder(sortOrder4);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        xYPlot8.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        xYPlot8.setRenderer((int) (byte) 1, xYItemRenderer12);
        double double14 = xYPlot8.getRangeCrosshairValue();
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int18 = xYPlot15.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis17);
        boolean boolean19 = xYPlot8.equals((java.lang.Object) xYPlot15);
        xYPlot8.setForegroundAlpha((float) 10L);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor25 = null;
        java.awt.geom.Point2D point2D26 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D24, rectangleAnchor25);
        xYPlot8.zoomRangeAxes((double) 128, plotRenderingInfo23, point2D26, true);
        boolean boolean29 = sortOrder4.equals((java.lang.Object) xYPlot8);
        org.junit.Assert.assertNotNull(sortOrder4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(point2D26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        java.awt.Paint paint4 = categoryPlot0.getDomainGridlinePaint();
        categoryPlot0.clearDomainAxes();
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        boolean boolean2 = xYPlot0.isRangeGridlinesVisible();
        java.awt.Color color5 = java.awt.Color.getColor("hi!", 0);
        xYPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color5);
        java.lang.Object obj7 = xYPlot0.clone();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = xYPlot0.getRangeAxisEdge();
        org.jfree.data.xy.XYDataset xYDataset10 = xYPlot0.getDataset(0);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNull(xYDataset10);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str2 = numberAxis1.getLabel();
        numberAxis1.setVisible(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis1.setTickUnit(numberTickUnit5, false, false);
        numberAxis1.setAxisLineVisible(false);
        numberAxis1.setAutoTickUnitSelection(true);
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint14 = xYPlot13.getDomainZeroBaselinePaint();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color16, stroke17);
        java.awt.Paint paint19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryMarker18.setLabelPaint(paint19);
        xYPlot13.setDomainZeroBaselinePaint(paint19);
        java.awt.Stroke stroke22 = xYPlot13.getDomainZeroBaselineStroke();
        numberAxis1.setAxisLineStroke(stroke22);
        numberAxis1.setLabelURL("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.awt.Stroke stroke26 = numberAxis1.getTickMarkStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = numberAxis1.getLabelInsets();
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D31 = rectangleInsets27.createOutsetRectangle(rectangle2D28, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str2.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(numberTickUnit5);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(rectangleInsets27);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        xYPlot0.setDataset(xYDataset3);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        xYPlot0.setRangeAxis((int) (short) 1, valueAxis6);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str9 = xYPlot8.getNoDataMessage();
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot8.setDataset(0, xYDataset11);
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot13.setDomainGridlineStroke(stroke14);
        java.awt.Stroke stroke16 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        xYPlot13.setRangeGridlineStroke(stroke16);
        xYPlot8.setOutlineStroke(stroke16);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = xYPlot8.getRenderer(2);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder21 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        xYPlot8.setSeriesRenderingOrder(seriesRenderingOrder21);
        xYPlot0.setSeriesRenderingOrder(seriesRenderingOrder21);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke30 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker31 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color29, stroke30);
        xYPlot27.setBackgroundPaint((java.awt.Paint) color29);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        xYPlot27.setRenderer(6, xYItemRenderer34);
        org.jfree.chart.event.PlotChangeListener plotChangeListener36 = null;
        xYPlot27.removeChangeListener(plotChangeListener36);
        java.awt.Stroke stroke38 = xYPlot27.getDomainZeroBaselineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo40 = null;
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor42 = null;
        java.awt.geom.Point2D point2D43 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D41, rectangleAnchor42);
        xYPlot27.zoomRangeAxes(2.0d, plotRenderingInfo40, point2D43, true);
        xYPlot0.zoomRangeAxes(0.0d, 100.0d, plotRenderingInfo26, point2D43);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNull(xYItemRenderer20);
        org.junit.Assert.assertNotNull(seriesRenderingOrder21);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(point2D43);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        java.awt.Color color0 = java.awt.Color.yellow;
        java.lang.Class<?> wildcardClass1 = color0.getClass();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        categoryPlot0.setRangeCrosshairVisible(true);
        categoryPlot0.clearRangeMarkers(11);
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot0.getDomainAxisLocation();
        org.junit.Assert.assertNotNull(axisLocation8);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        xYPlot0.setDomainAxis(12, valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color8, stroke9);
        xYPlot6.setBackgroundPaint((java.awt.Paint) color8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        xYPlot6.setRenderer(6, xYItemRenderer13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        xYPlot6.removeChangeListener(plotChangeListener15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection18 = xYPlot6.getDomainMarkers(layer17);
        java.util.Collection collection19 = xYPlot0.getDomainMarkers(0, layer17);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder20 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.axis.ValueAxis valueAxis21 = xYPlot0.getRangeAxis();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertNull(collection19);
        org.junit.Assert.assertNotNull(datasetRenderingOrder20);
        org.junit.Assert.assertNull(valueAxis21);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int3 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis2);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int9 = xYPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis8);
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color12, stroke13);
        xYPlot10.setBackgroundPaint((java.awt.Paint) color12);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        xYPlot10.setRenderer(6, xYItemRenderer17);
        org.jfree.chart.util.Layer layer20 = null;
        java.util.Collection collection21 = xYPlot10.getRangeMarkers((int) ' ', layer20);
        boolean boolean22 = numberAxis8.hasListener((java.util.EventListener) xYPlot10);
        java.lang.Object obj23 = numberAxis8.clone();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, (org.jfree.chart.axis.ValueAxis) numberAxis8, categoryItemRenderer24);
        int int26 = xYPlot0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        xYPlot0.setRenderer((int) (byte) 1, xYItemRenderer4);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int9 = xYPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis8);
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis8);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        numberAxis12.setTickLabelPaint((java.awt.Paint) color13);
        numberAxis12.setLowerBound(0.0d);
        double double17 = numberAxis12.getFixedDimension();
        java.awt.Stroke stroke18 = numberAxis12.getAxisLineStroke();
        org.jfree.data.Range range19 = xYPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis12);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = xYPlot0.getDomainAxisEdge();
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNull(range19);
        org.junit.Assert.assertNotNull(rectangleEdge20);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        java.awt.Color color1 = java.awt.Color.black;
        java.awt.Color color2 = java.awt.Color.getColor("UnitType.RELATIVE", color1);
        int int3 = color2.getGreen();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = xYPlot5.getOrientation();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.awt.Paint paint11 = numberAxis10.getLabelPaint();
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = null;
        double double15 = numberAxis10.valueToJava2D(0.0d, rectangle2D13, rectangleEdge14);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray16 = new org.jfree.chart.axis.ValueAxis[] { numberAxis10 };
        xYPlot5.setDomainAxes(valueAxisArray16);
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke21 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color20, stroke21);
        xYPlot18.setBackgroundPaint((java.awt.Paint) color20);
        xYPlot5.setRangeCrosshairPaint((java.awt.Paint) color20);
        float[] floatArray29 = new float[] { (byte) 1, 10L, 100.0f, 100.0f };
        float[] floatArray30 = color20.getComponents(floatArray29);
        float[] floatArray31 = color4.getComponents(floatArray29);
        float[] floatArray32 = color2.getColorComponents(floatArray31);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(valueAxisArray16);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(floatArray29);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertNotNull(floatArray32);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        xYPlot0.setDomainAxis(12, valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color8, stroke9);
        xYPlot6.setBackgroundPaint((java.awt.Paint) color8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        xYPlot6.setRenderer(6, xYItemRenderer13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        xYPlot6.removeChangeListener(plotChangeListener15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection18 = xYPlot6.getDomainMarkers(layer17);
        java.util.Collection collection19 = xYPlot0.getDomainMarkers(0, layer17);
        org.jfree.chart.event.PlotChangeListener plotChangeListener20 = null;
        xYPlot0.removeChangeListener(plotChangeListener20);
        boolean boolean22 = xYPlot0.isDomainGridlinesVisible();
        org.jfree.chart.plot.PlotOrientation plotOrientation23 = xYPlot0.getOrientation();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertNull(collection19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(plotOrientation23);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker5 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color3, stroke4);
        java.awt.Paint paint6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryMarker5.setLabelPaint(paint6);
        xYPlot0.setDomainZeroBaselinePaint(paint6);
        java.awt.Stroke stroke9 = xYPlot0.getDomainZeroBaselineStroke();
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker15 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color13, stroke14);
        org.jfree.chart.util.Layer layer16 = null;
        xYPlot10.addRangeMarker(4, (org.jfree.chart.plot.Marker) categoryMarker15, layer16);
        java.awt.Font font18 = categoryMarker15.getLabelFont();
        xYPlot0.setNoDataMessageFont(font18);
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        xYPlot0.setDataset(xYDataset20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot0.getRangeAxis((int) (byte) 10);
        boolean boolean24 = xYPlot0.isRangeZoomable();
        int int25 = xYPlot0.getWeight();
        org.jfree.chart.axis.ValueAxis valueAxis27 = xYPlot0.getDomainAxisForDataset(0);
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        try {
            xYPlot0.setDataset((-1), xYDataset29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNull(valueAxis27);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("EXPAND");
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        xYPlot6.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation9 = xYPlot6.getOrientation();
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.awt.Paint paint12 = numberAxis11.getLabelPaint();
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        double double16 = numberAxis11.valueToJava2D(0.0d, rectangle2D14, rectangleEdge15);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray17 = new org.jfree.chart.axis.ValueAxis[] { numberAxis11 };
        xYPlot6.setDomainAxes(valueAxisArray17);
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker23 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color21, stroke22);
        xYPlot19.setBackgroundPaint((java.awt.Paint) color21);
        xYPlot6.setRangeCrosshairPaint((java.awt.Paint) color21);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = xYPlot6.getRangeAxisEdge(0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        try {
            org.jfree.chart.axis.AxisState axisState29 = dateAxis1.draw(graphics2D2, 0.0d, rectangle2D4, rectangle2D5, rectangleEdge27, plotRenderingInfo28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation9);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(valueAxisArray17);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(rectangleEdge27);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=192,g=192,b=192]");
        java.lang.String str2 = categoryAxis1.getLabel();
        double double3 = categoryAxis1.getUpperMargin();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java.awt.Color[r=192,g=192,b=192]" + "'", str2.equals("java.awt.Color[r=192,g=192,b=192]"));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str1 = xYPlot0.getNoDataMessage();
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        xYPlot0.setDataset(0, xYDataset3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot5.setDomainGridlineStroke(stroke6);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        xYPlot5.setRangeGridlineStroke(stroke8);
        xYPlot0.setOutlineStroke(stroke8);
        org.jfree.chart.axis.ValueAxis valueAxis11 = xYPlot0.getDomainAxis();
        java.awt.Stroke stroke12 = xYPlot0.getRangeZeroBaselineStroke();
        java.awt.Paint paint13 = null;
        try {
            xYPlot0.setRangeGridlinePaint(paint13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str2 = numberAxis1.getLabel();
        numberAxis1.setVisible(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis1.setTickUnit(numberTickUnit5, false, false);
        numberAxis1.setLabelURL("SeriesRenderingOrder.FORWARD");
        boolean boolean11 = numberAxis1.isAutoTickUnitSelection();
        numberAxis1.resizeRange((double) 255);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str2.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(numberTickUnit5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int6 = xYPlot3.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis5);
        numberAxis5.setLowerBound((double) (short) 10);
        xYPlot0.setDomainAxis((int) (byte) 1, (org.jfree.chart.axis.ValueAxis) numberAxis5, true);
        java.awt.Paint paint11 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.axis.AxisSpace axisSpace12 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace12);
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot14.setDomainGridlineStroke(stroke15);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        xYPlot14.zoomDomainAxes(100.0d, plotRenderingInfo18, point2D19, false);
        java.awt.Stroke stroke22 = xYPlot14.getDomainCrosshairStroke();
        xYPlot0.setRangeZeroBaselineStroke(stroke22);
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = xYPlot0.getRangeAxisEdge(12);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation26 = null;
        try {
            boolean boolean27 = xYPlot0.removeAnnotation(xYAnnotation26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(rectangleEdge25);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color2, stroke3);
        xYPlot0.setBackgroundPaint((java.awt.Paint) color2);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        xYPlot0.setRenderer(6, xYItemRenderer7);
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        xYPlot0.removeChangeListener(plotChangeListener9);
        org.jfree.chart.axis.ValueAxis valueAxis12 = xYPlot0.getRangeAxisForDataset((int) (short) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        xYPlot0.setAxisOffset(rectangleInsets13);
        java.awt.Color color15 = java.awt.Color.blue;
        xYPlot0.setOutlinePaint((java.awt.Paint) color15);
        java.awt.Color color17 = color15.darker();
        int int18 = color15.getRed();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color6, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color10, stroke11);
        categoryMarker8.setLabelPaint((java.awt.Paint) color10);
        org.jfree.chart.util.Layer layer14 = null;
        categoryPlot0.addRangeMarker((int) (short) 1, (org.jfree.chart.plot.Marker) categoryMarker8, layer14, false);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray17 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot0.setDomainAxes(categoryAxisArray17);
        categoryPlot0.configureRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        categoryPlot0.setDataset(categoryDataset20);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(categoryAxisArray17);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation6 = categoryPlot0.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot0.getRangeAxis((int) '4');
        categoryPlot0.setAnchorValue((double) (-1L));
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryPlot0.setRangeCrosshairStroke(stroke11);
        categoryPlot0.setAnchorValue((double) 12, true);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color2, stroke3);
        xYPlot0.setBackgroundPaint((java.awt.Paint) color2);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        xYPlot0.setRenderer(6, xYItemRenderer7);
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        xYPlot0.removeChangeListener(plotChangeListener9);
        org.jfree.chart.axis.ValueAxis valueAxis12 = xYPlot0.getRangeAxisForDataset((int) (short) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        xYPlot0.setAxisOffset(rectangleInsets13);
        double double16 = rectangleInsets13.trimHeight(0.0d);
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D20 = rectangleInsets13.createOutsetRectangle(rectangle2D17, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-4.0d) + "'", double16 == (-4.0d));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color2, stroke3);
        xYPlot0.setBackgroundPaint((java.awt.Paint) color2);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        xYPlot0.setRenderer(6, xYItemRenderer7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.axis.AxisLocation axisLocation11 = axisLocation10.getOpposite();
        xYPlot0.setDomainAxisLocation(13, axisLocation10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int18 = xYPlot15.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis17);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        xYPlot15.setRangeZeroBaselinePaint((java.awt.Paint) color19);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint25 = xYPlot24.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int30 = xYPlot27.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis29);
        numberAxis29.setLowerBound((double) (short) 10);
        xYPlot24.setDomainAxis((int) (byte) 1, (org.jfree.chart.axis.ValueAxis) numberAxis29, true);
        java.awt.Paint paint35 = xYPlot24.getDomainZeroBaselinePaint();
        org.jfree.chart.axis.AxisSpace axisSpace36 = null;
        xYPlot24.setFixedRangeAxisSpace(axisSpace36);
        org.jfree.chart.plot.XYPlot xYPlot38 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke39 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot38.setDomainGridlineStroke(stroke39);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo42 = null;
        java.awt.geom.Point2D point2D43 = null;
        xYPlot38.zoomDomainAxes(100.0d, plotRenderingInfo42, point2D43, false);
        java.awt.Stroke stroke46 = xYPlot38.getDomainCrosshairStroke();
        xYPlot24.setRangeZeroBaselineStroke(stroke46);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer48 = xYPlot24.getRenderer();
        org.jfree.data.xy.XYDataset xYDataset49 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer50 = xYPlot24.getRendererForDataset(xYDataset49);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo52 = null;
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor54 = null;
        java.awt.geom.Point2D point2D55 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D53, rectangleAnchor54);
        xYPlot24.zoomDomainAxes((double) 4, plotRenderingInfo52, point2D55);
        xYPlot15.zoomDomainAxes((double) (-1.0f), 0.0d, plotRenderingInfo23, point2D55);
        xYPlot0.zoomRangeAxes((double) 12, plotRenderingInfo14, point2D55);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNull(xYItemRenderer48);
        org.junit.Assert.assertNull(xYItemRenderer50);
        org.junit.Assert.assertNotNull(point2D55);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=192,g=192,b=192]");
        java.lang.String str2 = categoryAxis1.getLabel();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint5 = xYPlot4.getDomainZeroBaselinePaint();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color7, stroke8);
        org.jfree.data.general.Dataset dataset11 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) 100, dataset11);
        boolean boolean13 = categoryMarker9.equals((java.lang.Object) 100);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        categoryMarker9.setPaint((java.awt.Paint) color14);
        xYPlot4.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker9);
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot18.setAnchorValue((double) (-1L), true);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = categoryPlot18.getDomainAxis(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        java.util.List list25 = categoryPlot18.getCategoriesForAxis(categoryAxis24);
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int29 = xYPlot26.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis28);
        java.awt.Stroke stroke30 = numberAxis28.getAxisLineStroke();
        numberAxis28.setVisible(false);
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color35 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke36 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker37 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color35, stroke36);
        xYPlot33.setBackgroundPaint((java.awt.Paint) color35);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer40 = null;
        xYPlot33.setRenderer(6, xYItemRenderer40);
        org.jfree.chart.event.PlotChangeListener plotChangeListener42 = null;
        xYPlot33.removeChangeListener(plotChangeListener42);
        java.awt.Stroke stroke44 = xYPlot33.getDomainZeroBaselineStroke();
        numberAxis28.setTickMarkStroke(stroke44);
        categoryPlot18.setRangeCrosshairStroke(stroke44);
        boolean boolean47 = categoryPlot18.isRangeCrosshairVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge49 = categoryPlot18.getRangeAxisEdge(10);
        org.jfree.chart.axis.AxisSpace axisSpace50 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace51 = categoryAxis1.reserveSpace(graphics2D3, (org.jfree.chart.plot.Plot) xYPlot4, rectangle2D17, rectangleEdge49, axisSpace50);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java.awt.Color[r=192,g=192,b=192]" + "'", str2.equals("java.awt.Color[r=192,g=192,b=192]"));
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNull(categoryAxis23);
        org.junit.Assert.assertNotNull(list25);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(rectangleEdge49);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int3 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        xYPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color4);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color10, stroke11);
        org.jfree.chart.util.Layer layer13 = null;
        xYPlot7.addRangeMarker(4, (org.jfree.chart.plot.Marker) categoryMarker12, layer13);
        java.awt.Color color15 = java.awt.Color.BLACK;
        categoryMarker12.setPaint((java.awt.Paint) color15);
        org.jfree.chart.util.Layer layer17 = null;
        xYPlot0.addRangeMarker(0, (org.jfree.chart.plot.Marker) categoryMarker12, layer17);
        org.jfree.chart.plot.ValueMarker valueMarker20 = new org.jfree.chart.plot.ValueMarker(0.0d);
        double double21 = valueMarker20.getValue();
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str24 = numberAxis23.getLabel();
        java.lang.String str25 = numberAxis23.getLabel();
        java.awt.Paint paint26 = numberAxis23.getAxisLinePaint();
        boolean boolean27 = valueMarker20.equals((java.lang.Object) paint26);
        java.awt.Color color28 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        boolean boolean29 = valueMarker20.equals((java.lang.Object) color28);
        categoryMarker12.setOutlinePaint((java.awt.Paint) color28);
        categoryMarker12.setKey((java.lang.Comparable) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str24.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str25.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color1, stroke2);
        java.awt.Paint paint4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryMarker3.setLabelPaint(paint4);
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryMarker3.setLabelFont(font6);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str10 = numberAxis9.getLabel();
        java.lang.String str11 = numberAxis9.getLabel();
        java.awt.Paint paint12 = numberAxis9.getAxisLinePaint();
        categoryMarker3.setLabelPaint(paint12);
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color16, stroke17);
        xYPlot14.setBackgroundPaint((java.awt.Paint) color16);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        xYPlot14.setRenderer(6, xYItemRenderer21);
        org.jfree.chart.event.PlotChangeListener plotChangeListener23 = null;
        xYPlot14.removeChangeListener(plotChangeListener23);
        java.awt.Paint paint25 = xYPlot14.getRangeTickBandPaint();
        categoryMarker3.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot14);
        java.awt.Color color27 = java.awt.Color.red;
        categoryMarker3.setOutlinePaint((java.awt.Paint) color27);
        boolean boolean29 = categoryMarker3.getDrawAsLine();
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = categoryMarker3.getLabelOffset();
        double double31 = rectangleInsets30.getRight();
        double double33 = rectangleInsets30.calculateRightOutset(2.0d);
        double double35 = rectangleInsets30.calculateTopInset((double) (short) 1);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str10.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str11.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNull(paint25);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 3.0d + "'", double31 == 3.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 3.0d + "'", double33 == 3.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 3.0d + "'", double35 == 3.0d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int3 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis2);
        numberAxis2.setLowerBound((double) (short) 10);
        boolean boolean6 = numberAxis2.isTickMarksVisible();
        float float7 = numberAxis2.getTickMarkInsideLength();
        java.awt.Shape shape8 = numberAxis2.getDownArrow();
        numberAxis2.setRangeAboutValue((-1.0d), 0.05d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(shape8);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        java.util.List list7 = categoryPlot0.getCategoriesForAxis(categoryAxis6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=192,g=192,b=192]");
        categoryPlot0.setDomainAxis(categoryAxis9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace11, true);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(list7);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        java.awt.Color color5 = java.awt.Color.RED;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        xYPlot6.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation9 = xYPlot6.getOrientation();
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.awt.Paint paint12 = numberAxis11.getLabelPaint();
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        double double16 = numberAxis11.valueToJava2D(0.0d, rectangle2D14, rectangleEdge15);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray17 = new org.jfree.chart.axis.ValueAxis[] { numberAxis11 };
        xYPlot6.setDomainAxes(valueAxisArray17);
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker23 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color21, stroke22);
        xYPlot19.setBackgroundPaint((java.awt.Paint) color21);
        xYPlot6.setRangeCrosshairPaint((java.awt.Paint) color21);
        float[] floatArray30 = new float[] { (byte) 1, 10L, 100.0f, 100.0f };
        float[] floatArray31 = color21.getComponents(floatArray30);
        float[] floatArray32 = color5.getRGBComponents(floatArray31);
        float[] floatArray33 = java.awt.Color.RGBtoHSB((int) (byte) 1, (int) (byte) 1, 0, floatArray32);
        float[] floatArray34 = color1.getRGBComponents(floatArray32);
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint36 = xYPlot35.getDomainZeroBaselinePaint();
        java.awt.Color color38 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke39 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker40 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color38, stroke39);
        java.awt.Paint paint41 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryMarker40.setLabelPaint(paint41);
        xYPlot35.setDomainZeroBaselinePaint(paint41);
        java.awt.Stroke stroke44 = xYPlot35.getDomainZeroBaselineStroke();
        java.awt.Paint paint45 = null;
        org.jfree.chart.plot.XYPlot xYPlot46 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot47 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color49 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke50 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker51 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color49, stroke50);
        xYPlot47.setBackgroundPaint((java.awt.Paint) color49);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer54 = null;
        xYPlot47.setRenderer(6, xYItemRenderer54);
        org.jfree.chart.event.PlotChangeListener plotChangeListener56 = null;
        xYPlot47.removeChangeListener(plotChangeListener56);
        java.awt.Stroke stroke58 = xYPlot47.getDomainZeroBaselineStroke();
        xYPlot46.setRangeGridlineStroke(stroke58);
        xYPlot46.setRangeCrosshairVisible(true);
        org.jfree.chart.plot.XYPlot xYPlot62 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint63 = xYPlot62.getDomainZeroBaselinePaint();
        boolean boolean64 = xYPlot62.isRangeGridlinesVisible();
        org.jfree.chart.axis.AxisLocation axisLocation65 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot62.setRangeAxisLocation(axisLocation65);
        xYPlot46.setDomainAxisLocation(axisLocation65, true);
        java.awt.Stroke stroke69 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot46.setOutlineStroke(stroke69);
        try {
            org.jfree.chart.plot.ValueMarker valueMarker72 = new org.jfree.chart.plot.ValueMarker((double) (short) 100, (java.awt.Paint) color1, stroke44, paint45, stroke69, (float) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(plotOrientation9);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(valueAxisArray17);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertNotNull(paint63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertNotNull(axisLocation65);
        org.junit.Assert.assertNotNull(stroke69);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint2 = numberAxis1.getLabelPaint();
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker5 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color3, stroke4);
        java.awt.Paint paint6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryMarker5.setLabelPaint(paint6);
        xYPlot0.setDomainZeroBaselinePaint(paint6);
        java.awt.Stroke stroke9 = xYPlot0.getDomainZeroBaselineStroke();
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker15 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color13, stroke14);
        org.jfree.chart.util.Layer layer16 = null;
        xYPlot10.addRangeMarker(4, (org.jfree.chart.plot.Marker) categoryMarker15, layer16);
        java.awt.Font font18 = categoryMarker15.getLabelFont();
        xYPlot0.setNoDataMessageFont(font18);
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        xYPlot0.setDataset(xYDataset20);
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker25 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color23, stroke24);
        org.jfree.data.general.Dataset dataset27 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent28 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) 100, dataset27);
        boolean boolean29 = categoryMarker25.equals((java.lang.Object) 100);
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker25);
        java.awt.Color color31 = java.awt.Color.orange;
        categoryMarker25.setOutlinePaint((java.awt.Paint) color31);
        try {
            categoryMarker25.setAlpha((float) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(color31);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        xYPlot0.setRenderer((int) (byte) 1, xYItemRenderer4);
        double double6 = xYPlot0.getRangeCrosshairValue();
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int10 = xYPlot7.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis9);
        boolean boolean11 = xYPlot0.equals((java.lang.Object) xYPlot7);
        xYPlot0.setForegroundAlpha((float) 10L);
        java.awt.Paint paint14 = xYPlot0.getRangeCrosshairPaint();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str2 = numberAxis1.getLabel();
        numberAxis1.setVisible(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis1.setTickUnit(numberTickUnit5, false, false);
        numberAxis1.setLabelURL("SeriesRenderingOrder.FORWARD");
        numberAxis1.setLowerMargin((double) (-16744448));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str2.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(numberTickUnit5);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int6 = xYPlot3.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis5);
        numberAxis5.setLowerBound((double) (short) 10);
        xYPlot0.setDomainAxis((int) (byte) 1, (org.jfree.chart.axis.ValueAxis) numberAxis5, true);
        java.awt.Paint paint11 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.axis.AxisSpace axisSpace12 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace12);
        float float14 = xYPlot0.getBackgroundAlpha();
        org.jfree.data.xy.XYDataset xYDataset15 = xYPlot0.getDataset();
        java.awt.Paint paint16 = null;
        xYPlot0.setDomainTickBandPaint(paint16);
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str20 = numberAxis19.getLabel();
        boolean boolean21 = numberAxis19.isAutoRange();
        boolean boolean22 = numberAxis19.getAutoRangeStickyZero();
        int int23 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis19);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 1.0f + "'", float14 == 1.0f);
        org.junit.Assert.assertNull(xYDataset15);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str20.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str3 = numberAxis2.getLabel();
        numberAxis2.setVisible(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit6 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis2.setTickUnit(numberTickUnit6, false, false);
        numberAxis2.setLabelURL("SeriesRenderingOrder.FORWARD");
        boolean boolean12 = numberAxis2.isAutoTickUnitSelection();
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str15 = numberAxis14.getLabel();
        java.lang.String str16 = numberAxis14.getLabel();
        java.awt.Paint paint17 = numberAxis14.getAxisLinePaint();
        java.awt.Shape shape18 = numberAxis14.getRightArrow();
        numberAxis2.setDownArrow(shape18);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit20 = numberAxis2.getTickUnit();
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) numberTickUnit20, "RectangleAnchor.BOTTOM");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str3.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(numberTickUnit6);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str15.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str16.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(numberTickUnit20);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str2 = numberAxis1.getLabel();
        numberAxis1.setVisible(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis1.setTickUnit(numberTickUnit5, false, false);
        numberAxis1.setAxisLineVisible(false);
        double double11 = numberAxis1.getAutoRangeMinimumSize();
        boolean boolean12 = numberAxis1.isTickLabelsVisible();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str2.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(numberTickUnit5);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0E-8d + "'", double11 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color2, stroke3);
        xYPlot0.setBackgroundPaint((java.awt.Paint) color2);
        xYPlot0.setOutlineVisible(false);
        java.awt.Stroke stroke8 = xYPlot0.getRangeGridlineStroke();
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str12 = numberAxis11.getLabel();
        numberAxis11.setVisible(false);
        xYPlot0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis11, true);
        java.awt.Color color17 = java.awt.Color.ORANGE;
        xYPlot0.setRangeTickBandPaint((java.awt.Paint) color17);
        java.awt.Color color19 = color17.brighter();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str12.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color19);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=192,g=192,b=192]");
        float float2 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        categoryAxis1.setCategoryMargin((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str2 = numberAxis1.getLabel();
        numberAxis1.setVisible(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis1.setTickUnit(numberTickUnit5, false, false);
        numberAxis1.setLabelURL("SeriesRenderingOrder.FORWARD");
        boolean boolean11 = numberAxis1.isAutoTickUnitSelection();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str14 = numberAxis13.getLabel();
        java.lang.String str15 = numberAxis13.getLabel();
        java.awt.Paint paint16 = numberAxis13.getAxisLinePaint();
        java.awt.Shape shape17 = numberAxis13.getRightArrow();
        numberAxis1.setDownArrow(shape17);
        numberAxis1.setPositiveArrowVisible(true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str2.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(numberTickUnit5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str14.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str15.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(shape17);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        java.util.List list7 = categoryPlot0.getCategoriesForAxis(categoryAxis6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        boolean boolean12 = categoryPlot0.render(graphics2D8, rectangle2D9, (-1), plotRenderingInfo11);
        categoryPlot0.clearAnnotations();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor14 = org.jfree.chart.axis.CategoryAnchor.END;
        categoryPlot0.setDomainGridlinePosition(categoryAnchor14);
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        xYPlot16.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        xYPlot16.setRenderer((int) (byte) 1, xYItemRenderer20);
        double double22 = xYPlot16.getRangeCrosshairValue();
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker(0.0d);
        double double25 = valueMarker24.getValue();
        java.awt.Paint paint27 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke29 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot28.setDomainGridlineStroke(stroke29);
        org.jfree.chart.plot.ValueMarker valueMarker31 = new org.jfree.chart.plot.ValueMarker(0.0d, paint27, stroke29);
        java.awt.Font font32 = valueMarker31.getLabelFont();
        valueMarker24.setLabelFont(font32);
        valueMarker24.setLabel("ChartChangeEventType.DATASET_UPDATED");
        xYPlot16.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker24);
        boolean boolean37 = categoryPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker24);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(categoryAnchor14);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        java.lang.String str1 = seriesRenderingOrder0.toString();
        java.lang.String str2 = seriesRenderingOrder0.toString();
        java.lang.Object obj3 = null;
        boolean boolean4 = seriesRenderingOrder0.equals(obj3);
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SeriesRenderingOrder.FORWARD" + "'", str1.equals("SeriesRenderingOrder.FORWARD"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SeriesRenderingOrder.FORWARD" + "'", str2.equals("SeriesRenderingOrder.FORWARD"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color6, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color10, stroke11);
        categoryMarker8.setLabelPaint((java.awt.Paint) color10);
        org.jfree.chart.util.Layer layer14 = null;
        categoryPlot0.addRangeMarker((int) (short) 1, (org.jfree.chart.plot.Marker) categoryMarker8, layer14, false);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray17 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot0.setDomainAxes(categoryAxisArray17);
        org.jfree.chart.plot.Plot plot19 = categoryPlot0.getParent();
        categoryPlot0.setRangeGridlinesVisible(false);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(categoryAxisArray17);
        org.junit.Assert.assertNull(plot19);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(0.0d);
        double double2 = valueMarker1.getValue();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = valueMarker1.getLabelAnchor();
        java.lang.String str4 = valueMarker1.getLabel();
        valueMarker1.setLabel("java.awt.Color[r=64,g=255,b=64]");
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color2, stroke3);
        xYPlot0.setBackgroundPaint((java.awt.Paint) color2);
        xYPlot0.setOutlineVisible(false);
        java.awt.Stroke stroke8 = xYPlot0.getRangeGridlineStroke();
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str12 = numberAxis11.getLabel();
        numberAxis11.setVisible(false);
        xYPlot0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis11, true);
        org.jfree.chart.event.AxisChangeListener axisChangeListener17 = null;
        numberAxis11.removeChangeListener(axisChangeListener17);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str12.equals("TextAnchor.BASELINE_LEFT"));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color1, stroke2);
        java.awt.Paint paint4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryMarker3.setLabelPaint(paint4);
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryMarker3.setLabelFont(font6);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str10 = numberAxis9.getLabel();
        java.lang.String str11 = numberAxis9.getLabel();
        java.awt.Paint paint12 = numberAxis9.getAxisLinePaint();
        categoryMarker3.setLabelPaint(paint12);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent14 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker3);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType15 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        markerChangeEvent14.setType(chartChangeEventType15);
        org.jfree.chart.JFreeChart jFreeChart17 = null;
        markerChangeEvent14.setChart(jFreeChart17);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str10.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str11.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(chartChangeEventType15);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        java.awt.Paint paint4 = categoryPlot0.getDomainGridlinePaint();
        java.awt.Paint paint6 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot7.setDomainGridlineStroke(stroke8);
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.0d, paint6, stroke8);
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint12 = xYPlot11.getDomainZeroBaselinePaint();
        boolean boolean13 = xYPlot11.isRangeGridlinesVisible();
        java.awt.Color color16 = java.awt.Color.getColor("hi!", 0);
        xYPlot11.setRangeZeroBaselinePaint((java.awt.Paint) color16);
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint19 = xYPlot18.getDomainZeroBaselinePaint();
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker23 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color21, stroke22);
        java.awt.Paint paint24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryMarker23.setLabelPaint(paint24);
        xYPlot18.setDomainZeroBaselinePaint(paint24);
        java.awt.Stroke stroke27 = xYPlot18.getDomainZeroBaselineStroke();
        xYPlot11.setParent((org.jfree.chart.plot.Plot) xYPlot18);
        valueMarker10.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot11);
        org.jfree.chart.util.Layer layer30 = null;
        boolean boolean31 = categoryPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker10, layer30);
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot33.setAnchorValue((double) (-1L), true);
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = categoryPlot33.getDomainAxis(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = null;
        java.util.List list40 = categoryPlot33.getCategoriesForAxis(categoryAxis39);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=192,g=192,b=192]");
        categoryPlot33.setDomainAxis(categoryAxis42);
        categoryAxis42.addCategoryLabelToolTip((java.lang.Comparable) 100.0f, "UnitType.RELATIVE");
        categoryPlot0.setDomainAxis(0, categoryAxis42, false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNull(categoryAxis38);
        org.junit.Assert.assertNotNull(list40);
    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test093");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
//        java.awt.Paint paint3 = xYPlot2.getDomainZeroBaselinePaint();
//        boolean boolean4 = day0.equals((java.lang.Object) paint3);
//        java.util.Date date5 = day0.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day0.next();
//        long long7 = regularTimePeriod6.getMiddleMillisecond();
//        java.awt.Color color8 = java.awt.Color.darkGray;
//        int int9 = color8.getAlpha();
//        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
//        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
//        numberAxis11.setTickLabelPaint((java.awt.Paint) color12);
//        numberAxis11.setLowerBound(0.0d);
//        double double16 = numberAxis11.getFixedDimension();
//        java.awt.Stroke stroke17 = numberAxis11.getAxisLineStroke();
//        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
//        categoryPlot18.setAnchorValue((double) (-1L), true);
//        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
//        java.awt.Stroke stroke25 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
//        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color24, stroke25);
//        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
//        java.awt.Stroke stroke29 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
//        org.jfree.chart.plot.CategoryMarker categoryMarker30 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color28, stroke29);
//        categoryMarker26.setLabelPaint((java.awt.Paint) color28);
//        org.jfree.chart.util.Layer layer32 = null;
//        categoryPlot18.addRangeMarker((int) (short) 1, (org.jfree.chart.plot.Marker) categoryMarker26, layer32, false);
//        java.awt.Paint paint35 = categoryPlot18.getRangeGridlinePaint();
//        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot();
//        java.awt.Paint paint37 = xYPlot36.getDomainZeroBaselinePaint();
//        boolean boolean38 = xYPlot36.isRangeGridlinesVisible();
//        java.awt.Color color41 = java.awt.Color.getColor("hi!", 0);
//        xYPlot36.setRangeZeroBaselinePaint((java.awt.Paint) color41);
//        org.jfree.chart.axis.ValueAxis valueAxis43 = xYPlot36.getDomainAxis();
//        org.jfree.chart.axis.AxisLocation axisLocation44 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
//        xYPlot36.setRangeAxisLocation(axisLocation44, true);
//        boolean boolean47 = xYPlot36.isDomainGridlinesVisible();
//        java.awt.Stroke stroke48 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
//        xYPlot36.setDomainCrosshairStroke(stroke48);
//        org.jfree.chart.plot.CategoryMarker categoryMarker51 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) regularTimePeriod6, (java.awt.Paint) color8, stroke17, paint35, stroke48, 0.0f);
//        categoryMarker51.setLabel("13-June-2019");
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertNotNull(paint3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560538799999L + "'", long7 == 1560538799999L);
//        org.junit.Assert.assertNotNull(color8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 255 + "'", int9 == 255);
//        org.junit.Assert.assertNotNull(color12);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
//        org.junit.Assert.assertNotNull(stroke17);
//        org.junit.Assert.assertNotNull(color24);
//        org.junit.Assert.assertNotNull(stroke25);
//        org.junit.Assert.assertNotNull(color28);
//        org.junit.Assert.assertNotNull(stroke29);
//        org.junit.Assert.assertNotNull(paint35);
//        org.junit.Assert.assertNotNull(paint37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
//        org.junit.Assert.assertNotNull(color41);
//        org.junit.Assert.assertNull(valueAxis43);
//        org.junit.Assert.assertNotNull(axisLocation44);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
//        org.junit.Assert.assertNotNull(stroke48);
//    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        categoryPlot0.setRangeCrosshairVisible(true);
        categoryPlot0.setDomainGridlinesVisible(false);
        org.jfree.chart.JFreeChart jFreeChart8 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType9 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) false, jFreeChart8, chartChangeEventType9);
        java.lang.String str11 = chartChangeEventType9.toString();
        org.junit.Assert.assertNotNull(chartChangeEventType9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ChartChangeEventType.GENERAL" + "'", str11.equals("ChartChangeEventType.GENERAL"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        java.util.List list7 = categoryPlot0.getCategoriesForAxis(categoryAxis6);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int11 = xYPlot8.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        java.awt.Stroke stroke12 = numberAxis10.getAxisLineStroke();
        numberAxis10.setVisible(false);
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker19 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color17, stroke18);
        xYPlot15.setBackgroundPaint((java.awt.Paint) color17);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        xYPlot15.setRenderer(6, xYItemRenderer22);
        org.jfree.chart.event.PlotChangeListener plotChangeListener24 = null;
        xYPlot15.removeChangeListener(plotChangeListener24);
        java.awt.Stroke stroke26 = xYPlot15.getDomainZeroBaselineStroke();
        numberAxis10.setTickMarkStroke(stroke26);
        categoryPlot0.setRangeCrosshairStroke(stroke26);
        boolean boolean29 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = categoryPlot0.getRangeAxisEdge(10);
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = null;
        categoryPlot0.setDomainAxis(categoryAxis32);
        java.awt.Color color34 = java.awt.Color.darkGray;
        int int35 = color34.getAlpha();
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color34);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = categoryPlot0.getRenderer();
        categoryPlot0.setRangeGridlinesVisible(false);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 255 + "'", int35 == 255);
        org.junit.Assert.assertNull(categoryItemRenderer37);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int6 = xYPlot3.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis5);
        numberAxis5.setLowerBound((double) (short) 10);
        xYPlot0.setDomainAxis((int) (byte) 1, (org.jfree.chart.axis.ValueAxis) numberAxis5, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double12 = rectangleInsets11.getTop();
        java.lang.String str13 = rectangleInsets11.toString();
        xYPlot0.setInsets(rectangleInsets11, true);
        double double17 = rectangleInsets11.extendWidth(100.0d);
        java.lang.String str18 = rectangleInsets11.toString();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str13.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 108.0d + "'", double17 == 108.0d);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str18.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("EXPAND");
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        xYPlot2.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = xYPlot2.getOrientation();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint9 = xYPlot8.getDomainZeroBaselinePaint();
        boolean boolean10 = day6.equals((java.lang.Object) paint9);
        java.util.Date date11 = day6.getStart();
        boolean boolean12 = plotOrientation5.equals((java.lang.Object) date11);
        dateAxis1.setMinimumDate(date11);
        dateAxis1.zoomRange((double) 11, (double) 100L);
        dateAxis1.configure();
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        xYPlot0.setRenderer((int) (byte) 1, xYItemRenderer4);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = xYPlot0.getRenderer(0);
        org.junit.Assert.assertNull(xYItemRenderer7);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color2, stroke3);
        xYPlot0.setBackgroundPaint((java.awt.Paint) color2);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str9 = numberAxis8.getLabel();
        numberAxis8.setVisible(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis8.setTickUnit(numberTickUnit12, false, false);
        numberAxis8.setAxisLineVisible(false);
        numberAxis8.setAutoTickUnitSelection(true);
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint21 = xYPlot20.getDomainZeroBaselinePaint();
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker25 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color23, stroke24);
        java.awt.Paint paint26 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryMarker25.setLabelPaint(paint26);
        xYPlot20.setDomainZeroBaselinePaint(paint26);
        java.awt.Stroke stroke29 = xYPlot20.getDomainZeroBaselineStroke();
        numberAxis8.setAxisLineStroke(stroke29);
        xYPlot0.setRangeAxis((int) (short) 0, (org.jfree.chart.axis.ValueAxis) numberAxis8);
        numberAxis8.setFixedAutoRange(0.0d);
        double double34 = numberAxis8.getFixedDimension();
        org.jfree.data.Range range35 = numberAxis8.getRange();
        org.jfree.data.general.Dataset dataset36 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent37 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) numberAxis8, dataset36);
        org.jfree.data.RangeType rangeType38 = numberAxis8.getRangeType();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str9.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertNotNull(rangeType38);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        categoryPlot0.setRangeCrosshairVisible(true);
        categoryPlot0.setDrawSharedDomainAxis(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis9, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint16 = xYPlot15.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int21 = xYPlot18.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis20);
        numberAxis20.setLowerBound((double) (short) 10);
        xYPlot15.setDomainAxis((int) (byte) 1, (org.jfree.chart.axis.ValueAxis) numberAxis20, true);
        java.awt.Paint paint26 = xYPlot15.getDomainZeroBaselinePaint();
        org.jfree.chart.axis.AxisSpace axisSpace27 = null;
        xYPlot15.setFixedRangeAxisSpace(axisSpace27);
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke30 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot29.setDomainGridlineStroke(stroke30);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        java.awt.geom.Point2D point2D34 = null;
        xYPlot29.zoomDomainAxes(100.0d, plotRenderingInfo33, point2D34, false);
        java.awt.Stroke stroke37 = xYPlot29.getDomainCrosshairStroke();
        xYPlot15.setRangeZeroBaselineStroke(stroke37);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer39 = xYPlot15.getRenderer();
        org.jfree.data.xy.XYDataset xYDataset40 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer41 = xYPlot15.getRendererForDataset(xYDataset40);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo43 = null;
        java.awt.geom.Rectangle2D rectangle2D44 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor45 = null;
        java.awt.geom.Point2D point2D46 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D44, rectangleAnchor45);
        xYPlot15.zoomDomainAxes((double) 4, plotRenderingInfo43, point2D46);
        categoryPlot0.zoomDomainAxes((double) 100.0f, (double) 12, plotRenderingInfo14, point2D46);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNull(xYItemRenderer39);
        org.junit.Assert.assertNull(xYItemRenderer41);
        org.junit.Assert.assertNotNull(point2D46);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker5 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color3, stroke4);
        org.jfree.chart.util.Layer layer6 = null;
        xYPlot0.addRangeMarker(4, (org.jfree.chart.plot.Marker) categoryMarker5, layer6);
        java.awt.Font font8 = categoryMarker5.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryMarker5.getLabelOffset();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = categoryMarker5.getLabelAnchor();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(rectangleAnchor10);
    }

//    @Test
//    public void test102() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test102");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        int int2 = day0.getDayOfMonth();
//        java.lang.String str3 = day0.toString();
//        java.lang.Object obj4 = null;
//        int int5 = day0.compareTo(obj4);
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        java.util.List list7 = categoryPlot0.getCategoriesForAxis(categoryAxis6);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int11 = xYPlot8.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        java.awt.Stroke stroke12 = numberAxis10.getAxisLineStroke();
        numberAxis10.setVisible(false);
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker19 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color17, stroke18);
        xYPlot15.setBackgroundPaint((java.awt.Paint) color17);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        xYPlot15.setRenderer(6, xYItemRenderer22);
        org.jfree.chart.event.PlotChangeListener plotChangeListener24 = null;
        xYPlot15.removeChangeListener(plotChangeListener24);
        java.awt.Stroke stroke26 = xYPlot15.getDomainZeroBaselineStroke();
        numberAxis10.setTickMarkStroke(stroke26);
        categoryPlot0.setRangeCrosshairStroke(stroke26);
        boolean boolean29 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.axis.AxisSpace axisSpace30 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace30);
        int int32 = categoryPlot0.getDomainAxisCount();
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
    }

//    @Test
//    public void test104() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test104");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        int int2 = day0.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
//        java.lang.String str4 = day0.toString();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "13-June-2019" + "'", str4.equals("13-June-2019"));
//    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        boolean boolean2 = xYPlot0.isRangeGridlinesVisible();
        java.awt.Color color5 = java.awt.Color.getColor("hi!", 0);
        xYPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color5);
        org.jfree.chart.axis.ValueAxis valueAxis7 = xYPlot0.getDomainAxis();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis10.getLabelInsets();
        xYPlot0.setDomainAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis10);
        org.jfree.chart.axis.AxisSpace axisSpace13 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace13, true);
        xYPlot0.clearDomainMarkers(1);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNotNull(rectangleInsets11);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        java.util.List list7 = categoryPlot0.getCategoriesForAxis(categoryAxis6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot0.getRenderer(3);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color10);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertNull(categoryItemRenderer9);
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color9, stroke10);
        org.jfree.chart.util.Layer layer12 = null;
        xYPlot6.addRangeMarker(4, (org.jfree.chart.plot.Marker) categoryMarker11, layer12);
        java.awt.Font font14 = categoryMarker11.getLabelFont();
        java.awt.Paint paint15 = categoryMarker11.getPaint();
        org.jfree.chart.util.Layer layer16 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean17 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker11, layer16);
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str21 = numberAxis20.getLabel();
        java.lang.String str22 = numberAxis20.getLabel();
        java.awt.Paint paint23 = numberAxis20.getAxisLinePaint();
        boolean boolean24 = numberAxis20.isTickLabelsVisible();
        numberAxis20.setAutoRange(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = numberAxis20.getLabelInsets();
        java.awt.Stroke stroke28 = numberAxis20.getAxisLineStroke();
        int int29 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis20);
        java.awt.Stroke stroke30 = categoryPlot0.getRangeGridlineStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection31 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.util.SortOrder sortOrder32 = categoryPlot0.getColumnRenderingOrder();
        java.lang.String str33 = sortOrder32.toString();
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(layer16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str21.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str22.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNull(legendItemCollection31);
        org.junit.Assert.assertNotNull(sortOrder32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "SortOrder.ASCENDING" + "'", str33.equals("SortOrder.ASCENDING"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 10L, (double) (byte) 10, 0.0d, (double) 10);
    }

//    @Test
//    public void test109() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test109");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
//        java.awt.Paint paint3 = xYPlot2.getDomainZeroBaselinePaint();
//        boolean boolean4 = day0.equals((java.lang.Object) paint3);
//        int int5 = day0.getMonth();
//        int int6 = day0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day0.next();
//        long long8 = day0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertNotNull(paint3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560409200000L + "'", long8 == 1560409200000L);
//    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int3 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis2);
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color6, stroke7);
        xYPlot4.setBackgroundPaint((java.awt.Paint) color6);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        xYPlot4.setRenderer(6, xYItemRenderer11);
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = xYPlot4.getRangeMarkers((int) ' ', layer14);
        boolean boolean16 = numberAxis2.hasListener((java.util.EventListener) xYPlot4);
        boolean boolean17 = xYPlot4.isRangeZeroBaselineVisible();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("EXPAND");
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        xYPlot2.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = xYPlot2.getOrientation();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint9 = xYPlot8.getDomainZeroBaselinePaint();
        boolean boolean10 = day6.equals((java.lang.Object) paint9);
        java.util.Date date11 = day6.getStart();
        boolean boolean12 = plotOrientation5.equals((java.lang.Object) date11);
        dateAxis1.setMinimumDate(date11);
        org.jfree.data.time.DateRange dateRange14 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis1.setRange((org.jfree.data.Range) dateRange14, false, false);
        org.jfree.chart.axis.Timeline timeline18 = null;
        dateAxis1.setTimeline(timeline18);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition20 = dateAxis1.getTickMarkPosition();
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateRange14);
        org.junit.Assert.assertNotNull(dateTickMarkPosition20);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        xYPlot0.setDomainAxis(12, valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color8, stroke9);
        xYPlot6.setBackgroundPaint((java.awt.Paint) color8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        xYPlot6.setRenderer(6, xYItemRenderer13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        xYPlot6.removeChangeListener(plotChangeListener15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection18 = xYPlot6.getDomainMarkers(layer17);
        java.util.Collection collection19 = xYPlot0.getDomainMarkers(0, layer17);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder20 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot21.setAnchorValue((double) (-1L), true);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = categoryPlot21.getDomainAxis(0);
        categoryPlot21.setRangeGridlinesVisible(false);
        xYPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot21);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertNull(collection19);
        org.junit.Assert.assertNotNull(datasetRenderingOrder20);
        org.junit.Assert.assertNull(categoryAxis26);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color6, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color10, stroke11);
        categoryMarker8.setLabelPaint((java.awt.Paint) color10);
        org.jfree.chart.util.Layer layer14 = null;
        categoryPlot0.addRangeMarker((int) (short) 1, (org.jfree.chart.plot.Marker) categoryMarker8, layer14, false);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray17 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot0.setDomainAxes(categoryAxisArray17);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        int int20 = categoryPlot0.getIndexOf(categoryItemRenderer19);
        categoryPlot0.setRangeGridlinesVisible(true);
        categoryPlot0.clearAnnotations();
        categoryPlot0.setDomainGridlinesVisible(false);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(categoryAxisArray17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color2, stroke3);
        xYPlot0.setBackgroundPaint((java.awt.Paint) color2);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str9 = numberAxis8.getLabel();
        numberAxis8.setVisible(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis8.setTickUnit(numberTickUnit12, false, false);
        numberAxis8.setAxisLineVisible(false);
        numberAxis8.setAutoTickUnitSelection(true);
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint21 = xYPlot20.getDomainZeroBaselinePaint();
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker25 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color23, stroke24);
        java.awt.Paint paint26 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryMarker25.setLabelPaint(paint26);
        xYPlot20.setDomainZeroBaselinePaint(paint26);
        java.awt.Stroke stroke29 = xYPlot20.getDomainZeroBaselineStroke();
        numberAxis8.setAxisLineStroke(stroke29);
        xYPlot0.setRangeAxis((int) (short) 0, (org.jfree.chart.axis.ValueAxis) numberAxis8);
        numberAxis8.setFixedAutoRange(0.0d);
        java.lang.String str34 = numberAxis8.getLabelURL();
        numberAxis8.setTickLabelsVisible(true);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str9.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNull(str34);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str2 = numberAxis1.getLabel();
        numberAxis1.setVisible(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis1.setTickUnit(numberTickUnit5, false, false);
        boolean boolean9 = numberAxis1.isAutoRange();
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str11 = xYPlot10.getNoDataMessage();
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        xYPlot10.setDataset(0, xYDataset13);
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke16 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot15.setDomainGridlineStroke(stroke16);
        java.awt.Stroke stroke18 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        xYPlot15.setRangeGridlineStroke(stroke18);
        xYPlot10.setOutlineStroke(stroke18);
        numberAxis1.setAxisLineStroke(stroke18);
        java.awt.Paint paint22 = numberAxis1.getTickLabelPaint();
        java.awt.Font font23 = numberAxis1.getTickLabelFont();
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint27 = xYPlot26.getDomainZeroBaselinePaint();
        boolean boolean28 = xYPlot26.isRangeGridlinesVisible();
        java.awt.Color color31 = java.awt.Color.getColor("hi!", 0);
        xYPlot26.setRangeZeroBaselinePaint((java.awt.Paint) color31);
        java.lang.Object obj33 = xYPlot26.clone();
        java.awt.Paint paint34 = xYPlot26.getDomainTickBandPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = xYPlot26.getRangeAxisEdge((int) 'a');
        try {
            double double37 = numberAxis1.valueToJava2D((double) 'a', rectangle2D25, rectangleEdge36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str2.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(numberTickUnit5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNull(paint34);
        org.junit.Assert.assertNotNull(rectangleEdge36);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color6, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color10, stroke11);
        categoryMarker8.setLabelPaint((java.awt.Paint) color10);
        org.jfree.chart.util.Layer layer14 = null;
        categoryPlot0.addRangeMarker((int) (short) 1, (org.jfree.chart.plot.Marker) categoryMarker8, layer14, false);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray17 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot0.setDomainAxes(categoryAxisArray17);
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker(0.0d);
        double double22 = valueMarker21.getValue();
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str25 = numberAxis24.getLabel();
        java.lang.String str26 = numberAxis24.getLabel();
        java.awt.Paint paint27 = numberAxis24.getAxisLinePaint();
        boolean boolean28 = valueMarker21.equals((java.lang.Object) paint27);
        boolean boolean29 = categoryPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker21);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(categoryAxisArray17);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str25.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str26.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        int int1 = color0.getBlue();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 128 + "'", int1 == 128);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        java.awt.Color color7 = java.awt.Color.RED;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        xYPlot8.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation11 = xYPlot8.getOrientation();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.awt.Paint paint14 = numberAxis13.getLabelPaint();
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = null;
        double double18 = numberAxis13.valueToJava2D(0.0d, rectangle2D16, rectangleEdge17);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray19 = new org.jfree.chart.axis.ValueAxis[] { numberAxis13 };
        xYPlot8.setDomainAxes(valueAxisArray19);
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker25 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color23, stroke24);
        xYPlot21.setBackgroundPaint((java.awt.Paint) color23);
        xYPlot8.setRangeCrosshairPaint((java.awt.Paint) color23);
        float[] floatArray32 = new float[] { (byte) 1, 10L, 100.0f, 100.0f };
        float[] floatArray33 = color23.getComponents(floatArray32);
        float[] floatArray34 = color7.getRGBComponents(floatArray33);
        float[] floatArray35 = java.awt.Color.RGBtoHSB((int) (byte) 1, (int) (byte) 1, 0, floatArray34);
        float[] floatArray36 = color3.getRGBComponents(floatArray34);
        float[] floatArray37 = java.awt.Color.RGBtoHSB(100, 2019, 0, floatArray34);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(plotOrientation11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(valueAxisArray19);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertNotNull(floatArray35);
        org.junit.Assert.assertNotNull(floatArray36);
        org.junit.Assert.assertNotNull(floatArray37);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str2 = numberAxis1.getLabel();
        numberAxis1.setVisible(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis1.setTickUnit(numberTickUnit5, false, false);
        numberAxis1.setAxisLineVisible(false);
        numberAxis1.setLabelURL("SeriesRenderingOrder.FORWARD");
        numberAxis1.setTickMarksVisible(false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str2.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(numberTickUnit5);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        java.awt.Paint paint1 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot2.setDomainGridlineStroke(stroke3);
        org.jfree.chart.plot.ValueMarker valueMarker5 = new org.jfree.chart.plot.ValueMarker(0.0d, paint1, stroke3);
        java.awt.Font font6 = valueMarker5.getLabelFont();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color8, stroke9);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color12, stroke13);
        categoryMarker10.setLabelPaint((java.awt.Paint) color12);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType16 = categoryMarker10.getLabelOffsetType();
        java.lang.String str17 = lengthAdjustmentType16.toString();
        valueMarker5.setLabelOffsetType(lengthAdjustmentType16);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(lengthAdjustmentType16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "EXPAND" + "'", str17.equals("EXPAND"));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        categoryPlot0.setRangeCrosshairVisible(true);
        categoryPlot0.setDomainGridlinesVisible(false);
        categoryPlot0.clearDomainMarkers();
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=192,g=192,b=192]");
        java.lang.String str2 = categoryAxis1.getLabel();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis1.getCategoryMiddle((int) (short) 1, 9, rectangle2D5, rectangleEdge6);
        java.awt.Paint paint8 = categoryAxis1.getAxisLinePaint();
        categoryAxis1.setUpperMargin(0.0d);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java.awt.Color[r=192,g=192,b=192]" + "'", str2.equals("java.awt.Color[r=192,g=192,b=192]"));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        int int1 = color0.getGreen();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 128 + "'", int1 == 128);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets0.extendHeight((double) (-16056329));
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D6 = rectangleInsets0.createInsetRectangle(rectangle2D3, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.6056323E7d) + "'", double2 == (-1.6056323E7d));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str2 = numberAxis1.getLabel();
        java.lang.String str3 = numberAxis1.getLabel();
        java.awt.Paint paint4 = numberAxis1.getAxisLinePaint();
        java.awt.Shape shape5 = numberAxis1.getRightArrow();
        boolean boolean6 = numberAxis1.isAutoRange();
        numberAxis1.setLabelURL("AxisLocation.TOP_OR_LEFT");
        org.jfree.data.Range range9 = null;
        try {
            numberAxis1.setRange(range9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str2.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str3.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        boolean boolean2 = xYPlot0.isRangeGridlinesVisible();
        int int3 = xYPlot0.getDatasetCount();
        java.awt.Paint paint4 = xYPlot0.getRangeGridlinePaint();
        boolean boolean5 = xYPlot0.isDomainGridlinesVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = xYPlot0.getRenderer(15);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(xYItemRenderer7);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color9, stroke10);
        org.jfree.chart.util.Layer layer12 = null;
        xYPlot6.addRangeMarker(4, (org.jfree.chart.plot.Marker) categoryMarker11, layer12);
        java.awt.Font font14 = categoryMarker11.getLabelFont();
        java.awt.Paint paint15 = categoryMarker11.getPaint();
        org.jfree.chart.util.Layer layer16 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean17 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker11, layer16);
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        java.awt.geom.Point2D point2D20 = null;
        org.jfree.chart.plot.PlotState plotState21 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        try {
            categoryPlot0.draw(graphics2D18, rectangle2D19, point2D20, plotState21, plotRenderingInfo22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(layer16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(0.0d);
        double double2 = valueMarker1.getValue();
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str5 = numberAxis4.getLabel();
        java.lang.String str6 = numberAxis4.getLabel();
        java.awt.Paint paint7 = numberAxis4.getAxisLinePaint();
        boolean boolean8 = valueMarker1.equals((java.lang.Object) paint7);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        boolean boolean10 = valueMarker1.equals((java.lang.Object) color9);
        java.awt.Paint paint11 = valueMarker1.getLabelPaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = valueMarker1.getLabelAnchor();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str5.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str6.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker5 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color3, stroke4);
        xYPlot1.setBackgroundPaint((java.awt.Paint) color3);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        xYPlot1.setRenderer(6, xYItemRenderer8);
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        xYPlot1.removeChangeListener(plotChangeListener10);
        java.awt.Stroke stroke12 = xYPlot1.getDomainZeroBaselineStroke();
        xYPlot0.setRangeGridlineStroke(stroke12);
        xYPlot0.mapDatasetToDomainAxis(12, 0);
        org.jfree.chart.text.TextAnchor textAnchor17 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int21 = xYPlot18.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis20);
        org.jfree.chart.LegendItemCollection legendItemCollection22 = xYPlot18.getFixedLegendItems();
        boolean boolean23 = textAnchor17.equals((java.lang.Object) xYPlot18);
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot();
        xYPlot24.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation27 = xYPlot24.getOrientation();
        xYPlot18.setOrientation(plotOrientation27);
        xYPlot0.setOrientation(plotOrientation27);
        boolean boolean30 = xYPlot0.isDomainCrosshairVisible();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(textAnchor17);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNull(legendItemCollection22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(plotOrientation27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 'a');
        java.awt.Paint paint2 = null;
        try {
            valueMarker1.setPaint(paint2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker5 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color3, stroke4);
        org.jfree.chart.util.Layer layer6 = null;
        xYPlot0.addRangeMarker(4, (org.jfree.chart.plot.Marker) categoryMarker5, layer6);
        java.awt.Color color8 = java.awt.Color.BLACK;
        categoryMarker5.setPaint((java.awt.Paint) color8);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker5);
        org.jfree.chart.plot.Marker marker11 = markerChangeEvent10.getMarker();
        java.lang.String str12 = marker11.getLabel();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(marker11);
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int4 = xYPlot1.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3);
        org.jfree.chart.LegendItemCollection legendItemCollection5 = xYPlot1.getFixedLegendItems();
        boolean boolean6 = textAnchor0.equals((java.lang.Object) xYPlot1);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.awt.Paint paint9 = numberAxis8.getLabelPaint();
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        double double13 = numberAxis8.valueToJava2D(0.0d, rectangle2D11, rectangleEdge12);
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = numberAxis8.java2DToValue((double) 0L, rectangle2D15, rectangleEdge16);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double19 = rectangleInsets18.getTop();
        double double21 = rectangleInsets18.calculateBottomOutset((double) 1);
        numberAxis8.setLabelInsets(rectangleInsets18);
        double double24 = rectangleInsets18.calculateBottomInset((double) 0);
        xYPlot1.setInsets(rectangleInsets18, true);
        double double28 = rectangleInsets18.calculateLeftOutset((double) 1560495599999L);
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNull(legendItemCollection5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 2.0d + "'", double19 == 2.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 2.0d + "'", double21 == 2.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 2.0d + "'", double24 == 2.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 4.0d + "'", double28 == 4.0d);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        boolean boolean2 = xYPlot0.isRangeGridlinesVisible();
        java.awt.Color color5 = java.awt.Color.getColor("hi!", 0);
        xYPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color5);
        java.lang.Object obj7 = xYPlot0.clone();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = xYPlot0.getRangeAxisEdge();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color10, stroke11);
        java.awt.Paint paint13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryMarker12.setLabelPaint(paint13);
        boolean boolean15 = xYPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker12);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str1 = xYPlot0.getNoDataMessage();
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        xYPlot0.setDataset(0, xYDataset3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot5.setDomainGridlineStroke(stroke6);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        xYPlot5.setRangeGridlineStroke(stroke8);
        xYPlot0.setOutlineStroke(stroke8);
        org.jfree.chart.axis.ValueAxis valueAxis11 = xYPlot0.getDomainAxis();
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker16 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color14, stroke15);
        xYPlot12.setBackgroundPaint((java.awt.Paint) color14);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        xYPlot12.setRenderer(6, xYItemRenderer19);
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        xYPlot12.removeChangeListener(plotChangeListener21);
        java.awt.Stroke stroke23 = xYPlot12.getDomainGridlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        xYPlot12.zoomDomainAxes((double) 100, (double) 8, plotRenderingInfo26, point2D27);
        org.jfree.chart.axis.AxisLocation axisLocation29 = xYPlot12.getRangeAxisLocation();
        xYPlot0.setRangeAxisLocation(axisLocation29);
        java.awt.geom.Point2D point2D31 = xYPlot0.getQuadrantOrigin();
        org.jfree.data.xy.XYDataset xYDataset33 = xYPlot0.getDataset((int) (short) 100);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(axisLocation29);
        org.junit.Assert.assertNotNull(point2D31);
        org.junit.Assert.assertNull(xYDataset33);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str2 = numberAxis1.getLabel();
        numberAxis1.setVisible(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis1.setTickUnit(numberTickUnit5, false, false);
        java.lang.String str9 = numberAxis1.getLabel();
        numberAxis1.setTickLabelsVisible(true);
        boolean boolean12 = numberAxis1.getAutoRangeStickyZero();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str2.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(numberTickUnit5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str9.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(8);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str2 = numberAxis1.getLabel();
        boolean boolean3 = numberAxis1.isAutoRange();
        boolean boolean4 = numberAxis1.getAutoRangeStickyZero();
        java.lang.Object obj5 = numberAxis1.clone();
        numberAxis1.setRangeWithMargins(3.0d, 6.0d);
        numberAxis1.setTickLabelsVisible(false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str2.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int5 = xYPlot2.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis4);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color8, stroke9);
        xYPlot6.setBackgroundPaint((java.awt.Paint) color8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        xYPlot6.setRenderer(6, xYItemRenderer13);
        org.jfree.chart.util.Layer layer16 = null;
        java.util.Collection collection17 = xYPlot6.getRangeMarkers((int) ' ', layer16);
        boolean boolean18 = numberAxis4.hasListener((java.util.EventListener) xYPlot6);
        objectList0.set(1, (java.lang.Object) boolean18);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNull(collection17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        java.util.List list7 = categoryPlot0.getCategoriesForAxis(categoryAxis6);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int11 = xYPlot8.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        java.awt.Stroke stroke12 = numberAxis10.getAxisLineStroke();
        numberAxis10.setVisible(false);
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker19 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color17, stroke18);
        xYPlot15.setBackgroundPaint((java.awt.Paint) color17);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        xYPlot15.setRenderer(6, xYItemRenderer22);
        org.jfree.chart.event.PlotChangeListener plotChangeListener24 = null;
        xYPlot15.removeChangeListener(plotChangeListener24);
        java.awt.Stroke stroke26 = xYPlot15.getDomainZeroBaselineStroke();
        numberAxis10.setTickMarkStroke(stroke26);
        categoryPlot0.setRangeCrosshairStroke(stroke26);
        boolean boolean29 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.axis.AxisSpace axisSpace30 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace30);
        java.awt.Paint paint32 = categoryPlot0.getRangeGridlinePaint();
        org.jfree.chart.plot.PlotOrientation plotOrientation33 = categoryPlot0.getOrientation();
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot34.setAnchorValue((double) (-1L), true);
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = categoryPlot34.getDomainAxis(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = null;
        java.util.List list41 = categoryPlot34.getCategoriesForAxis(categoryAxis40);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer43 = categoryPlot34.getRenderer(3);
        org.jfree.chart.util.SortOrder sortOrder44 = categoryPlot34.getRowRenderingOrder();
        categoryPlot0.setColumnRenderingOrder(sortOrder44);
        org.jfree.chart.axis.AxisLocation axisLocation46 = categoryPlot0.getRangeAxisLocation();
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(plotOrientation33);
        org.junit.Assert.assertNull(categoryAxis39);
        org.junit.Assert.assertNotNull(list41);
        org.junit.Assert.assertNull(categoryItemRenderer43);
        org.junit.Assert.assertNotNull(sortOrder44);
        org.junit.Assert.assertNotNull(axisLocation46);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        java.util.List list7 = categoryPlot0.getCategoriesForAxis(categoryAxis6);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int11 = xYPlot8.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        java.awt.Stroke stroke12 = numberAxis10.getAxisLineStroke();
        numberAxis10.setVisible(false);
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker19 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color17, stroke18);
        xYPlot15.setBackgroundPaint((java.awt.Paint) color17);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        xYPlot15.setRenderer(6, xYItemRenderer22);
        org.jfree.chart.event.PlotChangeListener plotChangeListener24 = null;
        xYPlot15.removeChangeListener(plotChangeListener24);
        java.awt.Stroke stroke26 = xYPlot15.getDomainZeroBaselineStroke();
        numberAxis10.setTickMarkStroke(stroke26);
        categoryPlot0.setRangeCrosshairStroke(stroke26);
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int32 = xYPlot29.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis31);
        org.jfree.chart.LegendItemCollection legendItemCollection33 = xYPlot29.getFixedLegendItems();
        xYPlot29.setDomainCrosshairLockedOnData(false);
        xYPlot29.configureRangeAxes();
        java.awt.Stroke stroke37 = xYPlot29.getRangeCrosshairStroke();
        categoryPlot0.setRangeCrosshairStroke(stroke37);
        float float39 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo41 = null;
        org.jfree.chart.plot.XYPlot xYPlot42 = new org.jfree.chart.plot.XYPlot();
        xYPlot42.setRangeCrosshairLockedOnData(false);
        xYPlot42.setDomainCrosshairLockedOnData(false);
        boolean boolean47 = xYPlot42.isRangeGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo49 = null;
        java.awt.geom.Rectangle2D rectangle2D50 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor51 = null;
        java.awt.geom.Point2D point2D52 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D50, rectangleAnchor51);
        xYPlot42.zoomRangeAxes((double) 1, plotRenderingInfo49, point2D52);
        categoryPlot0.zoomRangeAxes(0.0d, plotRenderingInfo41, point2D52);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNull(legendItemCollection33);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertTrue("'" + float39 + "' != '" + 1.0f + "'", float39 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(point2D52);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        boolean boolean2 = xYPlot0.isRangeGridlinesVisible();
        java.awt.Color color5 = java.awt.Color.getColor("hi!", 0);
        xYPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint8 = xYPlot7.getDomainZeroBaselinePaint();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color10, stroke11);
        java.awt.Paint paint13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryMarker12.setLabelPaint(paint13);
        xYPlot7.setDomainZeroBaselinePaint(paint13);
        java.awt.Stroke stroke16 = xYPlot7.getDomainZeroBaselineStroke();
        xYPlot0.setParent((org.jfree.chart.plot.Plot) xYPlot7);
        xYPlot7.setRangeCrosshairVisible(false);
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke23 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker24 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color22, stroke23);
        xYPlot20.setBackgroundPaint((java.awt.Paint) color22);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        xYPlot20.setRenderer(6, xYItemRenderer27);
        org.jfree.chart.event.PlotChangeListener plotChangeListener29 = null;
        xYPlot20.removeChangeListener(plotChangeListener29);
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot();
        xYPlot31.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation34 = xYPlot31.getOrientation();
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.awt.Paint paint37 = numberAxis36.getLabelPaint();
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = null;
        double double41 = numberAxis36.valueToJava2D(0.0d, rectangle2D39, rectangleEdge40);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray42 = new org.jfree.chart.axis.ValueAxis[] { numberAxis36 };
        xYPlot31.setDomainAxes(valueAxisArray42);
        xYPlot20.setRangeAxes(valueAxisArray42);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier45 = xYPlot20.getDrawingSupplier();
        xYPlot7.setDrawingSupplier(drawingSupplier45);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(plotOrientation34);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(valueAxisArray42);
        org.junit.Assert.assertNotNull(drawingSupplier45);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        boolean boolean2 = xYPlot0.isRangeGridlinesVisible();
        java.awt.Color color5 = java.awt.Color.getColor("hi!", 0);
        xYPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color5);
        java.lang.Object obj7 = xYPlot0.clone();
        java.awt.Paint paint8 = xYPlot0.getDomainTickBandPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = xYPlot0.getRangeAxisEdge((int) (byte) 100);
        org.jfree.data.xy.XYDataset xYDataset12 = xYPlot0.getDataset(0);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNull(xYDataset12);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation6 = categoryPlot0.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot0.getRangeAxis((int) '4');
        categoryPlot0.clearRangeAxes();
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        categoryPlot0.drawBackgroundImage(graphics2D10, rectangle2D11);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = categoryPlot0.getDomainAxis();
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertNull(categoryAxis13);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        java.awt.Paint paint4 = categoryPlot0.getDomainGridlinePaint();
        java.awt.Paint paint6 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot7.setDomainGridlineStroke(stroke8);
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.0d, paint6, stroke8);
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint12 = xYPlot11.getDomainZeroBaselinePaint();
        boolean boolean13 = xYPlot11.isRangeGridlinesVisible();
        java.awt.Color color16 = java.awt.Color.getColor("hi!", 0);
        xYPlot11.setRangeZeroBaselinePaint((java.awt.Paint) color16);
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint19 = xYPlot18.getDomainZeroBaselinePaint();
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker23 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color21, stroke22);
        java.awt.Paint paint24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryMarker23.setLabelPaint(paint24);
        xYPlot18.setDomainZeroBaselinePaint(paint24);
        java.awt.Stroke stroke27 = xYPlot18.getDomainZeroBaselineStroke();
        xYPlot11.setParent((org.jfree.chart.plot.Plot) xYPlot18);
        valueMarker10.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot11);
        org.jfree.chart.util.Layer layer30 = null;
        boolean boolean31 = categoryPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker10, layer30);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent32 = null;
        categoryPlot0.notifyListeners(plotChangeEvent32);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        boolean boolean2 = xYPlot0.isRangeGridlinesVisible();
        java.awt.Color color5 = java.awt.Color.getColor("hi!", 0);
        xYPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color5);
        org.jfree.chart.axis.ValueAxis valueAxis7 = xYPlot0.getDomainAxis();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis10.getLabelInsets();
        xYPlot0.setDomainAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis10);
        org.jfree.chart.axis.AxisSpace axisSpace13 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace13, true);
        int int16 = xYPlot0.getDomainAxisCount();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 33 + "'", int16 == 33);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=192,g=192,b=192]");
        float float2 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        categoryAxis1.setFixedDimension((double) (-16744448));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("EXPAND");
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        xYPlot2.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = xYPlot2.getOrientation();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint9 = xYPlot8.getDomainZeroBaselinePaint();
        boolean boolean10 = day6.equals((java.lang.Object) paint9);
        java.util.Date date11 = day6.getStart();
        boolean boolean12 = plotOrientation5.equals((java.lang.Object) date11);
        dateAxis1.setMinimumDate(date11);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.axis.AxisState axisState15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int20 = xYPlot17.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis19);
        org.jfree.chart.LegendItemCollection legendItemCollection21 = xYPlot17.getFixedLegendItems();
        xYPlot17.setDomainCrosshairLockedOnData(false);
        xYPlot17.configureRangeAxes();
        xYPlot17.setRangeZeroBaselineVisible(true);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = xYPlot17.getRangeAxisEdge(11);
        try {
            java.util.List list29 = dateAxis1.refreshTicks(graphics2D14, axisState15, rectangle2D16, rectangleEdge28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNull(legendItemCollection21);
        org.junit.Assert.assertNotNull(rectangleEdge28);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        java.util.List list7 = categoryPlot0.getCategoriesForAxis(categoryAxis6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=192,g=192,b=192]");
        categoryPlot0.setDomainAxis(categoryAxis9);
        categoryPlot0.configureRangeAxes();
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(list7);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        boolean boolean2 = xYPlot0.isRangeGridlinesVisible();
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        xYPlot0.addChangeListener(plotChangeListener3);
        java.awt.Paint paint5 = null;
        try {
            xYPlot0.setDomainZeroBaselinePaint(paint5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker5 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color3, stroke4);
        java.awt.Paint paint6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryMarker5.setLabelPaint(paint6);
        xYPlot0.setDomainZeroBaselinePaint(paint6);
        xYPlot0.mapDatasetToRangeAxis(192, (-1));
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color6, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color10, stroke11);
        categoryMarker8.setLabelPaint((java.awt.Paint) color10);
        org.jfree.chart.util.Layer layer14 = null;
        categoryPlot0.addRangeMarker((int) (short) 1, (org.jfree.chart.plot.Marker) categoryMarker8, layer14, false);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray17 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot0.setDomainAxes(categoryAxisArray17);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        int int20 = categoryPlot0.getIndexOf(categoryItemRenderer19);
        categoryPlot0.setRangeCrosshairLockedOnData(false);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(categoryAxisArray17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=192,g=192,b=192]");
        java.lang.String str2 = categoryAxis1.getLabel();
        java.awt.Font font4 = categoryAxis1.getTickLabelFont((java.lang.Comparable) 1L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java.awt.Color[r=192,g=192,b=192]" + "'", str2.equals("java.awt.Color[r=192,g=192,b=192]"));
        org.junit.Assert.assertNotNull(font4);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color2, stroke3);
        xYPlot0.setBackgroundPaint((java.awt.Paint) color2);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        xYPlot0.setRenderer(6, xYItemRenderer7);
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        xYPlot0.removeChangeListener(plotChangeListener9);
        java.awt.Stroke stroke11 = xYPlot0.getDomainGridlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        xYPlot0.zoomDomainAxes((double) 100, (double) 8, plotRenderingInfo14, point2D15);
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        int int18 = xYPlot0.indexOf(xYDataset17);
        xYPlot0.setRangeCrosshairVisible(false);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str23 = numberAxis22.getLabel();
        numberAxis22.setVisible(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit26 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis22.setTickUnit(numberTickUnit26, false, false);
        numberAxis22.setAxisLineVisible(false);
        numberAxis22.setAutoTickUnitSelection(true);
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint35 = xYPlot34.getDomainZeroBaselinePaint();
        java.awt.Color color37 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke38 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker39 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color37, stroke38);
        java.awt.Paint paint40 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryMarker39.setLabelPaint(paint40);
        xYPlot34.setDomainZeroBaselinePaint(paint40);
        java.awt.Stroke stroke43 = xYPlot34.getDomainZeroBaselineStroke();
        numberAxis22.setAxisLineStroke(stroke43);
        numberAxis22.setLabelURL("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        int int47 = xYPlot0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis22);
        float float48 = numberAxis22.getTickMarkInsideLength();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str23.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(numberTickUnit26);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertTrue("'" + float48 + "' != '" + 0.0f + "'", float48 == 0.0f);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        categoryPlot0.setRangeCrosshairVisible(true);
        categoryPlot0.setDrawSharedDomainAxis(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis9, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot13.setAnchorValue((double) (-1L), true);
        categoryPlot13.setRangeCrosshairVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation19 = categoryPlot13.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis21 = categoryPlot13.getRangeAxis((int) '4');
        org.jfree.chart.axis.AxisLocation axisLocation22 = categoryPlot13.getRangeAxisLocation();
        try {
            categoryPlot0.setDomainAxisLocation((-16056329), axisLocation22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNull(valueAxis21);
        org.junit.Assert.assertNotNull(axisLocation22);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color2, stroke3);
        xYPlot0.setBackgroundPaint((java.awt.Paint) color2);
        boolean boolean6 = xYPlot0.isDomainZoomable();
        boolean boolean7 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str10 = numberAxis9.getLabel();
        java.lang.String str11 = numberAxis9.getLabel();
        java.awt.Paint paint12 = numberAxis9.getAxisLinePaint();
        boolean boolean13 = numberAxis9.isTickLabelsVisible();
        numberAxis9.setVerticalTickLabels(false);
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int19 = xYPlot16.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis18);
        java.awt.Stroke stroke20 = numberAxis18.getAxisLineStroke();
        boolean boolean21 = numberAxis18.isNegativeArrowVisible();
        org.jfree.data.Range range22 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis18.setRangeWithMargins(range22);
        numberAxis9.setRange(range22);
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis9);
        java.awt.Paint paint26 = xYPlot0.getOutlinePaint();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str10.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str11.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNotNull(paint26);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        java.util.List list7 = categoryPlot0.getCategoriesForAxis(categoryAxis6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot0.getRenderer(3);
        int int10 = categoryPlot0.getWeight();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color11);
        float float13 = categoryPlot0.getBackgroundAlpha();
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertNull(categoryItemRenderer9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 1.0f + "'", float13 == 1.0f);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=192,g=192,b=192]");
        float float2 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis1.getCategoryMiddle(100, 13, rectangle2D5, rectangleEdge6);
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) (short) -1);
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 0, "PlotOrientation.VERTICAL");
        java.awt.Font font13 = categoryAxis1.getTickLabelFont();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 0.0d, "SortOrder.ASCENDING");
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(font13);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color2, stroke3);
        xYPlot0.setBackgroundPaint((java.awt.Paint) color2);
        xYPlot0.setOutlineVisible(false);
        java.awt.Stroke stroke8 = xYPlot0.getRangeGridlineStroke();
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str12 = numberAxis11.getLabel();
        numberAxis11.setVisible(false);
        xYPlot0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis11, true);
        xYPlot0.setDomainGridlinesVisible(false);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str12.equals("TextAnchor.BASELINE_LEFT"));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int3 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        xYPlot0.setRangeCrosshairPaint((java.awt.Paint) color4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        xYPlot8.setRangeCrosshairLockedOnData(false);
        xYPlot8.setDomainCrosshairLockedOnData(false);
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        xYPlot13.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation16 = xYPlot13.getOrientation();
        java.lang.String str17 = plotOrientation16.toString();
        xYPlot8.setOrientation(plotOrientation16);
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint22 = xYPlot21.getDomainZeroBaselinePaint();
        boolean boolean23 = xYPlot21.isRangeGridlinesVisible();
        java.awt.Color color26 = java.awt.Color.getColor("hi!", 0);
        xYPlot21.setRangeZeroBaselinePaint((java.awt.Paint) color26);
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint29 = xYPlot28.getDomainZeroBaselinePaint();
        java.awt.Color color31 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke32 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker33 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color31, stroke32);
        java.awt.Paint paint34 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryMarker33.setLabelPaint(paint34);
        xYPlot28.setDomainZeroBaselinePaint(paint34);
        java.awt.Stroke stroke37 = xYPlot28.getDomainZeroBaselineStroke();
        xYPlot21.setParent((org.jfree.chart.plot.Plot) xYPlot28);
        java.awt.Graphics2D graphics2D39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot41.setAnchorValue((double) (-1L), true);
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = categoryPlot41.getDomainAxis(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = null;
        java.util.List list48 = categoryPlot41.getCategoriesForAxis(categoryAxis47);
        xYPlot21.drawDomainTickBands(graphics2D39, rectangle2D40, list48);
        xYPlot8.drawRangeTickBands(graphics2D19, rectangle2D20, list48);
        xYPlot0.drawRangeTickBands(graphics2D6, rectangle2D7, list48);
        xYPlot0.setDomainCrosshairVisible(false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(plotOrientation16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "PlotOrientation.VERTICAL" + "'", str17.equals("PlotOrientation.VERTICAL"));
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNull(categoryAxis46);
        org.junit.Assert.assertNotNull(list48);
    }

//    @Test
//    public void test160() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test160");
//        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
//        xYPlot0.setRangeCrosshairLockedOnData(false);
//        org.jfree.chart.plot.PlotOrientation plotOrientation3 = xYPlot0.getOrientation();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate5 = day4.getSerialDate();
//        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
//        java.awt.Paint paint7 = xYPlot6.getDomainZeroBaselinePaint();
//        boolean boolean8 = day4.equals((java.lang.Object) paint7);
//        java.util.Date date9 = day4.getStart();
//        boolean boolean10 = plotOrientation3.equals((java.lang.Object) date9);
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date9, timeZone11);
//        long long13 = day12.getSerialIndex();
//        org.junit.Assert.assertNotNull(plotOrientation3);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(paint7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43629L + "'", long13 == 43629L);
//    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str2 = numberAxis1.getLabel();
        numberAxis1.setVisible(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis1.setTickUnit(numberTickUnit5, false, false);
        numberAxis1.setAxisLineVisible(false);
        boolean boolean11 = numberAxis1.isVerticalTickLabels();
        numberAxis1.setUpperMargin((double) 33);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str2.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(numberTickUnit5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color6, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color10, stroke11);
        categoryMarker8.setLabelPaint((java.awt.Paint) color10);
        org.jfree.chart.util.Layer layer14 = null;
        categoryPlot0.addRangeMarker((int) (short) 1, (org.jfree.chart.plot.Marker) categoryMarker8, layer14, false);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray17 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot0.setDomainAxes(categoryAxisArray17);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        int int20 = categoryPlot0.getIndexOf(categoryItemRenderer19);
        categoryPlot0.setRangeGridlinesVisible(true);
        categoryPlot0.clearAnnotations();
        org.jfree.chart.plot.PlotOrientation plotOrientation24 = categoryPlot0.getOrientation();
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(categoryAxisArray17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(plotOrientation24);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        boolean boolean2 = xYPlot0.isRangeGridlinesVisible();
        java.awt.Color color5 = java.awt.Color.getColor("hi!", 0);
        xYPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint8 = xYPlot7.getDomainZeroBaselinePaint();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color10, stroke11);
        java.awt.Paint paint13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryMarker12.setLabelPaint(paint13);
        xYPlot7.setDomainZeroBaselinePaint(paint13);
        java.awt.Stroke stroke16 = xYPlot7.getDomainZeroBaselineStroke();
        xYPlot0.setParent((org.jfree.chart.plot.Plot) xYPlot7);
        java.awt.Paint paint18 = xYPlot7.getDomainGridlinePaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        java.util.List list7 = categoryPlot0.getCategoriesForAxis(categoryAxis6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot0.getRenderer(3);
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        xYPlot11.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        xYPlot11.setRenderer((int) (byte) 1, xYItemRenderer15);
        double double17 = xYPlot11.getRangeCrosshairValue();
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker(0.0d);
        double double20 = valueMarker19.getValue();
        java.awt.Paint paint22 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot23.setDomainGridlineStroke(stroke24);
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker(0.0d, paint22, stroke24);
        java.awt.Font font27 = valueMarker26.getLabelFont();
        valueMarker19.setLabelFont(font27);
        valueMarker19.setLabel("ChartChangeEventType.DATASET_UPDATED");
        xYPlot11.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker19);
        org.jfree.chart.util.Layer layer32 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot0.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker19, layer32);
        valueMarker19.setValue((double) 43629L);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertNull(categoryItemRenderer9);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(layer32);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str1 = xYPlot0.getNoDataMessage();
        xYPlot0.configureRangeAxes();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        xYPlot0.zoomRangeAxes((double) (-1), (double) (byte) -1, plotRenderingInfo5, point2D6);
        java.lang.Object obj8 = xYPlot0.clone();
        java.awt.Paint paint9 = xYPlot0.getOutlinePaint();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = numberAxis1.getLabelInsets();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D6 = rectangleInsets2.createOutsetRectangle(rectangle2D3, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int3 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        xYPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint10 = xYPlot9.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int15 = xYPlot12.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis14);
        numberAxis14.setLowerBound((double) (short) 10);
        xYPlot9.setDomainAxis((int) (byte) 1, (org.jfree.chart.axis.ValueAxis) numberAxis14, true);
        java.awt.Paint paint20 = xYPlot9.getDomainZeroBaselinePaint();
        org.jfree.chart.axis.AxisSpace axisSpace21 = null;
        xYPlot9.setFixedRangeAxisSpace(axisSpace21);
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot23.setDomainGridlineStroke(stroke24);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        java.awt.geom.Point2D point2D28 = null;
        xYPlot23.zoomDomainAxes(100.0d, plotRenderingInfo27, point2D28, false);
        java.awt.Stroke stroke31 = xYPlot23.getDomainCrosshairStroke();
        xYPlot9.setRangeZeroBaselineStroke(stroke31);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = xYPlot9.getRenderer();
        org.jfree.data.xy.XYDataset xYDataset34 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = xYPlot9.getRendererForDataset(xYDataset34);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo37 = null;
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor39 = null;
        java.awt.geom.Point2D point2D40 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D38, rectangleAnchor39);
        xYPlot9.zoomDomainAxes((double) 4, plotRenderingInfo37, point2D40);
        xYPlot0.zoomDomainAxes((double) (-1.0f), 0.0d, plotRenderingInfo8, point2D40);
        java.awt.Graphics2D graphics2D43 = null;
        java.awt.geom.Rectangle2D rectangle2D44 = null;
        try {
            xYPlot0.drawOutline(graphics2D43, rectangle2D44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNull(xYItemRenderer33);
        org.junit.Assert.assertNull(xYItemRenderer35);
        org.junit.Assert.assertNotNull(point2D40);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint3 = xYPlot2.getDomainZeroBaselinePaint();
        boolean boolean4 = day0.equals((java.lang.Object) paint3);
        int int5 = day0.getMonth();
        int int6 = day0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day0.previous();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int3 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis2);
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color6, stroke7);
        xYPlot4.setBackgroundPaint((java.awt.Paint) color6);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        xYPlot4.setRenderer(6, xYItemRenderer11);
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = xYPlot4.getRangeMarkers((int) ' ', layer14);
        boolean boolean16 = numberAxis2.hasListener((java.util.EventListener) xYPlot4);
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color18, stroke19);
        java.awt.Paint paint21 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryMarker20.setLabelPaint(paint21);
        java.awt.Font font23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryMarker20.setLabelFont(font23);
        numberAxis2.setTickLabelFont(font23);
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot();
        xYPlot26.setRangeCrosshairLockedOnData(false);
        xYPlot26.setDomainCrosshairLockedOnData(false);
        numberAxis2.setPlot((org.jfree.chart.plot.Plot) xYPlot26);
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = numberAxis2.getLabelInsets();
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D36 = rectangleInsets32.createOutsetRectangle(rectangle2D33, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(rectangleInsets32);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int5 = xYPlot2.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis4);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color8, stroke9);
        xYPlot6.setBackgroundPaint((java.awt.Paint) color8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        xYPlot6.setRenderer(6, xYItemRenderer13);
        org.jfree.chart.util.Layer layer16 = null;
        java.util.Collection collection17 = xYPlot6.getRangeMarkers((int) ' ', layer16);
        boolean boolean18 = numberAxis4.hasListener((java.util.EventListener) xYPlot6);
        java.lang.Object obj19 = numberAxis4.clone();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis4, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        categoryPlot21.mapDatasetToRangeAxis(10, 6);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot21.getDomainAxisEdge();
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot28.setAnchorValue((double) (-1L), true);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = categoryPlot28.getDomainAxis(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = null;
        java.util.List list35 = categoryPlot28.getCategoriesForAxis(categoryAxis34);
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis38 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int39 = xYPlot36.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis38);
        java.awt.Stroke stroke40 = numberAxis38.getAxisLineStroke();
        numberAxis38.setVisible(false);
        org.jfree.chart.plot.XYPlot xYPlot43 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color45 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke46 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker47 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color45, stroke46);
        xYPlot43.setBackgroundPaint((java.awt.Paint) color45);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer50 = null;
        xYPlot43.setRenderer(6, xYItemRenderer50);
        org.jfree.chart.event.PlotChangeListener plotChangeListener52 = null;
        xYPlot43.removeChangeListener(plotChangeListener52);
        java.awt.Stroke stroke54 = xYPlot43.getDomainZeroBaselineStroke();
        numberAxis38.setTickMarkStroke(stroke54);
        categoryPlot28.setRangeCrosshairStroke(stroke54);
        org.jfree.chart.axis.AxisSpace axisSpace57 = null;
        categoryPlot28.setFixedDomainAxisSpace(axisSpace57);
        org.jfree.chart.axis.AxisLocation axisLocation59 = categoryPlot28.getDomainAxisLocation();
        try {
            categoryPlot21.setDomainAxisLocation((-16744448), axisLocation59);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNull(collection17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertNull(categoryAxis33);
        org.junit.Assert.assertNotNull(list35);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertNotNull(axisLocation59);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        xYPlot0.setDataset(xYDataset3);
        org.jfree.chart.plot.Plot plot5 = null;
        xYPlot0.setParent(plot5);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        java.util.List list7 = categoryPlot0.getCategoriesForAxis(categoryAxis6);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int11 = xYPlot8.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        java.awt.Stroke stroke12 = numberAxis10.getAxisLineStroke();
        numberAxis10.setVisible(false);
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker19 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color17, stroke18);
        xYPlot15.setBackgroundPaint((java.awt.Paint) color17);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        xYPlot15.setRenderer(6, xYItemRenderer22);
        org.jfree.chart.event.PlotChangeListener plotChangeListener24 = null;
        xYPlot15.removeChangeListener(plotChangeListener24);
        java.awt.Stroke stroke26 = xYPlot15.getDomainZeroBaselineStroke();
        numberAxis10.setTickMarkStroke(stroke26);
        categoryPlot0.setRangeCrosshairStroke(stroke26);
        boolean boolean29 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.axis.AxisSpace axisSpace30 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.data.category.CategoryDataset categoryDataset31 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer32 = categoryPlot0.getRendererForDataset(categoryDataset31);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNull(axisSpace30);
        org.junit.Assert.assertNull(categoryItemRenderer32);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str1 = xYPlot0.getNoDataMessage();
        xYPlot0.configureRangeAxes();
        xYPlot0.clearRangeAxes();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        xYPlot0.setDomainAxis(8, valueAxis5, true);
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.awt.Paint paint2 = numberAxis1.getLabelPaint();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = numberAxis1.valueToJava2D(0.0d, rectangle2D4, rectangleEdge5);
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = numberAxis1.java2DToValue((double) 0L, rectangle2D8, rectangleEdge9);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double12 = rectangleInsets11.getTop();
        double double14 = rectangleInsets11.calculateBottomOutset((double) 1);
        numberAxis1.setLabelInsets(rectangleInsets11);
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str18 = numberAxis17.getLabel();
        java.lang.String str19 = numberAxis17.getLabel();
        java.awt.Paint paint20 = numberAxis17.getAxisLinePaint();
        java.awt.Shape shape21 = numberAxis17.getRightArrow();
        boolean boolean22 = numberAxis17.isAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str25 = numberAxis24.getLabel();
        java.lang.String str26 = numberAxis24.getLabel();
        java.awt.Paint paint27 = numberAxis24.getAxisLinePaint();
        java.awt.Shape shape28 = numberAxis24.getRightArrow();
        numberAxis17.setDownArrow(shape28);
        numberAxis1.setLeftArrow(shape28);
        numberAxis1.setVerticalTickLabels(false);
        java.text.NumberFormat numberFormat33 = null;
        numberAxis1.setNumberFormatOverride(numberFormat33);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 2.0d + "'", double14 == 2.0d);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str18.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str19.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str25.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str26.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(shape28);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        java.awt.Paint paint4 = categoryPlot0.getRangeGridlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        try {
            categoryPlot0.handleClick(1, 6, plotRenderingInfo7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color2, stroke3);
        xYPlot0.setBackgroundPaint((java.awt.Paint) color2);
        boolean boolean6 = xYPlot0.isDomainZoomable();
        org.jfree.data.xy.XYDataset xYDataset8 = xYPlot0.getDataset((int) 'a');
        xYPlot0.setWeight((-1));
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(xYDataset8);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("EXPAND");
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        xYPlot2.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = xYPlot2.getOrientation();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint9 = xYPlot8.getDomainZeroBaselinePaint();
        boolean boolean10 = day6.equals((java.lang.Object) paint9);
        java.util.Date date11 = day6.getStart();
        boolean boolean12 = plotOrientation5.equals((java.lang.Object) date11);
        dateAxis1.setMinimumDate(date11);
        java.text.DateFormat dateFormat14 = dateAxis1.getDateFormatOverride();
        dateAxis1.setRange(4.0d, (double) 1560409200000L);
        org.jfree.chart.axis.Timeline timeline18 = null;
        dateAxis1.setTimeline(timeline18);
        java.text.DateFormat dateFormat20 = null;
        dateAxis1.setDateFormatOverride(dateFormat20);
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(dateFormat14);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint2 = xYPlot1.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int7 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis6);
        numberAxis6.setLowerBound((double) (short) 10);
        xYPlot1.setDomainAxis((int) (byte) 1, (org.jfree.chart.axis.ValueAxis) numberAxis6, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double13 = rectangleInsets12.getTop();
        java.lang.String str14 = rectangleInsets12.toString();
        xYPlot1.setInsets(rectangleInsets12, true);
        boolean boolean17 = datasetRenderingOrder0.equals((java.lang.Object) rectangleInsets12);
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str20 = numberAxis19.getLabel();
        numberAxis19.setVisible(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit23 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis19.setTickUnit(numberTickUnit23, false, false);
        numberAxis19.setAxisLineVisible(false);
        numberAxis19.setAutoTickUnitSelection(true);
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint32 = xYPlot31.getDomainZeroBaselinePaint();
        java.awt.Color color34 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke35 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker36 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color34, stroke35);
        java.awt.Paint paint37 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryMarker36.setLabelPaint(paint37);
        xYPlot31.setDomainZeroBaselinePaint(paint37);
        java.awt.Stroke stroke40 = xYPlot31.getDomainZeroBaselineStroke();
        numberAxis19.setAxisLineStroke(stroke40);
        numberAxis19.setLabelToolTip("UnitType.RELATIVE");
        numberAxis19.setAutoRangeStickyZero(false);
        boolean boolean46 = rectangleInsets12.equals((java.lang.Object) numberAxis19);
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.0d + "'", double13 == 2.0d);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str14.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str20.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(numberTickUnit23);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int5 = xYPlot2.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis4);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color8, stroke9);
        xYPlot6.setBackgroundPaint((java.awt.Paint) color8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        xYPlot6.setRenderer(6, xYItemRenderer13);
        org.jfree.chart.util.Layer layer16 = null;
        java.util.Collection collection17 = xYPlot6.getRangeMarkers((int) ' ', layer16);
        boolean boolean18 = numberAxis4.hasListener((java.util.EventListener) xYPlot6);
        java.lang.Object obj19 = numberAxis4.clone();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis4, categoryItemRenderer20);
        categoryPlot21.setRangeCrosshairValue((double) (short) -1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNull(collection17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(obj19);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint3 = xYPlot2.getDomainZeroBaselinePaint();
        boolean boolean4 = day0.equals((java.lang.Object) paint3);
        java.util.Date date5 = day0.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day0.next();
        java.util.Date date7 = day0.getStart();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.START;
        java.lang.String str1 = categoryAnchor0.toString();
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CategoryAnchor.START" + "'", str1.equals("CategoryAnchor.START"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color1, stroke2);
        java.awt.Paint paint4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryMarker3.setLabelPaint(paint4);
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryMarker3.setLabelFont(font6);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str10 = numberAxis9.getLabel();
        java.lang.String str11 = numberAxis9.getLabel();
        java.awt.Paint paint12 = numberAxis9.getAxisLinePaint();
        categoryMarker3.setLabelPaint(paint12);
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color16, stroke17);
        xYPlot14.setBackgroundPaint((java.awt.Paint) color16);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        xYPlot14.setRenderer(6, xYItemRenderer21);
        org.jfree.chart.event.PlotChangeListener plotChangeListener23 = null;
        xYPlot14.removeChangeListener(plotChangeListener23);
        java.awt.Paint paint25 = xYPlot14.getRangeTickBandPaint();
        categoryMarker3.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot14);
        xYPlot14.setDomainCrosshairVisible(false);
        java.lang.Object obj29 = xYPlot14.clone();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation30 = null;
        try {
            xYPlot14.addAnnotation(xYAnnotation30, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str10.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str11.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNull(paint25);
        org.junit.Assert.assertNotNull(obj29);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color6, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color10, stroke11);
        categoryMarker8.setLabelPaint((java.awt.Paint) color10);
        org.jfree.chart.util.Layer layer14 = null;
        categoryPlot0.addRangeMarker((int) (short) 1, (org.jfree.chart.plot.Marker) categoryMarker8, layer14, false);
        categoryPlot0.setDomainGridlinesVisible(false);
        java.util.List list19 = categoryPlot0.getAnnotations();
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(list19);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str1 = xYPlot0.getNoDataMessage();
        xYPlot0.configureRangeAxes();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        xYPlot0.zoomRangeAxes((double) (-1), (double) (byte) -1, plotRenderingInfo5, point2D6);
        boolean boolean8 = xYPlot0.isRangeCrosshairLockedOnData();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        xYPlot0.setRenderer((int) (byte) 1, xYItemRenderer4);
        xYPlot0.clearRangeMarkers();
        java.awt.Stroke stroke7 = xYPlot0.getRangeCrosshairStroke();
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color1, stroke2);
        java.awt.Paint paint4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryMarker3.setLabelPaint(paint4);
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryMarker3.setLabelFont(font6);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str10 = numberAxis9.getLabel();
        java.lang.String str11 = numberAxis9.getLabel();
        java.awt.Paint paint12 = numberAxis9.getAxisLinePaint();
        categoryMarker3.setLabelPaint(paint12);
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color16, stroke17);
        xYPlot14.setBackgroundPaint((java.awt.Paint) color16);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        xYPlot14.setRenderer(6, xYItemRenderer21);
        org.jfree.chart.event.PlotChangeListener plotChangeListener23 = null;
        xYPlot14.removeChangeListener(plotChangeListener23);
        java.awt.Paint paint25 = xYPlot14.getRangeTickBandPaint();
        categoryMarker3.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot14);
        java.awt.Color color27 = java.awt.Color.red;
        categoryMarker3.setOutlinePaint((java.awt.Paint) color27);
        boolean boolean29 = categoryMarker3.getDrawAsLine();
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = categoryMarker3.getLabelOffset();
        double double31 = rectangleInsets30.getRight();
        double double33 = rectangleInsets30.calculateTopInset((double) 7);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str10.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str11.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNull(paint25);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 3.0d + "'", double31 == 3.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 3.0d + "'", double33 == 3.0d);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color2, stroke3);
        xYPlot0.setBackgroundPaint((java.awt.Paint) color2);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        xYPlot0.setRenderer(6, xYItemRenderer7);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot0.getRangeMarkers((int) ' ', layer10);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder12 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent14 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYPlot0, jFreeChart13);
        org.jfree.chart.JFreeChart jFreeChart15 = null;
        chartChangeEvent14.setChart(jFreeChart15);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(datasetRenderingOrder12);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color9, stroke10);
        org.jfree.chart.util.Layer layer12 = null;
        xYPlot6.addRangeMarker(4, (org.jfree.chart.plot.Marker) categoryMarker11, layer12);
        java.awt.Font font14 = categoryMarker11.getLabelFont();
        java.awt.Paint paint15 = categoryMarker11.getPaint();
        org.jfree.chart.util.Layer layer16 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean17 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker11, layer16);
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str21 = numberAxis20.getLabel();
        java.lang.String str22 = numberAxis20.getLabel();
        java.awt.Paint paint23 = numberAxis20.getAxisLinePaint();
        boolean boolean24 = numberAxis20.isTickLabelsVisible();
        numberAxis20.setAutoRange(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = numberAxis20.getLabelInsets();
        java.awt.Stroke stroke28 = numberAxis20.getAxisLineStroke();
        int int29 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis20);
        boolean boolean30 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.data.category.CategoryDataset categoryDataset31 = categoryPlot0.getDataset();
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(layer16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str21.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str22.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(categoryDataset31);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        java.awt.Paint paint4 = categoryPlot0.getDomainGridlinePaint();
        java.awt.Paint paint6 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot7.setDomainGridlineStroke(stroke8);
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.0d, paint6, stroke8);
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint12 = xYPlot11.getDomainZeroBaselinePaint();
        boolean boolean13 = xYPlot11.isRangeGridlinesVisible();
        java.awt.Color color16 = java.awt.Color.getColor("hi!", 0);
        xYPlot11.setRangeZeroBaselinePaint((java.awt.Paint) color16);
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint19 = xYPlot18.getDomainZeroBaselinePaint();
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker23 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color21, stroke22);
        java.awt.Paint paint24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryMarker23.setLabelPaint(paint24);
        xYPlot18.setDomainZeroBaselinePaint(paint24);
        java.awt.Stroke stroke27 = xYPlot18.getDomainZeroBaselineStroke();
        xYPlot11.setParent((org.jfree.chart.plot.Plot) xYPlot18);
        valueMarker10.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot11);
        org.jfree.chart.util.Layer layer30 = null;
        boolean boolean31 = categoryPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker10, layer30);
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color35 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke36 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker37 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color35, stroke36);
        xYPlot33.setBackgroundPaint((java.awt.Paint) color35);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer40 = null;
        xYPlot33.setRenderer(6, xYItemRenderer40);
        org.jfree.chart.event.PlotChangeListener plotChangeListener42 = null;
        xYPlot33.removeChangeListener(plotChangeListener42);
        java.awt.Stroke stroke44 = xYPlot33.getDomainZeroBaselineStroke();
        xYPlot32.setRangeGridlineStroke(stroke44);
        categoryPlot0.setDomainGridlineStroke(stroke44);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(stroke44);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis(0);
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d);
        double double9 = valueMarker8.getValue();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = valueMarker8.getLabelAnchor();
        java.lang.String str11 = valueMarker8.getLabel();
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker16 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color14, stroke15);
        xYPlot12.setBackgroundPaint((java.awt.Paint) color14);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        xYPlot12.setRenderer(6, xYItemRenderer19);
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        xYPlot12.removeChangeListener(plotChangeListener21);
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection24 = xYPlot12.getDomainMarkers(layer23);
        boolean boolean26 = layer23.equals((java.lang.Object) "SeriesRenderingOrder.FORWARD");
        boolean boolean28 = categoryPlot0.removeDomainMarker((int) (byte) 100, (org.jfree.chart.plot.Marker) valueMarker8, layer23, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot();
        xYPlot31.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = null;
        xYPlot31.setRenderer((int) (byte) 1, xYItemRenderer35);
        double double37 = xYPlot31.getRangeCrosshairValue();
        org.jfree.chart.plot.XYPlot xYPlot38 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis40 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int41 = xYPlot38.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis40);
        boolean boolean42 = xYPlot31.equals((java.lang.Object) xYPlot38);
        xYPlot31.setForegroundAlpha((float) 10L);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo46 = null;
        java.awt.geom.Rectangle2D rectangle2D47 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor48 = null;
        java.awt.geom.Point2D point2D49 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D47, rectangleAnchor48);
        xYPlot31.zoomRangeAxes((double) 128, plotRenderingInfo46, point2D49, true);
        categoryPlot0.zoomRangeAxes((double) 2, plotRenderingInfo30, point2D49);
        org.jfree.chart.axis.AxisLocation axisLocation53 = categoryPlot0.getDomainAxisLocation();
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor10);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(point2D49);
        org.junit.Assert.assertNotNull(axisLocation53);
    }

//    @Test
//    public void test191() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test191");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
//        java.awt.Paint paint3 = xYPlot2.getDomainZeroBaselinePaint();
//        boolean boolean4 = day0.equals((java.lang.Object) paint3);
//        java.util.Date date5 = day0.getStart();
//        java.lang.String str6 = day0.toString();
//        long long7 = day0.getLastMillisecond();
//        java.util.Date date8 = day0.getStart();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertNotNull(paint3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560495599999L + "'", long7 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date8);
//    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis(0);
        categoryPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisSpace axisSpace8 = categoryPlot0.getFixedDomainAxisSpace();
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNull(axisSpace8);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        java.util.List list7 = categoryPlot0.getCategoriesForAxis(categoryAxis6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot0.getRenderer(3);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.setAnchorValue((double) (-1L), true);
        categoryPlot10.clearDomainAxes();
        boolean boolean15 = categoryPlot0.equals((java.lang.Object) categoryPlot10);
        double double16 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot18.setAnchorValue((double) (-1L), true);
        categoryPlot18.setRangeCrosshairVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation24 = categoryPlot18.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis26 = categoryPlot18.getRangeAxis((int) '4');
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke31 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker32 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color30, stroke31);
        xYPlot28.setBackgroundPaint((java.awt.Paint) color30);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = null;
        xYPlot28.setRenderer(6, xYItemRenderer35);
        org.jfree.chart.event.PlotChangeListener plotChangeListener37 = null;
        xYPlot28.removeChangeListener(plotChangeListener37);
        java.awt.Stroke stroke39 = xYPlot28.getDomainZeroBaselineStroke();
        xYPlot27.setRangeGridlineStroke(stroke39);
        xYPlot27.setRangeCrosshairVisible(true);
        org.jfree.chart.plot.XYPlot xYPlot43 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint44 = xYPlot43.getDomainZeroBaselinePaint();
        boolean boolean45 = xYPlot43.isRangeGridlinesVisible();
        org.jfree.chart.axis.AxisLocation axisLocation46 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot43.setRangeAxisLocation(axisLocation46);
        xYPlot27.setDomainAxisLocation(axisLocation46, true);
        categoryPlot18.setDomainAxisLocation(axisLocation46, true);
        org.jfree.chart.plot.XYPlot xYPlot52 = new org.jfree.chart.plot.XYPlot();
        xYPlot52.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation55 = xYPlot52.getOrientation();
        java.lang.String str56 = plotOrientation55.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge57 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation46, plotOrientation55);
        categoryPlot0.setDomainAxisLocation(3, axisLocation46, true);
        org.jfree.chart.axis.AxisLocation axisLocation61 = categoryPlot0.getDomainAxisLocation(3);
        org.jfree.chart.axis.CategoryAxis categoryAxis63 = categoryPlot0.getDomainAxisForDataset((int) ' ');
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertNull(categoryItemRenderer9);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertNull(valueAxis26);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(axisLocation46);
        org.junit.Assert.assertNotNull(plotOrientation55);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "PlotOrientation.VERTICAL" + "'", str56.equals("PlotOrientation.VERTICAL"));
        org.junit.Assert.assertNotNull(rectangleEdge57);
        org.junit.Assert.assertNotNull(axisLocation61);
        org.junit.Assert.assertNull(categoryAxis63);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int3 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis2);
        numberAxis2.setLowerBound((double) (short) 10);
        boolean boolean6 = numberAxis2.isTickMarksVisible();
        numberAxis2.setFixedDimension(0.05d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        java.util.List list7 = categoryPlot0.getCategoriesForAxis(categoryAxis6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=192,g=192,b=192]");
        categoryPlot0.setDomainAxis(categoryAxis9);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.axis.AxisState axisState12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot14.setAnchorValue((double) (-1L), true);
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = categoryPlot14.getDomainAxis(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        java.util.List list21 = categoryPlot14.getCategoriesForAxis(categoryAxis20);
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int25 = xYPlot22.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis24);
        java.awt.Stroke stroke26 = numberAxis24.getAxisLineStroke();
        numberAxis24.setVisible(false);
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color31 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke32 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker33 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color31, stroke32);
        xYPlot29.setBackgroundPaint((java.awt.Paint) color31);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer36 = null;
        xYPlot29.setRenderer(6, xYItemRenderer36);
        org.jfree.chart.event.PlotChangeListener plotChangeListener38 = null;
        xYPlot29.removeChangeListener(plotChangeListener38);
        java.awt.Stroke stroke40 = xYPlot29.getDomainZeroBaselineStroke();
        numberAxis24.setTickMarkStroke(stroke40);
        categoryPlot14.setRangeCrosshairStroke(stroke40);
        boolean boolean43 = categoryPlot14.isRangeCrosshairVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = categoryPlot14.getRangeAxisEdge(10);
        try {
            java.util.List list46 = categoryAxis9.refreshTicks(graphics2D11, axisState12, rectangle2D13, rectangleEdge45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertNull(categoryAxis19);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(rectangleEdge45);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color2, stroke3);
        xYPlot0.setBackgroundPaint((java.awt.Paint) color2);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        xYPlot0.setRenderer(6, xYItemRenderer7);
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        xYPlot0.removeChangeListener(plotChangeListener9);
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        xYPlot11.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = xYPlot11.getOrientation();
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.awt.Paint paint17 = numberAxis16.getLabelPaint();
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = numberAxis16.valueToJava2D(0.0d, rectangle2D19, rectangleEdge20);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray22 = new org.jfree.chart.axis.ValueAxis[] { numberAxis16 };
        xYPlot11.setDomainAxes(valueAxisArray22);
        xYPlot0.setRangeAxes(valueAxisArray22);
        org.jfree.chart.axis.AxisSpace axisSpace25 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace25);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder28 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        java.lang.String str29 = datasetRenderingOrder28.toString();
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.awt.Paint paint32 = numberAxis31.getLabelPaint();
        boolean boolean33 = datasetRenderingOrder28.equals((java.lang.Object) numberAxis31);
        boolean boolean34 = numberAxis31.isAutoRange();
        org.jfree.chart.axis.TickUnitSource tickUnitSource35 = numberAxis31.getStandardTickUnits();
        xYPlot0.setDomainAxis(13, (org.jfree.chart.axis.ValueAxis) numberAxis31, false);
        org.jfree.chart.plot.XYPlot xYPlot39 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis41 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int42 = xYPlot39.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis41);
        java.awt.Stroke stroke43 = numberAxis41.getAxisLineStroke();
        boolean boolean44 = numberAxis41.isNegativeArrowVisible();
        org.jfree.data.Range range45 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis41.setRangeWithMargins(range45);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit47 = numberAxis41.getTickUnit();
        numberAxis41.setLowerBound(3.0d);
        java.awt.Shape shape50 = numberAxis41.getRightArrow();
        xYPlot0.setDomainAxis((int) '#', (org.jfree.chart.axis.ValueAxis) numberAxis41);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(valueAxisArray22);
        org.junit.Assert.assertNotNull(datasetRenderingOrder28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "DatasetRenderingOrder.REVERSE" + "'", str29.equals("DatasetRenderingOrder.REVERSE"));
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(tickUnitSource35);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(range45);
        org.junit.Assert.assertNotNull(numberTickUnit47);
        org.junit.Assert.assertNotNull(shape50);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        java.awt.Color color1 = color0.darker();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        boolean boolean2 = xYPlot0.isRangeGridlinesVisible();
        java.awt.Color color5 = java.awt.Color.getColor("hi!", 0);
        xYPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color5);
        xYPlot0.setDomainGridlinesVisible(true);
        java.lang.Class<?> wildcardClass9 = xYPlot0.getClass();
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_CYAN;
        int int11 = color10.getBlue();
        xYPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color10);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 192 + "'", int11 == 192);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        java.util.List list7 = categoryPlot0.getCategoriesForAxis(categoryAxis6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        boolean boolean12 = categoryPlot0.render(graphics2D8, rectangle2D9, (-1), plotRenderingInfo11);
        categoryPlot0.clearAnnotations();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor14 = org.jfree.chart.axis.CategoryAnchor.END;
        categoryPlot0.setDomainGridlinePosition(categoryAnchor14);
        java.awt.Image image16 = null;
        categoryPlot0.setBackgroundImage(image16);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation18 = null;
        try {
            categoryPlot0.addAnnotation(categoryAnnotation18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(categoryAnchor14);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        boolean boolean2 = xYPlot0.isRangeGridlinesVisible();
        java.awt.Color color5 = java.awt.Color.getColor("hi!", 0);
        xYPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint8 = xYPlot7.getDomainZeroBaselinePaint();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color10, stroke11);
        java.awt.Paint paint13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryMarker12.setLabelPaint(paint13);
        xYPlot7.setDomainZeroBaselinePaint(paint13);
        java.awt.Stroke stroke16 = xYPlot7.getDomainZeroBaselineStroke();
        xYPlot0.setParent((org.jfree.chart.plot.Plot) xYPlot7);
        xYPlot7.setRangeCrosshairVisible(false);
        xYPlot7.setForegroundAlpha((float) 9);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint3 = xYPlot2.getDomainZeroBaselinePaint();
        boolean boolean4 = day0.equals((java.lang.Object) paint3);
        int int5 = day0.getMonth();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str8 = numberAxis7.getLabel();
        numberAxis7.setVisible(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit11 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis7.setTickUnit(numberTickUnit11, false, false);
        numberAxis7.setAxisLineVisible(false);
        numberAxis7.setAutoTickUnitSelection(true);
        double double19 = numberAxis7.getFixedDimension();
        boolean boolean20 = day0.equals((java.lang.Object) numberAxis7);
        double double21 = numberAxis7.getAutoRangeMinimumSize();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str8.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(numberTickUnit11);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0E-8d + "'", double21 == 1.0E-8d);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation6 = categoryPlot0.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot0.getRangeAxis((int) '4');
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot0.getDomainAxis(175);
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent12 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot0, jFreeChart11);
        double double13 = categoryPlot0.getAnchorValue();
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-1.0d) + "'", double13 == (-1.0d));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int3 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        xYPlot0.zoomDomainAxes((double) 6, plotRenderingInfo5, point2D6);
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace8, false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        java.util.List list7 = categoryPlot0.getCategoriesForAxis(categoryAxis6);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int11 = xYPlot8.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        java.awt.Stroke stroke12 = numberAxis10.getAxisLineStroke();
        numberAxis10.setVisible(false);
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker19 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color17, stroke18);
        xYPlot15.setBackgroundPaint((java.awt.Paint) color17);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        xYPlot15.setRenderer(6, xYItemRenderer22);
        org.jfree.chart.event.PlotChangeListener plotChangeListener24 = null;
        xYPlot15.removeChangeListener(plotChangeListener24);
        java.awt.Stroke stroke26 = xYPlot15.getDomainZeroBaselineStroke();
        numberAxis10.setTickMarkStroke(stroke26);
        categoryPlot0.setRangeCrosshairStroke(stroke26);
        categoryPlot0.setNoDataMessage("");
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke26);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        xYPlot0.setDomainAxis(12, valueAxis3);
        boolean boolean5 = xYPlot0.isRangeZoomable();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation6 = null;
        try {
            xYPlot0.addAnnotation(xYAnnotation6, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int5 = xYPlot2.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis4);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color8, stroke9);
        xYPlot6.setBackgroundPaint((java.awt.Paint) color8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        xYPlot6.setRenderer(6, xYItemRenderer13);
        org.jfree.chart.util.Layer layer16 = null;
        java.util.Collection collection17 = xYPlot6.getRangeMarkers((int) ' ', layer16);
        boolean boolean18 = numberAxis4.hasListener((java.util.EventListener) xYPlot6);
        java.lang.Object obj19 = numberAxis4.clone();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis4, categoryItemRenderer20);
        java.awt.Shape shape22 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        numberAxis4.setLeftArrow(shape22);
        org.jfree.data.RangeType rangeType24 = numberAxis4.getRangeType();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNull(collection17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(rangeType24);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("EXPAND");
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        xYPlot2.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = xYPlot2.getOrientation();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint9 = xYPlot8.getDomainZeroBaselinePaint();
        boolean boolean10 = day6.equals((java.lang.Object) paint9);
        java.util.Date date11 = day6.getStart();
        boolean boolean12 = plotOrientation5.equals((java.lang.Object) date11);
        dateAxis1.setMinimumDate(date11);
        java.text.DateFormat dateFormat14 = dateAxis1.getDateFormatOverride();
        dateAxis1.setRange(4.0d, (double) 1560409200000L);
        org.jfree.chart.axis.Timeline timeline18 = null;
        dateAxis1.setTimeline(timeline18);
        dateAxis1.setInverted(true);
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(dateFormat14);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color2, stroke3);
        xYPlot0.setBackgroundPaint((java.awt.Paint) color2);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        xYPlot0.setRenderer(6, xYItemRenderer7);
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        xYPlot0.removeChangeListener(plotChangeListener9);
        java.awt.Stroke stroke11 = xYPlot0.getDomainGridlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        xYPlot0.zoomDomainAxes((double) 100, (double) 8, plotRenderingInfo14, point2D15);
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        int int18 = xYPlot0.indexOf(xYDataset17);
        xYPlot0.zoom(0.0d);
        org.jfree.chart.axis.AxisLocation axisLocation22 = null;
        xYPlot0.setRangeAxisLocation(10, axisLocation22, false);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairLockedOnData(false);
        xYPlot0.setDomainCrosshairLockedOnData(false);
        boolean boolean5 = xYPlot0.isRangeGridlinesVisible();
        xYPlot0.setBackgroundImageAlignment(0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker5 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color3, stroke4);
        org.jfree.data.general.Dataset dataset7 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) 100, dataset7);
        boolean boolean9 = categoryMarker5.equals((java.lang.Object) 100);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        categoryMarker5.setPaint((java.awt.Paint) color10);
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker5);
        org.jfree.chart.text.TextAnchor textAnchor13 = categoryMarker5.getLabelTextAnchor();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(textAnchor13);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int3 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis2);
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color6, stroke7);
        xYPlot4.setBackgroundPaint((java.awt.Paint) color6);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        xYPlot4.setRenderer(6, xYItemRenderer11);
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = xYPlot4.getRangeMarkers((int) ' ', layer14);
        boolean boolean16 = numberAxis2.hasListener((java.util.EventListener) xYPlot4);
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color18, stroke19);
        java.awt.Paint paint21 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryMarker20.setLabelPaint(paint21);
        java.awt.Font font23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryMarker20.setLabelFont(font23);
        numberAxis2.setTickLabelFont(font23);
        numberAxis2.setRangeAboutValue((double) 9, (double) 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(font23);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(0.0d);
        double double2 = valueMarker1.getValue();
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str5 = numberAxis4.getLabel();
        java.lang.String str6 = numberAxis4.getLabel();
        java.awt.Paint paint7 = numberAxis4.getAxisLinePaint();
        boolean boolean8 = valueMarker1.equals((java.lang.Object) paint7);
        valueMarker1.setValue((double) 1560495599999L);
        java.awt.Color color11 = java.awt.Color.DARK_GRAY;
        valueMarker1.setLabelPaint((java.awt.Paint) color11);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str5.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str6.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color1, stroke2);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color5, stroke6);
        categoryMarker3.setLabelPaint((java.awt.Paint) color5);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType9 = categoryMarker3.getLabelOffsetType();
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = numberAxis11.getLabelInsets();
        double double14 = rectangleInsets12.extendWidth(0.0d);
        double double16 = rectangleInsets12.calculateLeftOutset(0.0d);
        categoryMarker3.setLabelOffset(rectangleInsets12);
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D21 = rectangleInsets12.createInsetRectangle(rectangle2D18, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(lengthAdjustmentType9);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 6.0d + "'", double14 == 6.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 3.0d + "'", double16 == 3.0d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        java.util.List list7 = categoryPlot0.getCategoriesForAxis(categoryAxis6);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int11 = xYPlot8.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        java.awt.Stroke stroke12 = numberAxis10.getAxisLineStroke();
        numberAxis10.setVisible(false);
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker19 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color17, stroke18);
        xYPlot15.setBackgroundPaint((java.awt.Paint) color17);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        xYPlot15.setRenderer(6, xYItemRenderer22);
        org.jfree.chart.event.PlotChangeListener plotChangeListener24 = null;
        xYPlot15.removeChangeListener(plotChangeListener24);
        java.awt.Stroke stroke26 = xYPlot15.getDomainZeroBaselineStroke();
        numberAxis10.setTickMarkStroke(stroke26);
        categoryPlot0.setRangeCrosshairStroke(stroke26);
        boolean boolean29 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.axis.AxisSpace axisSpace30 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace30);
        java.awt.Paint paint32 = categoryPlot0.getRangeGridlinePaint();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent33 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot0);
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=192,g=192,b=192]");
        float float36 = categoryAxis35.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions37 = categoryAxis35.getCategoryLabelPositions();
        categoryAxis35.setUpperMargin((double) 175);
        categoryPlot0.setDomainAxis(categoryAxis35);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + float36 + "' != '" + 0.0f + "'", float36 == 0.0f);
        org.junit.Assert.assertNotNull(categoryLabelPositions37);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color5, stroke6);
        org.jfree.chart.util.Layer layer8 = null;
        xYPlot2.addRangeMarker(4, (org.jfree.chart.plot.Marker) categoryMarker7, layer8);
        java.awt.Font font10 = categoryMarker7.getLabelFont();
        java.awt.Paint paint11 = categoryMarker7.getPaint();
        java.awt.Paint paint12 = categoryMarker7.getLabelPaint();
        java.awt.Stroke stroke13 = categoryMarker7.getOutlineStroke();
        valueMarker1.setStroke(stroke13);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairLockedOnData(false);
        xYPlot0.setRangeCrosshairValue((double) 255, false);
        xYPlot0.setRangeCrosshairLockedOnData(false);
        double double8 = xYPlot0.getRangeCrosshairValue();
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 255.0d + "'", double8 == 255.0d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        java.lang.String str1 = datasetRenderingOrder0.toString();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.awt.Paint paint4 = numberAxis3.getLabelPaint();
        boolean boolean5 = datasetRenderingOrder0.equals((java.lang.Object) numberAxis3);
        boolean boolean6 = numberAxis3.isAutoRange();
        boolean boolean7 = numberAxis3.getAutoRangeStickyZero();
        numberAxis3.setUpperMargin((double) (short) 0);
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DatasetRenderingOrder.REVERSE" + "'", str1.equals("DatasetRenderingOrder.REVERSE"));
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int3 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis2);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier4 = xYPlot0.getDrawingSupplier();
        java.awt.Stroke stroke5 = xYPlot0.getRangeCrosshairStroke();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation6 = null;
        try {
            xYPlot0.addAnnotation(xYAnnotation6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(drawingSupplier4);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        boolean boolean2 = xYPlot0.isRangeGridlinesVisible();
        java.awt.Color color5 = java.awt.Color.getColor("hi!", 0);
        xYPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color5);
        org.jfree.chart.axis.ValueAxis valueAxis7 = xYPlot0.getDomainAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.setAnchorValue((double) (-1L), true);
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = categoryPlot10.getDomainAxis(0);
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker(0.0d);
        double double19 = valueMarker18.getValue();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor20 = valueMarker18.getLabelAnchor();
        java.lang.String str21 = valueMarker18.getLabel();
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke25 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color24, stroke25);
        xYPlot22.setBackgroundPaint((java.awt.Paint) color24);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        xYPlot22.setRenderer(6, xYItemRenderer29);
        org.jfree.chart.event.PlotChangeListener plotChangeListener31 = null;
        xYPlot22.removeChangeListener(plotChangeListener31);
        org.jfree.chart.util.Layer layer33 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection34 = xYPlot22.getDomainMarkers(layer33);
        boolean boolean36 = layer33.equals((java.lang.Object) "SeriesRenderingOrder.FORWARD");
        boolean boolean38 = categoryPlot10.removeDomainMarker((int) (byte) 100, (org.jfree.chart.plot.Marker) valueMarker18, layer33, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo40 = null;
        org.jfree.chart.plot.XYPlot xYPlot41 = new org.jfree.chart.plot.XYPlot();
        xYPlot41.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer45 = null;
        xYPlot41.setRenderer((int) (byte) 1, xYItemRenderer45);
        double double47 = xYPlot41.getRangeCrosshairValue();
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis50 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int51 = xYPlot48.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis50);
        boolean boolean52 = xYPlot41.equals((java.lang.Object) xYPlot48);
        xYPlot41.setForegroundAlpha((float) 10L);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo56 = null;
        java.awt.geom.Rectangle2D rectangle2D57 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor58 = null;
        java.awt.geom.Point2D point2D59 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D57, rectangleAnchor58);
        xYPlot41.zoomRangeAxes((double) 128, plotRenderingInfo56, point2D59, true);
        categoryPlot10.zoomRangeAxes((double) 2, plotRenderingInfo40, point2D59);
        xYPlot0.zoomDomainAxes((double) (short) -1, plotRenderingInfo9, point2D59, false);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNull(categoryAxis15);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(layer33);
        org.junit.Assert.assertNull(collection34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1) + "'", int51 == (-1));
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(point2D59);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int6 = xYPlot3.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis5);
        numberAxis5.setLowerBound((double) (short) 10);
        xYPlot0.setDomainAxis((int) (byte) 1, (org.jfree.chart.axis.ValueAxis) numberAxis5, true);
        java.awt.Paint paint11 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.axis.AxisSpace axisSpace12 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace12);
        float float14 = xYPlot0.getBackgroundAlpha();
        org.jfree.data.xy.XYDataset xYDataset15 = xYPlot0.getDataset();
        xYPlot0.mapDatasetToDomainAxis(11, (int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        xYPlot0.setRangeAxis(6, valueAxis20);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 1.0f + "'", float14 == 1.0f);
        org.junit.Assert.assertNull(xYDataset15);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        java.util.List list7 = categoryPlot0.getCategoriesForAxis(categoryAxis6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot0.getRenderer(3);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.setAnchorValue((double) (-1L), true);
        categoryPlot10.clearDomainAxes();
        boolean boolean15 = categoryPlot0.equals((java.lang.Object) categoryPlot10);
        double double16 = categoryPlot0.getRangeCrosshairValue();
        categoryPlot0.mapDatasetToRangeAxis(0, 3);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertNull(categoryItemRenderer9);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=192,g=192,b=192]");
        float float2 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis1.getCategoryMiddle(100, 13, rectangle2D5, rectangleEdge6);
        java.awt.Color color9 = java.awt.Color.red;
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) 128, (java.awt.Paint) color9);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(0.0d);
        double double2 = valueMarker1.getValue();
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str5 = numberAxis4.getLabel();
        java.lang.String str6 = numberAxis4.getLabel();
        java.awt.Paint paint7 = numberAxis4.getAxisLinePaint();
        boolean boolean8 = valueMarker1.equals((java.lang.Object) paint7);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        boolean boolean10 = valueMarker1.equals((java.lang.Object) color9);
        java.awt.Paint paint11 = valueMarker1.getPaint();
        java.awt.Paint paint12 = valueMarker1.getPaint();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str5.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str6.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        java.lang.String str1 = textAnchor0.toString();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextAnchor.HALF_ASCENT_CENTER" + "'", str1.equals("TextAnchor.HALF_ASCENT_CENTER"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int3 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis2);
        org.jfree.chart.LegendItemCollection legendItemCollection4 = xYPlot0.getFixedLegendItems();
        xYPlot0.setDomainCrosshairLockedOnData(false);
        xYPlot0.configureRangeAxes();
        xYPlot0.setRangeZeroBaselineVisible(true);
        xYPlot0.mapDatasetToDomainAxis((int) (byte) 0, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNull(legendItemCollection4);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        java.util.List list7 = categoryPlot0.getCategoriesForAxis(categoryAxis6);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int11 = xYPlot8.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        java.awt.Stroke stroke12 = numberAxis10.getAxisLineStroke();
        numberAxis10.setVisible(false);
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker19 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color17, stroke18);
        xYPlot15.setBackgroundPaint((java.awt.Paint) color17);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        xYPlot15.setRenderer(6, xYItemRenderer22);
        org.jfree.chart.event.PlotChangeListener plotChangeListener24 = null;
        xYPlot15.removeChangeListener(plotChangeListener24);
        java.awt.Stroke stroke26 = xYPlot15.getDomainZeroBaselineStroke();
        numberAxis10.setTickMarkStroke(stroke26);
        categoryPlot0.setRangeCrosshairStroke(stroke26);
        org.jfree.chart.axis.AxisSpace axisSpace29 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace29);
        org.jfree.chart.axis.AxisLocation axisLocation31 = categoryPlot0.getRangeAxisLocation();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.axis.AxisSpace axisSpace33 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace33);
        org.jfree.data.category.CategoryDataset categoryDataset36 = categoryPlot0.getDataset((int) '#');
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = categoryPlot0.getRenderer();
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertNull(categoryDataset36);
        org.junit.Assert.assertNull(categoryItemRenderer37);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color1, stroke2);
        categoryMarker3.setDrawAsLine(false);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.LEFT;
        categoryMarker3.setLabelAnchor(rectangleAnchor6);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint9 = xYPlot8.getDomainZeroBaselinePaint();
        boolean boolean10 = xYPlot8.isRangeGridlinesVisible();
        java.awt.Color color13 = java.awt.Color.getColor("hi!", 0);
        xYPlot8.setRangeZeroBaselinePaint((java.awt.Paint) color13);
        xYPlot8.setDomainGridlinesVisible(true);
        java.lang.Class<?> wildcardClass17 = xYPlot8.getClass();
        java.util.EventListener[] eventListenerArray18 = categoryMarker3.getListeners((java.lang.Class) wildcardClass17);
        categoryMarker3.setLabel("");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = categoryMarker3.getLabelAnchor();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(eventListenerArray18);
        org.junit.Assert.assertNotNull(rectangleAnchor21);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        java.awt.Color color0 = java.awt.Color.lightGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker5 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color3, stroke4);
        org.jfree.chart.util.Layer layer6 = null;
        xYPlot0.addRangeMarker(4, (org.jfree.chart.plot.Marker) categoryMarker5, layer6);
        xYPlot0.configureRangeAxes();
        xYPlot0.setWeight(0);
        xYPlot0.clearDomainAxes();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.resizeRange((double) (short) 100, (double) 6);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = numberAxis0.getLabelInsets();
        org.junit.Assert.assertNotNull(rectangleInsets4);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str2 = numberAxis1.getLabel();
        java.lang.String str3 = numberAxis1.getLabel();
        java.awt.Paint paint4 = numberAxis1.getAxisLinePaint();
        boolean boolean5 = numberAxis1.isTickLabelsVisible();
        numberAxis1.setVerticalTickLabels(false);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint13 = xYPlot12.getDomainZeroBaselinePaint();
        boolean boolean14 = xYPlot12.isRangeGridlinesVisible();
        java.awt.Color color17 = java.awt.Color.getColor("hi!", 0);
        xYPlot12.setRangeZeroBaselinePaint((java.awt.Paint) color17);
        java.lang.Object obj19 = xYPlot12.clone();
        java.awt.Paint paint20 = xYPlot12.getDomainTickBandPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = xYPlot12.getRangeAxisEdge((int) (byte) 100);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        try {
            org.jfree.chart.axis.AxisState axisState24 = numberAxis1.draw(graphics2D8, (-4.0d), rectangle2D10, rectangle2D11, rectangleEdge22, plotRenderingInfo23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str2.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str3.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertNull(paint20);
        org.junit.Assert.assertNotNull(rectangleEdge22);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color6, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color10, stroke11);
        categoryMarker8.setLabelPaint((java.awt.Paint) color10);
        org.jfree.chart.util.Layer layer14 = null;
        categoryPlot0.addRangeMarker((int) (short) 1, (org.jfree.chart.plot.Marker) categoryMarker8, layer14, false);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray17 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot0.setDomainAxes(categoryAxisArray17);
        java.lang.String str19 = categoryPlot0.getPlotType();
        org.jfree.chart.axis.ValueAxis valueAxis21 = categoryPlot0.getRangeAxis(8);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(categoryAxisArray17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Category Plot" + "'", str19.equals("Category Plot"));
        org.junit.Assert.assertNull(valueAxis21);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color1, stroke2);
        categoryMarker3.setDrawAsLine(false);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.LEFT;
        categoryMarker3.setLabelAnchor(rectangleAnchor6);
        java.awt.Color color10 = java.awt.Color.getColor("hi!", 0);
        categoryMarker3.setPaint((java.awt.Paint) color10);
        boolean boolean12 = categoryMarker3.getDrawAsLine();
        java.awt.Color color13 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryMarker3.setOutlinePaint((java.awt.Paint) color13);
        java.awt.Font font15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryMarker3.setLabelFont(font15);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(font15);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace1);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        categoryPlot0.setRangeCrosshairVisible(true);
        categoryPlot0.clearRangeMarkers(11);
        boolean boolean8 = categoryPlot0.isOutlineVisible();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str2 = numberAxis1.getLabel();
        numberAxis1.setVisible(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis1.setTickUnit(numberTickUnit5, false, false);
        numberAxis1.setAxisLineVisible(false);
        numberAxis1.setLabelURL("SeriesRenderingOrder.FORWARD");
        java.lang.String str13 = numberAxis1.getLabel();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = numberAxis1.lengthToJava2D((double) 9, rectangle2D15, rectangleEdge16);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str2.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(numberTickUnit5);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str13.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=192,g=192,b=192]");
        float float2 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis1.getCategoryMiddle(100, 13, rectangle2D5, rectangleEdge6);
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) (short) -1);
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 0, "PlotOrientation.VERTICAL");
        java.awt.Color color14 = java.awt.Color.LIGHT_GRAY;
        java.lang.String str15 = color14.toString();
        int int16 = color14.getBlue();
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) (byte) 0, (java.awt.Paint) color14);
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke25 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color24, stroke25);
        xYPlot22.setBackgroundPaint((java.awt.Paint) color24);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        xYPlot22.setRenderer(6, xYItemRenderer29);
        org.jfree.chart.event.PlotChangeListener plotChangeListener31 = null;
        xYPlot22.removeChangeListener(plotChangeListener31);
        java.awt.Stroke stroke33 = xYPlot22.getDomainGridlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        java.awt.geom.Point2D point2D37 = null;
        xYPlot22.zoomDomainAxes((double) 100, (double) 8, plotRenderingInfo36, point2D37);
        org.jfree.data.xy.XYDataset xYDataset39 = null;
        int int40 = xYPlot22.indexOf(xYDataset39);
        xYPlot22.setRangeCrosshairVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = xYPlot22.getDomainAxisEdge(2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo45 = null;
        try {
            org.jfree.chart.axis.AxisState axisState46 = categoryAxis1.draw(graphics2D18, (double) 1560409200000L, rectangle2D20, rectangle2D21, rectangleEdge44, plotRenderingInfo45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "java.awt.Color[r=192,g=192,b=192]" + "'", str15.equals("java.awt.Color[r=192,g=192,b=192]"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 192 + "'", int16 == 192);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge44);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color2, stroke3);
        xYPlot0.setBackgroundPaint((java.awt.Paint) color2);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        xYPlot0.setRenderer(6, xYItemRenderer7);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot0.getRangeMarkers((int) ' ', layer10);
        org.jfree.data.xy.XYDataset xYDataset13 = xYPlot0.getDataset(4);
        java.lang.Class<?> wildcardClass14 = xYPlot0.getClass();
        org.jfree.chart.plot.Marker marker16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot();
        xYPlot17.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.axis.AxisSpace axisSpace20 = null;
        xYPlot17.setFixedRangeAxisSpace(axisSpace20, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot17.setInsets(rectangleInsets23);
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke29 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker30 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color28, stroke29);
        xYPlot26.setBackgroundPaint((java.awt.Paint) color28);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = null;
        xYPlot26.setRenderer(6, xYItemRenderer33);
        org.jfree.chart.axis.ValueAxis valueAxis35 = xYPlot26.getRangeAxis();
        java.awt.Paint paint37 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.plot.XYPlot xYPlot38 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke39 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot38.setDomainGridlineStroke(stroke39);
        org.jfree.chart.plot.ValueMarker valueMarker41 = new org.jfree.chart.plot.ValueMarker(0.0d, paint37, stroke39);
        boolean boolean42 = xYPlot26.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker41);
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean44 = categoryPlot43.isDomainZoomable();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo46 = null;
        java.awt.geom.Point2D point2D47 = null;
        categoryPlot43.zoomRangeAxes((double) 8, plotRenderingInfo46, point2D47);
        org.jfree.chart.util.Layer layer50 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection51 = categoryPlot43.getDomainMarkers((int) 'a', layer50);
        boolean boolean53 = xYPlot17.removeRangeMarker(100, (org.jfree.chart.plot.Marker) valueMarker41, layer50, false);
        try {
            xYPlot0.addDomainMarker(128, marker16, layer50, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNull(xYDataset13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNull(valueAxis35);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(layer50);
        org.junit.Assert.assertNull(collection51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        java.lang.String str1 = datasetRenderingOrder0.toString();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.awt.Paint paint4 = numberAxis3.getLabelPaint();
        boolean boolean5 = datasetRenderingOrder0.equals((java.lang.Object) numberAxis3);
        boolean boolean6 = numberAxis3.isAutoRange();
        org.jfree.chart.axis.TickUnitSource tickUnitSource7 = numberAxis3.getStandardTickUnits();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color9, stroke10);
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryMarker11.setLabelPaint(paint12);
        java.awt.Font font14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryMarker11.setLabelFont(font14);
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str18 = numberAxis17.getLabel();
        java.lang.String str19 = numberAxis17.getLabel();
        java.awt.Paint paint20 = numberAxis17.getAxisLinePaint();
        categoryMarker11.setLabelPaint(paint20);
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke25 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color24, stroke25);
        xYPlot22.setBackgroundPaint((java.awt.Paint) color24);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        xYPlot22.setRenderer(6, xYItemRenderer29);
        org.jfree.chart.event.PlotChangeListener plotChangeListener31 = null;
        xYPlot22.removeChangeListener(plotChangeListener31);
        java.awt.Paint paint33 = xYPlot22.getRangeTickBandPaint();
        categoryMarker11.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot22);
        java.awt.Color color35 = java.awt.Color.red;
        categoryMarker11.setOutlinePaint((java.awt.Paint) color35);
        java.awt.Color color38 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke39 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker40 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color38, stroke39);
        java.awt.Paint paint41 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryMarker40.setLabelPaint(paint41);
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.awt.Color color45 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        numberAxis44.setTickLabelPaint((java.awt.Paint) color45);
        java.lang.String str47 = color45.toString();
        categoryMarker40.setOutlinePaint((java.awt.Paint) color45);
        java.lang.String str49 = color45.toString();
        categoryMarker11.setOutlinePaint((java.awt.Paint) color45);
        boolean boolean51 = numberAxis3.equals((java.lang.Object) color45);
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DatasetRenderingOrder.REVERSE" + "'", str1.equals("DatasetRenderingOrder.REVERSE"));
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(tickUnitSource7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str18.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str19.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNull(paint33);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "java.awt.Color[r=0,g=0,b=128]" + "'", str47.equals("java.awt.Color[r=0,g=0,b=128]"));
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "java.awt.Color[r=0,g=0,b=128]" + "'", str49.equals("java.awt.Color[r=0,g=0,b=128]"));
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        xYPlot0.setDataset(xYDataset3);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        xYPlot0.setRangeAxis((int) (short) 1, valueAxis6);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        xYPlot0.setRenderer((int) '4', xYItemRenderer9, false);
        java.awt.Stroke stroke12 = xYPlot0.getRangeGridlineStroke();
        boolean boolean13 = xYPlot0.isDomainZoomable();
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        java.awt.Color color2 = java.awt.Color.getColor("java.awt.Color[r=128,g=128,b=128]", 4);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str2 = numberAxis1.getLabel();
        java.lang.String str3 = numberAxis1.getLabel();
        java.awt.Paint paint4 = numberAxis1.getAxisLinePaint();
        boolean boolean5 = numberAxis1.isTickLabelsVisible();
        java.awt.Font font6 = numberAxis1.getTickLabelFont();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand7 = numberAxis1.getMarkerBand();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str2.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str3.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNull(markerAxisBand7);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color2, stroke3);
        xYPlot0.setBackgroundPaint((java.awt.Paint) color2);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        xYPlot0.setRenderer(6, xYItemRenderer7);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot0.getRangeMarkers((int) ' ', layer10);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder12 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        int int14 = xYPlot0.getRangeAxisIndex(valueAxis13);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(datasetRenderingOrder12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis(0);
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d);
        double double9 = valueMarker8.getValue();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = valueMarker8.getLabelAnchor();
        java.lang.String str11 = valueMarker8.getLabel();
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker16 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color14, stroke15);
        xYPlot12.setBackgroundPaint((java.awt.Paint) color14);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        xYPlot12.setRenderer(6, xYItemRenderer19);
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        xYPlot12.removeChangeListener(plotChangeListener21);
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection24 = xYPlot12.getDomainMarkers(layer23);
        boolean boolean26 = layer23.equals((java.lang.Object) "SeriesRenderingOrder.FORWARD");
        boolean boolean28 = categoryPlot0.removeDomainMarker((int) (byte) 100, (org.jfree.chart.plot.Marker) valueMarker8, layer23, true);
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot();
        xYPlot29.setRangeCrosshairLockedOnData(false);
        xYPlot29.setRangeCrosshairValue((double) 255, false);
        boolean boolean35 = layer23.equals((java.lang.Object) 255);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor10);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        xYPlot0.setDataset(xYDataset3);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        numberAxis6.setTickLabelPaint((java.awt.Paint) color7);
        java.lang.String str9 = color7.toString();
        java.awt.Color color10 = color7.brighter();
        xYPlot0.setRangeCrosshairPaint((java.awt.Paint) color10);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "java.awt.Color[r=0,g=0,b=128]" + "'", str9.equals("java.awt.Color[r=0,g=0,b=128]"));
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        boolean boolean2 = xYPlot0.isRangeGridlinesVisible();
        java.awt.Color color5 = java.awt.Color.getColor("hi!", 0);
        xYPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color5);
        java.lang.Object obj7 = xYPlot0.clone();
        java.awt.Paint paint8 = xYPlot0.getDomainTickBandPaint();
        org.jfree.chart.axis.AxisLocation axisLocation9 = xYPlot0.getRangeAxisLocation();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(axisLocation9);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairLockedOnData(false);
        xYPlot0.setDomainCrosshairLockedOnData(false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = xYPlot0.getRangeAxisForDataset((int) (byte) 0);
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace7, false);
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker15 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color13, stroke14);
        org.jfree.chart.util.Layer layer16 = null;
        xYPlot10.addRangeMarker(4, (org.jfree.chart.plot.Marker) categoryMarker15, layer16);
        java.awt.Font font18 = categoryMarker15.getLabelFont();
        java.awt.Paint paint19 = categoryMarker15.getPaint();
        java.awt.Paint paint20 = categoryMarker15.getLabelPaint();
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker15);
        java.awt.Paint paint22 = categoryMarker15.getOutlinePaint();
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color9, stroke10);
        org.jfree.chart.util.Layer layer12 = null;
        xYPlot6.addRangeMarker(4, (org.jfree.chart.plot.Marker) categoryMarker11, layer12);
        java.awt.Font font14 = categoryMarker11.getLabelFont();
        java.awt.Paint paint15 = categoryMarker11.getPaint();
        org.jfree.chart.util.Layer layer16 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean17 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker11, layer16);
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str21 = numberAxis20.getLabel();
        java.lang.String str22 = numberAxis20.getLabel();
        java.awt.Paint paint23 = numberAxis20.getAxisLinePaint();
        boolean boolean24 = numberAxis20.isTickLabelsVisible();
        numberAxis20.setAutoRange(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = numberAxis20.getLabelInsets();
        java.awt.Stroke stroke28 = numberAxis20.getAxisLineStroke();
        int int29 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis20);
        java.awt.Stroke stroke30 = categoryPlot0.getRangeGridlineStroke();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation31 = null;
        try {
            boolean boolean32 = categoryPlot0.removeAnnotation(categoryAnnotation31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(layer16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str21.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str22.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(stroke30);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        xYPlot3.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = xYPlot3.getOrientation();
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.awt.Paint paint9 = numberAxis8.getLabelPaint();
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        double double13 = numberAxis8.valueToJava2D(0.0d, rectangle2D11, rectangleEdge12);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] { numberAxis8 };
        xYPlot3.setDomainAxes(valueAxisArray14);
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color18, stroke19);
        xYPlot16.setBackgroundPaint((java.awt.Paint) color18);
        xYPlot3.setRangeCrosshairPaint((java.awt.Paint) color18);
        float[] floatArray27 = new float[] { (byte) 1, 10L, 100.0f, 100.0f };
        float[] floatArray28 = color18.getComponents(floatArray27);
        float[] floatArray29 = java.awt.Color.RGBtoHSB(13, 255, (int) (short) 10, floatArray27);
        org.junit.Assert.assertNotNull(plotOrientation6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(valueAxisArray14);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(floatArray27);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertNotNull(floatArray29);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=192,g=192,b=192]");
        float float2 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis1.getCategoryMiddle(100, 13, rectangle2D5, rectangleEdge6);
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) (short) -1);
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 0, "PlotOrientation.VERTICAL");
        java.awt.Color color14 = java.awt.Color.LIGHT_GRAY;
        java.lang.String str15 = color14.toString();
        int int16 = color14.getBlue();
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) (byte) 0, (java.awt.Paint) color14);
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot21.setAnchorValue((double) (-1L), true);
        categoryPlot21.setRangeCrosshairVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation27 = categoryPlot21.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis29 = categoryPlot21.getRangeAxis((int) '4');
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke34 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker35 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color33, stroke34);
        xYPlot31.setBackgroundPaint((java.awt.Paint) color33);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer38 = null;
        xYPlot31.setRenderer(6, xYItemRenderer38);
        org.jfree.chart.event.PlotChangeListener plotChangeListener40 = null;
        xYPlot31.removeChangeListener(plotChangeListener40);
        java.awt.Stroke stroke42 = xYPlot31.getDomainZeroBaselineStroke();
        xYPlot30.setRangeGridlineStroke(stroke42);
        xYPlot30.setRangeCrosshairVisible(true);
        org.jfree.chart.plot.XYPlot xYPlot46 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint47 = xYPlot46.getDomainZeroBaselinePaint();
        boolean boolean48 = xYPlot46.isRangeGridlinesVisible();
        org.jfree.chart.axis.AxisLocation axisLocation49 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot46.setRangeAxisLocation(axisLocation49);
        xYPlot30.setDomainAxisLocation(axisLocation49, true);
        categoryPlot21.setDomainAxisLocation(axisLocation49, true);
        org.jfree.chart.plot.XYPlot xYPlot55 = new org.jfree.chart.plot.XYPlot();
        xYPlot55.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation58 = xYPlot55.getOrientation();
        java.lang.String str59 = plotOrientation58.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge60 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation49, plotOrientation58);
        try {
            double double61 = categoryAxis1.getCategoryMiddle(192, (int) (short) 100, rectangle2D20, rectangleEdge60);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "java.awt.Color[r=192,g=192,b=192]" + "'", str15.equals("java.awt.Color[r=192,g=192,b=192]"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 192 + "'", int16 == 192);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNull(valueAxis29);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(axisLocation49);
        org.junit.Assert.assertNotNull(plotOrientation58);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "PlotOrientation.VERTICAL" + "'", str59.equals("PlotOrientation.VERTICAL"));
        org.junit.Assert.assertNotNull(rectangleEdge60);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str2 = numberAxis1.getLabel();
        java.lang.String str3 = numberAxis1.getLabel();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("EXPAND");
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        xYPlot6.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation9 = xYPlot6.getOrientation();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate11 = day10.getSerialDate();
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint13 = xYPlot12.getDomainZeroBaselinePaint();
        boolean boolean14 = day10.equals((java.lang.Object) paint13);
        java.util.Date date15 = day10.getStart();
        boolean boolean16 = plotOrientation9.equals((java.lang.Object) date15);
        dateAxis5.setMinimumDate(date15);
        org.jfree.data.time.DateRange dateRange18 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis5.setRange((org.jfree.data.Range) dateRange18, false, false);
        numberAxis1.setRange((org.jfree.data.Range) dateRange18);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str2.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str3.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(plotOrientation9);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateRange18);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str2 = numberAxis1.getLabel();
        java.lang.String str3 = numberAxis1.getLabel();
        java.awt.Paint paint4 = numberAxis1.getAxisLinePaint();
        boolean boolean5 = numberAxis1.isTickLabelsVisible();
        numberAxis1.setVerticalTickLabels(false);
        org.jfree.chart.plot.Plot plot8 = numberAxis1.getPlot();
        java.awt.Stroke stroke9 = numberAxis1.getTickMarkStroke();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str2.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str3.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        xYPlot0.setRenderer((int) (byte) 1, xYItemRenderer4);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int9 = xYPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis8);
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis8);
        numberAxis8.setAutoTickUnitSelection(true, false);
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker19 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color17, stroke18);
        org.jfree.chart.util.Layer layer20 = null;
        xYPlot14.addRangeMarker(4, (org.jfree.chart.plot.Marker) categoryMarker19, layer20);
        org.jfree.data.general.Dataset dataset23 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent24 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) 100, dataset23);
        xYPlot14.datasetChanged(datasetChangeEvent24);
        org.jfree.data.general.DatasetGroup datasetGroup26 = xYPlot14.getDatasetGroup();
        numberAxis8.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot14);
        try {
            numberAxis8.setAutoRangeMinimumSize((double) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNull(datasetGroup26);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str2 = numberAxis1.getLabel();
        java.lang.String str3 = numberAxis1.getLabel();
        java.awt.Paint paint4 = numberAxis1.getAxisLinePaint();
        boolean boolean5 = numberAxis1.isTickLabelsVisible();
        numberAxis1.setAutoRange(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis1.getLabelInsets();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit9 = numberAxis1.getTickUnit();
        numberAxis1.resizeRange(6.0d, (double) 10.0f);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str2.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str3.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(numberTickUnit9);
    }

//    @Test
//    public void test255() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test255");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
//        int int2 = day1.getMonth();
//        long long3 = day1.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560452399999L + "'", long3 == 1560452399999L);
//    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color2);
        numberAxis1.setLowerBound(0.0d);
        double double6 = numberAxis1.getFixedDimension();
        java.awt.Color color7 = java.awt.Color.WHITE;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color7);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        xYPlot0.setDataset(xYDataset3);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        xYPlot0.setRangeAxis((int) (short) 1, valueAxis6);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        xYPlot0.setRenderer((int) '4', xYItemRenderer9, false);
        java.awt.Stroke stroke12 = xYPlot0.getRangeGridlineStroke();
        int int13 = xYPlot0.getDomainAxisCount();
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        java.util.List list7 = categoryPlot0.getCategoriesForAxis(categoryAxis6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot0.getRenderer(3);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.setAnchorValue((double) (-1L), true);
        categoryPlot10.clearDomainAxes();
        boolean boolean15 = categoryPlot0.equals((java.lang.Object) categoryPlot10);
        double double16 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot18.setAnchorValue((double) (-1L), true);
        categoryPlot18.setRangeCrosshairVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation24 = categoryPlot18.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis26 = categoryPlot18.getRangeAxis((int) '4');
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke31 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker32 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color30, stroke31);
        xYPlot28.setBackgroundPaint((java.awt.Paint) color30);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = null;
        xYPlot28.setRenderer(6, xYItemRenderer35);
        org.jfree.chart.event.PlotChangeListener plotChangeListener37 = null;
        xYPlot28.removeChangeListener(plotChangeListener37);
        java.awt.Stroke stroke39 = xYPlot28.getDomainZeroBaselineStroke();
        xYPlot27.setRangeGridlineStroke(stroke39);
        xYPlot27.setRangeCrosshairVisible(true);
        org.jfree.chart.plot.XYPlot xYPlot43 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint44 = xYPlot43.getDomainZeroBaselinePaint();
        boolean boolean45 = xYPlot43.isRangeGridlinesVisible();
        org.jfree.chart.axis.AxisLocation axisLocation46 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot43.setRangeAxisLocation(axisLocation46);
        xYPlot27.setDomainAxisLocation(axisLocation46, true);
        categoryPlot18.setDomainAxisLocation(axisLocation46, true);
        org.jfree.chart.plot.XYPlot xYPlot52 = new org.jfree.chart.plot.XYPlot();
        xYPlot52.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation55 = xYPlot52.getOrientation();
        java.lang.String str56 = plotOrientation55.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge57 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation46, plotOrientation55);
        categoryPlot0.setDomainAxisLocation(3, axisLocation46, true);
        org.jfree.chart.axis.AxisSpace axisSpace60 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace60);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertNull(categoryItemRenderer9);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertNull(valueAxis26);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(axisLocation46);
        org.junit.Assert.assertNotNull(plotOrientation55);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "PlotOrientation.VERTICAL" + "'", str56.equals("PlotOrientation.VERTICAL"));
        org.junit.Assert.assertNotNull(rectangleEdge57);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker5 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color3, stroke4);
        xYPlot1.setBackgroundPaint((java.awt.Paint) color3);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        xYPlot1.setRenderer(6, xYItemRenderer8);
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        xYPlot1.removeChangeListener(plotChangeListener10);
        java.awt.Stroke stroke12 = xYPlot1.getDomainZeroBaselineStroke();
        xYPlot0.setRangeGridlineStroke(stroke12);
        xYPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent16 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) true);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("", timeZone1);
        java.awt.Font font3 = dateAxis2.getTickLabelFont();
        java.util.Date date4 = dateAxis2.getMaximumDate();
        dateAxis2.configure();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color2, stroke3);
        xYPlot0.setBackgroundPaint((java.awt.Paint) color2);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        xYPlot0.setRenderer(6, xYItemRenderer7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.axis.AxisLocation axisLocation11 = axisLocation10.getOpposite();
        xYPlot0.setDomainAxisLocation(13, axisLocation10);
        xYPlot0.clearDomainAxes();
        org.jfree.chart.axis.AxisLocation axisLocation15 = null;
        try {
            xYPlot0.setRangeAxisLocation(0, axisLocation15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(axisLocation11);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("EXPAND");
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        xYPlot2.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = xYPlot2.getOrientation();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint9 = xYPlot8.getDomainZeroBaselinePaint();
        boolean boolean10 = day6.equals((java.lang.Object) paint9);
        java.util.Date date11 = day6.getStart();
        boolean boolean12 = plotOrientation5.equals((java.lang.Object) date11);
        dateAxis1.setMinimumDate(date11);
        java.text.DateFormat dateFormat14 = dateAxis1.getDateFormatOverride();
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        try {
            org.jfree.chart.axis.AxisState axisState21 = dateAxis1.draw(graphics2D15, (double) 10L, rectangle2D17, rectangle2D18, rectangleEdge19, plotRenderingInfo20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(dateFormat14);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color1, stroke2);
        java.awt.Paint paint4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryMarker3.setLabelPaint(paint4);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        numberAxis7.setTickLabelPaint((java.awt.Paint) color8);
        java.lang.String str10 = color8.toString();
        categoryMarker3.setOutlinePaint((java.awt.Paint) color8);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = categoryMarker3.getLabelOffset();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "java.awt.Color[r=0,g=0,b=128]" + "'", str10.equals("java.awt.Color[r=0,g=0,b=128]"));
        org.junit.Assert.assertNotNull(rectangleInsets12);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str2 = numberAxis1.getLabel();
        numberAxis1.setVisible(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis1.setTickUnit(numberTickUnit5, false, false);
        numberAxis1.setAxisLineVisible(false);
        numberAxis1.setAutoTickUnitSelection(true);
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint14 = xYPlot13.getDomainZeroBaselinePaint();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color16, stroke17);
        java.awt.Paint paint19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryMarker18.setLabelPaint(paint19);
        xYPlot13.setDomainZeroBaselinePaint(paint19);
        java.awt.Stroke stroke22 = xYPlot13.getDomainZeroBaselineStroke();
        numberAxis1.setAxisLineStroke(stroke22);
        numberAxis1.setLabelURL("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.awt.Stroke stroke26 = numberAxis1.getTickMarkStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = numberAxis1.getLabelInsets();
        org.jfree.chart.util.UnitType unitType28 = rectangleInsets27.getUnitType();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str2.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(numberTickUnit5);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(unitType28);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        try {
            java.awt.Color color1 = java.awt.Color.decode("SortOrder.DESCENDING");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"SortOrder.DESCENDING\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainZoomable();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        categoryPlot0.zoomRangeAxes((double) 8, plotRenderingInfo3, point2D4);
        org.jfree.chart.util.Layer layer7 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection8 = categoryPlot0.getDomainMarkers((int) 'a', layer7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color11, stroke12);
        xYPlot9.setBackgroundPaint((java.awt.Paint) color11);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        xYPlot9.setRenderer(6, xYItemRenderer16);
        org.jfree.chart.event.PlotChangeListener plotChangeListener18 = null;
        xYPlot9.removeChangeListener(plotChangeListener18);
        org.jfree.chart.axis.ValueAxis valueAxis21 = xYPlot9.getRangeAxisForDataset((int) (short) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        xYPlot9.setAxisOffset(rectangleInsets22);
        java.awt.Color color24 = java.awt.Color.blue;
        xYPlot9.setOutlinePaint((java.awt.Paint) color24);
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color24);
        int int27 = categoryPlot0.getWeight();
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = categoryPlot0.getDomainAxis();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(layer7);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNull(valueAxis21);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNull(categoryAxis28);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint3 = xYPlot2.getDomainZeroBaselinePaint();
        boolean boolean4 = day0.equals((java.lang.Object) paint3);
        int int5 = day0.getMonth();
        int int6 = day0.getYear();
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color9, stroke10);
        xYPlot7.setBackgroundPaint((java.awt.Paint) color9);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        xYPlot7.setRenderer(6, xYItemRenderer14);
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        xYPlot7.removeChangeListener(plotChangeListener16);
        org.jfree.chart.util.Layer layer18 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection19 = xYPlot7.getDomainMarkers(layer18);
        boolean boolean20 = day0.equals((java.lang.Object) layer18);
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(layer18);
        org.junit.Assert.assertNull(collection19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("EXPAND");
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        xYPlot2.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = xYPlot2.getOrientation();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint9 = xYPlot8.getDomainZeroBaselinePaint();
        boolean boolean10 = day6.equals((java.lang.Object) paint9);
        java.util.Date date11 = day6.getStart();
        boolean boolean12 = plotOrientation5.equals((java.lang.Object) date11);
        dateAxis1.setMinimumDate(date11);
        org.jfree.data.time.DateRange dateRange14 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis1.setRange((org.jfree.data.Range) dateRange14, false, false);
        org.jfree.chart.axis.Timeline timeline18 = null;
        dateAxis1.setTimeline(timeline18);
        java.text.DateFormat dateFormat20 = dateAxis1.getDateFormatOverride();
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateRange14);
        org.junit.Assert.assertNull(dateFormat20);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color9, stroke10);
        org.jfree.chart.util.Layer layer12 = null;
        xYPlot6.addRangeMarker(4, (org.jfree.chart.plot.Marker) categoryMarker11, layer12);
        java.awt.Font font14 = categoryMarker11.getLabelFont();
        java.awt.Paint paint15 = categoryMarker11.getPaint();
        org.jfree.chart.util.Layer layer16 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean17 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker11, layer16);
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str21 = numberAxis20.getLabel();
        java.lang.String str22 = numberAxis20.getLabel();
        java.awt.Paint paint23 = numberAxis20.getAxisLinePaint();
        boolean boolean24 = numberAxis20.isTickLabelsVisible();
        numberAxis20.setAutoRange(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = numberAxis20.getLabelInsets();
        java.awt.Stroke stroke28 = numberAxis20.getAxisLineStroke();
        int int29 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis20);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand30 = null;
        numberAxis20.setMarkerBand(markerAxisBand30);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(layer16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str21.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str22.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=192,g=192,b=192]");
        java.awt.Paint[] paintArray3 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray4 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint7 = xYPlot6.getDomainZeroBaselinePaint();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color9, stroke10);
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryMarker11.setLabelPaint(paint12);
        xYPlot6.setDomainZeroBaselinePaint(paint12);
        java.awt.Stroke stroke15 = xYPlot6.getDomainZeroBaselineStroke();
        java.awt.Stroke stroke16 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke17 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke21 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color20, stroke21);
        xYPlot18.setBackgroundPaint((java.awt.Paint) color20);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer25 = null;
        xYPlot18.setRenderer(6, xYItemRenderer25);
        org.jfree.chart.event.PlotChangeListener plotChangeListener27 = null;
        xYPlot18.removeChangeListener(plotChangeListener27);
        java.awt.Stroke stroke29 = xYPlot18.getDomainZeroBaselineStroke();
        java.awt.Stroke[] strokeArray30 = new java.awt.Stroke[] { stroke5, stroke15, stroke16, stroke17, stroke29 };
        java.awt.Stroke[] strokeArray31 = new java.awt.Stroke[] {};
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str34 = numberAxis33.getLabel();
        java.lang.String str35 = numberAxis33.getLabel();
        java.awt.Paint paint36 = numberAxis33.getAxisLinePaint();
        java.awt.Shape shape37 = numberAxis33.getRightArrow();
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str40 = numberAxis39.getLabel();
        java.lang.String str41 = numberAxis39.getLabel();
        java.awt.Paint paint42 = numberAxis39.getAxisLinePaint();
        java.awt.Shape shape43 = numberAxis39.getRightArrow();
        org.jfree.chart.axis.NumberAxis numberAxis45 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str46 = numberAxis45.getLabel();
        java.lang.String str47 = numberAxis45.getLabel();
        java.awt.Paint paint48 = numberAxis45.getAxisLinePaint();
        java.awt.Shape shape49 = numberAxis45.getRightArrow();
        org.jfree.chart.axis.NumberAxis numberAxis51 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str52 = numberAxis51.getLabel();
        java.lang.String str53 = numberAxis51.getLabel();
        java.awt.Paint paint54 = numberAxis51.getAxisLinePaint();
        java.awt.Shape shape55 = numberAxis51.getRightArrow();
        java.awt.Shape[] shapeArray56 = new java.awt.Shape[] { shape37, shape43, shape49, shape55 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier57 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray3, paintArray4, strokeArray30, strokeArray31, shapeArray56);
        boolean boolean58 = categoryAxis2.equals((java.lang.Object) paintArray3);
        int int59 = categoryAxis2.getMaximumCategoryLabelLines();
        org.jfree.chart.plot.XYPlot xYPlot60 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis62 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int63 = xYPlot60.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis62);
        java.awt.Stroke stroke64 = numberAxis62.getAxisLineStroke();
        boolean boolean65 = numberAxis62.isNegativeArrowVisible();
        org.jfree.data.Range range66 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis62.setRangeWithMargins(range66);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit68 = numberAxis62.getTickUnit();
        numberAxis62.setUpperMargin((double) 500);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer71 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot72 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis62, categoryItemRenderer71);
        org.junit.Assert.assertNotNull(paintArray3);
        org.junit.Assert.assertNotNull(paintArray4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(strokeArray30);
        org.junit.Assert.assertNotNull(strokeArray31);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str34.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str35.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str40.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str41.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(shape43);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str46.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str47.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNotNull(shape49);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str52.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str53.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertNotNull(shape55);
        org.junit.Assert.assertNotNull(shapeArray56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-1) + "'", int63 == (-1));
        org.junit.Assert.assertNotNull(stroke64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(range66);
        org.junit.Assert.assertNotNull(numberTickUnit68);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        java.util.List list7 = categoryPlot0.getCategoriesForAxis(categoryAxis6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot0.getRenderer(3);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.setAnchorValue((double) (-1L), true);
        categoryPlot10.clearDomainAxes();
        boolean boolean15 = categoryPlot0.equals((java.lang.Object) categoryPlot10);
        categoryPlot0.clearDomainAxes();
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertNull(categoryItemRenderer9);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int6 = xYPlot3.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis5);
        numberAxis5.setLowerBound((double) (short) 10);
        xYPlot0.setDomainAxis((int) (byte) 1, (org.jfree.chart.axis.ValueAxis) numberAxis5, true);
        java.awt.Paint paint11 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint13 = xYPlot12.getDomainZeroBaselinePaint();
        boolean boolean14 = xYPlot12.isRangeGridlinesVisible();
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot12.setRangeAxisLocation(axisLocation15);
        xYPlot0.setRangeAxisLocation(axisLocation15);
        boolean boolean18 = xYPlot0.isRangeZoomable();
        boolean boolean19 = xYPlot0.isDomainZeroBaselineVisible();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color2, stroke3);
        xYPlot0.setBackgroundPaint((java.awt.Paint) color2);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        xYPlot0.setRenderer(6, xYItemRenderer7);
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        xYPlot0.removeChangeListener(plotChangeListener9);
        org.jfree.chart.axis.ValueAxis valueAxis12 = xYPlot0.getRangeAxisForDataset((int) (short) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        xYPlot0.setAxisOffset(rectangleInsets13);
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker(0.0d);
        double double18 = valueMarker17.getValue();
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str21 = numberAxis20.getLabel();
        java.lang.String str22 = numberAxis20.getLabel();
        java.awt.Paint paint23 = numberAxis20.getAxisLinePaint();
        boolean boolean24 = valueMarker17.equals((java.lang.Object) paint23);
        java.awt.Color color25 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        boolean boolean26 = valueMarker17.equals((java.lang.Object) color25);
        java.awt.Paint paint27 = valueMarker17.getPaint();
        java.awt.Color color28 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        java.awt.Color color32 = java.awt.Color.RED;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot();
        xYPlot33.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation36 = xYPlot33.getOrientation();
        org.jfree.chart.axis.NumberAxis numberAxis38 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.awt.Paint paint39 = numberAxis38.getLabelPaint();
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = null;
        double double43 = numberAxis38.valueToJava2D(0.0d, rectangle2D41, rectangleEdge42);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray44 = new org.jfree.chart.axis.ValueAxis[] { numberAxis38 };
        xYPlot33.setDomainAxes(valueAxisArray44);
        org.jfree.chart.plot.XYPlot xYPlot46 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color48 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke49 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker50 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color48, stroke49);
        xYPlot46.setBackgroundPaint((java.awt.Paint) color48);
        xYPlot33.setRangeCrosshairPaint((java.awt.Paint) color48);
        float[] floatArray57 = new float[] { (byte) 1, 10L, 100.0f, 100.0f };
        float[] floatArray58 = color48.getComponents(floatArray57);
        float[] floatArray59 = color32.getRGBComponents(floatArray58);
        float[] floatArray60 = java.awt.Color.RGBtoHSB((int) (byte) 1, (int) (byte) 1, 0, floatArray59);
        float[] floatArray61 = color28.getRGBComponents(floatArray59);
        java.awt.Color color62 = color28.brighter();
        valueMarker17.setLabelPaint((java.awt.Paint) color62);
        org.jfree.chart.plot.ValueMarker valueMarker65 = new org.jfree.chart.plot.ValueMarker((double) 'a');
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType66 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        java.lang.Object obj67 = null;
        boolean boolean68 = lengthAdjustmentType66.equals(obj67);
        valueMarker65.setLabelOffsetType(lengthAdjustmentType66);
        valueMarker17.setLabelOffsetType(lengthAdjustmentType66);
        java.lang.String str71 = lengthAdjustmentType66.toString();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType72 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        try {
            java.awt.geom.Rectangle2D rectangle2D73 = rectangleInsets13.createAdjustedRectangle(rectangle2D15, lengthAdjustmentType66, lengthAdjustmentType72);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str21.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str22.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(plotOrientation36);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(valueAxisArray44);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(floatArray57);
        org.junit.Assert.assertNotNull(floatArray58);
        org.junit.Assert.assertNotNull(floatArray59);
        org.junit.Assert.assertNotNull(floatArray60);
        org.junit.Assert.assertNotNull(floatArray61);
        org.junit.Assert.assertNotNull(color62);
        org.junit.Assert.assertNotNull(lengthAdjustmentType66);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "NO_CHANGE" + "'", str71.equals("NO_CHANGE"));
        org.junit.Assert.assertNotNull(lengthAdjustmentType72);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj2 = objectList0.get(0);
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        xYPlot3.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        xYPlot3.setRenderer((int) (byte) 1, xYItemRenderer7);
        double double9 = xYPlot3.getRangeCrosshairValue();
        int int10 = objectList0.indexOf((java.lang.Object) xYPlot3);
        java.awt.Paint[] paintArray11 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray12 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint15 = xYPlot14.getDomainZeroBaselinePaint();
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker19 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color17, stroke18);
        java.awt.Paint paint20 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryMarker19.setLabelPaint(paint20);
        xYPlot14.setDomainZeroBaselinePaint(paint20);
        java.awt.Stroke stroke23 = xYPlot14.getDomainZeroBaselineStroke();
        java.awt.Stroke stroke24 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke25 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke29 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker30 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color28, stroke29);
        xYPlot26.setBackgroundPaint((java.awt.Paint) color28);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = null;
        xYPlot26.setRenderer(6, xYItemRenderer33);
        org.jfree.chart.event.PlotChangeListener plotChangeListener35 = null;
        xYPlot26.removeChangeListener(plotChangeListener35);
        java.awt.Stroke stroke37 = xYPlot26.getDomainZeroBaselineStroke();
        java.awt.Stroke[] strokeArray38 = new java.awt.Stroke[] { stroke13, stroke23, stroke24, stroke25, stroke37 };
        java.awt.Stroke[] strokeArray39 = new java.awt.Stroke[] {};
        org.jfree.chart.axis.NumberAxis numberAxis41 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str42 = numberAxis41.getLabel();
        java.lang.String str43 = numberAxis41.getLabel();
        java.awt.Paint paint44 = numberAxis41.getAxisLinePaint();
        java.awt.Shape shape45 = numberAxis41.getRightArrow();
        org.jfree.chart.axis.NumberAxis numberAxis47 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str48 = numberAxis47.getLabel();
        java.lang.String str49 = numberAxis47.getLabel();
        java.awt.Paint paint50 = numberAxis47.getAxisLinePaint();
        java.awt.Shape shape51 = numberAxis47.getRightArrow();
        org.jfree.chart.axis.NumberAxis numberAxis53 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str54 = numberAxis53.getLabel();
        java.lang.String str55 = numberAxis53.getLabel();
        java.awt.Paint paint56 = numberAxis53.getAxisLinePaint();
        java.awt.Shape shape57 = numberAxis53.getRightArrow();
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str60 = numberAxis59.getLabel();
        java.lang.String str61 = numberAxis59.getLabel();
        java.awt.Paint paint62 = numberAxis59.getAxisLinePaint();
        java.awt.Shape shape63 = numberAxis59.getRightArrow();
        java.awt.Shape[] shapeArray64 = new java.awt.Shape[] { shape45, shape51, shape57, shape63 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier65 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray11, paintArray12, strokeArray38, strokeArray39, shapeArray64);
        java.lang.Object obj66 = defaultDrawingSupplier65.clone();
        java.awt.Paint paint67 = defaultDrawingSupplier65.getNextPaint();
        boolean boolean68 = objectList0.equals((java.lang.Object) defaultDrawingSupplier65);
        org.jfree.chart.plot.XYPlot xYPlot69 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis71 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int72 = xYPlot69.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis71);
        java.awt.Color color73 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        xYPlot69.setRangeCrosshairPaint((java.awt.Paint) color73);
        boolean boolean75 = objectList0.equals((java.lang.Object) xYPlot69);
        org.junit.Assert.assertNull(obj2);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(paintArray11);
        org.junit.Assert.assertNotNull(paintArray12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(strokeArray38);
        org.junit.Assert.assertNotNull(strokeArray39);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str42.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str43.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(shape45);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str48.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str49.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertNotNull(shape51);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str54.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str55.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint56);
        org.junit.Assert.assertNotNull(shape57);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str60.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str61.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint62);
        org.junit.Assert.assertNotNull(shape63);
        org.junit.Assert.assertNotNull(shapeArray64);
        org.junit.Assert.assertNotNull(obj66);
        org.junit.Assert.assertNotNull(paint67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + (-1) + "'", int72 == (-1));
        org.junit.Assert.assertNotNull(color73);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int6 = xYPlot3.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis5);
        numberAxis5.setLowerBound((double) (short) 10);
        xYPlot0.setDomainAxis((int) (byte) 1, (org.jfree.chart.axis.ValueAxis) numberAxis5, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double12 = rectangleInsets11.getTop();
        java.lang.String str13 = rectangleInsets11.toString();
        xYPlot0.setInsets(rectangleInsets11, true);
        java.awt.Stroke stroke16 = xYPlot0.getDomainGridlineStroke();
        java.awt.Stroke stroke17 = xYPlot0.getDomainCrosshairStroke();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str13.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 100.0f);
        java.awt.Font font2 = valueMarker1.getLabelFont();
        org.junit.Assert.assertNotNull(font2);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color2, stroke3);
        xYPlot0.setBackgroundPaint((java.awt.Paint) color2);
        xYPlot0.setForegroundAlpha((float) '4');
        java.awt.Stroke stroke8 = xYPlot0.getRangeZeroBaselineStroke();
        boolean boolean9 = xYPlot0.isRangeCrosshairVisible();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        boolean boolean2 = xYPlot0.isRangeGridlinesVisible();
        int int3 = xYPlot0.getDatasetCount();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder4 = xYPlot0.getSeriesRenderingOrder();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(seriesRenderingOrder4);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color9, stroke10);
        org.jfree.chart.util.Layer layer12 = null;
        xYPlot6.addRangeMarker(4, (org.jfree.chart.plot.Marker) categoryMarker11, layer12);
        java.awt.Font font14 = categoryMarker11.getLabelFont();
        java.awt.Paint paint15 = categoryMarker11.getPaint();
        org.jfree.chart.util.Layer layer16 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean17 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker11, layer16);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        java.util.List list19 = categoryPlot0.getCategoriesForAxis(categoryAxis18);
        java.util.List list20 = categoryPlot0.getAnnotations();
        org.jfree.chart.axis.ValueAxis valueAxis21 = categoryPlot0.getRangeAxis();
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(layer16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertNull(valueAxis21);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str2 = numberAxis1.getLabel();
        java.lang.String str3 = numberAxis1.getLabel();
        java.awt.Paint paint4 = numberAxis1.getAxisLinePaint();
        java.awt.Shape shape5 = numberAxis1.getRightArrow();
        boolean boolean6 = numberAxis1.isAutoRange();
        boolean boolean7 = numberAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.awt.Paint paint10 = numberAxis9.getLabelPaint();
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        double double14 = numberAxis9.valueToJava2D(0.0d, rectangle2D12, rectangleEdge13);
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = null;
        double double18 = numberAxis9.java2DToValue((double) 0L, rectangle2D16, rectangleEdge17);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double20 = rectangleInsets19.getTop();
        double double22 = rectangleInsets19.calculateBottomOutset((double) 1);
        numberAxis9.setLabelInsets(rectangleInsets19);
        double double25 = rectangleInsets19.calculateBottomInset((double) 0);
        numberAxis1.setLabelInsets(rectangleInsets19);
        double double28 = rectangleInsets19.calculateBottomOutset((double) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str2.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str3.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 2.0d + "'", double20 == 2.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 2.0d + "'", double22 == 2.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 2.0d + "'", double25 == 2.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 2.0d + "'", double28 == 2.0d);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("EXPAND");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition2 = dateAxis1.getTickMarkPosition();
        org.junit.Assert.assertNotNull(dateTickMarkPosition2);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker5 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color3, stroke4);
        org.jfree.chart.util.Layer layer6 = null;
        xYPlot0.addRangeMarker(4, (org.jfree.chart.plot.Marker) categoryMarker5, layer6);
        org.jfree.data.general.Dataset dataset9 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent10 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) 100, dataset9);
        xYPlot0.datasetChanged(datasetChangeEvent10);
        org.jfree.data.general.DatasetGroup datasetGroup12 = xYPlot0.getDatasetGroup();
        org.jfree.chart.event.PlotChangeListener plotChangeListener13 = null;
        xYPlot0.addChangeListener(plotChangeListener13);
        float float15 = xYPlot0.getBackgroundAlpha();
        java.awt.Paint paint16 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        xYPlot0.setDomainGridlinePaint(paint16);
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int21 = xYPlot18.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis20);
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        xYPlot18.setRangeZeroBaselinePaint((java.awt.Paint) color22);
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke29 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker30 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color28, stroke29);
        org.jfree.chart.util.Layer layer31 = null;
        xYPlot25.addRangeMarker(4, (org.jfree.chart.plot.Marker) categoryMarker30, layer31);
        java.awt.Color color33 = java.awt.Color.BLACK;
        categoryMarker30.setPaint((java.awt.Paint) color33);
        org.jfree.chart.util.Layer layer35 = null;
        xYPlot18.addRangeMarker(0, (org.jfree.chart.plot.Marker) categoryMarker30, layer35);
        org.jfree.chart.plot.ValueMarker valueMarker38 = new org.jfree.chart.plot.ValueMarker(0.0d);
        double double39 = valueMarker38.getValue();
        org.jfree.chart.axis.NumberAxis numberAxis41 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str42 = numberAxis41.getLabel();
        java.lang.String str43 = numberAxis41.getLabel();
        java.awt.Paint paint44 = numberAxis41.getAxisLinePaint();
        boolean boolean45 = valueMarker38.equals((java.lang.Object) paint44);
        java.awt.Color color46 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        boolean boolean47 = valueMarker38.equals((java.lang.Object) color46);
        categoryMarker30.setOutlinePaint((java.awt.Paint) color46);
        xYPlot0.setRangeGridlinePaint((java.awt.Paint) color46);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(datasetGroup12);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 1.0f + "'", float15 == 1.0f);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str42.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str43.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int3 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        xYPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color4);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int9 = xYPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis8);
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color12, stroke13);
        xYPlot10.setBackgroundPaint((java.awt.Paint) color12);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        xYPlot10.setRenderer(6, xYItemRenderer17);
        org.jfree.chart.util.Layer layer20 = null;
        java.util.Collection collection21 = xYPlot10.getRangeMarkers((int) ' ', layer20);
        boolean boolean22 = numberAxis8.hasListener((java.util.EventListener) xYPlot10);
        java.lang.Object obj23 = numberAxis8.clone();
        boolean boolean24 = numberAxis8.isAutoTickUnitSelection();
        boolean boolean25 = color4.equals((java.lang.Object) numberAxis8);
        java.lang.String str26 = color4.toString();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "java.awt.Color[r=128,g=128,b=255]" + "'", str26.equals("java.awt.Color[r=128,g=128,b=255]"));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        boolean boolean2 = xYPlot0.isRangeGridlinesVisible();
        org.jfree.chart.axis.AxisLocation axisLocation3 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot0.setRangeAxisLocation(axisLocation3);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str7 = numberAxis6.getLabel();
        numberAxis6.setVisible(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit10 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis6.setTickUnit(numberTickUnit10, false, false);
        numberAxis6.setLabelURL("SeriesRenderingOrder.FORWARD");
        boolean boolean16 = numberAxis6.isAutoTickUnitSelection();
        numberAxis6.setRange((double) ' ', (double) 100.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = numberAxis6.getLabelInsets();
        int int21 = xYPlot0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str7.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(numberTickUnit10);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=0,g=0,b=128]");
        java.lang.Object obj2 = dateAxis1.clone();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis1.setTickUnit(dateTickUnit3, false, false);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(dateTickUnit3);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("EXPAND");
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        xYPlot2.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = xYPlot2.getOrientation();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint9 = xYPlot8.getDomainZeroBaselinePaint();
        boolean boolean10 = day6.equals((java.lang.Object) paint9);
        java.util.Date date11 = day6.getStart();
        boolean boolean12 = plotOrientation5.equals((java.lang.Object) date11);
        dateAxis1.setMinimumDate(date11);
        org.jfree.data.time.DateRange dateRange14 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis1.setRange((org.jfree.data.Range) dateRange14, false, false);
        org.jfree.chart.axis.Timeline timeline18 = null;
        dateAxis1.setTimeline(timeline18);
        java.lang.Object obj20 = dateAxis1.clone();
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot23.setAnchorValue((double) (-1L), true);
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = categoryPlot23.getDomainAxis(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        java.util.List list30 = categoryPlot23.getCategoriesForAxis(categoryAxis29);
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        int int34 = xYPlot31.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis33);
        java.awt.Stroke stroke35 = numberAxis33.getAxisLineStroke();
        numberAxis33.setVisible(false);
        org.jfree.chart.plot.XYPlot xYPlot38 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color40 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke41 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker42 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color40, stroke41);
        xYPlot38.setBackgroundPaint((java.awt.Paint) color40);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer45 = null;
        xYPlot38.setRenderer(6, xYItemRenderer45);
        org.jfree.chart.event.PlotChangeListener plotChangeListener47 = null;
        xYPlot38.removeChangeListener(plotChangeListener47);
        java.awt.Stroke stroke49 = xYPlot38.getDomainZeroBaselineStroke();
        numberAxis33.setTickMarkStroke(stroke49);
        categoryPlot23.setRangeCrosshairStroke(stroke49);
        org.jfree.chart.util.RectangleEdge rectangleEdge53 = categoryPlot23.getDomainAxisEdge(11);
        try {
            double double54 = dateAxis1.java2DToValue((double) 'a', rectangle2D22, rectangleEdge53);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateRange14);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNull(categoryAxis28);
        org.junit.Assert.assertNotNull(list30);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(rectangleEdge53);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color2);
        numberAxis1.setLowerBound(0.0d);
        numberAxis1.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str10 = numberAxis9.getLabel();
        java.lang.String str11 = numberAxis9.getLabel();
        java.awt.Paint paint12 = numberAxis9.getAxisLinePaint();
        boolean boolean13 = numberAxis9.isTickLabelsVisible();
        numberAxis9.setAutoRange(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = numberAxis9.getLabelInsets();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit17 = numberAxis9.getTickUnit();
        numberAxis1.setTickUnit(numberTickUnit17, true, false);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str10.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str11.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(numberTickUnit17);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color6, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color10, stroke11);
        categoryMarker8.setLabelPaint((java.awt.Paint) color10);
        org.jfree.chart.util.Layer layer14 = null;
        categoryPlot0.addRangeMarker((int) (short) 1, (org.jfree.chart.plot.Marker) categoryMarker8, layer14, false);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray17 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot0.setDomainAxes(categoryAxisArray17);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        int int20 = categoryPlot0.getIndexOf(categoryItemRenderer19);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = categoryPlot0.getDomainAxis(100);
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.axis.AxisLocation axisLocation25 = categoryPlot0.getRangeAxisLocation((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation26 = categoryPlot0.getDomainAxisLocation();
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(categoryAxisArray17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNull(categoryAxis22);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertNotNull(axisLocation26);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        boolean boolean2 = xYPlot0.isRangeGridlinesVisible();
        java.awt.Color color5 = java.awt.Color.getColor("hi!", 0);
        xYPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color5);
        xYPlot0.setDomainGridlinesVisible(true);
        java.lang.Class<?> wildcardClass9 = xYPlot0.getClass();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        try {
            xYPlot0.handleClick((int) (byte) 10, 3, plotRenderingInfo12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str2 = numberAxis1.getLabel();
        numberAxis1.setVisible(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis1.setTickUnit(numberTickUnit5, false, false);
        numberAxis1.setLabelURL("SeriesRenderingOrder.FORWARD");
        boolean boolean11 = numberAxis1.isAutoTickUnitSelection();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str14 = numberAxis13.getLabel();
        java.lang.String str15 = numberAxis13.getLabel();
        java.awt.Paint paint16 = numberAxis13.getAxisLinePaint();
        java.awt.Shape shape17 = numberAxis13.getRightArrow();
        numberAxis1.setDownArrow(shape17);
        java.text.NumberFormat numberFormat19 = numberAxis1.getNumberFormatOverride();
        java.lang.String str20 = numberAxis1.getLabelURL();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str2.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(numberTickUnit5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str14.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str15.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNull(numberFormat19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "SeriesRenderingOrder.FORWARD" + "'", str20.equals("SeriesRenderingOrder.FORWARD"));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str2 = numberAxis1.getLabel();
        java.lang.String str3 = numberAxis1.getLabel();
        java.awt.Paint paint4 = numberAxis1.getAxisLinePaint();
        boolean boolean5 = numberAxis1.isTickLabelsVisible();
        java.awt.Font font6 = numberAxis1.getTickLabelFont();
        numberAxis1.setAutoRangeStickyZero(true);
        double double9 = numberAxis1.getLowerMargin();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str2.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str3.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        xYPlot2.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = xYPlot2.getOrientation();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint9 = xYPlot8.getDomainZeroBaselinePaint();
        boolean boolean10 = day6.equals((java.lang.Object) paint9);
        java.util.Date date11 = day6.getStart();
        boolean boolean12 = plotOrientation5.equals((java.lang.Object) date11);
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date11, timeZone13);
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("CategoryAnchor.START", timeZone13);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("hi!", timeZone13);
        boolean boolean17 = dateAxis16.isVerticalTickLabels();
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint2 = xYPlot1.getDomainZeroBaselinePaint();
        boolean boolean3 = xYPlot1.isRangeGridlinesVisible();
        java.awt.Color color6 = java.awt.Color.getColor("hi!", 0);
        xYPlot1.setRangeZeroBaselinePaint((java.awt.Paint) color6);
        org.jfree.chart.axis.ValueAxis valueAxis8 = xYPlot1.getDomainAxis();
        org.jfree.chart.plot.Plot plot9 = xYPlot1.getParent();
        org.jfree.data.general.Dataset dataset11 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) 100, dataset11);
        xYPlot1.datasetChanged(datasetChangeEvent12);
        xYPlot0.datasetChanged(datasetChangeEvent12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        xYPlot0.zoomDomainAxes((double) (short) 100, plotRenderingInfo16, point2D17);
        xYPlot0.setDomainCrosshairValue((double) (short) 10);
        java.awt.Paint paint21 = xYPlot0.getRangeTickBandPaint();
        xYPlot0.setBackgroundAlpha((float) 2019);
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke26 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker27 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color25, stroke26);
        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke30 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker31 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color29, stroke30);
        categoryMarker27.setLabelPaint((java.awt.Paint) color29);
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot33.setAnchorValue((double) (-1L), true);
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = categoryPlot33.getDomainAxis(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = null;
        java.util.List list40 = categoryPlot33.getCategoriesForAxis(categoryAxis39);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer42 = categoryPlot33.getRenderer(3);
        org.jfree.chart.plot.XYPlot xYPlot44 = new org.jfree.chart.plot.XYPlot();
        xYPlot44.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer48 = null;
        xYPlot44.setRenderer((int) (byte) 1, xYItemRenderer48);
        double double50 = xYPlot44.getRangeCrosshairValue();
        org.jfree.chart.plot.ValueMarker valueMarker52 = new org.jfree.chart.plot.ValueMarker(0.0d);
        double double53 = valueMarker52.getValue();
        java.awt.Paint paint55 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.plot.XYPlot xYPlot56 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke57 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot56.setDomainGridlineStroke(stroke57);
        org.jfree.chart.plot.ValueMarker valueMarker59 = new org.jfree.chart.plot.ValueMarker(0.0d, paint55, stroke57);
        java.awt.Font font60 = valueMarker59.getLabelFont();
        valueMarker52.setLabelFont(font60);
        valueMarker52.setLabel("ChartChangeEventType.DATASET_UPDATED");
        xYPlot44.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker52);
        org.jfree.chart.util.Layer layer65 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot33.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker52, layer65);
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker27, layer65);
        try {
            categoryMarker27.setAlpha((float) 175);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertNull(plot9);
        org.junit.Assert.assertNull(paint21);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNull(categoryAxis38);
        org.junit.Assert.assertNotNull(list40);
        org.junit.Assert.assertNull(categoryItemRenderer42);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertNotNull(font60);
        org.junit.Assert.assertNotNull(layer65);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color2, stroke3);
        xYPlot0.setBackgroundPaint((java.awt.Paint) color2);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str9 = numberAxis8.getLabel();
        numberAxis8.setVisible(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis8.setTickUnit(numberTickUnit12, false, false);
        numberAxis8.setAxisLineVisible(false);
        numberAxis8.setAutoTickUnitSelection(true);
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint21 = xYPlot20.getDomainZeroBaselinePaint();
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker25 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color23, stroke24);
        java.awt.Paint paint26 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryMarker25.setLabelPaint(paint26);
        xYPlot20.setDomainZeroBaselinePaint(paint26);
        java.awt.Stroke stroke29 = xYPlot20.getDomainZeroBaselineStroke();
        numberAxis8.setAxisLineStroke(stroke29);
        xYPlot0.setRangeAxis((int) (short) 0, (org.jfree.chart.axis.ValueAxis) numberAxis8);
        numberAxis8.setFixedAutoRange(0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str36 = numberAxis35.getLabel();
        java.lang.String str37 = numberAxis35.getLabel();
        java.awt.Paint paint38 = numberAxis35.getAxisLinePaint();
        java.awt.Shape shape39 = numberAxis35.getRightArrow();
        boolean boolean40 = numberAxis35.isAutoRange();
        numberAxis35.setLabelURL("AxisLocation.TOP_OR_LEFT");
        java.awt.Shape shape43 = numberAxis35.getLeftArrow();
        numberAxis8.setRightArrow(shape43);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str9.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str36.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str37.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(shape43);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 100.0f);
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker5 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color3, stroke4);
        java.awt.Paint paint6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryMarker5.setLabelPaint(paint6);
        java.awt.Font font8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryMarker5.setLabelFont(font8);
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str12 = numberAxis11.getLabel();
        java.lang.String str13 = numberAxis11.getLabel();
        java.awt.Paint paint14 = numberAxis11.getAxisLinePaint();
        categoryMarker5.setLabelPaint(paint14);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent16 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker5);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType17 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        markerChangeEvent16.setType(chartChangeEventType17);
        valueMarker1.notifyListeners(markerChangeEvent16);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType20 = markerChangeEvent16.getType();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str12.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str13.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(chartChangeEventType17);
        org.junit.Assert.assertNotNull(chartChangeEventType20);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker5 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color3, stroke4);
        org.jfree.chart.util.Layer layer6 = null;
        xYPlot0.addRangeMarker(4, (org.jfree.chart.plot.Marker) categoryMarker5, layer6);
        xYPlot0.setDomainCrosshairVisible(true);
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        int int11 = xYPlot0.indexOf(xYDataset10);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color1, stroke2);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", (java.awt.Paint) color5, stroke6);
        categoryMarker3.setLabelPaint((java.awt.Paint) color5);
        java.awt.Font font9 = categoryMarker3.getLabelFont();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker3);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType11 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        java.lang.String str12 = chartChangeEventType11.toString();
        markerChangeEvent10.setType(chartChangeEventType11);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(chartChangeEventType11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str12.equals("ChartChangeEventType.DATASET_UPDATED"));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BASELINE_LEFT");
        java.lang.String str2 = numberAxis1.getLabel();
        java.lang.String str3 = numberAxis1.getLabel();
        java.awt.Paint paint4 = numberAxis1.getAxisLinePaint();
        java.awt.Shape shape5 = numberAxis1.getRightArrow();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = numberAxis1.getTickLabelInsets();
        java.lang.String str7 = rectangleInsets6.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str2.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str3.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str7.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("", timeZone2);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("NO_CHANGE", timeZone2);
        double double5 = dateAxis4.getLowerMargin();
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("EXPAND");
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        xYPlot2.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = xYPlot2.getOrientation();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint9 = xYPlot8.getDomainZeroBaselinePaint();
        boolean boolean10 = day6.equals((java.lang.Object) paint9);
        java.util.Date date11 = day6.getStart();
        boolean boolean12 = plotOrientation5.equals((java.lang.Object) date11);
        dateAxis1.setMinimumDate(date11);
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = dateAxis1.java2DToValue((double) 15, rectangle2D15, rectangleEdge16);
        java.lang.Object obj18 = dateAxis1.clone();
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 9.223372036854776E18d + "'", double17 == 9.223372036854776E18d);
        org.junit.Assert.assertNotNull(obj18);
    }
}

