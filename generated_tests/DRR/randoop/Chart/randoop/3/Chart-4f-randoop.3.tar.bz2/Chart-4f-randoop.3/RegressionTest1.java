import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        java.awt.Paint paint1 = null;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        try {
            org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (-458), paint1, stroke2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = categoryPlot4.getDomainAxisEdge();
        boolean boolean6 = categoryPlot4.isRangeGridlinesVisible();
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=0,g=255,b=0]");
        org.jfree.data.Range range9 = categoryPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis8);
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        categoryPlot4.setFixedDomainAxisSpace(axisSpace10, false);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(range9);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        int int2 = combinedDomainXYPlot0.getDomainAxisIndex(valueAxis1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = combinedDomainXYPlot0.getRangeAxis();
        boolean boolean4 = combinedDomainXYPlot0.isSubplot();
        combinedDomainXYPlot0.setRangeMinorGridlinesVisible(false);
        boolean boolean7 = combinedDomainXYPlot0.isDomainZeroBaselineVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = combinedDomainXYPlot0.getRenderer();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(xYItemRenderer8);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.START;
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.data.Range range2 = xYStepRenderer0.findDomainBounds(xYDataset1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = null;
        xYStepRenderer0.setBaseToolTipGenerator(xYToolTipGenerator3);
        boolean boolean5 = xYStepRenderer0.getBaseShapesVisible();
        double double6 = xYStepRenderer0.getStepPoint();
        boolean boolean9 = xYStepRenderer0.getItemLineVisible((int) 'a', 15);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = xYStepRenderer0.getBaseNegativeItemLabelPosition();
        try {
            xYStepRenderer0.setStepPoint((double) (-2208960000000L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires stepPoint in [0.0;1.0]");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        int int2 = combinedDomainXYPlot0.getDomainAxisIndex(valueAxis1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = combinedDomainXYPlot0.getRangeAxis();
        boolean boolean4 = combinedDomainXYPlot0.isSubplot();
        combinedDomainXYPlot0.setRangeMinorGridlinesVisible(false);
        boolean boolean7 = combinedDomainXYPlot0.isDomainZeroBaselineVisible();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder8 = combinedDomainXYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        try {
            combinedDomainXYPlot0.zoomRangeAxes(8.0d, plotRenderingInfo10, point2D11, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(seriesRenderingOrder8);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = categoryPlot4.getDomainAxisEdge();
        java.awt.Paint paint6 = categoryPlot4.getOutlinePaint();
        java.awt.Paint paint9 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer10 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer10.clearSeriesStrokes(true);
        java.awt.Stroke stroke14 = xYBarRenderer10.lookupSeriesOutlineStroke(100);
        xYBarRenderer10.setShadowXOffset((double) 100.0f);
        java.awt.Stroke stroke17 = xYBarRenderer10.getBaseOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker(0.05d, paint9, stroke17);
        float float19 = valueMarker18.getAlpha();
        org.jfree.chart.util.Layer layer20 = null;
        boolean boolean21 = categoryPlot4.removeRangeMarker(100, (org.jfree.chart.plot.Marker) valueMarker18, layer20);
        java.awt.Graphics2D graphics2D22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        try {
            categoryPlot4.drawBackground(graphics2D22, rectangle2D23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 1.0f + "'", float19 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        int int2 = combinedDomainXYPlot0.getDomainAxisIndex(valueAxis1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = combinedDomainXYPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        try {
            combinedDomainXYPlot0.setDomainAxis((-9999), valueAxis5, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(valueAxis3);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        int int2 = combinedDomainXYPlot0.getDomainAxisIndex(valueAxis1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = combinedDomainXYPlot0.getRangeAxisIndex(valueAxis3);
        java.awt.Paint paint5 = combinedDomainXYPlot0.getDomainZeroBaselinePaint();
        boolean boolean6 = combinedDomainXYPlot0.isDomainZeroBaselineVisible();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder7 = combinedDomainXYPlot0.getSeriesRenderingOrder();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis10, categoryItemRenderer11);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = categoryPlot12.getDomainAxisEdge();
        java.awt.Paint paint14 = categoryPlot12.getOutlinePaint();
        java.awt.Paint paint17 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer18 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer18.clearSeriesStrokes(true);
        java.awt.Stroke stroke22 = xYBarRenderer18.lookupSeriesOutlineStroke(100);
        xYBarRenderer18.setShadowXOffset((double) 100.0f);
        java.awt.Stroke stroke25 = xYBarRenderer18.getBaseOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker(0.05d, paint17, stroke25);
        float float27 = valueMarker26.getAlpha();
        org.jfree.chart.util.Layer layer28 = null;
        boolean boolean29 = categoryPlot12.removeRangeMarker(100, (org.jfree.chart.plot.Marker) valueMarker26, layer28);
        boolean boolean30 = seriesRenderingOrder7.equals((java.lang.Object) boolean29);
        org.jfree.data.category.CategoryDataset categoryDataset31 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = null;
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset31, categoryAxis32, valueAxis33, categoryItemRenderer34);
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = categoryPlot35.getDomainAxisEdge();
        java.awt.Paint paint37 = categoryPlot35.getOutlinePaint();
        categoryPlot35.setBackgroundAlpha((float) 100L);
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        categoryPlot35.setRangeAxis(valueAxis40);
        java.awt.Paint paint42 = categoryPlot35.getBackgroundPaint();
        categoryPlot35.clearAnnotations();
        boolean boolean44 = seriesRenderingOrder7.equals((java.lang.Object) categoryPlot35);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(seriesRenderingOrder7);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + float27 + "' != '" + 1.0f + "'", float27 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation(100, axisLocation7);
        int int9 = categoryPlot4.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = categoryPlot4.getDomainAxisEdge();
        int int11 = categoryPlot4.getDatasetCount();
        org.jfree.chart.axis.AxisSpace axisSpace12 = categoryPlot4.getFixedRangeAxisSpace();
        org.jfree.data.category.CategoryDataset categoryDataset14 = categoryPlot4.getDataset(2958465);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNull(axisSpace12);
        org.junit.Assert.assertNull(categoryDataset14);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation(100, axisLocation7);
        int int9 = categoryPlot4.getWeight();
        java.awt.Paint paint10 = categoryPlot4.getRangeGridlinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier11 = null;
        categoryPlot4.setDrawingSupplier(drawingSupplier11, false);
        boolean boolean14 = categoryPlot4.isDomainZoomable();
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis17, categoryItemRenderer18);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = categoryPlot19.getDomainAxisEdge();
        java.awt.Paint paint21 = categoryPlot19.getOutlinePaint();
        java.awt.Paint paint24 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer25 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer25.clearSeriesStrokes(true);
        java.awt.Stroke stroke29 = xYBarRenderer25.lookupSeriesOutlineStroke(100);
        xYBarRenderer25.setShadowXOffset((double) 100.0f);
        java.awt.Stroke stroke32 = xYBarRenderer25.getBaseOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker(0.05d, paint24, stroke32);
        float float34 = valueMarker33.getAlpha();
        org.jfree.chart.util.Layer layer35 = null;
        boolean boolean36 = categoryPlot19.removeRangeMarker(100, (org.jfree.chart.plot.Marker) valueMarker33, layer35);
        categoryPlot4.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker33);
        boolean boolean38 = categoryPlot4.isRangeZeroBaselineVisible();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertTrue("'" + float34 + "' != '" + 1.0f + "'", float34 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.awt.Image image1 = projectInfo0.getLogo();
        projectInfo0.setLicenceName("hi!");
        java.awt.Font font5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot6 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        int int8 = combinedDomainXYPlot6.getDomainAxisIndex(valueAxis7);
        org.jfree.chart.axis.ValueAxis valueAxis9 = combinedDomainXYPlot6.getRangeAxis();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("WMAP_Plot", font5, (org.jfree.chart.plot.Plot) combinedDomainXYPlot6, true);
        boolean boolean12 = jFreeChart11.getAntiAlias();
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        textTitle14.setPadding(rectangleInsets15);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = textTitle14.getMargin();
        jFreeChart11.setPadding(rectangleInsets17);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo21 = null;
        java.awt.image.BufferedImage bufferedImage22 = jFreeChart11.createBufferedImage((int) (short) 1, 3, chartRenderingInfo21);
        projectInfo0.setLogo((java.awt.Image) bufferedImage22);
        org.junit.Assert.assertNull(image1);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(bufferedImage22);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.chart.renderer.xy.XYBarRenderer.setDefaultShadowsVisible(false);
    }

//    @Test
//    public void test014() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test014");
//        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
//        java.awt.Graphics2D graphics2D1 = null;
//        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot2 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
//        int int4 = combinedDomainXYPlot2.getDomainAxisIndex(valueAxis3);
//        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
//        int int6 = combinedDomainXYPlot2.getRangeAxisIndex(valueAxis5);
//        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
//        combinedDomainXYPlot2.setFixedRangeAxisSpace(axisSpace7, false);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date13 = spreadsheetDate12.toDate();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        long long16 = day15.getLastMillisecond();
//        org.jfree.chart.axis.PeriodAxis periodAxis17 = new org.jfree.chart.axis.PeriodAxis("$8.00", (org.jfree.data.time.RegularTimePeriod) day14, (org.jfree.data.time.RegularTimePeriod) day15);
//        java.lang.String str18 = periodAxis17.getLabelToolTip();
//        java.util.TimeZone timeZone19 = periodAxis17.getTimeZone();
//        java.awt.geom.Rectangle2D rectangle2D21 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge22 = null;
//        double double23 = periodAxis17.java2DToValue((double) 1900, rectangle2D21, rectangleEdge22);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date27 = spreadsheetDate26.toDate();
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date27);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        long long30 = day29.getLastMillisecond();
//        org.jfree.chart.axis.PeriodAxis periodAxis31 = new org.jfree.chart.axis.PeriodAxis("$8.00", (org.jfree.data.time.RegularTimePeriod) day28, (org.jfree.data.time.RegularTimePeriod) day29);
//        periodAxis17.setFirst((org.jfree.data.time.RegularTimePeriod) day28);
//        java.awt.geom.Rectangle2D rectangle2D33 = null;
//        java.awt.Paint paint35 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
//        java.awt.Stroke stroke36 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
//        try {
//            xYLineAndShapeRenderer0.drawRangeLine(graphics2D1, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot2, (org.jfree.chart.axis.ValueAxis) periodAxis17, rectangle2D33, (double) (-9999), paint35, stroke36);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560495599999L + "'", long16 == 1560495599999L);
//        org.junit.Assert.assertNull(str18);
//        org.junit.Assert.assertNotNull(timeZone19);
//        org.junit.Assert.assertTrue("'" + double23 + "' != '" + Double.POSITIVE_INFINITY + "'", double23 == Double.POSITIVE_INFINITY);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560495599999L + "'", long30 == 1560495599999L);
//        org.junit.Assert.assertNotNull(paint35);
//        org.junit.Assert.assertNotNull(stroke36);
//    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date5 = spreadsheetDate4.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date8 = spreadsheetDate7.toDate();
        boolean boolean9 = spreadsheetDate4.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate7);
        boolean boolean10 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date13 = spreadsheetDate12.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date16 = spreadsheetDate15.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date19 = spreadsheetDate18.toDate();
        boolean boolean20 = spreadsheetDate15.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate18);
        boolean boolean21 = spreadsheetDate12.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean25 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate12, (org.jfree.data.time.SerialDate) spreadsheetDate23, 0);
        try {
            org.jfree.data.time.SerialDate serialDate27 = spreadsheetDate12.getNearestDayOfWeek(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.data.Range range2 = xYStepRenderer0.findDomainBounds(xYDataset1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = null;
        xYStepRenderer0.setBaseToolTipGenerator(xYToolTipGenerator3);
        boolean boolean5 = xYStepRenderer0.getBaseShapesVisible();
        double double6 = xYStepRenderer0.getStepPoint();
        boolean boolean9 = xYStepRenderer0.getItemLineVisible((int) 'a', 15);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = xYStepRenderer0.getBaseNegativeItemLabelPosition();
        boolean boolean14 = xYStepRenderer0.getItemCreateEntity(0, 6, false);
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

//    @Test
//    public void test017() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test017");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date3 = spreadsheetDate2.toDate();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        long long6 = day5.getLastMillisecond();
//        org.jfree.chart.axis.PeriodAxis periodAxis7 = new org.jfree.chart.axis.PeriodAxis("$8.00", (org.jfree.data.time.RegularTimePeriod) day4, (org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.String str8 = periodAxis7.getLabelToolTip();
//        java.util.TimeZone timeZone9 = periodAxis7.getTimeZone();
//        java.awt.geom.Rectangle2D rectangle2D11 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
//        double double13 = periodAxis7.java2DToValue((double) 1900, rectangle2D11, rectangleEdge12);
//        periodAxis7.resizeRange(3.0d);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560495599999L + "'", long6 == 1560495599999L);
//        org.junit.Assert.assertNull(str8);
//        org.junit.Assert.assertNotNull(timeZone9);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + Double.POSITIVE_INFINITY + "'", double13 == Double.POSITIVE_INFINITY);
//    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot2 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = combinedDomainXYPlot2.getDomainAxisIndex(valueAxis3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = combinedDomainXYPlot2.getRangeAxis();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("WMAP_Plot", font1, (org.jfree.chart.plot.Plot) combinedDomainXYPlot2, true);
        boolean boolean8 = jFreeChart7.getAntiAlias();
        java.awt.Paint paint9 = jFreeChart7.getBorderPaint();
        java.awt.Image image10 = jFreeChart7.getBackgroundImage();
        jFreeChart7.setBackgroundImageAlpha((float) (-4126));
        org.jfree.chart.title.TextTitle textTitle13 = jFreeChart7.getTitle();
        org.jfree.chart.title.Title title15 = jFreeChart7.getSubtitle(0);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(image10);
        org.junit.Assert.assertNotNull(textTitle13);
        org.junit.Assert.assertNotNull(title15);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("NOID", "{0}: ({1}, {2})", "ClassContext", "null", "");
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation(100, axisLocation7);
        int int9 = categoryPlot4.getWeight();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = categoryPlot4.getRenderer();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation11 = null;
        try {
            boolean boolean12 = categoryPlot4.removeAnnotation(categoryAnnotation11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNull(categoryItemRenderer10);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset0.insertValue(0, (java.lang.Comparable) (-2208960000000L), (double) (byte) 10);
        org.jfree.data.xy.XYDataItem xYDataItem7 = new org.jfree.data.xy.XYDataItem(0.0d, (double) 1L);
        try {
            java.lang.Number number8 = defaultPieDataset0.getValue((java.lang.Comparable) 1L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Key not found: 1");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState1 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo0);
        java.awt.geom.Line2D line2D2 = xYItemRendererState1.workingLine;
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        int int8 = categoryPlot7.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation10 = null;
        categoryPlot7.setRangeAxisLocation(100, axisLocation10);
        int int12 = categoryPlot7.getWeight();
        java.awt.Paint paint13 = categoryPlot7.getRangeGridlinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier14 = null;
        categoryPlot7.setDrawingSupplier(drawingSupplier14, false);
        org.jfree.chart.entity.PlotEntity plotEntity17 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape) line2D2, (org.jfree.chart.plot.Plot) categoryPlot7);
        org.jfree.chart.plot.Plot plot18 = plotEntity17.getPlot();
        org.junit.Assert.assertNotNull(line2D2);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(plot18);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset) defaultPieDataset0);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = ringPlot1.getLegendLabelGenerator();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("TextBlockAnchor.TOP_RIGHT");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer6 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer6.clearSeriesStrokes(true);
        java.awt.Stroke stroke10 = xYBarRenderer6.lookupSeriesOutlineStroke(100);
        xYBarRenderer6.setShadowXOffset((double) 100.0f);
        java.awt.Stroke stroke13 = xYBarRenderer6.getBaseOutlineStroke();
        java.awt.Paint paint14 = xYBarRenderer6.getBasePaint();
        labelBlock5.setPaint(paint14);
        ringPlot1.setSectionOutlinePaint((java.lang.Comparable) 1.0E-5d, paint14);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator2);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot2 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = combinedDomainXYPlot2.getDomainAxisIndex(valueAxis3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = combinedDomainXYPlot2.getRangeAxis();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("WMAP_Plot", font1, (org.jfree.chart.plot.Plot) combinedDomainXYPlot2, true);
        boolean boolean8 = jFreeChart7.getAntiAlias();
        java.awt.Paint paint9 = jFreeChart7.getBorderPaint();
        java.awt.Image image10 = jFreeChart7.getBackgroundImage();
        jFreeChart7.setBackgroundImageAlpha((float) (-4126));
        org.jfree.chart.title.TextTitle textTitle13 = jFreeChart7.getTitle();
        org.jfree.chart.event.ChartProgressListener chartProgressListener14 = null;
        jFreeChart7.addProgressListener(chartProgressListener14);
        int int16 = jFreeChart7.getBackgroundImageAlignment();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(image10);
        org.junit.Assert.assertNotNull(textTitle13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 15 + "'", int16 == 15);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.CLOCKWISE;
        org.junit.Assert.assertNotNull(rotation0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation(100, axisLocation7);
        int int9 = categoryPlot4.getWeight();
        java.awt.Paint paint10 = categoryPlot4.getRangeGridlinePaint();
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.data.Range range12 = categoryPlot4.getDataRange(valueAxis11);
        java.awt.Stroke stroke13 = categoryPlot4.getRangeMinorGridlineStroke();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D16 = new org.jfree.chart.axis.CategoryAxis3D("ERROR : Relative To String");
        categoryAxis3D16.clearCategoryLabelToolTips();
        categoryPlot4.setDomainAxis((int) '#', (org.jfree.chart.axis.CategoryAxis) categoryAxis3D16, false);
        java.awt.Font font20 = categoryAxis3D16.getLabelFont();
        categoryAxis3D16.setLabelToolTip("null");
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(font20);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        int int2 = combinedDomainXYPlot0.getDomainAxisIndex(valueAxis1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = combinedDomainXYPlot0.getRangeAxisIndex(valueAxis3);
        java.awt.Paint paint5 = combinedDomainXYPlot0.getDomainZeroBaselinePaint();
        java.awt.Paint paint7 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer8 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer8.clearSeriesStrokes(true);
        java.awt.Stroke stroke12 = xYBarRenderer8.lookupSeriesOutlineStroke(100);
        xYBarRenderer8.setShadowXOffset((double) 100.0f);
        java.awt.Stroke stroke15 = xYBarRenderer8.getBaseOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker(0.05d, paint7, stroke15);
        java.awt.Paint paint17 = valueMarker16.getPaint();
        java.awt.Paint paint18 = null;
        valueMarker16.setOutlinePaint(paint18);
        boolean boolean20 = combinedDomainXYPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker16);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer0.setBaseLinesVisible(true);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator4 = xYStepRenderer0.getSeriesItemLabelGenerator((int) '#');
        boolean boolean5 = xYStepRenderer0.getAutoPopulateSeriesShape();
        java.awt.Paint paint7 = xYStepRenderer0.lookupSeriesPaint((int) (byte) 10);
        xYStepRenderer0.setUseOutlinePaint(true);
        org.junit.Assert.assertNull(xYItemLabelGenerator4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.data.Range range2 = xYStepRenderer0.findDomainBounds(xYDataset1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = null;
        xYStepRenderer0.setBaseToolTipGenerator(xYToolTipGenerator3);
        boolean boolean5 = xYStepRenderer0.getBaseShapesVisible();
        double double6 = xYStepRenderer0.getStepPoint();
        boolean boolean9 = xYStepRenderer0.getItemLineVisible((int) 'a', 15);
        try {
            xYStepRenderer0.setSeriesItemLabelsVisible((-4126), (java.lang.Boolean) false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getCurrencyInstance();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit((double) 100L, numberFormat1);
        java.lang.String str4 = numberFormat1.format((long) 8);
        boolean boolean5 = numberFormat1.isGroupingUsed();
        int int6 = numberFormat1.getMaximumFractionDigits();
        try {
            java.lang.Number number8 = numberFormat1.parse("{0}");
            org.junit.Assert.fail("Expected exception of type java.text.ParseException; message: Unparseable number: \"{0}\"");
        } catch (java.text.ParseException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "$8.00" + "'", str4.equals("$8.00"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        java.awt.Shape shape4 = null;
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, valueAxis7, categoryItemRenderer8);
        int int10 = categoryPlot9.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation12 = null;
        categoryPlot9.setRangeAxisLocation(100, axisLocation12);
        int int14 = categoryPlot9.getWeight();
        java.awt.Paint paint15 = categoryPlot9.getRangeGridlinePaint();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer16 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer16.clearSeriesStrokes(true);
        java.awt.Stroke stroke20 = xYBarRenderer16.lookupSeriesOutlineStroke(100);
        xYBarRenderer16.setShadowXOffset((double) 100.0f);
        java.awt.Stroke stroke23 = xYBarRenderer16.getBaseOutlineStroke();
        java.awt.Paint paint24 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("", "TextBlockAnchor.TOP_RIGHT", "{0}: ({1}, {2})", "", shape4, paint15, stroke23, paint24);
        java.awt.Color color26 = java.awt.Color.lightGray;
        legendItem25.setLabelPaint((java.awt.Paint) color26);
        java.awt.Paint paint28 = legendItem25.getLinePaint();
        legendItem25.setLineVisible(false);
        java.awt.Shape shape31 = legendItem25.getShape();
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNull(shape31);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getCurrencyInstance();
        boolean boolean1 = numberFormat0.isParseIntegerOnly();
        java.lang.String str3 = numberFormat0.format((double) (-1L));
        numberFormat0.setMaximumIntegerDigits((int) ' ');
        int int6 = numberFormat0.getMinimumIntegerDigits();
        org.junit.Assert.assertNotNull(numberFormat0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "($1.00)" + "'", str3.equals("($1.00)"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset0.insertValue(0, (java.lang.Comparable) (-2208960000000L), (double) (byte) 10);
        org.jfree.chart.util.SortOrder sortOrder5 = null;
        try {
            defaultPieDataset0.sortByKeys(sortOrder5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (short) -1, 0.0d, (double) (short) -1, (double) (byte) 10);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D6 = rectangleInsets4.createOutsetRectangle(rectangle2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test036() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test036");
//        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
//        org.jfree.data.xy.XYDataset xYDataset1 = null;
//        org.jfree.data.Range range2 = xYStepRenderer0.findDomainBounds(xYDataset1);
//        java.awt.Color color5 = org.jfree.chart.util.PaintUtilities.stringToColor("ERROR : Relative To String");
//        xYStepRenderer0.setSeriesOutlinePaint(1, (java.awt.Paint) color5);
//        java.awt.Graphics2D graphics2D7 = null;
//        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("hi!");
//        textTitle9.setMaximumLinesToDisplay(1);
//        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, categoryItemRenderer15);
//        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot16.getDomainAxisEdge();
//        textTitle9.setPosition(rectangleEdge17);
//        org.jfree.chart.util.HorizontalAlignment horizontalAlignment19 = textTitle9.getTextAlignment();
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
//        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState21 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo20);
//        int int22 = xYItemRendererState21.getFirstItemIndex();
//        boolean boolean23 = horizontalAlignment19.equals((java.lang.Object) xYItemRendererState21);
//        java.awt.geom.Rectangle2D rectangle2D24 = null;
//        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot25 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
//        int int27 = combinedDomainXYPlot25.getDomainAxisIndex(valueAxis26);
//        combinedDomainXYPlot25.setRangeCrosshairLockedOnData(false);
//        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
//        int int31 = combinedDomainXYPlot25.getRangeAxisIndex(valueAxis30);
//        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot32 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
//        int int34 = combinedDomainXYPlot32.getDomainAxisIndex(valueAxis33);
//        org.jfree.chart.axis.ValueAxis valueAxis35 = combinedDomainXYPlot32.getRangeAxis();
//        boolean boolean36 = combinedDomainXYPlot32.isSubplot();
//        combinedDomainXYPlot32.setRangeMinorGridlinesVisible(false);
//        boolean boolean39 = combinedDomainXYPlot32.isDomainZeroBaselineVisible();
//        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
//        combinedDomainXYPlot32.setRangeAxis((int) 'a', valueAxis41);
//        double double43 = combinedDomainXYPlot32.getRangeCrosshairValue();
//        combinedDomainXYPlot25.remove((org.jfree.chart.plot.XYPlot) combinedDomainXYPlot32);
//        org.jfree.chart.axis.NumberAxis numberAxis46 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=0,g=255,b=0]");
//        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer47 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//        xYBarRenderer47.clearSeriesStrokes(true);
//        java.awt.Stroke stroke51 = xYBarRenderer47.lookupSeriesOutlineStroke(100);
//        xYBarRenderer47.setShadowXOffset((double) 100.0f);
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo55 = null;
//        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState56 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo55);
//        java.awt.geom.Line2D line2D57 = xYItemRendererState56.workingLine;
//        xYBarRenderer47.setLegendShape(0, (java.awt.Shape) line2D57);
//        numberAxis46.setRightArrow((java.awt.Shape) line2D57);
//        org.jfree.chart.axis.TickUnitSource tickUnitSource60 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
//        numberAxis46.setStandardTickUnits(tickUnitSource60);
//        boolean boolean62 = numberAxis46.isVerticalTickLabels();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate65 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date66 = spreadsheetDate65.toDate();
//        org.jfree.data.time.Day day67 = new org.jfree.data.time.Day(date66);
//        org.jfree.data.time.Day day68 = new org.jfree.data.time.Day();
//        long long69 = day68.getLastMillisecond();
//        org.jfree.chart.axis.PeriodAxis periodAxis70 = new org.jfree.chart.axis.PeriodAxis("$8.00", (org.jfree.data.time.RegularTimePeriod) day67, (org.jfree.data.time.RegularTimePeriod) day68);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate72 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date73 = spreadsheetDate72.toDate();
//        java.util.Date date74 = spreadsheetDate72.toDate();
//        java.util.TimeZone timeZone75 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month76 = new org.jfree.data.time.Month(date74, timeZone75);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = month76.previous();
//        periodAxis70.setFirst((org.jfree.data.time.RegularTimePeriod) month76);
//        periodAxis70.setMinorTickMarkInsideLength((float) (-2208960000000L));
//        org.jfree.data.time.TimeSeries timeSeries81 = null;
//        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection82 = new org.jfree.data.time.TimeSeriesCollection(timeSeries81);
//        org.jfree.data.Range range84 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection82, false);
//        java.lang.Object obj85 = timeSeriesCollection82.clone();
//        boolean boolean86 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection82);
//        try {
//            xYStepRenderer0.drawItem(graphics2D7, xYItemRendererState21, rectangle2D24, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot32, (org.jfree.chart.axis.ValueAxis) numberAxis46, (org.jfree.chart.axis.ValueAxis) periodAxis70, (org.jfree.data.xy.XYDataset) timeSeriesCollection82, 6, 0, false, 6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(range2);
//        org.junit.Assert.assertNotNull(color5);
//        org.junit.Assert.assertNotNull(rectangleEdge17);
//        org.junit.Assert.assertNotNull(horizontalAlignment19);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
//        org.junit.Assert.assertNull(valueAxis35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
//        org.junit.Assert.assertNotNull(stroke51);
//        org.junit.Assert.assertNotNull(line2D57);
//        org.junit.Assert.assertNotNull(tickUnitSource60);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertNotNull(date66);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 1560495599999L + "'", long69 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date73);
//        org.junit.Assert.assertNotNull(date74);
//        org.junit.Assert.assertNotNull(timeZone75);
//        org.junit.Assert.assertNull(regularTimePeriod77);
//        org.junit.Assert.assertNull(range84);
//        org.junit.Assert.assertNotNull(obj85);
//        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + true + "'", boolean86 == true);
//    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.data.general.DatasetGroup datasetGroup2 = timeSeriesCollection1.getGroup();
        org.jfree.data.general.DatasetGroup datasetGroup3 = timeSeriesCollection1.getGroup();
        try {
            int int5 = timeSeriesCollection1.getItemCount((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(datasetGroup2);
        org.junit.Assert.assertNotNull(datasetGroup3);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=0,g=255,b=0]");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer2 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer2.clearSeriesStrokes(true);
        java.awt.Stroke stroke6 = xYBarRenderer2.lookupSeriesOutlineStroke(100);
        xYBarRenderer2.setShadowXOffset((double) 100.0f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState11 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo10);
        java.awt.geom.Line2D line2D12 = xYItemRendererState11.workingLine;
        xYBarRenderer2.setLegendShape(0, (java.awt.Shape) line2D12);
        numberAxis1.setRightArrow((java.awt.Shape) line2D12);
        numberAxis1.setMinorTickMarksVisible(true);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot17 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        int int19 = combinedDomainXYPlot17.getDomainAxisIndex(valueAxis18);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        int int21 = combinedDomainXYPlot17.getRangeAxisIndex(valueAxis20);
        java.awt.Paint paint22 = combinedDomainXYPlot17.getDomainZeroBaselinePaint();
        boolean boolean23 = combinedDomainXYPlot17.isDomainZeroBaselineVisible();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder24 = combinedDomainXYPlot17.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation25 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        combinedDomainXYPlot17.setRangeAxisLocation(axisLocation25, true);
        numberAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) combinedDomainXYPlot17);
        org.jfree.chart.axis.AxisSpace axisSpace29 = null;
        combinedDomainXYPlot17.setFixedRangeAxisSpace(axisSpace29, false);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(line2D12);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(seriesRenderingOrder24);
        org.junit.Assert.assertNotNull(axisLocation25);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "org.jfree.data.UnknownKeyException: TextBlockAnchor.TOP_RIGHT", "ItemLabelAnchor.INSIDE7", "DomainOrder.NONE");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = null;
        try {
            timeSeries3.add(timeSeriesDataItem4, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection1, true);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate5 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection1, false);
        org.junit.Assert.assertNull(range3);
    }

//    @Test
//    public void test041() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test041");
//        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
//        int int5 = categoryPlot4.getDomainAxisCount();
//        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
//        categoryPlot4.setRangeAxisLocation(100, axisLocation7);
//        int int9 = categoryPlot4.getWeight();
//        java.awt.Paint paint10 = categoryPlot4.getRangeGridlinePaint();
//        org.jfree.chart.plot.DrawingSupplier drawingSupplier11 = null;
//        categoryPlot4.setDrawingSupplier(drawingSupplier11, false);
//        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot14 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
//        int int16 = combinedDomainXYPlot14.getDomainAxisIndex(valueAxis15);
//        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
//        int int18 = combinedDomainXYPlot14.getRangeAxisIndex(valueAxis17);
//        java.awt.Paint paint19 = combinedDomainXYPlot14.getDomainZeroBaselinePaint();
//        java.awt.Stroke stroke20 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
//        combinedDomainXYPlot14.setRangeZeroBaselineStroke(stroke20);
//        org.jfree.data.xy.XYDataset xYDataset22 = null;
//        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = combinedDomainXYPlot14.getRendererForDataset(xYDataset22);
//        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=0,g=255,b=0]");
//        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer26 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//        xYBarRenderer26.clearSeriesStrokes(true);
//        java.awt.Stroke stroke30 = xYBarRenderer26.lookupSeriesOutlineStroke(100);
//        xYBarRenderer26.setShadowXOffset((double) 100.0f);
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
//        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState35 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo34);
//        java.awt.geom.Line2D line2D36 = xYItemRendererState35.workingLine;
//        xYBarRenderer26.setLegendShape(0, (java.awt.Shape) line2D36);
//        numberAxis25.setRightArrow((java.awt.Shape) line2D36);
//        org.jfree.chart.axis.TickUnitSource tickUnitSource39 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
//        numberAxis25.setStandardTickUnits(tickUnitSource39);
//        java.text.NumberFormat numberFormat42 = java.text.NumberFormat.getCurrencyInstance();
//        org.jfree.chart.axis.NumberTickUnit numberTickUnit43 = new org.jfree.chart.axis.NumberTickUnit((double) 100L, numberFormat42);
//        numberAxis25.setTickUnit(numberTickUnit43, true, false);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date50 = spreadsheetDate49.toDate();
//        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date50);
//        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day();
//        long long53 = day52.getLastMillisecond();
//        org.jfree.chart.axis.PeriodAxis periodAxis54 = new org.jfree.chart.axis.PeriodAxis("$8.00", (org.jfree.data.time.RegularTimePeriod) day51, (org.jfree.data.time.RegularTimePeriod) day52);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate57 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date58 = spreadsheetDate57.toDate();
//        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day(date58);
//        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day();
//        long long61 = day60.getLastMillisecond();
//        org.jfree.chart.axis.PeriodAxis periodAxis62 = new org.jfree.chart.axis.PeriodAxis("$8.00", (org.jfree.data.time.RegularTimePeriod) day59, (org.jfree.data.time.RegularTimePeriod) day60);
//        org.jfree.chart.axis.ValueAxis[] valueAxisArray63 = new org.jfree.chart.axis.ValueAxis[] { numberAxis25, periodAxis54, periodAxis62 };
//        combinedDomainXYPlot14.setRangeAxes(valueAxisArray63);
//        categoryPlot4.setRangeAxes(valueAxisArray63);
//        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem68 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day66, (java.lang.Number) 255);
//        categoryPlot4.setDomainCrosshairRowKey((java.lang.Comparable) 255);
//        categoryPlot4.zoom((double) 9999);
//        categoryPlot4.setNotify(false);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertNotNull(paint10);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(paint19);
//        org.junit.Assert.assertNotNull(stroke20);
//        org.junit.Assert.assertNull(xYItemRenderer23);
//        org.junit.Assert.assertNotNull(stroke30);
//        org.junit.Assert.assertNotNull(line2D36);
//        org.junit.Assert.assertNotNull(tickUnitSource39);
//        org.junit.Assert.assertNotNull(numberFormat42);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 1560495599999L + "'", long53 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 1560495599999L + "'", long61 == 1560495599999L);
//        org.junit.Assert.assertNotNull(valueAxisArray63);
//    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.chart.renderer.PaintScale paintScale0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        try {
            org.jfree.chart.title.PaintScaleLegend paintScaleLegend2 = new org.jfree.chart.title.PaintScaleLegend(paintScale0, valueAxis1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot4.getDomainAxis();
        categoryPlot4.clearDomainMarkers();
        org.junit.Assert.assertNull(categoryAxis5);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        int int2 = combinedDomainXYPlot0.getDomainAxisIndex(valueAxis1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = combinedDomainXYPlot0.getRangeAxis();
        boolean boolean4 = combinedDomainXYPlot0.isSubplot();
        combinedDomainXYPlot0.setRangeMinorGridlinesVisible(false);
        boolean boolean7 = combinedDomainXYPlot0.isDomainZeroBaselineVisible();
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        combinedDomainXYPlot0.setRangeAxis((int) 'a', valueAxis9);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.awt.geom.Point2D point2D13 = null;
        org.jfree.chart.plot.PlotState plotState14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        try {
            combinedDomainXYPlot0.draw(graphics2D11, rectangle2D12, point2D13, plotState14, plotRenderingInfo15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        java.awt.Shape shape4 = null;
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, valueAxis7, categoryItemRenderer8);
        int int10 = categoryPlot9.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation12 = null;
        categoryPlot9.setRangeAxisLocation(100, axisLocation12);
        int int14 = categoryPlot9.getWeight();
        java.awt.Paint paint15 = categoryPlot9.getRangeGridlinePaint();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer16 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer16.clearSeriesStrokes(true);
        java.awt.Stroke stroke20 = xYBarRenderer16.lookupSeriesOutlineStroke(100);
        xYBarRenderer16.setShadowXOffset((double) 100.0f);
        java.awt.Stroke stroke23 = xYBarRenderer16.getBaseOutlineStroke();
        java.awt.Paint paint24 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("", "TextBlockAnchor.TOP_RIGHT", "{0}: ({1}, {2})", "", shape4, paint15, stroke23, paint24);
        java.awt.Color color26 = java.awt.Color.lightGray;
        legendItem25.setLabelPaint((java.awt.Paint) color26);
        java.awt.Paint paint28 = legendItem25.getLinePaint();
        legendItem25.setLineVisible(false);
        java.text.AttributedString attributedString31 = legendItem25.getAttributedLabel();
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNull(attributedString31);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset) defaultPieDataset0);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = ringPlot1.getLegendLabelGenerator();
        ringPlot1.setIgnoreNullValues(false);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator2);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = categoryPlot4.getDomainAxisEdge();
        java.awt.Paint paint6 = categoryPlot4.getOutlinePaint();
        categoryPlot4.setBackgroundAlpha((float) 100L);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot4.setRangeAxis(valueAxis9);
        java.awt.Paint paint11 = categoryPlot4.getBackgroundPaint();
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = null;
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, categoryItemRenderer16);
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        categoryPlot17.setDataset(categoryDataset18);
        boolean boolean20 = categoryPlot17.isSubplot();
        java.awt.Paint paint22 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer23 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer23.clearSeriesStrokes(true);
        java.awt.Stroke stroke27 = xYBarRenderer23.lookupSeriesOutlineStroke(100);
        xYBarRenderer23.setShadowXOffset((double) 100.0f);
        java.awt.Stroke stroke30 = xYBarRenderer23.getBaseOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker31 = new org.jfree.chart.plot.ValueMarker(0.05d, paint22, stroke30);
        org.jfree.chart.text.TextAnchor textAnchor32 = valueMarker31.getLabelTextAnchor();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot33 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        int int35 = combinedDomainXYPlot33.getDomainAxisIndex(valueAxis34);
        org.jfree.chart.axis.ValueAxis valueAxis36 = combinedDomainXYPlot33.getRangeAxis();
        org.jfree.data.category.CategoryDataset categoryDataset37 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = null;
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer40 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot(categoryDataset37, categoryAxis38, valueAxis39, categoryItemRenderer40);
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = categoryPlot41.getDomainAxisEdge();
        java.awt.Paint paint43 = categoryPlot41.getOutlinePaint();
        java.awt.Paint paint46 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer47 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer47.clearSeriesStrokes(true);
        java.awt.Stroke stroke51 = xYBarRenderer47.lookupSeriesOutlineStroke(100);
        xYBarRenderer47.setShadowXOffset((double) 100.0f);
        java.awt.Stroke stroke54 = xYBarRenderer47.getBaseOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker55 = new org.jfree.chart.plot.ValueMarker(0.05d, paint46, stroke54);
        float float56 = valueMarker55.getAlpha();
        org.jfree.chart.util.Layer layer57 = null;
        boolean boolean58 = categoryPlot41.removeRangeMarker(100, (org.jfree.chart.plot.Marker) valueMarker55, layer57);
        org.jfree.chart.text.TextAnchor textAnchor59 = valueMarker55.getLabelTextAnchor();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot60 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis61 = null;
        int int62 = combinedDomainXYPlot60.getDomainAxisIndex(valueAxis61);
        org.jfree.chart.axis.ValueAxis valueAxis63 = null;
        int int64 = combinedDomainXYPlot60.getRangeAxisIndex(valueAxis63);
        java.awt.Paint paint65 = combinedDomainXYPlot60.getDomainZeroBaselinePaint();
        boolean boolean66 = combinedDomainXYPlot60.isDomainZeroBaselineVisible();
        org.jfree.chart.util.Layer layer67 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection68 = combinedDomainXYPlot60.getRangeMarkers(layer67);
        combinedDomainXYPlot33.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker55, layer67);
        boolean boolean70 = categoryPlot17.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker31, layer67);
        try {
            categoryPlot4.addDomainMarker(categoryMarker12, layer67);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(textAnchor32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertNull(valueAxis36);
        org.junit.Assert.assertNotNull(rectangleEdge42);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertTrue("'" + float56 + "' != '" + 1.0f + "'", float56 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(textAnchor59);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-1) + "'", int62 == (-1));
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
        org.junit.Assert.assertNotNull(paint65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(layer67);
        org.junit.Assert.assertNull(collection68);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Paint paint2 = null;
        try {
            org.jfree.chart.block.LabelBlock labelBlock3 = new org.jfree.chart.block.LabelBlock("hi!", font1, paint2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation(100, axisLocation7);
        int int9 = categoryPlot4.getWeight();
        java.awt.Paint paint10 = categoryPlot4.getRangeGridlinePaint();
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.data.Range range12 = categoryPlot4.getDataRange(valueAxis11);
        java.awt.Stroke stroke13 = categoryPlot4.getRangeMinorGridlineStroke();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D16 = new org.jfree.chart.axis.CategoryAxis3D("ERROR : Relative To String");
        categoryAxis3D16.clearCategoryLabelToolTips();
        categoryPlot4.setDomainAxis((int) '#', (org.jfree.chart.axis.CategoryAxis) categoryAxis3D16, false);
        java.awt.Font font20 = categoryAxis3D16.getLabelFont();
        float float21 = categoryAxis3D16.getTickMarkOutsideLength();
        java.lang.String str22 = categoryAxis3D16.getLabelToolTip();
        categoryAxis3D16.setLabelToolTip("LengthConstraintType.FIXED");
        categoryAxis3D16.clearCategoryLabelToolTips();
        float float26 = categoryAxis3D16.getTickMarkOutsideLength();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 2.0f + "'", float21 == 2.0f);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 2.0f + "'", float26 == 2.0f);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE1;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date5 = spreadsheetDate4.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date8 = spreadsheetDate7.toDate();
        boolean boolean9 = spreadsheetDate4.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate7);
        boolean boolean10 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date13 = spreadsheetDate12.toDate();
        java.util.Date date14 = spreadsheetDate12.toDate();
        boolean boolean15 = spreadsheetDate7.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=0,g=255,b=0]");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer2 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer2.clearSeriesStrokes(true);
        java.awt.Stroke stroke6 = xYBarRenderer2.lookupSeriesOutlineStroke(100);
        xYBarRenderer2.setShadowXOffset((double) 100.0f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState11 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo10);
        java.awt.geom.Line2D line2D12 = xYItemRendererState11.workingLine;
        xYBarRenderer2.setLegendShape(0, (java.awt.Shape) line2D12);
        numberAxis1.setRightArrow((java.awt.Shape) line2D12);
        numberAxis1.setMinorTickMarksVisible(true);
        double double17 = numberAxis1.getFixedAutoRange();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(line2D12);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.data.Range range4 = xYStepRenderer2.findDomainBounds(xYDataset3);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator5 = null;
        xYStepRenderer2.setBaseToolTipGenerator(xYToolTipGenerator5);
        boolean boolean7 = xYStepRenderer2.getBaseShapesVisible();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator8 = null;
        xYStepRenderer2.setBaseToolTipGenerator(xYToolTipGenerator8, true);
        java.awt.Color color12 = java.awt.Color.lightGray;
        xYStepRenderer2.setSeriesFillPaint((int) '#', (java.awt.Paint) color12);
        boolean boolean14 = timeSeriesCollection1.equals((java.lang.Object) xYStepRenderer2);
        xYStepRenderer2.setSeriesShapesFilled(5, (java.lang.Boolean) false);
        boolean boolean21 = xYStepRenderer2.getItemCreateEntity(6, 0, false);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.Paint paint5 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer6 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer6.clearSeriesStrokes(true);
        java.awt.Stroke stroke10 = xYBarRenderer6.lookupSeriesOutlineStroke(100);
        xYBarRenderer6.setShadowXOffset((double) 100.0f);
        java.awt.Stroke stroke13 = xYBarRenderer6.getBaseOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker(0.05d, paint5, stroke13);
        java.awt.Paint paint15 = valueMarker14.getPaint();
        java.awt.Paint paint16 = null;
        valueMarker14.setOutlinePaint(paint16);
        org.jfree.chart.text.TextAnchor textAnchor18 = valueMarker14.getLabelTextAnchor();
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("java.awt.Color[r=0,g=255,b=0]", graphics2D1, (float) 100, (float) (-458), textAnchor18, (double) 2958465, (float) 8, (float) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(textAnchor18);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=0,g=255,b=0]");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer2 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer2.clearSeriesStrokes(true);
        java.awt.Stroke stroke6 = xYBarRenderer2.lookupSeriesOutlineStroke(100);
        xYBarRenderer2.setShadowXOffset((double) 100.0f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState11 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo10);
        java.awt.geom.Line2D line2D12 = xYItemRendererState11.workingLine;
        xYBarRenderer2.setLegendShape(0, (java.awt.Shape) line2D12);
        numberAxis1.setRightArrow((java.awt.Shape) line2D12);
        org.jfree.chart.axis.TickUnitSource tickUnitSource15 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        numberAxis1.setStandardTickUnits(tickUnitSource15);
        boolean boolean17 = numberAxis1.isVerticalTickLabels();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand18 = null;
        numberAxis1.setMarkerBand(markerAxisBand18);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(line2D12);
        org.junit.Assert.assertNotNull(tickUnitSource15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.data.general.DatasetGroup datasetGroup2 = timeSeriesCollection1.getGroup();
        org.jfree.data.general.DatasetGroup datasetGroup3 = new org.jfree.data.general.DatasetGroup();
        timeSeriesCollection1.setGroup(datasetGroup3);
        java.lang.Object obj5 = datasetGroup3.clone();
        org.junit.Assert.assertNotNull(datasetGroup2);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle1.setMaximumLinesToDisplay(1);
        double double4 = textTitle1.getHeight();
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        textTitle1.setFont(font5);
        java.lang.String str7 = textTitle1.getText();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
    }

//    @Test
//    public void test059() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test059");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date3 = spreadsheetDate2.toDate();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        long long6 = day5.getLastMillisecond();
//        org.jfree.chart.axis.PeriodAxis periodAxis7 = new org.jfree.chart.axis.PeriodAxis("$8.00", (org.jfree.data.time.RegularTimePeriod) day4, (org.jfree.data.time.RegularTimePeriod) day5);
//        double double8 = periodAxis7.getLabelAngle();
//        float float9 = periodAxis7.getTickMarkInsideLength();
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560495599999L + "'", long6 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
//        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.0f + "'", float9 == 0.0f);
//    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection1, false);
        java.lang.Object obj4 = timeSeriesCollection1.clone();
        boolean boolean5 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        timeSeriesCollection1.clearSelection();
        try {
            double double9 = timeSeriesCollection1.getXValue((-4126), (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset) defaultPieDataset0);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator2 = null;
        ringPlot1.setURLGenerator(pieURLGenerator2);
        double double4 = ringPlot1.getInteriorGap();
        double double5 = ringPlot1.getStartAngle();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, valueAxis8, categoryItemRenderer9);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot10.getDomainAxisEdge();
        boolean boolean12 = categoryPlot10.isRangeGridlinesVisible();
        java.lang.Comparable comparable13 = categoryPlot10.getDomainCrosshairColumnKey();
        java.awt.Paint paint14 = categoryPlot10.getDomainCrosshairPaint();
        ringPlot1.setBaseSectionOutlinePaint(paint14);
        boolean boolean16 = ringPlot1.getSeparatorsVisible();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.08d + "'", double4 == 0.08d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 90.0d + "'", double5 == 90.0d);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(comparable13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

//    @Test
//    public void test062() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test062");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date4 = spreadsheetDate3.toDate();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        long long7 = day6.getLastMillisecond();
//        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("$8.00", (org.jfree.data.time.RegularTimePeriod) day5, (org.jfree.data.time.RegularTimePeriod) day6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date11 = spreadsheetDate10.toDate();
//        java.util.Date date12 = spreadsheetDate10.toDate();
//        java.util.TimeZone timeZone13 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date12, timeZone13);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month14.previous();
//        periodAxis8.setFirst((org.jfree.data.time.RegularTimePeriod) month14);
//        java.util.Locale locale17 = periodAxis8.getLocale();
//        try {
//            java.util.ResourceBundle resourceBundle18 = java.util.ResourceBundle.getBundle("ERROR : Relative To String", locale17);
//            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name ERROR : Relative To String, locale en_US");
//        } catch (java.util.MissingResourceException e) {
//        }
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560495599999L + "'", long7 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(timeZone13);
//        org.junit.Assert.assertNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(locale17);
//    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = categoryPlot4.getDomainAxisEdge();
        java.awt.Paint paint6 = categoryPlot4.getOutlinePaint();
        categoryPlot4.setRangeZeroBaselineVisible(false);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, valueAxis12, categoryItemRenderer13);
        int int15 = categoryPlot14.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation17 = null;
        categoryPlot14.setRangeAxisLocation(100, axisLocation17);
        int int19 = categoryPlot14.getWeight();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        int int21 = categoryPlot14.getIndexOf(categoryItemRenderer20);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot22 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot23 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        int int25 = combinedDomainXYPlot23.getDomainAxisIndex(valueAxis24);
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        int int27 = combinedDomainXYPlot23.getRangeAxisIndex(valueAxis26);
        java.awt.Paint paint28 = combinedDomainXYPlot23.getDomainZeroBaselinePaint();
        java.awt.Stroke stroke29 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        combinedDomainXYPlot23.setRangeZeroBaselineStroke(stroke29);
        org.jfree.data.xy.XYDataset xYDataset31 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = combinedDomainXYPlot23.getRendererForDataset(xYDataset31);
        org.jfree.chart.axis.AxisLocation axisLocation34 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        combinedDomainXYPlot23.setRangeAxisLocation(0, axisLocation34);
        combinedDomainXYPlot22.setRangeAxisLocation(axisLocation34, true);
        org.jfree.data.category.CategoryDataset categoryDataset38 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = null;
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer41 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot(categoryDataset38, categoryAxis39, valueAxis40, categoryItemRenderer41);
        int int43 = categoryPlot42.getDomainAxisCount();
        java.awt.Color color44 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        categoryPlot42.setRangeZeroBaselinePaint((java.awt.Paint) color44);
        java.awt.Paint paint46 = categoryPlot42.getDomainCrosshairPaint();
        boolean boolean47 = axisLocation34.equals((java.lang.Object) paint46);
        categoryPlot14.setRangeAxisLocation(axisLocation34);
        categoryPlot4.setRangeAxisLocation((int) ' ', axisLocation34);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNull(xYItemRenderer32);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=0,g=255,b=0]");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer2 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer2.clearSeriesStrokes(true);
        java.awt.Stroke stroke6 = xYBarRenderer2.lookupSeriesOutlineStroke(100);
        xYBarRenderer2.setShadowXOffset((double) 100.0f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState11 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo10);
        java.awt.geom.Line2D line2D12 = xYItemRendererState11.workingLine;
        xYBarRenderer2.setLegendShape(0, (java.awt.Shape) line2D12);
        numberAxis1.setRightArrow((java.awt.Shape) line2D12);
        org.jfree.chart.axis.TickUnitSource tickUnitSource15 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        numberAxis1.setStandardTickUnits(tickUnitSource15);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range18 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range19 = org.jfree.data.Range.combine(range17, range18);
        numberAxis1.setRange(range17, true, false);
        boolean boolean23 = numberAxis1.isInverted();
        boolean boolean24 = numberAxis1.isVerticalTickLabels();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(line2D12);
        org.junit.Assert.assertNotNull(tickUnitSource15);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        java.awt.Paint paint1 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer2 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer2.clearSeriesStrokes(true);
        java.awt.Stroke stroke6 = xYBarRenderer2.lookupSeriesOutlineStroke(100);
        xYBarRenderer2.setShadowXOffset((double) 100.0f);
        java.awt.Stroke stroke9 = xYBarRenderer2.getBaseOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.05d, paint1, stroke9);
        float float11 = valueMarker10.getAlpha();
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, categoryItemRenderer15);
        int int17 = categoryPlot16.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation19 = null;
        categoryPlot16.setRangeAxisLocation(100, axisLocation19);
        int int21 = categoryPlot16.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = categoryPlot16.getDomainAxisEdge();
        valueMarker10.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot16);
        valueMarker10.setValue((double) 100.0f);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 1.0f + "'", float11 == 1.0f);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge22);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isRadiusGridlinesVisible();
        int int2 = polarPlot0.getSeriesCount();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation(100, axisLocation7);
        int int9 = categoryPlot4.getWeight();
        java.awt.Paint paint10 = categoryPlot4.getRangeGridlinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier11 = null;
        categoryPlot4.setDrawingSupplier(drawingSupplier11, false);
        boolean boolean14 = categoryPlot4.isSubplot();
        categoryPlot4.setRangeZeroBaselineVisible(true);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder17 = categoryPlot4.getDatasetRenderingOrder();
        categoryPlot4.clearDomainAxes();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder17);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        int int2 = combinedDomainXYPlot0.getDomainAxisIndex(valueAxis1);
        org.jfree.chart.axis.AxisLocation axisLocation4 = null;
        combinedDomainXYPlot0.setDomainAxisLocation((int) (byte) 1, axisLocation4);
        combinedDomainXYPlot0.setRangePannable(false);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation(100, axisLocation7);
        java.lang.String str9 = categoryPlot4.getNoDataMessage();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder10 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot4.setDatasetRenderingOrder(datasetRenderingOrder10);
        java.awt.Color color12 = java.awt.Color.pink;
        categoryPlot4.setBackgroundPaint((java.awt.Paint) color12);
        int int14 = color12.getRed();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(datasetRenderingOrder10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 255 + "'", int14 == 255);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        java.util.Date date3 = spreadsheetDate1.toDate();
        java.util.TimeZone timeZone4 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date3, timeZone4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.previous();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = month5.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(regularTimePeriod6);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("ERROR : Relative To String");
        numberAxis3D1.setAutoTickUnitSelection(true);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.clearSeriesStrokes(true);
        java.awt.Stroke stroke4 = xYBarRenderer0.lookupSeriesOutlineStroke(100);
        xYBarRenderer0.setShadowXOffset((double) 100.0f);
        org.jfree.chart.plot.XYPlot xYPlot7 = xYBarRenderer0.getPlot();
        xYBarRenderer0.setBaseItemLabelsVisible(false, false);
        java.awt.Paint paint12 = xYBarRenderer0.lookupLegendTextPaint((-1));
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(xYPlot7);
        org.junit.Assert.assertNull(paint12);
    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test073");
//        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//        xYBarRenderer0.clearSeriesStrokes(true);
//        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator3 = xYBarRenderer0.getBaseItemLabelGenerator();
//        java.awt.Paint paint5 = xYBarRenderer0.lookupSeriesPaint(9999);
//        java.awt.Shape shape7 = xYBarRenderer0.getLegendShape((int) ' ');
//        java.awt.Graphics2D graphics2D8 = null;
//        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot9 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
//        int int11 = combinedDomainXYPlot9.getDomainAxisIndex(valueAxis10);
//        org.jfree.chart.axis.ValueAxis valueAxis12 = combinedDomainXYPlot9.getRangeAxis();
//        boolean boolean13 = combinedDomainXYPlot9.isSubplot();
//        combinedDomainXYPlot9.setRangeMinorGridlinesVisible(false);
//        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer16 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//        xYBarRenderer16.clearSeriesStrokes(true);
//        java.awt.Stroke stroke20 = xYBarRenderer16.lookupSeriesOutlineStroke(100);
//        xYBarRenderer16.setShadowXOffset((double) 100.0f);
//        java.awt.Stroke stroke23 = xYBarRenderer16.getBaseOutlineStroke();
//        boolean boolean24 = xYBarRenderer16.getBaseItemLabelsVisible();
//        combinedDomainXYPlot9.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer16);
//        java.awt.Paint paint26 = combinedDomainXYPlot9.getRangeTickBandPaint();
//        combinedDomainXYPlot9.mapDatasetToDomainAxis(0, (int) (byte) 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date33 = spreadsheetDate32.toDate();
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date33);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        long long36 = day35.getLastMillisecond();
//        org.jfree.chart.axis.PeriodAxis periodAxis37 = new org.jfree.chart.axis.PeriodAxis("$8.00", (org.jfree.data.time.RegularTimePeriod) day34, (org.jfree.data.time.RegularTimePeriod) day35);
//        java.awt.Paint paint38 = periodAxis37.getTickMarkPaint();
//        periodAxis37.setFixedAutoRange((double) 4);
//        java.awt.Paint paint42 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
//        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer43 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//        xYBarRenderer43.clearSeriesStrokes(true);
//        java.awt.Stroke stroke47 = xYBarRenderer43.lookupSeriesOutlineStroke(100);
//        xYBarRenderer43.setShadowXOffset((double) 100.0f);
//        java.awt.Stroke stroke50 = xYBarRenderer43.getBaseOutlineStroke();
//        org.jfree.chart.plot.ValueMarker valueMarker51 = new org.jfree.chart.plot.ValueMarker(0.05d, paint42, stroke50);
//        float float52 = valueMarker51.getAlpha();
//        java.awt.geom.Rectangle2D rectangle2D53 = null;
//        try {
//            xYBarRenderer0.drawRangeMarker(graphics2D8, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot9, (org.jfree.chart.axis.ValueAxis) periodAxis37, (org.jfree.chart.plot.Marker) valueMarker51, rectangle2D53);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(xYItemLabelGenerator3);
//        org.junit.Assert.assertNotNull(paint5);
//        org.junit.Assert.assertNull(shape7);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertNull(valueAxis12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(stroke20);
//        org.junit.Assert.assertNotNull(stroke23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNull(paint26);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560495599999L + "'", long36 == 1560495599999L);
//        org.junit.Assert.assertNotNull(paint38);
//        org.junit.Assert.assertNotNull(paint42);
//        org.junit.Assert.assertNotNull(stroke47);
//        org.junit.Assert.assertNotNull(stroke50);
//        org.junit.Assert.assertTrue("'" + float52 + "' != '" + 1.0f + "'", float52 == 1.0f);
//    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot2 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = combinedDomainXYPlot2.getDomainAxisIndex(valueAxis3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = combinedDomainXYPlot2.getRangeAxis();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("WMAP_Plot", font1, (org.jfree.chart.plot.Plot) combinedDomainXYPlot2, true);
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle9.setMaximumLinesToDisplay(1);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, categoryItemRenderer15);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot16.getDomainAxisEdge();
        textTitle9.setPosition(rectangleEdge17);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = textTitle9.getPadding();
        jFreeChart7.removeSubtitle((org.jfree.chart.title.Title) textTitle9);
        org.jfree.chart.title.LegendTitle legendTitle21 = jFreeChart7.getLegend();
        java.awt.Font font22 = legendTitle21.getItemFont();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent23 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle21);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(legendTitle21);
        org.junit.Assert.assertNotNull(font22);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.awt.Image image1 = projectInfo0.getLogo();
        projectInfo0.setLicenceName("hi!");
        java.lang.String str4 = projectInfo0.getLicenceText();
        org.junit.Assert.assertNull(image1);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot2 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = combinedDomainXYPlot2.getDomainAxisIndex(valueAxis3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = combinedDomainXYPlot2.getRangeAxis();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("WMAP_Plot", font1, (org.jfree.chart.plot.Plot) combinedDomainXYPlot2, true);
        boolean boolean8 = jFreeChart7.getAntiAlias();
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        textTitle10.setPadding(rectangleInsets11);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        textTitle10.draw(graphics2D13, rectangle2D14);
        java.lang.Object obj16 = textTitle10.clone();
        jFreeChart7.setTitle(textTitle10);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(obj16);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (short) -1, 0.0d, (double) (short) -1, (double) (byte) 10);
        double double6 = rectangleInsets4.calculateLeftOutset(100.0d);
        double double8 = rectangleInsets4.extendHeight(10.0d);
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType10 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        java.lang.String str11 = lengthAdjustmentType10.toString();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType12 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        try {
            java.awt.geom.Rectangle2D rectangle2D13 = rectangleInsets4.createAdjustedRectangle(rectangle2D9, lengthAdjustmentType10, lengthAdjustmentType12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 8.0d + "'", double8 == 8.0d);
        org.junit.Assert.assertNotNull(lengthAdjustmentType10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "NO_CHANGE" + "'", str11.equals("NO_CHANGE"));
        org.junit.Assert.assertNotNull(lengthAdjustmentType12);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("[Dec 31, 1969 3:59:59 PM --> Dec 31, 1969 4:00:00 PM]", "NOID", "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "MAJOR", "TextBlockAnchor.TOP_RIGHT");
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.chart.text.TextBlock textBlock2 = new org.jfree.chart.text.TextBlock();
        java.util.List list3 = textBlock2.getLines();
        org.jfree.data.Range range5 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection1, list3, true);
        try {
            java.util.Collection collection6 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list3);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNull(range5);
    }

//    @Test
//    public void test081() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test081");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date3 = spreadsheetDate2.toDate();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        long long6 = day5.getLastMillisecond();
//        org.jfree.chart.axis.PeriodAxis periodAxis7 = new org.jfree.chart.axis.PeriodAxis("$8.00", (org.jfree.data.time.RegularTimePeriod) day4, (org.jfree.data.time.RegularTimePeriod) day5);
//        java.awt.Paint paint8 = periodAxis7.getTickMarkPaint();
//        org.jfree.data.time.DateRange dateRange11 = new org.jfree.data.time.DateRange((-1.0d), (double) (byte) 100);
//        double double12 = dateRange11.getUpperBound();
//        periodAxis7.setRange((org.jfree.data.Range) dateRange11, false, false);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560495599999L + "'", long6 == 1560495599999L);
//        org.junit.Assert.assertNotNull(paint8);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 100.0d + "'", double12 == 100.0d);
//    }

//    @Test
//    public void test082() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test082");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date3 = spreadsheetDate2.toDate();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        long long6 = day5.getLastMillisecond();
//        org.jfree.chart.axis.PeriodAxis periodAxis7 = new org.jfree.chart.axis.PeriodAxis("$8.00", (org.jfree.data.time.RegularTimePeriod) day4, (org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.String str8 = periodAxis7.getLabelToolTip();
//        java.awt.Graphics2D graphics2D9 = null;
//        org.jfree.chart.plot.Plot plot10 = null;
//        java.awt.geom.Rectangle2D rectangle2D11 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge12 = org.jfree.chart.util.RectangleEdge.TOP;
//        org.jfree.chart.axis.AxisSpace axisSpace13 = null;
//        try {
//            org.jfree.chart.axis.AxisSpace axisSpace14 = periodAxis7.reserveSpace(graphics2D9, plot10, rectangle2D11, rectangleEdge12, axisSpace13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560495599999L + "'", long6 == 1560495599999L);
//        org.junit.Assert.assertNull(str8);
//        org.junit.Assert.assertNotNull(rectangleEdge12);
//    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot5.getDomainAxisEdge();
        boolean boolean7 = categoryPlot5.isRangeGridlinesVisible();
        java.lang.Comparable comparable8 = categoryPlot5.getDomainCrosshairColumnKey();
        java.awt.Paint paint9 = categoryPlot5.getDomainCrosshairPaint();
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("NO_CHANGE", paint9);
        int int11 = legendItem10.getSeriesIndex();
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(comparable8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj2 = objectList0.get(6);
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=0,g=255,b=0]");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer5 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer5.clearSeriesStrokes(true);
        java.awt.Stroke stroke9 = xYBarRenderer5.lookupSeriesOutlineStroke(100);
        xYBarRenderer5.setShadowXOffset((double) 100.0f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState14 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo13);
        java.awt.geom.Line2D line2D15 = xYItemRendererState14.workingLine;
        xYBarRenderer5.setLegendShape(0, (java.awt.Shape) line2D15);
        numberAxis4.setRightArrow((java.awt.Shape) line2D15);
        numberAxis4.setMinorTickMarksVisible(true);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot20 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        int int22 = combinedDomainXYPlot20.getDomainAxisIndex(valueAxis21);
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        int int24 = combinedDomainXYPlot20.getRangeAxisIndex(valueAxis23);
        java.awt.Paint paint25 = combinedDomainXYPlot20.getDomainZeroBaselinePaint();
        boolean boolean26 = combinedDomainXYPlot20.isDomainZeroBaselineVisible();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder27 = combinedDomainXYPlot20.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation28 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        combinedDomainXYPlot20.setRangeAxisLocation(axisLocation28, true);
        numberAxis4.removeChangeListener((org.jfree.chart.event.AxisChangeListener) combinedDomainXYPlot20);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand32 = numberAxis4.getMarkerBand();
        int int33 = objectList0.indexOf((java.lang.Object) numberAxis4);
        org.junit.Assert.assertNull(obj2);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(line2D15);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(seriesRenderingOrder27);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertNull(markerAxisBand32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        int int2 = combinedDomainXYPlot0.getDomainAxisIndex(valueAxis1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = combinedDomainXYPlot0.getRangeAxis();
        boolean boolean4 = combinedDomainXYPlot0.isSubplot();
        combinedDomainXYPlot0.setRangeMinorGridlinesVisible(false);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer7 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer7.clearSeriesStrokes(true);
        java.awt.Stroke stroke11 = xYBarRenderer7.lookupSeriesOutlineStroke(100);
        xYBarRenderer7.setShadowXOffset((double) 100.0f);
        java.awt.Stroke stroke14 = xYBarRenderer7.getBaseOutlineStroke();
        boolean boolean15 = xYBarRenderer7.getBaseItemLabelsVisible();
        combinedDomainXYPlot0.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer7);
        java.awt.Paint paint17 = combinedDomainXYPlot0.getRangeTickBandPaint();
        java.util.TimeZone timeZone19 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection20 = new org.jfree.data.time.TimeSeriesCollection(timeZone19);
        org.jfree.data.Range range22 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection20, true);
        combinedDomainXYPlot0.setDataset(1, (org.jfree.data.xy.XYDataset) timeSeriesCollection20);
        org.jfree.data.DomainOrder domainOrder24 = timeSeriesCollection20.getDomainOrder();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertNull(range22);
        org.junit.Assert.assertNotNull(domainOrder24);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.Size2D size2D2 = textLine0.calculateDimensions(graphics2D1);
        org.junit.Assert.assertNotNull(size2D2);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.awt.geom.Point2D point2D3 = null;
        org.jfree.chart.plot.PlotState plotState4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        try {
            multiplePiePlot0.draw(graphics2D1, rectangle2D2, point2D3, plotState4, plotRenderingInfo5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.chart.axis.SegmentedTimeline.FIRST_MONDAY_AFTER_1900 = 0L;
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (short) -1, 0.0d, (double) (short) -1, (double) (byte) 10);
        double double6 = rectangleInsets4.extendWidth((double) (-1));
        org.jfree.chart.util.UnitType unitType7 = rectangleInsets4.getUnitType();
        double double9 = rectangleInsets4.calculateLeftInset((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 9.0d + "'", double6 == 9.0d);
        org.junit.Assert.assertNotNull(unitType7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0);
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        int int7 = categoryPlot6.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation9 = null;
        categoryPlot6.setRangeAxisLocation(100, axisLocation9);
        timeSeriesCollection1.removeChangeListener((org.jfree.data.general.DatasetChangeListener) categoryPlot6);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate13 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection1, true);
        boolean boolean14 = intervalXYDelegate13.isAutoWidth();
        intervalXYDelegate13.setAutoWidth(true);
        double double18 = intervalXYDelegate13.getDomainUpperBound(false);
        org.jfree.data.Range range20 = intervalXYDelegate13.getDomainBounds(false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
        org.junit.Assert.assertNull(range20);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = categoryPlot4.getDomainAxisEdge();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot4.getRangeAxis();
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNull(valueAxis6);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        int int2 = combinedDomainXYPlot0.getDomainAxisIndex(valueAxis1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = combinedDomainXYPlot0.getRangeAxisIndex(valueAxis3);
        java.awt.Paint paint5 = combinedDomainXYPlot0.getDomainZeroBaselinePaint();
        boolean boolean6 = combinedDomainXYPlot0.isDomainZeroBaselineVisible();
        org.jfree.chart.util.Layer layer7 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection8 = combinedDomainXYPlot0.getRangeMarkers(layer7);
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle10.setMaximumLinesToDisplay(1);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, categoryItemRenderer16);
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = categoryPlot17.getDomainAxisEdge();
        textTitle10.setPosition(rectangleEdge18);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment20 = textTitle10.getTextAlignment();
        boolean boolean21 = layer7.equals((java.lang.Object) textTitle10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(layer7);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(horizontalAlignment20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.setRangeCrosshairValue(0.0d);
        org.jfree.chart.axis.AxisSpace axisSpace7 = categoryPlot4.getFixedDomainAxisSpace();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot4.panDomainAxes((double) 8, plotRenderingInfo9, point2D10);
        org.junit.Assert.assertNull(axisSpace7);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.jfree.data.UnknownKeyException unknownKeyException4 = new org.jfree.data.UnknownKeyException("TextBlockAnchor.TOP_RIGHT");
        java.lang.Throwable[] throwableArray5 = unknownKeyException4.getSuppressed();
        org.jfree.data.UnknownKeyException unknownKeyException7 = new org.jfree.data.UnknownKeyException("TextBlockAnchor.TOP_RIGHT");
        unknownKeyException4.addSuppressed((java.lang.Throwable) unknownKeyException7);
        seriesException1.addSuppressed((java.lang.Throwable) unknownKeyException7);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) 255);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        int int9 = categoryPlot8.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation11 = null;
        categoryPlot8.setRangeAxisLocation(100, axisLocation11);
        int int13 = categoryPlot8.getWeight();
        java.awt.Paint paint14 = categoryPlot8.getRangeGridlinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier15 = null;
        categoryPlot8.setDrawingSupplier(drawingSupplier15, false);
        boolean boolean18 = categoryPlot8.isSubplot();
        categoryPlot8.setRangeZeroBaselineVisible(true);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder21 = categoryPlot8.getDatasetRenderingOrder();
        int int22 = timeSeriesDataItem2.compareTo((java.lang.Object) categoryPlot8);
        java.lang.Number number23 = timeSeriesDataItem2.getValue();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + 255 + "'", number23.equals(255));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        boolean boolean0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation(100, axisLocation7);
        int int9 = categoryPlot4.getWeight();
        java.awt.Paint paint10 = categoryPlot4.getRangeGridlinePaint();
        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot4.getRangeAxisForDataset((int) (short) 100);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent13 = null;
        categoryPlot4.datasetChanged(datasetChangeEvent13);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder15 = categoryPlot4.getDatasetRenderingOrder();
        double double16 = categoryPlot4.getAnchorValue();
        java.awt.Stroke stroke17 = categoryPlot4.getRangeGridlineStroke();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNotNull(datasetRenderingOrder15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) 255);
        boolean boolean3 = timeSeriesDataItem2.isSelected();
        int int5 = timeSeriesDataItem2.compareTo((java.lang.Object) (byte) 1);
        org.jfree.data.xy.XYSeries xYSeries6 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection1, true);
        try {
            double double6 = timeSeriesCollection1.getStartYValue(1, 31);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range3);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.chart.renderer.xy.GradientXYBarPainter gradientXYBarPainter0 = new org.jfree.chart.renderer.xy.GradientXYBarPainter();
        org.jfree.chart.renderer.xy.XYBarRenderer.setDefaultBarPainter((org.jfree.chart.renderer.xy.XYBarPainter) gradientXYBarPainter0);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation(100, axisLocation7);
        int int9 = categoryPlot4.getWeight();
        java.awt.Paint paint10 = categoryPlot4.getRangeGridlinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier11 = null;
        categoryPlot4.setDrawingSupplier(drawingSupplier11, false);
        boolean boolean14 = categoryPlot4.isSubplot();
        categoryPlot4.setRangeZeroBaselineVisible(true);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder17 = categoryPlot4.getDatasetRenderingOrder();
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = categoryPlot4.getRendererForDataset(categoryDataset18);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder17);
        org.junit.Assert.assertNull(categoryItemRenderer19);
    }

//    @Test
//    public void test102() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test102");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date3 = spreadsheetDate2.toDate();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        long long6 = day5.getLastMillisecond();
//        org.jfree.chart.axis.PeriodAxis periodAxis7 = new org.jfree.chart.axis.PeriodAxis("$8.00", (org.jfree.data.time.RegularTimePeriod) day4, (org.jfree.data.time.RegularTimePeriod) day5);
//        java.awt.Paint paint8 = periodAxis7.getTickMarkPaint();
//        periodAxis7.setFixedAutoRange((double) 4);
//        periodAxis7.setUpperMargin((double) 15);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560495599999L + "'", long6 == 1560495599999L);
//        org.junit.Assert.assertNotNull(paint8);
//    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot2 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = combinedDomainXYPlot2.getDomainAxisIndex(valueAxis3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = combinedDomainXYPlot2.getRangeAxis();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("WMAP_Plot", font1, (org.jfree.chart.plot.Plot) combinedDomainXYPlot2, true);
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle9.setMaximumLinesToDisplay(1);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, categoryItemRenderer15);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot16.getDomainAxisEdge();
        textTitle9.setPosition(rectangleEdge17);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = textTitle9.getPadding();
        jFreeChart7.removeSubtitle((org.jfree.chart.title.Title) textTitle9);
        java.awt.RenderingHints renderingHints21 = null;
        try {
            jFreeChart7.setRenderingHints(renderingHints21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: RenderingHints given are null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(rectangleInsets19);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation(100, axisLocation7);
        int int9 = categoryPlot4.getWeight();
        java.awt.Paint paint10 = categoryPlot4.getRangeGridlinePaint();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation11 = null;
        try {
            categoryPlot4.addAnnotation(categoryAnnotation11, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        org.jfree.chart.text.TextFragment textFragment1 = null;
        textLine0.removeFragment(textFragment1);
        org.jfree.chart.text.TextFragment textFragment3 = textLine0.getLastTextFragment();
        org.jfree.chart.text.TextFragment textFragment4 = textLine0.getLastTextFragment();
        org.junit.Assert.assertNull(textFragment3);
        org.junit.Assert.assertNull(textFragment4);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState1 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo0);
        int int2 = xYItemRendererState1.getFirstItemIndex();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = xYItemRendererState1.getInfo();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNull(plotRenderingInfo3);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("NO_CHANGE");
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 7);
        xYSeries1.add((double) (byte) -1, (double) (-1), true);
        java.lang.String str6 = xYSeries1.getDescription();
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.data.Range range2 = xYStepRenderer0.findDomainBounds(xYDataset1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = null;
        xYStepRenderer0.setBaseToolTipGenerator(xYToolTipGenerator3);
        java.awt.Paint paint5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepRenderer0.setBaseOutlinePaint(paint5);
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = categoryPlot4.getDomainAxisEdge();
        boolean boolean6 = categoryPlot4.isRangeGridlinesVisible();
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=0,g=255,b=0]");
        org.jfree.data.Range range9 = categoryPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis8);
        boolean boolean10 = numberAxis8.isAutoTickUnitSelection();
        java.lang.Object obj11 = numberAxis8.clone();
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState5 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo4);
        java.awt.geom.Line2D line2D6 = xYItemRendererState5.workingLine;
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape) line2D6, (double) (-1L), (double) (short) -1);
        java.awt.Paint paint10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, valueAxis13, categoryItemRenderer14);
        int int16 = categoryPlot15.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation18 = null;
        categoryPlot15.setRangeAxisLocation(100, axisLocation18);
        int int20 = categoryPlot15.getWeight();
        java.awt.Paint paint21 = categoryPlot15.getRangeGridlinePaint();
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.data.Range range23 = categoryPlot15.getDataRange(valueAxis22);
        java.awt.Stroke stroke24 = categoryPlot15.getRangeMinorGridlineStroke();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D27 = new org.jfree.chart.axis.CategoryAxis3D("ERROR : Relative To String");
        categoryAxis3D27.clearCategoryLabelToolTips();
        categoryPlot15.setDomainAxis((int) '#', (org.jfree.chart.axis.CategoryAxis) categoryAxis3D27, false);
        categoryAxis3D27.setCategoryMargin((double) 7);
        java.awt.Stroke stroke33 = categoryAxis3D27.getTickMarkStroke();
        java.awt.Paint paint35 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer36 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer36.clearSeriesStrokes(true);
        java.awt.Stroke stroke40 = xYBarRenderer36.lookupSeriesOutlineStroke(100);
        xYBarRenderer36.setShadowXOffset((double) 100.0f);
        java.awt.Stroke stroke43 = xYBarRenderer36.getBaseOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker44 = new org.jfree.chart.plot.ValueMarker(0.05d, paint35, stroke43);
        org.jfree.chart.text.TextAnchor textAnchor45 = valueMarker44.getLabelTextAnchor();
        java.awt.Font font46 = valueMarker44.getLabelFont();
        java.awt.Paint paint47 = valueMarker44.getOutlinePaint();
        org.jfree.chart.LegendItem legendItem48 = new org.jfree.chart.LegendItem("TextBlockAnchor.TOP_RIGHT", "($1.00)", "MAJOR", "TextBlockAnchor.TOP_RIGHT", shape9, paint10, stroke33, paint47);
        java.awt.Paint paint49 = legendItem48.getLinePaint();
        org.junit.Assert.assertNotNull(line2D6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNull(range23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(textAnchor45);
        org.junit.Assert.assertNotNull(font46);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(paint49);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        int int9 = categoryPlot8.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation11 = null;
        categoryPlot8.setRangeAxisLocation(100, axisLocation11);
        int int13 = categoryPlot8.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = categoryPlot8.getDomainAxisEdge();
        try {
            double double15 = logAxis1.java2DToValue(100.0d, rectangle2D3, rectangleEdge14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge14);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        java.lang.Class class1 = null;
        java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResource("", class1);
        java.net.URLClassLoader uRLClassLoader3 = null;
        try {
            org.jfree.chart.util.ResourceBundleWrapper.removeCodeBase(uRL2, uRLClassLoader3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(uRL2);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.clearSeriesStrokes(true);
        java.awt.Paint paint4 = xYBarRenderer0.getSeriesFillPaint((int) '#');
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator5 = xYBarRenderer0.getLegendItemURLGenerator();
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_RED;
        xYBarRenderer0.setSeriesOutlinePaint(1, (java.awt.Paint) color7, true);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator5);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer0.setBaseLinesVisible(true);
        java.awt.Paint paint4 = xYStepRenderer0.lookupLegendTextPaint(2);
        boolean boolean5 = xYStepRenderer0.getDataBoundsIncludesVisibleSeriesOnly();
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_SECOND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day3, (double) 100);
        long long6 = day3.getLastMillisecond();
        long long7 = day3.getLastMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-2208182400001L) + "'", long6 == (-2208182400001L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208182400001L) + "'", long7 == (-2208182400001L));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.chart.renderer.RendererUtilities rendererUtilities0 = new org.jfree.chart.renderer.RendererUtilities();
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation(100, axisLocation7);
        int int9 = categoryPlot4.getWeight();
        java.awt.Paint paint10 = categoryPlot4.getRangeGridlinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier11 = null;
        categoryPlot4.setDrawingSupplier(drawingSupplier11, false);
        boolean boolean14 = categoryPlot4.isSubplot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        categoryPlot4.setRenderer(15, categoryItemRenderer16, false);
        org.jfree.chart.util.Layer layer20 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection21 = categoryPlot4.getRangeMarkers(8, layer20);
        org.jfree.chart.LegendItemCollection legendItemCollection22 = categoryPlot4.getFixedLegendItems();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(layer20);
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertNull(legendItemCollection22);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        java.lang.Comparable comparable1 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, comparable1, Double.POSITIVE_INFINITY, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.data.Range range2 = xYStepRenderer0.findDomainBounds(xYDataset1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = null;
        xYStepRenderer0.setBaseToolTipGenerator(xYToolTipGenerator3);
        org.jfree.data.general.WaferMapDataset waferMapDataset6 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot7 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset6);
        java.awt.Paint paint8 = waferMapPlot7.getOutlinePaint();
        xYStepRenderer0.setSeriesFillPaint(100, paint8, false);
        java.awt.Font font12 = xYStepRenderer0.getSeriesItemLabelFont(100);
        xYStepRenderer0.setSeriesVisible((int) (short) 0, (java.lang.Boolean) true);
        try {
            xYStepRenderer0.setSeriesShapesVisible((-4126), true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(font12);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot2 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = combinedDomainXYPlot2.getDomainAxisIndex(valueAxis3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = combinedDomainXYPlot2.getRangeAxis();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("WMAP_Plot", font1, (org.jfree.chart.plot.Plot) combinedDomainXYPlot2, true);
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle9.setMaximumLinesToDisplay(1);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, categoryItemRenderer15);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot16.getDomainAxisEdge();
        textTitle9.setPosition(rectangleEdge17);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = textTitle9.getPadding();
        jFreeChart7.removeSubtitle((org.jfree.chart.title.Title) textTitle9);
        org.jfree.chart.title.LegendTitle legendTitle21 = jFreeChart7.getLegend();
        org.jfree.chart.block.BlockContainer blockContainer22 = legendTitle21.getItemContainer();
        java.awt.Paint paint23 = legendTitle21.getItemPaint();
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint25 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.util.Size2D size2D26 = legendTitle21.arrange(graphics2D24, rectangleConstraint25);
        org.jfree.data.time.DateRange dateRange27 = new org.jfree.data.time.DateRange();
        long long28 = dateRange27.getUpperMillis();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint29 = rectangleConstraint25.toRangeHeight((org.jfree.data.Range) dateRange27);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(legendTitle21);
        org.junit.Assert.assertNotNull(blockContainer22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(rectangleConstraint25);
        org.junit.Assert.assertNotNull(size2D26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1L + "'", long28 == 1L);
        org.junit.Assert.assertNotNull(rectangleConstraint29);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.data.Range range2 = xYStepRenderer0.findDomainBounds(xYDataset1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = null;
        xYStepRenderer0.setBaseToolTipGenerator(xYToolTipGenerator3);
        boolean boolean5 = xYStepRenderer0.getBaseShapesVisible();
        double double6 = xYStepRenderer0.getStepPoint();
        org.jfree.chart.plot.XYPlot xYPlot7 = xYStepRenderer0.getPlot();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = xYStepRenderer0.getSeriesNegativeItemLabelPosition(0);
        org.jfree.chart.text.TextAnchor textAnchor10 = itemLabelPosition9.getRotationAnchor();
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNull(xYPlot7);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(textAnchor10);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation(100, axisLocation7);
        int int9 = categoryPlot4.getWeight();
        java.awt.Paint paint10 = categoryPlot4.getRangeGridlinePaint();
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.data.Range range12 = categoryPlot4.getDataRange(valueAxis11);
        java.awt.Stroke stroke13 = categoryPlot4.getRangeMinorGridlineStroke();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D16 = new org.jfree.chart.axis.CategoryAxis3D("ERROR : Relative To String");
        categoryAxis3D16.clearCategoryLabelToolTips();
        categoryPlot4.setDomainAxis((int) '#', (org.jfree.chart.axis.CategoryAxis) categoryAxis3D16, false);
        java.awt.Font font20 = categoryAxis3D16.getLabelFont();
        float float21 = categoryAxis3D16.getTickMarkOutsideLength();
        java.lang.String str22 = categoryAxis3D16.getLabelToolTip();
        categoryAxis3D16.setLabelToolTip("LengthConstraintType.FIXED");
        categoryAxis3D16.clearCategoryLabelToolTips();
        float float26 = categoryAxis3D16.getMaximumCategoryLabelWidthRatio();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 2.0f + "'", float21 == 2.0f);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 0.0f + "'", float26 == 0.0f);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.chart.util.PaintMap paintMap0 = new org.jfree.chart.util.PaintMap();
        boolean boolean2 = paintMap0.containsKey((java.lang.Comparable) 9999);
        boolean boolean4 = paintMap0.containsKey((java.lang.Comparable) "{0}");
        java.lang.Object obj5 = paintMap0.clone();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        int int2 = combinedDomainXYPlot0.getDomainAxisIndex(valueAxis1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = combinedDomainXYPlot0.getRangeAxisIndex(valueAxis3);
        java.awt.Paint paint5 = combinedDomainXYPlot0.getDomainZeroBaselinePaint();
        org.jfree.data.general.DatasetGroup datasetGroup6 = combinedDomainXYPlot0.getDatasetGroup();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis10, categoryItemRenderer11);
        int int13 = categoryPlot12.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation15 = null;
        categoryPlot12.setRangeAxisLocation(100, axisLocation15);
        int int17 = categoryPlot12.getWeight();
        java.awt.Paint paint18 = categoryPlot12.getRangeGridlinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier19 = null;
        categoryPlot12.setDrawingSupplier(drawingSupplier19, false);
        boolean boolean22 = categoryPlot12.isDomainZoomable();
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, valueAxis25, categoryItemRenderer26);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = categoryPlot27.getDomainAxisEdge();
        java.awt.Paint paint29 = categoryPlot27.getOutlinePaint();
        java.awt.Paint paint32 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer33 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer33.clearSeriesStrokes(true);
        java.awt.Stroke stroke37 = xYBarRenderer33.lookupSeriesOutlineStroke(100);
        xYBarRenderer33.setShadowXOffset((double) 100.0f);
        java.awt.Stroke stroke40 = xYBarRenderer33.getBaseOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker41 = new org.jfree.chart.plot.ValueMarker(0.05d, paint32, stroke40);
        float float42 = valueMarker41.getAlpha();
        org.jfree.chart.util.Layer layer43 = null;
        boolean boolean44 = categoryPlot27.removeRangeMarker(100, (org.jfree.chart.plot.Marker) valueMarker41, layer43);
        categoryPlot12.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker41);
        org.jfree.chart.util.Layer layer46 = null;
        combinedDomainXYPlot0.addRangeMarker(3, (org.jfree.chart.plot.Marker) valueMarker41, layer46);
        java.lang.Object obj48 = null;
        boolean boolean49 = valueMarker41.equals(obj48);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(datasetGroup6);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertTrue("'" + float42 + "' != '" + 1.0f + "'", float42 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        textTitle1.setPadding(rectangleInsets2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = textTitle1.getMargin();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        textTitle1.draw(graphics2D5, rectangle2D6);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.data.Range range2 = xYStepRenderer0.findDomainBounds(xYDataset1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = null;
        xYStepRenderer0.setBaseToolTipGenerator(xYToolTipGenerator3);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = xYStepRenderer0.getPositiveItemLabelPosition((int) (short) -1, (-458), false);
        xYStepRenderer0.setItemLabelAnchorOffset((-1.0d));
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer12 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.data.Range range14 = xYStepRenderer12.findDomainBounds(xYDataset13);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator15 = null;
        xYStepRenderer12.setBaseToolTipGenerator(xYToolTipGenerator15);
        boolean boolean17 = xYStepRenderer12.getBaseShapesVisible();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator18 = null;
        xYStepRenderer12.setBaseToolTipGenerator(xYToolTipGenerator18, true);
        java.awt.Stroke stroke22 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        xYStepRenderer12.setSeriesOutlineStroke((int) (short) 1, stroke22);
        org.jfree.data.general.WaferMapDataset waferMapDataset24 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot25 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset24);
        java.awt.Font font26 = waferMapPlot25.getNoDataMessageFont();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent27 = null;
        waferMapPlot25.notifyListeners(plotChangeEvent27);
        boolean boolean29 = xYStepRenderer12.hasListener((java.util.EventListener) waferMapPlot25);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier30 = xYStepRenderer12.getDrawingSupplier();
        xYStepRenderer12.clearSeriesPaints(false);
        java.awt.Paint paint35 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer36 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer36.clearSeriesStrokes(true);
        java.awt.Stroke stroke40 = xYBarRenderer36.lookupSeriesOutlineStroke(100);
        xYBarRenderer36.setShadowXOffset((double) 100.0f);
        java.awt.Stroke stroke43 = xYBarRenderer36.getBaseOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker44 = new org.jfree.chart.plot.ValueMarker(0.05d, paint35, stroke43);
        org.jfree.chart.text.TextAnchor textAnchor45 = valueMarker44.getLabelTextAnchor();
        java.awt.Font font46 = valueMarker44.getLabelFont();
        java.awt.Paint paint47 = valueMarker44.getOutlinePaint();
        xYStepRenderer12.setLegendTextPaint(8, paint47);
        try {
            xYStepRenderer0.setSeriesItemLabelPaint((-9999), paint47, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNull(drawingSupplier30);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(textAnchor45);
        org.junit.Assert.assertNotNull(font46);
        org.junit.Assert.assertNotNull(paint47);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot2 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = combinedDomainXYPlot2.getDomainAxisIndex(valueAxis3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = combinedDomainXYPlot2.getRangeAxis();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("WMAP_Plot", font1, (org.jfree.chart.plot.Plot) combinedDomainXYPlot2, true);
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle9.setMaximumLinesToDisplay(1);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, categoryItemRenderer15);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot16.getDomainAxisEdge();
        textTitle9.setPosition(rectangleEdge17);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = textTitle9.getPadding();
        jFreeChart7.removeSubtitle((org.jfree.chart.title.Title) textTitle9);
        org.jfree.chart.title.LegendTitle legendTitle21 = jFreeChart7.getLegend();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = legendTitle21.getItemLabelPadding();
        java.awt.Font font23 = legendTitle21.getItemFont();
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = null;
        try {
            legendTitle21.setLegendItemGraphicEdge(rectangleEdge24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'edge' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(legendTitle21);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(font23);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation(100, axisLocation7);
        int int9 = categoryPlot4.getWeight();
        java.awt.Paint paint10 = categoryPlot4.getRangeGridlinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier11 = null;
        categoryPlot4.setDrawingSupplier(drawingSupplier11, false);
        boolean boolean14 = categoryPlot4.isSubplot();
        categoryPlot4.setRangeZeroBaselineVisible(true);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder17 = categoryPlot4.getDatasetRenderingOrder();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        categoryPlot4.setRenderer(9999, categoryItemRenderer19, true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder17);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.data.time.DateRange dateRange0 = new org.jfree.data.time.DateRange();
        java.util.Date date1 = dateRange0.getLowerDate();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange0, 1.0d);
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("MAJOR");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("ClassContext");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.data.general.DefaultPieDataset defaultPieDataset3 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset) defaultPieDataset3);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D7 = new org.jfree.chart.axis.CategoryAxis3D("ERROR : Relative To String");
        categoryAxis3D7.clearCategoryLabelToolTips();
        categoryAxis3D7.configure();
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.axis.AxisState axisState14 = null;
        categoryAxis3D7.drawTickMarks(graphics2D10, (double) (-1.0f), rectangle2D12, rectangleEdge13, axisState14);
        org.jfree.chart.axis.AxisSpace axisSpace16 = new org.jfree.chart.axis.AxisSpace();
        try {
            org.jfree.chart.axis.AxisSpace axisSpace17 = periodAxis1.reserveSpace(graphics2D2, (org.jfree.chart.plot.Plot) ringPlot4, rectangle2D5, rectangleEdge13, axisSpace16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge13);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        java.awt.Font font3 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("ClassContext", font3);
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("hi!", font3);
        java.awt.Paint paint6 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("{0}", font3, paint6);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(textBlock7);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.chart.axis.TickType tickType0 = org.jfree.chart.axis.TickType.MAJOR;
        java.lang.String str1 = tickType0.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date4 = spreadsheetDate3.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date7 = spreadsheetDate6.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date10 = spreadsheetDate9.toDate();
        boolean boolean11 = spreadsheetDate6.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
        boolean boolean12 = spreadsheetDate3.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date15 = spreadsheetDate14.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date18 = spreadsheetDate17.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date21 = spreadsheetDate20.toDate();
        boolean boolean22 = spreadsheetDate17.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate20);
        boolean boolean23 = spreadsheetDate14.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean27 = spreadsheetDate3.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate14, (org.jfree.data.time.SerialDate) spreadsheetDate25, 0);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date30 = spreadsheetDate29.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date33 = spreadsheetDate32.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date36 = spreadsheetDate35.toDate();
        boolean boolean37 = spreadsheetDate32.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate35);
        boolean boolean38 = spreadsheetDate29.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate35);
        int int39 = spreadsheetDate29.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date42 = spreadsheetDate41.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date45 = spreadsheetDate44.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date48 = spreadsheetDate47.toDate();
        boolean boolean49 = spreadsheetDate44.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate47);
        boolean boolean50 = spreadsheetDate41.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate47);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate52 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date53 = spreadsheetDate52.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate55 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date56 = spreadsheetDate55.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate58 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date59 = spreadsheetDate58.toDate();
        boolean boolean60 = spreadsheetDate55.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate58);
        boolean boolean61 = spreadsheetDate52.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate58);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate63 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean65 = spreadsheetDate41.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate52, (org.jfree.data.time.SerialDate) spreadsheetDate63, 0);
        boolean boolean67 = spreadsheetDate3.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate29, (org.jfree.data.time.SerialDate) spreadsheetDate41, (int) (byte) 100);
        boolean boolean68 = tickType0.equals((java.lang.Object) (byte) 100);
        org.junit.Assert.assertNotNull(tickType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MAJOR" + "'", str1.equals("MAJOR"));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1900 + "'", int39 == 1900);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("TextBlockAnchor.TOP_RIGHT");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType4 = rectangleConstraint3.getHeightConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = rectangleConstraint3.toFixedHeight(0.08d);
        try {
            org.jfree.chart.util.Size2D size2D7 = labelBlock1.arrange(graphics2D2, rectangleConstraint6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleConstraint3);
        org.junit.Assert.assertNotNull(lengthConstraintType4);
        org.junit.Assert.assertNotNull(rectangleConstraint6);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.clearSeriesStrokes(true);
        java.awt.Stroke stroke4 = xYBarRenderer0.lookupSeriesOutlineStroke(100);
        xYBarRenderer0.setShadowXOffset((double) 100.0f);
        xYBarRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        centerArrangement0.clear();
        java.awt.Font font4 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine("ClassContext", font4);
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("hi!", font4);
        boolean boolean7 = centerArrangement0.equals((java.lang.Object) font4);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!");
        double double2 = logAxis1.getBase();
        logAxis1.pan((double) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem(1.0E-5d, (double) 2147483647);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot3 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        int int5 = combinedDomainXYPlot3.getDomainAxisIndex(valueAxis4);
        org.jfree.chart.axis.ValueAxis valueAxis6 = combinedDomainXYPlot3.getRangeAxis();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("WMAP_Plot", font2, (org.jfree.chart.plot.Plot) combinedDomainXYPlot3, true);
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle10.setMaximumLinesToDisplay(1);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, categoryItemRenderer16);
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = categoryPlot17.getDomainAxisEdge();
        textTitle10.setPosition(rectangleEdge18);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = textTitle10.getPadding();
        jFreeChart8.removeSubtitle((org.jfree.chart.title.Title) textTitle10);
        org.jfree.chart.title.LegendTitle legendTitle22 = jFreeChart8.getLegend();
        java.awt.Font font23 = legendTitle22.getItemFont();
        org.jfree.chart.block.LabelBlock labelBlock24 = new org.jfree.chart.block.LabelBlock("", font23);
        labelBlock24.setToolTipText("ClassContext");
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(legendTitle22);
        org.junit.Assert.assertNotNull(font23);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=0,g=255,b=0]");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer2 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer2.clearSeriesStrokes(true);
        java.awt.Stroke stroke6 = xYBarRenderer2.lookupSeriesOutlineStroke(100);
        xYBarRenderer2.setShadowXOffset((double) 100.0f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState11 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo10);
        java.awt.geom.Line2D line2D12 = xYItemRendererState11.workingLine;
        xYBarRenderer2.setLegendShape(0, (java.awt.Shape) line2D12);
        numberAxis1.setRightArrow((java.awt.Shape) line2D12);
        org.jfree.chart.axis.TickUnitSource tickUnitSource15 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        numberAxis1.setStandardTickUnits(tickUnitSource15);
        numberAxis1.resizeRange2(9.0d, (double) 100);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(line2D12);
        org.junit.Assert.assertNotNull(tickUnitSource15);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation(100, axisLocation7);
        int int9 = categoryPlot4.getWeight();
        java.awt.Paint paint10 = categoryPlot4.getRangeGridlinePaint();
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.data.Range range12 = categoryPlot4.getDataRange(valueAxis11);
        java.awt.Stroke stroke13 = categoryPlot4.getRangeMinorGridlineStroke();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D16 = new org.jfree.chart.axis.CategoryAxis3D("ERROR : Relative To String");
        categoryAxis3D16.clearCategoryLabelToolTips();
        categoryPlot4.setDomainAxis((int) '#', (org.jfree.chart.axis.CategoryAxis) categoryAxis3D16, false);
        java.awt.Font font20 = categoryAxis3D16.getLabelFont();
        float float21 = categoryAxis3D16.getTickMarkOutsideLength();
        java.lang.String str22 = categoryAxis3D16.getLabelToolTip();
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.plot.PolarPlot polarPlot24 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean25 = polarPlot24.isRadiusGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        java.awt.geom.Point2D point2D29 = null;
        polarPlot24.zoomDomainAxes((double) 1560495599999L, (double) 4, plotRenderingInfo28, point2D29);
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        java.awt.Font font34 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.text.TextLine textLine35 = new org.jfree.chart.text.TextLine("ClassContext", font34);
        org.jfree.chart.title.TextTitle textTitle36 = new org.jfree.chart.title.TextTitle("hi!", font34);
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = textTitle36.getPosition();
        org.jfree.chart.axis.AxisSpace axisSpace38 = new org.jfree.chart.axis.AxisSpace();
        try {
            org.jfree.chart.axis.AxisSpace axisSpace39 = categoryAxis3D16.reserveSpace(graphics2D23, (org.jfree.chart.plot.Plot) polarPlot24, rectangle2D31, rectangleEdge37, axisSpace38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 2.0f + "'", float21 == 2.0f);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertNotNull(rectangleEdge37);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke1 = polarPlot0.getRadiusGridlineStroke();
        org.jfree.chart.plot.PlotOrientation plotOrientation2 = polarPlot0.getOrientation();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(plotOrientation2);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

//    @Test
//    public void test148() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test148");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date4 = spreadsheetDate3.toDate();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        long long7 = day6.getLastMillisecond();
//        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("$8.00", (org.jfree.data.time.RegularTimePeriod) day5, (org.jfree.data.time.RegularTimePeriod) day6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date11 = spreadsheetDate10.toDate();
//        java.util.Date date12 = spreadsheetDate10.toDate();
//        java.util.TimeZone timeZone13 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date12, timeZone13);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month14.previous();
//        periodAxis8.setFirst((org.jfree.data.time.RegularTimePeriod) month14);
//        java.util.Locale locale17 = periodAxis8.getLocale();
//        try {
//            java.util.ResourceBundle resourceBundle18 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("", locale17);
//            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name , locale en_US");
//        } catch (java.util.MissingResourceException e) {
//        }
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560495599999L + "'", long7 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(timeZone13);
//        org.junit.Assert.assertNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(locale17);
//    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        int int1 = segmentedTimeline0.getSegmentsExcluded();
        int int2 = segmentedTimeline0.getGroupSegmentCount();
        boolean boolean3 = segmentedTimeline0.getAdjustForDaylightSaving();
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange();
        java.util.Date date5 = dateRange4.getLowerDate();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment6 = segmentedTimeline0.getSegment(date5);
        long long7 = segment6.getSegmentCount();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(segment6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test150");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date4 = spreadsheetDate3.toDate();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        long long7 = day6.getLastMillisecond();
//        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("$8.00", (org.jfree.data.time.RegularTimePeriod) day5, (org.jfree.data.time.RegularTimePeriod) day6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date11 = spreadsheetDate10.toDate();
//        java.util.Date date12 = spreadsheetDate10.toDate();
//        java.util.TimeZone timeZone13 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date12, timeZone13);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month14.previous();
//        periodAxis8.setFirst((org.jfree.data.time.RegularTimePeriod) month14);
//        java.util.Locale locale17 = periodAxis8.getLocale();
//        try {
//            java.util.ResourceBundle resourceBundle18 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("ItemLabelAnchor.INSIDE7", locale17);
//            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name ItemLabelAnchor.INSIDE7, locale en_US");
//        } catch (java.util.MissingResourceException e) {
//        }
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560495599999L + "'", long7 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(timeZone13);
//        org.junit.Assert.assertNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(locale17);
//    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date3 = spreadsheetDate2.toDate();
        java.util.Date date4 = spreadsheetDate2.toDate();
        java.util.TimeZone timeZone5 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date4, timeZone5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month6.previous();
        boolean boolean8 = shapeList0.equals((java.lang.Object) regularTimePeriod7);
        org.jfree.chart.ui.ProjectInfo projectInfo9 = new org.jfree.chart.ui.ProjectInfo();
        java.awt.Image image10 = projectInfo9.getLogo();
        projectInfo9.setLicenceName("hi!");
        java.lang.String str13 = projectInfo9.getLicenceName();
        boolean boolean14 = shapeList0.equals((java.lang.Object) str13);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(image10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

//    @Test
//    public void test152() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test152");
//        java.text.AttributedString attributedString0 = null;
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
//        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState6 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo5);
//        java.awt.geom.Line2D line2D7 = xYItemRendererState6.workingLine;
//        org.jfree.chart.entity.ChartEntity chartEntity10 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) line2D7, "{0}: ({1}, {2})", "series");
//        java.awt.Shape shape14 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) line2D7, 3.0d, (float) 'a', (float) (short) 0);
//        java.awt.Paint paint16 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
//        java.awt.Color color18 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
//        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer19 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//        xYBarRenderer19.clearSeriesStrokes(true);
//        java.awt.Stroke stroke23 = xYBarRenderer19.lookupSeriesOutlineStroke(100);
//        xYBarRenderer19.setShadowXOffset((double) 100.0f);
//        java.awt.Stroke stroke26 = xYBarRenderer19.getBaseOutlineStroke();
//        java.awt.Shape shape32 = null;
//        org.jfree.data.category.CategoryDataset categoryDataset33 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis34 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, categoryAxis34, valueAxis35, categoryItemRenderer36);
//        int int38 = categoryPlot37.getDomainAxisCount();
//        org.jfree.chart.axis.AxisLocation axisLocation40 = null;
//        categoryPlot37.setRangeAxisLocation(100, axisLocation40);
//        int int42 = categoryPlot37.getWeight();
//        java.awt.Paint paint43 = categoryPlot37.getRangeGridlinePaint();
//        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer44 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//        xYBarRenderer44.clearSeriesStrokes(true);
//        java.awt.Stroke stroke48 = xYBarRenderer44.lookupSeriesOutlineStroke(100);
//        xYBarRenderer44.setShadowXOffset((double) 100.0f);
//        java.awt.Stroke stroke51 = xYBarRenderer44.getBaseOutlineStroke();
//        java.awt.Paint paint52 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
//        org.jfree.chart.LegendItem legendItem53 = new org.jfree.chart.LegendItem("", "TextBlockAnchor.TOP_RIGHT", "{0}: ({1}, {2})", "", shape32, paint43, stroke51, paint52);
//        java.awt.Color color54 = java.awt.Color.lightGray;
//        legendItem53.setLabelPaint((java.awt.Paint) color54);
//        java.awt.Shape shape56 = legendItem53.getShape();
//        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer57 = new org.jfree.chart.util.StandardGradientPaintTransformer();
//        legendItem53.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer57);
//        java.awt.Shape shape61 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) (short) -1, (float) 1L);
//        org.jfree.chart.util.RectangleAnchor rectangleAnchor62 = org.jfree.chart.util.RectangleAnchor.TOP;
//        java.awt.Shape shape65 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape61, rectangleAnchor62, (double) (short) 0, (double) 1);
//        legendItem53.setShape(shape65);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate69 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date70 = spreadsheetDate69.toDate();
//        org.jfree.data.time.Day day71 = new org.jfree.data.time.Day(date70);
//        org.jfree.data.time.Day day72 = new org.jfree.data.time.Day();
//        long long73 = day72.getLastMillisecond();
//        org.jfree.chart.axis.PeriodAxis periodAxis74 = new org.jfree.chart.axis.PeriodAxis("$8.00", (org.jfree.data.time.RegularTimePeriod) day71, (org.jfree.data.time.RegularTimePeriod) day72);
//        java.lang.String str75 = periodAxis74.getLabelToolTip();
//        java.util.TimeZone timeZone76 = periodAxis74.getTimeZone();
//        boolean boolean77 = periodAxis74.isAutoRange();
//        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot78 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//        org.jfree.chart.axis.ValueAxis valueAxis79 = null;
//        int int80 = combinedDomainXYPlot78.getDomainAxisIndex(valueAxis79);
//        org.jfree.chart.axis.ValueAxis valueAxis81 = combinedDomainXYPlot78.getRangeAxis();
//        boolean boolean82 = combinedDomainXYPlot78.isSubplot();
//        java.awt.Stroke stroke83 = combinedDomainXYPlot78.getRangeMinorGridlineStroke();
//        periodAxis74.setTickMarkStroke(stroke83);
//        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer85 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//        xYBarRenderer85.clearSeriesStrokes(true);
//        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator88 = xYBarRenderer85.getBaseItemLabelGenerator();
//        java.awt.Paint paint90 = xYBarRenderer85.lookupSeriesPaint(9999);
//        java.awt.Shape shape92 = xYBarRenderer85.getLegendShape((int) ' ');
//        java.awt.Paint paint96 = xYBarRenderer85.getItemOutlinePaint(12, 0, true);
//        try {
//            org.jfree.chart.LegendItem legendItem97 = new org.jfree.chart.LegendItem(attributedString0, "Category Plot", "series", "hi!", false, shape14, false, paint16, false, (java.awt.Paint) color18, stroke26, true, shape65, stroke83, paint96);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(line2D7);
//        org.junit.Assert.assertNotNull(shape14);
//        org.junit.Assert.assertNotNull(paint16);
//        org.junit.Assert.assertNotNull(color18);
//        org.junit.Assert.assertNotNull(stroke23);
//        org.junit.Assert.assertNotNull(stroke26);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertNotNull(paint43);
//        org.junit.Assert.assertNotNull(stroke48);
//        org.junit.Assert.assertNotNull(stroke51);
//        org.junit.Assert.assertNotNull(paint52);
//        org.junit.Assert.assertNotNull(color54);
//        org.junit.Assert.assertNull(shape56);
//        org.junit.Assert.assertNotNull(shape61);
//        org.junit.Assert.assertNotNull(rectangleAnchor62);
//        org.junit.Assert.assertNotNull(shape65);
//        org.junit.Assert.assertNotNull(date70);
//        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 1560495599999L + "'", long73 == 1560495599999L);
//        org.junit.Assert.assertNull(str75);
//        org.junit.Assert.assertNotNull(timeZone76);
//        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
//        org.junit.Assert.assertTrue("'" + int80 + "' != '" + (-1) + "'", int80 == (-1));
//        org.junit.Assert.assertNull(valueAxis81);
//        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
//        org.junit.Assert.assertNotNull(stroke83);
//        org.junit.Assert.assertNull(xYItemLabelGenerator88);
//        org.junit.Assert.assertNotNull(paint90);
//        org.junit.Assert.assertNull(shape92);
//        org.junit.Assert.assertNotNull(paint96);
//    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        java.awt.Color color0 = java.awt.Color.GREEN;
        java.awt.Color color1 = java.awt.Color.GREEN;
        java.awt.color.ColorSpace colorSpace2 = color1.getColorSpace();
        float[] floatArray4 = new float[] { 4 };
        try {
            float[] floatArray5 = color0.getColorComponents(colorSpace2, floatArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(colorSpace2);
        org.junit.Assert.assertNotNull(floatArray4);
    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test154");
//        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
//        int int2 = combinedDomainXYPlot0.getDomainAxisIndex(valueAxis1);
//        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
//        int int4 = combinedDomainXYPlot0.getRangeAxisIndex(valueAxis3);
//        java.awt.Paint paint5 = combinedDomainXYPlot0.getDomainZeroBaselinePaint();
//        java.awt.Stroke stroke6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
//        combinedDomainXYPlot0.setRangeZeroBaselineStroke(stroke6);
//        org.jfree.data.xy.XYDataset xYDataset8 = null;
//        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = combinedDomainXYPlot0.getRendererForDataset(xYDataset8);
//        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=0,g=255,b=0]");
//        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer12 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//        xYBarRenderer12.clearSeriesStrokes(true);
//        java.awt.Stroke stroke16 = xYBarRenderer12.lookupSeriesOutlineStroke(100);
//        xYBarRenderer12.setShadowXOffset((double) 100.0f);
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
//        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState21 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo20);
//        java.awt.geom.Line2D line2D22 = xYItemRendererState21.workingLine;
//        xYBarRenderer12.setLegendShape(0, (java.awt.Shape) line2D22);
//        numberAxis11.setRightArrow((java.awt.Shape) line2D22);
//        org.jfree.chart.axis.TickUnitSource tickUnitSource25 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
//        numberAxis11.setStandardTickUnits(tickUnitSource25);
//        java.text.NumberFormat numberFormat28 = java.text.NumberFormat.getCurrencyInstance();
//        org.jfree.chart.axis.NumberTickUnit numberTickUnit29 = new org.jfree.chart.axis.NumberTickUnit((double) 100L, numberFormat28);
//        numberAxis11.setTickUnit(numberTickUnit29, true, false);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date36 = spreadsheetDate35.toDate();
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date36);
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
//        long long39 = day38.getLastMillisecond();
//        org.jfree.chart.axis.PeriodAxis periodAxis40 = new org.jfree.chart.axis.PeriodAxis("$8.00", (org.jfree.data.time.RegularTimePeriod) day37, (org.jfree.data.time.RegularTimePeriod) day38);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date44 = spreadsheetDate43.toDate();
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date44);
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day();
//        long long47 = day46.getLastMillisecond();
//        org.jfree.chart.axis.PeriodAxis periodAxis48 = new org.jfree.chart.axis.PeriodAxis("$8.00", (org.jfree.data.time.RegularTimePeriod) day45, (org.jfree.data.time.RegularTimePeriod) day46);
//        org.jfree.chart.axis.ValueAxis[] valueAxisArray49 = new org.jfree.chart.axis.ValueAxis[] { numberAxis11, periodAxis40, periodAxis48 };
//        combinedDomainXYPlot0.setRangeAxes(valueAxisArray49);
//        java.awt.Stroke stroke51 = null;
//        combinedDomainXYPlot0.setOutlineStroke(stroke51);
//        java.awt.Stroke stroke53 = combinedDomainXYPlot0.getDomainGridlineStroke();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(paint5);
//        org.junit.Assert.assertNotNull(stroke6);
//        org.junit.Assert.assertNull(xYItemRenderer9);
//        org.junit.Assert.assertNotNull(stroke16);
//        org.junit.Assert.assertNotNull(line2D22);
//        org.junit.Assert.assertNotNull(tickUnitSource25);
//        org.junit.Assert.assertNotNull(numberFormat28);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560495599999L + "'", long39 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1560495599999L + "'", long47 == 1560495599999L);
//        org.junit.Assert.assertNotNull(valueAxisArray49);
//        org.junit.Assert.assertNotNull(stroke53);
//    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        int int0 = org.jfree.chart.renderer.xy.XYAreaRenderer.AREA;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("ERROR : Relative To String");
        categoryAxis3D1.clearCategoryLabelToolTips();
        categoryAxis3D1.configure();
        java.lang.Object obj4 = categoryAxis3D1.clone();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor5 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle10.setMaximumLinesToDisplay(1);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, categoryItemRenderer16);
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = categoryPlot17.getDomainAxisEdge();
        textTitle10.setPosition(rectangleEdge18);
        try {
            double double20 = categoryAxis3D1.getCategoryJava2DCoordinate(categoryAnchor5, (int) (short) 10, 12, rectangle2D8, rectangleEdge18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(rectangleEdge18);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        int int2 = combinedDomainXYPlot0.getDomainAxisIndex(valueAxis1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = combinedDomainXYPlot0.getRangeAxis();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = categoryPlot8.getDomainAxisEdge();
        java.awt.Paint paint10 = categoryPlot8.getOutlinePaint();
        java.awt.Paint paint13 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer14 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer14.clearSeriesStrokes(true);
        java.awt.Stroke stroke18 = xYBarRenderer14.lookupSeriesOutlineStroke(100);
        xYBarRenderer14.setShadowXOffset((double) 100.0f);
        java.awt.Stroke stroke21 = xYBarRenderer14.getBaseOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker(0.05d, paint13, stroke21);
        float float23 = valueMarker22.getAlpha();
        org.jfree.chart.util.Layer layer24 = null;
        boolean boolean25 = categoryPlot8.removeRangeMarker(100, (org.jfree.chart.plot.Marker) valueMarker22, layer24);
        org.jfree.chart.text.TextAnchor textAnchor26 = valueMarker22.getLabelTextAnchor();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot27 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        int int29 = combinedDomainXYPlot27.getDomainAxisIndex(valueAxis28);
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        int int31 = combinedDomainXYPlot27.getRangeAxisIndex(valueAxis30);
        java.awt.Paint paint32 = combinedDomainXYPlot27.getDomainZeroBaselinePaint();
        boolean boolean33 = combinedDomainXYPlot27.isDomainZeroBaselineVisible();
        org.jfree.chart.util.Layer layer34 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection35 = combinedDomainXYPlot27.getRangeMarkers(layer34);
        combinedDomainXYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker22, layer34);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent37 = null;
        valueMarker22.notifyListeners(markerChangeEvent37);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType39 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        valueMarker22.setLabelOffsetType(lengthAdjustmentType39);
        try {
            valueMarker22.setAlpha((float) (-9999));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 1.0f + "'", float23 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(textAnchor26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(layer34);
        org.junit.Assert.assertNull(collection35);
        org.junit.Assert.assertNotNull(lengthAdjustmentType39);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(9999, (-4126), 9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'month' argument must be in the range 1 to 12.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        int int2 = combinedDomainXYPlot0.getDomainAxisIndex(valueAxis1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = combinedDomainXYPlot0.getRangeAxis();
        boolean boolean4 = combinedDomainXYPlot0.isSubplot();
        combinedDomainXYPlot0.setRangeMinorGridlinesVisible(false);
        boolean boolean7 = combinedDomainXYPlot0.isDomainZeroBaselineVisible();
        int int8 = combinedDomainXYPlot0.getWeight();
        java.awt.Stroke stroke9 = combinedDomainXYPlot0.getDomainCrosshairStroke();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.setRangeCrosshairValue(0.0d);
        categoryPlot4.setCrosshairDatasetIndex(31);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation(100, axisLocation7);
        int int9 = categoryPlot4.getWeight();
        java.awt.Paint paint10 = categoryPlot4.getRangeGridlinePaint();
        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot4.getRangeAxisForDataset((int) (short) 100);
        org.jfree.chart.LegendItemCollection legendItemCollection13 = categoryPlot4.getLegendItems();
        org.jfree.chart.renderer.xy.GradientXYBarPainter gradientXYBarPainter14 = new org.jfree.chart.renderer.xy.GradientXYBarPainter();
        boolean boolean15 = legendItemCollection13.equals((java.lang.Object) gradientXYBarPainter14);
        int int16 = legendItemCollection13.getItemCount();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNotNull(legendItemCollection13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("($1.00)", graphics2D1, (float) (-458), (float) 15, 8.0d, (float) (short) 10, 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0);
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        int int7 = categoryPlot6.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation9 = null;
        categoryPlot6.setRangeAxisLocation(100, axisLocation9);
        timeSeriesCollection1.removeChangeListener((org.jfree.data.general.DatasetChangeListener) categoryPlot6);
        timeSeriesCollection1.validateObject();
        try {
            double double15 = timeSeriesCollection1.getStartXValue((int) (short) 1, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

//    @Test
//    public void test164() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test164");
//        double[][] doubleArray2 = new double[][] {};
//        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("null", "LengthConstraintType.FIXED", doubleArray2);
//        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D5 = new org.jfree.chart.axis.CategoryAxis3D("ERROR : Relative To String");
//        categoryAxis3D5.clearCategoryLabelToolTips();
//        categoryAxis3D5.configure();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date11 = spreadsheetDate10.toDate();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        long long14 = day13.getLastMillisecond();
//        org.jfree.chart.axis.PeriodAxis periodAxis15 = new org.jfree.chart.axis.PeriodAxis("$8.00", (org.jfree.data.time.RegularTimePeriod) day12, (org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D5, (org.jfree.chart.axis.ValueAxis) periodAxis15, categoryItemRenderer16);
//        org.jfree.data.KeyToGroupMap keyToGroupMap18 = null;
//        try {
//            org.jfree.data.Range range19 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset3, keyToGroupMap18);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(doubleArray2);
//        org.junit.Assert.assertNotNull(categoryDataset3);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560495599999L + "'", long14 == 1560495599999L);
//    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 1, (float) 6);
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.clone(shape2);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=0,g=255,b=0]");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer2 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer2.clearSeriesStrokes(true);
        java.awt.Stroke stroke6 = xYBarRenderer2.lookupSeriesOutlineStroke(100);
        xYBarRenderer2.setShadowXOffset((double) 100.0f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState11 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo10);
        java.awt.geom.Line2D line2D12 = xYItemRendererState11.workingLine;
        xYBarRenderer2.setLegendShape(0, (java.awt.Shape) line2D12);
        numberAxis1.setRightArrow((java.awt.Shape) line2D12);
        org.jfree.data.RangeType rangeType15 = org.jfree.data.RangeType.FULL;
        numberAxis1.setRangeType(rangeType15);
        double double17 = numberAxis1.getUpperBound();
        numberAxis1.setFixedAutoRange((double) 25566L);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(line2D12);
        org.junit.Assert.assertNotNull(rangeType15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.clearSeriesStrokes(true);
        java.awt.Stroke stroke4 = xYBarRenderer0.lookupSeriesOutlineStroke(100);
        java.awt.Paint paint5 = xYBarRenderer0.getBaseFillPaint();
        double double6 = xYBarRenderer0.getBarAlignmentFactor();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=0,g=255,b=0]");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer2 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer2.clearSeriesStrokes(true);
        java.awt.Stroke stroke6 = xYBarRenderer2.lookupSeriesOutlineStroke(100);
        xYBarRenderer2.setShadowXOffset((double) 100.0f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState11 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo10);
        java.awt.geom.Line2D line2D12 = xYItemRendererState11.workingLine;
        xYBarRenderer2.setLegendShape(0, (java.awt.Shape) line2D12);
        numberAxis1.setRightArrow((java.awt.Shape) line2D12);
        org.jfree.data.RangeType rangeType15 = org.jfree.data.RangeType.FULL;
        numberAxis1.setRangeType(rangeType15);
        float float17 = numberAxis1.getTickMarkInsideLength();
        numberAxis1.configure();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(line2D12);
        org.junit.Assert.assertNotNull(rangeType15);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.0f + "'", float17 == 0.0f);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.data.Range range2 = xYStepRenderer0.findDomainBounds(xYDataset1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = null;
        xYStepRenderer0.setBaseToolTipGenerator(xYToolTipGenerator3);
        boolean boolean5 = xYStepRenderer0.getBaseShapesVisible();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator6 = null;
        xYStepRenderer0.setBaseToolTipGenerator(xYToolTipGenerator6, true);
        java.awt.Stroke stroke10 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        xYStepRenderer0.setSeriesOutlineStroke((int) (short) 1, stroke10);
        org.jfree.data.general.WaferMapDataset waferMapDataset12 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot13 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset12);
        java.awt.Font font14 = waferMapPlot13.getNoDataMessageFont();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent15 = null;
        waferMapPlot13.notifyListeners(plotChangeEvent15);
        boolean boolean17 = xYStepRenderer0.hasListener((java.util.EventListener) waferMapPlot13);
        xYStepRenderer0.clearSeriesStrokes(true);
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.Color color2 = color1.darker();
        java.awt.Color color3 = java.awt.Color.getColor("$8.00", color2);
        int int4 = color2.getAlpha();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 255 + "'", int4 == 255);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        int int2 = combinedDomainXYPlot0.getDomainAxisIndex(valueAxis1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = combinedDomainXYPlot0.getDomainAxisIndex(valueAxis3);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        combinedDomainXYPlot0.setRangeAxis(10, valueAxis6);
        boolean boolean8 = combinedDomainXYPlot0.canSelectByRegion();
        java.awt.Paint paint9 = combinedDomainXYPlot0.getDomainTickBandPaint();
        boolean boolean10 = combinedDomainXYPlot0.isRangeZoomable();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        org.jfree.chart.text.TextFragment textFragment1 = textLine0.getLastTextFragment();
        org.junit.Assert.assertNull(textFragment1);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot2 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = combinedDomainXYPlot2.getDomainAxisIndex(valueAxis3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = combinedDomainXYPlot2.getRangeAxis();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("WMAP_Plot", font1, (org.jfree.chart.plot.Plot) combinedDomainXYPlot2, true);
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle9.setMaximumLinesToDisplay(1);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, categoryItemRenderer15);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot16.getDomainAxisEdge();
        textTitle9.setPosition(rectangleEdge17);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = textTitle9.getPadding();
        jFreeChart7.removeSubtitle((org.jfree.chart.title.Title) textTitle9);
        org.jfree.chart.title.LegendTitle legendTitle21 = jFreeChart7.getLegend();
        org.jfree.chart.block.BlockContainer blockContainer22 = legendTitle21.getItemContainer();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment23 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment24 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.ColumnArrangement columnArrangement27 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment23, verticalAlignment24, 0.0d, (double) 100);
        blockContainer22.setArrangement((org.jfree.chart.block.Arrangement) columnArrangement27);
        java.util.TimeZone timeZone29 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection30 = new org.jfree.data.time.TimeSeriesCollection(timeZone29);
        org.jfree.data.Range range32 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection30, true);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer34 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement27, (org.jfree.data.general.Dataset) timeSeriesCollection30, (java.lang.Comparable) 2147483647);
        legendItemBlockContainer34.setURLText("");
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(legendTitle21);
        org.junit.Assert.assertNotNull(blockContainer22);
        org.junit.Assert.assertNotNull(horizontalAlignment23);
        org.junit.Assert.assertNotNull(verticalAlignment24);
        org.junit.Assert.assertNull(range32);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) (short) -1, (float) 1L);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape2, rectangleAnchor3, (double) (short) 0, (double) 1);
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis9, categoryItemRenderer10);
        int int12 = categoryPlot11.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation14 = null;
        categoryPlot11.setRangeAxisLocation(100, axisLocation14);
        int int16 = categoryPlot11.getWeight();
        java.awt.Paint paint17 = categoryPlot11.getRangeGridlinePaint();
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.data.Range range19 = categoryPlot11.getDataRange(valueAxis18);
        java.awt.Stroke stroke20 = categoryPlot11.getRangeMinorGridlineStroke();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D23 = new org.jfree.chart.axis.CategoryAxis3D("ERROR : Relative To String");
        categoryAxis3D23.clearCategoryLabelToolTips();
        categoryPlot11.setDomainAxis((int) '#', (org.jfree.chart.axis.CategoryAxis) categoryAxis3D23, false);
        java.awt.Font font27 = categoryAxis3D23.getLabelFont();
        float float28 = categoryAxis3D23.getTickMarkInsideLength();
        org.jfree.chart.entity.AxisEntity axisEntity29 = new org.jfree.chart.entity.AxisEntity(shape2, (org.jfree.chart.axis.Axis) categoryAxis3D23);
        java.awt.Graphics2D graphics2D30 = null;
        org.jfree.data.category.CategoryDataset categoryDataset31 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = null;
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset31, categoryAxis32, valueAxis33, categoryItemRenderer34);
        int int36 = categoryPlot35.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation38 = null;
        categoryPlot35.setRangeAxisLocation(100, axisLocation38);
        int int40 = categoryPlot35.getWeight();
        java.awt.Paint paint41 = categoryPlot35.getRangeGridlinePaint();
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = null;
        org.jfree.chart.axis.AxisSpace axisSpace44 = new org.jfree.chart.axis.AxisSpace();
        try {
            org.jfree.chart.axis.AxisSpace axisSpace45 = categoryAxis3D23.reserveSpace(graphics2D30, (org.jfree.chart.plot.Plot) categoryPlot35, rectangle2D42, rectangleEdge43, axisSpace44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNull(range19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertTrue("'" + float28 + "' != '" + 0.0f + "'", float28 == 0.0f);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(paint41);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!");
        java.text.NumberFormat numberFormat4 = java.text.NumberFormat.getCurrencyInstance();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = new org.jfree.chart.axis.NumberTickUnit((double) 100L, numberFormat4);
        java.lang.String str7 = numberFormat4.format((long) 8);
        boolean boolean8 = numberFormat4.isGroupingUsed();
        int int9 = numberFormat4.getMaximumFractionDigits();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit11 = new org.jfree.chart.axis.NumberTickUnit((double) 0.0f, numberFormat4, 2147483647);
        logAxis1.setTickUnit(numberTickUnit11, true, true);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis17, categoryItemRenderer18);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = categoryPlot19.getDomainAxisEdge();
        java.awt.Paint paint21 = categoryPlot19.getOutlinePaint();
        categoryPlot19.setRangeZeroBaselineVisible(false);
        java.awt.Font font26 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot27 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        int int29 = combinedDomainXYPlot27.getDomainAxisIndex(valueAxis28);
        org.jfree.chart.axis.ValueAxis valueAxis30 = combinedDomainXYPlot27.getRangeAxis();
        org.jfree.chart.JFreeChart jFreeChart32 = new org.jfree.chart.JFreeChart("WMAP_Plot", font26, (org.jfree.chart.plot.Plot) combinedDomainXYPlot27, true);
        org.jfree.chart.block.LabelBlock labelBlock33 = new org.jfree.chart.block.LabelBlock("{0}: ({1}, {2})", font26);
        categoryPlot19.setNoDataMessageFont(font26);
        int int35 = numberTickUnit11.compareTo((java.lang.Object) categoryPlot19);
        org.junit.Assert.assertNotNull(numberFormat4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "$8.00" + "'", str7.equals("$8.00"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNull(valueAxis30);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset) defaultPieDataset0);
        java.awt.Stroke stroke2 = ringPlot1.getLabelLinkStroke();
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.data.Range range2 = xYBarRenderer0.findRangeBounds(xYDataset1);
        org.jfree.chart.LegendItem legendItem5 = xYBarRenderer0.getLegendItem((int) (byte) -1, 7);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer6 = null;
        xYBarRenderer0.setGradientPaintTransformer(gradientPaintTransformer6);
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertNull(legendItem5);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        java.text.NumberFormat numberFormat2 = java.text.NumberFormat.getCurrencyInstance();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = new org.jfree.chart.axis.NumberTickUnit((double) 100L, numberFormat2);
        java.lang.String str5 = numberFormat2.format((long) 8);
        boolean boolean6 = numberFormat2.isGroupingUsed();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit8 = new org.jfree.chart.axis.NumberTickUnit((double) (-1), numberFormat2, (int) (short) 1);
        org.junit.Assert.assertNotNull(numberFormat2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "$8.00" + "'", str5.equals("$8.00"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("TextBlockAnchor.BOTTOM_RIGHT");
        periodAxis1.setMinorTickMarkInsideLength((float) 12);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.data.Range range2 = xYStepRenderer0.findDomainBounds(xYDataset1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = null;
        xYStepRenderer0.setBaseToolTipGenerator(xYToolTipGenerator3);
        boolean boolean5 = xYStepRenderer0.getBaseShapesVisible();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator6 = null;
        xYStepRenderer0.setBaseToolTipGenerator(xYToolTipGenerator6, true);
        java.awt.Stroke stroke10 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        xYStepRenderer0.setSeriesOutlineStroke((int) (short) 1, stroke10);
        int int12 = xYStepRenderer0.getPassCount();
        java.awt.Paint paint16 = xYStepRenderer0.getItemFillPaint(8, (int) (short) 10, false);
        xYStepRenderer0.setBaseCreateEntities(false, false);
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date3 = spreadsheetDate2.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date6 = spreadsheetDate5.toDate();
        boolean boolean7 = spreadsheetDate2.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        spreadsheetDate2.setDescription("hi!");
        int int10 = spreadsheetDate2.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date13 = spreadsheetDate12.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date16 = spreadsheetDate15.toDate();
        boolean boolean17 = spreadsheetDate12.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SerialDate serialDate18 = spreadsheetDate2.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addYears(100, serialDate18);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate19);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        int int2 = combinedDomainXYPlot0.getDomainAxisIndex(valueAxis1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = combinedDomainXYPlot0.getRangeAxisIndex(valueAxis3);
        java.awt.Paint paint5 = combinedDomainXYPlot0.getDomainZeroBaselinePaint();
        boolean boolean6 = combinedDomainXYPlot0.isDomainZeroBaselineVisible();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder7 = combinedDomainXYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation8 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        combinedDomainXYPlot0.setRangeAxisLocation(axisLocation8, true);
        int int11 = combinedDomainXYPlot0.getRangeAxisCount();
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer12 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.data.Range range14 = xYStepRenderer12.findDomainBounds(xYDataset13);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator15 = null;
        xYStepRenderer12.setBaseToolTipGenerator(xYToolTipGenerator15);
        org.jfree.data.general.WaferMapDataset waferMapDataset18 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot19 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset18);
        java.awt.Paint paint20 = waferMapPlot19.getOutlinePaint();
        xYStepRenderer12.setSeriesFillPaint(100, paint20, false);
        combinedDomainXYPlot0.setRangeCrosshairPaint(paint20);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(seriesRenderingOrder7);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        int int2 = combinedDomainXYPlot0.getDomainAxisIndex(valueAxis1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = combinedDomainXYPlot0.getRangeAxis();
        boolean boolean4 = combinedDomainXYPlot0.isSubplot();
        combinedDomainXYPlot0.setRangeMinorGridlinesVisible(false);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer7 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer7.clearSeriesStrokes(true);
        java.awt.Stroke stroke11 = xYBarRenderer7.lookupSeriesOutlineStroke(100);
        xYBarRenderer7.setShadowXOffset((double) 100.0f);
        java.awt.Stroke stroke14 = xYBarRenderer7.getBaseOutlineStroke();
        boolean boolean15 = xYBarRenderer7.getBaseItemLabelsVisible();
        combinedDomainXYPlot0.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer7);
        java.awt.Paint paint17 = combinedDomainXYPlot0.getRangeTickBandPaint();
        java.util.TimeZone timeZone19 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection20 = new org.jfree.data.time.TimeSeriesCollection(timeZone19);
        org.jfree.data.Range range22 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection20, true);
        combinedDomainXYPlot0.setDataset(1, (org.jfree.data.xy.XYDataset) timeSeriesCollection20);
        try {
            int[] intArray27 = org.jfree.chart.renderer.RendererUtilities.findLiveItems((org.jfree.data.xy.XYDataset) timeSeriesCollection20, 255, (double) (-4126), (double) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (255).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertNull(range22);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        int int2 = combinedDomainXYPlot0.getDomainAxisIndex(valueAxis1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = combinedDomainXYPlot0.getRangeAxis();
        boolean boolean4 = combinedDomainXYPlot0.isSubplot();
        combinedDomainXYPlot0.setRangeMinorGridlinesVisible(false);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer7 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer7.clearSeriesStrokes(true);
        java.awt.Stroke stroke11 = xYBarRenderer7.lookupSeriesOutlineStroke(100);
        xYBarRenderer7.setShadowXOffset((double) 100.0f);
        java.awt.Stroke stroke14 = xYBarRenderer7.getBaseOutlineStroke();
        boolean boolean15 = xYBarRenderer7.getBaseItemLabelsVisible();
        combinedDomainXYPlot0.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer7);
        java.awt.Paint paint17 = combinedDomainXYPlot0.getRangeTickBandPaint();
        java.awt.Paint paint19 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer20 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer20.clearSeriesStrokes(true);
        java.awt.Stroke stroke24 = xYBarRenderer20.lookupSeriesOutlineStroke(100);
        xYBarRenderer20.setShadowXOffset((double) 100.0f);
        java.awt.Stroke stroke27 = xYBarRenderer20.getBaseOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker28 = new org.jfree.chart.plot.ValueMarker(0.05d, paint19, stroke27);
        org.jfree.chart.text.TextAnchor textAnchor29 = valueMarker28.getLabelTextAnchor();
        java.awt.Font font30 = valueMarker28.getLabelFont();
        java.awt.Paint paint31 = valueMarker28.getOutlinePaint();
        combinedDomainXYPlot0.setRangeMinorGridlinePaint(paint31);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(textAnchor29);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertNotNull(paint31);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "org.jfree.data.UnknownKeyException: TextBlockAnchor.TOP_RIGHT", "ItemLabelAnchor.INSIDE7", "DomainOrder.NONE");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date6 = spreadsheetDate5.toDate();
        java.util.Date date7 = spreadsheetDate5.toDate();
        java.util.TimeZone timeZone8 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date7, timeZone8);
        int int10 = month9.getYearValue();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month9, (java.lang.Number) 0.0f, false);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(5, 1900);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month16, 2.0d, true);
        java.util.Calendar calendar20 = null;
        try {
            month16.peg(calendar20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1900 + "'", int10 == 1900);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation(100, axisLocation7);
        int int9 = categoryPlot4.getWeight();
        java.awt.Paint paint10 = categoryPlot4.getRangeGridlinePaint();
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.data.Range range12 = categoryPlot4.getDataRange(valueAxis11);
        java.awt.Stroke stroke13 = categoryPlot4.getRangeMinorGridlineStroke();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D16 = new org.jfree.chart.axis.CategoryAxis3D("ERROR : Relative To String");
        categoryAxis3D16.clearCategoryLabelToolTips();
        categoryPlot4.setDomainAxis((int) '#', (org.jfree.chart.axis.CategoryAxis) categoryAxis3D16, false);
        categoryAxis3D16.setCategoryMargin((double) 7);
        categoryAxis3D16.setMaximumCategoryLabelWidthRatio((float) (short) 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray1 = null;
        java.awt.Paint[] paintArray2 = null;
        java.awt.Paint[] paintArray3 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Stroke[] strokeArray5 = new java.awt.Stroke[] { stroke4 };
        java.awt.Stroke[] strokeArray6 = new java.awt.Stroke[] {};
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) (short) -1, (float) 1L);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape9, rectangleAnchor10, (double) (short) 0, (double) 1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState15 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo14);
        java.awt.geom.Line2D line2D16 = xYItemRendererState15.workingLine;
        java.awt.Shape[] shapeArray17 = new java.awt.Shape[] { shape13, line2D16 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier18 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray1, paintArray2, paintArray3, strokeArray5, strokeArray6, shapeArray17);
        java.awt.Paint[] paintArray19 = null;
        java.awt.Paint[] paintArray20 = null;
        java.awt.Paint[] paintArray21 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Stroke[] strokeArray23 = new java.awt.Stroke[] { stroke22 };
        java.awt.Stroke[] strokeArray24 = new java.awt.Stroke[] {};
        java.awt.Shape shape27 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) (short) -1, (float) 1L);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor28 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape31 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape27, rectangleAnchor28, (double) (short) 0, (double) 1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState33 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo32);
        java.awt.geom.Line2D line2D34 = xYItemRendererState33.workingLine;
        java.awt.Shape[] shapeArray35 = new java.awt.Shape[] { shape31, line2D34 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier36 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray19, paintArray20, paintArray21, strokeArray23, strokeArray24, shapeArray35);
        java.awt.Stroke[] strokeArray37 = new java.awt.Stroke[] {};
        java.awt.Paint[] paintArray38 = null;
        java.awt.Paint[] paintArray39 = null;
        java.awt.Paint[] paintArray40 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Stroke stroke41 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Stroke[] strokeArray42 = new java.awt.Stroke[] { stroke41 };
        java.awt.Stroke[] strokeArray43 = new java.awt.Stroke[] {};
        java.awt.Shape shape46 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) (short) -1, (float) 1L);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor47 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape50 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape46, rectangleAnchor47, (double) (short) 0, (double) 1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo51 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState52 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo51);
        java.awt.geom.Line2D line2D53 = xYItemRendererState52.workingLine;
        java.awt.Shape[] shapeArray54 = new java.awt.Shape[] { shape50, line2D53 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier55 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray38, paintArray39, paintArray40, strokeArray42, strokeArray43, shapeArray54);
        java.awt.Paint[] paintArray56 = null;
        java.awt.Paint[] paintArray57 = null;
        java.awt.Paint[] paintArray58 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Stroke stroke59 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Stroke[] strokeArray60 = new java.awt.Stroke[] { stroke59 };
        java.awt.Stroke[] strokeArray61 = new java.awt.Stroke[] {};
        java.awt.Shape shape64 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) (short) -1, (float) 1L);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor65 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape68 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape64, rectangleAnchor65, (double) (short) 0, (double) 1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo69 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState70 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo69);
        java.awt.geom.Line2D line2D71 = xYItemRendererState70.workingLine;
        java.awt.Shape[] shapeArray72 = new java.awt.Shape[] { shape68, line2D71 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier73 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray56, paintArray57, paintArray58, strokeArray60, strokeArray61, shapeArray72);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier74 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, paintArray20, strokeArray37, strokeArray43, shapeArray72);
        try {
            java.awt.Paint paint75 = defaultDrawingSupplier74.getNextFillPaint();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(strokeArray5);
        org.junit.Assert.assertNotNull(strokeArray6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(rectangleAnchor10);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(line2D16);
        org.junit.Assert.assertNotNull(shapeArray17);
        org.junit.Assert.assertNotNull(paintArray21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(strokeArray23);
        org.junit.Assert.assertNotNull(strokeArray24);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(rectangleAnchor28);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(line2D34);
        org.junit.Assert.assertNotNull(shapeArray35);
        org.junit.Assert.assertNotNull(strokeArray37);
        org.junit.Assert.assertNotNull(paintArray40);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(strokeArray42);
        org.junit.Assert.assertNotNull(strokeArray43);
        org.junit.Assert.assertNotNull(shape46);
        org.junit.Assert.assertNotNull(rectangleAnchor47);
        org.junit.Assert.assertNotNull(shape50);
        org.junit.Assert.assertNotNull(line2D53);
        org.junit.Assert.assertNotNull(shapeArray54);
        org.junit.Assert.assertNotNull(paintArray58);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertNotNull(strokeArray60);
        org.junit.Assert.assertNotNull(strokeArray61);
        org.junit.Assert.assertNotNull(shape64);
        org.junit.Assert.assertNotNull(rectangleAnchor65);
        org.junit.Assert.assertNotNull(shape68);
        org.junit.Assert.assertNotNull(line2D71);
        org.junit.Assert.assertNotNull(shapeArray72);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer0.setBaseLinesVisible(true);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator4 = xYStepRenderer0.getSeriesItemLabelGenerator((int) '#');
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = xYStepRenderer0.getBasePositiveItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor6 = itemLabelPosition5.getRotationAnchor();
        org.junit.Assert.assertNull(xYItemLabelGenerator4);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date5 = spreadsheetDate4.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date8 = spreadsheetDate7.toDate();
        boolean boolean9 = spreadsheetDate4.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate7);
        boolean boolean10 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate7);
        java.lang.String str11 = spreadsheetDate1.toString();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "9-January-1900" + "'", str11.equals("9-January-1900"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot2 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = combinedDomainXYPlot2.getDomainAxisIndex(valueAxis3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = combinedDomainXYPlot2.getRangeAxis();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("WMAP_Plot", font1, (org.jfree.chart.plot.Plot) combinedDomainXYPlot2, true);
        boolean boolean8 = jFreeChart7.getAntiAlias();
        java.awt.Paint paint9 = jFreeChart7.getBorderPaint();
        java.awt.Image image10 = jFreeChart7.getBackgroundImage();
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, valueAxis13, categoryItemRenderer14);
        int int16 = categoryPlot15.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation18 = null;
        categoryPlot15.setRangeAxisLocation(100, axisLocation18);
        int int20 = categoryPlot15.getWeight();
        java.awt.Paint paint21 = categoryPlot15.getRangeGridlinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier22 = null;
        categoryPlot15.setDrawingSupplier(drawingSupplier22, false);
        boolean boolean25 = categoryPlot15.isSubplot();
        categoryPlot15.setRangeZeroBaselineVisible(true);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder28 = categoryPlot15.getDatasetRenderingOrder();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent29 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot15);
        jFreeChart7.plotChanged(plotChangeEvent29);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType31 = null;
        plotChangeEvent29.setType(chartChangeEventType31);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(image10);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder28);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("NOID");
        java.awt.Stroke stroke2 = numberAxis3D1.getTickMarkStroke();
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 7);
        java.lang.String str2 = xYSeries1.getDescription();
        org.jfree.data.xy.XYSeries xYSeries5 = xYSeries1.createCopy((int) 'a', (-1));
        int int6 = xYSeries5.getMaximumItemCount();
        boolean boolean7 = xYSeries5.getAutoSort();
        double double8 = xYSeries5.getMinY();
        xYSeries5.add((double) (byte) 100, 0.0d, false);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(xYSeries5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2147483647 + "'", int6 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean2 = textBlock0.equals((java.lang.Object) rectangleInsets1);
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine();
        org.jfree.chart.text.TextFragment textFragment4 = null;
        textLine3.removeFragment(textFragment4);
        org.jfree.chart.text.TextFragment textFragment6 = textLine3.getLastTextFragment();
        textBlock0.addLine(textLine3);
        org.jfree.chart.text.TextFragment textFragment9 = new org.jfree.chart.text.TextFragment("ERROR : Relative To String");
        textLine3.addFragment(textFragment9);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(textFragment6);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        int int2 = combinedDomainXYPlot0.getDomainAxisIndex(valueAxis1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = combinedDomainXYPlot0.getRangeAxis();
        boolean boolean4 = combinedDomainXYPlot0.isSubplot();
        combinedDomainXYPlot0.setRangeMinorGridlinesVisible(false);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer7 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer7.clearSeriesStrokes(true);
        java.awt.Stroke stroke11 = xYBarRenderer7.lookupSeriesOutlineStroke(100);
        xYBarRenderer7.setShadowXOffset((double) 100.0f);
        java.awt.Stroke stroke14 = xYBarRenderer7.getBaseOutlineStroke();
        boolean boolean15 = xYBarRenderer7.getBaseItemLabelsVisible();
        combinedDomainXYPlot0.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer7);
        java.awt.Paint paint17 = combinedDomainXYPlot0.getRangeTickBandPaint();
        combinedDomainXYPlot0.mapDatasetToDomainAxis(0, (int) (byte) 10);
        combinedDomainXYPlot0.setRangeGridlinesVisible(false);
        java.awt.Stroke stroke23 = combinedDomainXYPlot0.getRangeGridlineStroke();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertNotNull(stroke23);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot2 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = combinedDomainXYPlot2.getDomainAxisIndex(valueAxis3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = combinedDomainXYPlot2.getRangeAxis();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("WMAP_Plot", font1, (org.jfree.chart.plot.Plot) combinedDomainXYPlot2, true);
        boolean boolean8 = jFreeChart7.getAntiAlias();
        java.awt.Paint paint9 = jFreeChart7.getBorderPaint();
        java.awt.Image image10 = jFreeChart7.getBackgroundImage();
        jFreeChart7.setBackgroundImageAlpha((float) (-4126));
        org.jfree.chart.event.ChartChangeListener chartChangeListener13 = null;
        try {
            jFreeChart7.removeChangeListener(chartChangeListener13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(image10);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=0,g=255,b=0]");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer2 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer2.clearSeriesStrokes(true);
        java.awt.Stroke stroke6 = xYBarRenderer2.lookupSeriesOutlineStroke(100);
        xYBarRenderer2.setShadowXOffset((double) 100.0f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState11 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo10);
        java.awt.geom.Line2D line2D12 = xYItemRendererState11.workingLine;
        xYBarRenderer2.setLegendShape(0, (java.awt.Shape) line2D12);
        numberAxis1.setRightArrow((java.awt.Shape) line2D12);
        numberAxis1.setMinorTickMarksVisible(true);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot17 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        int int19 = combinedDomainXYPlot17.getDomainAxisIndex(valueAxis18);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        int int21 = combinedDomainXYPlot17.getRangeAxisIndex(valueAxis20);
        java.awt.Paint paint22 = combinedDomainXYPlot17.getDomainZeroBaselinePaint();
        boolean boolean23 = combinedDomainXYPlot17.isDomainZeroBaselineVisible();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder24 = combinedDomainXYPlot17.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation25 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        combinedDomainXYPlot17.setRangeAxisLocation(axisLocation25, true);
        numberAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) combinedDomainXYPlot17);
        org.jfree.data.general.DefaultPieDataset defaultPieDataset29 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset29.insertValue(0, (java.lang.Comparable) (-2208960000000L), (double) (byte) 10);
        boolean boolean34 = numberAxis1.equals((java.lang.Object) (byte) 10);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(line2D12);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(seriesRenderingOrder24);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.awt.Image image1 = projectInfo0.getLogo();
        projectInfo0.setLicenceName("hi!");
        projectInfo0.setCopyright("LengthConstraintType.FIXED");
        org.junit.Assert.assertNull(image1);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.data.Range range2 = xYStepRenderer0.findDomainBounds(xYDataset1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = null;
        xYStepRenderer0.setBaseToolTipGenerator(xYToolTipGenerator3);
        boolean boolean5 = xYStepRenderer0.getBaseShapesVisible();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator6 = null;
        xYStepRenderer0.setBaseToolTipGenerator(xYToolTipGenerator6, true);
        java.awt.Stroke stroke10 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        xYStepRenderer0.setSeriesOutlineStroke((int) (short) 1, stroke10);
        org.jfree.data.general.WaferMapDataset waferMapDataset12 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot13 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset12);
        java.awt.Font font14 = waferMapPlot13.getNoDataMessageFont();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent15 = null;
        waferMapPlot13.notifyListeners(plotChangeEvent15);
        boolean boolean17 = xYStepRenderer0.hasListener((java.util.EventListener) waferMapPlot13);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState19 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo18);
        java.awt.geom.Line2D line2D20 = xYItemRendererState19.workingLine;
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, valueAxis23, categoryItemRenderer24);
        int int26 = categoryPlot25.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation28 = null;
        categoryPlot25.setRangeAxisLocation(100, axisLocation28);
        int int30 = categoryPlot25.getWeight();
        java.awt.Paint paint31 = categoryPlot25.getRangeGridlinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier32 = null;
        categoryPlot25.setDrawingSupplier(drawingSupplier32, false);
        org.jfree.chart.entity.PlotEntity plotEntity35 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape) line2D20, (org.jfree.chart.plot.Plot) categoryPlot25);
        java.awt.Shape shape38 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) (short) -1, (float) 1L);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor39 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape42 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape38, rectangleAnchor39, (double) (short) 0, (double) 1);
        plotEntity35.setArea(shape38);
        xYStepRenderer0.setBaseLegendShape(shape38);
        org.jfree.chart.LegendItem legendItem47 = xYStepRenderer0.getLegendItem(3, 0);
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(line2D20);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(shape38);
        org.junit.Assert.assertNotNull(rectangleAnchor39);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertNull(legendItem47);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("java.awt.Color[r=0,g=255,b=0]");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = logAxis1.getTickUnit();
        logAxis1.setTickLabelsVisible(false);
        org.junit.Assert.assertNotNull(numberTickUnit2);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator0 = new org.jfree.chart.labels.StandardPieToolTipGenerator();
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.data.Range range2 = xYStepRenderer0.findDomainBounds(xYDataset1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = null;
        xYStepRenderer0.setBaseToolTipGenerator(xYToolTipGenerator3);
        boolean boolean5 = xYStepRenderer0.getBaseShapesVisible();
        double double6 = xYStepRenderer0.getStepPoint();
        org.jfree.chart.plot.XYPlot xYPlot7 = xYStepRenderer0.getPlot();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = xYStepRenderer0.getSeriesNegativeItemLabelPosition(0);
        java.awt.Paint paint11 = xYStepRenderer0.getSeriesFillPaint(2147483647);
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNull(xYPlot7);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNull(paint11);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=0,g=255,b=0]");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer2 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer2.clearSeriesStrokes(true);
        java.awt.Stroke stroke6 = xYBarRenderer2.lookupSeriesOutlineStroke(100);
        xYBarRenderer2.setShadowXOffset((double) 100.0f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState11 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo10);
        java.awt.geom.Line2D line2D12 = xYItemRendererState11.workingLine;
        xYBarRenderer2.setLegendShape(0, (java.awt.Shape) line2D12);
        numberAxis1.setRightArrow((java.awt.Shape) line2D12);
        org.jfree.chart.axis.TickUnitSource tickUnitSource15 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        numberAxis1.setStandardTickUnits(tickUnitSource15);
        java.text.NumberFormat numberFormat18 = java.text.NumberFormat.getCurrencyInstance();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit19 = new org.jfree.chart.axis.NumberTickUnit((double) 100L, numberFormat18);
        numberAxis1.setTickUnit(numberTickUnit19, true, false);
        double double23 = numberTickUnit19.getSize();
        double double24 = numberTickUnit19.getSize();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(line2D12);
        org.junit.Assert.assertNotNull(tickUnitSource15);
        org.junit.Assert.assertNotNull(numberFormat18);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 100.0d + "'", double23 == 100.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 100.0d + "'", double24 == 100.0d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset1 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset1.insertValue(0, (java.lang.Comparable) (-2208960000000L), (double) (byte) 10);
        org.jfree.data.category.CategoryDataset categoryDataset6 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) 100.0f, (org.jfree.data.KeyedValues) defaultPieDataset1);
        org.junit.Assert.assertNotNull(categoryDataset6);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getPercentInstance();
        org.junit.Assert.assertNotNull(numberFormat0);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        double double1 = xYStepAreaRenderer0.getRangeBase();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("WMAP_Plot", graphics2D1, (float) (-1L), (float) (byte) 100, 0.0d, 0.0f, 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 2147483647, (double) 1.0f, 0.0d, (double) 1L);
        double double6 = rectangleInsets4.calculateRightInset((double) 2);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("ERROR : Relative To String");
        categoryAxis3D1.setCategoryMargin((double) 10L);
        java.lang.Comparable comparable4 = null;
        try {
            categoryAxis3D1.addCategoryLabelToolTip(comparable4, "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        int int2 = combinedDomainXYPlot0.getDomainAxisIndex(valueAxis1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = combinedDomainXYPlot0.getRangeAxis();
        boolean boolean4 = combinedDomainXYPlot0.isSubplot();
        java.awt.Stroke stroke5 = combinedDomainXYPlot0.getRangeMinorGridlineStroke();
        java.util.List list6 = combinedDomainXYPlot0.getAnnotations();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(list6);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = categoryPlot4.getDomainAxisEdge();
        java.awt.Paint paint6 = categoryPlot4.getNoDataMessagePaint();
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = categoryPlot4.getOrientation();
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(plotOrientation7);
    }

//    @Test
//    public void test212() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test212");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date3 = spreadsheetDate2.toDate();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        long long6 = day5.getLastMillisecond();
//        org.jfree.chart.axis.PeriodAxis periodAxis7 = new org.jfree.chart.axis.PeriodAxis("$8.00", (org.jfree.data.time.RegularTimePeriod) day4, (org.jfree.data.time.RegularTimePeriod) day5);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date10 = spreadsheetDate9.toDate();
//        java.util.Date date11 = spreadsheetDate9.toDate();
//        java.util.TimeZone timeZone12 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date11, timeZone12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month13.previous();
//        periodAxis7.setFirst((org.jfree.data.time.RegularTimePeriod) month13);
//        periodAxis7.setMinorTickMarkInsideLength((float) (-2208960000000L));
//        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray18 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] {};
//        periodAxis7.setLabelInfo(periodAxisLabelInfoArray18);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560495599999L + "'", long6 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(timeZone12);
//        org.junit.Assert.assertNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray18);
//    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.data.Range range2 = xYStepRenderer0.findDomainBounds(xYDataset1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.LIGHT_RED;
        xYStepRenderer0.setBasePaint((java.awt.Paint) color3, true);
        java.awt.Font font6 = xYStepRenderer0.getBaseLegendTextFont();
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(font6);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer0.setBaseLinesVisible(true);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator4 = xYStepRenderer0.getSeriesItemLabelGenerator((int) '#');
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator8 = xYStepRenderer0.getItemLabelGenerator((int) (byte) 100, (-1), false);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator9 = null;
        xYStepRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator9);
        java.awt.Stroke stroke12 = xYStepRenderer0.getSeriesOutlineStroke(4);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, categoryItemRenderer16);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = categoryPlot17.getDomainAxis();
        categoryPlot17.setRangeCrosshairValue((double) (-1), false);
        boolean boolean22 = xYStepRenderer0.equals((java.lang.Object) categoryPlot17);
        org.junit.Assert.assertNull(xYItemLabelGenerator4);
        org.junit.Assert.assertNull(xYItemLabelGenerator8);
        org.junit.Assert.assertNull(stroke12);
        org.junit.Assert.assertNull(categoryAxis18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        java.awt.Stroke stroke0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation(100, axisLocation7);
        int int9 = categoryPlot4.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = categoryPlot4.getDomainAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot4.zoomRangeAxes((double) 10.0f, plotRenderingInfo12, point2D13, false);
        java.lang.Comparable comparable16 = categoryPlot4.getDomainCrosshairColumnKey();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNull(comparable16);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 7);
        java.lang.String str2 = xYSeries1.getDescription();
        org.jfree.data.xy.XYSeries xYSeries5 = xYSeries1.createCopy((int) 'a', (-1));
        double double6 = xYSeries1.getMaxY();
        int int7 = xYSeries1.getItemCount();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(xYSeries5);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        java.util.Date date3 = spreadsheetDate1.toDate();
        java.util.TimeZone timeZone4 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date3, timeZone4);
        java.lang.Number number6 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, number6);
        long long8 = month5.getSerialIndex();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 22801L + "'", long8 == 22801L);
    }

//    @Test
//    public void test219() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test219");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date3 = spreadsheetDate2.toDate();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        long long6 = day5.getLastMillisecond();
//        org.jfree.chart.axis.PeriodAxis periodAxis7 = new org.jfree.chart.axis.PeriodAxis("$8.00", (org.jfree.data.time.RegularTimePeriod) day4, (org.jfree.data.time.RegularTimePeriod) day5);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date10 = spreadsheetDate9.toDate();
//        java.util.Date date11 = spreadsheetDate9.toDate();
//        java.util.TimeZone timeZone12 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date11, timeZone12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month13.previous();
//        periodAxis7.setFirst((org.jfree.data.time.RegularTimePeriod) month13);
//        java.util.Locale locale16 = periodAxis7.getLocale();
//        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = org.jfree.chart.axis.LogAxis.createLogTickUnits(locale16);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560495599999L + "'", long6 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(timeZone12);
//        org.junit.Assert.assertNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(locale16);
//        org.junit.Assert.assertNotNull(tickUnitSource17);
//    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.data.time.DateRange dateRange0 = new org.jfree.data.time.DateRange();
        long long1 = dateRange0.getUpperMillis();
        org.jfree.data.Range range3 = org.jfree.data.Range.scale((org.jfree.data.Range) dateRange0, (double) 100.0f);
        org.jfree.data.Range range5 = org.jfree.data.Range.expandToInclude(range3, 3.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(range5);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        int int2 = combinedDomainXYPlot0.getDomainAxisIndex(valueAxis1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = combinedDomainXYPlot0.getRangeAxisIndex(valueAxis3);
        java.awt.Paint paint5 = combinedDomainXYPlot0.getDomainZeroBaselinePaint();
        boolean boolean6 = combinedDomainXYPlot0.isDomainZeroBaselineVisible();
        org.jfree.chart.util.Layer layer7 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection8 = combinedDomainXYPlot0.getRangeMarkers(layer7);
        boolean boolean9 = combinedDomainXYPlot0.isDomainZeroBaselineVisible();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot10 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        int int12 = combinedDomainXYPlot10.getDomainAxisIndex(valueAxis11);
        org.jfree.chart.axis.ValueAxis valueAxis13 = combinedDomainXYPlot10.getRangeAxis();
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, valueAxis16, categoryItemRenderer17);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = categoryPlot18.getDomainAxisEdge();
        java.awt.Paint paint20 = categoryPlot18.getOutlinePaint();
        java.awt.Paint paint23 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer24 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer24.clearSeriesStrokes(true);
        java.awt.Stroke stroke28 = xYBarRenderer24.lookupSeriesOutlineStroke(100);
        xYBarRenderer24.setShadowXOffset((double) 100.0f);
        java.awt.Stroke stroke31 = xYBarRenderer24.getBaseOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker32 = new org.jfree.chart.plot.ValueMarker(0.05d, paint23, stroke31);
        float float33 = valueMarker32.getAlpha();
        org.jfree.chart.util.Layer layer34 = null;
        boolean boolean35 = categoryPlot18.removeRangeMarker(100, (org.jfree.chart.plot.Marker) valueMarker32, layer34);
        org.jfree.chart.text.TextAnchor textAnchor36 = valueMarker32.getLabelTextAnchor();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot37 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        int int39 = combinedDomainXYPlot37.getDomainAxisIndex(valueAxis38);
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        int int41 = combinedDomainXYPlot37.getRangeAxisIndex(valueAxis40);
        java.awt.Paint paint42 = combinedDomainXYPlot37.getDomainZeroBaselinePaint();
        boolean boolean43 = combinedDomainXYPlot37.isDomainZeroBaselineVisible();
        org.jfree.chart.util.Layer layer44 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection45 = combinedDomainXYPlot37.getRangeMarkers(layer44);
        combinedDomainXYPlot10.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker32, layer44);
        org.jfree.chart.plot.Marker marker48 = null;
        org.jfree.chart.util.Layer layer49 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean51 = combinedDomainXYPlot10.removeDomainMarker(1, marker48, layer49, false);
        combinedDomainXYPlot10.clearSelection();
        combinedDomainXYPlot0.add((org.jfree.chart.plot.XYPlot) combinedDomainXYPlot10, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(layer7);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNull(valueAxis13);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 1.0f + "'", float33 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(textAnchor36);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(layer44);
        org.junit.Assert.assertNull(collection45);
        org.junit.Assert.assertNotNull(layer49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_HORIZONTAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo7 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "", "ERROR : Relative To String", "hi!", "ERROR : Relative To String");
        basicProjectInfo7.setLicenceName("");
        basicProjectInfo7.setLicenceName("$8.00");
        java.lang.String str12 = basicProjectInfo7.getCopyright();
        boolean boolean13 = gradientPaintTransformType0.equals((java.lang.Object) basicProjectInfo7);
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 7);
        java.lang.String str2 = xYSeries1.getDescription();
        xYSeries1.add((java.lang.Number) (-1), (java.lang.Number) (byte) 0);
        java.util.List list6 = xYSeries1.getItems();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(list6);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.awt.Image image1 = projectInfo0.getLogo();
        projectInfo0.addOptionalLibrary("ERROR : Relative To String");
        java.util.List list4 = projectInfo0.getContributors();
        org.junit.Assert.assertNull(image1);
        org.junit.Assert.assertNull(list4);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        int int2 = combinedDomainXYPlot0.getDomainAxisIndex(valueAxis1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = combinedDomainXYPlot0.getRangeAxis();
        boolean boolean4 = combinedDomainXYPlot0.isSubplot();
        java.awt.Stroke stroke5 = combinedDomainXYPlot0.getRangeMinorGridlineStroke();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot6 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot7 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        int int9 = combinedDomainXYPlot7.getDomainAxisIndex(valueAxis8);
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        int int11 = combinedDomainXYPlot7.getRangeAxisIndex(valueAxis10);
        java.awt.Paint paint12 = combinedDomainXYPlot7.getDomainZeroBaselinePaint();
        java.awt.Stroke stroke13 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        combinedDomainXYPlot7.setRangeZeroBaselineStroke(stroke13);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = combinedDomainXYPlot7.getRendererForDataset(xYDataset15);
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        combinedDomainXYPlot7.setRangeAxisLocation(0, axisLocation18);
        combinedDomainXYPlot6.setRangeAxisLocation(axisLocation18, true);
        combinedDomainXYPlot0.setDomainAxisLocation(axisLocation18);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNull(xYItemRenderer16);
        org.junit.Assert.assertNotNull(axisLocation18);
    }

//    @Test
//    public void test227() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test227");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date3 = spreadsheetDate2.toDate();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        long long6 = day5.getLastMillisecond();
//        org.jfree.chart.axis.PeriodAxis periodAxis7 = new org.jfree.chart.axis.PeriodAxis("$8.00", (org.jfree.data.time.RegularTimePeriod) day4, (org.jfree.data.time.RegularTimePeriod) day5);
//        java.awt.Paint paint8 = periodAxis7.getTickMarkPaint();
//        periodAxis7.setFixedAutoRange((double) 4);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = null;
//        try {
//            periodAxis7.setFirst(regularTimePeriod11);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'first' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560495599999L + "'", long6 == 1560495599999L);
//        org.junit.Assert.assertNotNull(paint8);
//    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setMinimumArcAngleToDraw((double) 9999);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer0.setBaseLinesVisible(true);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator4 = xYStepRenderer0.getSeriesItemLabelGenerator((int) '#');
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = xYStepRenderer0.getBasePositiveItemLabelPosition();
        xYStepRenderer0.setSeriesShapesVisible((int) (byte) 0, false);
        java.awt.Shape shape10 = xYStepRenderer0.getLegendShape(8);
        java.awt.Paint paint11 = xYStepRenderer0.getBasePaint();
        org.junit.Assert.assertNull(xYItemLabelGenerator4);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNull(shape10);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset) defaultPieDataset0);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator2 = null;
        ringPlot1.setURLGenerator(pieURLGenerator2);
        double double4 = ringPlot1.getInteriorGap();
        ringPlot1.setSeparatorsVisible(false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.08d + "'", double4 == 0.08d);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle1.setText("hi!");
        java.awt.Graphics2D graphics2D4 = null;
        try {
            org.jfree.chart.util.Size2D size2D5 = textTitle1.arrange(graphics2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Stroke stroke2 = null;
        xYBarRenderer0.setSeriesStroke(3, stroke2, false);
        boolean boolean6 = xYBarRenderer0.equals((java.lang.Object) '#');
        java.awt.Stroke stroke7 = null;
        try {
            xYBarRenderer0.setBaseOutlineStroke(stroke7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = categoryPlot4.getDomainAxisEdge();
        java.awt.Paint paint6 = categoryPlot4.getOutlinePaint();
        java.awt.Paint paint9 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer10 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer10.clearSeriesStrokes(true);
        java.awt.Stroke stroke14 = xYBarRenderer10.lookupSeriesOutlineStroke(100);
        xYBarRenderer10.setShadowXOffset((double) 100.0f);
        java.awt.Stroke stroke17 = xYBarRenderer10.getBaseOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker(0.05d, paint9, stroke17);
        float float19 = valueMarker18.getAlpha();
        org.jfree.chart.util.Layer layer20 = null;
        boolean boolean21 = categoryPlot4.removeRangeMarker(100, (org.jfree.chart.plot.Marker) valueMarker18, layer20);
        java.awt.Graphics2D graphics2D22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        org.jfree.chart.plot.CategoryCrosshairState categoryCrosshairState26 = null;
        boolean boolean27 = categoryPlot4.render(graphics2D22, rectangle2D23, 9999, plotRenderingInfo25, categoryCrosshairState26);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 1.0f + "'", float19 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=0,g=255,b=0]");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer2 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer2.clearSeriesStrokes(true);
        java.awt.Stroke stroke6 = xYBarRenderer2.lookupSeriesOutlineStroke(100);
        xYBarRenderer2.setShadowXOffset((double) 100.0f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState11 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo10);
        java.awt.geom.Line2D line2D12 = xYItemRendererState11.workingLine;
        xYBarRenderer2.setLegendShape(0, (java.awt.Shape) line2D12);
        numberAxis1.setRightArrow((java.awt.Shape) line2D12);
        org.jfree.chart.axis.TickUnitSource tickUnitSource15 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        numberAxis1.setStandardTickUnits(tickUnitSource15);
        java.text.NumberFormat numberFormat18 = java.text.NumberFormat.getCurrencyInstance();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit19 = new org.jfree.chart.axis.NumberTickUnit((double) 100L, numberFormat18);
        numberAxis1.setTickUnit(numberTickUnit19, true, false);
        java.lang.String str23 = numberTickUnit19.toString();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(line2D12);
        org.junit.Assert.assertNotNull(tickUnitSource15);
        org.junit.Assert.assertNotNull(numberFormat18);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "[size=$100.00]" + "'", str23.equals("[size=$100.00]"));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.POSITIVE;
        java.lang.Object obj1 = null;
        boolean boolean2 = rangeType0.equals(obj1);
        org.junit.Assert.assertNotNull(rangeType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.clearSeriesStrokes(true);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator3 = xYBarRenderer0.getBaseItemLabelGenerator();
        java.awt.Paint paint5 = xYBarRenderer0.lookupSeriesPaint(9999);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = xYBarRenderer0.getSeriesNegativeItemLabelPosition(6);
        org.jfree.data.time.TimeSeries timeSeries8 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection9 = new org.jfree.data.time.TimeSeriesCollection(timeSeries8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, valueAxis12, categoryItemRenderer13);
        int int15 = categoryPlot14.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation17 = null;
        categoryPlot14.setRangeAxisLocation(100, axisLocation17);
        timeSeriesCollection9.removeChangeListener((org.jfree.data.general.DatasetChangeListener) categoryPlot14);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate21 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection9, true);
        org.jfree.data.Range range22 = xYBarRenderer0.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection9);
        boolean boolean23 = xYBarRenderer0.getShadowsVisible();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator24 = xYBarRenderer0.getLegendItemURLGenerator();
        org.junit.Assert.assertNull(xYItemLabelGenerator3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNull(range22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator24);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.data.Range range2 = xYStepRenderer0.findDomainBounds(xYDataset1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = null;
        xYStepRenderer0.setBaseToolTipGenerator(xYToolTipGenerator3);
        org.jfree.data.general.WaferMapDataset waferMapDataset6 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot7 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset6);
        java.awt.Paint paint8 = waferMapPlot7.getOutlinePaint();
        xYStepRenderer0.setSeriesFillPaint(100, paint8, false);
        boolean boolean12 = xYStepRenderer0.isSeriesItemLabelsVisible(10);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator16 = xYStepRenderer0.getURLGenerator(2, (int) (byte) 100, false);
        boolean boolean19 = xYStepRenderer0.getItemShapeVisible((int) (byte) 10, (-458));
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator20 = xYStepRenderer0.getBaseToolTipGenerator();
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(xYURLGenerator16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(xYToolTipGenerator20);
    }

//    @Test
//    public void test239() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test239");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date3 = spreadsheetDate2.toDate();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        long long6 = day5.getLastMillisecond();
//        org.jfree.chart.axis.PeriodAxis periodAxis7 = new org.jfree.chart.axis.PeriodAxis("$8.00", (org.jfree.data.time.RegularTimePeriod) day4, (org.jfree.data.time.RegularTimePeriod) day5);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date10 = spreadsheetDate9.toDate();
//        java.util.Date date11 = spreadsheetDate9.toDate();
//        java.util.TimeZone timeZone12 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date11, timeZone12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month13.previous();
//        periodAxis7.setFirst((org.jfree.data.time.RegularTimePeriod) month13);
//        java.util.Locale locale16 = periodAxis7.getLocale();
//        java.text.NumberFormat numberFormat17 = java.text.NumberFormat.getCurrencyInstance(locale16);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560495599999L + "'", long6 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(timeZone12);
//        org.junit.Assert.assertNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(locale16);
//        org.junit.Assert.assertNotNull(numberFormat17);
//    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        int int1 = shapeList0.size();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        float float0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.5f + "'", float0 == 0.5f);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        int int2 = combinedDomainXYPlot0.getDomainAxisIndex(valueAxis1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = combinedDomainXYPlot0.getRangeAxis();
        combinedDomainXYPlot0.setNotify(true);
        java.awt.Paint paint7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        try {
            combinedDomainXYPlot0.setQuadrantPaint(100, paint7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (100) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.data.Range range2 = xYStepRenderer0.findDomainBounds(xYDataset1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = null;
        xYStepRenderer0.setBaseToolTipGenerator(xYToolTipGenerator3);
        boolean boolean5 = xYStepRenderer0.getBaseShapesVisible();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator6 = null;
        xYStepRenderer0.setBaseToolTipGenerator(xYToolTipGenerator6, true);
        java.text.DateFormat dateFormat10 = null;
        java.text.DateFormat dateFormat11 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator12 = new org.jfree.chart.labels.StandardXYToolTipGenerator("{0}: ({1}, {2})", dateFormat10, dateFormat11);
        xYStepRenderer0.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator12);
        java.text.NumberFormat numberFormat14 = standardXYToolTipGenerator12.getYFormat();
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(numberFormat14);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.data.time.DateRange dateRange1 = new org.jfree.data.time.DateRange();
        long long2 = dateRange1.getUpperMillis();
        org.jfree.data.Range range4 = org.jfree.data.Range.scale((org.jfree.data.Range) dateRange1, (double) 100.0f);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint(0.0d, (org.jfree.data.Range) dateRange1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
        org.junit.Assert.assertNotNull(range4);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.data.Range range2 = xYStepRenderer0.findDomainBounds(xYDataset1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = null;
        xYStepRenderer0.setBaseToolTipGenerator(xYToolTipGenerator3);
        boolean boolean5 = xYStepRenderer0.getBaseShapesVisible();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator6 = null;
        xYStepRenderer0.setBaseToolTipGenerator(xYToolTipGenerator6, true);
        java.awt.Stroke stroke10 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        xYStepRenderer0.setSeriesOutlineStroke((int) (short) 1, stroke10);
        org.jfree.data.general.WaferMapDataset waferMapDataset12 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot13 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset12);
        java.awt.Font font14 = waferMapPlot13.getNoDataMessageFont();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent15 = null;
        waferMapPlot13.notifyListeners(plotChangeEvent15);
        boolean boolean17 = xYStepRenderer0.hasListener((java.util.EventListener) waferMapPlot13);
        xYStepRenderer0.setBaseSeriesVisible(true);
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        int int2 = combinedDomainXYPlot0.getDomainAxisIndex(valueAxis1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = combinedDomainXYPlot0.getRangeAxis();
        boolean boolean4 = combinedDomainXYPlot0.isSubplot();
        combinedDomainXYPlot0.setRangeMinorGridlinesVisible(false);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer7 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer7.clearSeriesStrokes(true);
        java.awt.Stroke stroke11 = xYBarRenderer7.lookupSeriesOutlineStroke(100);
        xYBarRenderer7.setShadowXOffset((double) 100.0f);
        java.awt.Stroke stroke14 = xYBarRenderer7.getBaseOutlineStroke();
        boolean boolean15 = xYBarRenderer7.getBaseItemLabelsVisible();
        combinedDomainXYPlot0.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer7);
        java.awt.Paint paint17 = combinedDomainXYPlot0.getRangeTickBandPaint();
        combinedDomainXYPlot0.mapDatasetToDomainAxis(0, (int) (byte) 10);
        combinedDomainXYPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation23 = null;
        try {
            combinedDomainXYPlot0.addAnnotation(xYAnnotation23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(paint17);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation(100, axisLocation7);
        org.jfree.chart.plot.Marker marker9 = null;
        org.jfree.chart.util.Layer layer10 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean11 = categoryPlot4.removeDomainMarker(marker9, layer10);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, categoryItemRenderer15);
        int int17 = categoryPlot16.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation19 = null;
        categoryPlot16.setRangeAxisLocation(100, axisLocation19);
        org.jfree.chart.plot.Marker marker21 = null;
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean23 = categoryPlot16.removeDomainMarker(marker21, layer22);
        java.util.Collection collection24 = categoryPlot4.getRangeMarkers(layer22);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot26 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        int int28 = combinedDomainXYPlot26.getDomainAxisIndex(valueAxis27);
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        int int30 = combinedDomainXYPlot26.getRangeAxisIndex(valueAxis29);
        java.awt.Paint paint31 = combinedDomainXYPlot26.getDomainZeroBaselinePaint();
        boolean boolean32 = combinedDomainXYPlot26.isDomainZeroBaselineVisible();
        org.jfree.chart.util.Layer layer33 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection34 = combinedDomainXYPlot26.getRangeMarkers(layer33);
        java.util.List list35 = combinedDomainXYPlot26.getAnnotations();
        try {
            categoryPlot4.mapDatasetToRangeAxes(12, list35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Empty list not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(layer10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(layer33);
        org.junit.Assert.assertNull(collection34);
        org.junit.Assert.assertNotNull(list35);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.data.Range range2 = xYStepRenderer0.findDomainBounds(xYDataset1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = null;
        xYStepRenderer0.setBaseToolTipGenerator(xYToolTipGenerator3);
        boolean boolean5 = xYStepRenderer0.getBaseShapesVisible();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator6 = null;
        xYStepRenderer0.setBaseToolTipGenerator(xYToolTipGenerator6, true);
        java.text.DateFormat dateFormat10 = null;
        java.text.DateFormat dateFormat11 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator12 = new org.jfree.chart.labels.StandardXYToolTipGenerator("{0}: ({1}, {2})", dateFormat10, dateFormat11);
        xYStepRenderer0.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator12);
        java.awt.Paint paint15 = null;
        xYStepRenderer0.setSeriesFillPaint((int) (byte) 1, paint15);
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        int int2 = combinedDomainXYPlot0.getDomainAxisIndex(valueAxis1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = combinedDomainXYPlot0.getRangeAxisIndex(valueAxis3);
        java.awt.Paint paint5 = combinedDomainXYPlot0.getDomainZeroBaselinePaint();
        java.awt.Stroke stroke6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        combinedDomainXYPlot0.setRangeZeroBaselineStroke(stroke6);
        java.awt.Paint paint8 = combinedDomainXYPlot0.getDomainCrosshairPaint();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent9 = null;
        combinedDomainXYPlot0.notifyListeners(plotChangeEvent9);
        int int11 = combinedDomainXYPlot0.getSeriesCount();
        org.jfree.chart.axis.AxisSpace axisSpace12 = null;
        combinedDomainXYPlot0.setFixedRangeAxisSpace(axisSpace12);
        java.awt.Paint paint14 = combinedDomainXYPlot0.getDomainZeroBaselinePaint();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = categoryPlot4.getDomainAxisEdge();
        boolean boolean6 = categoryPlot4.isRangeGridlinesVisible();
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=0,g=255,b=0]");
        org.jfree.data.Range range9 = categoryPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis8);
        categoryPlot4.setNotify(true);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(range9);
    }

//    @Test
//    public void test253() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test253");
//        double[][] doubleArray2 = new double[][] {};
//        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("null", "LengthConstraintType.FIXED", doubleArray2);
//        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D5 = new org.jfree.chart.axis.CategoryAxis3D("ERROR : Relative To String");
//        categoryAxis3D5.clearCategoryLabelToolTips();
//        categoryAxis3D5.configure();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date11 = spreadsheetDate10.toDate();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        long long14 = day13.getLastMillisecond();
//        org.jfree.chart.axis.PeriodAxis periodAxis15 = new org.jfree.chart.axis.PeriodAxis("$8.00", (org.jfree.data.time.RegularTimePeriod) day12, (org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D5, (org.jfree.chart.axis.ValueAxis) periodAxis15, categoryItemRenderer16);
//        java.awt.Font font19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
//        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot20 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
//        int int22 = combinedDomainXYPlot20.getDomainAxisIndex(valueAxis21);
//        org.jfree.chart.axis.ValueAxis valueAxis23 = combinedDomainXYPlot20.getRangeAxis();
//        org.jfree.chart.JFreeChart jFreeChart25 = new org.jfree.chart.JFreeChart("WMAP_Plot", font19, (org.jfree.chart.plot.Plot) combinedDomainXYPlot20, true);
//        boolean boolean26 = jFreeChart25.getAntiAlias();
//        org.jfree.chart.title.TextTitle textTitle28 = new org.jfree.chart.title.TextTitle("hi!");
//        textTitle28.setMaximumLinesToDisplay(1);
//        org.jfree.data.category.CategoryDataset categoryDataset31 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis32 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset31, categoryAxis32, valueAxis33, categoryItemRenderer34);
//        org.jfree.chart.util.RectangleEdge rectangleEdge36 = categoryPlot35.getDomainAxisEdge();
//        textTitle28.setPosition(rectangleEdge36);
//        textTitle28.setPadding((double) '#', (double) (short) -1, 0.0d, (double) (byte) 10);
//        boolean boolean43 = jFreeChart25.equals((java.lang.Object) (byte) 10);
//        org.jfree.chart.text.TextBlock textBlock44 = new org.jfree.chart.text.TextBlock();
//        java.util.List list45 = textBlock44.getLines();
//        jFreeChart25.setSubtitles(list45);
//        org.jfree.data.Range range48 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset3, list45, true);
//        org.junit.Assert.assertNotNull(doubleArray2);
//        org.junit.Assert.assertNotNull(categoryDataset3);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560495599999L + "'", long14 == 1560495599999L);
//        org.junit.Assert.assertNotNull(font19);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
//        org.junit.Assert.assertNull(valueAxis23);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
//        org.junit.Assert.assertNotNull(rectangleEdge36);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertNotNull(list45);
//        org.junit.Assert.assertNull(range48);
//    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range3 = org.jfree.data.Range.combine(range1, range2);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint0.toRangeWidth(range3);
        org.jfree.data.time.DateRange dateRange7 = new org.jfree.data.time.DateRange((-1.0d), (double) (byte) 100);
        java.lang.String str8 = dateRange7.toString();
        boolean boolean9 = range3.intersects((org.jfree.data.Range) dateRange7);
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(rectangleConstraint4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "[Dec 31, 1969 3:59:59 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str8.equals("[Dec 31, 1969 3:59:59 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        int int2 = combinedDomainXYPlot0.getDomainAxisIndex(valueAxis1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = combinedDomainXYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = null;
        combinedDomainXYPlot0.setFixedRangeAxisSpace(axisSpace5, false);
        org.jfree.data.time.TimeSeries timeSeries8 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection9 = new org.jfree.data.time.TimeSeriesCollection(timeSeries8);
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection9, false);
        java.lang.Object obj12 = timeSeriesCollection9.clone();
        int int13 = combinedDomainXYPlot0.indexOf((org.jfree.data.xy.XYDataset) timeSeriesCollection9);
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor14 = org.jfree.data.time.TimePeriodAnchor.END;
        timeSeriesCollection9.setXPosition(timePeriodAnchor14);
        java.lang.String str16 = timePeriodAnchor14.toString();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(timePeriodAnchor14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "TimePeriodAnchor.END" + "'", str16.equals("TimePeriodAnchor.END"));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.data.Range range4 = xYStepRenderer2.findDomainBounds(xYDataset3);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator5 = null;
        xYStepRenderer2.setBaseToolTipGenerator(xYToolTipGenerator5);
        boolean boolean7 = xYStepRenderer2.getBaseShapesVisible();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator8 = null;
        xYStepRenderer2.setBaseToolTipGenerator(xYToolTipGenerator8, true);
        java.awt.Color color12 = java.awt.Color.lightGray;
        xYStepRenderer2.setSeriesFillPaint((int) '#', (java.awt.Paint) color12);
        boolean boolean14 = timeSeriesCollection1.equals((java.lang.Object) xYStepRenderer2);
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection19 = new org.jfree.data.time.TimeSeriesCollection(timeSeries18);
        org.jfree.data.Range range21 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection19, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState23 = xYStepRenderer2.initialise(graphics2D15, rectangle2D16, xYPlot17, (org.jfree.data.xy.XYDataset) timeSeriesCollection19, plotRenderingInfo22);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(range21);
        org.junit.Assert.assertNotNull(xYItemRendererState23);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem(0.0d, (double) 1L);
        xYDataItem2.setSelected(false);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer5 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer5.setBaseLinesVisible(true);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator9 = xYStepRenderer5.getSeriesItemLabelGenerator((int) '#');
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = xYStepRenderer5.getBasePositiveItemLabelPosition();
        xYStepRenderer5.setSeriesShapesVisible((int) (byte) 0, false);
        int int14 = xYDataItem2.compareTo((java.lang.Object) (byte) 0);
        java.lang.Object obj15 = xYDataItem2.clone();
        org.junit.Assert.assertNull(xYItemLabelGenerator9);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "org.jfree.data.UnknownKeyException: TextBlockAnchor.TOP_RIGHT", "ItemLabelAnchor.INSIDE7", "DomainOrder.NONE");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date6 = spreadsheetDate5.toDate();
        java.util.Date date7 = spreadsheetDate5.toDate();
        java.util.TimeZone timeZone8 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date7, timeZone8);
        int int10 = month9.getYearValue();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month9, (java.lang.Number) 0.0f, false);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(5, 1900);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month16, 2.0d, true);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date22 = spreadsheetDate21.toDate();
        java.util.Date date23 = spreadsheetDate21.toDate();
        java.util.TimeZone timeZone24 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(date23, timeZone24);
        java.lang.Number number26 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month25, number26);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer28 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Stroke stroke30 = null;
        xYBarRenderer28.setSeriesStroke(3, stroke30, false);
        int int33 = timeSeriesDataItem27.compareTo((java.lang.Object) 3);
        java.lang.Number number34 = null;
        timeSeriesDataItem27.setValue(number34);
        try {
            timeSeries3.add(timeSeriesDataItem27);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period January 1900 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1900 + "'", int10 == 1900);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset) defaultPieDataset0);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator2 = null;
        ringPlot1.setURLGenerator(pieURLGenerator2);
        double double4 = ringPlot1.getInteriorGap();
        double double5 = ringPlot1.getStartAngle();
        ringPlot1.setSectionOutlinesVisible(false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.08d + "'", double4 == 0.08d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 90.0d + "'", double5 == 90.0d);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        int int3 = combinedDomainXYPlot1.getDomainAxisIndex(valueAxis2);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        int int5 = combinedDomainXYPlot1.getRangeAxisIndex(valueAxis4);
        java.awt.Paint paint6 = combinedDomainXYPlot1.getDomainZeroBaselinePaint();
        java.awt.Stroke stroke7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        combinedDomainXYPlot1.setRangeZeroBaselineStroke(stroke7);
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = combinedDomainXYPlot1.getRendererForDataset(xYDataset9);
        org.jfree.chart.axis.AxisLocation axisLocation12 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        combinedDomainXYPlot1.setRangeAxisLocation(0, axisLocation12);
        combinedDomainXYPlot0.setRangeAxisLocation(axisLocation12, true);
        org.jfree.chart.axis.AxisSpace axisSpace16 = combinedDomainXYPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer17 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer17.clearSeriesStrokes(true);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator20 = xYBarRenderer17.getBaseItemLabelGenerator();
        java.awt.Paint paint22 = xYBarRenderer17.lookupSeriesPaint(9999);
        java.awt.Shape shape24 = xYBarRenderer17.getLegendShape((int) ' ');
        java.awt.Stroke stroke26 = xYBarRenderer17.lookupSeriesOutlineStroke((int) ' ');
        combinedDomainXYPlot0.setRangeMinorGridlineStroke(stroke26);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(xYItemRenderer10);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNull(axisSpace16);
        org.junit.Assert.assertNull(xYItemLabelGenerator20);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNull(shape24);
        org.junit.Assert.assertNotNull(stroke26);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.DAY;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        int int3 = combinedDomainXYPlot1.getDomainAxisIndex(valueAxis2);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        int int5 = combinedDomainXYPlot1.getRangeAxisIndex(valueAxis4);
        java.awt.Paint paint6 = combinedDomainXYPlot1.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot8 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        int int10 = combinedDomainXYPlot8.getDomainAxisIndex(valueAxis9);
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        int int12 = combinedDomainXYPlot8.getRangeAxisIndex(valueAxis11);
        java.awt.Paint paint13 = combinedDomainXYPlot8.getDomainZeroBaselinePaint();
        java.awt.Stroke stroke14 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        combinedDomainXYPlot8.setRangeZeroBaselineStroke(stroke14);
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = combinedDomainXYPlot8.getRendererForDataset(xYDataset16);
        org.jfree.chart.axis.AxisLocation axisLocation19 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        combinedDomainXYPlot8.setRangeAxisLocation(0, axisLocation19);
        combinedDomainXYPlot1.setDomainAxisLocation(31, axisLocation19);
        boolean boolean22 = dateTickUnitType0.equals((java.lang.Object) axisLocation19);
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNull(xYItemRenderer17);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState1 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo0);
        java.awt.geom.Line2D line2D2 = xYItemRendererState1.workingLine;
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) line2D2, "{0}: ({1}, {2})", "series");
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            boolean boolean7 = org.jfree.chart.util.ShapeUtilities.clipLine(line2D2, rectangle2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(line2D2);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset) defaultPieDataset0);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator2 = null;
        ringPlot1.setURLGenerator(pieURLGenerator2);
        double double4 = ringPlot1.getInteriorGap();
        double double5 = ringPlot1.getStartAngle();
        ringPlot1.setSectionDepth((double) (-4126));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.08d + "'", double4 == 0.08d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 90.0d + "'", double5 == 90.0d);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot2 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = combinedDomainXYPlot2.getDomainAxisIndex(valueAxis3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = combinedDomainXYPlot2.getRangeAxis();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("WMAP_Plot", font1, (org.jfree.chart.plot.Plot) combinedDomainXYPlot2, true);
        boolean boolean8 = jFreeChart7.getAntiAlias();
        java.awt.Paint paint9 = jFreeChart7.getBorderPaint();
        java.awt.Image image10 = jFreeChart7.getBackgroundImage();
        jFreeChart7.setBackgroundImageAlpha((float) (-4126));
        java.awt.Image image13 = jFreeChart7.getBackgroundImage();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(image10);
        org.junit.Assert.assertNull(image13);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        categoryPlot4.setDataset(categoryDataset5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot4.zoomRangeAxes((double) 2, 0.05d, plotRenderingInfo9, point2D10);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        int int2 = combinedDomainXYPlot0.getDomainAxisIndex(valueAxis1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = combinedDomainXYPlot0.getRangeAxisIndex(valueAxis3);
        java.awt.Paint paint5 = combinedDomainXYPlot0.getDomainZeroBaselinePaint();
        java.awt.Stroke stroke6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        combinedDomainXYPlot0.setRangeZeroBaselineStroke(stroke6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = combinedDomainXYPlot0.getRendererForDataset(xYDataset8);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer10 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer10.clearSeriesStrokes(true);
        java.awt.Paint paint14 = xYBarRenderer10.getSeriesFillPaint((int) '#');
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator15 = xYBarRenderer10.getLegendItemURLGenerator();
        boolean boolean16 = combinedDomainXYPlot0.equals((java.lang.Object) xYSeriesLabelGenerator15);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertNull(paint14);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

//    @Test
//    public void test268() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test268");
//        double[][] doubleArray2 = new double[][] {};
//        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("null", "LengthConstraintType.FIXED", doubleArray2);
//        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D5 = new org.jfree.chart.axis.CategoryAxis3D("ERROR : Relative To String");
//        categoryAxis3D5.clearCategoryLabelToolTips();
//        categoryAxis3D5.configure();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date11 = spreadsheetDate10.toDate();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        long long14 = day13.getLastMillisecond();
//        org.jfree.chart.axis.PeriodAxis periodAxis15 = new org.jfree.chart.axis.PeriodAxis("$8.00", (org.jfree.data.time.RegularTimePeriod) day12, (org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D5, (org.jfree.chart.axis.ValueAxis) periodAxis15, categoryItemRenderer16);
//        java.lang.Object obj18 = categoryAxis3D5.clone();
//        org.junit.Assert.assertNotNull(doubleArray2);
//        org.junit.Assert.assertNotNull(categoryDataset3);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560495599999L + "'", long14 == 1560495599999L);
//        org.junit.Assert.assertNotNull(obj18);
//    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        int int2 = combinedDomainXYPlot0.getDomainAxisIndex(valueAxis1);
        combinedDomainXYPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        int int6 = combinedDomainXYPlot0.getRangeAxisIndex(valueAxis5);
        combinedDomainXYPlot0.setDomainZeroBaselineVisible(false);
        boolean boolean9 = combinedDomainXYPlot0.isRangeGridlinesVisible();
        boolean boolean10 = combinedDomainXYPlot0.isDomainMinorGridlinesVisible();
        java.lang.Object obj11 = combinedDomainXYPlot0.clone();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.data.Range range2 = xYStepRenderer0.findDomainBounds(xYDataset1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = null;
        xYStepRenderer0.setBaseToolTipGenerator(xYToolTipGenerator3);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = xYStepRenderer0.getPositiveItemLabelPosition((int) (short) -1, (-458), false);
        xYStepRenderer0.setUseFillPaint(false);
        boolean boolean11 = xYStepRenderer0.getAutoPopulateSeriesPaint();
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer1 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        xYStepRenderer1.setBaseItemLabelFont(font2, true);
        java.awt.Paint paint5 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.text.TextFragment textFragment7 = new org.jfree.chart.text.TextFragment("{0}", font2, paint5, 0.0f);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        int int3 = combinedDomainXYPlot1.getDomainAxisIndex(valueAxis2);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        int int5 = combinedDomainXYPlot1.getRangeAxisIndex(valueAxis4);
        java.awt.Paint paint6 = combinedDomainXYPlot1.getDomainZeroBaselinePaint();
        java.awt.Stroke stroke7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        combinedDomainXYPlot1.setRangeZeroBaselineStroke(stroke7);
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = combinedDomainXYPlot1.getRendererForDataset(xYDataset9);
        org.jfree.chart.axis.AxisLocation axisLocation12 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        combinedDomainXYPlot1.setRangeAxisLocation(0, axisLocation12);
        combinedDomainXYPlot0.setRangeAxisLocation(axisLocation12, true);
        org.jfree.chart.axis.AxisSpace axisSpace16 = combinedDomainXYPlot0.getFixedDomainAxisSpace();
        combinedDomainXYPlot0.clearDomainAxes();
        combinedDomainXYPlot0.setDomainZeroBaselineVisible(false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(xYItemRenderer10);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNull(axisSpace16);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot2 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = combinedDomainXYPlot2.getDomainAxisIndex(valueAxis3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = combinedDomainXYPlot2.getRangeAxis();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("WMAP_Plot", font1, (org.jfree.chart.plot.Plot) combinedDomainXYPlot2, true);
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle9.setMaximumLinesToDisplay(1);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, categoryItemRenderer15);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot16.getDomainAxisEdge();
        textTitle9.setPosition(rectangleEdge17);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = textTitle9.getPadding();
        jFreeChart7.removeSubtitle((org.jfree.chart.title.Title) textTitle9);
        org.jfree.chart.title.LegendTitle legendTitle21 = jFreeChart7.getLegend();
        org.jfree.chart.block.BlockContainer blockContainer22 = legendTitle21.getItemContainer();
        java.awt.Paint paint23 = legendTitle21.getItemPaint();
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint25 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.util.Size2D size2D26 = legendTitle21.arrange(graphics2D24, rectangleConstraint25);
        java.lang.Object obj27 = legendTitle21.clone();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(legendTitle21);
        org.junit.Assert.assertNotNull(blockContainer22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(rectangleConstraint25);
        org.junit.Assert.assertNotNull(size2D26);
        org.junit.Assert.assertNotNull(obj27);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "org.jfree.data.UnknownKeyException: TextBlockAnchor.TOP_RIGHT", "ItemLabelAnchor.INSIDE7", "DomainOrder.NONE");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date6 = spreadsheetDate5.toDate();
        java.util.Date date7 = spreadsheetDate5.toDate();
        java.util.TimeZone timeZone8 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date7, timeZone8);
        int int10 = month9.getYearValue();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month9, (java.lang.Number) 0.0f, false);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(5, 1900);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month16, 2.0d, true);
        try {
            timeSeries3.update(100, (java.lang.Number) 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1900 + "'", int10 == 1900);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.clearSeriesStrokes(true);
        java.awt.Stroke stroke4 = xYBarRenderer0.lookupSeriesOutlineStroke(100);
        xYBarRenderer0.setShadowXOffset((double) 100.0f);
        org.jfree.chart.plot.XYPlot xYPlot7 = xYBarRenderer0.getPlot();
        xYBarRenderer0.setBaseItemLabelsVisible(false, false);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, categoryItemRenderer15);
        int int17 = categoryPlot16.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation19 = null;
        categoryPlot16.setRangeAxisLocation(100, axisLocation19);
        int int21 = categoryPlot16.getWeight();
        java.awt.Paint paint22 = categoryPlot16.getRangeGridlinePaint();
        xYBarRenderer0.setLegendTextPaint((int) (byte) 100, paint22);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(xYPlot7);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation(100, axisLocation7);
        int int9 = categoryPlot4.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = categoryPlot4.getDomainAxisEdge();
        int int11 = categoryPlot4.getDatasetCount();
        java.lang.Class<?> wildcardClass12 = categoryPlot4.getClass();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isRadiusGridlinesVisible();
        polarPlot0.setNoDataMessage("");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        java.awt.Shape shape4 = null;
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, valueAxis7, categoryItemRenderer8);
        int int10 = categoryPlot9.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation12 = null;
        categoryPlot9.setRangeAxisLocation(100, axisLocation12);
        int int14 = categoryPlot9.getWeight();
        java.awt.Paint paint15 = categoryPlot9.getRangeGridlinePaint();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer16 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer16.clearSeriesStrokes(true);
        java.awt.Stroke stroke20 = xYBarRenderer16.lookupSeriesOutlineStroke(100);
        xYBarRenderer16.setShadowXOffset((double) 100.0f);
        java.awt.Stroke stroke23 = xYBarRenderer16.getBaseOutlineStroke();
        java.awt.Paint paint24 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("", "TextBlockAnchor.TOP_RIGHT", "{0}: ({1}, {2})", "", shape4, paint15, stroke23, paint24);
        java.awt.Color color26 = java.awt.Color.lightGray;
        legendItem25.setLabelPaint((java.awt.Paint) color26);
        java.awt.Shape shape28 = legendItem25.getShape();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer29 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        legendItem25.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer29);
        int int31 = legendItem25.getDatasetIndex();
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNull(shape28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer5 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.data.Range range7 = xYStepRenderer5.findDomainBounds(xYDataset6);
        java.awt.Color color10 = org.jfree.chart.util.PaintUtilities.stringToColor("ERROR : Relative To String");
        xYStepRenderer5.setSeriesOutlinePaint(1, (java.awt.Paint) color10);
        java.awt.Shape shape15 = xYStepRenderer5.getItemShape(255, 0, false);
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.Color color18 = color17.darker();
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, valueAxis22, categoryItemRenderer23);
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = categoryPlot24.getDomainAxisEdge();
        java.awt.Paint paint26 = categoryPlot24.getNoDataMessagePaint();
        java.awt.Paint paint28 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer29 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer29.clearSeriesStrokes(true);
        java.awt.Stroke stroke33 = xYBarRenderer29.lookupSeriesOutlineStroke(100);
        xYBarRenderer29.setShadowXOffset((double) 100.0f);
        java.awt.Stroke stroke36 = xYBarRenderer29.getBaseOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker37 = new org.jfree.chart.plot.ValueMarker(0.05d, paint28, stroke36);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer39 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.data.xy.XYDataset xYDataset40 = null;
        org.jfree.data.Range range41 = xYStepRenderer39.findDomainBounds(xYDataset40);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator42 = null;
        xYStepRenderer39.setBaseToolTipGenerator(xYToolTipGenerator42);
        org.jfree.data.general.WaferMapDataset waferMapDataset45 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot46 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset45);
        java.awt.Paint paint47 = waferMapPlot46.getOutlinePaint();
        xYStepRenderer39.setSeriesFillPaint(100, paint47, false);
        java.awt.Font font51 = xYStepRenderer39.getSeriesItemLabelFont(100);
        xYStepRenderer39.setSeriesVisible((int) (short) 0, (java.lang.Boolean) true);
        java.awt.Shape shape55 = xYStepRenderer39.getBaseShape();
        java.awt.Stroke stroke56 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot57 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis58 = null;
        int int59 = combinedDomainXYPlot57.getDomainAxisIndex(valueAxis58);
        org.jfree.chart.axis.ValueAxis valueAxis60 = null;
        int int61 = combinedDomainXYPlot57.getRangeAxisIndex(valueAxis60);
        java.awt.Paint paint62 = combinedDomainXYPlot57.getDomainZeroBaselinePaint();
        try {
            org.jfree.chart.LegendItem legendItem63 = new org.jfree.chart.LegendItem(attributedString0, "{0}", "NOID", "ItemLabelAnchor.INSIDE7", true, shape15, false, (java.awt.Paint) color18, true, paint26, stroke36, true, shape55, stroke56, paint62);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(rectangleEdge25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNull(range41);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNull(font51);
        org.junit.Assert.assertNotNull(shape55);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-1) + "'", int59 == (-1));
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
        org.junit.Assert.assertNotNull(paint62);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("hi!", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        int int6 = categoryPlot5.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation8 = null;
        categoryPlot5.setRangeAxisLocation(100, axisLocation8);
        int int10 = categoryPlot5.getWeight();
        java.awt.Paint paint11 = categoryPlot5.getRangeGridlinePaint();
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.data.Range range13 = categoryPlot5.getDataRange(valueAxis12);
        java.awt.Stroke stroke14 = categoryPlot5.getRangeMinorGridlineStroke();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("ERROR : Relative To String");
        categoryAxis3D17.clearCategoryLabelToolTips();
        categoryPlot5.setDomainAxis((int) '#', (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, false);
        java.awt.Font font21 = categoryAxis3D17.getLabelFont();
        float float22 = categoryAxis3D17.getTickMarkInsideLength();
        java.awt.Stroke stroke23 = categoryAxis3D17.getAxisLineStroke();
        piePlot3D0.setLabelOutlineStroke(stroke23);
        java.awt.Paint paint25 = null;
        try {
            piePlot3D0.setBaseSectionOutlinePaint(paint25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 0.0f + "'", float22 == 0.0f);
        org.junit.Assert.assertNotNull(stroke23);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        java.awt.Color color1 = java.awt.Color.getColor("MAJOR");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        waferMapPlot1.handleClick(7, 12, plotRenderingInfo4);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent6 = null;
        waferMapPlot1.markerChanged(markerChangeEvent6);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer0.setSeriesCreateEntities((int) (short) 0, (java.lang.Boolean) true, true);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        int int2 = combinedDomainXYPlot0.getDomainAxisIndex(valueAxis1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = combinedDomainXYPlot0.getDomainAxisIndex(valueAxis3);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        combinedDomainXYPlot0.setRangeAxis(10, valueAxis6);
        boolean boolean8 = combinedDomainXYPlot0.canSelectByRegion();
        java.awt.Paint paint9 = combinedDomainXYPlot0.getDomainTickBandPaint();
        int int10 = combinedDomainXYPlot0.getDomainAxisCount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("ERROR : Relative To String");
        categoryAxis3D1.clearCategoryLabelToolTips();
        categoryAxis3D1.setCategoryLabelPositionOffset((-10289251));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(5, 1900);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation(100, axisLocation7);
        int int9 = categoryPlot4.getWeight();
        java.awt.Paint paint10 = categoryPlot4.getRangeGridlinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier11 = null;
        categoryPlot4.setDrawingSupplier(drawingSupplier11, false);
        boolean boolean14 = categoryPlot4.isSubplot();
        categoryPlot4.setRangeZeroBaselineVisible(true);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder17 = categoryPlot4.getDatasetRenderingOrder();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent18 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot4);
        java.awt.Font font20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot21 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        int int23 = combinedDomainXYPlot21.getDomainAxisIndex(valueAxis22);
        org.jfree.chart.axis.ValueAxis valueAxis24 = combinedDomainXYPlot21.getRangeAxis();
        org.jfree.chart.JFreeChart jFreeChart26 = new org.jfree.chart.JFreeChart("WMAP_Plot", font20, (org.jfree.chart.plot.Plot) combinedDomainXYPlot21, true);
        boolean boolean27 = jFreeChart26.getAntiAlias();
        java.awt.Paint paint28 = jFreeChart26.getBorderPaint();
        java.awt.Image image29 = jFreeChart26.getBackgroundImage();
        plotChangeEvent18.setChart(jFreeChart26);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder17);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNull(valueAxis24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNull(image29);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer0.setBaseLinesVisible(true);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator4 = xYStepRenderer0.getSeriesItemLabelGenerator((int) '#');
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator8 = xYStepRenderer0.getItemLabelGenerator((int) (byte) 100, (-1), false);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator9 = null;
        xYStepRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator9);
        java.awt.Paint paint12 = xYStepRenderer0.lookupSeriesPaint(6);
        org.junit.Assert.assertNull(xYItemLabelGenerator4);
        org.junit.Assert.assertNull(xYItemLabelGenerator8);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.clearSeriesStrokes(true);
        java.awt.Stroke stroke4 = xYBarRenderer0.lookupSeriesOutlineStroke(100);
        xYBarRenderer0.setShadowXOffset((double) 100.0f);
        java.awt.Stroke stroke7 = xYBarRenderer0.getBaseOutlineStroke();
        java.awt.Paint paint8 = xYBarRenderer0.getBasePaint();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator12 = xYBarRenderer0.getToolTipGenerator((int) (short) 100, 10, false);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator13 = null;
        xYBarRenderer0.setBaseItemLabelGenerator(xYItemLabelGenerator13);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(xYToolTipGenerator12);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day3, (double) 100);
        long long6 = day3.getSerialIndex();
        org.jfree.data.time.SerialDate serialDate7 = day3.getSerialDate();
        java.lang.String str8 = serialDate7.toString();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "9-January-1900" + "'", str8.equals("9-January-1900"));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot2 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = combinedDomainXYPlot2.getDomainAxisIndex(valueAxis3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = combinedDomainXYPlot2.getRangeAxis();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("WMAP_Plot", font1, (org.jfree.chart.plot.Plot) combinedDomainXYPlot2, true);
        boolean boolean8 = jFreeChart7.getAntiAlias();
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        textTitle10.setPadding(rectangleInsets11);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = textTitle10.getMargin();
        jFreeChart7.setPadding(rectangleInsets13);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        java.awt.image.BufferedImage bufferedImage18 = jFreeChart7.createBufferedImage((int) (short) 1, 3, chartRenderingInfo17);
        try {
            org.jfree.chart.title.Title title20 = jFreeChart7.getSubtitle((-10289251));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(bufferedImage18);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.clearSeriesStrokes(true);
        java.awt.Stroke stroke4 = xYBarRenderer0.lookupSeriesOutlineStroke(100);
        xYBarRenderer0.setShadowXOffset((double) 100.0f);
        java.awt.Stroke stroke7 = xYBarRenderer0.getBaseOutlineStroke();
        java.awt.Paint paint8 = xYBarRenderer0.getBasePaint();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator12 = xYBarRenderer0.getItemLabelGenerator((int) (short) 1, 6, false);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(xYItemLabelGenerator12);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!");
        java.text.NumberFormat numberFormat4 = java.text.NumberFormat.getCurrencyInstance();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = new org.jfree.chart.axis.NumberTickUnit((double) 100L, numberFormat4);
        java.lang.String str7 = numberFormat4.format((long) 8);
        boolean boolean8 = numberFormat4.isGroupingUsed();
        int int9 = numberFormat4.getMaximumFractionDigits();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit11 = new org.jfree.chart.axis.NumberTickUnit((double) 0.0f, numberFormat4, 2147483647);
        logAxis1.setTickUnit(numberTickUnit11, true, true);
        logAxis1.pan(9.0d);
        org.junit.Assert.assertNotNull(numberFormat4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "$8.00" + "'", str7.equals("$8.00"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer0.setBaseLinesVisible(true);
        java.awt.Paint paint4 = xYStepRenderer0.lookupLegendTextPaint(2);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        xYStepRenderer0.notifyListeners(rendererChangeEvent5);
        java.awt.Paint paint10 = xYStepRenderer0.getItemLabelPaint((-458), (-458), false);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.clearSeriesStrokes(true);
        java.awt.Stroke stroke4 = xYBarRenderer0.lookupSeriesOutlineStroke(100);
        xYBarRenderer0.setShadowXOffset((double) 100.0f);
        java.awt.Stroke stroke7 = xYBarRenderer0.getBaseOutlineStroke();
        boolean boolean8 = xYBarRenderer0.getBaseItemLabelsVisible();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator9 = null;
        xYBarRenderer0.setBaseURLGenerator(xYURLGenerator9);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setDepthFactor((double) 2958465);
        java.awt.Stroke stroke4 = piePlot3D0.getSectionOutlineStroke((java.lang.Comparable) "Category Plot");
        org.junit.Assert.assertNull(stroke4);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot4.getDomainAxis();
        boolean boolean6 = categoryPlot4.isDomainPannable();
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.data.Range range2 = xYStepRenderer0.findDomainBounds(xYDataset1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = null;
        xYStepRenderer0.setBaseToolTipGenerator(xYToolTipGenerator3);
        org.jfree.data.general.WaferMapDataset waferMapDataset6 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot7 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset6);
        java.awt.Paint paint8 = waferMapPlot7.getOutlinePaint();
        xYStepRenderer0.setSeriesFillPaint(100, paint8, false);
        java.awt.Font font12 = xYStepRenderer0.getSeriesItemLabelFont(100);
        boolean boolean13 = xYStepRenderer0.getBaseShapesFilled();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator14 = null;
        xYStepRenderer0.setBaseURLGenerator(xYURLGenerator14, true);
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(font12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter0 = new org.jfree.chart.renderer.category.GradientBarPainter();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = null;
        java.awt.geom.RectangularShape rectangularShape6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        try {
            gradientBarPainter0.paintBar(graphics2D1, barRenderer2, (int) (short) 10, (int) (byte) 100, false, rectangularShape6, rectangleEdge7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) 255);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = day0.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.clearSeriesStrokes(true);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator3 = xYBarRenderer0.getBaseItemLabelGenerator();
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator4 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator();
        java.lang.Object obj5 = standardXYSeriesLabelGenerator4.clone();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot6 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot6.setLimit(0.0d);
        boolean boolean9 = standardXYSeriesLabelGenerator4.equals((java.lang.Object) multiplePiePlot6);
        xYBarRenderer0.setLegendItemURLGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator4);
        org.junit.Assert.assertNull(xYItemLabelGenerator3);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        int int2 = combinedDomainXYPlot0.getDomainAxisIndex(valueAxis1);
        combinedDomainXYPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.axis.AxisSpace axisSpace5 = null;
        combinedDomainXYPlot0.setFixedDomainAxisSpace(axisSpace5);
        boolean boolean7 = combinedDomainXYPlot0.isDomainZoomable();
        combinedDomainXYPlot0.setRangeMinorGridlinesVisible(false);
        java.awt.Font font12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot13 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        int int15 = combinedDomainXYPlot13.getDomainAxisIndex(valueAxis14);
        org.jfree.chart.axis.ValueAxis valueAxis16 = combinedDomainXYPlot13.getRangeAxis();
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("WMAP_Plot", font12, (org.jfree.chart.plot.Plot) combinedDomainXYPlot13, true);
        boolean boolean19 = jFreeChart18.getAntiAlias();
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle21.setMaximumLinesToDisplay(1);
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, valueAxis26, categoryItemRenderer27);
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = categoryPlot28.getDomainAxisEdge();
        textTitle21.setPosition(rectangleEdge29);
        textTitle21.setPadding((double) '#', (double) (short) -1, 0.0d, (double) (byte) 10);
        boolean boolean36 = jFreeChart18.equals((java.lang.Object) (byte) 10);
        org.jfree.chart.text.TextBlock textBlock37 = new org.jfree.chart.text.TextBlock();
        java.util.List list38 = textBlock37.getLines();
        jFreeChart18.setSubtitles(list38);
        try {
            combinedDomainXYPlot0.mapDatasetToRangeAxes((int) (short) 100, list38);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Empty list not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNull(valueAxis16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(list38);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("org.jfree.data.UnknownKeyException: TextBlockAnchor.TOP_RIGHT", graphics2D1, 1.0f, 1.0f, textAnchor4, (double) 2958465, textAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "org.jfree.data.UnknownKeyException: TextBlockAnchor.TOP_RIGHT", "ItemLabelAnchor.INSIDE7", "DomainOrder.NONE");
        try {
            timeSeries3.delete(0, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("ClassContext");
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        java.text.NumberFormat numberFormat1 = null;
        java.text.NumberFormat numberFormat4 = java.text.NumberFormat.getCurrencyInstance();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = new org.jfree.chart.axis.NumberTickUnit((double) 100L, numberFormat4);
        java.text.NumberFormat numberFormat7 = java.text.NumberFormat.getCurrencyInstance();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit8 = new org.jfree.chart.axis.NumberTickUnit((double) 100L, numberFormat7);
        java.lang.String str10 = numberFormat7.format((long) 8);
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator11 = new org.jfree.chart.labels.StandardPieToolTipGenerator("{0}: ({1}, {2})", numberFormat4, numberFormat7);
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator12 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("$8.00", numberFormat1, numberFormat7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'numberFormat' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat4);
        org.junit.Assert.assertNotNull(numberFormat7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "$8.00" + "'", str10.equals("$8.00"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.data.Range range2 = xYBarRenderer0.findRangeBounds(xYDataset1);
        double double3 = xYBarRenderer0.getShadowXOffset();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot6 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        int int8 = combinedDomainXYPlot6.getDomainAxisIndex(valueAxis7);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        int int10 = combinedDomainXYPlot6.getRangeAxisIndex(valueAxis9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        combinedDomainXYPlot6.setFixedRangeAxisSpace(axisSpace11, false);
        org.jfree.data.time.TimeSeries timeSeries14 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection15 = new org.jfree.data.time.TimeSeriesCollection(timeSeries14);
        org.jfree.data.Range range17 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection15, false);
        java.lang.Object obj18 = timeSeriesCollection15.clone();
        int int19 = combinedDomainXYPlot6.indexOf((org.jfree.data.xy.XYDataset) timeSeriesCollection15);
        java.util.TimeZone timeZone20 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection21 = new org.jfree.data.time.TimeSeriesCollection(timeZone20);
        org.jfree.data.general.DatasetGroup datasetGroup22 = timeSeriesCollection21.getGroup();
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState23 = timeSeriesCollection21.getSelectionState();
        java.lang.Number number24 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset) timeSeriesCollection21);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        try {
            org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState26 = xYBarRenderer0.initialise(graphics2D4, rectangle2D5, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot6, (org.jfree.data.xy.XYDataset) timeSeriesCollection21, plotRenderingInfo25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index -1 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(datasetGroup22);
        org.junit.Assert.assertNotNull(xYDatasetSelectionState23);
        org.junit.Assert.assertEquals((double) number24, Double.NaN, 0);
    }

//    @Test
//    public void test310() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test310");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date3 = spreadsheetDate2.toDate();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        long long6 = day5.getLastMillisecond();
//        org.jfree.chart.axis.PeriodAxis periodAxis7 = new org.jfree.chart.axis.PeriodAxis("$8.00", (org.jfree.data.time.RegularTimePeriod) day4, (org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.String str8 = periodAxis7.getLabelToolTip();
//        java.util.TimeZone timeZone9 = periodAxis7.getTimeZone();
//        java.awt.geom.Rectangle2D rectangle2D11 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
//        double double13 = periodAxis7.java2DToValue((double) 1900, rectangle2D11, rectangleEdge12);
//        org.jfree.chart.axis.TickUnitSource tickUnitSource14 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
//        periodAxis7.setStandardTickUnits(tickUnitSource14);
//        java.awt.Stroke stroke16 = periodAxis7.getMinorTickMarkStroke();
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560495599999L + "'", long6 == 1560495599999L);
//        org.junit.Assert.assertNull(str8);
//        org.junit.Assert.assertNotNull(timeZone9);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + Double.POSITIVE_INFINITY + "'", double13 == Double.POSITIVE_INFINITY);
//        org.junit.Assert.assertNotNull(tickUnitSource14);
//        org.junit.Assert.assertNotNull(stroke16);
//    }

//    @Test
//    public void test311() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test311");
//        double[][] doubleArray2 = new double[][] {};
//        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("null", "LengthConstraintType.FIXED", doubleArray2);
//        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D5 = new org.jfree.chart.axis.CategoryAxis3D("ERROR : Relative To String");
//        categoryAxis3D5.clearCategoryLabelToolTips();
//        categoryAxis3D5.configure();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date11 = spreadsheetDate10.toDate();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        long long14 = day13.getLastMillisecond();
//        org.jfree.chart.axis.PeriodAxis periodAxis15 = new org.jfree.chart.axis.PeriodAxis("$8.00", (org.jfree.data.time.RegularTimePeriod) day12, (org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D5, (org.jfree.chart.axis.ValueAxis) periodAxis15, categoryItemRenderer16);
//        org.jfree.data.Range range18 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset3);
//        org.junit.Assert.assertNotNull(doubleArray2);
//        org.junit.Assert.assertNotNull(categoryDataset3);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560495599999L + "'", long14 == 1560495599999L);
//        org.junit.Assert.assertNull(range18);
//    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray1 = null;
        java.awt.Paint[] paintArray2 = null;
        java.awt.Paint[] paintArray3 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Stroke[] strokeArray5 = new java.awt.Stroke[] { stroke4 };
        java.awt.Stroke[] strokeArray6 = new java.awt.Stroke[] {};
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) (short) -1, (float) 1L);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape9, rectangleAnchor10, (double) (short) 0, (double) 1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState15 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo14);
        java.awt.geom.Line2D line2D16 = xYItemRendererState15.workingLine;
        java.awt.Shape[] shapeArray17 = new java.awt.Shape[] { shape13, line2D16 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier18 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray1, paintArray2, paintArray3, strokeArray5, strokeArray6, shapeArray17);
        java.awt.Paint[] paintArray19 = null;
        java.awt.Paint[] paintArray20 = null;
        java.awt.Paint[] paintArray21 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Stroke[] strokeArray23 = new java.awt.Stroke[] { stroke22 };
        java.awt.Stroke[] strokeArray24 = new java.awt.Stroke[] {};
        java.awt.Shape shape27 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) (short) -1, (float) 1L);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor28 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape31 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape27, rectangleAnchor28, (double) (short) 0, (double) 1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState33 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo32);
        java.awt.geom.Line2D line2D34 = xYItemRendererState33.workingLine;
        java.awt.Shape[] shapeArray35 = new java.awt.Shape[] { shape31, line2D34 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier36 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray19, paintArray20, paintArray21, strokeArray23, strokeArray24, shapeArray35);
        java.awt.Stroke[] strokeArray37 = new java.awt.Stroke[] {};
        java.awt.Paint[] paintArray38 = null;
        java.awt.Paint[] paintArray39 = null;
        java.awt.Paint[] paintArray40 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Stroke stroke41 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Stroke[] strokeArray42 = new java.awt.Stroke[] { stroke41 };
        java.awt.Stroke[] strokeArray43 = new java.awt.Stroke[] {};
        java.awt.Shape shape46 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) (short) -1, (float) 1L);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor47 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape50 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape46, rectangleAnchor47, (double) (short) 0, (double) 1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo51 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState52 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo51);
        java.awt.geom.Line2D line2D53 = xYItemRendererState52.workingLine;
        java.awt.Shape[] shapeArray54 = new java.awt.Shape[] { shape50, line2D53 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier55 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray38, paintArray39, paintArray40, strokeArray42, strokeArray43, shapeArray54);
        java.awt.Paint[] paintArray56 = null;
        java.awt.Paint[] paintArray57 = null;
        java.awt.Paint[] paintArray58 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Stroke stroke59 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Stroke[] strokeArray60 = new java.awt.Stroke[] { stroke59 };
        java.awt.Stroke[] strokeArray61 = new java.awt.Stroke[] {};
        java.awt.Shape shape64 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) (short) -1, (float) 1L);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor65 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape68 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape64, rectangleAnchor65, (double) (short) 0, (double) 1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo69 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState70 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo69);
        java.awt.geom.Line2D line2D71 = xYItemRendererState70.workingLine;
        java.awt.Shape[] shapeArray72 = new java.awt.Shape[] { shape68, line2D71 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier73 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray56, paintArray57, paintArray58, strokeArray60, strokeArray61, shapeArray72);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier74 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, paintArray20, strokeArray37, strokeArray43, shapeArray72);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline75 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        int int76 = segmentedTimeline75.getSegmentsExcluded();
        int int77 = segmentedTimeline75.getGroupSegmentCount();
        boolean boolean78 = segmentedTimeline75.getAdjustForDaylightSaving();
        org.jfree.data.time.DateRange dateRange79 = new org.jfree.data.time.DateRange();
        java.util.Date date80 = dateRange79.getLowerDate();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment81 = segmentedTimeline75.getSegment(date80);
        boolean boolean82 = defaultDrawingSupplier74.equals((java.lang.Object) segmentedTimeline75);
        long long83 = segmentedTimeline75.getSegmentsIncludedSize();
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(strokeArray5);
        org.junit.Assert.assertNotNull(strokeArray6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(rectangleAnchor10);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(line2D16);
        org.junit.Assert.assertNotNull(shapeArray17);
        org.junit.Assert.assertNotNull(paintArray21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(strokeArray23);
        org.junit.Assert.assertNotNull(strokeArray24);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(rectangleAnchor28);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(line2D34);
        org.junit.Assert.assertNotNull(shapeArray35);
        org.junit.Assert.assertNotNull(strokeArray37);
        org.junit.Assert.assertNotNull(paintArray40);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(strokeArray42);
        org.junit.Assert.assertNotNull(strokeArray43);
        org.junit.Assert.assertNotNull(shape46);
        org.junit.Assert.assertNotNull(rectangleAnchor47);
        org.junit.Assert.assertNotNull(shape50);
        org.junit.Assert.assertNotNull(line2D53);
        org.junit.Assert.assertNotNull(shapeArray54);
        org.junit.Assert.assertNotNull(paintArray58);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertNotNull(strokeArray60);
        org.junit.Assert.assertNotNull(strokeArray61);
        org.junit.Assert.assertNotNull(shape64);
        org.junit.Assert.assertNotNull(rectangleAnchor65);
        org.junit.Assert.assertNotNull(shape68);
        org.junit.Assert.assertNotNull(line2D71);
        org.junit.Assert.assertNotNull(shapeArray72);
        org.junit.Assert.assertNotNull(segmentedTimeline75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 2 + "'", int76 == 2);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 7 + "'", int77 == 7);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(date80);
        org.junit.Assert.assertNotNull(segment81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + long83 + "' != '" + 432000000L + "'", long83 == 432000000L);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!");
        java.lang.Object obj2 = logAxis1.clone();
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType4 = rectangleConstraint3.getHeightConstraintType();
        org.jfree.chart.util.Size2D size2D5 = borderArrangement0.arrange(blockContainer1, graphics2D2, rectangleConstraint3);
        org.jfree.data.time.DateRange dateRange6 = new org.jfree.data.time.DateRange();
        double double7 = dateRange6.getLength();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = rectangleConstraint3.toRangeWidth((org.jfree.data.Range) dateRange6);
        double double9 = rectangleConstraint3.getHeight();
        org.junit.Assert.assertNotNull(rectangleConstraint3);
        org.junit.Assert.assertNotNull(lengthConstraintType4);
        org.junit.Assert.assertNotNull(size2D5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot2 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = combinedDomainXYPlot2.getDomainAxisIndex(valueAxis3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = combinedDomainXYPlot2.getRangeAxis();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("WMAP_Plot", font1, (org.jfree.chart.plot.Plot) combinedDomainXYPlot2, true);
        boolean boolean8 = jFreeChart7.getAntiAlias();
        java.awt.Paint paint9 = jFreeChart7.getBorderPaint();
        java.awt.Image image10 = jFreeChart7.getBackgroundImage();
        jFreeChart7.setBackgroundImageAlpha((float) (-4126));
        org.jfree.chart.title.TextTitle textTitle13 = jFreeChart7.getTitle();
        org.jfree.chart.plot.XYPlot xYPlot14 = jFreeChart7.getXYPlot();
        float float15 = jFreeChart7.getBackgroundImageAlpha();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(image10);
        org.junit.Assert.assertNotNull(textTitle13);
        org.junit.Assert.assertNotNull(xYPlot14);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + (-4126.0f) + "'", float15 == (-4126.0f));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType1 = rectangleConstraint0.getHeightConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = rectangleConstraint0.toFixedHeight(0.08d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType4 = rectangleConstraint3.getHeightConstraintType();
        org.jfree.data.Range range5 = rectangleConstraint3.getHeightRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = rectangleConstraint3.toUnconstrainedWidth();
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertNotNull(lengthConstraintType1);
        org.junit.Assert.assertNotNull(rectangleConstraint3);
        org.junit.Assert.assertNotNull(lengthConstraintType4);
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertNotNull(rectangleConstraint6);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0);
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        java.lang.Comparable comparable3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeriesCollection1.getSeries(comparable3);
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection1, true);
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertNull(timeSeries4);
        org.junit.Assert.assertNull(range6);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.data.time.DateRange dateRange0 = new org.jfree.data.time.DateRange();
        org.jfree.data.Range range3 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange0, (double) 3, true);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange0, 8.0d);
        org.junit.Assert.assertNotNull(range3);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        java.awt.Paint[] paintArray2 = null;
        java.awt.Paint[] paintArray3 = null;
        java.awt.Paint[] paintArray4 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Stroke[] strokeArray6 = new java.awt.Stroke[] { stroke5 };
        java.awt.Stroke[] strokeArray7 = new java.awt.Stroke[] {};
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) (short) -1, (float) 1L);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape14 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape10, rectangleAnchor11, (double) (short) 0, (double) 1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState16 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo15);
        java.awt.geom.Line2D line2D17 = xYItemRendererState16.workingLine;
        java.awt.Shape[] shapeArray18 = new java.awt.Shape[] { shape14, line2D17 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier19 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray2, paintArray3, paintArray4, strokeArray6, strokeArray7, shapeArray18);
        java.awt.Shape shape20 = defaultDrawingSupplier19.getNextShape();
        shapeList0.setShape(10, shape20);
        org.junit.Assert.assertNotNull(paintArray4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(strokeArray6);
        org.junit.Assert.assertNotNull(strokeArray7);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(line2D17);
        org.junit.Assert.assertNotNull(shapeArray18);
        org.junit.Assert.assertNotNull(shape20);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        int int2 = combinedDomainXYPlot0.getDomainAxisIndex(valueAxis1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = combinedDomainXYPlot0.getRangeAxis();
        boolean boolean4 = combinedDomainXYPlot0.isSubplot();
        combinedDomainXYPlot0.setRangeMinorGridlinesVisible(false);
        boolean boolean7 = combinedDomainXYPlot0.isDomainZeroBaselineVisible();
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        combinedDomainXYPlot0.setRangeAxis((int) 'a', valueAxis9);
        double double11 = combinedDomainXYPlot0.getRangeCrosshairValue();
        combinedDomainXYPlot0.setRangeCrosshairValue((double) (short) 0);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer14 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer14.clearSeriesStrokes(true);
        java.awt.Stroke stroke18 = xYBarRenderer14.lookupSeriesOutlineStroke(100);
        combinedDomainXYPlot0.setRangeCrosshairStroke(stroke18);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.data.Range range2 = xYStepRenderer0.findDomainBounds(xYDataset1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = null;
        xYStepRenderer0.setBaseToolTipGenerator(xYToolTipGenerator3);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = xYStepRenderer0.getPositiveItemLabelPosition((int) (short) -1, (-458), false);
        java.util.Collection collection9 = xYStepRenderer0.getAnnotations();
        java.awt.Stroke stroke11 = xYStepRenderer0.getSeriesOutlineStroke(1);
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNull(stroke11);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = categoryPlot4.getDomainAxisEdge();
        java.awt.Paint paint6 = categoryPlot4.getOutlinePaint();
        categoryPlot4.setBackgroundAlpha((float) 100L);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot4.setRangeAxis(valueAxis9);
        categoryPlot4.setForegroundAlpha((float) 100);
        java.lang.Comparable comparable13 = categoryPlot4.getDomainCrosshairColumnKey();
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(comparable13);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        int int6 = categoryPlot5.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation8 = null;
        categoryPlot5.setRangeAxisLocation(100, axisLocation8);
        int int10 = categoryPlot5.getWeight();
        java.awt.Paint paint11 = categoryPlot5.getRangeGridlinePaint();
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.data.Range range13 = categoryPlot5.getDataRange(valueAxis12);
        java.awt.Stroke stroke14 = categoryPlot5.getRangeMinorGridlineStroke();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("ERROR : Relative To String");
        categoryAxis3D17.clearCategoryLabelToolTips();
        categoryPlot5.setDomainAxis((int) '#', (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, false);
        java.awt.Font font21 = categoryAxis3D17.getLabelFont();
        float float22 = categoryAxis3D17.getTickMarkInsideLength();
        java.awt.Stroke stroke23 = categoryAxis3D17.getAxisLineStroke();
        piePlot3D0.setLabelOutlineStroke(stroke23);
        java.lang.String str25 = piePlot3D0.getPlotType();
        piePlot3D0.setIgnoreZeroValues(false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 0.0f + "'", float22 == 0.0f);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Pie 3D Plot" + "'", str25.equals("Pie 3D Plot"));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=0,g=255,b=0]");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer2 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer2.clearSeriesStrokes(true);
        java.awt.Stroke stroke6 = xYBarRenderer2.lookupSeriesOutlineStroke(100);
        xYBarRenderer2.setShadowXOffset((double) 100.0f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState11 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo10);
        java.awt.geom.Line2D line2D12 = xYItemRendererState11.workingLine;
        xYBarRenderer2.setLegendShape(0, (java.awt.Shape) line2D12);
        numberAxis1.setRightArrow((java.awt.Shape) line2D12);
        org.jfree.chart.axis.TickUnitSource tickUnitSource15 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        numberAxis1.setStandardTickUnits(tickUnitSource15);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range18 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range19 = org.jfree.data.Range.combine(range17, range18);
        numberAxis1.setRange(range17, true, false);
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = null;
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis28, valueAxis29, categoryItemRenderer30);
        int int32 = categoryPlot31.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation34 = null;
        categoryPlot31.setRangeAxisLocation(100, axisLocation34);
        int int36 = categoryPlot31.getWeight();
        java.awt.Paint paint37 = categoryPlot31.getRangeGridlinePaint();
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.data.Range range39 = categoryPlot31.getDataRange(valueAxis38);
        java.awt.Stroke stroke40 = categoryPlot31.getRangeMinorGridlineStroke();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D43 = new org.jfree.chart.axis.CategoryAxis3D("ERROR : Relative To String");
        categoryAxis3D43.clearCategoryLabelToolTips();
        categoryPlot31.setDomainAxis((int) '#', (org.jfree.chart.axis.CategoryAxis) categoryAxis3D43, false);
        java.awt.Font font47 = categoryAxis3D43.getLabelFont();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand48 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis1, (double) 8, (double) 0, (double) (-9999), (double) 255, font47);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(line2D12);
        org.junit.Assert.assertNotNull(tickUnitSource15);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNull(range39);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(font47);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset) defaultPieDataset0);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator2 = null;
        ringPlot1.setURLGenerator(pieURLGenerator2);
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.Color color6 = color5.darker();
        ringPlot1.setSectionPaint((java.lang.Comparable) 2, (java.awt.Paint) color5);
        java.lang.Comparable comparable8 = null;
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.color.ColorSpace colorSpace10 = color9.getColorSpace();
        try {
            ringPlot1.setSectionOutlinePaint(comparable8, (java.awt.Paint) color9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(colorSpace10);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        int int2 = combinedDomainXYPlot0.getDomainAxisIndex(valueAxis1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = combinedDomainXYPlot0.getRangeAxisIndex(valueAxis3);
        java.awt.Paint paint5 = combinedDomainXYPlot0.getDomainZeroBaselinePaint();
        java.awt.Stroke stroke6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        combinedDomainXYPlot0.setRangeZeroBaselineStroke(stroke6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = combinedDomainXYPlot0.getRendererForDataset(xYDataset8);
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        combinedDomainXYPlot0.drawAnnotations(graphics2D10, rectangle2D11, plotRenderingInfo12);
        float float14 = combinedDomainXYPlot0.getForegroundAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        int int16 = combinedDomainXYPlot0.getRangeAxisIndex(valueAxis15);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 1.0f + "'", float14 == 1.0f);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        textTitle1.setPadding(rectangleInsets2);
        double double5 = rectangleInsets2.extendWidth(0.0d);
        double double7 = rectangleInsets2.calculateRightOutset(10.0d);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "org.jfree.data.UnknownKeyException: TextBlockAnchor.TOP_RIGHT", "ItemLabelAnchor.INSIDE7", "DomainOrder.NONE");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date6 = spreadsheetDate5.toDate();
        java.util.Date date7 = spreadsheetDate5.toDate();
        java.util.TimeZone timeZone8 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date7, timeZone8);
        int int10 = month9.getYearValue();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month9, (java.lang.Number) 0.0f, false);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(5, 1900);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month16, 2.0d, true);
        org.jfree.data.time.Year year20 = month16.getYear();
        java.awt.Font font22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot23 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        int int25 = combinedDomainXYPlot23.getDomainAxisIndex(valueAxis24);
        org.jfree.chart.axis.ValueAxis valueAxis26 = combinedDomainXYPlot23.getRangeAxis();
        org.jfree.chart.JFreeChart jFreeChart28 = new org.jfree.chart.JFreeChart("WMAP_Plot", font22, (org.jfree.chart.plot.Plot) combinedDomainXYPlot23, true);
        boolean boolean29 = jFreeChart28.getAntiAlias();
        java.awt.Paint paint30 = jFreeChart28.getBorderPaint();
        boolean boolean31 = year20.equals((java.lang.Object) jFreeChart28);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1900 + "'", int10 == 1900);
        org.junit.Assert.assertNotNull(year20);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNull(valueAxis26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("ERROR : Relative To String");
        categoryAxis3D1.setCategoryMargin((double) 10L);
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryAxis3D1, jFreeChart4, chartChangeEventType5);
        categoryAxis3D1.setLabelAngle((double) 2958465);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean2 = textBlock0.equals((java.lang.Object) rectangleInsets1);
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine();
        org.jfree.chart.text.TextFragment textFragment4 = null;
        textLine3.removeFragment(textFragment4);
        org.jfree.chart.text.TextFragment textFragment6 = textLine3.getLastTextFragment();
        textBlock0.addLine(textLine3);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.util.Size2D size2D9 = textBlock0.calculateDimensions(graphics2D8);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor13 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, valueAxis16, categoryItemRenderer17);
        int int19 = categoryPlot18.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation21 = null;
        categoryPlot18.setRangeAxisLocation(100, axisLocation21);
        int int23 = categoryPlot18.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = categoryPlot18.getDomainAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        categoryPlot18.zoomRangeAxes((double) 10.0f, plotRenderingInfo26, point2D27, false);
        boolean boolean30 = textBlockAnchor13.equals((java.lang.Object) point2D27);
        textBlock0.draw(graphics2D10, (float) (byte) -1, 2.0f, textBlockAnchor13, (float) 100L, (float) 6, 100.0d);
        java.awt.Graphics2D graphics2D35 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor38 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape42 = textBlock0.calculateBounds(graphics2D35, 0.0f, (float) 6, textBlockAnchor38, (float) (byte) 10, 0.0f, (double) (-458));
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(textFragment6);
        org.junit.Assert.assertNotNull(size2D9);
        org.junit.Assert.assertNotNull(textBlockAnchor13);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(textBlockAnchor38);
        org.junit.Assert.assertNotNull(shape42);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        textTitle1.setPadding(rectangleInsets2);
        textTitle1.setURLText("");
        java.lang.String str6 = textTitle1.getText();
        java.awt.Font font8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot9 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        int int11 = combinedDomainXYPlot9.getDomainAxisIndex(valueAxis10);
        org.jfree.chart.axis.ValueAxis valueAxis12 = combinedDomainXYPlot9.getRangeAxis();
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("WMAP_Plot", font8, (org.jfree.chart.plot.Plot) combinedDomainXYPlot9, true);
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle16.setMaximumLinesToDisplay(1);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, valueAxis21, categoryItemRenderer22);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = categoryPlot23.getDomainAxisEdge();
        textTitle16.setPosition(rectangleEdge24);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = textTitle16.getPadding();
        jFreeChart14.removeSubtitle((org.jfree.chart.title.Title) textTitle16);
        org.jfree.chart.title.LegendTitle legendTitle28 = jFreeChart14.getLegend();
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = legendTitle28.getItemLabelPadding();
        java.awt.Font font30 = legendTitle28.getItemFont();
        textTitle1.setFont(font30);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(legendTitle28);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(font30);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.jfree.data.time.DateRange dateRange0 = new org.jfree.data.time.DateRange();
        double double1 = dateRange0.getLength();
        java.util.Date date2 = dateRange0.getUpperDate();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot2 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = combinedDomainXYPlot2.getDomainAxisIndex(valueAxis3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = combinedDomainXYPlot2.getRangeAxis();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("WMAP_Plot", font1, (org.jfree.chart.plot.Plot) combinedDomainXYPlot2, true);
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle9.setMaximumLinesToDisplay(1);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, categoryItemRenderer15);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot16.getDomainAxisEdge();
        textTitle9.setPosition(rectangleEdge17);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = textTitle9.getPadding();
        jFreeChart7.removeSubtitle((org.jfree.chart.title.Title) textTitle9);
        org.jfree.chart.title.LegendTitle legendTitle21 = jFreeChart7.getLegend();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = legendTitle21.getItemLabelPadding();
        java.awt.Font font23 = legendTitle21.getItemFont();
        org.jfree.chart.block.BlockContainer blockContainer24 = legendTitle21.getItemContainer();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(legendTitle21);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(blockContainer24);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE6;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("ERROR : Relative To String");
        categoryAxis3D1.clearCategoryLabelToolTips();
        categoryAxis3D1.configure();
        org.jfree.chart.event.AxisChangeListener axisChangeListener4 = null;
        categoryAxis3D1.addChangeListener(axisChangeListener4);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = new org.jfree.chart.util.RectangleInsets((double) (short) -1, 0.0d, (double) (short) -1, (double) (byte) 10);
        double double12 = rectangleInsets10.extendWidth((double) (-1));
        categoryAxis3D1.setLabelInsets(rectangleInsets10);
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D17 = rectangleInsets10.createInsetRectangle(rectangle2D14, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 9.0d + "'", double12 == 9.0d);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 7);
        java.lang.String str2 = xYSeries1.getDescription();
        org.jfree.data.xy.XYSeries xYSeries5 = xYSeries1.createCopy(3, 5);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        xYSeries1.addPropertyChangeListener(propertyChangeListener6);
        xYSeries1.setKey((java.lang.Comparable) "MAJOR");
        xYSeries1.setDescription("series");
        xYSeries1.fireSeriesChanged();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(xYSeries5);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        java.util.Date date3 = spreadsheetDate1.toDate();
        java.util.TimeZone timeZone4 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date3, timeZone4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month5.previous();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(regularTimePeriod6);
        org.junit.Assert.assertNull(regularTimePeriod7);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 7);
        java.lang.String str2 = xYSeries1.getDescription();
        double double3 = xYSeries1.getMaxX();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        int int6 = categoryPlot5.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation8 = null;
        categoryPlot5.setRangeAxisLocation(100, axisLocation8);
        int int10 = categoryPlot5.getWeight();
        java.awt.Paint paint11 = categoryPlot5.getRangeGridlinePaint();
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.data.Range range13 = categoryPlot5.getDataRange(valueAxis12);
        java.awt.Stroke stroke14 = categoryPlot5.getRangeMinorGridlineStroke();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("ERROR : Relative To String");
        categoryAxis3D17.clearCategoryLabelToolTips();
        categoryPlot5.setDomainAxis((int) '#', (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, false);
        java.awt.Font font21 = categoryAxis3D17.getLabelFont();
        float float22 = categoryAxis3D17.getTickMarkInsideLength();
        java.awt.Stroke stroke23 = categoryAxis3D17.getAxisLineStroke();
        piePlot3D0.setLabelOutlineStroke(stroke23);
        double double25 = piePlot3D0.getShadowXOffset();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 0.0f + "'", float22 == 0.0f);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 4.0d + "'", double25 == 4.0d);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.clearSeriesStrokes(true);
        java.awt.Stroke stroke4 = xYBarRenderer0.lookupSeriesOutlineStroke(100);
        xYBarRenderer0.setShadowXOffset((double) 100.0f);
        xYBarRenderer0.setBase((double) 2.0f);
        org.junit.Assert.assertNotNull(stroke4);
    }

//    @Test
//    public void test342() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test342");
//        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer1 = new org.jfree.chart.renderer.xy.XYStepRenderer();
//        org.jfree.data.xy.XYDataset xYDataset2 = null;
//        org.jfree.data.Range range3 = xYStepRenderer1.findDomainBounds(xYDataset2);
//        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator4 = null;
//        xYStepRenderer1.setBaseToolTipGenerator(xYToolTipGenerator4);
//        boolean boolean6 = xYStepRenderer1.getBaseShapesVisible();
//        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
//        xYStepRenderer1.setBaseToolTipGenerator(xYToolTipGenerator7, true);
//        java.text.DateFormat dateFormat11 = null;
//        java.text.DateFormat dateFormat12 = null;
//        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator13 = new org.jfree.chart.labels.StandardXYToolTipGenerator("{0}: ({1}, {2})", dateFormat11, dateFormat12);
//        xYStepRenderer1.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator13);
//        org.jfree.chart.urls.XYURLGenerator xYURLGenerator15 = null;
//        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer16 = new org.jfree.chart.renderer.xy.XYAreaRenderer(3, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator13, xYURLGenerator15);
//        boolean boolean17 = xYAreaRenderer16.isOutline();
//        java.awt.Paint paint19 = xYAreaRenderer16.getSeriesPaint((int) (short) 100);
//        boolean boolean20 = xYAreaRenderer16.getPlotShapes();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date24 = spreadsheetDate23.toDate();
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date24);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        long long27 = day26.getLastMillisecond();
//        org.jfree.chart.axis.PeriodAxis periodAxis28 = new org.jfree.chart.axis.PeriodAxis("$8.00", (org.jfree.data.time.RegularTimePeriod) day25, (org.jfree.data.time.RegularTimePeriod) day26);
//        java.lang.String str29 = periodAxis28.getLabelToolTip();
//        java.util.TimeZone timeZone30 = periodAxis28.getTimeZone();
//        boolean boolean31 = periodAxis28.isAutoRange();
//        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot32 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
//        int int34 = combinedDomainXYPlot32.getDomainAxisIndex(valueAxis33);
//        org.jfree.chart.axis.ValueAxis valueAxis35 = combinedDomainXYPlot32.getRangeAxis();
//        boolean boolean36 = combinedDomainXYPlot32.isSubplot();
//        java.awt.Stroke stroke37 = combinedDomainXYPlot32.getRangeMinorGridlineStroke();
//        periodAxis28.setTickMarkStroke(stroke37);
//        xYAreaRenderer16.setBaseOutlineStroke(stroke37, false);
//        org.junit.Assert.assertNull(range3);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNull(paint19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560495599999L + "'", long27 == 1560495599999L);
//        org.junit.Assert.assertNull(str29);
//        org.junit.Assert.assertNotNull(timeZone30);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
//        org.junit.Assert.assertNull(valueAxis35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(stroke37);
//    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        java.awt.Paint[] paintArray0 = null;
        java.awt.Paint[] paintArray1 = null;
        java.awt.Paint[] paintArray2 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Stroke[] strokeArray4 = new java.awt.Stroke[] { stroke3 };
        java.awt.Stroke[] strokeArray5 = new java.awt.Stroke[] {};
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) (short) -1, (float) 1L);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape8, rectangleAnchor9, (double) (short) 0, (double) 1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState14 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo13);
        java.awt.geom.Line2D line2D15 = xYItemRendererState14.workingLine;
        java.awt.Shape[] shapeArray16 = new java.awt.Shape[] { shape12, line2D15 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier17 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, paintArray2, strokeArray4, strokeArray5, shapeArray16);
        java.awt.Stroke stroke18 = defaultDrawingSupplier17.getNextStroke();
        try {
            java.awt.Paint paint19 = defaultDrawingSupplier17.getNextPaint();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(strokeArray4);
        org.junit.Assert.assertNotNull(strokeArray5);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(line2D15);
        org.junit.Assert.assertNotNull(shapeArray16);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer1 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.data.Range range3 = xYStepRenderer1.findDomainBounds(xYDataset2);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator4 = null;
        xYStepRenderer1.setBaseToolTipGenerator(xYToolTipGenerator4);
        boolean boolean6 = xYStepRenderer1.getBaseShapesVisible();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
        xYStepRenderer1.setBaseToolTipGenerator(xYToolTipGenerator7, true);
        java.text.DateFormat dateFormat11 = null;
        java.text.DateFormat dateFormat12 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator13 = new org.jfree.chart.labels.StandardXYToolTipGenerator("{0}: ({1}, {2})", dateFormat11, dateFormat12);
        xYStepRenderer1.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator13);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator15 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer16 = new org.jfree.chart.renderer.xy.XYAreaRenderer(3, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator13, xYURLGenerator15);
        boolean boolean17 = xYAreaRenderer16.isOutline();
        java.awt.Shape shape18 = xYAreaRenderer16.getLegendArea();
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(shape18);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

//    @Test
//    public void test346() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test346");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date3 = spreadsheetDate2.toDate();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        long long6 = day5.getLastMillisecond();
//        org.jfree.chart.axis.PeriodAxis periodAxis7 = new org.jfree.chart.axis.PeriodAxis("$8.00", (org.jfree.data.time.RegularTimePeriod) day4, (org.jfree.data.time.RegularTimePeriod) day5);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day5.next();
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560495599999L + "'", long6 == 1560495599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        java.awt.Font font0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0);
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        int int7 = categoryPlot6.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation9 = null;
        categoryPlot6.setRangeAxisLocation(100, axisLocation9);
        timeSeriesCollection1.removeChangeListener((org.jfree.data.general.DatasetChangeListener) categoryPlot6);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate13 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection1, true);
        boolean boolean14 = intervalXYDelegate13.isAutoWidth();
        intervalXYDelegate13.setAutoWidth(true);
        try {
            java.lang.Number number19 = intervalXYDelegate13.getEndX((int) '#', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE5;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState1 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo0);
        java.awt.geom.Line2D line2D2 = xYItemRendererState1.workingLine;
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) line2D2, "{0}: ({1}, {2})", "series");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D7 = new org.jfree.chart.axis.CategoryAxis3D("ERROR : Relative To String");
        categoryAxis3D7.setCategoryLabelPositionOffset(0);
        java.awt.Font font10 = categoryAxis3D7.getLabelFont();
        double double11 = categoryAxis3D7.getFixedDimension();
        org.jfree.chart.entity.AxisEntity axisEntity13 = new org.jfree.chart.entity.AxisEntity((java.awt.Shape) line2D2, (org.jfree.chart.axis.Axis) categoryAxis3D7, "null");
        org.junit.Assert.assertNotNull(line2D2);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator0 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator0, xYURLGenerator1);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator0);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Stroke stroke2 = null;
        xYBarRenderer0.setSeriesStroke(3, stroke2, false);
        java.awt.Shape shape6 = xYBarRenderer0.getLegendShape(3);
        org.junit.Assert.assertNull(shape6);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.data.Range range2 = xYStepRenderer0.findDomainBounds(xYDataset1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = null;
        xYStepRenderer0.setBaseToolTipGenerator(xYToolTipGenerator3);
        boolean boolean5 = xYStepRenderer0.getBaseShapesVisible();
        double double6 = xYStepRenderer0.getStepPoint();
        boolean boolean9 = xYStepRenderer0.getItemLineVisible((int) 'a', 15);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = xYStepRenderer0.getBaseNegativeItemLabelPosition();
        double double11 = itemLabelPosition10.getAngle();
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("java.awt.Color[r=0,g=255,b=0]");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = logAxis1.getTickUnit();
        boolean boolean3 = logAxis1.isMinorTickMarksVisible();
        logAxis1.setBase(Double.NaN);
        org.junit.Assert.assertNotNull(numberTickUnit2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState1 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo0);
        java.awt.geom.Line2D line2D2 = xYItemRendererState1.workingLine;
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        int int8 = categoryPlot7.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation10 = null;
        categoryPlot7.setRangeAxisLocation(100, axisLocation10);
        int int12 = categoryPlot7.getWeight();
        java.awt.Paint paint13 = categoryPlot7.getRangeGridlinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier14 = null;
        categoryPlot7.setDrawingSupplier(drawingSupplier14, false);
        org.jfree.chart.entity.PlotEntity plotEntity17 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape) line2D2, (org.jfree.chart.plot.Plot) categoryPlot7);
        java.awt.Shape shape20 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) (short) -1, (float) 1L);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape24 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape20, rectangleAnchor21, (double) (short) 0, (double) 1);
        plotEntity17.setArea(shape20);
        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape20, (double) (-458), (float) 5, (float) 15);
        java.awt.Shape shape30 = null;
        boolean boolean31 = org.jfree.chart.util.ShapeUtilities.equal(shape20, shape30);
        org.junit.Assert.assertNotNull(line2D2);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(rectangleAnchor21);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation(100, axisLocation7);
        int int9 = categoryPlot4.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = categoryPlot4.getDomainAxisEdge();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot12 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot13 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        int int15 = combinedDomainXYPlot13.getDomainAxisIndex(valueAxis14);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        int int17 = combinedDomainXYPlot13.getRangeAxisIndex(valueAxis16);
        java.awt.Paint paint18 = combinedDomainXYPlot13.getDomainZeroBaselinePaint();
        java.awt.Stroke stroke19 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        combinedDomainXYPlot13.setRangeZeroBaselineStroke(stroke19);
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = combinedDomainXYPlot13.getRendererForDataset(xYDataset21);
        org.jfree.chart.axis.AxisLocation axisLocation24 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        combinedDomainXYPlot13.setRangeAxisLocation(0, axisLocation24);
        combinedDomainXYPlot12.setRangeAxisLocation(axisLocation24, true);
        categoryPlot4.setDomainAxisLocation((int) ' ', axisLocation24);
        int int29 = categoryPlot4.getCrosshairDatasetIndex();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(xYItemRenderer22);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        int int2 = combinedDomainXYPlot0.getDomainAxisIndex(valueAxis1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = combinedDomainXYPlot0.getRangeAxis();
        boolean boolean4 = combinedDomainXYPlot0.isSubplot();
        java.util.List list5 = combinedDomainXYPlot0.getAnnotations();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(list5);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.data.Range range4 = xYStepRenderer2.findDomainBounds(xYDataset3);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator5 = null;
        xYStepRenderer2.setBaseToolTipGenerator(xYToolTipGenerator5);
        boolean boolean7 = xYStepRenderer2.getBaseShapesVisible();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator8 = null;
        xYStepRenderer2.setBaseToolTipGenerator(xYToolTipGenerator8, true);
        java.text.DateFormat dateFormat12 = null;
        java.text.DateFormat dateFormat13 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator14 = new org.jfree.chart.labels.StandardXYToolTipGenerator("{0}: ({1}, {2})", dateFormat12, dateFormat13);
        xYStepRenderer2.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator14);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator16 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer17 = new org.jfree.chart.renderer.xy.XYAreaRenderer(3, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator14, xYURLGenerator16);
        java.lang.Object obj18 = null;
        boolean boolean19 = standardXYToolTipGenerator14.equals(obj18);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator20 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer21 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator14, xYURLGenerator20);
        xYStepAreaRenderer21.setShapesVisible(true);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        java.util.Date date3 = spreadsheetDate1.toDate();
        java.util.TimeZone timeZone4 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date3, timeZone4);
        java.lang.Number number6 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, number6);
        long long8 = month5.getLastMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-2206281600001L) + "'", long8 == (-2206281600001L));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.data.Range range2 = xYStepRenderer0.findDomainBounds(xYDataset1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = null;
        xYStepRenderer0.setBaseToolTipGenerator(xYToolTipGenerator3);
        boolean boolean5 = xYStepRenderer0.getBaseShapesVisible();
        double double6 = xYStepRenderer0.getStepPoint();
        java.lang.Object obj7 = xYStepRenderer0.clone();
        java.awt.Paint paint11 = xYStepRenderer0.getItemLabelPaint(0, 0, true);
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("ERROR : Relative To String");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.lang.Object obj3 = standardPieSectionLabelGenerator2.clone();
        boolean boolean4 = textFragment1.equals((java.lang.Object) standardPieSectionLabelGenerator2);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot5 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        int int7 = combinedDomainXYPlot5.getDomainAxisIndex(valueAxis6);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        int int9 = combinedDomainXYPlot5.getRangeAxisIndex(valueAxis8);
        java.awt.Paint paint10 = combinedDomainXYPlot5.getDomainZeroBaselinePaint();
        boolean boolean11 = combinedDomainXYPlot5.isDomainZeroBaselineVisible();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = combinedDomainXYPlot5.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation14 = combinedDomainXYPlot5.getRangeAxisLocation((int) '#');
        boolean boolean15 = textFragment1.equals((java.lang.Object) combinedDomainXYPlot5);
        java.awt.Graphics2D graphics2D16 = null;
        try {
            org.jfree.chart.util.Size2D size2D17 = textFragment1.calculateDimensions(graphics2D16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (short) -1, 0.0d, (double) (short) -1, (double) (byte) 10);
        double double6 = rectangleInsets4.extendWidth((double) (-1));
        org.jfree.chart.util.UnitType unitType7 = rectangleInsets4.getUnitType();
        java.lang.String str8 = unitType7.toString();
        java.lang.String str9 = unitType7.toString();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 9.0d + "'", double6 == 9.0d);
        org.junit.Assert.assertNotNull(unitType7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "UnitType.ABSOLUTE" + "'", str8.equals("UnitType.ABSOLUTE"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "UnitType.ABSOLUTE" + "'", str9.equals("UnitType.ABSOLUTE"));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0);
        double double3 = timeSeriesCollection1.getDomainLowerBound(true);
        try {
            double double6 = timeSeriesCollection1.getStartXValue(1900, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1900, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation(100, axisLocation7);
        int int9 = categoryPlot4.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = categoryPlot4.getDomainAxisEdge();
        org.jfree.chart.axis.AxisSpace axisSpace11 = categoryPlot4.getFixedRangeAxisSpace();
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Point2D point2D14 = null;
        org.jfree.chart.plot.PlotState plotState15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        try {
            categoryPlot4.draw(graphics2D12, rectangle2D13, point2D14, plotState15, plotRenderingInfo16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNull(axisSpace11);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset) defaultPieDataset0);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator2 = null;
        ringPlot1.setURLGenerator(pieURLGenerator2);
        double double4 = ringPlot1.getInteriorGap();
        double double5 = ringPlot1.getStartAngle();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, valueAxis8, categoryItemRenderer9);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot10.getDomainAxisEdge();
        boolean boolean12 = categoryPlot10.isRangeGridlinesVisible();
        java.lang.Comparable comparable13 = categoryPlot10.getDomainCrosshairColumnKey();
        java.awt.Paint paint14 = categoryPlot10.getDomainCrosshairPaint();
        ringPlot1.setBaseSectionOutlinePaint(paint14);
        java.awt.Paint paint16 = ringPlot1.getBaseSectionOutlinePaint();
        boolean boolean17 = ringPlot1.getIgnoreNullValues();
        ringPlot1.setIgnoreNullValues(false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.08d + "'", double4 == 0.08d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 90.0d + "'", double5 == 90.0d);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(comparable13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.jfree.data.time.DateRange dateRange0 = new org.jfree.data.time.DateRange();
        org.jfree.data.Range range3 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange0, (double) 3, true);
        double double4 = dateRange0.getCentralValue();
        long long5 = dateRange0.getUpperMillis();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.5d + "'", double4 == 0.5d);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot2 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = combinedDomainXYPlot2.getDomainAxisIndex(valueAxis3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = combinedDomainXYPlot2.getRangeAxis();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("WMAP_Plot", font1, (org.jfree.chart.plot.Plot) combinedDomainXYPlot2, true);
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle9.setMaximumLinesToDisplay(1);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, categoryItemRenderer15);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot16.getDomainAxisEdge();
        textTitle9.setPosition(rectangleEdge17);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = textTitle9.getPadding();
        jFreeChart7.removeSubtitle((org.jfree.chart.title.Title) textTitle9);
        org.jfree.chart.title.LegendTitle legendTitle21 = jFreeChart7.getLegend();
        org.jfree.chart.block.BlockContainer blockContainer22 = legendTitle21.getItemContainer();
        java.awt.Paint paint23 = legendTitle21.getItemPaint();
        java.awt.Paint paint24 = legendTitle21.getItemPaint();
        java.lang.Object obj25 = null;
        boolean boolean26 = legendTitle21.equals(obj25);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(legendTitle21);
        org.junit.Assert.assertNotNull(blockContainer22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 10);
        xYLineAndShapeRenderer0.setLegendLine(shape2);
        xYLineAndShapeRenderer0.setDataBoundsIncludesVisibleSeriesOnly(false);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.data.Range range2 = xYStepRenderer0.findDomainBounds(xYDataset1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = null;
        xYStepRenderer0.setBaseToolTipGenerator(xYToolTipGenerator3);
        org.jfree.data.general.WaferMapDataset waferMapDataset6 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot7 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset6);
        java.awt.Paint paint8 = waferMapPlot7.getOutlinePaint();
        xYStepRenderer0.setSeriesFillPaint(100, paint8, false);
        java.awt.Font font12 = xYStepRenderer0.getSeriesItemLabelFont(100);
        boolean boolean13 = xYStepRenderer0.getBaseShapesFilled();
        xYStepRenderer0.setBaseSeriesVisible(false);
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(font12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer0.setBaseLinesVisible(true);
        xYStepRenderer0.setSeriesLinesVisible(0, true);
        java.awt.Paint paint6 = xYStepRenderer0.getBaseLegendTextPaint();
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis9, categoryItemRenderer10);
        int int12 = categoryPlot11.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation14 = null;
        categoryPlot11.setRangeAxisLocation(100, axisLocation14);
        int int16 = categoryPlot11.getWeight();
        java.awt.Paint paint17 = categoryPlot11.getRangeGridlinePaint();
        xYStepRenderer0.setBaseFillPaint(paint17, false);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getCurrencyInstance();
        boolean boolean1 = numberFormat0.isParseIntegerOnly();
        java.lang.String str3 = numberFormat0.format((double) (-1L));
        java.math.RoundingMode roundingMode4 = numberFormat0.getRoundingMode();
        numberFormat0.setGroupingUsed(true);
        org.junit.Assert.assertNotNull(numberFormat0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "($1.00)" + "'", str3.equals("($1.00)"));
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + java.math.RoundingMode.HALF_EVEN + "'", roundingMode4.equals(java.math.RoundingMode.HALF_EVEN));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        java.awt.Paint paint1 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer2 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer2.clearSeriesStrokes(true);
        java.awt.Stroke stroke6 = xYBarRenderer2.lookupSeriesOutlineStroke(100);
        xYBarRenderer2.setShadowXOffset((double) 100.0f);
        java.awt.Stroke stroke9 = xYBarRenderer2.getBaseOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.05d, paint1, stroke9);
        float float11 = valueMarker10.getAlpha();
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, categoryItemRenderer15);
        int int17 = categoryPlot16.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation19 = null;
        categoryPlot16.setRangeAxisLocation(100, axisLocation19);
        int int21 = categoryPlot16.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = categoryPlot16.getDomainAxisEdge();
        valueMarker10.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot16);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        categoryPlot16.setRenderer(categoryItemRenderer24, false);
        org.jfree.chart.axis.AxisSpace axisSpace27 = new org.jfree.chart.axis.AxisSpace();
        boolean boolean29 = axisSpace27.equals((java.lang.Object) 10);
        categoryPlot16.setFixedDomainAxisSpace(axisSpace27, false);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 1.0f + "'", float11 == 1.0f);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=0,g=255,b=0]");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer2 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer2.clearSeriesStrokes(true);
        java.awt.Stroke stroke6 = xYBarRenderer2.lookupSeriesOutlineStroke(100);
        xYBarRenderer2.setShadowXOffset((double) 100.0f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState11 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo10);
        java.awt.geom.Line2D line2D12 = xYItemRendererState11.workingLine;
        xYBarRenderer2.setLegendShape(0, (java.awt.Shape) line2D12);
        numberAxis1.setRightArrow((java.awt.Shape) line2D12);
        numberAxis1.setMinorTickMarksVisible(true);
        numberAxis1.setVerticalTickLabels(false);
        numberAxis1.setMinorTickMarkInsideLength((float) 10);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(line2D12);
    }

//    @Test
//    public void test374() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test374");
//        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 1, (float) 6);
//        double[][] doubleArray7 = new double[][] {};
//        org.jfree.data.category.CategoryDataset categoryDataset8 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("null", "LengthConstraintType.FIXED", doubleArray7);
//        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D10 = new org.jfree.chart.axis.CategoryAxis3D("ERROR : Relative To String");
//        categoryAxis3D10.clearCategoryLabelToolTips();
//        categoryAxis3D10.configure();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date16 = spreadsheetDate15.toDate();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date16);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        long long19 = day18.getLastMillisecond();
//        org.jfree.chart.axis.PeriodAxis periodAxis20 = new org.jfree.chart.axis.PeriodAxis("$8.00", (org.jfree.data.time.RegularTimePeriod) day17, (org.jfree.data.time.RegularTimePeriod) day18);
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D10, (org.jfree.chart.axis.ValueAxis) periodAxis20, categoryItemRenderer21);
//        boolean boolean23 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset8);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date26 = spreadsheetDate25.toDate();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date29 = spreadsheetDate28.toDate();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date32 = spreadsheetDate31.toDate();
//        boolean boolean33 = spreadsheetDate28.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate31);
//        boolean boolean34 = spreadsheetDate25.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate31);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date37 = spreadsheetDate36.toDate();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date40 = spreadsheetDate39.toDate();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date43 = spreadsheetDate42.toDate();
//        boolean boolean44 = spreadsheetDate39.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate42);
//        boolean boolean45 = spreadsheetDate36.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate42);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean49 = spreadsheetDate25.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate36, (org.jfree.data.time.SerialDate) spreadsheetDate47, 0);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date52 = spreadsheetDate51.toDate();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate54 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date55 = spreadsheetDate54.toDate();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate57 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date58 = spreadsheetDate57.toDate();
//        boolean boolean59 = spreadsheetDate54.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate57);
//        boolean boolean60 = spreadsheetDate51.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate57);
//        int int61 = spreadsheetDate51.getYYYY();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate63 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date64 = spreadsheetDate63.toDate();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate66 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date67 = spreadsheetDate66.toDate();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate69 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date70 = spreadsheetDate69.toDate();
//        boolean boolean71 = spreadsheetDate66.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate69);
//        boolean boolean72 = spreadsheetDate63.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate69);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate74 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date75 = spreadsheetDate74.toDate();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate77 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date78 = spreadsheetDate77.toDate();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate80 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date81 = spreadsheetDate80.toDate();
//        boolean boolean82 = spreadsheetDate77.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate80);
//        boolean boolean83 = spreadsheetDate74.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate80);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate85 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean87 = spreadsheetDate63.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate74, (org.jfree.data.time.SerialDate) spreadsheetDate85, 0);
//        boolean boolean89 = spreadsheetDate25.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate51, (org.jfree.data.time.SerialDate) spreadsheetDate63, (int) (byte) 100);
//        java.lang.String str90 = spreadsheetDate63.toString();
//        org.jfree.data.time.DateRange dateRange91 = new org.jfree.data.time.DateRange();
//        java.util.Date date92 = dateRange91.getLowerDate();
//        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity93 = new org.jfree.chart.entity.CategoryItemEntity(shape2, "TextBlockAnchor.BOTTOM_RIGHT", "Category Plot", categoryDataset8, (java.lang.Comparable) spreadsheetDate63, (java.lang.Comparable) date92);
//        org.jfree.data.Range range95 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset8, false);
//        org.junit.Assert.assertNotNull(shape2);
//        org.junit.Assert.assertNotNull(doubleArray7);
//        org.junit.Assert.assertNotNull(categoryDataset8);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560495599999L + "'", long19 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1900 + "'", int61 == 1900);
//        org.junit.Assert.assertNotNull(date64);
//        org.junit.Assert.assertNotNull(date67);
//        org.junit.Assert.assertNotNull(date70);
//        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
//        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
//        org.junit.Assert.assertNotNull(date75);
//        org.junit.Assert.assertNotNull(date78);
//        org.junit.Assert.assertNotNull(date81);
//        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
//        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
//        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
//        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
//        org.junit.Assert.assertTrue("'" + str90 + "' != '" + "9-January-1900" + "'", str90.equals("9-January-1900"));
//        org.junit.Assert.assertNotNull(date92);
//        org.junit.Assert.assertNull(range95);
//    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("TextBlockAnchor.TOP_RIGHT");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        labelBlock1.setContentAlignmentPoint(textBlockAnchor2);
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        textTitle5.setPadding(rectangleInsets6);
        double double9 = rectangleInsets6.extendWidth(0.0d);
        labelBlock1.setPadding(rectangleInsets6);
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.clearSeriesStrokes(true);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator3 = xYBarRenderer0.getBaseItemLabelGenerator();
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle6.setMaximumLinesToDisplay(1);
        double double9 = textTitle6.getHeight();
        java.awt.Font font10 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        textTitle6.setFont(font10);
        xYBarRenderer0.setLegendTextFont((int) (short) 1, font10);
        org.junit.Assert.assertNull(xYItemLabelGenerator3);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(font10);
    }

//    @Test
//    public void test377() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test377");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date3 = spreadsheetDate2.toDate();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        long long6 = day5.getLastMillisecond();
//        org.jfree.chart.axis.PeriodAxis periodAxis7 = new org.jfree.chart.axis.PeriodAxis("$8.00", (org.jfree.data.time.RegularTimePeriod) day4, (org.jfree.data.time.RegularTimePeriod) day5);
//        java.awt.Paint paint8 = periodAxis7.getTickMarkPaint();
//        periodAxis7.setFixedAutoRange((double) 4);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date14 = spreadsheetDate13.toDate();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        long long17 = day16.getLastMillisecond();
//        org.jfree.chart.axis.PeriodAxis periodAxis18 = new org.jfree.chart.axis.PeriodAxis("$8.00", (org.jfree.data.time.RegularTimePeriod) day15, (org.jfree.data.time.RegularTimePeriod) day16);
//        java.lang.String str19 = periodAxis18.getLabelToolTip();
//        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, valueAxis22, categoryItemRenderer23);
//        int int25 = categoryPlot24.getDomainAxisCount();
//        org.jfree.chart.axis.AxisLocation axisLocation27 = null;
//        categoryPlot24.setRangeAxisLocation(100, axisLocation27);
//        org.jfree.chart.plot.Marker marker29 = null;
//        org.jfree.chart.util.Layer layer30 = org.jfree.chart.util.Layer.FOREGROUND;
//        boolean boolean31 = categoryPlot24.removeDomainMarker(marker29, layer30);
//        periodAxis18.setPlot((org.jfree.chart.plot.Plot) categoryPlot24);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date36 = spreadsheetDate35.toDate();
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date36);
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
//        long long39 = day38.getLastMillisecond();
//        org.jfree.chart.axis.PeriodAxis periodAxis40 = new org.jfree.chart.axis.PeriodAxis("$8.00", (org.jfree.data.time.RegularTimePeriod) day37, (org.jfree.data.time.RegularTimePeriod) day38);
//        java.lang.Class class41 = periodAxis40.getMajorTickTimePeriodClass();
//        periodAxis18.setAutoRangeTimePeriodClass(class41);
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline43 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//        int int44 = segmentedTimeline43.getSegmentsExcluded();
//        int int45 = segmentedTimeline43.getGroupSegmentCount();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date48 = spreadsheetDate47.toDate();
//        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day(date48);
//        boolean boolean50 = segmentedTimeline43.containsDomainValue(date48);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate52 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date53 = spreadsheetDate52.toDate();
//        java.util.Date date54 = spreadsheetDate52.toDate();
//        java.util.TimeZone timeZone55 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month56 = new org.jfree.data.time.Month(date54, timeZone55);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance(class41, date48, timeZone55);
//        periodAxis7.setMajorTickTimePeriodClass(class41);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560495599999L + "'", long6 == 1560495599999L);
//        org.junit.Assert.assertNotNull(paint8);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560495599999L + "'", long17 == 1560495599999L);
//        org.junit.Assert.assertNull(str19);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertNotNull(layer30);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560495599999L + "'", long39 == 1560495599999L);
//        org.junit.Assert.assertNotNull(class41);
//        org.junit.Assert.assertNotNull(segmentedTimeline43);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 2 + "'", int44 == 2);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 7 + "'", int45 == 7);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertNotNull(timeZone55);
//        org.junit.Assert.assertNotNull(regularTimePeriod57);
//    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle2.setMaximumLinesToDisplay(1);
        org.jfree.data.general.WaferMapDataset waferMapDataset5 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot6 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset5);
        java.awt.Font font7 = waferMapPlot6.getNoDataMessageFont();
        textTitle2.setFont(font7);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, valueAxis11, categoryItemRenderer12);
        int int14 = categoryPlot13.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation16 = null;
        categoryPlot13.setRangeAxisLocation(100, axisLocation16);
        int int18 = categoryPlot13.getWeight();
        java.awt.Paint paint19 = categoryPlot13.getRangeGridlinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier20 = null;
        categoryPlot13.setDrawingSupplier(drawingSupplier20, false);
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor23 = org.jfree.data.time.TimePeriodAnchor.END;
        boolean boolean24 = categoryPlot13.equals((java.lang.Object) timePeriodAnchor23);
        org.jfree.chart.JFreeChart jFreeChart26 = new org.jfree.chart.JFreeChart("", font7, (org.jfree.chart.plot.Plot) categoryPlot13, true);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(timePeriodAnchor23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isRadiusGridlinesVisible();
        java.awt.Paint paint2 = polarPlot0.getRadiusGridlinePaint();
        int int3 = polarPlot0.getSeriesCount();
        java.awt.Paint paint4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        polarPlot0.setRadiusGridlinePaint(paint4);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation(100, axisLocation7);
        int int9 = categoryPlot4.getWeight();
        java.awt.Paint paint10 = categoryPlot4.getRangeGridlinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier11 = null;
        categoryPlot4.setDrawingSupplier(drawingSupplier11, false);
        boolean boolean14 = categoryPlot4.isDomainZoomable();
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis17, categoryItemRenderer18);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = categoryPlot19.getDomainAxisEdge();
        java.awt.Paint paint21 = categoryPlot19.getOutlinePaint();
        java.awt.Paint paint24 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer25 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer25.clearSeriesStrokes(true);
        java.awt.Stroke stroke29 = xYBarRenderer25.lookupSeriesOutlineStroke(100);
        xYBarRenderer25.setShadowXOffset((double) 100.0f);
        java.awt.Stroke stroke32 = xYBarRenderer25.getBaseOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker(0.05d, paint24, stroke32);
        float float34 = valueMarker33.getAlpha();
        org.jfree.chart.util.Layer layer35 = null;
        boolean boolean36 = categoryPlot19.removeRangeMarker(100, (org.jfree.chart.plot.Marker) valueMarker33, layer35);
        categoryPlot4.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker33);
        java.awt.Font font40 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot41 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis42 = null;
        int int43 = combinedDomainXYPlot41.getDomainAxisIndex(valueAxis42);
        org.jfree.chart.axis.ValueAxis valueAxis44 = combinedDomainXYPlot41.getRangeAxis();
        org.jfree.chart.JFreeChart jFreeChart46 = new org.jfree.chart.JFreeChart("WMAP_Plot", font40, (org.jfree.chart.plot.Plot) combinedDomainXYPlot41, true);
        org.jfree.chart.block.LabelBlock labelBlock47 = new org.jfree.chart.block.LabelBlock("{0}: ({1}, {2})", font40);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor48 = org.jfree.chart.util.RectangleAnchor.TOP;
        labelBlock47.setTextAnchor(rectangleAnchor48);
        valueMarker33.setLabelAnchor(rectangleAnchor48);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertTrue("'" + float34 + "' != '" + 1.0f + "'", float34 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(font40);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertNull(valueAxis44);
        org.junit.Assert.assertNotNull(rectangleAnchor48);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.data.Range range2 = xYStepRenderer0.findDomainBounds(xYDataset1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = null;
        xYStepRenderer0.setBaseToolTipGenerator(xYToolTipGenerator3);
        boolean boolean5 = xYStepRenderer0.getAutoPopulateSeriesStroke();
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = categoryPlot4.getDomainAxisEdge();
        java.awt.Paint paint6 = categoryPlot4.getOutlinePaint();
        categoryPlot4.setBackgroundAlpha((float) 100L);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot4.zoomDomainAxes((double) 10L, plotRenderingInfo10, point2D11, false);
        java.awt.Font font15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot16 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        int int18 = combinedDomainXYPlot16.getDomainAxisIndex(valueAxis17);
        org.jfree.chart.axis.ValueAxis valueAxis19 = combinedDomainXYPlot16.getRangeAxis();
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("WMAP_Plot", font15, (org.jfree.chart.plot.Plot) combinedDomainXYPlot16, true);
        boolean boolean22 = jFreeChart21.getAntiAlias();
        org.jfree.chart.title.TextTitle textTitle24 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        textTitle24.setPadding(rectangleInsets25);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = textTitle24.getMargin();
        jFreeChart21.setPadding(rectangleInsets27);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo31 = null;
        java.awt.image.BufferedImage bufferedImage32 = jFreeChart21.createBufferedImage((int) (short) 1, 3, chartRenderingInfo31);
        categoryPlot4.setBackgroundImage((java.awt.Image) bufferedImage32);
        java.awt.Paint paint34 = categoryPlot4.getRangeGridlinePaint();
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNull(valueAxis19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(bufferedImage32);
        org.junit.Assert.assertNotNull(paint34);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.data.general.DatasetGroup datasetGroup2 = timeSeriesCollection1.getGroup();
        org.jfree.data.general.DatasetGroup datasetGroup3 = new org.jfree.data.general.DatasetGroup();
        timeSeriesCollection1.setGroup(datasetGroup3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer6 = new org.jfree.chart.text.G2TextMeasurer(graphics2D5);
        boolean boolean7 = datasetGroup3.equals((java.lang.Object) g2TextMeasurer6);
        org.junit.Assert.assertNotNull(datasetGroup2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

//    @Test
//    public void test384() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test384");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date3 = spreadsheetDate2.toDate();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        long long6 = day5.getLastMillisecond();
//        org.jfree.chart.axis.PeriodAxis periodAxis7 = new org.jfree.chart.axis.PeriodAxis("$8.00", (org.jfree.data.time.RegularTimePeriod) day4, (org.jfree.data.time.RegularTimePeriod) day5);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date10 = spreadsheetDate9.toDate();
//        java.util.Date date11 = spreadsheetDate9.toDate();
//        java.util.TimeZone timeZone12 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date11, timeZone12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month13.previous();
//        periodAxis7.setFirst((org.jfree.data.time.RegularTimePeriod) month13);
//        periodAxis7.setMinorTickMarkInsideLength((float) (-2208960000000L));
//        periodAxis7.setLowerBound(1.0d);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560495599999L + "'", long6 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(timeZone12);
//        org.junit.Assert.assertNull(regularTimePeriod14);
//    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation(100, axisLocation7);
        int int9 = categoryPlot4.getWeight();
        java.awt.Paint paint10 = categoryPlot4.getRangeGridlinePaint();
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.data.Range range12 = categoryPlot4.getDataRange(valueAxis11);
        java.awt.Stroke stroke13 = categoryPlot4.getRangeMinorGridlineStroke();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D16 = new org.jfree.chart.axis.CategoryAxis3D("ERROR : Relative To String");
        categoryAxis3D16.clearCategoryLabelToolTips();
        categoryPlot4.setDomainAxis((int) '#', (org.jfree.chart.axis.CategoryAxis) categoryAxis3D16, false);
        java.awt.Font font20 = categoryAxis3D16.getLabelFont();
        float float21 = categoryAxis3D16.getTickMarkOutsideLength();
        categoryAxis3D16.setCategoryMargin((double) 1560495599999L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 2.0f + "'", float21 == 2.0f);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset) defaultPieDataset0);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator2 = null;
        ringPlot1.setURLGenerator(pieURLGenerator2);
        double double4 = ringPlot1.getInteriorGap();
        double double5 = ringPlot1.getStartAngle();
        double double6 = ringPlot1.getLabelLinkMargin();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.08d + "'", double4 == 0.08d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 90.0d + "'", double5 == 90.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.025d + "'", double6 == 0.025d);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer0.setBaseLinesVisible(true);
        xYStepRenderer0.setSeriesLinesVisible(0, true);
        xYStepRenderer0.setSeriesVisibleInLegend(1, (java.lang.Boolean) false, false);
        java.awt.Shape shape14 = null;
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis17, categoryItemRenderer18);
        int int20 = categoryPlot19.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation22 = null;
        categoryPlot19.setRangeAxisLocation(100, axisLocation22);
        int int24 = categoryPlot19.getWeight();
        java.awt.Paint paint25 = categoryPlot19.getRangeGridlinePaint();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer26 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer26.clearSeriesStrokes(true);
        java.awt.Stroke stroke30 = xYBarRenderer26.lookupSeriesOutlineStroke(100);
        xYBarRenderer26.setShadowXOffset((double) 100.0f);
        java.awt.Stroke stroke33 = xYBarRenderer26.getBaseOutlineStroke();
        java.awt.Paint paint34 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem35 = new org.jfree.chart.LegendItem("", "TextBlockAnchor.TOP_RIGHT", "{0}: ({1}, {2})", "", shape14, paint25, stroke33, paint34);
        java.awt.Color color36 = java.awt.Color.lightGray;
        legendItem35.setLabelPaint((java.awt.Paint) color36);
        java.awt.Paint paint38 = legendItem35.getLinePaint();
        xYStepRenderer0.setBaseOutlinePaint(paint38);
        java.awt.Shape shape41 = xYStepRenderer0.getSeriesShape(12);
        java.lang.Object obj42 = null;
        boolean boolean43 = xYStepRenderer0.equals(obj42);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNull(shape41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.ANTICLOCKWISE;
        java.lang.String str1 = rotation0.toString();
        org.junit.Assert.assertNotNull(rotation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Rotation.ANTICLOCKWISE" + "'", str1.equals("Rotation.ANTICLOCKWISE"));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        int int2 = combinedDomainXYPlot0.getDomainAxisIndex(valueAxis1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = combinedDomainXYPlot0.getRangeAxisIndex(valueAxis3);
        java.awt.Paint paint5 = combinedDomainXYPlot0.getDomainZeroBaselinePaint();
        boolean boolean6 = combinedDomainXYPlot0.isDomainZeroBaselineVisible();
        org.jfree.chart.util.Layer layer7 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection8 = combinedDomainXYPlot0.getRangeMarkers(layer7);
        java.awt.Stroke stroke9 = combinedDomainXYPlot0.getDomainMinorGridlineStroke();
        org.jfree.chart.plot.PlotOrientation plotOrientation10 = combinedDomainXYPlot0.getOrientation();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(layer7);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(plotOrientation10);
    }

//    @Test
//    public void test390() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test390");
//        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
//        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset) defaultPieDataset0);
//        org.jfree.chart.urls.PieURLGenerator pieURLGenerator2 = null;
//        ringPlot1.setURLGenerator(pieURLGenerator2);
//        double double4 = ringPlot1.getInteriorGap();
//        double double5 = ringPlot1.getStartAngle();
//        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, valueAxis8, categoryItemRenderer9);
//        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot10.getDomainAxisEdge();
//        boolean boolean12 = categoryPlot10.isRangeGridlinesVisible();
//        java.lang.Comparable comparable13 = categoryPlot10.getDomainCrosshairColumnKey();
//        java.awt.Paint paint14 = categoryPlot10.getDomainCrosshairPaint();
//        ringPlot1.setBaseSectionOutlinePaint(paint14);
//        java.awt.Paint paint16 = ringPlot1.getBaseSectionOutlinePaint();
//        boolean boolean17 = ringPlot1.getIgnoreNullValues();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date21 = spreadsheetDate20.toDate();
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date21);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        long long24 = day23.getLastMillisecond();
//        org.jfree.chart.axis.PeriodAxis periodAxis25 = new org.jfree.chart.axis.PeriodAxis("$8.00", (org.jfree.data.time.RegularTimePeriod) day22, (org.jfree.data.time.RegularTimePeriod) day23);
//        java.lang.String str26 = periodAxis25.getLabelToolTip();
//        java.util.TimeZone timeZone27 = periodAxis25.getTimeZone();
//        java.awt.Paint paint28 = periodAxis25.getTickLabelPaint();
//        ringPlot1.setLabelShadowPaint(paint28);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.08d + "'", double4 == 0.08d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 90.0d + "'", double5 == 90.0d);
//        org.junit.Assert.assertNotNull(rectangleEdge11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertNull(comparable13);
//        org.junit.Assert.assertNotNull(paint14);
//        org.junit.Assert.assertNotNull(paint16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560495599999L + "'", long24 == 1560495599999L);
//        org.junit.Assert.assertNull(str26);
//        org.junit.Assert.assertNotNull(timeZone27);
//        org.junit.Assert.assertNotNull(paint28);
//    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date4 = spreadsheetDate3.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date7 = spreadsheetDate6.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date10 = spreadsheetDate9.toDate();
        boolean boolean11 = spreadsheetDate6.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
        boolean boolean12 = spreadsheetDate3.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
        int int13 = spreadsheetDate3.getYYYY();
        boolean boolean14 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1900 + "'", int13 == 1900);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

//    @Test
//    public void test393() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test393");
//        double[][] doubleArray2 = new double[][] {};
//        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("null", "LengthConstraintType.FIXED", doubleArray2);
//        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D5 = new org.jfree.chart.axis.CategoryAxis3D("ERROR : Relative To String");
//        categoryAxis3D5.clearCategoryLabelToolTips();
//        categoryAxis3D5.configure();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date11 = spreadsheetDate10.toDate();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        long long14 = day13.getLastMillisecond();
//        org.jfree.chart.axis.PeriodAxis periodAxis15 = new org.jfree.chart.axis.PeriodAxis("$8.00", (org.jfree.data.time.RegularTimePeriod) day12, (org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D5, (org.jfree.chart.axis.ValueAxis) periodAxis15, categoryItemRenderer16);
//        boolean boolean18 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset3);
//        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot19 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset3);
//        org.junit.Assert.assertNotNull(doubleArray2);
//        org.junit.Assert.assertNotNull(categoryDataset3);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560495599999L + "'", long14 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        java.util.Date date3 = spreadsheetDate1.toDate();
        java.util.TimeZone timeZone4 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date3, timeZone4);
        java.lang.Number number6 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, number6);
        boolean boolean8 = timeSeriesDataItem7.isSelected();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.util.List list1 = projectInfo0.getContributors();
        org.junit.Assert.assertNull(list1);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_RIGHT;
        java.lang.String str1 = textBlockAnchor0.toString();
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        boolean boolean3 = textBlockAnchor0.equals((java.lang.Object) textAnchor2);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        int int6 = combinedDomainXYPlot4.getDomainAxisIndex(valueAxis5);
        boolean boolean7 = textAnchor2.equals((java.lang.Object) combinedDomainXYPlot4);
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextBlockAnchor.TOP_RIGHT" + "'", str1.equals("TextBlockAnchor.TOP_RIGHT"));
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        java.awt.Shape shape0 = null;
        java.awt.Font font3 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("ClassContext", font3);
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("hi!", font3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = textTitle5.getPosition();
        try {
            org.jfree.chart.entity.TitleEntity titleEntity7 = new org.jfree.chart.entity.TitleEntity(shape0, (org.jfree.chart.title.Title) textTitle5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(rectangleEdge6);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "org.jfree.data.UnknownKeyException: TextBlockAnchor.TOP_RIGHT", "ItemLabelAnchor.INSIDE7", "DomainOrder.NONE");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date6 = spreadsheetDate5.toDate();
        java.util.Date date7 = spreadsheetDate5.toDate();
        java.util.TimeZone timeZone8 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date7, timeZone8);
        int int10 = month9.getYearValue();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month9, (java.lang.Number) 0.0f, false);
        timeSeries3.setMaximumItemAge((long) 0);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "org.jfree.data.UnknownKeyException: TextBlockAnchor.TOP_RIGHT", "ItemLabelAnchor.INSIDE7", "DomainOrder.NONE");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date22 = spreadsheetDate21.toDate();
        java.util.Date date23 = spreadsheetDate21.toDate();
        java.util.TimeZone timeZone24 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(date23, timeZone24);
        int int26 = month25.getYearValue();
        timeSeries19.add((org.jfree.data.time.RegularTimePeriod) month25, (java.lang.Number) 0.0f, false);
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(5, 1900);
        timeSeries19.add((org.jfree.data.time.RegularTimePeriod) month32, 2.0d, true);
        org.jfree.data.time.Year year36 = month32.getYear();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month32, 0.0d, false);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1900 + "'", int10 == 1900);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1900 + "'", int26 == 1900);
        org.junit.Assert.assertNotNull(year36);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer0.setBaseLinesVisible(true);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator4 = xYStepRenderer0.getSeriesItemLabelGenerator((int) '#');
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator8 = xYStepRenderer0.getItemLabelGenerator((int) (byte) 100, (-1), false);
        int int9 = xYStepRenderer0.getPassCount();
        boolean boolean10 = xYStepRenderer0.getBaseItemLabelsVisible();
        xYStepRenderer0.setSeriesLinesVisible(5, (java.lang.Boolean) true);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer14 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.data.Range range16 = xYStepRenderer14.findDomainBounds(xYDataset15);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator17 = null;
        xYStepRenderer14.setBaseToolTipGenerator(xYToolTipGenerator17);
        boolean boolean19 = xYStepRenderer14.getBaseShapesVisible();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator20 = null;
        xYStepRenderer14.setBaseToolTipGenerator(xYToolTipGenerator20, true);
        java.awt.Stroke stroke24 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        xYStepRenderer14.setSeriesOutlineStroke((int) (short) 1, stroke24);
        org.jfree.data.general.WaferMapDataset waferMapDataset26 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot27 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset26);
        java.awt.Font font28 = waferMapPlot27.getNoDataMessageFont();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent29 = null;
        waferMapPlot27.notifyListeners(plotChangeEvent29);
        boolean boolean31 = xYStepRenderer14.hasListener((java.util.EventListener) waferMapPlot27);
        waferMapPlot27.setNotify(false);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier34 = waferMapPlot27.getDrawingSupplier();
        boolean boolean35 = xYStepRenderer0.equals((java.lang.Object) drawingSupplier34);
        org.junit.Assert.assertNull(xYItemLabelGenerator4);
        org.junit.Assert.assertNull(xYItemLabelGenerator8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(drawingSupplier34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState1 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo0);
        java.awt.geom.Line2D line2D2 = xYItemRendererState1.workingLine;
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        int int8 = categoryPlot7.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation10 = null;
        categoryPlot7.setRangeAxisLocation(100, axisLocation10);
        int int12 = categoryPlot7.getWeight();
        java.awt.Paint paint13 = categoryPlot7.getRangeGridlinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier14 = null;
        categoryPlot7.setDrawingSupplier(drawingSupplier14, false);
        org.jfree.chart.entity.PlotEntity plotEntity17 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape) line2D2, (org.jfree.chart.plot.Plot) categoryPlot7);
        java.awt.Shape shape20 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) (short) -1, (float) 1L);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape24 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape20, rectangleAnchor21, (double) (short) 0, (double) 1);
        plotEntity17.setArea(shape20);
        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape20, (double) (-458), (float) 5, (float) 15);
        java.io.ObjectOutputStream objectOutputStream30 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeShape(shape29, objectOutputStream30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(line2D2);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(rectangleAnchor21);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(shape29);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getCurrencyInstance();
        boolean boolean1 = numberFormat0.isParseIntegerOnly();
        java.awt.Shape shape6 = null;
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis9, categoryItemRenderer10);
        int int12 = categoryPlot11.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation14 = null;
        categoryPlot11.setRangeAxisLocation(100, axisLocation14);
        int int16 = categoryPlot11.getWeight();
        java.awt.Paint paint17 = categoryPlot11.getRangeGridlinePaint();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer18 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer18.clearSeriesStrokes(true);
        java.awt.Stroke stroke22 = xYBarRenderer18.lookupSeriesOutlineStroke(100);
        xYBarRenderer18.setShadowXOffset((double) 100.0f);
        java.awt.Stroke stroke25 = xYBarRenderer18.getBaseOutlineStroke();
        java.awt.Paint paint26 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem27 = new org.jfree.chart.LegendItem("", "TextBlockAnchor.TOP_RIGHT", "{0}: ({1}, {2})", "", shape6, paint17, stroke25, paint26);
        java.awt.Color color28 = java.awt.Color.lightGray;
        legendItem27.setLabelPaint((java.awt.Paint) color28);
        java.awt.Shape shape30 = legendItem27.getLine();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot31 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        int int33 = combinedDomainXYPlot31.getDomainAxisIndex(valueAxis32);
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        int int35 = combinedDomainXYPlot31.getRangeAxisIndex(valueAxis34);
        java.awt.Paint paint36 = combinedDomainXYPlot31.getDomainZeroBaselinePaint();
        java.awt.Stroke stroke37 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        combinedDomainXYPlot31.setRangeZeroBaselineStroke(stroke37);
        org.jfree.chart.entity.PlotEntity plotEntity41 = new org.jfree.chart.entity.PlotEntity(shape30, (org.jfree.chart.plot.Plot) combinedDomainXYPlot31, "{0}: ({1}, {2})", "[size=$100.00]");
        try {
            java.lang.String str42 = numberFormat0.format((java.lang.Object) "[size=$100.00]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Cannot format given Object as a Number");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(stroke37);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("org.jfree.data.UnknownKeyException: TextBlockAnchor.TOP_RIGHT", graphics2D1, (float) 22801L, (-4126.0f), textAnchor4, (double) (-9999), textAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) 255, (double) 9999, (double) 100L, 0.0d);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            blockBorder4.draw(graphics2D5, rectangle2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        java.lang.String str1 = lengthAdjustmentType0.toString();
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "EXPAND" + "'", str1.equals("EXPAND"));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        int int2 = combinedDomainXYPlot0.getDomainAxisIndex(valueAxis1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = combinedDomainXYPlot0.getRangeAxis();
        boolean boolean4 = combinedDomainXYPlot0.isSubplot();
        combinedDomainXYPlot0.setRangeMinorGridlinesVisible(false);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer7 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer7.clearSeriesStrokes(true);
        java.awt.Stroke stroke11 = xYBarRenderer7.lookupSeriesOutlineStroke(100);
        xYBarRenderer7.setShadowXOffset((double) 100.0f);
        java.awt.Stroke stroke14 = xYBarRenderer7.getBaseOutlineStroke();
        boolean boolean15 = xYBarRenderer7.getBaseItemLabelsVisible();
        combinedDomainXYPlot0.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer7);
        java.awt.Paint paint17 = combinedDomainXYPlot0.getRangeTickBandPaint();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer18 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer18.clearSeriesStrokes(true);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator21 = xYBarRenderer18.getBaseItemLabelGenerator();
        java.awt.Paint paint23 = xYBarRenderer18.lookupSeriesPaint(9999);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition25 = xYBarRenderer18.getSeriesNegativeItemLabelPosition(6);
        org.jfree.data.time.TimeSeries timeSeries26 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection27 = new org.jfree.data.time.TimeSeriesCollection(timeSeries26);
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, categoryItemRenderer31);
        int int33 = categoryPlot32.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation35 = null;
        categoryPlot32.setRangeAxisLocation(100, axisLocation35);
        timeSeriesCollection27.removeChangeListener((org.jfree.data.general.DatasetChangeListener) categoryPlot32);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate39 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection27, true);
        org.jfree.data.Range range40 = xYBarRenderer18.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection27);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer41 = combinedDomainXYPlot0.getRendererForDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection27);
        java.awt.Paint paint42 = combinedDomainXYPlot0.getRangeMinorGridlinePaint();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertNull(xYItemLabelGenerator21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(itemLabelPosition25);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertNull(range40);
        org.junit.Assert.assertNull(xYItemRenderer41);
        org.junit.Assert.assertNotNull(paint42);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState1 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo0);
        java.awt.geom.Line2D line2D2 = xYItemRendererState1.workingLine;
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) line2D2, "{0}: ({1}, {2})", "series");
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) line2D2, 3.0d, (float) 'a', (float) (short) 0);
        java.awt.Font font11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot12 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        int int14 = combinedDomainXYPlot12.getDomainAxisIndex(valueAxis13);
        org.jfree.chart.axis.ValueAxis valueAxis15 = combinedDomainXYPlot12.getRangeAxis();
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("WMAP_Plot", font11, (org.jfree.chart.plot.Plot) combinedDomainXYPlot12, true);
        boolean boolean18 = jFreeChart17.getAntiAlias();
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        textTitle20.setPadding(rectangleInsets21);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = textTitle20.getMargin();
        jFreeChart17.setPadding(rectangleInsets23);
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity27 = new org.jfree.chart.entity.JFreeChartEntity(shape9, jFreeChart17, "MAJOR", "");
        org.jfree.chart.entity.ChartEntity chartEntity28 = new org.jfree.chart.entity.ChartEntity(shape9);
        org.junit.Assert.assertNotNull(line2D2);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(rectangleInsets23);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        int int3 = combinedDomainXYPlot1.getDomainAxisIndex(valueAxis2);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        int int5 = combinedDomainXYPlot1.getRangeAxisIndex(valueAxis4);
        java.awt.Paint paint6 = combinedDomainXYPlot1.getDomainZeroBaselinePaint();
        java.awt.Stroke stroke7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        combinedDomainXYPlot1.setRangeZeroBaselineStroke(stroke7);
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = combinedDomainXYPlot1.getRendererForDataset(xYDataset9);
        org.jfree.chart.axis.AxisLocation axisLocation12 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        combinedDomainXYPlot1.setRangeAxisLocation(0, axisLocation12);
        combinedDomainXYPlot0.setRangeAxisLocation(axisLocation12, true);
        boolean boolean16 = combinedDomainXYPlot0.isSubplot();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(xYItemRenderer10);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        java.awt.Paint paint0 = org.jfree.chart.axis.SymbolAxis.DEFAULT_GRID_BAND_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder(paint0);
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        int int2 = combinedDomainXYPlot0.getDomainAxisIndex(valueAxis1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = combinedDomainXYPlot0.getRangeAxis();
        boolean boolean4 = combinedDomainXYPlot0.isSubplot();
        combinedDomainXYPlot0.setRangeMinorGridlinesVisible(false);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer7 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer7.clearSeriesStrokes(true);
        java.awt.Stroke stroke11 = xYBarRenderer7.lookupSeriesOutlineStroke(100);
        xYBarRenderer7.setShadowXOffset((double) 100.0f);
        java.awt.Stroke stroke14 = xYBarRenderer7.getBaseOutlineStroke();
        boolean boolean15 = xYBarRenderer7.getBaseItemLabelsVisible();
        combinedDomainXYPlot0.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer7);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot18 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        int int20 = combinedDomainXYPlot18.getDomainAxisIndex(valueAxis19);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        int int22 = combinedDomainXYPlot18.getRangeAxisIndex(valueAxis21);
        java.awt.Paint paint23 = combinedDomainXYPlot18.getDomainZeroBaselinePaint();
        xYBarRenderer7.setSeriesItemLabelPaint(5, paint23, false);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(paint23);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        int int2 = combinedDomainXYPlot0.getDomainAxisIndex(valueAxis1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = combinedDomainXYPlot0.getRangeAxisIndex(valueAxis3);
        java.awt.Paint paint5 = combinedDomainXYPlot0.getDomainZeroBaselinePaint();
        org.jfree.data.general.DatasetGroup datasetGroup6 = combinedDomainXYPlot0.getDatasetGroup();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis10, categoryItemRenderer11);
        int int13 = categoryPlot12.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation15 = null;
        categoryPlot12.setRangeAxisLocation(100, axisLocation15);
        int int17 = categoryPlot12.getWeight();
        java.awt.Paint paint18 = categoryPlot12.getRangeGridlinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier19 = null;
        categoryPlot12.setDrawingSupplier(drawingSupplier19, false);
        boolean boolean22 = categoryPlot12.isDomainZoomable();
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, valueAxis25, categoryItemRenderer26);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = categoryPlot27.getDomainAxisEdge();
        java.awt.Paint paint29 = categoryPlot27.getOutlinePaint();
        java.awt.Paint paint32 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer33 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer33.clearSeriesStrokes(true);
        java.awt.Stroke stroke37 = xYBarRenderer33.lookupSeriesOutlineStroke(100);
        xYBarRenderer33.setShadowXOffset((double) 100.0f);
        java.awt.Stroke stroke40 = xYBarRenderer33.getBaseOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker41 = new org.jfree.chart.plot.ValueMarker(0.05d, paint32, stroke40);
        float float42 = valueMarker41.getAlpha();
        org.jfree.chart.util.Layer layer43 = null;
        boolean boolean44 = categoryPlot27.removeRangeMarker(100, (org.jfree.chart.plot.Marker) valueMarker41, layer43);
        categoryPlot12.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker41);
        org.jfree.chart.util.Layer layer46 = null;
        combinedDomainXYPlot0.addRangeMarker(3, (org.jfree.chart.plot.Marker) valueMarker41, layer46);
        java.awt.Paint paint48 = null;
        try {
            valueMarker41.setPaint(paint48);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(datasetGroup6);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertTrue("'" + float42 + "' != '" + 1.0f + "'", float42 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        double[][] doubleArray2 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("null", "LengthConstraintType.FIXED", doubleArray2);
        java.lang.Number number4 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset3);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertNull(number4);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("ClassContext");
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        java.awt.Shape shape4 = null;
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, valueAxis7, categoryItemRenderer8);
        int int10 = categoryPlot9.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation12 = null;
        categoryPlot9.setRangeAxisLocation(100, axisLocation12);
        int int14 = categoryPlot9.getWeight();
        java.awt.Paint paint15 = categoryPlot9.getRangeGridlinePaint();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer16 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer16.clearSeriesStrokes(true);
        java.awt.Stroke stroke20 = xYBarRenderer16.lookupSeriesOutlineStroke(100);
        xYBarRenderer16.setShadowXOffset((double) 100.0f);
        java.awt.Stroke stroke23 = xYBarRenderer16.getBaseOutlineStroke();
        java.awt.Paint paint24 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("", "TextBlockAnchor.TOP_RIGHT", "{0}: ({1}, {2})", "", shape4, paint15, stroke23, paint24);
        java.awt.Color color26 = java.awt.Color.lightGray;
        legendItem25.setLabelPaint((java.awt.Paint) color26);
        java.awt.Shape shape28 = legendItem25.getLine();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot29 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        int int31 = combinedDomainXYPlot29.getDomainAxisIndex(valueAxis30);
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        int int33 = combinedDomainXYPlot29.getRangeAxisIndex(valueAxis32);
        java.awt.Paint paint34 = combinedDomainXYPlot29.getDomainZeroBaselinePaint();
        java.awt.Stroke stroke35 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        combinedDomainXYPlot29.setRangeZeroBaselineStroke(stroke35);
        org.jfree.chart.entity.PlotEntity plotEntity39 = new org.jfree.chart.entity.PlotEntity(shape28, (org.jfree.chart.plot.Plot) combinedDomainXYPlot29, "{0}: ({1}, {2})", "[size=$100.00]");
        org.jfree.chart.title.TextTitle textTitle41 = new org.jfree.chart.title.TextTitle("hi!");
        double double42 = textTitle41.getContentXOffset();
        org.jfree.chart.entity.TitleEntity titleEntity44 = new org.jfree.chart.entity.TitleEntity(shape28, (org.jfree.chart.title.Title) textTitle41, "WMAP_Plot");
        double[][] doubleArray49 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset50 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("null", "LengthConstraintType.FIXED", doubleArray49);
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day51, (java.lang.Number) 255);
        java.lang.Object obj54 = timeSeriesDataItem53.clone();
        java.lang.Number number55 = null;
        timeSeriesDataItem53.setValue(number55);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate58 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date59 = spreadsheetDate58.toDate();
        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day(date59);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem62 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day60, (double) 100);
        long long63 = day60.getLastMillisecond();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity64 = new org.jfree.chart.entity.CategoryItemEntity(shape28, "", "WMAP_Plot", categoryDataset50, (java.lang.Comparable) timeSeriesDataItem53, (java.lang.Comparable) day60);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 1.0d + "'", double42 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(categoryDataset50);
        org.junit.Assert.assertNotNull(obj54);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + (-2208182400001L) + "'", long63 == (-2208182400001L));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        int int0 = org.jfree.data.time.SerialDate.MINIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1900 + "'", int0 == 1900);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("Category Plot");
        boolean boolean2 = legendItem1.isShapeVisible();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator1 = new org.jfree.chart.labels.StandardPieToolTipGenerator("NOID");
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.data.Range range2 = xYStepRenderer0.findDomainBounds(xYDataset1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = null;
        xYStepRenderer0.setBaseToolTipGenerator(xYToolTipGenerator3);
        boolean boolean5 = xYStepRenderer0.getBaseShapesVisible();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator6 = null;
        xYStepRenderer0.setBaseToolTipGenerator(xYToolTipGenerator6, true);
        java.awt.Stroke stroke10 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        xYStepRenderer0.setSeriesOutlineStroke((int) (short) 1, stroke10);
        org.jfree.data.general.WaferMapDataset waferMapDataset12 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot13 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset12);
        java.awt.Font font14 = waferMapPlot13.getNoDataMessageFont();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent15 = null;
        waferMapPlot13.notifyListeners(plotChangeEvent15);
        boolean boolean17 = xYStepRenderer0.hasListener((java.util.EventListener) waferMapPlot13);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = xYStepRenderer0.getDrawingSupplier();
        xYStepRenderer0.clearSeriesPaints(false);
        try {
            xYStepRenderer0.setSeriesShapesFilled((-1), false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier18);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        java.awt.Font font0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        categoryPlot4.setDataset(categoryDataset5);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot7 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        int int9 = combinedDomainXYPlot7.getDomainAxisIndex(valueAxis8);
        org.jfree.chart.axis.ValueAxis valueAxis10 = combinedDomainXYPlot7.getRangeAxis();
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, valueAxis13, categoryItemRenderer14);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = categoryPlot15.getDomainAxisEdge();
        java.awt.Paint paint17 = categoryPlot15.getOutlinePaint();
        java.awt.Paint paint20 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer21 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer21.clearSeriesStrokes(true);
        java.awt.Stroke stroke25 = xYBarRenderer21.lookupSeriesOutlineStroke(100);
        xYBarRenderer21.setShadowXOffset((double) 100.0f);
        java.awt.Stroke stroke28 = xYBarRenderer21.getBaseOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker29 = new org.jfree.chart.plot.ValueMarker(0.05d, paint20, stroke28);
        float float30 = valueMarker29.getAlpha();
        org.jfree.chart.util.Layer layer31 = null;
        boolean boolean32 = categoryPlot15.removeRangeMarker(100, (org.jfree.chart.plot.Marker) valueMarker29, layer31);
        org.jfree.chart.text.TextAnchor textAnchor33 = valueMarker29.getLabelTextAnchor();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot34 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        int int36 = combinedDomainXYPlot34.getDomainAxisIndex(valueAxis35);
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        int int38 = combinedDomainXYPlot34.getRangeAxisIndex(valueAxis37);
        java.awt.Paint paint39 = combinedDomainXYPlot34.getDomainZeroBaselinePaint();
        boolean boolean40 = combinedDomainXYPlot34.isDomainZeroBaselineVisible();
        org.jfree.chart.util.Layer layer41 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection42 = combinedDomainXYPlot34.getRangeMarkers(layer41);
        combinedDomainXYPlot7.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker29, layer41);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent44 = null;
        valueMarker29.notifyListeners(markerChangeEvent44);
        boolean boolean46 = categoryPlot4.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker29);
        java.awt.Graphics2D graphics2D47 = null;
        java.awt.Font font49 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot50 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis51 = null;
        int int52 = combinedDomainXYPlot50.getDomainAxisIndex(valueAxis51);
        org.jfree.chart.axis.ValueAxis valueAxis53 = combinedDomainXYPlot50.getRangeAxis();
        org.jfree.chart.JFreeChart jFreeChart55 = new org.jfree.chart.JFreeChart("WMAP_Plot", font49, (org.jfree.chart.plot.Plot) combinedDomainXYPlot50, true);
        org.jfree.chart.title.TextTitle textTitle57 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle57.setMaximumLinesToDisplay(1);
        org.jfree.data.category.CategoryDataset categoryDataset60 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis61 = null;
        org.jfree.chart.axis.ValueAxis valueAxis62 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer63 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot64 = new org.jfree.chart.plot.CategoryPlot(categoryDataset60, categoryAxis61, valueAxis62, categoryItemRenderer63);
        org.jfree.chart.util.RectangleEdge rectangleEdge65 = categoryPlot64.getDomainAxisEdge();
        textTitle57.setPosition(rectangleEdge65);
        org.jfree.chart.util.RectangleInsets rectangleInsets67 = textTitle57.getPadding();
        jFreeChart55.removeSubtitle((org.jfree.chart.title.Title) textTitle57);
        org.jfree.chart.title.LegendTitle legendTitle69 = jFreeChart55.getLegend();
        org.jfree.chart.block.BlockContainer blockContainer70 = legendTitle69.getItemContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets71 = legendTitle69.getPadding();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor72 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        legendTitle69.setLegendItemGraphicAnchor(rectangleAnchor72);
        java.awt.geom.Rectangle2D rectangle2D74 = legendTitle69.getBounds();
        try {
            categoryPlot4.drawBackground(graphics2D47, rectangle2D74);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 1.0f + "'", float30 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(textAnchor33);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(layer41);
        org.junit.Assert.assertNull(collection42);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(font49);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
        org.junit.Assert.assertNull(valueAxis53);
        org.junit.Assert.assertNotNull(rectangleEdge65);
        org.junit.Assert.assertNotNull(rectangleInsets67);
        org.junit.Assert.assertNotNull(legendTitle69);
        org.junit.Assert.assertNotNull(blockContainer70);
        org.junit.Assert.assertNotNull(rectangleInsets71);
        org.junit.Assert.assertNotNull(rectangleAnchor72);
        org.junit.Assert.assertNotNull(rectangle2D74);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("java.awt.Color[r=0,g=255,b=0]");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.Font font5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot6 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        int int8 = combinedDomainXYPlot6.getDomainAxisIndex(valueAxis7);
        org.jfree.chart.axis.ValueAxis valueAxis9 = combinedDomainXYPlot6.getRangeAxis();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("WMAP_Plot", font5, (org.jfree.chart.plot.Plot) combinedDomainXYPlot6, true);
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle13.setMaximumLinesToDisplay(1);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis18, categoryItemRenderer19);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = categoryPlot20.getDomainAxisEdge();
        textTitle13.setPosition(rectangleEdge21);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = textTitle13.getPadding();
        jFreeChart11.removeSubtitle((org.jfree.chart.title.Title) textTitle13);
        org.jfree.chart.title.LegendTitle legendTitle25 = jFreeChart11.getLegend();
        org.jfree.chart.block.BlockContainer blockContainer26 = legendTitle25.getItemContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = legendTitle25.getPadding();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor28 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        legendTitle25.setLegendItemGraphicAnchor(rectangleAnchor28);
        java.awt.geom.Rectangle2D rectangle2D30 = legendTitle25.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = org.jfree.chart.util.RectangleEdge.LEFT;
        try {
            java.util.List list32 = logAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D30, rectangleEdge31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(legendTitle25);
        org.junit.Assert.assertNotNull(blockContainer26);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(rectangleAnchor28);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(rectangleEdge31);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.Paint paint2 = periodAxis1.getMinorTickMarkPaint();
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) (short) -1, (float) 1L);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape2, rectangleAnchor3, (double) (short) 0, (double) 1);
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis9, categoryItemRenderer10);
        int int12 = categoryPlot11.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation14 = null;
        categoryPlot11.setRangeAxisLocation(100, axisLocation14);
        int int16 = categoryPlot11.getWeight();
        java.awt.Paint paint17 = categoryPlot11.getRangeGridlinePaint();
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.data.Range range19 = categoryPlot11.getDataRange(valueAxis18);
        java.awt.Stroke stroke20 = categoryPlot11.getRangeMinorGridlineStroke();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D23 = new org.jfree.chart.axis.CategoryAxis3D("ERROR : Relative To String");
        categoryAxis3D23.clearCategoryLabelToolTips();
        categoryPlot11.setDomainAxis((int) '#', (org.jfree.chart.axis.CategoryAxis) categoryAxis3D23, false);
        java.awt.Font font27 = categoryAxis3D23.getLabelFont();
        float float28 = categoryAxis3D23.getTickMarkInsideLength();
        org.jfree.chart.entity.AxisEntity axisEntity29 = new org.jfree.chart.entity.AxisEntity(shape2, (org.jfree.chart.axis.Axis) categoryAxis3D23);
        java.lang.Object obj30 = axisEntity29.clone();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNull(range19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertTrue("'" + float28 + "' != '" + 0.0f + "'", float28 == 0.0f);
        org.junit.Assert.assertNotNull(obj30);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        int int2 = combinedDomainXYPlot0.getDomainAxisIndex(valueAxis1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = combinedDomainXYPlot0.getRangeAxis();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = categoryPlot8.getDomainAxisEdge();
        java.awt.Paint paint10 = categoryPlot8.getOutlinePaint();
        java.awt.Paint paint13 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer14 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer14.clearSeriesStrokes(true);
        java.awt.Stroke stroke18 = xYBarRenderer14.lookupSeriesOutlineStroke(100);
        xYBarRenderer14.setShadowXOffset((double) 100.0f);
        java.awt.Stroke stroke21 = xYBarRenderer14.getBaseOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker(0.05d, paint13, stroke21);
        float float23 = valueMarker22.getAlpha();
        org.jfree.chart.util.Layer layer24 = null;
        boolean boolean25 = categoryPlot8.removeRangeMarker(100, (org.jfree.chart.plot.Marker) valueMarker22, layer24);
        org.jfree.chart.text.TextAnchor textAnchor26 = valueMarker22.getLabelTextAnchor();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot27 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        int int29 = combinedDomainXYPlot27.getDomainAxisIndex(valueAxis28);
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        int int31 = combinedDomainXYPlot27.getRangeAxisIndex(valueAxis30);
        java.awt.Paint paint32 = combinedDomainXYPlot27.getDomainZeroBaselinePaint();
        boolean boolean33 = combinedDomainXYPlot27.isDomainZeroBaselineVisible();
        org.jfree.chart.util.Layer layer34 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection35 = combinedDomainXYPlot27.getRangeMarkers(layer34);
        combinedDomainXYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker22, layer34);
        java.awt.Stroke stroke37 = combinedDomainXYPlot0.getRangeMinorGridlineStroke();
        combinedDomainXYPlot0.setRangeCrosshairValue((double) 0.0f);
        org.jfree.chart.LegendItemCollection legendItemCollection40 = combinedDomainXYPlot0.getFixedLegendItems();
        org.jfree.chart.axis.PeriodAxis periodAxis43 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis43.pan((double) (-4126));
        org.jfree.data.time.DateRange dateRange46 = new org.jfree.data.time.DateRange();
        org.jfree.data.Range range49 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange46, (double) 3, true);
        double double50 = dateRange46.getCentralValue();
        periodAxis43.setRangeWithMargins((org.jfree.data.Range) dateRange46);
        combinedDomainXYPlot0.setDomainAxis(9999, (org.jfree.chart.axis.ValueAxis) periodAxis43);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 1.0f + "'", float23 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(textAnchor26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(layer34);
        org.junit.Assert.assertNull(collection35);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNull(legendItemCollection40);
        org.junit.Assert.assertNotNull(range49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.5d + "'", double50 == 0.5d);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.data.Range range4 = xYStepRenderer2.findDomainBounds(xYDataset3);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator5 = null;
        xYStepRenderer2.setBaseToolTipGenerator(xYToolTipGenerator5);
        boolean boolean7 = xYStepRenderer2.getBaseShapesVisible();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator8 = null;
        xYStepRenderer2.setBaseToolTipGenerator(xYToolTipGenerator8, true);
        java.text.DateFormat dateFormat12 = null;
        java.text.DateFormat dateFormat13 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator14 = new org.jfree.chart.labels.StandardXYToolTipGenerator("{0}: ({1}, {2})", dateFormat12, dateFormat13);
        xYStepRenderer2.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator14);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator16 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer17 = new org.jfree.chart.renderer.xy.XYAreaRenderer(3, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator14, xYURLGenerator16);
        java.lang.Object obj18 = null;
        boolean boolean19 = standardXYToolTipGenerator14.equals(obj18);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator20 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer21 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator14, xYURLGenerator20);
        java.awt.Paint paint22 = xYStepAreaRenderer21.getBaseLegendTextPaint();
        double double23 = xYStepAreaRenderer21.getRangeBase();
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(paint22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 7);
        java.lang.String str2 = xYSeries1.getDescription();
        org.jfree.data.xy.XYSeries xYSeries5 = xYSeries1.createCopy((int) 'a', (-1));
        int int6 = xYSeries5.getMaximumItemCount();
        boolean boolean7 = xYSeries5.getAutoSort();
        java.lang.String str8 = xYSeries5.getDescription();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(xYSeries5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2147483647 + "'", int6 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getCurrencyInstance();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit((double) 100L, numberFormat1);
        numberFormat1.setMinimumFractionDigits(0);
        java.text.NumberFormat numberFormat7 = java.text.NumberFormat.getCurrencyInstance();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit8 = new org.jfree.chart.axis.NumberTickUnit((double) 100L, numberFormat7);
        java.lang.String str10 = numberFormat7.format((long) 8);
        boolean boolean11 = numberFormat7.isGroupingUsed();
        int int12 = numberFormat7.getMaximumFractionDigits();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit14 = new org.jfree.chart.axis.NumberTickUnit((double) 0.0f, numberFormat7, 2147483647);
        java.math.RoundingMode roundingMode15 = numberFormat7.getRoundingMode();
        numberFormat1.setRoundingMode(roundingMode15);
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertNotNull(numberFormat7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "$8.00" + "'", str10.equals("$8.00"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertTrue("'" + roundingMode15 + "' != '" + java.math.RoundingMode.HALF_EVEN + "'", roundingMode15.equals(java.math.RoundingMode.HALF_EVEN));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot2 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = combinedDomainXYPlot2.getDomainAxisIndex(valueAxis3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = combinedDomainXYPlot2.getRangeAxis();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("WMAP_Plot", font1, (org.jfree.chart.plot.Plot) combinedDomainXYPlot2, true);
        boolean boolean8 = jFreeChart7.getAntiAlias();
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        textTitle10.setPadding(rectangleInsets11);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = textTitle10.getMargin();
        jFreeChart7.setPadding(rectangleInsets13);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        java.awt.image.BufferedImage bufferedImage18 = jFreeChart7.createBufferedImage((int) (short) 1, 3, chartRenderingInfo17);
        jFreeChart7.setAntiAlias(false);
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle22.setMaximumLinesToDisplay(1);
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset25, categoryAxis26, valueAxis27, categoryItemRenderer28);
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = categoryPlot29.getDomainAxisEdge();
        textTitle22.setPosition(rectangleEdge30);
        textTitle22.setPadding((double) '#', (double) (short) -1, 0.0d, (double) (byte) 10);
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = textTitle22.getPadding();
        jFreeChart7.setTitle(textTitle22);
        jFreeChart7.setTextAntiAlias(true);
        org.jfree.chart.title.TextTitle textTitle41 = jFreeChart7.getTitle();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(bufferedImage18);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertNotNull(textTitle41);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date4 = spreadsheetDate3.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date7 = spreadsheetDate6.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date10 = spreadsheetDate9.toDate();
        boolean boolean11 = spreadsheetDate6.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
        boolean boolean12 = spreadsheetDate3.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date15 = spreadsheetDate14.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date18 = spreadsheetDate17.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date21 = spreadsheetDate20.toDate();
        boolean boolean22 = spreadsheetDate17.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate20);
        boolean boolean23 = spreadsheetDate14.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean27 = spreadsheetDate3.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate14, (org.jfree.data.time.SerialDate) spreadsheetDate25, 0);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date30 = spreadsheetDate29.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date33 = spreadsheetDate32.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date36 = spreadsheetDate35.toDate();
        boolean boolean37 = spreadsheetDate32.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate35);
        boolean boolean38 = spreadsheetDate29.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate35);
        int int39 = spreadsheetDate29.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date42 = spreadsheetDate41.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date45 = spreadsheetDate44.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date48 = spreadsheetDate47.toDate();
        boolean boolean49 = spreadsheetDate44.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate47);
        boolean boolean50 = spreadsheetDate41.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate47);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate52 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date53 = spreadsheetDate52.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate55 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date56 = spreadsheetDate55.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate58 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date59 = spreadsheetDate58.toDate();
        boolean boolean60 = spreadsheetDate55.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate58);
        boolean boolean61 = spreadsheetDate52.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate58);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate63 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean65 = spreadsheetDate41.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate52, (org.jfree.data.time.SerialDate) spreadsheetDate63, 0);
        boolean boolean67 = spreadsheetDate3.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate29, (org.jfree.data.time.SerialDate) spreadsheetDate41, (int) (byte) 100);
        java.lang.String str68 = spreadsheetDate41.toString();
        org.jfree.data.time.SerialDate serialDate69 = org.jfree.data.time.SerialDate.addMonths((int) '4', (org.jfree.data.time.SerialDate) spreadsheetDate41);
        org.jfree.data.time.SerialDate serialDate70 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(6, serialDate69);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1900 + "'", int39 == 1900);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "9-January-1900" + "'", str68.equals("9-January-1900"));
        org.junit.Assert.assertNotNull(serialDate69);
        org.junit.Assert.assertNotNull(serialDate70);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        org.jfree.chart.util.PaintMap paintMap0 = new org.jfree.chart.util.PaintMap();
        boolean boolean2 = paintMap0.containsKey((java.lang.Comparable) 9999);
        boolean boolean4 = paintMap0.containsKey((java.lang.Comparable) "{0}");
        boolean boolean6 = paintMap0.equals((java.lang.Object) 1900);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        java.lang.String str1 = org.jfree.chart.util.PaintUtilities.colorToString(color0);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#40ff40" + "'", str1.equals("#40ff40"));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0);
        org.jfree.chart.LegendItem legendItem4 = xYAreaRenderer1.getLegendItem((int) 'a', 2);
        xYAreaRenderer1.setOutline(false);
        org.junit.Assert.assertNull(legendItem4);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation(100, axisLocation7);
        int int9 = categoryPlot4.getWeight();
        java.awt.Paint paint10 = categoryPlot4.getRangeGridlinePaint();
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.data.Range range12 = categoryPlot4.getDataRange(valueAxis11);
        java.awt.Stroke stroke13 = categoryPlot4.getRangeMinorGridlineStroke();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D16 = new org.jfree.chart.axis.CategoryAxis3D("ERROR : Relative To String");
        categoryAxis3D16.clearCategoryLabelToolTips();
        categoryPlot4.setDomainAxis((int) '#', (org.jfree.chart.axis.CategoryAxis) categoryAxis3D16, false);
        java.awt.Font font20 = categoryAxis3D16.getLabelFont();
        float float21 = categoryAxis3D16.getTickMarkInsideLength();
        java.lang.Object obj22 = categoryAxis3D16.clone();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 0.0f + "'", float21 == 0.0f);
        org.junit.Assert.assertNotNull(obj22);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        java.util.Date date3 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) (short) 100);
        pieLabelDistributor1.sort();
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.data.Range range2 = xYBarRenderer0.findRangeBounds(xYDataset1);
        double double3 = xYBarRenderer0.getShadowXOffset();
        java.awt.Shape shape5 = xYBarRenderer0.lookupSeriesShape(1900);
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit(0.0d);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (short) 10, 2, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.data.Range range2 = xYStepRenderer0.findDomainBounds(xYDataset1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = null;
        xYStepRenderer0.setBaseToolTipGenerator(xYToolTipGenerator3);
        boolean boolean5 = xYStepRenderer0.getBaseShapesVisible();
        double double6 = xYStepRenderer0.getStepPoint();
        org.jfree.chart.plot.XYPlot xYPlot7 = xYStepRenderer0.getPlot();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = xYStepRenderer0.getSeriesNegativeItemLabelPosition(0);
        boolean boolean10 = xYStepRenderer0.getBaseItemLabelsVisible();
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNull(xYPlot7);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation(100, axisLocation7);
        int int9 = categoryPlot4.getWeight();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot4.panDomainAxes((double) 1, plotRenderingInfo11, point2D12);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        int int2 = combinedDomainXYPlot0.getDomainAxisIndex(valueAxis1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = combinedDomainXYPlot0.getRangeAxis();
        boolean boolean4 = combinedDomainXYPlot0.isSubplot();
        combinedDomainXYPlot0.setRangeMinorGridlinesVisible(false);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer7 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer7.clearSeriesStrokes(true);
        java.awt.Stroke stroke11 = xYBarRenderer7.lookupSeriesOutlineStroke(100);
        xYBarRenderer7.setShadowXOffset((double) 100.0f);
        java.awt.Stroke stroke14 = xYBarRenderer7.getBaseOutlineStroke();
        boolean boolean15 = xYBarRenderer7.getBaseItemLabelsVisible();
        combinedDomainXYPlot0.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer7);
        java.awt.Shape shape17 = xYBarRenderer7.getLegendBar();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(shape17);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        java.awt.Paint paint1 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer2 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer2.clearSeriesStrokes(true);
        java.awt.Stroke stroke6 = xYBarRenderer2.lookupSeriesOutlineStroke(100);
        xYBarRenderer2.setShadowXOffset((double) 100.0f);
        java.awt.Stroke stroke9 = xYBarRenderer2.getBaseOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.05d, paint1, stroke9);
        org.jfree.chart.text.TextAnchor textAnchor11 = valueMarker10.getLabelTextAnchor();
        java.awt.Font font12 = valueMarker10.getLabelFont();
        java.awt.Paint paint13 = valueMarker10.getOutlinePaint();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType14 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        valueMarker10.setLabelOffsetType(lengthAdjustmentType14);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(textAnchor11);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(lengthAdjustmentType14);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset) defaultPieDataset0);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = ringPlot1.getLegendLabelGenerator();
        ringPlot1.setSectionOutlinesVisible(false);
        java.lang.String str5 = ringPlot1.getPlotType();
        java.awt.Stroke stroke6 = null;
        try {
            ringPlot1.setLabelLinkStroke(stroke6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Pie Plot" + "'", str5.equals("Pie Plot"));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=0,g=255,b=0]");
        numberAxis1.setRangeAboutValue((double) (-1.0f), (double) (byte) 0);
        java.text.NumberFormat numberFormat5 = numberAxis1.getNumberFormatOverride();
        org.junit.Assert.assertNull(numberFormat5);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState6 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo5);
        java.awt.geom.Line2D line2D7 = xYItemRendererState6.workingLine;
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape) line2D7, (double) (-1L), (double) (short) -1);
        java.awt.Paint paint11 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, categoryItemRenderer15);
        int int17 = categoryPlot16.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation19 = null;
        categoryPlot16.setRangeAxisLocation(100, axisLocation19);
        int int21 = categoryPlot16.getWeight();
        java.awt.Paint paint22 = categoryPlot16.getRangeGridlinePaint();
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.data.Range range24 = categoryPlot16.getDataRange(valueAxis23);
        java.awt.Stroke stroke25 = categoryPlot16.getRangeMinorGridlineStroke();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D28 = new org.jfree.chart.axis.CategoryAxis3D("ERROR : Relative To String");
        categoryAxis3D28.clearCategoryLabelToolTips();
        categoryPlot16.setDomainAxis((int) '#', (org.jfree.chart.axis.CategoryAxis) categoryAxis3D28, false);
        categoryAxis3D28.setCategoryMargin((double) 7);
        java.awt.Stroke stroke34 = categoryAxis3D28.getTickMarkStroke();
        java.awt.Paint paint36 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer37 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer37.clearSeriesStrokes(true);
        java.awt.Stroke stroke41 = xYBarRenderer37.lookupSeriesOutlineStroke(100);
        xYBarRenderer37.setShadowXOffset((double) 100.0f);
        java.awt.Stroke stroke44 = xYBarRenderer37.getBaseOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker45 = new org.jfree.chart.plot.ValueMarker(0.05d, paint36, stroke44);
        org.jfree.chart.text.TextAnchor textAnchor46 = valueMarker45.getLabelTextAnchor();
        java.awt.Font font47 = valueMarker45.getLabelFont();
        java.awt.Paint paint48 = valueMarker45.getOutlinePaint();
        org.jfree.chart.LegendItem legendItem49 = new org.jfree.chart.LegendItem("TextBlockAnchor.TOP_RIGHT", "($1.00)", "MAJOR", "TextBlockAnchor.TOP_RIGHT", shape10, paint11, stroke34, paint48);
        try {
            org.jfree.chart.util.ShapeUtilities.drawRotatedShape(graphics2D0, shape10, (double) 1, (float) 1900, 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(line2D7);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(textAnchor46);
        org.junit.Assert.assertNotNull(font47);
        org.junit.Assert.assertNotNull(paint48);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset) defaultPieDataset0);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator2 = null;
        ringPlot1.setURLGenerator(pieURLGenerator2);
        double double4 = ringPlot1.getInteriorGap();
        double double5 = ringPlot1.getStartAngle();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, valueAxis8, categoryItemRenderer9);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot10.getDomainAxisEdge();
        boolean boolean12 = categoryPlot10.isRangeGridlinesVisible();
        java.lang.Comparable comparable13 = categoryPlot10.getDomainCrosshairColumnKey();
        java.awt.Paint paint14 = categoryPlot10.getDomainCrosshairPaint();
        ringPlot1.setBaseSectionOutlinePaint(paint14);
        boolean boolean16 = ringPlot1.getIgnoreZeroValues();
        ringPlot1.clearSectionOutlineStrokes(true);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.08d + "'", double4 == 0.08d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 90.0d + "'", double5 == 90.0d);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(comparable13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.clearSeriesStrokes(true);
        java.awt.Stroke stroke4 = xYBarRenderer0.lookupSeriesOutlineStroke(100);
        xYBarRenderer0.setShadowXOffset((double) 100.0f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState9 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo8);
        java.awt.geom.Line2D line2D10 = xYItemRendererState9.workingLine;
        xYBarRenderer0.setLegendShape(0, (java.awt.Shape) line2D10);
        boolean boolean12 = xYBarRenderer0.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        xYBarRenderer0.notifyListeners(rendererChangeEvent13);
        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter15 = org.jfree.chart.renderer.xy.XYBarRenderer.getDefaultBarPainter();
        xYBarRenderer0.setBarPainter(xYBarPainter15);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(line2D10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(xYBarPainter15);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        java.awt.Shape shape4 = null;
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, valueAxis7, categoryItemRenderer8);
        int int10 = categoryPlot9.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation12 = null;
        categoryPlot9.setRangeAxisLocation(100, axisLocation12);
        int int14 = categoryPlot9.getWeight();
        java.awt.Paint paint15 = categoryPlot9.getRangeGridlinePaint();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer16 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer16.clearSeriesStrokes(true);
        java.awt.Stroke stroke20 = xYBarRenderer16.lookupSeriesOutlineStroke(100);
        xYBarRenderer16.setShadowXOffset((double) 100.0f);
        java.awt.Stroke stroke23 = xYBarRenderer16.getBaseOutlineStroke();
        java.awt.Paint paint24 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("", "TextBlockAnchor.TOP_RIGHT", "{0}: ({1}, {2})", "", shape4, paint15, stroke23, paint24);
        java.awt.Color color26 = java.awt.Color.lightGray;
        legendItem25.setLabelPaint((java.awt.Paint) color26);
        java.awt.Shape shape28 = legendItem25.getLine();
        legendItem25.setShapeVisible(true);
        org.jfree.data.general.DefaultPieDataset defaultPieDataset31 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.chart.plot.RingPlot ringPlot32 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset) defaultPieDataset31);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator33 = null;
        ringPlot32.setURLGenerator(pieURLGenerator33);
        java.awt.Color color36 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.Color color37 = color36.darker();
        ringPlot32.setSectionPaint((java.lang.Comparable) 2, (java.awt.Paint) color36);
        legendItem25.setLabelPaint((java.awt.Paint) color36);
        java.util.TimeZone timeZone40 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection41 = new org.jfree.data.time.TimeSeriesCollection(timeZone40);
        org.jfree.data.general.DatasetGroup datasetGroup42 = timeSeriesCollection41.getGroup();
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState43 = timeSeriesCollection41.getSelectionState();
        legendItem25.setDataset((org.jfree.data.general.Dataset) timeSeriesCollection41);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(datasetGroup42);
        org.junit.Assert.assertNotNull(xYDatasetSelectionState43);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0);
        double double3 = timeSeriesCollection1.getDomainLowerBound(true);
        java.awt.Paint paint5 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer6 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer6.clearSeriesStrokes(true);
        java.awt.Stroke stroke10 = xYBarRenderer6.lookupSeriesOutlineStroke(100);
        xYBarRenderer6.setShadowXOffset((double) 100.0f);
        java.awt.Stroke stroke13 = xYBarRenderer6.getBaseOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker(0.05d, paint5, stroke13);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent15 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) stroke13);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo16 = seriesChangeEvent15.getSummary();
        timeSeriesCollection1.seriesChanged(seriesChangeEvent15);
        try {
            int int19 = timeSeriesCollection1.getItemCount(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNull(seriesChangeInfo16);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset) defaultPieDataset0);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator2 = null;
        ringPlot1.setURLGenerator(pieURLGenerator2);
        double double4 = ringPlot1.getInteriorGap();
        double double5 = ringPlot1.getStartAngle();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, valueAxis8, categoryItemRenderer9);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot10.getDomainAxisEdge();
        boolean boolean12 = categoryPlot10.isRangeGridlinesVisible();
        java.lang.Comparable comparable13 = categoryPlot10.getDomainCrosshairColumnKey();
        java.awt.Paint paint14 = categoryPlot10.getDomainCrosshairPaint();
        ringPlot1.setBaseSectionOutlinePaint(paint14);
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) (short) -1, (float) 1L);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape18, rectangleAnchor19, (double) (short) 0, (double) 1);
        ringPlot1.setLegendItemShape(shape18);
        ringPlot1.setShadowYOffset((double) 0);
        java.awt.Paint paint26 = ringPlot1.getLabelBackgroundPaint();
        double double27 = ringPlot1.getSectionDepth();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.08d + "'", double4 == 0.08d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 90.0d + "'", double5 == 90.0d);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(comparable13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(rectangleAnchor19);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.2d + "'", double27 == 0.2d);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 7);
        java.lang.String str2 = xYSeries1.getDescription();
        org.jfree.data.xy.XYSeries xYSeries5 = xYSeries1.createCopy((int) 'a', (-1));
        double double6 = xYSeries1.getMaxY();
        org.jfree.data.xy.XYDataItem xYDataItem7 = null;
        try {
            xYSeries1.add(xYDataItem7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(xYSeries5);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = categoryPlot4.getDomainAxisEdge();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = categoryPlot4.getDomainAxis();
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        categoryPlot4.setOrientation(plotOrientation7);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator9 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        boolean boolean10 = plotOrientation7.equals((java.lang.Object) standardPieSectionLabelGenerator9);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNull(categoryAxis6);
        org.junit.Assert.assertNotNull(plotOrientation7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot2 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = combinedDomainXYPlot2.getDomainAxisIndex(valueAxis3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = combinedDomainXYPlot2.getRangeAxis();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("WMAP_Plot", font1, (org.jfree.chart.plot.Plot) combinedDomainXYPlot2, true);
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle9.setMaximumLinesToDisplay(1);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, categoryItemRenderer15);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot16.getDomainAxisEdge();
        textTitle9.setPosition(rectangleEdge17);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = textTitle9.getPadding();
        jFreeChart7.removeSubtitle((org.jfree.chart.title.Title) textTitle9);
        org.jfree.chart.title.LegendTitle legendTitle21 = jFreeChart7.getLegend();
        org.jfree.chart.block.BlockContainer blockContainer22 = legendTitle21.getItemContainer();
        java.awt.Paint paint23 = legendTitle21.getItemPaint();
        java.awt.Paint paint24 = legendTitle21.getItemPaint();
        java.awt.Graphics2D graphics2D25 = null;
        java.awt.Font font27 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot28 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        int int30 = combinedDomainXYPlot28.getDomainAxisIndex(valueAxis29);
        org.jfree.chart.axis.ValueAxis valueAxis31 = combinedDomainXYPlot28.getRangeAxis();
        org.jfree.chart.JFreeChart jFreeChart33 = new org.jfree.chart.JFreeChart("WMAP_Plot", font27, (org.jfree.chart.plot.Plot) combinedDomainXYPlot28, true);
        org.jfree.chart.title.TextTitle textTitle35 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle35.setMaximumLinesToDisplay(1);
        org.jfree.data.category.CategoryDataset categoryDataset38 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = null;
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer41 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot(categoryDataset38, categoryAxis39, valueAxis40, categoryItemRenderer41);
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = categoryPlot42.getDomainAxisEdge();
        textTitle35.setPosition(rectangleEdge43);
        org.jfree.chart.util.RectangleInsets rectangleInsets45 = textTitle35.getPadding();
        jFreeChart33.removeSubtitle((org.jfree.chart.title.Title) textTitle35);
        org.jfree.chart.title.LegendTitle legendTitle47 = jFreeChart33.getLegend();
        org.jfree.chart.block.BlockContainer blockContainer48 = legendTitle47.getItemContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets49 = legendTitle47.getPadding();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor50 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        legendTitle47.setLegendItemGraphicAnchor(rectangleAnchor50);
        java.awt.geom.Rectangle2D rectangle2D52 = legendTitle47.getBounds();
        try {
            legendTitle21.draw(graphics2D25, rectangle2D52);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(legendTitle21);
        org.junit.Assert.assertNotNull(blockContainer22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNull(valueAxis31);
        org.junit.Assert.assertNotNull(rectangleEdge43);
        org.junit.Assert.assertNotNull(rectangleInsets45);
        org.junit.Assert.assertNotNull(legendTitle47);
        org.junit.Assert.assertNotNull(blockContainer48);
        org.junit.Assert.assertNotNull(rectangleInsets49);
        org.junit.Assert.assertNotNull(rectangleAnchor50);
        org.junit.Assert.assertNotNull(rectangle2D52);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        int int1 = segmentedTimeline0.getSegmentsExcluded();
        int int2 = segmentedTimeline0.getGroupSegmentCount();
        boolean boolean3 = segmentedTimeline0.getAdjustForDaylightSaving();
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange();
        java.util.Date date5 = dateRange4.getLowerDate();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment6 = segmentedTimeline0.getSegment(date5);
        boolean boolean9 = segment6.contains(100L, (long) (-458));
        boolean boolean10 = segment6.inIncludeSegments();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(segment6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "org.jfree.data.UnknownKeyException: TextBlockAnchor.TOP_RIGHT", "ItemLabelAnchor.INSIDE7", "DomainOrder.NONE");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date6 = spreadsheetDate5.toDate();
        java.util.Date date7 = spreadsheetDate5.toDate();
        java.util.TimeZone timeZone8 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date7, timeZone8);
        int int10 = month9.getYearValue();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month9, (java.lang.Number) 0.0f, false);
        java.lang.String str14 = timeSeries3.getDomainDescription();
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1900 + "'", int10 == 1900);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ItemLabelAnchor.INSIDE7" + "'", str14.equals("ItemLabelAnchor.INSIDE7"));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        int int1 = segmentedTimeline0.getSegmentsExcluded();
        int int2 = segmentedTimeline0.getGroupSegmentCount();
        boolean boolean3 = segmentedTimeline0.getAdjustForDaylightSaving();
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange();
        java.util.Date date5 = dateRange4.getLowerDate();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment6 = segmentedTimeline0.getSegment(date5);
        boolean boolean8 = segment6.contains((long) (short) 100);
        segment6.dec();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(segment6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("NO_CHANGE", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.lang.Object obj1 = standardPieSectionLabelGenerator0.clone();
        java.text.NumberFormat numberFormat2 = standardPieSectionLabelGenerator0.getNumberFormat();
        java.lang.Object obj3 = standardPieSectionLabelGenerator0.clone();
        org.jfree.data.general.DefaultPieDataset defaultPieDataset4 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset4.insertValue(0, (java.lang.Comparable) (-2208960000000L), (double) (byte) 10);
        defaultPieDataset4.clear();
        try {
            java.lang.String str11 = standardPieSectionLabelGenerator0.generateSectionLabel((org.jfree.data.general.PieDataset) defaultPieDataset4, (java.lang.Comparable) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Key not found: 1");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(numberFormat2);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset0.insertValue(0, (java.lang.Comparable) (-2208960000000L), (double) (byte) 10);
        defaultPieDataset0.setValue((java.lang.Comparable) '4', (java.lang.Number) 31);
        java.lang.Comparable comparable8 = null;
        try {
            int int9 = defaultPieDataset0.getIndex(comparable8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.text.AttributedString attributedString1 = org.jfree.chart.util.SerialUtilities.readAttributedString(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0);
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        int int7 = categoryPlot6.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation9 = null;
        categoryPlot6.setRangeAxisLocation(100, axisLocation9);
        timeSeriesCollection1.removeChangeListener((org.jfree.data.general.DatasetChangeListener) categoryPlot6);
        org.jfree.chart.plot.PiePlot3D piePlot3D12 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, categoryItemRenderer16);
        int int18 = categoryPlot17.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation20 = null;
        categoryPlot17.setRangeAxisLocation(100, axisLocation20);
        int int22 = categoryPlot17.getWeight();
        java.awt.Paint paint23 = categoryPlot17.getRangeGridlinePaint();
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.data.Range range25 = categoryPlot17.getDataRange(valueAxis24);
        java.awt.Stroke stroke26 = categoryPlot17.getRangeMinorGridlineStroke();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D29 = new org.jfree.chart.axis.CategoryAxis3D("ERROR : Relative To String");
        categoryAxis3D29.clearCategoryLabelToolTips();
        categoryPlot17.setDomainAxis((int) '#', (org.jfree.chart.axis.CategoryAxis) categoryAxis3D29, false);
        java.awt.Font font33 = categoryAxis3D29.getLabelFont();
        float float34 = categoryAxis3D29.getTickMarkInsideLength();
        java.awt.Stroke stroke35 = categoryAxis3D29.getAxisLineStroke();
        piePlot3D12.setLabelOutlineStroke(stroke35);
        categoryPlot6.setRangeZeroBaselineStroke(stroke35);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNull(range25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertTrue("'" + float34 + "' != '" + 0.0f + "'", float34 == 0.0f);
        org.junit.Assert.assertNotNull(stroke35);
    }

//    @Test
//    public void test462() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test462");
//        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
//        int int5 = categoryPlot4.getDomainAxisCount();
//        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
//        categoryPlot4.setRangeAxisLocation(100, axisLocation7);
//        int int9 = categoryPlot4.getWeight();
//        java.awt.Paint paint10 = categoryPlot4.getRangeGridlinePaint();
//        org.jfree.chart.plot.DrawingSupplier drawingSupplier11 = null;
//        categoryPlot4.setDrawingSupplier(drawingSupplier11, false);
//        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot14 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
//        int int16 = combinedDomainXYPlot14.getDomainAxisIndex(valueAxis15);
//        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
//        int int18 = combinedDomainXYPlot14.getRangeAxisIndex(valueAxis17);
//        java.awt.Paint paint19 = combinedDomainXYPlot14.getDomainZeroBaselinePaint();
//        java.awt.Stroke stroke20 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
//        combinedDomainXYPlot14.setRangeZeroBaselineStroke(stroke20);
//        org.jfree.data.xy.XYDataset xYDataset22 = null;
//        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = combinedDomainXYPlot14.getRendererForDataset(xYDataset22);
//        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=0,g=255,b=0]");
//        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer26 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//        xYBarRenderer26.clearSeriesStrokes(true);
//        java.awt.Stroke stroke30 = xYBarRenderer26.lookupSeriesOutlineStroke(100);
//        xYBarRenderer26.setShadowXOffset((double) 100.0f);
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
//        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState35 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo34);
//        java.awt.geom.Line2D line2D36 = xYItemRendererState35.workingLine;
//        xYBarRenderer26.setLegendShape(0, (java.awt.Shape) line2D36);
//        numberAxis25.setRightArrow((java.awt.Shape) line2D36);
//        org.jfree.chart.axis.TickUnitSource tickUnitSource39 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
//        numberAxis25.setStandardTickUnits(tickUnitSource39);
//        java.text.NumberFormat numberFormat42 = java.text.NumberFormat.getCurrencyInstance();
//        org.jfree.chart.axis.NumberTickUnit numberTickUnit43 = new org.jfree.chart.axis.NumberTickUnit((double) 100L, numberFormat42);
//        numberAxis25.setTickUnit(numberTickUnit43, true, false);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date50 = spreadsheetDate49.toDate();
//        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date50);
//        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day();
//        long long53 = day52.getLastMillisecond();
//        org.jfree.chart.axis.PeriodAxis periodAxis54 = new org.jfree.chart.axis.PeriodAxis("$8.00", (org.jfree.data.time.RegularTimePeriod) day51, (org.jfree.data.time.RegularTimePeriod) day52);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate57 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date58 = spreadsheetDate57.toDate();
//        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day(date58);
//        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day();
//        long long61 = day60.getLastMillisecond();
//        org.jfree.chart.axis.PeriodAxis periodAxis62 = new org.jfree.chart.axis.PeriodAxis("$8.00", (org.jfree.data.time.RegularTimePeriod) day59, (org.jfree.data.time.RegularTimePeriod) day60);
//        org.jfree.chart.axis.ValueAxis[] valueAxisArray63 = new org.jfree.chart.axis.ValueAxis[] { numberAxis25, periodAxis54, periodAxis62 };
//        combinedDomainXYPlot14.setRangeAxes(valueAxisArray63);
//        categoryPlot4.setRangeAxes(valueAxisArray63);
//        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem68 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day66, (java.lang.Number) 255);
//        categoryPlot4.setDomainCrosshairRowKey((java.lang.Comparable) 255);
//        categoryPlot4.zoom((double) 9999);
//        org.jfree.chart.axis.AxisLocation axisLocation72 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
//        categoryPlot4.setRangeAxisLocation(axisLocation72, false);
//        categoryPlot4.setDomainGridlinesVisible(false);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertNotNull(paint10);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(paint19);
//        org.junit.Assert.assertNotNull(stroke20);
//        org.junit.Assert.assertNull(xYItemRenderer23);
//        org.junit.Assert.assertNotNull(stroke30);
//        org.junit.Assert.assertNotNull(line2D36);
//        org.junit.Assert.assertNotNull(tickUnitSource39);
//        org.junit.Assert.assertNotNull(numberFormat42);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 1560495599999L + "'", long53 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 1560495599999L + "'", long61 == 1560495599999L);
//        org.junit.Assert.assertNotNull(valueAxisArray63);
//        org.junit.Assert.assertNotNull(axisLocation72);
//    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation(100, axisLocation7);
        int int9 = categoryPlot4.getWeight();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        int int11 = categoryPlot4.getIndexOf(categoryItemRenderer10);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot12 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot13 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        int int15 = combinedDomainXYPlot13.getDomainAxisIndex(valueAxis14);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        int int17 = combinedDomainXYPlot13.getRangeAxisIndex(valueAxis16);
        java.awt.Paint paint18 = combinedDomainXYPlot13.getDomainZeroBaselinePaint();
        java.awt.Stroke stroke19 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        combinedDomainXYPlot13.setRangeZeroBaselineStroke(stroke19);
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = combinedDomainXYPlot13.getRendererForDataset(xYDataset21);
        org.jfree.chart.axis.AxisLocation axisLocation24 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        combinedDomainXYPlot13.setRangeAxisLocation(0, axisLocation24);
        combinedDomainXYPlot12.setRangeAxisLocation(axisLocation24, true);
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, categoryItemRenderer31);
        int int33 = categoryPlot32.getDomainAxisCount();
        java.awt.Color color34 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        categoryPlot32.setRangeZeroBaselinePaint((java.awt.Paint) color34);
        java.awt.Paint paint36 = categoryPlot32.getDomainCrosshairPaint();
        boolean boolean37 = axisLocation24.equals((java.lang.Object) paint36);
        categoryPlot4.setRangeAxisLocation(axisLocation24);
        org.jfree.chart.axis.AxisSpace axisSpace39 = null;
        categoryPlot4.setFixedDomainAxisSpace(axisSpace39);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(xYItemRenderer22);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        org.jfree.chart.util.LogFormat logFormat3 = new org.jfree.chart.util.LogFormat((double) 8, "series", true);
        java.lang.Object obj4 = null;
        boolean boolean5 = logFormat3.equals(obj4);
        int int6 = logFormat3.getMaximumFractionDigits();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 3 + "'", int6 == 3);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection1, true);
        java.lang.Number number4 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNull(number4);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState1 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo0);
        int int2 = xYItemRendererState1.getFirstItemIndex();
        java.awt.Font font4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot5 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        int int7 = combinedDomainXYPlot5.getDomainAxisIndex(valueAxis6);
        org.jfree.chart.axis.ValueAxis valueAxis8 = combinedDomainXYPlot5.getRangeAxis();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("WMAP_Plot", font4, (org.jfree.chart.plot.Plot) combinedDomainXYPlot5, true);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent11 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) int2, jFreeChart10);
        boolean boolean12 = jFreeChart10.isNotify();
        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle15.setMaximumLinesToDisplay(1);
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, valueAxis20, categoryItemRenderer21);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = categoryPlot22.getDomainAxisEdge();
        textTitle15.setPosition(rectangleEdge23);
        try {
            jFreeChart10.addSubtitle(100, (org.jfree.chart.title.Title) textTitle15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'index' argument is out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(rectangleEdge23);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) 255);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot3 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        int int5 = combinedDomainXYPlot3.getDomainAxisIndex(valueAxis4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, valueAxis8, categoryItemRenderer9);
        int int11 = categoryPlot10.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation13 = null;
        categoryPlot10.setRangeAxisLocation(100, axisLocation13);
        int int15 = categoryPlot10.getWeight();
        java.awt.Paint paint16 = categoryPlot10.getRangeGridlinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier17 = null;
        categoryPlot10.setDrawingSupplier(drawingSupplier17, false);
        boolean boolean20 = categoryPlot10.isSubplot();
        categoryPlot10.setRangeZeroBaselineVisible(true);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder23 = categoryPlot10.getDatasetRenderingOrder();
        combinedDomainXYPlot3.setDatasetRenderingOrder(datasetRenderingOrder23);
        java.awt.Stroke stroke25 = combinedDomainXYPlot3.getOutlineStroke();
        int int26 = day0.compareTo((java.lang.Object) stroke25);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder23);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer1 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.data.Range range3 = xYStepRenderer1.findDomainBounds(xYDataset2);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator4 = null;
        xYStepRenderer1.setBaseToolTipGenerator(xYToolTipGenerator4);
        boolean boolean6 = xYStepRenderer1.getBaseShapesVisible();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
        xYStepRenderer1.setBaseToolTipGenerator(xYToolTipGenerator7, true);
        java.text.DateFormat dateFormat11 = null;
        java.text.DateFormat dateFormat12 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator13 = new org.jfree.chart.labels.StandardXYToolTipGenerator("{0}: ({1}, {2})", dateFormat11, dateFormat12);
        xYStepRenderer1.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator13);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator15 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer16 = new org.jfree.chart.renderer.xy.XYAreaRenderer(3, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator13, xYURLGenerator15);
        boolean boolean17 = xYAreaRenderer16.isOutline();
        java.awt.Paint paint19 = xYAreaRenderer16.getSeriesPaint((int) (short) 100);
        boolean boolean20 = xYAreaRenderer16.getPlotArea();
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer0.setBaseLinesVisible(true);
        xYStepRenderer0.setSeriesLinesVisible(0, true);
        xYStepRenderer0.setSeriesVisibleInLegend(1, (java.lang.Boolean) false, false);
        java.lang.Object obj10 = xYStepRenderer0.clone();
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) (short) -1, (float) 1L);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape13, rectangleAnchor14, (double) (short) 0, (double) 1);
        xYStepRenderer0.setLegendLine(shape17);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(rectangleAnchor14);
        org.junit.Assert.assertNotNull(shape17);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        xYAreaRenderer0.setBaseURLGenerator(xYURLGenerator1, true);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        int int1 = segmentedTimeline0.getSegmentsExcluded();
        int int2 = segmentedTimeline0.getGroupSegmentCount();
        boolean boolean4 = segmentedTimeline0.containsDomainValue((long) 5);
        long long5 = segmentedTimeline0.getStartTime();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-2208960000000L) + "'", long5 == (-2208960000000L));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        int int2 = combinedDomainXYPlot0.getDomainAxisIndex(valueAxis1);
        combinedDomainXYPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        int int6 = combinedDomainXYPlot0.getRangeAxisIndex(valueAxis5);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot7 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        int int9 = combinedDomainXYPlot7.getDomainAxisIndex(valueAxis8);
        org.jfree.chart.axis.ValueAxis valueAxis10 = combinedDomainXYPlot7.getRangeAxis();
        boolean boolean11 = combinedDomainXYPlot7.isSubplot();
        combinedDomainXYPlot7.setRangeMinorGridlinesVisible(false);
        boolean boolean14 = combinedDomainXYPlot7.isDomainZeroBaselineVisible();
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        combinedDomainXYPlot7.setRangeAxis((int) 'a', valueAxis16);
        double double18 = combinedDomainXYPlot7.getRangeCrosshairValue();
        combinedDomainXYPlot0.remove((org.jfree.chart.plot.XYPlot) combinedDomainXYPlot7);
        java.lang.Object obj20 = combinedDomainXYPlot7.clone();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(obj20);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset) defaultPieDataset0);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator2 = null;
        ringPlot1.setURLGenerator(pieURLGenerator2);
        double double4 = ringPlot1.getInteriorGap();
        double double5 = ringPlot1.getStartAngle();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, valueAxis8, categoryItemRenderer9);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot10.getDomainAxisEdge();
        boolean boolean12 = categoryPlot10.isRangeGridlinesVisible();
        java.lang.Comparable comparable13 = categoryPlot10.getDomainCrosshairColumnKey();
        java.awt.Paint paint14 = categoryPlot10.getDomainCrosshairPaint();
        ringPlot1.setBaseSectionOutlinePaint(paint14);
        java.awt.Paint paint16 = ringPlot1.getBaseSectionOutlinePaint();
        boolean boolean17 = ringPlot1.getIgnoreNullValues();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator18 = ringPlot1.getLegendLabelURLGenerator();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.08d + "'", double4 == 0.08d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 90.0d + "'", double5 == 90.0d);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(comparable13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(pieURLGenerator18);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer0.setBaseLinesVisible(true);
        xYStepRenderer0.setSeriesLinesVisible(0, true);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator6 = xYStepRenderer0.getBaseToolTipGenerator();
        java.awt.Paint paint10 = xYStepRenderer0.getItemLabelPaint(31, (int) '#', false);
        org.junit.Assert.assertNull(xYToolTipGenerator6);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean2 = textBlock0.equals((java.lang.Object) rectangleInsets1);
        double double4 = rectangleInsets1.calculateRightInset((double) (byte) 10);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.0d + "'", double4 == 8.0d);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset) defaultPieDataset0);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator2 = null;
        ringPlot1.setURLGenerator(pieURLGenerator2);
        double double4 = ringPlot1.getInteriorGap();
        double double5 = ringPlot1.getStartAngle();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, valueAxis8, categoryItemRenderer9);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot10.getDomainAxisEdge();
        boolean boolean12 = categoryPlot10.isRangeGridlinesVisible();
        java.lang.Comparable comparable13 = categoryPlot10.getDomainCrosshairColumnKey();
        java.awt.Paint paint14 = categoryPlot10.getDomainCrosshairPaint();
        ringPlot1.setBaseSectionOutlinePaint(paint14);
        java.awt.Paint paint16 = ringPlot1.getBaseSectionOutlinePaint();
        org.jfree.chart.util.Rotation rotation17 = org.jfree.chart.util.Rotation.ANTICLOCKWISE;
        ringPlot1.setDirection(rotation17);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor19 = ringPlot1.getLabelDistributor();
        ringPlot1.setAutoPopulateSectionOutlineStroke(false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.08d + "'", double4 == 0.08d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 90.0d + "'", double5 == 90.0d);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(comparable13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(rotation17);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor19);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        org.jfree.chart.util.PaintMap paintMap0 = new org.jfree.chart.util.PaintMap();
        boolean boolean2 = paintMap0.containsKey((java.lang.Comparable) 9999);
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=0,g=255,b=0]");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer5 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer5.clearSeriesStrokes(true);
        java.awt.Stroke stroke9 = xYBarRenderer5.lookupSeriesOutlineStroke(100);
        xYBarRenderer5.setShadowXOffset((double) 100.0f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState14 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo13);
        java.awt.geom.Line2D line2D15 = xYItemRendererState14.workingLine;
        xYBarRenderer5.setLegendShape(0, (java.awt.Shape) line2D15);
        numberAxis4.setRightArrow((java.awt.Shape) line2D15);
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        numberAxis4.setStandardTickUnits(tickUnitSource18);
        java.text.NumberFormat numberFormat21 = java.text.NumberFormat.getCurrencyInstance();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit22 = new org.jfree.chart.axis.NumberTickUnit((double) 100L, numberFormat21);
        numberAxis4.setTickUnit(numberTickUnit22, true, false);
        double double26 = numberTickUnit22.getSize();
        boolean boolean27 = paintMap0.containsKey((java.lang.Comparable) double26);
        paintMap0.clear();
        java.lang.Object obj29 = paintMap0.clone();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(line2D15);
        org.junit.Assert.assertNotNull(tickUnitSource18);
        org.junit.Assert.assertNotNull(numberFormat21);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 100.0d + "'", double26 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(obj29);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_HORIZONTAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        int int7 = categoryPlot6.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation9 = null;
        categoryPlot6.setRangeAxisLocation(100, axisLocation9);
        int int11 = categoryPlot6.getWeight();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        int int13 = categoryPlot6.getIndexOf(categoryItemRenderer12);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot14 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot15 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        int int17 = combinedDomainXYPlot15.getDomainAxisIndex(valueAxis16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        int int19 = combinedDomainXYPlot15.getRangeAxisIndex(valueAxis18);
        java.awt.Paint paint20 = combinedDomainXYPlot15.getDomainZeroBaselinePaint();
        java.awt.Stroke stroke21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        combinedDomainXYPlot15.setRangeZeroBaselineStroke(stroke21);
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = combinedDomainXYPlot15.getRendererForDataset(xYDataset23);
        org.jfree.chart.axis.AxisLocation axisLocation26 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        combinedDomainXYPlot15.setRangeAxisLocation(0, axisLocation26);
        combinedDomainXYPlot14.setRangeAxisLocation(axisLocation26, true);
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = null;
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis31, valueAxis32, categoryItemRenderer33);
        int int35 = categoryPlot34.getDomainAxisCount();
        java.awt.Color color36 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        categoryPlot34.setRangeZeroBaselinePaint((java.awt.Paint) color36);
        java.awt.Paint paint38 = categoryPlot34.getDomainCrosshairPaint();
        boolean boolean39 = axisLocation26.equals((java.lang.Object) paint38);
        categoryPlot6.setRangeAxisLocation(axisLocation26);
        boolean boolean41 = standardGradientPaintTransformer1.equals((java.lang.Object) axisLocation26);
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNull(xYItemRenderer24);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        int int2 = combinedDomainXYPlot0.getDomainAxisIndex(valueAxis1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = combinedDomainXYPlot0.getRangeAxisIndex(valueAxis3);
        java.awt.Paint paint5 = combinedDomainXYPlot0.getDomainZeroBaselinePaint();
        boolean boolean6 = combinedDomainXYPlot0.isDomainZeroBaselineVisible();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder7 = combinedDomainXYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation9 = combinedDomainXYPlot0.getRangeAxisLocation((int) '#');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        try {
            combinedDomainXYPlot0.zoomRangeAxes((double) 100.0f, plotRenderingInfo11, point2D12, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(seriesRenderingOrder7);
        org.junit.Assert.assertNotNull(axisLocation9);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        java.awt.Color color0 = java.awt.Color.green;
        java.awt.Color color1 = java.awt.Color.darkGray;
        float[] floatArray8 = new float[] { 0.0f, 60000L, 2147483647, 1560495599999L, 31, 1900 };
        float[] floatArray9 = color1.getColorComponents(floatArray8);
        float[] floatArray10 = color0.getColorComponents(floatArray9);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=0,g=255,b=0]");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer2 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer2.clearSeriesStrokes(true);
        java.awt.Stroke stroke6 = xYBarRenderer2.lookupSeriesOutlineStroke(100);
        xYBarRenderer2.setShadowXOffset((double) 100.0f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState11 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo10);
        java.awt.geom.Line2D line2D12 = xYItemRendererState11.workingLine;
        xYBarRenderer2.setLegendShape(0, (java.awt.Shape) line2D12);
        numberAxis1.setRightArrow((java.awt.Shape) line2D12);
        org.jfree.chart.axis.TickUnitSource tickUnitSource15 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        numberAxis1.setStandardTickUnits(tickUnitSource15);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range18 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range19 = org.jfree.data.Range.combine(range17, range18);
        numberAxis1.setRange(range17, true, false);
        boolean boolean23 = numberAxis1.isInverted();
        boolean boolean24 = numberAxis1.getAutoRangeIncludesZero();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(line2D12);
        org.junit.Assert.assertNotNull(tickUnitSource15);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        org.jfree.data.time.DateRange dateRange1 = new org.jfree.data.time.DateRange();
        double double2 = dateRange1.getLength();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType4 = rectangleConstraint3.getHeightConstraintType();
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer5 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer5.setBaseLinesVisible(true);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator9 = xYStepRenderer5.getSeriesItemLabelGenerator((int) '#');
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator13 = xYStepRenderer5.getItemLabelGenerator((int) (byte) 100, (-1), false);
        boolean boolean14 = lengthConstraintType4.equals((java.lang.Object) xYItemLabelGenerator13);
        java.lang.Object obj15 = null;
        boolean boolean16 = lengthConstraintType4.equals(obj15);
        org.jfree.data.Range range18 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range19 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range20 = org.jfree.data.Range.combine(range18, range19);
        double double21 = range20.getLength();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType22 = org.jfree.chart.block.LengthConstraintType.FIXED;
        java.lang.String str23 = lengthConstraintType22.toString();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint24 = new org.jfree.chart.block.RectangleConstraint((double) (short) 100, (org.jfree.data.Range) dateRange1, lengthConstraintType4, (double) (short) 1, range20, lengthConstraintType22);
        double double25 = dateRange1.getLowerBound();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint3);
        org.junit.Assert.assertNotNull(lengthConstraintType4);
        org.junit.Assert.assertNull(xYItemLabelGenerator9);
        org.junit.Assert.assertNull(xYItemLabelGenerator13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "LengthConstraintType.FIXED" + "'", str23.equals("LengthConstraintType.FIXED"));
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        double double1 = piePlot0.getMaximumExplodePercent();
        java.awt.Shape shape2 = piePlot0.getLegendItemShape();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.data.Range range2 = xYStepRenderer0.findDomainBounds(xYDataset1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = null;
        xYStepRenderer0.setBaseToolTipGenerator(xYToolTipGenerator3);
        org.jfree.data.general.WaferMapDataset waferMapDataset6 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot7 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset6);
        java.awt.Paint paint8 = waferMapPlot7.getOutlinePaint();
        xYStepRenderer0.setSeriesFillPaint(100, paint8, false);
        java.awt.Font font12 = xYStepRenderer0.getSeriesItemLabelFont(100);
        boolean boolean13 = xYStepRenderer0.getBaseShapesFilled();
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYStepRenderer0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = legendTitle14.getHorizontalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = legendTitle14.getPadding();
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(font12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
        org.junit.Assert.assertNotNull(rectangleInsets16);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit(0.0d);
        org.jfree.data.category.CategoryDataset categoryDataset3 = multiplePiePlot0.getDataset();
        org.jfree.chart.LegendItemCollection legendItemCollection4 = multiplePiePlot0.getLegendItems();
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertNotNull(legendItemCollection4);
    }

//    @Test
//    public void test490() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test490");
//        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
//        int int2 = combinedDomainXYPlot0.getDomainAxisIndex(valueAxis1);
//        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
//        int int4 = combinedDomainXYPlot0.getRangeAxisIndex(valueAxis3);
//        java.awt.Paint paint5 = combinedDomainXYPlot0.getDomainZeroBaselinePaint();
//        java.awt.Stroke stroke6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
//        combinedDomainXYPlot0.setRangeZeroBaselineStroke(stroke6);
//        org.jfree.data.xy.XYDataset xYDataset8 = null;
//        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = combinedDomainXYPlot0.getRendererForDataset(xYDataset8);
//        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=0,g=255,b=0]");
//        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer12 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//        xYBarRenderer12.clearSeriesStrokes(true);
//        java.awt.Stroke stroke16 = xYBarRenderer12.lookupSeriesOutlineStroke(100);
//        xYBarRenderer12.setShadowXOffset((double) 100.0f);
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
//        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState21 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo20);
//        java.awt.geom.Line2D line2D22 = xYItemRendererState21.workingLine;
//        xYBarRenderer12.setLegendShape(0, (java.awt.Shape) line2D22);
//        numberAxis11.setRightArrow((java.awt.Shape) line2D22);
//        org.jfree.chart.axis.TickUnitSource tickUnitSource25 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
//        numberAxis11.setStandardTickUnits(tickUnitSource25);
//        java.text.NumberFormat numberFormat28 = java.text.NumberFormat.getCurrencyInstance();
//        org.jfree.chart.axis.NumberTickUnit numberTickUnit29 = new org.jfree.chart.axis.NumberTickUnit((double) 100L, numberFormat28);
//        numberAxis11.setTickUnit(numberTickUnit29, true, false);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date36 = spreadsheetDate35.toDate();
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date36);
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
//        long long39 = day38.getLastMillisecond();
//        org.jfree.chart.axis.PeriodAxis periodAxis40 = new org.jfree.chart.axis.PeriodAxis("$8.00", (org.jfree.data.time.RegularTimePeriod) day37, (org.jfree.data.time.RegularTimePeriod) day38);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date44 = spreadsheetDate43.toDate();
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date44);
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day();
//        long long47 = day46.getLastMillisecond();
//        org.jfree.chart.axis.PeriodAxis periodAxis48 = new org.jfree.chart.axis.PeriodAxis("$8.00", (org.jfree.data.time.RegularTimePeriod) day45, (org.jfree.data.time.RegularTimePeriod) day46);
//        org.jfree.chart.axis.ValueAxis[] valueAxisArray49 = new org.jfree.chart.axis.ValueAxis[] { numberAxis11, periodAxis40, periodAxis48 };
//        combinedDomainXYPlot0.setRangeAxes(valueAxisArray49);
//        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer51 = combinedDomainXYPlot0.getRenderer();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(paint5);
//        org.junit.Assert.assertNotNull(stroke6);
//        org.junit.Assert.assertNull(xYItemRenderer9);
//        org.junit.Assert.assertNotNull(stroke16);
//        org.junit.Assert.assertNotNull(line2D22);
//        org.junit.Assert.assertNotNull(tickUnitSource25);
//        org.junit.Assert.assertNotNull(numberFormat28);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560495599999L + "'", long39 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1560495599999L + "'", long47 == 1560495599999L);
//        org.junit.Assert.assertNotNull(valueAxisArray49);
//        org.junit.Assert.assertNull(xYItemRenderer51);
//    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("TextBlockAnchor.TOP_RIGHT");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer2 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer2.clearSeriesStrokes(true);
        java.awt.Stroke stroke6 = xYBarRenderer2.lookupSeriesOutlineStroke(100);
        xYBarRenderer2.setShadowXOffset((double) 100.0f);
        java.awt.Stroke stroke9 = xYBarRenderer2.getBaseOutlineStroke();
        java.awt.Paint paint10 = xYBarRenderer2.getBasePaint();
        labelBlock1.setPaint(paint10);
        java.lang.String str12 = labelBlock1.getURLText();
        labelBlock1.setURLText("");
        labelBlock1.setHeight((double) 7);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.clearSeriesStrokes(true);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator3 = xYBarRenderer0.getBaseItemLabelGenerator();
        java.awt.Paint paint5 = xYBarRenderer0.lookupSeriesPaint(9999);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = xYBarRenderer0.getSeriesNegativeItemLabelPosition(6);
        org.jfree.data.time.TimeSeries timeSeries8 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection9 = new org.jfree.data.time.TimeSeriesCollection(timeSeries8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, valueAxis12, categoryItemRenderer13);
        int int15 = categoryPlot14.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation17 = null;
        categoryPlot14.setRangeAxisLocation(100, axisLocation17);
        timeSeriesCollection9.removeChangeListener((org.jfree.data.general.DatasetChangeListener) categoryPlot14);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate21 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection9, true);
        org.jfree.data.Range range22 = xYBarRenderer0.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection9);
        boolean boolean23 = xYBarRenderer0.isDrawBarOutline();
        org.junit.Assert.assertNull(xYItemLabelGenerator3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNull(range22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        int int6 = categoryPlot5.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation8 = null;
        categoryPlot5.setRangeAxisLocation(100, axisLocation8);
        int int10 = categoryPlot5.getWeight();
        java.awt.Paint paint11 = categoryPlot5.getRangeGridlinePaint();
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.data.Range range13 = categoryPlot5.getDataRange(valueAxis12);
        java.awt.Stroke stroke14 = categoryPlot5.getRangeMinorGridlineStroke();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("ERROR : Relative To String");
        categoryAxis3D17.clearCategoryLabelToolTips();
        categoryPlot5.setDomainAxis((int) '#', (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, false);
        java.awt.Font font21 = categoryAxis3D17.getLabelFont();
        float float22 = categoryAxis3D17.getTickMarkInsideLength();
        java.awt.Stroke stroke23 = categoryAxis3D17.getAxisLineStroke();
        piePlot3D0.setLabelOutlineStroke(stroke23);
        try {
            piePlot3D0.setInteriorGap((double) 2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid 'percent' (2.147483647E9) argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 0.0f + "'", float22 == 0.0f);
        org.junit.Assert.assertNotNull(stroke23);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.Font font5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot6 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        int int8 = combinedDomainXYPlot6.getDomainAxisIndex(valueAxis7);
        org.jfree.chart.axis.ValueAxis valueAxis9 = combinedDomainXYPlot6.getRangeAxis();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("WMAP_Plot", font5, (org.jfree.chart.plot.Plot) combinedDomainXYPlot6, true);
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle13.setMaximumLinesToDisplay(1);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis18, categoryItemRenderer19);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = categoryPlot20.getDomainAxisEdge();
        textTitle13.setPosition(rectangleEdge21);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = textTitle13.getPadding();
        jFreeChart11.removeSubtitle((org.jfree.chart.title.Title) textTitle13);
        org.jfree.chart.title.LegendTitle legendTitle25 = jFreeChart11.getLegend();
        org.jfree.chart.block.BlockContainer blockContainer26 = legendTitle25.getItemContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = legendTitle25.getPadding();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor28 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        legendTitle25.setLegendItemGraphicAnchor(rectangleAnchor28);
        java.awt.geom.Rectangle2D rectangle2D30 = legendTitle25.getBounds();
        java.awt.Font font32 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot33 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        int int35 = combinedDomainXYPlot33.getDomainAxisIndex(valueAxis34);
        org.jfree.chart.axis.ValueAxis valueAxis36 = combinedDomainXYPlot33.getRangeAxis();
        org.jfree.chart.JFreeChart jFreeChart38 = new org.jfree.chart.JFreeChart("WMAP_Plot", font32, (org.jfree.chart.plot.Plot) combinedDomainXYPlot33, true);
        org.jfree.chart.title.TextTitle textTitle40 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle40.setMaximumLinesToDisplay(1);
        org.jfree.data.category.CategoryDataset categoryDataset43 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = null;
        org.jfree.chart.axis.ValueAxis valueAxis45 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer46 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot47 = new org.jfree.chart.plot.CategoryPlot(categoryDataset43, categoryAxis44, valueAxis45, categoryItemRenderer46);
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = categoryPlot47.getDomainAxisEdge();
        textTitle40.setPosition(rectangleEdge48);
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = textTitle40.getPadding();
        jFreeChart38.removeSubtitle((org.jfree.chart.title.Title) textTitle40);
        org.jfree.chart.title.LegendTitle legendTitle52 = jFreeChart38.getLegend();
        org.jfree.chart.block.BlockContainer blockContainer53 = legendTitle52.getItemContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets54 = legendTitle52.getPadding();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor55 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        legendTitle52.setLegendItemGraphicAnchor(rectangleAnchor55);
        java.awt.geom.Rectangle2D rectangle2D57 = legendTitle52.getBounds();
        java.awt.Font font60 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.text.TextLine textLine61 = new org.jfree.chart.text.TextLine("ClassContext", font60);
        org.jfree.chart.title.TextTitle textTitle62 = new org.jfree.chart.title.TextTitle("hi!", font60);
        org.jfree.chart.util.RectangleEdge rectangleEdge63 = textTitle62.getPosition();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo64 = null;
        try {
            org.jfree.chart.axis.AxisState axisState65 = periodAxis1.draw(graphics2D2, 2.0d, rectangle2D30, rectangle2D57, rectangleEdge63, plotRenderingInfo64);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(legendTitle25);
        org.junit.Assert.assertNotNull(blockContainer26);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(rectangleAnchor28);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertNull(valueAxis36);
        org.junit.Assert.assertNotNull(rectangleEdge48);
        org.junit.Assert.assertNotNull(rectangleInsets50);
        org.junit.Assert.assertNotNull(legendTitle52);
        org.junit.Assert.assertNotNull(blockContainer53);
        org.junit.Assert.assertNotNull(rectangleInsets54);
        org.junit.Assert.assertNotNull(rectangleAnchor55);
        org.junit.Assert.assertNotNull(rectangle2D57);
        org.junit.Assert.assertNotNull(font60);
        org.junit.Assert.assertNotNull(rectangleEdge63);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter1 = xYBarRenderer0.getBarPainter();
        org.junit.Assert.assertNotNull(xYBarPainter1);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        categoryPlot4.setRangeZeroBaselinePaint((java.awt.Paint) color6);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=0,g=255,b=0]");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer10 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer10.clearSeriesStrokes(true);
        java.awt.Stroke stroke14 = xYBarRenderer10.lookupSeriesOutlineStroke(100);
        xYBarRenderer10.setShadowXOffset((double) 100.0f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState19 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo18);
        java.awt.geom.Line2D line2D20 = xYItemRendererState19.workingLine;
        xYBarRenderer10.setLegendShape(0, (java.awt.Shape) line2D20);
        numberAxis9.setRightArrow((java.awt.Shape) line2D20);
        numberAxis9.setMinorTickMarksVisible(true);
        numberAxis9.setVerticalTickLabels(false);
        int int27 = categoryPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis9);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(line2D20);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer0.setBaseLinesVisible(true);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator4 = xYStepRenderer0.getSeriesItemLabelGenerator((int) '#');
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator8 = xYStepRenderer0.getItemLabelGenerator((int) (byte) 100, (-1), false);
        int int9 = xYStepRenderer0.getPassCount();
        boolean boolean10 = xYStepRenderer0.getBaseItemLabelsVisible();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot12 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        int int14 = combinedDomainXYPlot12.getDomainAxisIndex(valueAxis13);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        int int16 = combinedDomainXYPlot12.getRangeAxisIndex(valueAxis15);
        java.awt.Paint paint17 = combinedDomainXYPlot12.getDomainZeroBaselinePaint();
        java.awt.Stroke stroke18 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        combinedDomainXYPlot12.setRangeZeroBaselineStroke(stroke18);
        java.awt.Paint paint20 = combinedDomainXYPlot12.getDomainCrosshairPaint();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=0,g=255,b=0]");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer23 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer23.clearSeriesStrokes(true);
        java.awt.Stroke stroke27 = xYBarRenderer23.lookupSeriesOutlineStroke(100);
        xYBarRenderer23.setShadowXOffset((double) 100.0f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState32 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo31);
        java.awt.geom.Line2D line2D33 = xYItemRendererState32.workingLine;
        xYBarRenderer23.setLegendShape(0, (java.awt.Shape) line2D33);
        numberAxis22.setRightArrow((java.awt.Shape) line2D33);
        org.jfree.chart.axis.TickUnitSource tickUnitSource36 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        numberAxis22.setStandardTickUnits(tickUnitSource36);
        org.jfree.data.Range range38 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range39 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range40 = org.jfree.data.Range.combine(range38, range39);
        numberAxis22.setRange(range38, true, false);
        boolean boolean44 = numberAxis22.isInverted();
        numberAxis22.setVerticalTickLabels(true);
        java.awt.Font font48 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot49 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis50 = null;
        int int51 = combinedDomainXYPlot49.getDomainAxisIndex(valueAxis50);
        org.jfree.chart.axis.ValueAxis valueAxis52 = combinedDomainXYPlot49.getRangeAxis();
        org.jfree.chart.JFreeChart jFreeChart54 = new org.jfree.chart.JFreeChart("WMAP_Plot", font48, (org.jfree.chart.plot.Plot) combinedDomainXYPlot49, true);
        org.jfree.chart.title.TextTitle textTitle56 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle56.setMaximumLinesToDisplay(1);
        org.jfree.data.category.CategoryDataset categoryDataset59 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis60 = null;
        org.jfree.chart.axis.ValueAxis valueAxis61 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer62 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot63 = new org.jfree.chart.plot.CategoryPlot(categoryDataset59, categoryAxis60, valueAxis61, categoryItemRenderer62);
        org.jfree.chart.util.RectangleEdge rectangleEdge64 = categoryPlot63.getDomainAxisEdge();
        textTitle56.setPosition(rectangleEdge64);
        org.jfree.chart.util.RectangleInsets rectangleInsets66 = textTitle56.getPadding();
        jFreeChart54.removeSubtitle((org.jfree.chart.title.Title) textTitle56);
        org.jfree.chart.title.LegendTitle legendTitle68 = jFreeChart54.getLegend();
        org.jfree.chart.block.BlockContainer blockContainer69 = legendTitle68.getItemContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets70 = legendTitle68.getPadding();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor71 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        legendTitle68.setLegendItemGraphicAnchor(rectangleAnchor71);
        java.awt.geom.Rectangle2D rectangle2D73 = legendTitle68.getBounds();
        java.awt.Color color75 = java.awt.Color.magenta;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer76 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer76.clearSeriesStrokes(true);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator79 = xYBarRenderer76.getBaseItemLabelGenerator();
        java.awt.Paint paint81 = xYBarRenderer76.lookupSeriesPaint(9999);
        java.awt.Shape shape83 = xYBarRenderer76.getLegendShape((int) ' ');
        java.awt.Stroke stroke85 = xYBarRenderer76.lookupSeriesOutlineStroke((int) ' ');
        xYStepRenderer0.drawDomainLine(graphics2D11, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot12, (org.jfree.chart.axis.ValueAxis) numberAxis22, rectangle2D73, (double) 255, (java.awt.Paint) color75, stroke85);
        org.junit.Assert.assertNull(xYItemLabelGenerator4);
        org.junit.Assert.assertNull(xYItemLabelGenerator8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(line2D33);
        org.junit.Assert.assertNotNull(tickUnitSource36);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNotNull(range39);
        org.junit.Assert.assertNotNull(range40);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(font48);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1) + "'", int51 == (-1));
        org.junit.Assert.assertNull(valueAxis52);
        org.junit.Assert.assertNotNull(rectangleEdge64);
        org.junit.Assert.assertNotNull(rectangleInsets66);
        org.junit.Assert.assertNotNull(legendTitle68);
        org.junit.Assert.assertNotNull(blockContainer69);
        org.junit.Assert.assertNotNull(rectangleInsets70);
        org.junit.Assert.assertNotNull(rectangleAnchor71);
        org.junit.Assert.assertNotNull(rectangle2D73);
        org.junit.Assert.assertNotNull(color75);
        org.junit.Assert.assertNull(xYItemLabelGenerator79);
        org.junit.Assert.assertNotNull(paint81);
        org.junit.Assert.assertNull(shape83);
        org.junit.Assert.assertNotNull(stroke85);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        java.awt.Shape shape4 = null;
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, valueAxis7, categoryItemRenderer8);
        int int10 = categoryPlot9.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation12 = null;
        categoryPlot9.setRangeAxisLocation(100, axisLocation12);
        int int14 = categoryPlot9.getWeight();
        java.awt.Paint paint15 = categoryPlot9.getRangeGridlinePaint();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer16 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer16.clearSeriesStrokes(true);
        java.awt.Stroke stroke20 = xYBarRenderer16.lookupSeriesOutlineStroke(100);
        xYBarRenderer16.setShadowXOffset((double) 100.0f);
        java.awt.Stroke stroke23 = xYBarRenderer16.getBaseOutlineStroke();
        java.awt.Paint paint24 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("", "TextBlockAnchor.TOP_RIGHT", "{0}: ({1}, {2})", "", shape4, paint15, stroke23, paint24);
        java.awt.Color color26 = java.awt.Color.lightGray;
        legendItem25.setLabelPaint((java.awt.Paint) color26);
        java.awt.Shape shape28 = legendItem25.getLine();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot29 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        int int31 = combinedDomainXYPlot29.getDomainAxisIndex(valueAxis30);
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        int int33 = combinedDomainXYPlot29.getRangeAxisIndex(valueAxis32);
        java.awt.Paint paint34 = combinedDomainXYPlot29.getDomainZeroBaselinePaint();
        java.awt.Stroke stroke35 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        combinedDomainXYPlot29.setRangeZeroBaselineStroke(stroke35);
        org.jfree.chart.entity.PlotEntity plotEntity39 = new org.jfree.chart.entity.PlotEntity(shape28, (org.jfree.chart.plot.Plot) combinedDomainXYPlot29, "{0}: ({1}, {2})", "[size=$100.00]");
        org.jfree.chart.title.TextTitle textTitle41 = new org.jfree.chart.title.TextTitle("hi!");
        double double42 = textTitle41.getContentXOffset();
        org.jfree.chart.entity.TitleEntity titleEntity44 = new org.jfree.chart.entity.TitleEntity(shape28, (org.jfree.chart.title.Title) textTitle41, "WMAP_Plot");
        java.lang.String str45 = titleEntity44.toString();
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 1.0d + "'", double42 == 1.0d);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "TitleEntity: tooltip = WMAP_Plot" + "'", str45.equals("TitleEntity: tooltip = WMAP_Plot"));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "", "ERROR : Relative To String", "hi!", "ERROR : Relative To String");
        basicProjectInfo5.setCopyright("ERROR : Relative To String");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo13 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "", "ERROR : Relative To String", "hi!", "ERROR : Relative To String");
        basicProjectInfo13.setCopyright("ERROR : Relative To String");
        basicProjectInfo5.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo13);
        java.lang.String str17 = basicProjectInfo5.getCopyright();
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ERROR : Relative To String" + "'", str17.equals("ERROR : Relative To String"));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot2 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = combinedDomainXYPlot2.getDomainAxisIndex(valueAxis3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = combinedDomainXYPlot2.getRangeAxis();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("WMAP_Plot", font1, (org.jfree.chart.plot.Plot) combinedDomainXYPlot2, true);
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle9.setMaximumLinesToDisplay(1);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, categoryItemRenderer15);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot16.getDomainAxisEdge();
        textTitle9.setPosition(rectangleEdge17);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = textTitle9.getPadding();
        jFreeChart7.removeSubtitle((org.jfree.chart.title.Title) textTitle9);
        org.jfree.chart.title.LegendTitle legendTitle21 = jFreeChart7.getLegend();
        org.jfree.chart.block.BlockContainer blockContainer22 = legendTitle21.getItemContainer();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment23 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment24 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.ColumnArrangement columnArrangement27 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment23, verticalAlignment24, 0.0d, (double) 100);
        blockContainer22.setArrangement((org.jfree.chart.block.Arrangement) columnArrangement27);
        java.util.TimeZone timeZone29 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection30 = new org.jfree.data.time.TimeSeriesCollection(timeZone29);
        org.jfree.data.Range range32 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection30, true);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer34 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement27, (org.jfree.data.general.Dataset) timeSeriesCollection30, (java.lang.Comparable) 2147483647);
        legendItemBlockContainer34.setToolTipText("TextBlockAnchor.TOP_RIGHT");
        legendItemBlockContainer34.setURLText("Category Plot");
        java.lang.String str39 = legendItemBlockContainer34.getToolTipText();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(legendTitle21);
        org.junit.Assert.assertNotNull(blockContainer22);
        org.junit.Assert.assertNotNull(horizontalAlignment23);
        org.junit.Assert.assertNotNull(verticalAlignment24);
        org.junit.Assert.assertNull(range32);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "TextBlockAnchor.TOP_RIGHT" + "'", str39.equals("TextBlockAnchor.TOP_RIGHT"));
    }
}

