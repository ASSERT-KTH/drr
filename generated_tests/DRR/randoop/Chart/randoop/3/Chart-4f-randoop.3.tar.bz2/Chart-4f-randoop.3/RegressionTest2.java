import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        try {
            org.jfree.chart.LegendItemCollection legendItemCollection2 = waferMapPlot1.getLegendItems();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.clearSeriesStrokes(true);
        java.awt.Color color3 = java.awt.Color.CYAN;
        xYBarRenderer0.setBaseFillPaint((java.awt.Paint) color3, false);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator9 = xYBarRenderer0.getURLGenerator(8, (int) (short) 10, false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(xYURLGenerator9);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        org.jfree.chart.util.PaintMap paintMap0 = new org.jfree.chart.util.PaintMap();
        boolean boolean2 = paintMap0.containsKey((java.lang.Comparable) 9999);
        boolean boolean4 = paintMap0.containsKey((java.lang.Comparable) "{0}");
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection(timeZone5);
        boolean boolean7 = paintMap0.equals((java.lang.Object) timeZone5);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        java.awt.Paint[] paintArray0 = null;
        java.awt.Paint[] paintArray1 = null;
        java.awt.Paint[] paintArray2 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Stroke[] strokeArray4 = new java.awt.Stroke[] { stroke3 };
        java.awt.Stroke[] strokeArray5 = new java.awt.Stroke[] {};
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) (short) -1, (float) 1L);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape8, rectangleAnchor9, (double) (short) 0, (double) 1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState14 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo13);
        java.awt.geom.Line2D line2D15 = xYItemRendererState14.workingLine;
        java.awt.Shape[] shapeArray16 = new java.awt.Shape[] { shape12, line2D15 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier17 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, paintArray2, strokeArray4, strokeArray5, shapeArray16);
        java.awt.Paint paint18 = defaultDrawingSupplier17.getNextOutlinePaint();
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(strokeArray4);
        org.junit.Assert.assertNotNull(strokeArray5);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(line2D15);
        org.junit.Assert.assertNotNull(shapeArray16);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot2 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = combinedDomainXYPlot2.getDomainAxisIndex(valueAxis3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = combinedDomainXYPlot2.getRangeAxis();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("WMAP_Plot", font1, (org.jfree.chart.plot.Plot) combinedDomainXYPlot2, true);
        boolean boolean8 = jFreeChart7.getAntiAlias();
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        textTitle10.setPadding(rectangleInsets11);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = textTitle10.getMargin();
        jFreeChart7.setPadding(rectangleInsets13);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        java.awt.image.BufferedImage bufferedImage18 = jFreeChart7.createBufferedImage((int) (short) 1, 3, chartRenderingInfo17);
        jFreeChart7.setAntiAlias(false);
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle22.setMaximumLinesToDisplay(1);
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset25, categoryAxis26, valueAxis27, categoryItemRenderer28);
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = categoryPlot29.getDomainAxisEdge();
        textTitle22.setPosition(rectangleEdge30);
        textTitle22.setPadding((double) '#', (double) (short) -1, 0.0d, (double) (byte) 10);
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = textTitle22.getPadding();
        jFreeChart7.setTitle(textTitle22);
        jFreeChart7.setBackgroundImageAlignment(3);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(bufferedImage18);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertNotNull(rectangleInsets37);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.junit.Assert.assertNotNull(unitType0);
    }

//    @Test
//    public void test009() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test009");
//        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
//        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
//        int int3 = combinedDomainXYPlot1.getDomainAxisIndex(valueAxis2);
//        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
//        int int5 = combinedDomainXYPlot1.getRangeAxisIndex(valueAxis4);
//        java.awt.Paint paint6 = combinedDomainXYPlot1.getDomainZeroBaselinePaint();
//        java.awt.Stroke stroke7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
//        combinedDomainXYPlot1.setRangeZeroBaselineStroke(stroke7);
//        org.jfree.data.xy.XYDataset xYDataset9 = null;
//        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = combinedDomainXYPlot1.getRendererForDataset(xYDataset9);
//        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=0,g=255,b=0]");
//        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//        xYBarRenderer13.clearSeriesStrokes(true);
//        java.awt.Stroke stroke17 = xYBarRenderer13.lookupSeriesOutlineStroke(100);
//        xYBarRenderer13.setShadowXOffset((double) 100.0f);
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
//        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState22 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo21);
//        java.awt.geom.Line2D line2D23 = xYItemRendererState22.workingLine;
//        xYBarRenderer13.setLegendShape(0, (java.awt.Shape) line2D23);
//        numberAxis12.setRightArrow((java.awt.Shape) line2D23);
//        org.jfree.chart.axis.TickUnitSource tickUnitSource26 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
//        numberAxis12.setStandardTickUnits(tickUnitSource26);
//        java.text.NumberFormat numberFormat29 = java.text.NumberFormat.getCurrencyInstance();
//        org.jfree.chart.axis.NumberTickUnit numberTickUnit30 = new org.jfree.chart.axis.NumberTickUnit((double) 100L, numberFormat29);
//        numberAxis12.setTickUnit(numberTickUnit30, true, false);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date37 = spreadsheetDate36.toDate();
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date37);
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day();
//        long long40 = day39.getLastMillisecond();
//        org.jfree.chart.axis.PeriodAxis periodAxis41 = new org.jfree.chart.axis.PeriodAxis("$8.00", (org.jfree.data.time.RegularTimePeriod) day38, (org.jfree.data.time.RegularTimePeriod) day39);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date45 = spreadsheetDate44.toDate();
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date45);
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
//        long long48 = day47.getLastMillisecond();
//        org.jfree.chart.axis.PeriodAxis periodAxis49 = new org.jfree.chart.axis.PeriodAxis("$8.00", (org.jfree.data.time.RegularTimePeriod) day46, (org.jfree.data.time.RegularTimePeriod) day47);
//        org.jfree.chart.axis.ValueAxis[] valueAxisArray50 = new org.jfree.chart.axis.ValueAxis[] { numberAxis12, periodAxis41, periodAxis49 };
//        combinedDomainXYPlot1.setRangeAxes(valueAxisArray50);
//        java.awt.Stroke stroke52 = null;
//        combinedDomainXYPlot1.setOutlineStroke(stroke52);
//        combinedDomainXYPlot1.clearAnnotations();
//        combinedRangeXYPlot0.add((org.jfree.chart.plot.XYPlot) combinedDomainXYPlot1, 9999);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(paint6);
//        org.junit.Assert.assertNotNull(stroke7);
//        org.junit.Assert.assertNull(xYItemRenderer10);
//        org.junit.Assert.assertNotNull(stroke17);
//        org.junit.Assert.assertNotNull(line2D23);
//        org.junit.Assert.assertNotNull(tickUnitSource26);
//        org.junit.Assert.assertNotNull(numberFormat29);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560495599999L + "'", long40 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1560495599999L + "'", long48 == 1560495599999L);
//        org.junit.Assert.assertNotNull(valueAxisArray50);
//    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        org.jfree.chart.util.StrokeMap strokeMap0 = new org.jfree.chart.util.StrokeMap();
        java.lang.Object obj1 = strokeMap0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        org.jfree.data.time.DateRange dateRange0 = new org.jfree.data.time.DateRange();
        long long1 = dateRange0.getUpperMillis();
        org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState1 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo0);
        java.awt.geom.Line2D line2D2 = xYItemRendererState1.workingLine;
        boolean boolean3 = xYItemRendererState1.getProcessVisibleItemsOnly();
        int int4 = xYItemRendererState1.getFirstItemIndex();
        org.junit.Assert.assertNotNull(line2D2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        int int2 = combinedDomainXYPlot0.getDomainAxisIndex(valueAxis1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = combinedDomainXYPlot0.getDomainAxisIndex(valueAxis3);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        combinedDomainXYPlot0.setRangeAxis(10, valueAxis6);
        boolean boolean8 = combinedDomainXYPlot0.canSelectByRegion();
        java.awt.Paint paint9 = combinedDomainXYPlot0.getDomainTickBandPaint();
        java.awt.Paint paint10 = org.jfree.chart.axis.SymbolAxis.DEFAULT_GRID_BAND_ALTERNATE_PAINT;
        combinedDomainXYPlot0.setDomainGridlinePaint(paint10);
        java.awt.geom.Point2D point2D12 = null;
        try {
            combinedDomainXYPlot0.setQuadrantOrigin(point2D12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'origin' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        java.awt.Color color1 = java.awt.Color.getColor("");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        org.jfree.data.time.DateRange dateRange0 = new org.jfree.data.time.DateRange();
        long long1 = dateRange0.getUpperMillis();
        org.jfree.data.Range range3 = org.jfree.data.Range.scale((org.jfree.data.Range) dateRange0, (double) 100.0f);
        org.jfree.data.Range range5 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange0, 0.0d);
        java.lang.String str6 = dateRange0.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str6.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("($1.00)");
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Point2D point2D3 = null;
        polarPlot0.zoomDomainAxes((double) 3, plotRenderingInfo2, point2D3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        try {
            polarPlot0.zoomRangeAxes((double) (-2208182400001L), (double) (-2206281600001L), plotRenderingInfo7, point2D8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation(100, axisLocation7);
        int int9 = categoryPlot4.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = categoryPlot4.getDomainAxisEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge10);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer12 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.data.Range range14 = xYStepRenderer12.findDomainBounds(xYDataset13);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator15 = null;
        xYStepRenderer12.setBaseToolTipGenerator(xYToolTipGenerator15);
        boolean boolean17 = xYStepRenderer12.getBaseShapesVisible();
        double double18 = xYStepRenderer12.getStepPoint();
        boolean boolean19 = rectangleEdge10.equals((java.lang.Object) xYStepRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState22 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo21);
        java.awt.geom.Line2D line2D23 = xYItemRendererState22.workingLine;
        org.jfree.chart.entity.ChartEntity chartEntity26 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) line2D23, "{0}: ({1}, {2})", "series");
        java.awt.Shape shape30 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) line2D23, 3.0d, (float) 'a', (float) (short) 0);
        xYStepRenderer12.setSeriesShape(0, (java.awt.Shape) line2D23, false);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator36 = xYStepRenderer12.getItemLabelGenerator(1, 31, true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(line2D23);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNull(xYItemLabelGenerator36);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        int int0 = org.jfree.data.time.SerialDate.MONDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

//    @Test
//    public void test021() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test021");
//        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
//        int int5 = categoryPlot4.getDomainAxisCount();
//        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
//        categoryPlot4.setRangeAxisLocation(100, axisLocation7);
//        int int9 = categoryPlot4.getWeight();
//        java.awt.Paint paint10 = categoryPlot4.getRangeGridlinePaint();
//        org.jfree.chart.plot.DrawingSupplier drawingSupplier11 = null;
//        categoryPlot4.setDrawingSupplier(drawingSupplier11, false);
//        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot14 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
//        int int16 = combinedDomainXYPlot14.getDomainAxisIndex(valueAxis15);
//        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
//        int int18 = combinedDomainXYPlot14.getRangeAxisIndex(valueAxis17);
//        java.awt.Paint paint19 = combinedDomainXYPlot14.getDomainZeroBaselinePaint();
//        java.awt.Stroke stroke20 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
//        combinedDomainXYPlot14.setRangeZeroBaselineStroke(stroke20);
//        org.jfree.data.xy.XYDataset xYDataset22 = null;
//        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = combinedDomainXYPlot14.getRendererForDataset(xYDataset22);
//        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=0,g=255,b=0]");
//        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer26 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//        xYBarRenderer26.clearSeriesStrokes(true);
//        java.awt.Stroke stroke30 = xYBarRenderer26.lookupSeriesOutlineStroke(100);
//        xYBarRenderer26.setShadowXOffset((double) 100.0f);
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
//        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState35 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo34);
//        java.awt.geom.Line2D line2D36 = xYItemRendererState35.workingLine;
//        xYBarRenderer26.setLegendShape(0, (java.awt.Shape) line2D36);
//        numberAxis25.setRightArrow((java.awt.Shape) line2D36);
//        org.jfree.chart.axis.TickUnitSource tickUnitSource39 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
//        numberAxis25.setStandardTickUnits(tickUnitSource39);
//        java.text.NumberFormat numberFormat42 = java.text.NumberFormat.getCurrencyInstance();
//        org.jfree.chart.axis.NumberTickUnit numberTickUnit43 = new org.jfree.chart.axis.NumberTickUnit((double) 100L, numberFormat42);
//        numberAxis25.setTickUnit(numberTickUnit43, true, false);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date50 = spreadsheetDate49.toDate();
//        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date50);
//        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day();
//        long long53 = day52.getLastMillisecond();
//        org.jfree.chart.axis.PeriodAxis periodAxis54 = new org.jfree.chart.axis.PeriodAxis("$8.00", (org.jfree.data.time.RegularTimePeriod) day51, (org.jfree.data.time.RegularTimePeriod) day52);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate57 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date58 = spreadsheetDate57.toDate();
//        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day(date58);
//        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day();
//        long long61 = day60.getLastMillisecond();
//        org.jfree.chart.axis.PeriodAxis periodAxis62 = new org.jfree.chart.axis.PeriodAxis("$8.00", (org.jfree.data.time.RegularTimePeriod) day59, (org.jfree.data.time.RegularTimePeriod) day60);
//        org.jfree.chart.axis.ValueAxis[] valueAxisArray63 = new org.jfree.chart.axis.ValueAxis[] { numberAxis25, periodAxis54, periodAxis62 };
//        combinedDomainXYPlot14.setRangeAxes(valueAxisArray63);
//        categoryPlot4.setRangeAxes(valueAxisArray63);
//        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem68 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day66, (java.lang.Number) 255);
//        categoryPlot4.setDomainCrosshairRowKey((java.lang.Comparable) 255);
//        org.jfree.data.category.CategoryDataset categoryDataset70 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis71 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis72 = null;
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer73 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot74 = new org.jfree.chart.plot.CategoryPlot(categoryDataset70, categoryAxis71, valueAxis72, categoryItemRenderer73);
//        int int75 = categoryPlot74.getDomainAxisCount();
//        org.jfree.chart.axis.AxisLocation axisLocation77 = null;
//        categoryPlot74.setRangeAxisLocation(100, axisLocation77);
//        java.lang.String str79 = categoryPlot74.getNoDataMessage();
//        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder80 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
//        categoryPlot74.setDatasetRenderingOrder(datasetRenderingOrder80);
//        categoryPlot4.setDatasetRenderingOrder(datasetRenderingOrder80);
//        java.lang.Object obj83 = null;
//        boolean boolean84 = datasetRenderingOrder80.equals(obj83);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertNotNull(paint10);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(paint19);
//        org.junit.Assert.assertNotNull(stroke20);
//        org.junit.Assert.assertNull(xYItemRenderer23);
//        org.junit.Assert.assertNotNull(stroke30);
//        org.junit.Assert.assertNotNull(line2D36);
//        org.junit.Assert.assertNotNull(tickUnitSource39);
//        org.junit.Assert.assertNotNull(numberFormat42);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 1560495599999L + "'", long53 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 1560495599999L + "'", long61 == 1560495599999L);
//        org.junit.Assert.assertNotNull(valueAxisArray63);
//        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 1 + "'", int75 == 1);
//        org.junit.Assert.assertNull(str79);
//        org.junit.Assert.assertNotNull(datasetRenderingOrder80);
//        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
//    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot4.getDomainAxis();
        java.awt.Color color6 = java.awt.Color.MAGENTA;
        categoryPlot4.setRangeMinorGridlinePaint((java.awt.Paint) color6);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) -1);
        int int2 = year1.getYear();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

//    @Test
//    public void test024() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test024");
//        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
//        int int2 = combinedDomainXYPlot0.getDomainAxisIndex(valueAxis1);
//        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
//        int int8 = categoryPlot7.getDomainAxisCount();
//        org.jfree.chart.axis.AxisLocation axisLocation10 = null;
//        categoryPlot7.setRangeAxisLocation(100, axisLocation10);
//        int int12 = categoryPlot7.getWeight();
//        java.awt.Paint paint13 = categoryPlot7.getRangeGridlinePaint();
//        org.jfree.chart.plot.DrawingSupplier drawingSupplier14 = null;
//        categoryPlot7.setDrawingSupplier(drawingSupplier14, false);
//        boolean boolean17 = categoryPlot7.isSubplot();
//        categoryPlot7.setRangeZeroBaselineVisible(true);
//        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder20 = categoryPlot7.getDatasetRenderingOrder();
//        combinedDomainXYPlot0.setDatasetRenderingOrder(datasetRenderingOrder20);
//        java.awt.Stroke stroke22 = combinedDomainXYPlot0.getOutlineStroke();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date26 = spreadsheetDate25.toDate();
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date26);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        long long29 = day28.getLastMillisecond();
//        org.jfree.chart.axis.PeriodAxis periodAxis30 = new org.jfree.chart.axis.PeriodAxis("$8.00", (org.jfree.data.time.RegularTimePeriod) day27, (org.jfree.data.time.RegularTimePeriod) day28);
//        java.lang.String str31 = periodAxis30.getLabelToolTip();
//        java.util.TimeZone timeZone32 = periodAxis30.getTimeZone();
//        boolean boolean33 = periodAxis30.isAutoRange();
//        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot34 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
//        int int36 = combinedDomainXYPlot34.getDomainAxisIndex(valueAxis35);
//        org.jfree.chart.axis.ValueAxis valueAxis37 = combinedDomainXYPlot34.getRangeAxis();
//        boolean boolean38 = combinedDomainXYPlot34.isSubplot();
//        java.awt.Stroke stroke39 = combinedDomainXYPlot34.getRangeMinorGridlineStroke();
//        periodAxis30.setTickMarkStroke(stroke39);
//        int int41 = combinedDomainXYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) periodAxis30);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertNotNull(paint13);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(datasetRenderingOrder20);
//        org.junit.Assert.assertNotNull(stroke22);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560495599999L + "'", long29 == 1560495599999L);
//        org.junit.Assert.assertNull(str31);
//        org.junit.Assert.assertNotNull(timeZone32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
//        org.junit.Assert.assertNull(valueAxis37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(stroke39);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
//    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer0.setBaseLinesVisible(true);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator4 = xYStepRenderer0.getSeriesItemLabelGenerator((int) '#');
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator8 = xYStepRenderer0.getItemLabelGenerator((int) (byte) 100, (-1), false);
        try {
            xYStepRenderer0.setSeriesLinesVisible((int) (byte) -1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYItemLabelGenerator4);
        org.junit.Assert.assertNull(xYItemLabelGenerator8);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        int int2 = combinedDomainXYPlot0.getDomainAxisIndex(valueAxis1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = combinedDomainXYPlot0.getRangeAxisIndex(valueAxis3);
        java.awt.Paint paint5 = combinedDomainXYPlot0.getDomainZeroBaselinePaint();
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        combinedDomainXYPlot0.setRangeMinorGridlineStroke(stroke6);
        org.jfree.chart.LegendItemCollection legendItemCollection8 = combinedDomainXYPlot0.getLegendItems();
        boolean boolean9 = combinedDomainXYPlot0.isRangeZoomable();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(legendItemCollection8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot2 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = combinedDomainXYPlot2.getDomainAxisIndex(valueAxis3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = combinedDomainXYPlot2.getRangeAxis();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("WMAP_Plot", font1, (org.jfree.chart.plot.Plot) combinedDomainXYPlot2, true);
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        combinedDomainXYPlot2.setFixedRangeAxisSpace(axisSpace8, true);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNull(valueAxis5);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot2 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = combinedDomainXYPlot2.getDomainAxisIndex(valueAxis3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = combinedDomainXYPlot2.getRangeAxis();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("WMAP_Plot", font1, (org.jfree.chart.plot.Plot) combinedDomainXYPlot2, true);
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle9.setMaximumLinesToDisplay(1);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, categoryItemRenderer15);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot16.getDomainAxisEdge();
        textTitle9.setPosition(rectangleEdge17);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = textTitle9.getPadding();
        jFreeChart7.removeSubtitle((org.jfree.chart.title.Title) textTitle9);
        org.jfree.chart.title.LegendTitle legendTitle21 = jFreeChart7.getLegend();
        org.jfree.chart.block.BlockContainer blockContainer22 = legendTitle21.getItemContainer();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment23 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment24 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.ColumnArrangement columnArrangement27 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment23, verticalAlignment24, 0.0d, (double) 100);
        blockContainer22.setArrangement((org.jfree.chart.block.Arrangement) columnArrangement27);
        java.util.TimeZone timeZone29 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection30 = new org.jfree.data.time.TimeSeriesCollection(timeZone29);
        org.jfree.data.Range range32 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection30, true);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer34 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement27, (org.jfree.data.general.Dataset) timeSeriesCollection30, (java.lang.Comparable) 2147483647);
        legendItemBlockContainer34.setToolTipText("TextBlockAnchor.TOP_RIGHT");
        legendItemBlockContainer34.setURLText("Category Plot");
        org.jfree.data.general.Dataset dataset39 = legendItemBlockContainer34.getDataset();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(legendTitle21);
        org.junit.Assert.assertNotNull(blockContainer22);
        org.junit.Assert.assertNotNull(horizontalAlignment23);
        org.junit.Assert.assertNotNull(verticalAlignment24);
        org.junit.Assert.assertNull(range32);
        org.junit.Assert.assertNotNull(dataset39);
    }

//    @Test
//    public void test029() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test029");
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//        int int1 = segmentedTimeline0.getSegmentsExcluded();
//        int int2 = segmentedTimeline0.getGroupSegmentCount();
//        boolean boolean3 = segmentedTimeline0.getAdjustForDaylightSaving();
//        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange();
//        java.util.Date date5 = dateRange4.getLowerDate();
//        org.jfree.chart.axis.SegmentedTimeline.Segment segment6 = segmentedTimeline0.getSegment(date5);
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline7 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//        int int8 = segmentedTimeline7.getSegmentsExcluded();
//        int int9 = segmentedTimeline7.getGroupSegmentCount();
//        boolean boolean12 = segmentedTimeline7.containsDomainRange((long) 8, (long) (short) 100);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date15 = spreadsheetDate14.toDate();
//        java.util.Date date16 = spreadsheetDate14.toDate();
//        java.util.TimeZone timeZone17 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(date16, timeZone17);
//        boolean boolean19 = segmentedTimeline7.containsDomainValue(date16);
//        long long20 = segmentedTimeline0.toTimelineValue(date16);
//        segmentedTimeline0.addException(86400000L);
//        org.junit.Assert.assertNotNull(segmentedTimeline0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(segment6);
//        org.junit.Assert.assertNotNull(segmentedTimeline7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 7 + "'", int9 == 7);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 518400267L + "'", long20 == 518400267L);
//    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot2 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = combinedDomainXYPlot2.getDomainAxisIndex(valueAxis3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = combinedDomainXYPlot2.getRangeAxis();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("WMAP_Plot", font1, (org.jfree.chart.plot.Plot) combinedDomainXYPlot2, true);
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle9.setMaximumLinesToDisplay(1);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, categoryItemRenderer15);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot16.getDomainAxisEdge();
        textTitle9.setPosition(rectangleEdge17);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = textTitle9.getPadding();
        jFreeChart7.removeSubtitle((org.jfree.chart.title.Title) textTitle9);
        org.jfree.chart.title.LegendTitle legendTitle21 = jFreeChart7.getLegend();
        org.jfree.chart.block.BlockContainer blockContainer22 = legendTitle21.getItemContainer();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment23 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment24 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.ColumnArrangement columnArrangement27 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment23, verticalAlignment24, 0.0d, (double) 100);
        blockContainer22.setArrangement((org.jfree.chart.block.Arrangement) columnArrangement27);
        java.util.TimeZone timeZone29 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection30 = new org.jfree.data.time.TimeSeriesCollection(timeZone29);
        org.jfree.data.Range range32 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection30, true);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer34 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement27, (org.jfree.data.general.Dataset) timeSeriesCollection30, (java.lang.Comparable) 2147483647);
        legendItemBlockContainer34.setToolTipText("TextBlockAnchor.TOP_RIGHT");
        org.jfree.data.time.DateRange dateRange39 = new org.jfree.data.time.DateRange((-1.0d), (double) (byte) 100);
        long long40 = dateRange39.getLowerMillis();
        boolean boolean41 = legendItemBlockContainer34.equals((java.lang.Object) long40);
        java.lang.String str42 = legendItemBlockContainer34.getURLText();
        java.awt.Graphics2D graphics2D43 = null;
        java.awt.Font font45 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot46 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis47 = null;
        int int48 = combinedDomainXYPlot46.getDomainAxisIndex(valueAxis47);
        org.jfree.chart.axis.ValueAxis valueAxis49 = combinedDomainXYPlot46.getRangeAxis();
        org.jfree.chart.JFreeChart jFreeChart51 = new org.jfree.chart.JFreeChart("WMAP_Plot", font45, (org.jfree.chart.plot.Plot) combinedDomainXYPlot46, true);
        org.jfree.chart.title.TextTitle textTitle53 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle53.setMaximumLinesToDisplay(1);
        org.jfree.data.category.CategoryDataset categoryDataset56 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = null;
        org.jfree.chart.axis.ValueAxis valueAxis58 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer59 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot(categoryDataset56, categoryAxis57, valueAxis58, categoryItemRenderer59);
        org.jfree.chart.util.RectangleEdge rectangleEdge61 = categoryPlot60.getDomainAxisEdge();
        textTitle53.setPosition(rectangleEdge61);
        org.jfree.chart.util.RectangleInsets rectangleInsets63 = textTitle53.getPadding();
        jFreeChart51.removeSubtitle((org.jfree.chart.title.Title) textTitle53);
        org.jfree.chart.title.LegendTitle legendTitle65 = jFreeChart51.getLegend();
        org.jfree.chart.block.BlockContainer blockContainer66 = legendTitle65.getItemContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets67 = legendTitle65.getPadding();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor68 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        legendTitle65.setLegendItemGraphicAnchor(rectangleAnchor68);
        java.awt.geom.Rectangle2D rectangle2D70 = legendTitle65.getBounds();
        org.jfree.chart.axis.NumberAxis numberAxis72 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=0,g=255,b=0]");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer73 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer73.clearSeriesStrokes(true);
        java.awt.Stroke stroke77 = xYBarRenderer73.lookupSeriesOutlineStroke(100);
        xYBarRenderer73.setShadowXOffset((double) 100.0f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo81 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState82 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo81);
        java.awt.geom.Line2D line2D83 = xYItemRendererState82.workingLine;
        xYBarRenderer73.setLegendShape(0, (java.awt.Shape) line2D83);
        numberAxis72.setRightArrow((java.awt.Shape) line2D83);
        numberAxis72.setMinorTickMarksVisible(true);
        numberAxis72.setVerticalTickLabels(false);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline90 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        int int91 = segmentedTimeline90.getSegmentsExcluded();
        int int92 = segmentedTimeline90.getGroupSegmentCount();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate94 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date95 = spreadsheetDate94.toDate();
        org.jfree.data.time.Day day96 = new org.jfree.data.time.Day(date95);
        boolean boolean97 = segmentedTimeline90.containsDomainValue(date95);
        boolean boolean98 = numberAxis72.equals((java.lang.Object) boolean97);
        try {
            java.lang.Object obj99 = legendItemBlockContainer34.draw(graphics2D43, rectangle2D70, (java.lang.Object) boolean97);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(legendTitle21);
        org.junit.Assert.assertNotNull(blockContainer22);
        org.junit.Assert.assertNotNull(horizontalAlignment23);
        org.junit.Assert.assertNotNull(verticalAlignment24);
        org.junit.Assert.assertNull(range32);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-1L) + "'", long40 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertNotNull(font45);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertNull(valueAxis49);
        org.junit.Assert.assertNotNull(rectangleEdge61);
        org.junit.Assert.assertNotNull(rectangleInsets63);
        org.junit.Assert.assertNotNull(legendTitle65);
        org.junit.Assert.assertNotNull(blockContainer66);
        org.junit.Assert.assertNotNull(rectangleInsets67);
        org.junit.Assert.assertNotNull(rectangleAnchor68);
        org.junit.Assert.assertNotNull(rectangle2D70);
        org.junit.Assert.assertNotNull(stroke77);
        org.junit.Assert.assertNotNull(line2D83);
        org.junit.Assert.assertNotNull(segmentedTimeline90);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 2 + "'", int91 == 2);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 7 + "'", int92 == 7);
        org.junit.Assert.assertNotNull(date95);
        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + true + "'", boolean97 == true);
        org.junit.Assert.assertTrue("'" + boolean98 + "' != '" + false + "'", boolean98 == false);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation(100, axisLocation7);
        int int9 = categoryPlot4.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = categoryPlot4.getDomainAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot4.zoomRangeAxes((double) 10.0f, plotRenderingInfo12, point2D13, false);
        categoryPlot4.setRangeGridlinesVisible(true);
        org.jfree.chart.util.SortOrder sortOrder18 = null;
        try {
            categoryPlot4.setRowRenderingOrder(sortOrder18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge10);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition0 = new org.jfree.chart.labels.ItemLabelPosition();
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        int int3 = combinedDomainXYPlot1.getDomainAxisIndex(valueAxis2);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        int int5 = combinedDomainXYPlot1.getRangeAxisIndex(valueAxis4);
        java.awt.Paint paint6 = combinedDomainXYPlot1.getDomainZeroBaselinePaint();
        java.awt.Stroke stroke7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        combinedDomainXYPlot1.setRangeZeroBaselineStroke(stroke7);
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = combinedDomainXYPlot1.getRendererForDataset(xYDataset9);
        org.jfree.chart.axis.AxisLocation axisLocation12 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        combinedDomainXYPlot1.setRangeAxisLocation(0, axisLocation12);
        combinedDomainXYPlot0.setRangeAxisLocation(axisLocation12, true);
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.Font font18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot19 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        int int21 = combinedDomainXYPlot19.getDomainAxisIndex(valueAxis20);
        org.jfree.chart.axis.ValueAxis valueAxis22 = combinedDomainXYPlot19.getRangeAxis();
        org.jfree.chart.JFreeChart jFreeChart24 = new org.jfree.chart.JFreeChart("WMAP_Plot", font18, (org.jfree.chart.plot.Plot) combinedDomainXYPlot19, true);
        org.jfree.chart.title.TextTitle textTitle26 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle26.setMaximumLinesToDisplay(1);
        org.jfree.data.category.CategoryDataset categoryDataset29 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = null;
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer32 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot(categoryDataset29, categoryAxis30, valueAxis31, categoryItemRenderer32);
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = categoryPlot33.getDomainAxisEdge();
        textTitle26.setPosition(rectangleEdge34);
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = textTitle26.getPadding();
        jFreeChart24.removeSubtitle((org.jfree.chart.title.Title) textTitle26);
        org.jfree.chart.title.LegendTitle legendTitle38 = jFreeChart24.getLegend();
        org.jfree.chart.block.BlockContainer blockContainer39 = legendTitle38.getItemContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = legendTitle38.getPadding();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor41 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        legendTitle38.setLegendItemGraphicAnchor(rectangleAnchor41);
        java.awt.geom.Rectangle2D rectangle2D43 = legendTitle38.getBounds();
        try {
            combinedDomainXYPlot0.drawBackground(graphics2D16, rectangle2D43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(xYItemRenderer10);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNull(valueAxis22);
        org.junit.Assert.assertNotNull(rectangleEdge34);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertNotNull(legendTitle38);
        org.junit.Assert.assertNotNull(blockContainer39);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertNotNull(rectangleAnchor41);
        org.junit.Assert.assertNotNull(rectangle2D43);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setDepthFactor((double) 2958465);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.data.general.DefaultPieDataset defaultPieDataset5 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset) defaultPieDataset5);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator7 = ringPlot6.getToolTipGenerator();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        org.jfree.chart.plot.PiePlotState piePlotState10 = piePlot3D0.initialise(graphics2D3, rectangle2D4, (org.jfree.chart.plot.PiePlot) ringPlot6, (java.lang.Integer) 1, plotRenderingInfo9);
        java.text.NumberFormat numberFormat13 = java.text.NumberFormat.getCurrencyInstance();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit14 = new org.jfree.chart.axis.NumberTickUnit((double) 100L, numberFormat13);
        java.text.NumberFormat numberFormat16 = java.text.NumberFormat.getCurrencyInstance();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit17 = new org.jfree.chart.axis.NumberTickUnit((double) 100L, numberFormat16);
        java.lang.String str19 = numberFormat16.format((long) 8);
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator20 = new org.jfree.chart.labels.StandardPieToolTipGenerator("{0}: ({1}, {2})", numberFormat13, numberFormat16);
        piePlot3D0.setToolTipGenerator((org.jfree.chart.labels.PieToolTipGenerator) standardPieToolTipGenerator20);
        org.junit.Assert.assertNull(pieToolTipGenerator7);
        org.junit.Assert.assertNotNull(piePlotState10);
        org.junit.Assert.assertNotNull(numberFormat13);
        org.junit.Assert.assertNotNull(numberFormat16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "$8.00" + "'", str19.equals("$8.00"));
    }

//    @Test
//    public void test035() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test035");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date3 = spreadsheetDate2.toDate();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        long long6 = day5.getLastMillisecond();
//        org.jfree.chart.axis.PeriodAxis periodAxis7 = new org.jfree.chart.axis.PeriodAxis("$8.00", (org.jfree.data.time.RegularTimePeriod) day4, (org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.String str8 = periodAxis7.getLabelToolTip();
//        java.util.TimeZone timeZone9 = periodAxis7.getTimeZone();
//        java.awt.geom.Rectangle2D rectangle2D11 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
//        double double13 = periodAxis7.java2DToValue((double) 1900, rectangle2D11, rectangleEdge12);
//        periodAxis7.setNegativeArrowVisible(true);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560495599999L + "'", long6 == 1560495599999L);
//        org.junit.Assert.assertNull(str8);
//        org.junit.Assert.assertNotNull(timeZone9);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + Double.POSITIVE_INFINITY + "'", double13 == Double.POSITIVE_INFINITY);
//    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.data.general.DatasetGroup datasetGroup2 = timeSeriesCollection1.getGroup();
        org.jfree.data.general.DatasetGroup datasetGroup3 = timeSeriesCollection1.getGroup();
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.junit.Assert.assertNotNull(datasetGroup2);
        org.junit.Assert.assertNotNull(datasetGroup3);
        org.junit.Assert.assertNull(range4);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator0 = new org.jfree.chart.urls.StandardXYURLGenerator();
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = categoryPlot4.getDomainAxisEdge();
        boolean boolean6 = categoryPlot4.isRangeGridlinesVisible();
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=0,g=255,b=0]");
        org.jfree.data.Range range9 = categoryPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis8);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = categoryPlot4.getDomainAxisForDataset(2147483647);
        categoryPlot4.clearDomainAxes();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, categoryItemRenderer16);
        int int18 = categoryPlot17.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation20 = null;
        categoryPlot17.setRangeAxisLocation(100, axisLocation20);
        int int22 = categoryPlot17.getWeight();
        java.awt.Paint paint23 = categoryPlot17.getRangeGridlinePaint();
        org.jfree.chart.axis.ValueAxis valueAxis25 = categoryPlot17.getRangeAxisForDataset((int) (short) 100);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent26 = null;
        categoryPlot17.datasetChanged(datasetChangeEvent26);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder28 = categoryPlot17.getDatasetRenderingOrder();
        categoryPlot4.setParent((org.jfree.chart.plot.Plot) categoryPlot17);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertNull(categoryAxis11);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNull(valueAxis25);
        org.junit.Assert.assertNotNull(datasetRenderingOrder28);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        int int3 = java.awt.Color.HSBtoRGB((float) 100L, (float) 22801L, (float) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-67856) + "'", int3 == (-67856));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        int int1 = segmentedTimeline0.getSegmentsExcluded();
        int int2 = segmentedTimeline0.getGroupSegmentCount();
        boolean boolean4 = segmentedTimeline0.containsDomainValue((long) 5);
        long long5 = segmentedTimeline0.getSegmentsIncludedSize();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 432000000L + "'", long5 == 432000000L);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot2 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = combinedDomainXYPlot2.getDomainAxisIndex(valueAxis3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = combinedDomainXYPlot2.getRangeAxis();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("WMAP_Plot", font1, (org.jfree.chart.plot.Plot) combinedDomainXYPlot2, true);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, valueAxis11, categoryItemRenderer12);
        int int14 = categoryPlot13.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation16 = null;
        categoryPlot13.setRangeAxisLocation(100, axisLocation16);
        org.jfree.chart.plot.Marker marker18 = null;
        org.jfree.chart.util.Layer layer19 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean20 = categoryPlot13.removeDomainMarker(marker18, layer19);
        java.util.Collection collection21 = combinedDomainXYPlot2.getDomainMarkers(1900, layer19);
        combinedDomainXYPlot2.setDomainCrosshairValue((double) 100.0f);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot24 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        int int26 = combinedDomainXYPlot24.getDomainAxisIndex(valueAxis25);
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        int int28 = combinedDomainXYPlot24.getRangeAxisIndex(valueAxis27);
        java.awt.Paint paint29 = combinedDomainXYPlot24.getDomainZeroBaselinePaint();
        java.awt.Stroke stroke30 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        combinedDomainXYPlot24.setRangeZeroBaselineStroke(stroke30);
        org.jfree.data.xy.XYDataset xYDataset32 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = combinedDomainXYPlot24.getRendererForDataset(xYDataset32);
        org.jfree.chart.axis.AxisLocation axisLocation35 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        combinedDomainXYPlot24.setRangeAxisLocation(0, axisLocation35);
        combinedDomainXYPlot2.setRangeAxisLocation(axisLocation35, false);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer39 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.data.xy.XYDataset xYDataset40 = null;
        org.jfree.data.Range range41 = xYStepRenderer39.findDomainBounds(xYDataset40);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator42 = null;
        xYStepRenderer39.setBaseToolTipGenerator(xYToolTipGenerator42);
        boolean boolean44 = xYStepRenderer39.getBaseShapesVisible();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator45 = null;
        xYStepRenderer39.setBaseToolTipGenerator(xYToolTipGenerator45, true);
        java.awt.Color color49 = java.awt.Color.lightGray;
        xYStepRenderer39.setSeriesFillPaint((int) '#', (java.awt.Paint) color49);
        java.awt.image.ColorModel colorModel51 = null;
        java.awt.Rectangle rectangle52 = null;
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        java.awt.geom.AffineTransform affineTransform54 = null;
        java.awt.RenderingHints renderingHints55 = null;
        java.awt.PaintContext paintContext56 = color49.createContext(colorModel51, rectangle52, rectangle2D53, affineTransform54, renderingHints55);
        combinedDomainXYPlot2.setRangeCrosshairPaint((java.awt.Paint) color49);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(layer19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNull(xYItemRenderer33);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertNull(range41);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNotNull(paintContext56);
    }

//    @Test
//    public void test044() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test044");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date3 = spreadsheetDate2.toDate();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        long long6 = day5.getLastMillisecond();
//        org.jfree.chart.axis.PeriodAxis periodAxis7 = new org.jfree.chart.axis.PeriodAxis("$8.00", (org.jfree.data.time.RegularTimePeriod) day4, (org.jfree.data.time.RegularTimePeriod) day5);
//        double double8 = periodAxis7.getLabelAngle();
//        boolean boolean9 = periodAxis7.isMinorTickMarksVisible();
//        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) (short) -1, (float) 1L);
//        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = org.jfree.chart.util.RectangleAnchor.TOP;
//        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape12, rectangleAnchor13, (double) (short) 0, (double) 1);
//        periodAxis7.setUpArrow(shape12);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560495599999L + "'", long6 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(shape12);
//        org.junit.Assert.assertNotNull(rectangleAnchor13);
//        org.junit.Assert.assertNotNull(shape16);
//    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation(100, axisLocation7);
        java.awt.Paint paint11 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer12 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer12.clearSeriesStrokes(true);
        java.awt.Stroke stroke16 = xYBarRenderer12.lookupSeriesOutlineStroke(100);
        xYBarRenderer12.setShadowXOffset((double) 100.0f);
        java.awt.Stroke stroke19 = xYBarRenderer12.getBaseOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker20 = new org.jfree.chart.plot.ValueMarker(0.05d, paint11, stroke19);
        java.awt.Paint paint21 = valueMarker20.getPaint();
        java.awt.Paint paint22 = null;
        valueMarker20.setOutlinePaint(paint22);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot24 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        int int26 = combinedDomainXYPlot24.getDomainAxisIndex(valueAxis25);
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        int int28 = combinedDomainXYPlot24.getRangeAxisIndex(valueAxis27);
        java.awt.Paint paint29 = combinedDomainXYPlot24.getDomainZeroBaselinePaint();
        boolean boolean30 = combinedDomainXYPlot24.isDomainZeroBaselineVisible();
        org.jfree.chart.util.Layer layer31 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection32 = combinedDomainXYPlot24.getRangeMarkers(layer31);
        categoryPlot4.addRangeMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker20, layer31);
        int int34 = categoryPlot4.getWeight();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(layer31);
        org.junit.Assert.assertNull(collection32);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        double double0 = org.jfree.chart.plot.PolarPlot.DEFAULT_ANGLE_TICK_UNIT_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 45.0d + "'", double0 == 45.0d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        double double3 = timeSeriesCollection1.getDomainUpperBound(false);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
    }

//    @Test
//    public void test049() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test049");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date3 = spreadsheetDate2.toDate();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        long long6 = day5.getLastMillisecond();
//        org.jfree.chart.axis.PeriodAxis periodAxis7 = new org.jfree.chart.axis.PeriodAxis("$8.00", (org.jfree.data.time.RegularTimePeriod) day4, (org.jfree.data.time.RegularTimePeriod) day5);
//        boolean boolean8 = periodAxis7.isMinorTickMarksVisible();
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560495599999L + "'", long6 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Paint paint1 = piePlot3D0.getBaseSectionOutlinePaint();
        java.awt.Paint paint2 = piePlot3D0.getShadowPaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        java.awt.Shape shape4 = null;
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, valueAxis7, categoryItemRenderer8);
        int int10 = categoryPlot9.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation12 = null;
        categoryPlot9.setRangeAxisLocation(100, axisLocation12);
        int int14 = categoryPlot9.getWeight();
        java.awt.Paint paint15 = categoryPlot9.getRangeGridlinePaint();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer16 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer16.clearSeriesStrokes(true);
        java.awt.Stroke stroke20 = xYBarRenderer16.lookupSeriesOutlineStroke(100);
        xYBarRenderer16.setShadowXOffset((double) 100.0f);
        java.awt.Stroke stroke23 = xYBarRenderer16.getBaseOutlineStroke();
        java.awt.Paint paint24 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("", "TextBlockAnchor.TOP_RIGHT", "{0}: ({1}, {2})", "", shape4, paint15, stroke23, paint24);
        java.awt.Color color26 = java.awt.Color.lightGray;
        legendItem25.setLabelPaint((java.awt.Paint) color26);
        java.awt.Shape shape28 = legendItem25.getLine();
        java.text.AttributedString attributedString29 = legendItem25.getAttributedLabel();
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNull(attributedString29);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation(100, axisLocation7);
        int int9 = categoryPlot4.getWeight();
        java.awt.Paint paint10 = categoryPlot4.getRangeGridlinePaint();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent11 = null;
        categoryPlot4.notifyListeners(plotChangeEvent11);
        java.awt.Paint paint13 = categoryPlot4.getRangeZeroBaselinePaint();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset0.insertValue(0, (java.lang.Comparable) (-2208960000000L), (double) (byte) 10);
        defaultPieDataset0.setValue((java.lang.Comparable) '4', (java.lang.Number) 31);
        try {
            defaultPieDataset0.insertValue(9999, (java.lang.Comparable) Double.NaN, (double) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 'position' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=0,g=255,b=0]");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer2 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer2.clearSeriesStrokes(true);
        java.awt.Stroke stroke6 = xYBarRenderer2.lookupSeriesOutlineStroke(100);
        xYBarRenderer2.setShadowXOffset((double) 100.0f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState11 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo10);
        java.awt.geom.Line2D line2D12 = xYItemRendererState11.workingLine;
        xYBarRenderer2.setLegendShape(0, (java.awt.Shape) line2D12);
        numberAxis1.setRightArrow((java.awt.Shape) line2D12);
        org.jfree.chart.axis.TickUnitSource tickUnitSource15 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        numberAxis1.setStandardTickUnits(tickUnitSource15);
        java.text.NumberFormat numberFormat18 = java.text.NumberFormat.getCurrencyInstance();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit19 = new org.jfree.chart.axis.NumberTickUnit((double) 100L, numberFormat18);
        numberAxis1.setTickUnit(numberTickUnit19, true, false);
        numberAxis1.setVerticalTickLabels(false);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(line2D12);
        org.junit.Assert.assertNotNull(tickUnitSource15);
        org.junit.Assert.assertNotNull(numberFormat18);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.SECOND;
        java.lang.String str1 = dateTickUnitType0.toString();
        java.text.DateFormat dateFormat3 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit4 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, (int) (short) -1, dateFormat3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DateTickUnitType.SECOND" + "'", str1.equals("DateTickUnitType.SECOND"));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot4.getDomainAxis();
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis9, categoryItemRenderer10);
        int int12 = categoryPlot11.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation14 = null;
        categoryPlot11.setRangeAxisLocation(100, axisLocation14);
        int int16 = categoryPlot11.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot11.getDomainAxisEdge();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot19 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot20 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        int int22 = combinedDomainXYPlot20.getDomainAxisIndex(valueAxis21);
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        int int24 = combinedDomainXYPlot20.getRangeAxisIndex(valueAxis23);
        java.awt.Paint paint25 = combinedDomainXYPlot20.getDomainZeroBaselinePaint();
        java.awt.Stroke stroke26 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        combinedDomainXYPlot20.setRangeZeroBaselineStroke(stroke26);
        org.jfree.data.xy.XYDataset xYDataset28 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = combinedDomainXYPlot20.getRendererForDataset(xYDataset28);
        org.jfree.chart.axis.AxisLocation axisLocation31 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        combinedDomainXYPlot20.setRangeAxisLocation(0, axisLocation31);
        combinedDomainXYPlot19.setRangeAxisLocation(axisLocation31, true);
        categoryPlot11.setDomainAxisLocation((int) ' ', axisLocation31);
        java.lang.String str36 = axisLocation31.toString();
        categoryPlot4.setDomainAxisLocation(2, axisLocation31, false);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNull(xYItemRenderer29);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str36.equals("AxisLocation.TOP_OR_RIGHT"));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "org.jfree.data.UnknownKeyException: TextBlockAnchor.TOP_RIGHT", "ItemLabelAnchor.INSIDE7", "DomainOrder.NONE");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date6 = spreadsheetDate5.toDate();
        java.util.Date date7 = spreadsheetDate5.toDate();
        java.util.TimeZone timeZone8 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date7, timeZone8);
        int int10 = month9.getYearValue();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month9, (java.lang.Number) 0.0f, false);
        java.util.Collection collection14 = timeSeries3.getTimePeriods();
        java.lang.String str15 = timeSeries3.getDomainDescription();
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1900 + "'", int10 == 1900);
        org.junit.Assert.assertNotNull(collection14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "ItemLabelAnchor.INSIDE7" + "'", str15.equals("ItemLabelAnchor.INSIDE7"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=0,g=255,b=0]");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer2 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer2.clearSeriesStrokes(true);
        java.awt.Stroke stroke6 = xYBarRenderer2.lookupSeriesOutlineStroke(100);
        xYBarRenderer2.setShadowXOffset((double) 100.0f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState11 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo10);
        java.awt.geom.Line2D line2D12 = xYItemRendererState11.workingLine;
        xYBarRenderer2.setLegendShape(0, (java.awt.Shape) line2D12);
        numberAxis1.setRightArrow((java.awt.Shape) line2D12);
        org.jfree.chart.axis.TickUnitSource tickUnitSource15 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        numberAxis1.setStandardTickUnits(tickUnitSource15);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range18 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range19 = org.jfree.data.Range.combine(range17, range18);
        numberAxis1.setRange(range17, true, false);
        boolean boolean23 = numberAxis1.isInverted();
        numberAxis1.zoomRange((double) (byte) 10, (double) 100L);
        org.jfree.data.RangeType rangeType27 = numberAxis1.getRangeType();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(line2D12);
        org.junit.Assert.assertNotNull(tickUnitSource15);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rangeType27);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        int int3 = combinedDomainXYPlot1.getDomainAxisIndex(valueAxis2);
        org.jfree.chart.axis.ValueAxis valueAxis4 = combinedDomainXYPlot1.getRangeAxis();
        boolean boolean5 = combinedDomainXYPlot1.isSubplot();
        combinedDomainXYPlot1.setRangeMinorGridlinesVisible(false);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer8 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer8.clearSeriesStrokes(true);
        java.awt.Stroke stroke12 = xYBarRenderer8.lookupSeriesOutlineStroke(100);
        xYBarRenderer8.setShadowXOffset((double) 100.0f);
        java.awt.Stroke stroke15 = xYBarRenderer8.getBaseOutlineStroke();
        boolean boolean16 = xYBarRenderer8.getBaseItemLabelsVisible();
        combinedDomainXYPlot1.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer8);
        java.awt.Paint paint18 = combinedDomainXYPlot1.getRangeTickBandPaint();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer19 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer19.clearSeriesStrokes(true);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator22 = xYBarRenderer19.getBaseItemLabelGenerator();
        java.awt.Paint paint24 = xYBarRenderer19.lookupSeriesPaint(9999);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = xYBarRenderer19.getSeriesNegativeItemLabelPosition(6);
        org.jfree.data.time.TimeSeries timeSeries27 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection28 = new org.jfree.data.time.TimeSeriesCollection(timeSeries27);
        org.jfree.data.category.CategoryDataset categoryDataset29 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = null;
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer32 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot(categoryDataset29, categoryAxis30, valueAxis31, categoryItemRenderer32);
        int int34 = categoryPlot33.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation36 = null;
        categoryPlot33.setRangeAxisLocation(100, axisLocation36);
        timeSeriesCollection28.removeChangeListener((org.jfree.data.general.DatasetChangeListener) categoryPlot33);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate40 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection28, true);
        org.jfree.data.Range range41 = xYBarRenderer19.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection28);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer42 = combinedDomainXYPlot1.getRendererForDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection28);
        boolean boolean43 = xYStepAreaRenderer0.hasListener((java.util.EventListener) timeSeriesCollection28);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertNull(xYItemLabelGenerator22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(itemLabelPosition26);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertNull(range41);
        org.junit.Assert.assertNull(xYItemRenderer42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.lang.Object obj1 = multiplePiePlot0.clone();
        org.jfree.chart.util.TableOrder tableOrder2 = multiplePiePlot0.getDataExtractOrder();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(tableOrder2);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot2 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = combinedDomainXYPlot2.getDomainAxisIndex(valueAxis3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = combinedDomainXYPlot2.getRangeAxis();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("WMAP_Plot", font1, (org.jfree.chart.plot.Plot) combinedDomainXYPlot2, true);
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle9.setMaximumLinesToDisplay(1);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, categoryItemRenderer15);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot16.getDomainAxisEdge();
        textTitle9.setPosition(rectangleEdge17);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = textTitle9.getPadding();
        jFreeChart7.removeSubtitle((org.jfree.chart.title.Title) textTitle9);
        java.awt.RenderingHints renderingHints21 = jFreeChart7.getRenderingHints();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(renderingHints21);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle1.setMaximumLinesToDisplay(1);
        double double4 = textTitle1.getHeight();
        textTitle1.visible = false;
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle8.setMaximumLinesToDisplay(1);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, valueAxis13, categoryItemRenderer14);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = categoryPlot15.getDomainAxisEdge();
        textTitle8.setPosition(rectangleEdge16);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment18 = textTitle8.getTextAlignment();
        textTitle1.setTextAlignment(horizontalAlignment18);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNotNull(horizontalAlignment18);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem(0.0d, (double) 1L);
        java.lang.String str3 = xYDataItem2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "[0.0, 1.0]" + "'", str3.equals("[0.0, 1.0]"));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date3 = spreadsheetDate2.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date6 = spreadsheetDate5.toDate();
        boolean boolean7 = spreadsheetDate2.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        int int8 = spreadsheetDate2.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addMonths(31, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertNotNull(serialDate9);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setBaseItemLabelsVisible(true);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType1 = rectangleConstraint0.getHeightConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = rectangleConstraint0.toFixedHeight(0.08d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType4 = rectangleConstraint0.getHeightConstraintType();
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertNotNull(lengthConstraintType1);
        org.junit.Assert.assertNotNull(rectangleConstraint3);
        org.junit.Assert.assertNotNull(lengthConstraintType4);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.data.Range range2 = xYStepRenderer0.findDomainBounds(xYDataset1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = null;
        xYStepRenderer0.setBaseToolTipGenerator(xYToolTipGenerator3);
        boolean boolean5 = xYStepRenderer0.getBaseShapesVisible();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator6 = null;
        xYStepRenderer0.setBaseToolTipGenerator(xYToolTipGenerator6, true);
        java.awt.Stroke stroke10 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        xYStepRenderer0.setSeriesOutlineStroke((int) (short) 1, stroke10);
        int int12 = xYStepRenderer0.getPassCount();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot13 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        int int15 = combinedDomainXYPlot13.getDomainAxisIndex(valueAxis14);
        org.jfree.chart.axis.ValueAxis valueAxis16 = combinedDomainXYPlot13.getRangeAxis();
        boolean boolean17 = combinedDomainXYPlot13.isSubplot();
        combinedDomainXYPlot13.setRangeMinorGridlinesVisible(false);
        boolean boolean20 = combinedDomainXYPlot13.isDomainZeroBaselineVisible();
        int int21 = combinedDomainXYPlot13.getWeight();
        xYStepRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) combinedDomainXYPlot13);
        xYStepRenderer0.setSeriesItemLabelsVisible(0, (java.lang.Boolean) false, false);
        xYStepRenderer0.setUseOutlinePaint(false);
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNull(valueAxis16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot2 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = combinedDomainXYPlot2.getDomainAxisIndex(valueAxis3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = combinedDomainXYPlot2.getRangeAxis();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("WMAP_Plot", font1, (org.jfree.chart.plot.Plot) combinedDomainXYPlot2, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        combinedDomainXYPlot2.zoomDomainAxes(0.025d, plotRenderingInfo9, point2D10, false);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNull(valueAxis5);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        int int1 = segmentedTimeline0.getSegmentsExcluded();
        int int2 = segmentedTimeline0.getGroupSegmentCount();
        boolean boolean3 = segmentedTimeline0.getAdjustForDaylightSaving();
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange();
        java.util.Date date5 = dateRange4.getLowerDate();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment6 = segmentedTimeline0.getSegment(date5);
        boolean boolean7 = segment6.inIncludeSegments();
        long long8 = segment6.getSegmentNumber();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(segment6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 25566L + "'", long8 == 25566L);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation(100, axisLocation7);
        int int9 = categoryPlot4.getWeight();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        int int11 = categoryPlot4.getIndexOf(categoryItemRenderer10);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot12 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot13 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        int int15 = combinedDomainXYPlot13.getDomainAxisIndex(valueAxis14);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        int int17 = combinedDomainXYPlot13.getRangeAxisIndex(valueAxis16);
        java.awt.Paint paint18 = combinedDomainXYPlot13.getDomainZeroBaselinePaint();
        java.awt.Stroke stroke19 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        combinedDomainXYPlot13.setRangeZeroBaselineStroke(stroke19);
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = combinedDomainXYPlot13.getRendererForDataset(xYDataset21);
        org.jfree.chart.axis.AxisLocation axisLocation24 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        combinedDomainXYPlot13.setRangeAxisLocation(0, axisLocation24);
        combinedDomainXYPlot12.setRangeAxisLocation(axisLocation24, true);
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, categoryItemRenderer31);
        int int33 = categoryPlot32.getDomainAxisCount();
        java.awt.Color color34 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        categoryPlot32.setRangeZeroBaselinePaint((java.awt.Paint) color34);
        java.awt.Paint paint36 = categoryPlot32.getDomainCrosshairPaint();
        boolean boolean37 = axisLocation24.equals((java.lang.Object) paint36);
        categoryPlot4.setRangeAxisLocation(axisLocation24);
        categoryPlot4.setBackgroundAlpha((-4126.0f));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(xYItemRenderer22);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        java.lang.String str0 = org.jfree.chart.urls.StandardXYURLGenerator.DEFAULT_PREFIX;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "index.html" + "'", str0.equals("index.html"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState1 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo0);
        org.jfree.chart.plot.XYCrosshairState xYCrosshairState2 = null;
        xYItemRendererState1.setCrosshairState(xYCrosshairState2);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = categoryPlot4.getDomainAxisEdge();
        boolean boolean6 = categoryPlot4.isRangeGridlinesVisible();
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=0,g=255,b=0]");
        org.jfree.data.Range range9 = categoryPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis8);
        numberAxis8.setAutoRangeMinimumSize((double) 100);
        java.text.NumberFormat numberFormat12 = numberAxis8.getNumberFormatOverride();
        numberAxis8.setRangeAboutValue((double) (-4126), (double) 2.0f);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertNull(numberFormat12);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        java.awt.geom.Ellipse2D ellipse2D0 = null;
        java.awt.geom.Ellipse2D ellipse2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(ellipse2D0, ellipse2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) (short) -1, (float) 1L);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape2, rectangleAnchor3, (double) (short) 0, (double) 1);
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis9, categoryItemRenderer10);
        int int12 = categoryPlot11.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation14 = null;
        categoryPlot11.setRangeAxisLocation(100, axisLocation14);
        org.jfree.chart.plot.Marker marker16 = null;
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean18 = categoryPlot11.removeDomainMarker(marker16, layer17);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, valueAxis21, categoryItemRenderer22);
        int int24 = categoryPlot23.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation26 = null;
        categoryPlot23.setRangeAxisLocation(100, axisLocation26);
        org.jfree.chart.plot.Marker marker28 = null;
        org.jfree.chart.util.Layer layer29 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean30 = categoryPlot23.removeDomainMarker(marker28, layer29);
        java.util.Collection collection31 = categoryPlot11.getRangeMarkers(layer29);
        org.jfree.chart.entity.PlotEntity plotEntity34 = new org.jfree.chart.entity.PlotEntity(shape6, (org.jfree.chart.plot.Plot) categoryPlot11, "", "");
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(layer29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(collection31);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        int int2 = combinedDomainXYPlot0.getDomainAxisIndex(valueAxis1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = combinedDomainXYPlot0.getRangeAxis();
        boolean boolean4 = combinedDomainXYPlot0.isSubplot();
        combinedDomainXYPlot0.setRangeMinorGridlinesVisible(false);
        boolean boolean7 = combinedDomainXYPlot0.isDomainZeroBaselineVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        try {
            combinedDomainXYPlot0.zoomDomainAxes(1.0d, plotRenderingInfo9, point2D10, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

//    @Test
//    public void test080() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test080");
//        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
//        org.jfree.chart.util.RectangleInsets rectangleInsets2 = textTitle1.getMargin();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date7 = spreadsheetDate6.toDate();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date7);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        long long10 = day9.getLastMillisecond();
//        org.jfree.chart.axis.PeriodAxis periodAxis11 = new org.jfree.chart.axis.PeriodAxis("$8.00", (org.jfree.data.time.RegularTimePeriod) day8, (org.jfree.data.time.RegularTimePeriod) day9);
//        java.lang.Class class12 = periodAxis11.getMajorTickTimePeriodClass();
//        java.lang.Object obj13 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("NOID", class12);
//        boolean boolean14 = textTitle1.equals(obj13);
//        org.junit.Assert.assertNotNull(rectangleInsets2);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560495599999L + "'", long10 == 1560495599999L);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertNull(obj13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        java.util.Date date3 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date6 = spreadsheetDate5.toDate();
        java.util.Date date7 = spreadsheetDate5.toDate();
        java.util.TimeZone timeZone8 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date7, timeZone8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date3, timeZone8);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone8);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=0,g=255,b=0]");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer4 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer4.clearSeriesStrokes(true);
        java.awt.Stroke stroke8 = xYBarRenderer4.lookupSeriesOutlineStroke(100);
        xYBarRenderer4.setShadowXOffset((double) 100.0f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState13 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo12);
        java.awt.geom.Line2D line2D14 = xYItemRendererState13.workingLine;
        xYBarRenderer4.setLegendShape(0, (java.awt.Shape) line2D14);
        numberAxis3.setRightArrow((java.awt.Shape) line2D14);
        xYStepRenderer0.setLegendShape(0, (java.awt.Shape) line2D14);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot18 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        xYStepRenderer0.setPlot((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot18);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        try {
            combinedRangeXYPlot18.zoomDomainAxes((double) (-458), (double) 10, plotRenderingInfo22, point2D23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(line2D14);
    }

//    @Test
//    public void test083() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test083");
//        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 1, (float) 6);
//        double[][] doubleArray7 = new double[][] {};
//        org.jfree.data.category.CategoryDataset categoryDataset8 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("null", "LengthConstraintType.FIXED", doubleArray7);
//        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D10 = new org.jfree.chart.axis.CategoryAxis3D("ERROR : Relative To String");
//        categoryAxis3D10.clearCategoryLabelToolTips();
//        categoryAxis3D10.configure();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date16 = spreadsheetDate15.toDate();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date16);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        long long19 = day18.getLastMillisecond();
//        org.jfree.chart.axis.PeriodAxis periodAxis20 = new org.jfree.chart.axis.PeriodAxis("$8.00", (org.jfree.data.time.RegularTimePeriod) day17, (org.jfree.data.time.RegularTimePeriod) day18);
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D10, (org.jfree.chart.axis.ValueAxis) periodAxis20, categoryItemRenderer21);
//        boolean boolean23 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset8);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date26 = spreadsheetDate25.toDate();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date29 = spreadsheetDate28.toDate();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date32 = spreadsheetDate31.toDate();
//        boolean boolean33 = spreadsheetDate28.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate31);
//        boolean boolean34 = spreadsheetDate25.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate31);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date37 = spreadsheetDate36.toDate();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date40 = spreadsheetDate39.toDate();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date43 = spreadsheetDate42.toDate();
//        boolean boolean44 = spreadsheetDate39.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate42);
//        boolean boolean45 = spreadsheetDate36.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate42);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean49 = spreadsheetDate25.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate36, (org.jfree.data.time.SerialDate) spreadsheetDate47, 0);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date52 = spreadsheetDate51.toDate();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate54 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date55 = spreadsheetDate54.toDate();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate57 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date58 = spreadsheetDate57.toDate();
//        boolean boolean59 = spreadsheetDate54.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate57);
//        boolean boolean60 = spreadsheetDate51.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate57);
//        int int61 = spreadsheetDate51.getYYYY();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate63 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date64 = spreadsheetDate63.toDate();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate66 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date67 = spreadsheetDate66.toDate();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate69 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date70 = spreadsheetDate69.toDate();
//        boolean boolean71 = spreadsheetDate66.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate69);
//        boolean boolean72 = spreadsheetDate63.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate69);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate74 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date75 = spreadsheetDate74.toDate();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate77 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date78 = spreadsheetDate77.toDate();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate80 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date81 = spreadsheetDate80.toDate();
//        boolean boolean82 = spreadsheetDate77.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate80);
//        boolean boolean83 = spreadsheetDate74.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate80);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate85 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean87 = spreadsheetDate63.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate74, (org.jfree.data.time.SerialDate) spreadsheetDate85, 0);
//        boolean boolean89 = spreadsheetDate25.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate51, (org.jfree.data.time.SerialDate) spreadsheetDate63, (int) (byte) 100);
//        java.lang.String str90 = spreadsheetDate63.toString();
//        org.jfree.data.time.DateRange dateRange91 = new org.jfree.data.time.DateRange();
//        java.util.Date date92 = dateRange91.getLowerDate();
//        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity93 = new org.jfree.chart.entity.CategoryItemEntity(shape2, "TextBlockAnchor.BOTTOM_RIGHT", "Category Plot", categoryDataset8, (java.lang.Comparable) spreadsheetDate63, (java.lang.Comparable) date92);
//        org.jfree.data.category.CategoryDataset categoryDataset94 = categoryItemEntity93.getDataset();
//        org.junit.Assert.assertNotNull(shape2);
//        org.junit.Assert.assertNotNull(doubleArray7);
//        org.junit.Assert.assertNotNull(categoryDataset8);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560495599999L + "'", long19 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1900 + "'", int61 == 1900);
//        org.junit.Assert.assertNotNull(date64);
//        org.junit.Assert.assertNotNull(date67);
//        org.junit.Assert.assertNotNull(date70);
//        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
//        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
//        org.junit.Assert.assertNotNull(date75);
//        org.junit.Assert.assertNotNull(date78);
//        org.junit.Assert.assertNotNull(date81);
//        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
//        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
//        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
//        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
//        org.junit.Assert.assertTrue("'" + str90 + "' != '" + "9-January-1900" + "'", str90.equals("9-January-1900"));
//        org.junit.Assert.assertNotNull(date92);
//        org.junit.Assert.assertNotNull(categoryDataset94);
//    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.data.Range range2 = xYStepRenderer0.findDomainBounds(xYDataset1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = null;
        xYStepRenderer0.setBaseToolTipGenerator(xYToolTipGenerator3);
        boolean boolean5 = xYStepRenderer0.getBaseShapesVisible();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator6 = null;
        xYStepRenderer0.setBaseToolTipGenerator(xYToolTipGenerator6, true);
        java.awt.Stroke stroke10 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        xYStepRenderer0.setSeriesOutlineStroke((int) (short) 1, stroke10);
        org.jfree.data.general.WaferMapDataset waferMapDataset12 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot13 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset12);
        java.awt.Font font14 = waferMapPlot13.getNoDataMessageFont();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent15 = null;
        waferMapPlot13.notifyListeners(plotChangeEvent15);
        boolean boolean17 = xYStepRenderer0.hasListener((java.util.EventListener) waferMapPlot13);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState19 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo18);
        java.awt.geom.Line2D line2D20 = xYItemRendererState19.workingLine;
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, valueAxis23, categoryItemRenderer24);
        int int26 = categoryPlot25.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation28 = null;
        categoryPlot25.setRangeAxisLocation(100, axisLocation28);
        int int30 = categoryPlot25.getWeight();
        java.awt.Paint paint31 = categoryPlot25.getRangeGridlinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier32 = null;
        categoryPlot25.setDrawingSupplier(drawingSupplier32, false);
        org.jfree.chart.entity.PlotEntity plotEntity35 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape) line2D20, (org.jfree.chart.plot.Plot) categoryPlot25);
        java.awt.Shape shape38 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) (short) -1, (float) 1L);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor39 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape42 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape38, rectangleAnchor39, (double) (short) 0, (double) 1);
        plotEntity35.setArea(shape38);
        xYStepRenderer0.setBaseLegendShape(shape38);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer45 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer45.setBaseLinesVisible(true);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator49 = xYStepRenderer45.getSeriesItemLabelGenerator((int) '#');
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator53 = xYStepRenderer45.getItemLabelGenerator((int) (byte) 100, (-1), false);
        java.awt.Shape shape55 = xYStepRenderer45.getSeriesShape((int) '#');
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent56 = null;
        xYStepRenderer45.notifyListeners(rendererChangeEvent56);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer58 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.data.xy.XYDataset xYDataset59 = null;
        org.jfree.data.Range range60 = xYStepRenderer58.findDomainBounds(xYDataset59);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator61 = null;
        xYStepRenderer58.setBaseToolTipGenerator(xYToolTipGenerator61);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition66 = xYStepRenderer58.getPositiveItemLabelPosition((int) (short) -1, (-458), false);
        xYStepRenderer45.setBaseNegativeItemLabelPosition(itemLabelPosition66, true);
        xYStepRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition66, false);
        double double71 = itemLabelPosition66.getAngle();
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(line2D20);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(shape38);
        org.junit.Assert.assertNotNull(rectangleAnchor39);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertNull(xYItemLabelGenerator49);
        org.junit.Assert.assertNull(xYItemLabelGenerator53);
        org.junit.Assert.assertNull(shape55);
        org.junit.Assert.assertNull(range60);
        org.junit.Assert.assertNotNull(itemLabelPosition66);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
    }

//    @Test
//    public void test085() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test085");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date3 = spreadsheetDate2.toDate();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        long long6 = day5.getLastMillisecond();
//        org.jfree.chart.axis.PeriodAxis periodAxis7 = new org.jfree.chart.axis.PeriodAxis("$8.00", (org.jfree.data.time.RegularTimePeriod) day4, (org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.String str8 = periodAxis7.getLabelToolTip();
//        java.lang.Class class9 = periodAxis7.getMinorTickTimePeriodClass();
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560495599999L + "'", long6 == 1560495599999L);
//        org.junit.Assert.assertNull(str8);
//        org.junit.Assert.assertNotNull(class9);
//    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer1 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.data.Range range3 = xYStepRenderer1.findDomainBounds(xYDataset2);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator4 = null;
        xYStepRenderer1.setBaseToolTipGenerator(xYToolTipGenerator4);
        boolean boolean6 = xYStepRenderer1.getBaseShapesVisible();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
        xYStepRenderer1.setBaseToolTipGenerator(xYToolTipGenerator7, true);
        java.text.DateFormat dateFormat11 = null;
        java.text.DateFormat dateFormat12 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator13 = new org.jfree.chart.labels.StandardXYToolTipGenerator("{0}: ({1}, {2})", dateFormat11, dateFormat12);
        xYStepRenderer1.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator13);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator15 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer16 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(255, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator13, xYURLGenerator15);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        java.awt.Shape shape4 = null;
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, valueAxis7, categoryItemRenderer8);
        int int10 = categoryPlot9.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation12 = null;
        categoryPlot9.setRangeAxisLocation(100, axisLocation12);
        int int14 = categoryPlot9.getWeight();
        java.awt.Paint paint15 = categoryPlot9.getRangeGridlinePaint();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer16 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer16.clearSeriesStrokes(true);
        java.awt.Stroke stroke20 = xYBarRenderer16.lookupSeriesOutlineStroke(100);
        xYBarRenderer16.setShadowXOffset((double) 100.0f);
        java.awt.Stroke stroke23 = xYBarRenderer16.getBaseOutlineStroke();
        java.awt.Paint paint24 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("", "TextBlockAnchor.TOP_RIGHT", "{0}: ({1}, {2})", "", shape4, paint15, stroke23, paint24);
        java.lang.Comparable comparable26 = legendItem25.getSeriesKey();
        boolean boolean27 = legendItem25.isShapeVisible();
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNull(comparable26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation(100, axisLocation7);
        int int9 = categoryPlot4.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = categoryPlot4.getDomainAxisEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge10);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer12 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.data.Range range14 = xYStepRenderer12.findDomainBounds(xYDataset13);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator15 = null;
        xYStepRenderer12.setBaseToolTipGenerator(xYToolTipGenerator15);
        boolean boolean17 = xYStepRenderer12.getBaseShapesVisible();
        double double18 = xYStepRenderer12.getStepPoint();
        boolean boolean19 = rectangleEdge10.equals((java.lang.Object) xYStepRenderer12);
        java.awt.Paint[] paintArray21 = null;
        java.awt.Paint[] paintArray22 = null;
        java.awt.Paint[] paintArray23 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Stroke[] strokeArray25 = new java.awt.Stroke[] { stroke24 };
        java.awt.Stroke[] strokeArray26 = new java.awt.Stroke[] {};
        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) (short) -1, (float) 1L);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor30 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape33 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape29, rectangleAnchor30, (double) (short) 0, (double) 1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState35 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo34);
        java.awt.geom.Line2D line2D36 = xYItemRendererState35.workingLine;
        java.awt.Shape[] shapeArray37 = new java.awt.Shape[] { shape33, line2D36 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier38 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray21, paintArray22, paintArray23, strokeArray25, strokeArray26, shapeArray37);
        java.awt.Stroke stroke39 = defaultDrawingSupplier38.getNextStroke();
        try {
            xYStepRenderer12.setSeriesStroke(2147483647, stroke39, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(paintArray23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(strokeArray25);
        org.junit.Assert.assertNotNull(strokeArray26);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(rectangleAnchor30);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(line2D36);
        org.junit.Assert.assertNotNull(shapeArray37);
        org.junit.Assert.assertNotNull(stroke39);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        try {
            java.lang.Number number3 = defaultXYDataset0.getY((int) (byte) 1, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("$8.00", "HorizontalAlignment.CENTER", "", "AxisLocation.TOP_OR_RIGHT", "series");
        basicProjectInfo5.setCopyright("index.html");
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        int int2 = combinedDomainXYPlot0.getDomainAxisIndex(valueAxis1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = combinedDomainXYPlot0.getRangeAxisIndex(valueAxis3);
        java.awt.Paint paint5 = combinedDomainXYPlot0.getDomainZeroBaselinePaint();
        boolean boolean6 = combinedDomainXYPlot0.isDomainZeroBaselineVisible();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder7 = combinedDomainXYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation8 = combinedDomainXYPlot0.getDomainAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, valueAxis11, categoryItemRenderer12);
        int int14 = categoryPlot13.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation16 = null;
        categoryPlot13.setRangeAxisLocation(100, axisLocation16);
        int int18 = categoryPlot13.getWeight();
        java.awt.Paint paint19 = categoryPlot13.getRangeGridlinePaint();
        org.jfree.chart.axis.ValueAxis valueAxis21 = categoryPlot13.getRangeAxisForDataset((int) (short) 100);
        java.awt.Shape shape26 = null;
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = null;
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis28, valueAxis29, categoryItemRenderer30);
        int int32 = categoryPlot31.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation34 = null;
        categoryPlot31.setRangeAxisLocation(100, axisLocation34);
        int int36 = categoryPlot31.getWeight();
        java.awt.Paint paint37 = categoryPlot31.getRangeGridlinePaint();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer38 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer38.clearSeriesStrokes(true);
        java.awt.Stroke stroke42 = xYBarRenderer38.lookupSeriesOutlineStroke(100);
        xYBarRenderer38.setShadowXOffset((double) 100.0f);
        java.awt.Stroke stroke45 = xYBarRenderer38.getBaseOutlineStroke();
        java.awt.Paint paint46 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem47 = new org.jfree.chart.LegendItem("", "TextBlockAnchor.TOP_RIGHT", "{0}: ({1}, {2})", "", shape26, paint37, stroke45, paint46);
        categoryPlot13.setBackgroundPaint(paint46);
        combinedDomainXYPlot0.setDomainCrosshairPaint(paint46);
        java.awt.Paint paint51 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer52 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer52.clearSeriesStrokes(true);
        java.awt.Stroke stroke56 = xYBarRenderer52.lookupSeriesOutlineStroke(100);
        xYBarRenderer52.setShadowXOffset((double) 100.0f);
        java.awt.Stroke stroke59 = xYBarRenderer52.getBaseOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker60 = new org.jfree.chart.plot.ValueMarker(0.05d, paint51, stroke59);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent61 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) stroke59);
        combinedDomainXYPlot0.setDomainMinorGridlineStroke(stroke59);
        boolean boolean63 = combinedDomainXYPlot0.canSelectByPoint();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(seriesRenderingOrder7);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNull(valueAxis21);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation(100, axisLocation7);
        int int9 = categoryPlot4.getWeight();
        java.awt.Paint paint10 = categoryPlot4.getRangeGridlinePaint();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent11 = null;
        categoryPlot4.notifyListeners(plotChangeEvent11);
        categoryPlot4.setDomainCrosshairRowKey((java.lang.Comparable) (byte) 0, false);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline16 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        int int17 = segmentedTimeline16.getSegmentsExcluded();
        int int18 = segmentedTimeline16.getGroupSegmentCount();
        boolean boolean19 = segmentedTimeline16.getAdjustForDaylightSaving();
        org.jfree.data.time.DateRange dateRange20 = new org.jfree.data.time.DateRange();
        java.util.Date date21 = dateRange20.getLowerDate();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment22 = segmentedTimeline16.getSegment(date21);
        boolean boolean25 = segment22.contains(100L, (long) (-458));
        long long27 = segment22.calculateSegmentNumber(0L);
        boolean boolean29 = segment22.contains((long) 3);
        categoryPlot4.setDomainCrosshairRowKey((java.lang.Comparable) segment22, false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(segmentedTimeline16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2 + "'", int17 == 2);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 7 + "'", int18 == 7);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(segment22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 25566L + "'", long27 == 25566L);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE3;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        java.awt.Paint paint1 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer2 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer2.clearSeriesStrokes(true);
        java.awt.Stroke stroke6 = xYBarRenderer2.lookupSeriesOutlineStroke(100);
        xYBarRenderer2.setShadowXOffset((double) 100.0f);
        java.awt.Stroke stroke9 = xYBarRenderer2.getBaseOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.05d, paint1, stroke9);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) stroke9);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo12 = null;
        seriesChangeEvent11.setSummary(seriesChangeInfo12);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo14 = null;
        seriesChangeEvent11.setSummary(seriesChangeInfo14);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        int int2 = combinedDomainXYPlot0.getDomainAxisIndex(valueAxis1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = combinedDomainXYPlot0.getRangeAxis();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = categoryPlot8.getDomainAxisEdge();
        java.awt.Paint paint10 = categoryPlot8.getOutlinePaint();
        java.awt.Paint paint13 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer14 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer14.clearSeriesStrokes(true);
        java.awt.Stroke stroke18 = xYBarRenderer14.lookupSeriesOutlineStroke(100);
        xYBarRenderer14.setShadowXOffset((double) 100.0f);
        java.awt.Stroke stroke21 = xYBarRenderer14.getBaseOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker(0.05d, paint13, stroke21);
        float float23 = valueMarker22.getAlpha();
        org.jfree.chart.util.Layer layer24 = null;
        boolean boolean25 = categoryPlot8.removeRangeMarker(100, (org.jfree.chart.plot.Marker) valueMarker22, layer24);
        org.jfree.chart.text.TextAnchor textAnchor26 = valueMarker22.getLabelTextAnchor();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot27 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        int int29 = combinedDomainXYPlot27.getDomainAxisIndex(valueAxis28);
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        int int31 = combinedDomainXYPlot27.getRangeAxisIndex(valueAxis30);
        java.awt.Paint paint32 = combinedDomainXYPlot27.getDomainZeroBaselinePaint();
        boolean boolean33 = combinedDomainXYPlot27.isDomainZeroBaselineVisible();
        org.jfree.chart.util.Layer layer34 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection35 = combinedDomainXYPlot27.getRangeMarkers(layer34);
        combinedDomainXYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker22, layer34);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent37 = null;
        valueMarker22.notifyListeners(markerChangeEvent37);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType39 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        valueMarker22.setLabelOffsetType(lengthAdjustmentType39);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor41 = valueMarker22.getLabelAnchor();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 1.0f + "'", float23 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(textAnchor26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(layer34);
        org.junit.Assert.assertNull(collection35);
        org.junit.Assert.assertNotNull(lengthAdjustmentType39);
        org.junit.Assert.assertNotNull(rectangleAnchor41);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer0.setBaseLinesVisible(true);
        xYStepRenderer0.setSeriesLinesVisible(0, true);
        xYStepRenderer0.setSeriesVisibleInLegend(1, (java.lang.Boolean) false, false);
        java.awt.Shape shape14 = null;
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis17, categoryItemRenderer18);
        int int20 = categoryPlot19.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation22 = null;
        categoryPlot19.setRangeAxisLocation(100, axisLocation22);
        int int24 = categoryPlot19.getWeight();
        java.awt.Paint paint25 = categoryPlot19.getRangeGridlinePaint();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer26 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer26.clearSeriesStrokes(true);
        java.awt.Stroke stroke30 = xYBarRenderer26.lookupSeriesOutlineStroke(100);
        xYBarRenderer26.setShadowXOffset((double) 100.0f);
        java.awt.Stroke stroke33 = xYBarRenderer26.getBaseOutlineStroke();
        java.awt.Paint paint34 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem35 = new org.jfree.chart.LegendItem("", "TextBlockAnchor.TOP_RIGHT", "{0}: ({1}, {2})", "", shape14, paint25, stroke33, paint34);
        java.awt.Color color36 = java.awt.Color.lightGray;
        legendItem35.setLabelPaint((java.awt.Paint) color36);
        java.awt.Paint paint38 = legendItem35.getLinePaint();
        xYStepRenderer0.setBaseOutlinePaint(paint38);
        java.awt.Shape shape41 = xYStepRenderer0.getSeriesShape(12);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer42 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer42.clearSeriesStrokes(true);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator45 = xYBarRenderer42.getBaseItemLabelGenerator();
        java.awt.Color color46 = java.awt.Color.green;
        xYBarRenderer42.setBasePaint((java.awt.Paint) color46);
        org.jfree.data.time.TimeSeries timeSeries48 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection49 = new org.jfree.data.time.TimeSeriesCollection(timeSeries48);
        org.jfree.data.Range range51 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection49, false);
        java.lang.Object obj52 = timeSeriesCollection49.clone();
        boolean boolean53 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection49);
        org.jfree.data.Range range54 = xYBarRenderer42.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection49);
        org.jfree.data.Range range55 = xYStepRenderer0.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection49);
        timeSeriesCollection49.clearSelection();
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNull(shape41);
        org.junit.Assert.assertNull(xYItemLabelGenerator45);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNull(range51);
        org.junit.Assert.assertNotNull(obj52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertNull(range54);
        org.junit.Assert.assertNull(range55);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle1.setMaximumLinesToDisplay(1);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = categoryPlot8.getDomainAxisEdge();
        textTitle1.setPosition(rectangleEdge9);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment11 = textTitle1.getTextAlignment();
        java.lang.Object obj12 = textTitle1.clone();
        java.lang.Object obj13 = textTitle1.clone();
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertNotNull(horizontalAlignment11);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(obj13);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 7);
        java.lang.String str2 = xYSeries1.getDescription();
        org.jfree.data.xy.XYSeries xYSeries5 = xYSeries1.createCopy((int) 'a', (-1));
        int int6 = xYSeries5.getMaximumItemCount();
        double double7 = xYSeries5.getMinY();
        try {
            xYSeries5.updateByIndex((int) (byte) -1, (java.lang.Number) (-4126));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(xYSeries5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2147483647 + "'", int6 == 2147483647);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot2 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = combinedDomainXYPlot2.getDomainAxisIndex(valueAxis3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = combinedDomainXYPlot2.getRangeAxis();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("WMAP_Plot", font1, (org.jfree.chart.plot.Plot) combinedDomainXYPlot2, true);
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle9.setMaximumLinesToDisplay(1);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, categoryItemRenderer15);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot16.getDomainAxisEdge();
        textTitle9.setPosition(rectangleEdge17);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = textTitle9.getPadding();
        jFreeChart7.removeSubtitle((org.jfree.chart.title.Title) textTitle9);
        org.jfree.chart.title.LegendTitle legendTitle21 = jFreeChart7.getLegend();
        org.jfree.chart.block.BlockContainer blockContainer22 = legendTitle21.getItemContainer();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment23 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment24 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.ColumnArrangement columnArrangement27 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment23, verticalAlignment24, 0.0d, (double) 100);
        blockContainer22.setArrangement((org.jfree.chart.block.Arrangement) columnArrangement27);
        java.util.TimeZone timeZone29 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection30 = new org.jfree.data.time.TimeSeriesCollection(timeZone29);
        org.jfree.data.Range range32 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection30, true);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer34 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement27, (org.jfree.data.general.Dataset) timeSeriesCollection30, (java.lang.Comparable) 2147483647);
        legendItemBlockContainer34.setToolTipText("TextBlockAnchor.TOP_RIGHT");
        java.lang.Object obj37 = legendItemBlockContainer34.clone();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(legendTitle21);
        org.junit.Assert.assertNotNull(blockContainer22);
        org.junit.Assert.assertNotNull(horizontalAlignment23);
        org.junit.Assert.assertNotNull(verticalAlignment24);
        org.junit.Assert.assertNull(range32);
        org.junit.Assert.assertNotNull(obj37);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        categoryPlot4.setDataset(categoryDataset5);
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot4.setDomainCrosshairStroke(stroke7);
        java.lang.String str9 = categoryPlot4.getPlotType();
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = categoryPlot4.getDomainAxisEdge();
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Category Plot" + "'", str9.equals("Category Plot"));
        org.junit.Assert.assertNotNull(rectangleEdge10);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.data.Range range2 = xYStepRenderer0.findDomainBounds(xYDataset1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = null;
        xYStepRenderer0.setBaseToolTipGenerator(xYToolTipGenerator3);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = xYStepRenderer0.getPositiveItemLabelPosition((int) (short) -1, (-458), false);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor9 = itemLabelPosition8.getItemLabelAnchor();
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(itemLabelAnchor9);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer0.setShapesVisible(true);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        try {
            double double3 = defaultXYDataset0.getXValue((-1), (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot2 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = combinedDomainXYPlot2.getDomainAxisIndex(valueAxis3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = combinedDomainXYPlot2.getRangeAxis();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("WMAP_Plot", font1, (org.jfree.chart.plot.Plot) combinedDomainXYPlot2, true);
        boolean boolean8 = jFreeChart7.getAntiAlias();
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        textTitle10.setPadding(rectangleInsets11);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = textTitle10.getMargin();
        jFreeChart7.setPadding(rectangleInsets13);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        java.awt.image.BufferedImage bufferedImage18 = jFreeChart7.createBufferedImage((int) (short) 1, 3, chartRenderingInfo17);
        jFreeChart7.setNotify(true);
        java.awt.Font font23 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.text.TextLine textLine24 = new org.jfree.chart.text.TextLine("ClassContext", font23);
        org.jfree.chart.title.TextTitle textTitle25 = new org.jfree.chart.title.TextTitle("hi!", font23);
        jFreeChart7.removeSubtitle((org.jfree.chart.title.Title) textTitle25);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(bufferedImage18);
        org.junit.Assert.assertNotNull(font23);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 7);
        java.lang.String str2 = xYSeries1.getDescription();
        org.jfree.data.xy.XYSeries xYSeries5 = xYSeries1.createCopy((int) 'a', (-1));
        int int6 = xYSeries5.getMaximumItemCount();
        double double7 = xYSeries5.getMinY();
        java.lang.Comparable comparable8 = xYSeries5.getKey();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(xYSeries5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2147483647 + "'", int6 == 2147483647);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 7 + "'", comparable8.equals(7));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem(0.0d, (double) 1L);
        xYDataItem2.setSelected(false);
        double double5 = xYDataItem2.getXValue();
        java.lang.Object obj6 = xYDataItem2.clone();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 7);
        java.lang.String str2 = xYSeries1.getDescription();
        org.jfree.data.xy.XYSeries xYSeries5 = xYSeries1.createCopy(3, 5);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        xYSeries1.addPropertyChangeListener(propertyChangeListener6);
        xYSeries1.setKey((java.lang.Comparable) "MAJOR");
        org.jfree.data.time.TimeSeries timeSeries10 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection11 = new org.jfree.data.time.TimeSeriesCollection(timeSeries10);
        org.jfree.data.Range range13 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection11, false);
        java.lang.Object obj14 = timeSeriesCollection11.clone();
        xYSeries1.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection11);
        org.jfree.data.Range range17 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection11, false);
        org.jfree.data.Range range19 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection11, true);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(xYSeries5);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNull(range19);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        try {
            categoryPlot4.zoom(0.025d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("TextBlockAnchor.TOP_RIGHT");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        labelBlock1.setContentAlignmentPoint(textBlockAnchor2);
        labelBlock1.setWidth((double) 0.0f);
        labelBlock1.setHeight((double) '#');
        labelBlock1.setToolTipText("WMAP_Plot");
        org.junit.Assert.assertNotNull(textBlockAnchor2);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer0.setBaseLinesVisible(true);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator4 = xYStepRenderer0.getSeriesItemLabelGenerator((int) '#');
        boolean boolean5 = xYStepRenderer0.getAutoPopulateSeriesShape();
        java.awt.Paint paint7 = xYStepRenderer0.lookupSeriesPaint((int) (byte) 10);
        boolean boolean10 = xYStepRenderer0.getItemLineVisible(31, (int) (short) 100);
        org.junit.Assert.assertNull(xYItemLabelGenerator4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation(100, axisLocation7);
        java.lang.String str9 = categoryPlot4.getNoDataMessage();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder10 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot4.setDatasetRenderingOrder(datasetRenderingOrder10);
        boolean boolean12 = categoryPlot4.isOutlineVisible();
        boolean boolean13 = categoryPlot4.isNotify();
        categoryPlot4.setRangeCrosshairLockedOnData(true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(datasetRenderingOrder10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        int int2 = combinedDomainXYPlot0.getDomainAxisIndex(valueAxis1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = combinedDomainXYPlot0.getRangeAxisIndex(valueAxis3);
        java.awt.Paint paint5 = combinedDomainXYPlot0.getDomainZeroBaselinePaint();
        boolean boolean6 = combinedDomainXYPlot0.isDomainZeroBaselineVisible();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder7 = combinedDomainXYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation8 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        combinedDomainXYPlot0.setRangeAxisLocation(axisLocation8, true);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = combinedDomainXYPlot0.getDomainAxisEdge((-4126));
        org.jfree.chart.LegendItemCollection legendItemCollection13 = combinedDomainXYPlot0.getLegendItems();
        java.awt.Font font16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot17 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        int int19 = combinedDomainXYPlot17.getDomainAxisIndex(valueAxis18);
        org.jfree.chart.axis.ValueAxis valueAxis20 = combinedDomainXYPlot17.getRangeAxis();
        org.jfree.chart.JFreeChart jFreeChart22 = new org.jfree.chart.JFreeChart("WMAP_Plot", font16, (org.jfree.chart.plot.Plot) combinedDomainXYPlot17, true);
        boolean boolean23 = jFreeChart22.getAntiAlias();
        org.jfree.chart.title.TextTitle textTitle25 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle25.setMaximumLinesToDisplay(1);
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, categoryItemRenderer31);
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = categoryPlot32.getDomainAxisEdge();
        textTitle25.setPosition(rectangleEdge33);
        textTitle25.setPadding((double) '#', (double) (short) -1, 0.0d, (double) (byte) 10);
        boolean boolean40 = jFreeChart22.equals((java.lang.Object) (byte) 10);
        org.jfree.chart.text.TextBlock textBlock41 = new org.jfree.chart.text.TextBlock();
        java.util.List list42 = textBlock41.getLines();
        jFreeChart22.setSubtitles(list42);
        try {
            combinedDomainXYPlot0.mapDatasetToRangeAxes(1, list42);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Empty list not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(seriesRenderingOrder7);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertNotNull(legendItemCollection13);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNull(valueAxis20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(list42);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.clearSeriesStrokes(true);
        java.awt.Stroke stroke4 = xYBarRenderer0.lookupSeriesOutlineStroke(100);
        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter5 = xYBarRenderer0.getBarPainter();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(xYBarPainter5);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis1.pan((double) (-4126));
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot7 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        int int9 = combinedDomainXYPlot7.getDomainAxisIndex(valueAxis8);
        org.jfree.chart.axis.ValueAxis valueAxis10 = combinedDomainXYPlot7.getRangeAxis();
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("WMAP_Plot", font6, (org.jfree.chart.plot.Plot) combinedDomainXYPlot7, true);
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle14.setMaximumLinesToDisplay(1);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, valueAxis19, categoryItemRenderer20);
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = categoryPlot21.getDomainAxisEdge();
        textTitle14.setPosition(rectangleEdge22);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = textTitle14.getPadding();
        jFreeChart12.removeSubtitle((org.jfree.chart.title.Title) textTitle14);
        org.jfree.chart.title.LegendTitle legendTitle26 = jFreeChart12.getLegend();
        org.jfree.chart.block.BlockContainer blockContainer27 = legendTitle26.getItemContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = legendTitle26.getPadding();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor29 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        legendTitle26.setLegendItemGraphicAnchor(rectangleAnchor29);
        java.awt.geom.Rectangle2D rectangle2D31 = legendTitle26.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double33 = periodAxis1.valueToJava2D((double) 15, rectangle2D31, rectangleEdge32);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(legendTitle26);
        org.junit.Assert.assertNotNull(blockContainer27);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(rectangleAnchor29);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
    }
}

