import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addDays((-1), serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = null;
        try {
            xYStepRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.END;
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((int) '4');
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        int int0 = org.jfree.data.time.SerialDate.LAST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        java.awt.Stroke stroke0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeStroke(stroke0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            double double1 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        java.lang.Class class1 = null;
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("hi!", class1);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("ERROR : Relative To String", graphics2D1, (float) '#', (float) 0, textAnchor4, (double) (-1), (float) 1L, 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        java.net.URL uRL0 = null;
        java.net.URLClassLoader uRLClassLoader1 = null;
        try {
            org.jfree.chart.util.ResourceBundleWrapper.removeCodeBase(uRL0, uRLClassLoader1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("hi!", graphics2D1, 0.0f, 100.0f, textAnchor4, (double) (byte) 100, (float) 0, 100.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.Marker marker5 = null;
        try {
            categoryPlot4.addRangeMarker(marker5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D2 = rectangleInsets0.createInsetRectangle(rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        java.awt.Paint paint0 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        java.lang.Class class0 = null;
        java.util.Date date1 = null;
        java.util.TimeZone timeZone2 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date1, timeZone2);
        org.junit.Assert.assertNull(regularTimePeriod3);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.jfree.data.function.Function2D function2D0 = null;
        try {
            org.jfree.data.xy.XYDataset xYDataset5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, (double) '#', (double) 3, 2, (java.lang.Comparable) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        java.awt.geom.GeneralPath generalPath0 = null;
        java.awt.geom.GeneralPath generalPath1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(generalPath0, generalPath1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("TextBlockAnchor.TOP_RIGHT");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        org.jfree.chart.JFreeChart jFreeChart2 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = null;
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent4 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) waferMapDataset0, jFreeChart2, chartChangeEventType3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeStroke(stroke0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        java.lang.String str0 = org.jfree.chart.labels.StandardXYToolTipGenerator.DEFAULT_TOOL_TIP_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}: ({1}, {2})" + "'", str0.equals("{0}: ({1}, {2})"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation(100, axisLocation7);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        org.jfree.chart.plot.CategoryCrosshairState categoryCrosshairState13 = null;
        try {
            boolean boolean14 = categoryPlot4.render(graphics2D9, rectangle2D10, (int) (byte) -1, plotRenderingInfo12, categoryCrosshairState13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'index'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("hi!", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        int int0 = org.jfree.data.time.Year.MAXIMUM_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        java.awt.Shape shape0 = null;
        org.jfree.chart.axis.Axis axis1 = null;
        try {
            org.jfree.chart.entity.AxisEntity axisEntity2 = new org.jfree.chart.entity.AxisEntity(shape0, axis1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        java.lang.String str0 = org.jfree.chart.urls.StandardXYURLGenerator.DEFAULT_SERIES_PARAMETER;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "series" + "'", str0.equals("series"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.CLASS_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ClassContext" + "'", str0.equals("ClassContext"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        try {
            org.jfree.chart.util.Size2D size2D3 = textTitle1.arrange(graphics2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE8;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer0.setBaseLinesVisible(true);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator4 = xYStepRenderer0.getSeriesItemLabelGenerator((int) '#');
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator8 = xYStepRenderer0.getItemLabelGenerator((int) (byte) 100, (-1), false);
        java.awt.Shape shape9 = null;
        try {
            xYStepRenderer0.setBaseShape(shape9, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'shape' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYItemLabelGenerator4);
        org.junit.Assert.assertNull(xYItemLabelGenerator8);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.MINUTE_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 60000L + "'", long0 == 60000L);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Shape shape1 = org.jfree.chart.util.SerialUtilities.readShape(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.Point2D point2D4 = null;
        org.jfree.chart.plot.PlotState plotState5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        try {
            waferMapPlot1.draw(graphics2D2, rectangle2D3, point2D4, plotState5, plotRenderingInfo6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) (short) 10, (double) (short) 10, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.MIDDLE;
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        java.util.Locale locale0 = null;
        try {
            java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getNumberInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.clearSeriesStrokes(true);
        java.awt.Stroke stroke4 = xYBarRenderer0.lookupSeriesOutlineStroke(100);
        xYBarRenderer0.setShadowXOffset((double) 100.0f);
        boolean boolean7 = xYBarRenderer0.getBaseSeriesVisible();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        java.awt.geom.Line2D line2D0 = null;
        try {
            java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(line2D0, (float) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer0.setBaseLinesVisible(true);
        double double3 = xYStepRenderer0.getStepPoint();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter0 = null;
        try {
            org.jfree.chart.renderer.xy.XYBarRenderer.setDefaultBarPainter(xYBarPainter0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'painter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        java.lang.String str0 = org.jfree.chart.ui.Licences.GPL;
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (short) -1, 0.0d, (double) (short) -1, (double) (byte) 10);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType6 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType7 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D8 = rectangleInsets4.createAdjustedRectangle(rectangle2D5, lengthAdjustmentType6, lengthAdjustmentType7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.data.Range range2 = xYStepRenderer0.findDomainBounds(xYDataset1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = null;
        xYStepRenderer0.setBaseToolTipGenerator(xYToolTipGenerator3);
        boolean boolean5 = xYStepRenderer0.getBaseShapesVisible();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator6 = null;
        xYStepRenderer0.setBaseToolTipGenerator(xYToolTipGenerator6, true);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState11 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo10);
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        try {
            xYStepRenderer0.drawItem(graphics2D9, xYItemRendererState11, rectangle2D12, xYPlot13, valueAxis14, valueAxis15, xYDataset16, 7, (int) (short) 0, true, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 5");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        java.awt.Paint paint0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePaint(paint0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        java.util.Date date0 = null;
        java.util.Date date1 = null;
        try {
            org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange(date0, date1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.clearSeriesStrokes(true);
        java.awt.Stroke stroke4 = xYBarRenderer0.lookupSeriesOutlineStroke(100);
        xYBarRenderer0.setShadowXOffset((double) 100.0f);
        java.awt.Stroke stroke7 = xYBarRenderer0.getBaseOutlineStroke();
        java.awt.Shape shape8 = null;
        try {
            xYBarRenderer0.setLegendBar(shape8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'bar' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.data.Range range2 = xYStepRenderer0.findDomainBounds(xYDataset1);
        java.awt.Shape shape4 = null;
        xYStepRenderer0.setSeriesShape((int) ' ', shape4, false);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState9 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo8);
        int int10 = xYItemRendererState9.getFirstItemIndex();
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot12 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        try {
            xYStepRenderer0.drawItem(graphics2D7, xYItemRendererState9, rectangle2D11, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot12, valueAxis13, valueAxis14, xYDataset15, 0, 10, true, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor0 = org.jfree.data.time.TimePeriodAnchor.MIDDLE;
        org.junit.Assert.assertNotNull(timePeriodAnchor0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.BAR_OUTLINE_WIDTH_THRESHOLD;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.0d + "'", double0 == 3.0d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        java.awt.geom.Line2D line2D0 = null;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            boolean boolean2 = org.jfree.chart.util.ShapeUtilities.clipLine(line2D0, rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        double double1 = blockParams0.getTranslateY();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) '#', (-1), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        java.awt.Shape shape0 = null;
        try {
            java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape0, (double) 0, (double) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'shape' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        java.lang.String[] strArray0 = org.jfree.data.time.SerialDate.getMonths();
        org.junit.Assert.assertNotNull(strArray0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(10, (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.chart.renderer.category.BarPainter barPainter0 = org.jfree.chart.renderer.category.BarRenderer.getDefaultBarPainter();
        org.junit.Assert.assertNotNull(barPainter0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("{0}: ({1}, {2})", "hi!");
        java.lang.String str3 = contributor2.getEmail();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        java.awt.Shape shape0 = null;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        try {
            org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, (int) 'a', (int) (short) 1, (java.lang.Comparable) "", "", "{0}: ({1}, {2})");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        blockParams0.setTranslateY(1.0d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        int int0 = org.jfree.data.time.SerialDate.FOURTH_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.data.Range range2 = xYStepRenderer0.findDomainBounds(xYDataset1);
        java.awt.Shape shape4 = null;
        xYStepRenderer0.setSeriesShape((int) ' ', shape4, false);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator7 = xYStepRenderer0.getLegendItemURLGenerator();
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator7);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation(100, axisLocation7);
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = null;
        org.jfree.chart.util.Layer layer11 = null;
        try {
            categoryPlot4.addDomainMarker(0, categoryMarker10, layer11, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        java.awt.Paint paint0 = null;
        java.awt.Paint paint2 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer3.clearSeriesStrokes(true);
        java.awt.Stroke stroke7 = xYBarRenderer3.lookupSeriesOutlineStroke(100);
        xYBarRenderer3.setShadowXOffset((double) 100.0f);
        java.awt.Stroke stroke10 = xYBarRenderer3.getBaseOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker(0.05d, paint2, stroke10);
        boolean boolean12 = org.jfree.chart.util.PaintUtilities.equal(paint0, paint2);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation(100, axisLocation7);
        int int9 = categoryPlot4.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = categoryPlot4.getDomainAxisEdge();
        org.jfree.chart.util.SortOrder sortOrder11 = null;
        try {
            categoryPlot4.setRowRenderingOrder(sortOrder11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge10);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        java.awt.Paint paint2 = waferMapPlot1.getOutlinePaint();
        java.lang.String str3 = waferMapPlot1.getPlotType();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "WMAP_Plot" + "'", str3.equals("WMAP_Plot"));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("WMAP_Plot", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_TICK_UNIT_SELECTION;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit((double) '#', numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle1.setMaximumLinesToDisplay(1);
        double double4 = textTitle1.getHeight();
        textTitle1.visible = false;
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = textTitle1.getMargin();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment8 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        textTitle1.setHorizontalAlignment(horizontalAlignment8);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(horizontalAlignment8);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer0.setBaseLinesVisible(true);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator4 = xYStepRenderer0.getSeriesItemLabelGenerator((int) '#');
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator6 = null;
        xYStepRenderer0.setSeriesItemLabelGenerator((int) 'a', xYItemLabelGenerator6, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = null;
        try {
            xYStepRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition9, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYItemLabelGenerator4);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        textTitle1.setPadding(rectangleInsets2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = textTitle1.getMargin();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.lang.Object obj8 = textTitle1.draw(graphics2D5, rectangle2D6, (java.lang.Object) 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNull(obj8);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("WMAP_Plot", "hi!");
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        java.awt.Polygon polygon0 = null;
        java.awt.Polygon polygon1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(polygon0, polygon1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        java.awt.Color color0 = java.awt.Color.lightGray;
        float[] floatArray3 = new float[] { 10.0f, 1L };
        try {
            float[] floatArray4 = color0.getColorComponents(floatArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray3);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        int int2 = combinedDomainXYPlot0.getDomainAxisIndex(valueAxis1);
        combinedDomainXYPlot0.setRangeCrosshairLockedOnData(false);
        java.awt.geom.Point2D point2D5 = null;
        try {
            combinedDomainXYPlot0.setQuadrantOrigin(point2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'origin' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation(100, axisLocation7);
        int int9 = categoryPlot4.getWeight();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        try {
            categoryPlot4.setRenderer((int) (byte) -1, categoryItemRenderer11, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = null;
        java.util.TimeZone timeZone3 = null;
        java.util.Locale locale4 = null;
        try {
            org.jfree.chart.axis.PeriodAxis periodAxis5 = new org.jfree.chart.axis.PeriodAxis("WMAP_Plot", regularTimePeriod1, regularTimePeriod2, timeZone3, locale4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'timeZone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.chart.plot.Plot plot1 = null;
        try {
            org.jfree.chart.JFreeChart jFreeChart2 = new org.jfree.chart.JFreeChart("hi!", plot1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'plot' argument.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        int int2 = combinedDomainXYPlot0.getDomainAxisIndex(valueAxis1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = combinedDomainXYPlot0.getRangeAxisIndex(valueAxis3);
        java.awt.Paint paint5 = combinedDomainXYPlot0.getDomainZeroBaselinePaint();
        java.awt.Stroke stroke6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        combinedDomainXYPlot0.setRangeZeroBaselineStroke(stroke6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = combinedDomainXYPlot0.getRendererForDataset(xYDataset8);
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        java.awt.geom.Point2D point2D12 = null;
        org.jfree.chart.plot.PlotState plotState13 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        try {
            combinedDomainXYPlot0.draw(graphics2D10, rectangle2D11, point2D12, plotState13, plotRenderingInfo14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(xYItemRenderer9);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_INVERTED;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        java.util.Locale locale0 = null;
        try {
            java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getIntegerInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Stroke stroke2 = null;
        xYBarRenderer0.setSeriesStroke(3, stroke2, false);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation5 = null;
        try {
            xYBarRenderer0.addAnnotation(xYAnnotation5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.08d + "'", double0 == 0.08d);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        java.util.Locale locale2 = null;
        try {
            org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date0, timeZone1, locale2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.data.function.Function2D function2D0 = null;
        try {
            org.jfree.data.xy.XYSeries xYSeries5 = org.jfree.data.general.DatasetUtilities.sampleFunction2DToSeries(function2D0, (double) 2, (double) 1L, 10, (java.lang.Comparable) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.data.Range range2 = xYStepRenderer0.findDomainBounds(xYDataset1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = null;
        xYStepRenderer0.setBaseToolTipGenerator(xYToolTipGenerator3);
        boolean boolean5 = xYStepRenderer0.getBaseCreateEntities();
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_INSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0 == 0.0f);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        int int0 = org.jfree.data.time.SerialDate.THIRD_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        textTitle1.setPadding(rectangleInsets2);
        java.lang.String str4 = textTitle1.getID();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        boolean boolean2 = waferMapPlot1.isOutlineVisible();
        org.jfree.data.general.WaferMapDataset waferMapDataset3 = waferMapPlot1.getDataset();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(waferMapDataset3);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("series", "", "TextBlockAnchor.TOP_RIGHT", "WMAP_Plot");
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        int int1 = color0.getAlpha();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer0.setBaseLinesVisible(true);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator4 = xYStepRenderer0.getSeriesItemLabelGenerator((int) '#');
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator6 = null;
        xYStepRenderer0.setSeriesItemLabelGenerator((int) 'a', xYItemLabelGenerator6, true);
        boolean boolean11 = xYStepRenderer0.getItemLineVisible((int) (byte) -1, 0);
        java.awt.Font font13 = xYStepRenderer0.getSeriesItemLabelFont((int) (short) 10);
        org.junit.Assert.assertNull(xYItemLabelGenerator4);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(font13);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        java.awt.Shape shape4 = null;
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, valueAxis7, categoryItemRenderer8);
        int int10 = categoryPlot9.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation12 = null;
        categoryPlot9.setRangeAxisLocation(100, axisLocation12);
        int int14 = categoryPlot9.getWeight();
        java.awt.Paint paint15 = categoryPlot9.getRangeGridlinePaint();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer16 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer16.clearSeriesStrokes(true);
        java.awt.Stroke stroke20 = xYBarRenderer16.lookupSeriesOutlineStroke(100);
        xYBarRenderer16.setShadowXOffset((double) 100.0f);
        java.awt.Stroke stroke23 = xYBarRenderer16.getBaseOutlineStroke();
        java.awt.Paint paint24 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("", "TextBlockAnchor.TOP_RIGHT", "{0}: ({1}, {2})", "", shape4, paint15, stroke23, paint24);
        java.awt.Color color26 = java.awt.Color.lightGray;
        legendItem25.setLabelPaint((java.awt.Paint) color26);
        java.awt.Shape shape28 = legendItem25.getLine();
        java.lang.String str29 = legendItem25.getToolTipText();
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "{0}: ({1}, {2})" + "'", str29.equals("{0}: ({1}, {2})"));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        try {
            boolean boolean4 = timeSeriesCollection1.isSelected(10, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (10).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        java.awt.Font font1 = null;
        java.awt.Shape shape6 = null;
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis9, categoryItemRenderer10);
        int int12 = categoryPlot11.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation14 = null;
        categoryPlot11.setRangeAxisLocation(100, axisLocation14);
        int int16 = categoryPlot11.getWeight();
        java.awt.Paint paint17 = categoryPlot11.getRangeGridlinePaint();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer18 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer18.clearSeriesStrokes(true);
        java.awt.Stroke stroke22 = xYBarRenderer18.lookupSeriesOutlineStroke(100);
        xYBarRenderer18.setShadowXOffset((double) 100.0f);
        java.awt.Stroke stroke25 = xYBarRenderer18.getBaseOutlineStroke();
        java.awt.Paint paint26 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem27 = new org.jfree.chart.LegendItem("", "TextBlockAnchor.TOP_RIGHT", "{0}: ({1}, {2})", "", shape6, paint17, stroke25, paint26);
        java.awt.Color color28 = java.awt.Color.lightGray;
        legendItem27.setLabelPaint((java.awt.Paint) color28);
        try {
            org.jfree.chart.text.TextLine textLine30 = new org.jfree.chart.text.TextLine("TextBlockAnchor.TOP_RIGHT", font1, (java.awt.Paint) color28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(color28);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Stroke stroke1 = org.jfree.chart.util.SerialUtilities.readStroke(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((int) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date3 = spreadsheetDate2.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date6 = spreadsheetDate5.toDate();
        boolean boolean7 = spreadsheetDate2.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        spreadsheetDate2.setDescription("hi!");
        try {
            org.jfree.data.general.PieDataset pieDataset11 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) spreadsheetDate2, (double) 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "", "ERROR : Relative To String", "hi!", "ERROR : Relative To String");
        basicProjectInfo5.addOptionalLibrary("TextBlockAnchor.TOP_RIGHT");
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        java.awt.Color color0 = java.awt.Color.gray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape5 = null;
        java.awt.Paint paint7 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer9 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.data.Range range11 = xYStepRenderer9.findDomainBounds(xYDataset10);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator12 = null;
        xYStepRenderer9.setBaseToolTipGenerator(xYToolTipGenerator12);
        boolean boolean14 = xYStepRenderer9.getBaseShapesVisible();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator15 = null;
        xYStepRenderer9.setBaseToolTipGenerator(xYToolTipGenerator15, true);
        java.awt.Color color19 = java.awt.Color.lightGray;
        xYStepRenderer9.setSeriesFillPaint((int) '#', (java.awt.Paint) color19);
        java.awt.Stroke stroke21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState24 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo23);
        java.awt.geom.Line2D line2D25 = xYItemRendererState24.workingLine;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer26 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.data.Range range28 = xYStepRenderer26.findDomainBounds(xYDataset27);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator29 = null;
        xYStepRenderer26.setBaseToolTipGenerator(xYToolTipGenerator29);
        boolean boolean31 = xYStepRenderer26.getBaseShapesVisible();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator32 = null;
        xYStepRenderer26.setBaseToolTipGenerator(xYToolTipGenerator32, true);
        java.awt.Stroke stroke36 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        xYStepRenderer26.setSeriesOutlineStroke((int) (short) 1, stroke36);
        java.awt.Shape shape42 = null;
        org.jfree.data.category.CategoryDataset categoryDataset43 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = null;
        org.jfree.chart.axis.ValueAxis valueAxis45 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer46 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot47 = new org.jfree.chart.plot.CategoryPlot(categoryDataset43, categoryAxis44, valueAxis45, categoryItemRenderer46);
        int int48 = categoryPlot47.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation50 = null;
        categoryPlot47.setRangeAxisLocation(100, axisLocation50);
        int int52 = categoryPlot47.getWeight();
        java.awt.Paint paint53 = categoryPlot47.getRangeGridlinePaint();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer54 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer54.clearSeriesStrokes(true);
        java.awt.Stroke stroke58 = xYBarRenderer54.lookupSeriesOutlineStroke(100);
        xYBarRenderer54.setShadowXOffset((double) 100.0f);
        java.awt.Stroke stroke61 = xYBarRenderer54.getBaseOutlineStroke();
        java.awt.Paint paint62 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem63 = new org.jfree.chart.LegendItem("", "TextBlockAnchor.TOP_RIGHT", "{0}: ({1}, {2})", "", shape42, paint53, stroke61, paint62);
        java.awt.Color color64 = java.awt.Color.lightGray;
        legendItem63.setLabelPaint((java.awt.Paint) color64);
        try {
            org.jfree.chart.LegendItem legendItem66 = new org.jfree.chart.LegendItem(attributedString0, "", "", "", false, shape5, true, paint7, true, (java.awt.Paint) color19, stroke21, true, (java.awt.Shape) line2D25, stroke36, (java.awt.Paint) color64);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(line2D25);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertNotNull(paint53);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertNotNull(stroke61);
        org.junit.Assert.assertNotNull(paint62);
        org.junit.Assert.assertNotNull(color64);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.junit.Assert.assertNotNull(date0);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.data.Range range2 = xYStepRenderer0.findDomainBounds(xYDataset1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = null;
        xYStepRenderer0.setBaseToolTipGenerator(xYToolTipGenerator3);
        boolean boolean5 = xYStepRenderer0.getBaseShapesVisible();
        double double6 = xYStepRenderer0.getStepPoint();
        org.jfree.chart.plot.XYPlot xYPlot7 = xYStepRenderer0.getPlot();
        java.awt.Shape shape8 = null;
        try {
            xYStepRenderer0.setBaseShape(shape8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'shape' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNull(xYPlot7);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.setRangeCrosshairValue(0.0d);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation7 = null;
        try {
            boolean boolean8 = categoryPlot4.removeAnnotation(categoryAnnotation7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_INCLUDES_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        java.awt.Color color0 = java.awt.Color.green;
        java.lang.String str1 = color0.toString();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java.awt.Color[r=0,g=255,b=0]" + "'", str1.equals("java.awt.Color[r=0,g=255,b=0]"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        java.awt.Color color1 = java.awt.Color.getColor("ClassContext");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        int int2 = combinedDomainXYPlot0.getDomainAxisIndex(valueAxis1);
        combinedDomainXYPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.axis.AxisSpace axisSpace5 = null;
        combinedDomainXYPlot0.setFixedDomainAxisSpace(axisSpace5);
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = null;
        try {
            combinedDomainXYPlot0.setOrientation(plotOrientation7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation(100, axisLocation7);
        java.lang.String str9 = categoryPlot4.getNoDataMessage();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder10 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot4.setDatasetRenderingOrder(datasetRenderingOrder10);
        org.jfree.chart.axis.AxisLocation axisLocation12 = null;
        try {
            categoryPlot4.setDomainAxisLocation(axisLocation12, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(datasetRenderingOrder10);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        java.lang.Class class1 = null;
        java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", class1);
        org.junit.Assert.assertNotNull(inputStream2);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer0.setBaseLinesVisible(true);
        xYStepRenderer0.setSeriesLinesVisible(0, true);
        xYStepRenderer0.setSeriesVisibleInLegend(1, (java.lang.Boolean) false, false);
        try {
            xYStepRenderer0.setSeriesShapesFilled((int) (short) -1, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset0, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.data.Range range2 = xYStepRenderer0.findDomainBounds(xYDataset1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = null;
        xYStepRenderer0.setBaseToolTipGenerator(xYToolTipGenerator3);
        org.jfree.data.general.WaferMapDataset waferMapDataset6 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot7 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset6);
        java.awt.Paint paint8 = waferMapPlot7.getOutlinePaint();
        xYStepRenderer0.setSeriesFillPaint(100, paint8, false);
        boolean boolean12 = xYStepRenderer0.isSeriesItemLabelsVisible(10);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator14 = null;
        xYStepRenderer0.setSeriesItemLabelGenerator(255, xYItemLabelGenerator14);
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date5 = spreadsheetDate4.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date8 = spreadsheetDate7.toDate();
        boolean boolean9 = spreadsheetDate4.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate7);
        boolean boolean10 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate7);
        try {
            org.jfree.data.time.SerialDate serialDate12 = spreadsheetDate1.getNearestDayOfWeek((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        java.awt.Image image0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE;
        org.junit.Assert.assertNull(image0);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE11;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter0 = new org.jfree.chart.renderer.category.GradientBarPainter();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = null;
        java.awt.geom.RectangularShape rectangularShape6 = null;
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis9, categoryItemRenderer10);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = categoryPlot11.getDomainAxisEdge();
        try {
            gradientBarPainter0.paintBarShadow(graphics2D1, barRenderer2, (int) (short) -1, (int) (byte) 1, false, rectangularShape6, rectangleEdge12, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge12);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        java.lang.String str0 = org.jfree.chart.labels.StandardPieToolTipGenerator.DEFAULT_TOOLTIP_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}: ({1}, {2})" + "'", str0.equals("{0}: ({1}, {2})"));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation(100, axisLocation7);
        int int9 = categoryPlot4.getWeight();
        java.awt.Paint paint10 = categoryPlot4.getRangeGridlinePaint();
        org.jfree.chart.text.TextBlock textBlock12 = new org.jfree.chart.text.TextBlock();
        java.util.List list13 = textBlock12.getLines();
        try {
            categoryPlot4.mapDatasetToDomainAxes(4, list13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Empty list not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(list13);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        int int2 = combinedDomainXYPlot0.getDomainAxisIndex(valueAxis1);
        combinedDomainXYPlot0.setRangeCrosshairLockedOnData(false);
        java.awt.Stroke stroke5 = combinedDomainXYPlot0.getOutlineStroke();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        java.lang.Object obj0 = null;
        try {
            org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = new org.jfree.chart.event.RendererChangeEvent(obj0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        java.awt.Font font0 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj1 = objectList0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            boolean boolean2 = org.jfree.chart.util.ShapeUtilities.contains(rectangle2D0, rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(8);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-458) + "'", int1 == (-458));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        int int0 = org.jfree.chart.renderer.xy.XYAreaRenderer.SHAPES_AND_LINES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        java.awt.Font font1 = null;
        java.awt.Paint paint2 = null;
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        int int8 = categoryPlot7.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation10 = null;
        categoryPlot7.setRangeAxisLocation(100, axisLocation10);
        int int12 = categoryPlot7.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = categoryPlot7.getDomainAxisEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge13);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer15 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.data.Range range17 = xYStepRenderer15.findDomainBounds(xYDataset16);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator18 = null;
        xYStepRenderer15.setBaseToolTipGenerator(xYToolTipGenerator18);
        boolean boolean20 = xYStepRenderer15.getBaseShapesVisible();
        double double21 = xYStepRenderer15.getStepPoint();
        boolean boolean22 = rectangleEdge13.equals((java.lang.Object) xYStepRenderer15);
        org.jfree.chart.title.TextTitle textTitle24 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle24.setMaximumLinesToDisplay(1);
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = null;
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis28, valueAxis29, categoryItemRenderer30);
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = categoryPlot31.getDomainAxisEdge();
        textTitle24.setPosition(rectangleEdge32);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment34 = textTitle24.getTextAlignment();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment35 = textTitle24.getTextAlignment();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment36 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment37 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.ColumnArrangement columnArrangement40 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment36, verticalAlignment37, 0.0d, (double) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double42 = rectangleInsets41.getTop();
        try {
            org.jfree.chart.title.TextTitle textTitle43 = new org.jfree.chart.title.TextTitle("ClassContext", font1, paint2, rectangleEdge13, horizontalAlignment35, verticalAlignment37, rectangleInsets41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'font' argument.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertNotNull(horizontalAlignment34);
        org.junit.Assert.assertNotNull(horizontalAlignment35);
        org.junit.Assert.assertNotNull(horizontalAlignment36);
        org.junit.Assert.assertNotNull(verticalAlignment37);
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 3.0d + "'", double42 == 3.0d);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.clearSeriesStrokes(true);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator3 = xYBarRenderer0.getBaseItemLabelGenerator();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation4 = null;
        try {
            xYBarRenderer0.addAnnotation(xYAnnotation4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYItemLabelGenerator3);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.DAY_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 86400000L + "'", long0 == 86400000L);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer0.setBaseLinesVisible(true);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator4 = xYStepRenderer0.getSeriesItemLabelGenerator((int) '#');
        xYStepRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        boolean boolean9 = xYStepRenderer0.getItemShapeVisible((int) '4', 4);
        org.junit.Assert.assertNull(xYItemLabelGenerator4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.data.Range range2 = xYStepRenderer0.findDomainBounds(xYDataset1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = null;
        xYStepRenderer0.setBaseToolTipGenerator(xYToolTipGenerator3);
        boolean boolean5 = xYStepRenderer0.getBaseShapesVisible();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator6 = null;
        xYStepRenderer0.setBaseToolTipGenerator(xYToolTipGenerator6, true);
        java.awt.Color color10 = java.awt.Color.lightGray;
        xYStepRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color10);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot13 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        int int15 = combinedDomainXYPlot13.getDomainAxisIndex(valueAxis14);
        org.jfree.chart.axis.AxisLocation axisLocation17 = null;
        combinedDomainXYPlot13.setDomainAxisLocation((int) (byte) 1, axisLocation17);
        org.jfree.chart.LegendItemCollection legendItemCollection19 = null;
        combinedDomainXYPlot13.setFixedLegendItems(legendItemCollection19);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        try {
            xYStepRenderer0.fillRangeGridBand(graphics2D12, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot13, valueAxis21, rectangle2D22, (double) 255, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        boolean boolean0 = org.jfree.chart.renderer.category.BarRenderer.getDefaultShadowsVisible();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        java.util.Locale locale0 = null;
        try {
            java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        java.lang.Class class0 = null;
        try {
            boolean boolean1 = org.jfree.chart.util.SerialUtilities.isSerializable(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        int int0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALIGNMENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean2 = textBlock0.equals((java.lang.Object) rectangleInsets1);
        org.jfree.chart.text.TextLine textLine3 = textBlock0.getLastLine();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(textLine3);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot2 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = combinedDomainXYPlot2.getDomainAxisIndex(valueAxis3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = combinedDomainXYPlot2.getRangeAxis();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("WMAP_Plot", font1, (org.jfree.chart.plot.Plot) combinedDomainXYPlot2, true);
        org.jfree.data.xy.XYDataset xYDataset8 = combinedDomainXYPlot2.getDataset();
        org.jfree.chart.plot.PlotOrientation plotOrientation9 = null;
        try {
            combinedDomainXYPlot2.setOrientation(plotOrientation9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNull(xYDataset8);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name , locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState1 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo0);
        int int2 = xYItemRendererState1.getFirstItemIndex();
        java.awt.Font font4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot5 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        int int7 = combinedDomainXYPlot5.getDomainAxisIndex(valueAxis6);
        org.jfree.chart.axis.ValueAxis valueAxis8 = combinedDomainXYPlot5.getRangeAxis();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("WMAP_Plot", font4, (org.jfree.chart.plot.Plot) combinedDomainXYPlot5, true);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent11 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) int2, jFreeChart10);
        org.jfree.chart.event.ChartChangeListener chartChangeListener12 = null;
        try {
            jFreeChart10.addChangeListener(chartChangeListener12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNull(valueAxis8);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.MINUTE;
        org.junit.Assert.assertNotNull(dateTickUnitType0);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=0,g=255,b=0]");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = org.jfree.chart.util.RectangleEdge.RIGHT;
        try {
            double double5 = numberAxis1.lengthToJava2D((double) (byte) -1, rectangle2D3, rectangleEdge4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge4);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        boolean boolean1 = combinedDomainXYPlot0.isRangeGridlinesVisible();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        java.lang.String str1 = textBlockAnchor0.toString();
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextBlockAnchor.BOTTOM_RIGHT" + "'", str1.equals("TextBlockAnchor.BOTTOM_RIGHT"));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.chart.ui.Licences licences0 = new org.jfree.chart.ui.Licences();
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        java.awt.Shape shape4 = null;
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, valueAxis7, categoryItemRenderer8);
        int int10 = categoryPlot9.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation12 = null;
        categoryPlot9.setRangeAxisLocation(100, axisLocation12);
        int int14 = categoryPlot9.getWeight();
        java.awt.Paint paint15 = categoryPlot9.getRangeGridlinePaint();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer16 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer16.clearSeriesStrokes(true);
        java.awt.Stroke stroke20 = xYBarRenderer16.lookupSeriesOutlineStroke(100);
        xYBarRenderer16.setShadowXOffset((double) 100.0f);
        java.awt.Stroke stroke23 = xYBarRenderer16.getBaseOutlineStroke();
        java.awt.Paint paint24 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("", "TextBlockAnchor.TOP_RIGHT", "{0}: ({1}, {2})", "", shape4, paint15, stroke23, paint24);
        java.lang.Comparable comparable26 = legendItem25.getSeriesKey();
        legendItem25.setToolTipText("ERROR : Relative To String");
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNull(comparable26);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        int int2 = combinedDomainXYPlot0.getDomainAxisIndex(valueAxis1);
        combinedDomainXYPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.axis.AxisSpace axisSpace5 = null;
        combinedDomainXYPlot0.setFixedDomainAxisSpace(axisSpace5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        java.awt.geom.Point2D point2D9 = null;
        org.jfree.chart.plot.PlotState plotState10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        try {
            combinedDomainXYPlot0.draw(graphics2D7, rectangle2D8, point2D9, plotState10, plotRenderingInfo11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        java.awt.Shape shape4 = null;
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, valueAxis7, categoryItemRenderer8);
        int int10 = categoryPlot9.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation12 = null;
        categoryPlot9.setRangeAxisLocation(100, axisLocation12);
        int int14 = categoryPlot9.getWeight();
        java.awt.Paint paint15 = categoryPlot9.getRangeGridlinePaint();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer16 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer16.clearSeriesStrokes(true);
        java.awt.Stroke stroke20 = xYBarRenderer16.lookupSeriesOutlineStroke(100);
        xYBarRenderer16.setShadowXOffset((double) 100.0f);
        java.awt.Stroke stroke23 = xYBarRenderer16.getBaseOutlineStroke();
        java.awt.Paint paint24 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("", "TextBlockAnchor.TOP_RIGHT", "{0}: ({1}, {2})", "", shape4, paint15, stroke23, paint24);
        java.awt.Color color26 = java.awt.Color.lightGray;
        legendItem25.setLabelPaint((java.awt.Paint) color26);
        java.awt.Shape shape28 = legendItem25.getLine();
        java.io.ObjectOutputStream objectOutputStream29 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeShape(shape28, objectOutputStream29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(shape28);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.lang.Object obj1 = standardPieSectionLabelGenerator0.clone();
        java.text.NumberFormat numberFormat2 = standardPieSectionLabelGenerator0.getNumberFormat();
        java.lang.String str3 = standardPieSectionLabelGenerator0.getLabelFormat();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(numberFormat2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "{0}" + "'", str3.equals("{0}"));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 7);
        try {
            xYSeries1.delete(0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: toIndex = 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0);
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        int int7 = categoryPlot6.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation9 = null;
        categoryPlot6.setRangeAxisLocation(100, axisLocation9);
        timeSeriesCollection1.removeChangeListener((org.jfree.data.general.DatasetChangeListener) categoryPlot6);
        timeSeriesCollection1.validateObject();
        try {
            java.lang.Number number15 = timeSeriesCollection1.getX((-458), (-458));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -458");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE4;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle1.setMaximumLinesToDisplay(1);
        double double4 = textTitle1.getHeight();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            textTitle1.setBounds(rectangle2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'bounds' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        categoryPlot4.setDataset(categoryDataset5);
        boolean boolean7 = categoryPlot4.isSubplot();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = categoryPlot4.getAxisOffset();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(rectangleInsets8);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("series", "", "java.awt.Color[r=0,g=255,b=0]", "{0}: ({1}, {2})", "");
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) (short) -1, (float) 1L);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape6, rectangleAnchor7, (double) (short) 0, (double) 1);
        java.awt.Paint paint11 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer12 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer12.clearSeriesStrokes(true);
        java.awt.Stroke stroke16 = xYBarRenderer12.lookupSeriesOutlineStroke(100);
        xYBarRenderer12.setShadowXOffset((double) 100.0f);
        java.awt.Stroke stroke19 = xYBarRenderer12.getBaseOutlineStroke();
        java.awt.Paint paint20 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        try {
            org.jfree.chart.LegendItem legendItem21 = new org.jfree.chart.LegendItem(attributedString0, "ERROR : Relative To String", "TextBlockAnchor.TOP_RIGHT", "$8.00", shape10, paint11, stroke19, paint20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.data.KeyedValues keyedValues0 = null;
        try {
            org.jfree.data.general.DefaultPieDataset defaultPieDataset1 = new org.jfree.data.general.DefaultPieDataset(keyedValues0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'data' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation(100, axisLocation7);
        java.awt.Paint paint9 = categoryPlot4.getRangeCrosshairPaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot4.zoomDomainAxes(4.0d, plotRenderingInfo11, point2D12, true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        boolean boolean0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("$8.00");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        int int3 = java.awt.Color.HSBtoRGB((float) 100L, (float) 100, (float) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-10289251) + "'", int3 == (-10289251));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date3 = spreadsheetDate2.toDate();
        try {
            org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer0.setBaseLinesVisible(true);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator4 = xYStepRenderer0.getSeriesItemLabelGenerator((int) '#');
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator8 = xYStepRenderer0.getItemLabelGenerator((int) (byte) 100, (-1), false);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator9 = null;
        xYStepRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator9);
        java.awt.Stroke stroke14 = xYStepRenderer0.getItemOutlineStroke((int) (short) 1, (-1), true);
        org.junit.Assert.assertNull(xYItemLabelGenerator4);
        org.junit.Assert.assertNull(xYItemLabelGenerator8);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        org.jfree.chart.text.TextFragment textFragment1 = null;
        textLine0.removeFragment(textFragment1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.util.Size2D size2D4 = textLine0.calculateDimensions(graphics2D3);
        size2D4.setWidth((double) 4);
        org.junit.Assert.assertNotNull(size2D4);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        blockParams0.setTranslateX((double) 100.0f);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        java.lang.Class class1 = null;
        java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResource("java.awt.Color[r=0,g=255,b=0]", class1);
        org.junit.Assert.assertNull(uRL2);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(true);
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getCurrencyInstance();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit((double) 100L, numberFormat1);
        java.math.RoundingMode roundingMode3 = null;
        try {
            numberFormat1.setRoundingMode(roundingMode3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat1);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) (short) 100, (-1.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer0.setBaseLinesVisible(true);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator4 = xYStepRenderer0.getSeriesItemLabelGenerator((int) '#');
        boolean boolean5 = xYStepRenderer0.getAutoPopulateSeriesShape();
        xYStepRenderer0.setUseFillPaint(false);
        org.junit.Assert.assertNull(xYItemLabelGenerator4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("hi!", graphics2D1, 0.0f, (float) 86400000L, 0.08d, (float) 4, (-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit0 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        org.junit.Assert.assertNotNull(numberTickUnit0);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateBottomInset(10.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        int int0 = org.jfree.data.time.SerialDate.THURSDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.firstMondayAfter1900();
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + (-2208960000000L) + "'", long0 == (-2208960000000L));
    }

//    @Test
//    public void test215() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test215");
//        boolean boolean0 = org.jfree.chart.renderer.xy.XYBarRenderer.getDefaultShadowsVisible();
//        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
//    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        java.awt.Color color0 = java.awt.Color.blue;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer0.setBaseLinesVisible(true);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator4 = xYStepRenderer0.getSeriesItemLabelGenerator((int) '#');
        boolean boolean5 = xYStepRenderer0.getAutoPopulateSeriesShape();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation6 = null;
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis9, categoryItemRenderer10);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        categoryPlot11.setDataset(categoryDataset12);
        boolean boolean14 = categoryPlot11.isSubplot();
        java.awt.Paint paint16 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer17 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer17.clearSeriesStrokes(true);
        java.awt.Stroke stroke21 = xYBarRenderer17.lookupSeriesOutlineStroke(100);
        xYBarRenderer17.setShadowXOffset((double) 100.0f);
        java.awt.Stroke stroke24 = xYBarRenderer17.getBaseOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker(0.05d, paint16, stroke24);
        org.jfree.chart.text.TextAnchor textAnchor26 = valueMarker25.getLabelTextAnchor();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot27 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        int int29 = combinedDomainXYPlot27.getDomainAxisIndex(valueAxis28);
        org.jfree.chart.axis.ValueAxis valueAxis30 = combinedDomainXYPlot27.getRangeAxis();
        org.jfree.data.category.CategoryDataset categoryDataset31 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = null;
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset31, categoryAxis32, valueAxis33, categoryItemRenderer34);
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = categoryPlot35.getDomainAxisEdge();
        java.awt.Paint paint37 = categoryPlot35.getOutlinePaint();
        java.awt.Paint paint40 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer41 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer41.clearSeriesStrokes(true);
        java.awt.Stroke stroke45 = xYBarRenderer41.lookupSeriesOutlineStroke(100);
        xYBarRenderer41.setShadowXOffset((double) 100.0f);
        java.awt.Stroke stroke48 = xYBarRenderer41.getBaseOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker49 = new org.jfree.chart.plot.ValueMarker(0.05d, paint40, stroke48);
        float float50 = valueMarker49.getAlpha();
        org.jfree.chart.util.Layer layer51 = null;
        boolean boolean52 = categoryPlot35.removeRangeMarker(100, (org.jfree.chart.plot.Marker) valueMarker49, layer51);
        org.jfree.chart.text.TextAnchor textAnchor53 = valueMarker49.getLabelTextAnchor();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot54 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis55 = null;
        int int56 = combinedDomainXYPlot54.getDomainAxisIndex(valueAxis55);
        org.jfree.chart.axis.ValueAxis valueAxis57 = null;
        int int58 = combinedDomainXYPlot54.getRangeAxisIndex(valueAxis57);
        java.awt.Paint paint59 = combinedDomainXYPlot54.getDomainZeroBaselinePaint();
        boolean boolean60 = combinedDomainXYPlot54.isDomainZeroBaselineVisible();
        org.jfree.chart.util.Layer layer61 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection62 = combinedDomainXYPlot54.getRangeMarkers(layer61);
        combinedDomainXYPlot27.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker49, layer61);
        boolean boolean64 = categoryPlot11.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker25, layer61);
        try {
            xYStepRenderer0.addAnnotation(xYAnnotation6, layer61);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYItemLabelGenerator4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(textAnchor26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNull(valueAxis30);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertTrue("'" + float50 + "' != '" + 1.0f + "'", float50 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(textAnchor53);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + (-1) + "'", int56 == (-1));
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertNotNull(paint59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(layer61);
        org.junit.Assert.assertNull(collection62);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot2 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = combinedDomainXYPlot2.getDomainAxisIndex(valueAxis3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = combinedDomainXYPlot2.getRangeAxis();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("WMAP_Plot", font1, (org.jfree.chart.plot.Plot) combinedDomainXYPlot2, true);
        try {
            org.jfree.chart.title.Title title9 = jFreeChart7.getSubtitle((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNull(valueAxis5);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.data.function.Function2D function2D0 = null;
        try {
            org.jfree.data.xy.XYDataset xYDataset5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, (double) 100.0f, 0.0d, 6, (java.lang.Comparable) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState1 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo0);
        int int2 = xYItemRendererState1.getFirstItemIndex();
        java.awt.Font font4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot5 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        int int7 = combinedDomainXYPlot5.getDomainAxisIndex(valueAxis6);
        org.jfree.chart.axis.ValueAxis valueAxis8 = combinedDomainXYPlot5.getRangeAxis();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("WMAP_Plot", font4, (org.jfree.chart.plot.Plot) combinedDomainXYPlot5, true);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent11 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) int2, jFreeChart10);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Point2D point2D14 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = null;
        try {
            jFreeChart10.draw(graphics2D12, rectangle2D13, point2D14, chartRenderingInfo15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNull(valueAxis8);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 7);
        java.lang.String str2 = xYSeries1.getDescription();
        org.jfree.data.xy.XYSeries xYSeries5 = xYSeries1.createCopy((int) 'a', (-1));
        try {
            xYSeries1.delete(2, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: toIndex = 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(xYSeries5);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("$8.00", "{0}", "WMAP_Plot", "hi!", "");
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.clearSeriesStrokes(true);
        java.awt.Stroke stroke4 = xYBarRenderer0.lookupSeriesOutlineStroke(100);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = null;
        java.util.TimeZone timeZone8 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection9 = new org.jfree.data.time.TimeSeriesCollection(timeZone8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        try {
            org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState11 = xYBarRenderer0.initialise(graphics2D5, rectangle2D6, xYPlot7, (org.jfree.data.xy.XYDataset) timeSeriesCollection9, plotRenderingInfo10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter0 = new org.jfree.chart.renderer.category.GradientBarPainter();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = null;
        java.awt.geom.RectangularShape rectangularShape6 = null;
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle8.setMaximumLinesToDisplay(1);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, valueAxis13, categoryItemRenderer14);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = categoryPlot15.getDomainAxisEdge();
        textTitle8.setPosition(rectangleEdge16);
        try {
            gradientBarPainter0.paintBarShadow(graphics2D1, barRenderer2, 8, (int) (short) -1, true, rectangularShape6, rectangleEdge16, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge16);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=0,g=255,b=0]");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer2 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer2.clearSeriesStrokes(true);
        java.awt.Stroke stroke6 = xYBarRenderer2.lookupSeriesOutlineStroke(100);
        xYBarRenderer2.setShadowXOffset((double) 100.0f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState11 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo10);
        java.awt.geom.Line2D line2D12 = xYItemRendererState11.workingLine;
        xYBarRenderer2.setLegendShape(0, (java.awt.Shape) line2D12);
        numberAxis1.setRightArrow((java.awt.Shape) line2D12);
        numberAxis1.setNegativeArrowVisible(true);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(line2D12);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0, waferMapRenderer1);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range2 = org.jfree.data.Range.combine(range0, range1);
        org.jfree.data.Range range3 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range5 = org.jfree.data.Range.combine(range3, range4);
        boolean boolean6 = range2.intersects(range4);
        org.junit.Assert.assertNotNull(range0);
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.data.general.DatasetGroup datasetGroup2 = timeSeriesCollection1.getGroup();
        org.jfree.data.general.DatasetGroup datasetGroup3 = timeSeriesCollection1.getGroup();
        java.lang.Object obj4 = datasetGroup3.clone();
        org.junit.Assert.assertNotNull(datasetGroup2);
        org.junit.Assert.assertNotNull(datasetGroup3);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.HOUR;
        org.junit.Assert.assertNotNull(dateTickUnitType0);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE12;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            boolean boolean2 = org.jfree.chart.util.ShapeUtilities.intersects(rectangle2D0, rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        int int2 = combinedDomainXYPlot0.getDomainAxisIndex(valueAxis1);
        combinedDomainXYPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.axis.AxisSpace axisSpace5 = null;
        combinedDomainXYPlot0.setFixedDomainAxisSpace(axisSpace5);
        boolean boolean7 = combinedDomainXYPlot0.isDomainZoomable();
        org.jfree.data.general.WaferMapDataset waferMapDataset8 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot9 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset8);
        java.awt.Font font10 = waferMapPlot9.getNoDataMessageFont();
        boolean boolean11 = combinedDomainXYPlot0.equals((java.lang.Object) font10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("TextBlockAnchor.TOP_RIGHT", "");
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType4 = rectangleConstraint3.getHeightConstraintType();
        org.jfree.chart.util.Size2D size2D5 = borderArrangement0.arrange(blockContainer1, graphics2D2, rectangleConstraint3);
        org.jfree.chart.block.Arrangement arrangement6 = blockContainer1.getArrangement();
        org.junit.Assert.assertNotNull(rectangleConstraint3);
        org.junit.Assert.assertNotNull(lengthConstraintType4);
        org.junit.Assert.assertNotNull(size2D5);
        org.junit.Assert.assertNotNull(arrangement6);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        int int6 = categoryPlot5.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation8 = null;
        categoryPlot5.setRangeAxisLocation(100, axisLocation8);
        int int10 = categoryPlot5.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot5.getDomainAxisEdge();
        try {
            double double12 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D0, rectangleEdge11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge11);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset0, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot2 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = combinedDomainXYPlot2.getDomainAxisIndex(valueAxis3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = combinedDomainXYPlot2.getRangeAxis();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("WMAP_Plot", font1, (org.jfree.chart.plot.Plot) combinedDomainXYPlot2, true);
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle9.setMaximumLinesToDisplay(1);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, categoryItemRenderer15);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot16.getDomainAxisEdge();
        textTitle9.setPosition(rectangleEdge17);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = textTitle9.getPadding();
        jFreeChart7.removeSubtitle((org.jfree.chart.title.Title) textTitle9);
        org.jfree.chart.title.LegendTitle legendTitle21 = jFreeChart7.getLegend();
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer22 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        org.jfree.data.Range range24 = xYStepRenderer22.findDomainBounds(xYDataset23);
        java.awt.Color color27 = org.jfree.chart.util.PaintUtilities.stringToColor("ERROR : Relative To String");
        xYStepRenderer22.setSeriesOutlinePaint(1, (java.awt.Paint) color27);
        java.awt.Paint paint29 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        xYStepRenderer22.setBaseLegendTextPaint(paint29);
        legendTitle21.setBackgroundPaint(paint29);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(legendTitle21);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(paint29);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.chart.renderer.xy.XYBarRenderer.setDefaultShadowsVisible(true);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        java.awt.Font font0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle1.setMaximumLinesToDisplay(1);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = categoryPlot8.getDomainAxisEdge();
        textTitle1.setPosition(rectangleEdge9);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = textTitle1.getPadding();
        java.lang.Object obj12 = textTitle1.clone();
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor0 = org.jfree.data.time.TimePeriodAnchor.START;
        org.junit.Assert.assertNotNull(timePeriodAnchor0);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        categoryPlot4.setRangeZeroBaselinePaint((java.awt.Paint) color6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = categoryPlot4.getRangeAxisForDataset(100);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNull(valueAxis9);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection1, true);
        try {
            timeSeriesCollection1.setSelected((int) (byte) 0, 0, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range3);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "", "ERROR : Relative To String", "hi!", "ERROR : Relative To String");
        basicProjectInfo5.setCopyright("ERROR : Relative To String");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo13 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "", "ERROR : Relative To String", "hi!", "ERROR : Relative To String");
        basicProjectInfo13.setCopyright("ERROR : Relative To String");
        basicProjectInfo5.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo13);
        basicProjectInfo13.setCopyright("ClassContext");
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        java.util.Date date3 = spreadsheetDate1.toDate();
        java.util.TimeZone timeZone4 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date3, timeZone4);
        int int6 = month5.getYearValue();
        long long7 = month5.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1900 + "'", int6 == 1900);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208960000000L) + "'", long7 == (-2208960000000L));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.clearSeriesStrokes(true);
        java.awt.Paint paint4 = xYBarRenderer0.getSeriesFillPaint((int) '#');
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator5 = xYBarRenderer0.getLegendItemURLGenerator();
        java.awt.Paint paint9 = xYBarRenderer0.getItemFillPaint((int) ' ', (int) (byte) -1, true);
        double double10 = xYBarRenderer0.getMargin();
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator5);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.MONTH;
        org.junit.Assert.assertNotNull(dateTickUnitType0);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        java.awt.Shape shape4 = null;
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, valueAxis7, categoryItemRenderer8);
        int int10 = categoryPlot9.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation12 = null;
        categoryPlot9.setRangeAxisLocation(100, axisLocation12);
        int int14 = categoryPlot9.getWeight();
        java.awt.Paint paint15 = categoryPlot9.getRangeGridlinePaint();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer16 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer16.clearSeriesStrokes(true);
        java.awt.Stroke stroke20 = xYBarRenderer16.lookupSeriesOutlineStroke(100);
        xYBarRenderer16.setShadowXOffset((double) 100.0f);
        java.awt.Stroke stroke23 = xYBarRenderer16.getBaseOutlineStroke();
        java.awt.Paint paint24 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("", "TextBlockAnchor.TOP_RIGHT", "{0}: ({1}, {2})", "", shape4, paint15, stroke23, paint24);
        java.awt.Color color26 = java.awt.Color.lightGray;
        legendItem25.setLabelPaint((java.awt.Paint) color26);
        java.awt.Shape shape28 = legendItem25.getLine();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer29 = legendItem25.getFillPaintTransformer();
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(gradientPaintTransformer29);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer0.setBaseLinesVisible(true);
        xYStepRenderer0.setSeriesLinesVisible(0, true);
        java.awt.Paint paint6 = xYStepRenderer0.getBaseLegendTextPaint();
        int int7 = xYStepRenderer0.getPassCount();
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.data.Range range2 = xYStepRenderer0.findDomainBounds(xYDataset1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = null;
        xYStepRenderer0.setBaseToolTipGenerator(xYToolTipGenerator3);
        boolean boolean5 = xYStepRenderer0.getBaseShapesVisible();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator6 = null;
        xYStepRenderer0.setBaseToolTipGenerator(xYToolTipGenerator6, true);
        java.awt.Color color10 = java.awt.Color.lightGray;
        xYStepRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color10);
        double double12 = xYStepRenderer0.getItemLabelAnchorOffset();
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot2 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = combinedDomainXYPlot2.getDomainAxisIndex(valueAxis3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = combinedDomainXYPlot2.getRangeAxis();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("WMAP_Plot", font1, (org.jfree.chart.plot.Plot) combinedDomainXYPlot2, true);
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle9.setMaximumLinesToDisplay(1);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, categoryItemRenderer15);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot16.getDomainAxisEdge();
        textTitle9.setPosition(rectangleEdge17);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = textTitle9.getPadding();
        jFreeChart7.removeSubtitle((org.jfree.chart.title.Title) textTitle9);
        org.jfree.chart.title.LegendTitle legendTitle21 = jFreeChart7.getLegend();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent22 = null;
        try {
            jFreeChart7.titleChanged(titleChangeEvent22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(legendTitle21);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        java.awt.Shape shape4 = null;
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, valueAxis7, categoryItemRenderer8);
        int int10 = categoryPlot9.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation12 = null;
        categoryPlot9.setRangeAxisLocation(100, axisLocation12);
        int int14 = categoryPlot9.getWeight();
        java.awt.Paint paint15 = categoryPlot9.getRangeGridlinePaint();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer16 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer16.clearSeriesStrokes(true);
        java.awt.Stroke stroke20 = xYBarRenderer16.lookupSeriesOutlineStroke(100);
        xYBarRenderer16.setShadowXOffset((double) 100.0f);
        java.awt.Stroke stroke23 = xYBarRenderer16.getBaseOutlineStroke();
        java.awt.Paint paint24 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("", "TextBlockAnchor.TOP_RIGHT", "{0}: ({1}, {2})", "", shape4, paint15, stroke23, paint24);
        java.awt.Color color26 = java.awt.Color.lightGray;
        legendItem25.setLabelPaint((java.awt.Paint) color26);
        java.awt.Shape shape28 = legendItem25.getShape();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer29 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        legendItem25.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer29);
        java.awt.Stroke stroke31 = legendItem25.getOutlineStroke();
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNull(shape28);
        org.junit.Assert.assertNotNull(stroke31);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection1, false);
        try {
            double double6 = timeSeriesCollection1.getEndXValue(7, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range3);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer0.setBaseLinesVisible(true);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator4 = xYStepRenderer0.getSeriesItemLabelGenerator((int) '#');
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator8 = xYStepRenderer0.getItemLabelGenerator((int) (byte) 100, (-1), false);
        java.awt.Font font10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot11 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        int int13 = combinedDomainXYPlot11.getDomainAxisIndex(valueAxis12);
        org.jfree.chart.axis.ValueAxis valueAxis14 = combinedDomainXYPlot11.getRangeAxis();
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart("WMAP_Plot", font10, (org.jfree.chart.plot.Plot) combinedDomainXYPlot11, true);
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle18.setMaximumLinesToDisplay(1);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, valueAxis23, categoryItemRenderer24);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot25.getDomainAxisEdge();
        textTitle18.setPosition(rectangleEdge26);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = textTitle18.getPadding();
        jFreeChart16.removeSubtitle((org.jfree.chart.title.Title) textTitle18);
        boolean boolean30 = xYStepRenderer0.equals((java.lang.Object) textTitle18);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer32 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.data.xy.XYDataset xYDataset33 = null;
        org.jfree.data.Range range34 = xYStepRenderer32.findDomainBounds(xYDataset33);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator35 = null;
        xYStepRenderer32.setBaseToolTipGenerator(xYToolTipGenerator35);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition40 = xYStepRenderer32.getPositiveItemLabelPosition((int) (short) -1, (-458), false);
        try {
            xYStepRenderer0.setSeriesPositiveItemLabelPosition((int) (short) -1, itemLabelPosition40, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYItemLabelGenerator4);
        org.junit.Assert.assertNull(xYItemLabelGenerator8);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNull(valueAxis14);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(range34);
        org.junit.Assert.assertNotNull(itemLabelPosition40);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate1 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        java.awt.Color color0 = java.awt.Color.ORANGE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation(100, axisLocation7);
        org.jfree.chart.plot.Marker marker9 = null;
        org.jfree.chart.util.Layer layer10 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean11 = categoryPlot4.removeDomainMarker(marker9, layer10);
        categoryPlot4.clearRangeMarkers();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(layer10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation(100, axisLocation7);
        java.awt.Paint paint9 = categoryPlot4.getRangeCrosshairPaint();
        boolean boolean10 = categoryPlot4.isOutlineVisible();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date3 = spreadsheetDate2.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date6 = spreadsheetDate5.toDate();
        boolean boolean7 = spreadsheetDate2.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        try {
            org.jfree.data.general.PieDataset pieDataset8 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset0, (java.lang.Comparable) boolean7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.clearSeriesStrokes(true);
        java.awt.Stroke stroke4 = xYBarRenderer0.lookupSeriesOutlineStroke(100);
        xYBarRenderer0.setShadowXOffset((double) 100.0f);
        java.awt.Stroke stroke7 = xYBarRenderer0.getBaseOutlineStroke();
        boolean boolean8 = xYBarRenderer0.getBaseItemLabelsVisible();
        xYBarRenderer0.setUseYInterval(false);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("TextBlockAnchor.TOP_RIGHT");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType4 = rectangleConstraint3.getHeightConstraintType();
        try {
            org.jfree.chart.util.Size2D size2D5 = labelBlock1.arrange(graphics2D2, rectangleConstraint3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleConstraint3);
        org.junit.Assert.assertNotNull(lengthConstraintType4);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot2 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = combinedDomainXYPlot2.getDomainAxisIndex(valueAxis3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = combinedDomainXYPlot2.getRangeAxis();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("WMAP_Plot", font1, (org.jfree.chart.plot.Plot) combinedDomainXYPlot2, true);
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle9.setMaximumLinesToDisplay(1);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, categoryItemRenderer15);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot16.getDomainAxisEdge();
        textTitle9.setPosition(rectangleEdge17);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = textTitle9.getPadding();
        jFreeChart7.removeSubtitle((org.jfree.chart.title.Title) textTitle9);
        org.jfree.chart.title.LegendTitle legendTitle21 = jFreeChart7.getLegend();
        org.jfree.chart.event.ChartProgressListener chartProgressListener22 = null;
        jFreeChart7.addProgressListener(chartProgressListener22);
        java.awt.Color color24 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.Color color25 = color24.darker();
        try {
            jFreeChart7.setTextAntiAlias((java.lang.Object) color25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: java.awt.Color[r=178,g=178,b=44] incompatible with Text-specific antialiasing enable key");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(legendTitle21);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(color25);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE7;
        java.lang.String str1 = itemLabelAnchor0.toString();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ItemLabelAnchor.INSIDE7" + "'", str1.equals("ItemLabelAnchor.INSIDE7"));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        int int3 = combinedDomainXYPlot1.getDomainAxisIndex(valueAxis2);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        int int5 = combinedDomainXYPlot1.getRangeAxisIndex(valueAxis4);
        java.awt.Paint paint6 = combinedDomainXYPlot1.getDomainZeroBaselinePaint();
        java.awt.Stroke stroke7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        combinedDomainXYPlot1.setRangeZeroBaselineStroke(stroke7);
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = combinedDomainXYPlot1.getRendererForDataset(xYDataset9);
        org.jfree.chart.axis.AxisLocation axisLocation12 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        combinedDomainXYPlot1.setRangeAxisLocation(0, axisLocation12);
        combinedDomainXYPlot0.setRangeAxisLocation(axisLocation12, true);
        org.jfree.chart.axis.AxisSpace axisSpace16 = combinedDomainXYPlot0.getFixedDomainAxisSpace();
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        try {
            combinedDomainXYPlot0.drawBackground(graphics2D17, rectangle2D18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(xYItemRenderer10);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNull(axisSpace16);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        int int0 = org.jfree.chart.renderer.xy.XYAreaRenderer.SHAPES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getCurrencyInstance();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit((double) 100L, numberFormat1);
        java.lang.String str4 = numberFormat1.format((long) 8);
        numberFormat1.setMinimumIntegerDigits(15);
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "$8.00" + "'", str4.equals("$8.00"));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0);
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        int int7 = categoryPlot6.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation9 = null;
        categoryPlot6.setRangeAxisLocation(100, axisLocation9);
        timeSeriesCollection1.removeChangeListener((org.jfree.data.general.DatasetChangeListener) categoryPlot6);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate13 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection1, true);
        boolean boolean14 = intervalXYDelegate13.isAutoWidth();
        try {
            double double17 = intervalXYDelegate13.getEndXValue((int) (byte) 0, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState1 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo0);
        java.awt.geom.Line2D line2D2 = xYItemRendererState1.workingLine;
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) line2D2, "{0}: ({1}, {2})", "series");
        java.lang.String str6 = chartEntity5.getToolTipText();
        org.junit.Assert.assertNotNull(line2D2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "{0}: ({1}, {2})" + "'", str6.equals("{0}: ({1}, {2})"));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        try {
            java.lang.Number number2 = defaultPieDataset0.getValue((java.lang.Comparable) 10.0f);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Key not found: 10.0");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 7);
        xYSeries1.setNotify(false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        int int2 = combinedDomainXYPlot0.getDomainAxisIndex(valueAxis1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = combinedDomainXYPlot0.getRangeAxisIndex(valueAxis3);
        java.awt.Paint paint5 = combinedDomainXYPlot0.getDomainZeroBaselinePaint();
        java.awt.Stroke stroke6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        combinedDomainXYPlot0.setRangeZeroBaselineStroke(stroke6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = combinedDomainXYPlot0.getRendererForDataset(xYDataset8);
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        combinedDomainXYPlot0.drawAnnotations(graphics2D10, rectangle2D11, plotRenderingInfo12);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis15 = combinedDomainXYPlot0.getDomainAxisForDataset((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 32 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(xYItemRenderer9);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.setRangeCrosshairValue(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double8 = rectangleInsets7.getTop();
        categoryPlot4.setAxisOffset(rectangleInsets7);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 3.0d + "'", double8 == 3.0d);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=0,g=255,b=0]");
        java.awt.Stroke stroke2 = null;
        try {
            numberAxis1.setTickMarkStroke(stroke2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        double double2 = textTitle1.getContentXOffset();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        textTitle1.draw(graphics2D3, rectangle2D4);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter3 = new org.jfree.chart.renderer.category.GradientBarPainter(1.0d, (double) '#', (double) (byte) 0);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        int int0 = org.jfree.data.time.Year.MINIMUM_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-9999) + "'", int0 == (-9999));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        int int2 = combinedDomainXYPlot0.getDomainAxisIndex(valueAxis1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = combinedDomainXYPlot0.getRangeAxis();
        boolean boolean4 = combinedDomainXYPlot0.isSubplot();
        combinedDomainXYPlot0.setRangeMinorGridlinesVisible(false);
        boolean boolean7 = combinedDomainXYPlot0.isDomainZeroBaselineVisible();
        int int8 = combinedDomainXYPlot0.getWeight();
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        try {
            combinedDomainXYPlot0.drawBackground(graphics2D9, rectangle2D10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = categoryPlot4.getDomainAxisEdge();
        java.awt.Paint paint6 = categoryPlot4.getOutlinePaint();
        categoryPlot4.setBackgroundAlpha((float) 100L);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot4.setRangeAxis(valueAxis9);
        java.awt.Paint paint11 = categoryPlot4.getBackgroundPaint();
        categoryPlot4.clearAnnotations();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation13 = null;
        try {
            categoryPlot4.addAnnotation(categoryAnnotation13, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer0.setBaseLinesVisible(true);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator4 = xYStepRenderer0.getSeriesItemLabelGenerator((int) '#');
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator6 = null;
        xYStepRenderer0.setSeriesItemLabelGenerator((int) 'a', xYItemLabelGenerator6, true);
        boolean boolean11 = xYStepRenderer0.getItemLineVisible((int) (byte) -1, 0);
        java.awt.Font font13 = xYStepRenderer0.getLegendTextFont(2147483647);
        org.junit.Assert.assertNull(xYItemLabelGenerator4);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(font13);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        java.awt.geom.Point2D point2D0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePoint2D(point2D0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.data.Range range4 = xYStepRenderer2.findDomainBounds(xYDataset3);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator5 = null;
        xYStepRenderer2.setBaseToolTipGenerator(xYToolTipGenerator5);
        boolean boolean7 = xYStepRenderer2.getBaseShapesVisible();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator8 = null;
        xYStepRenderer2.setBaseToolTipGenerator(xYToolTipGenerator8, true);
        java.awt.Color color12 = java.awt.Color.lightGray;
        xYStepRenderer2.setSeriesFillPaint((int) '#', (java.awt.Paint) color12);
        boolean boolean14 = timeSeriesCollection1.equals((java.lang.Object) xYStepRenderer2);
        try {
            xYStepRenderer2.setSeriesLinesVisible((-1), false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        java.awt.Paint paint0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer0.setBaseLinesVisible(true);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator4 = xYStepRenderer0.getSeriesItemLabelGenerator((int) '#');
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = xYStepRenderer0.getBasePositiveItemLabelPosition();
        xYStepRenderer0.setAutoPopulateSeriesPaint(false);
        org.junit.Assert.assertNull(xYItemLabelGenerator4);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(2);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        int int3 = java.awt.Color.HSBtoRGB((float) 12, (float) (byte) -1, (float) 9999);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-4126) + "'", int3 == (-4126));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("ERROR : Relative To String");
        categoryAxis3D1.setCategoryLabelPositionOffset(0);
        java.lang.Comparable comparable4 = null;
        try {
            categoryAxis3D1.addCategoryLabelToolTip(comparable4, "TextBlockAnchor.TOP_RIGHT");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        segmentedTimeline0.addException((long) (byte) -1, 10L);
        int int4 = segmentedTimeline0.getSegmentsExcluded();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.data.DomainOrder domainOrder0 = org.jfree.data.DomainOrder.NONE;
        java.lang.String str1 = domainOrder0.toString();
        org.junit.Assert.assertNotNull(domainOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DomainOrder.NONE" + "'", str1.equals("DomainOrder.NONE"));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("ERROR : Relative To String");
        categoryAxis3D1.clearCategoryLabelToolTips();
        java.awt.Paint paint3 = categoryAxis3D1.getLabelPaint();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 255);
        java.lang.Object obj7 = timeSeriesDataItem6.clone();
        java.util.List list8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, valueAxis12, categoryItemRenderer13);
        int int15 = categoryPlot14.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation17 = null;
        categoryPlot14.setRangeAxisLocation(100, axisLocation17);
        int int19 = categoryPlot14.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = categoryPlot14.getDomainAxisEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge20);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer22 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        org.jfree.data.Range range24 = xYStepRenderer22.findDomainBounds(xYDataset23);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator25 = null;
        xYStepRenderer22.setBaseToolTipGenerator(xYToolTipGenerator25);
        boolean boolean27 = xYStepRenderer22.getBaseShapesVisible();
        double double28 = xYStepRenderer22.getStepPoint();
        boolean boolean29 = rectangleEdge20.equals((java.lang.Object) xYStepRenderer22);
        try {
            double double30 = categoryAxis3D1.getCategoryMiddle((java.lang.Comparable) timeSeriesDataItem6, list8, rectangle2D9, rectangleEdge20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'categories' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0d + "'", double28 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "", "ERROR : Relative To String", "hi!", "ERROR : Relative To String");
        basicProjectInfo5.setLicenceName("");
        basicProjectInfo5.setLicenceName("$8.00");
        org.jfree.chart.ui.Library[] libraryArray10 = basicProjectInfo5.getOptionalLibraries();
        org.junit.Assert.assertNotNull(libraryArray10);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = org.jfree.chart.text.TextUtilities.drawAlignedString("ItemLabelAnchor.INSIDE7", graphics2D1, (float) (byte) 0, (float) 1, textAnchor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        boolean boolean2 = waferMapPlot1.isOutlineVisible();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.awt.geom.Point2D point2D5 = null;
        org.jfree.chart.plot.PlotState plotState6 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        try {
            waferMapPlot1.draw(graphics2D3, rectangle2D4, point2D5, plotState6, plotRenderingInfo7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.text.TextBlock textBlock1 = new org.jfree.chart.text.TextBlock();
        java.util.List list2 = textBlock1.getLines();
        try {
            org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateToFindRangeBounds(categoryDataset0, list2, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.CENTER;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        java.lang.Class class1 = null;
        java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("hi!", class1);
        org.junit.Assert.assertNull(inputStream2);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0);
        int int2 = timeSeriesCollection1.getSeriesCount();
        try {
            int[] intArray5 = timeSeriesCollection1.getSurroundingItems(0, (long) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation(100, axisLocation7);
        int int9 = categoryPlot4.getWeight();
        java.awt.Paint paint10 = categoryPlot4.getRangeGridlinePaint();
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.data.Range range12 = categoryPlot4.getDataRange(valueAxis11);
        java.awt.Stroke stroke13 = categoryPlot4.getRangeMinorGridlineStroke();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D16 = new org.jfree.chart.axis.CategoryAxis3D("ERROR : Relative To String");
        categoryAxis3D16.clearCategoryLabelToolTips();
        categoryPlot4.setDomainAxis((int) '#', (org.jfree.chart.axis.CategoryAxis) categoryAxis3D16, false);
        java.awt.Font font20 = categoryAxis3D16.getLabelFont();
        float float21 = categoryAxis3D16.getTickMarkInsideLength();
        java.awt.Stroke stroke22 = categoryAxis3D16.getAxisLineStroke();
        org.jfree.chart.plot.Plot plot23 = categoryAxis3D16.getPlot();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 0.0f + "'", float21 == 0.0f);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(plot23);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, 0.0d, (double) 100);
        columnArrangement4.clear();
        java.lang.Object obj6 = null;
        boolean boolean7 = columnArrangement4.equals(obj6);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer0.setBaseLinesVisible(true);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator4 = xYStepRenderer0.getSeriesItemLabelGenerator((int) '#');
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator6 = xYStepRenderer0.getSeriesURLGenerator(0);
        org.junit.Assert.assertNull(xYItemLabelGenerator4);
        org.junit.Assert.assertNull(xYURLGenerator6);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_UPPER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.data.Range range2 = xYStepRenderer0.findDomainBounds(xYDataset1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = null;
        xYStepRenderer0.setBaseToolTipGenerator(xYToolTipGenerator3);
        org.jfree.data.general.WaferMapDataset waferMapDataset6 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot7 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset6);
        java.awt.Paint paint8 = waferMapPlot7.getOutlinePaint();
        xYStepRenderer0.setSeriesFillPaint(100, paint8, false);
        boolean boolean12 = xYStepRenderer0.isSeriesItemLabelsVisible(10);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator16 = xYStepRenderer0.getURLGenerator(2, (int) (byte) 100, false);
        boolean boolean17 = xYStepRenderer0.getAutoPopulateSeriesPaint();
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(xYURLGenerator16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.data.Range range2 = xYStepRenderer0.findDomainBounds(xYDataset1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = null;
        xYStepRenderer0.setBaseToolTipGenerator(xYToolTipGenerator3);
        boolean boolean5 = xYStepRenderer0.getBaseShapesVisible();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator6 = null;
        xYStepRenderer0.setBaseToolTipGenerator(xYToolTipGenerator6, true);
        java.awt.Stroke stroke10 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        xYStepRenderer0.setSeriesOutlineStroke((int) (short) 1, stroke10);
        org.jfree.data.general.WaferMapDataset waferMapDataset12 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot13 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset12);
        java.awt.Font font14 = waferMapPlot13.getNoDataMessageFont();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent15 = null;
        waferMapPlot13.notifyListeners(plotChangeEvent15);
        boolean boolean17 = xYStepRenderer0.hasListener((java.util.EventListener) waferMapPlot13);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = xYStepRenderer0.getDrawingSupplier();
        boolean boolean19 = xYStepRenderer0.getDataBoundsIncludesVisibleSeriesOnly();
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

//    @Test
//    public void test316() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test316");
//        long long0 = org.jfree.chart.axis.SegmentedTimeline.FIRST_MONDAY_AFTER_1900;
//        org.junit.Assert.assertTrue("'" + long0 + "' != '" + (-2208960000000L) + "'", long0 == (-2208960000000L));
//    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        double double0 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_X_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 12.0d + "'", double0 == 12.0d);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection1, true);
        timeSeriesCollection1.removeAllSeries();
        try {
            timeSeriesCollection1.setSelected(100, 2, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (100).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range3);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.clearSeriesStrokes(true);
        java.awt.Stroke stroke4 = xYBarRenderer0.lookupSeriesOutlineStroke(100);
        xYBarRenderer0.setShadowXOffset((double) 100.0f);
        org.jfree.chart.plot.XYPlot xYPlot7 = xYBarRenderer0.getPlot();
        org.jfree.chart.plot.XYPlot xYPlot8 = xYBarRenderer0.getPlot();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(xYPlot7);
        org.junit.Assert.assertNull(xYPlot8);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("{0}: ({1}, {2})", dateFormat1, dateFormat2);
        java.lang.String str4 = standardXYToolTipGenerator3.getNullYString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "null" + "'", str4.equals("null"));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        org.jfree.chart.text.TextFragment textFragment1 = null;
        textLine0.removeFragment(textFragment1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, valueAxis8, categoryItemRenderer9);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot10.getDomainAxisEdge();
        java.awt.Paint paint12 = categoryPlot10.getOutlinePaint();
        java.awt.Paint paint15 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer16 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer16.clearSeriesStrokes(true);
        java.awt.Stroke stroke20 = xYBarRenderer16.lookupSeriesOutlineStroke(100);
        xYBarRenderer16.setShadowXOffset((double) 100.0f);
        java.awt.Stroke stroke23 = xYBarRenderer16.getBaseOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker(0.05d, paint15, stroke23);
        float float25 = valueMarker24.getAlpha();
        org.jfree.chart.util.Layer layer26 = null;
        boolean boolean27 = categoryPlot10.removeRangeMarker(100, (org.jfree.chart.plot.Marker) valueMarker24, layer26);
        org.jfree.chart.text.TextAnchor textAnchor28 = valueMarker24.getLabelTextAnchor();
        textLine0.draw(graphics2D3, (float) (short) 10, (float) (byte) 0, textAnchor28, 100.0f, 0.0f, (double) (-458));
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 1.0f + "'", float25 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(textAnchor28);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.chart.axis.TickType tickType0 = org.jfree.chart.axis.TickType.MAJOR;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor4 = null;
        try {
            org.jfree.chart.axis.NumberTick numberTick6 = new org.jfree.chart.axis.NumberTick(tickType0, (double) 10, "hi!", textAnchor3, textAnchor4, (double) 86400000L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rotationAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(tickType0);
        org.junit.Assert.assertNotNull(textAnchor3);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        long long1 = segmentedTimeline0.getSegmentSize();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 86400000L + "'", long1 == 86400000L);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer0.setBaseLinesVisible(true);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator4 = xYStepRenderer0.getSeriesItemLabelGenerator((int) '#');
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator6 = null;
        xYStepRenderer0.setSeriesItemLabelGenerator((int) 'a', xYItemLabelGenerator6, true);
        boolean boolean11 = xYStepRenderer0.getItemLineVisible((int) (byte) -1, 0);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer13 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer13.setBaseLinesVisible(true);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator17 = xYStepRenderer13.getSeriesItemLabelGenerator((int) '#');
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator21 = xYStepRenderer13.getItemLabelGenerator((int) (byte) 100, (-1), false);
        java.awt.Shape shape23 = xYStepRenderer13.getSeriesShape((int) '#');
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent24 = null;
        xYStepRenderer13.notifyListeners(rendererChangeEvent24);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer26 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.data.Range range28 = xYStepRenderer26.findDomainBounds(xYDataset27);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator29 = null;
        xYStepRenderer26.setBaseToolTipGenerator(xYToolTipGenerator29);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition34 = xYStepRenderer26.getPositiveItemLabelPosition((int) (short) -1, (-458), false);
        xYStepRenderer13.setBaseNegativeItemLabelPosition(itemLabelPosition34, true);
        try {
            xYStepRenderer0.setSeriesNegativeItemLabelPosition((-1), itemLabelPosition34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYItemLabelGenerator4);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(xYItemLabelGenerator17);
        org.junit.Assert.assertNull(xYItemLabelGenerator21);
        org.junit.Assert.assertNull(shape23);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(itemLabelPosition34);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation(100, axisLocation7);
        categoryPlot4.clearRangeMarkers();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_MINIMUM_ARC_ANGLE_TO_DRAW;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-5d + "'", double0 == 1.0E-5d);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("ERROR : Relative To String");
        categoryAxis3D1.clearCategoryLabelToolTips();
        categoryAxis3D1.configure();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor4 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis10, categoryItemRenderer11);
        int int13 = categoryPlot12.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation15 = null;
        categoryPlot12.setRangeAxisLocation(100, axisLocation15);
        int int17 = categoryPlot12.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = categoryPlot12.getDomainAxisEdge();
        org.jfree.chart.axis.AxisSpace axisSpace19 = categoryPlot12.getFixedRangeAxisSpace();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        categoryPlot12.zoomRangeAxes(9.0d, plotRenderingInfo21, point2D22, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = categoryPlot12.getRangeAxisEdge();
        try {
            double double26 = categoryAxis3D1.getCategoryJava2DCoordinate(categoryAnchor4, 7, (int) (byte) 100, rectangle2D7, rectangleEdge25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNull(axisSpace19);
        org.junit.Assert.assertNotNull(rectangleEdge25);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        try {
            java.lang.Number number3 = timeSeriesCollection0.getEndY(5, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        java.text.NumberFormat numberFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        try {
            org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("{0}", numberFormat1, dateFormat2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'xFormat' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date5 = spreadsheetDate4.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date8 = spreadsheetDate7.toDate();
        boolean boolean9 = spreadsheetDate4.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate7);
        boolean boolean10 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date13 = spreadsheetDate12.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date16 = spreadsheetDate15.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date19 = spreadsheetDate18.toDate();
        boolean boolean20 = spreadsheetDate15.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate18);
        boolean boolean21 = spreadsheetDate12.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean25 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate12, (org.jfree.data.time.SerialDate) spreadsheetDate23, 0);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate23);
        spreadsheetDate23.setDescription("");
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=0,g=255,b=0]");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer6 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer6.clearSeriesStrokes(true);
        java.awt.Stroke stroke10 = xYBarRenderer6.lookupSeriesOutlineStroke(100);
        xYBarRenderer6.setShadowXOffset((double) 100.0f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState15 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo14);
        java.awt.geom.Line2D line2D16 = xYItemRendererState15.workingLine;
        xYBarRenderer6.setLegendShape(0, (java.awt.Shape) line2D16);
        numberAxis5.setRightArrow((java.awt.Shape) line2D16);
        java.awt.Paint paint19 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot20 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        int int22 = combinedDomainXYPlot20.getDomainAxisIndex(valueAxis21);
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        int int24 = combinedDomainXYPlot20.getDomainAxisIndex(valueAxis23);
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        combinedDomainXYPlot20.setRangeAxis(10, valueAxis26);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot28 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        int int30 = combinedDomainXYPlot28.getDomainAxisIndex(valueAxis29);
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        int int32 = combinedDomainXYPlot28.getRangeAxisIndex(valueAxis31);
        java.awt.Paint paint33 = combinedDomainXYPlot28.getDomainZeroBaselinePaint();
        java.awt.Stroke stroke34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        combinedDomainXYPlot28.setRangeMinorGridlineStroke(stroke34);
        combinedDomainXYPlot20.setDomainMinorGridlineStroke(stroke34);
        org.jfree.data.category.CategoryDataset categoryDataset37 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = null;
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer40 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot(categoryDataset37, categoryAxis38, valueAxis39, categoryItemRenderer40);
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = categoryPlot41.getDomainAxisEdge();
        java.awt.Paint paint43 = categoryPlot41.getOutlinePaint();
        try {
            org.jfree.chart.LegendItem legendItem44 = new org.jfree.chart.LegendItem("TextBlockAnchor.TOP_RIGHT", "TextBlockAnchor.BOTTOM_RIGHT", "TextBlockAnchor.BOTTOM_RIGHT", "WMAP_Plot", (java.awt.Shape) line2D16, paint19, stroke34, paint43);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'fillPaint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(line2D16);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(rectangleEdge42);
        org.junit.Assert.assertNotNull(paint43);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE12;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation(100, axisLocation7);
        int int9 = categoryPlot4.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = categoryPlot4.getDomainAxisEdge();
        org.jfree.chart.axis.AxisSpace axisSpace11 = categoryPlot4.getFixedRangeAxisSpace();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot4.zoomRangeAxes(9.0d, plotRenderingInfo13, point2D14, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot4.getRangeAxisEdge();
        org.jfree.chart.plot.PlotOrientation plotOrientation18 = null;
        try {
            categoryPlot4.setOrientation(plotOrientation18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNull(axisSpace11);
        org.junit.Assert.assertNotNull(rectangleEdge17);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        java.awt.Paint paint4 = null;
        try {
            org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder((double) 100, (double) 1.0f, 0.0d, (double) (byte) 0, paint4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.setSeriesVisible(3, (java.lang.Boolean) false, true);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        int int2 = combinedDomainXYPlot0.getDomainAxisIndex(valueAxis1);
        combinedDomainXYPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.axis.AxisSpace axisSpace5 = null;
        combinedDomainXYPlot0.setFixedDomainAxisSpace(axisSpace5);
        boolean boolean7 = combinedDomainXYPlot0.isDomainZoomable();
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = null;
        try {
            combinedDomainXYPlot0.setOrientation(plotOrientation8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.chart.util.SortOrder sortOrder1 = null;
        try {
            defaultPieDataset0.sortByValues(sortOrder1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=0,g=255,b=0]");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer2 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer2.clearSeriesStrokes(true);
        java.awt.Stroke stroke6 = xYBarRenderer2.lookupSeriesOutlineStroke(100);
        xYBarRenderer2.setShadowXOffset((double) 100.0f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState11 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo10);
        java.awt.geom.Line2D line2D12 = xYItemRendererState11.workingLine;
        xYBarRenderer2.setLegendShape(0, (java.awt.Shape) line2D12);
        numberAxis1.setRightArrow((java.awt.Shape) line2D12);
        org.jfree.chart.axis.TickUnitSource tickUnitSource15 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        numberAxis1.setStandardTickUnits(tickUnitSource15);
        double double17 = numberAxis1.getUpperMargin();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(line2D12);
        org.junit.Assert.assertNotNull(tickUnitSource15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.05d + "'", double17 == 0.05d);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getBackgroundImageAlignment();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor6 = null;
        try {
            categoryPlot4.setDomainGridlinePosition(categoryAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection1, false);
        java.lang.Object obj4 = timeSeriesCollection1.clone();
        try {
            timeSeriesCollection1.setSelected(4, 10, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (4).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        int int2 = combinedDomainXYPlot0.getDomainAxisIndex(valueAxis1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = combinedDomainXYPlot0.getDomainAxisIndex(valueAxis3);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        combinedDomainXYPlot0.setRangeAxis(10, valueAxis6);
        boolean boolean8 = combinedDomainXYPlot0.canSelectByRegion();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        try {
            combinedDomainXYPlot0.zoomRangeAxes((double) (short) -1, (double) 3, plotRenderingInfo11, point2D12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0);
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        int int7 = categoryPlot6.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation9 = null;
        categoryPlot6.setRangeAxisLocation(100, axisLocation9);
        timeSeriesCollection1.removeChangeListener((org.jfree.data.general.DatasetChangeListener) categoryPlot6);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate13 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection1, true);
        boolean boolean14 = intervalXYDelegate13.isAutoWidth();
        intervalXYDelegate13.setFixedIntervalWidth((double) (short) 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        java.awt.Paint paint1 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer2 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer2.clearSeriesStrokes(true);
        java.awt.Stroke stroke6 = xYBarRenderer2.lookupSeriesOutlineStroke(100);
        xYBarRenderer2.setShadowXOffset((double) 100.0f);
        java.awt.Stroke stroke9 = xYBarRenderer2.getBaseOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.05d, paint1, stroke9);
        java.lang.Class class11 = null;
        try {
            java.util.EventListener[] eventListenerArray12 = valueMarker10.getListeners(class11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer0.setBaseLinesVisible(true);
        java.lang.Boolean boolean4 = xYStepRenderer0.getSeriesLinesVisible((int) (byte) 0);
        org.junit.Assert.assertNull(boolean4);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.data.time.DateRange dateRange0 = new org.jfree.data.time.DateRange();
        java.util.Date date1 = dateRange0.getLowerDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date4 = spreadsheetDate3.toDate();
        java.util.Date date5 = spreadsheetDate3.toDate();
        java.util.TimeZone timeZone6 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date5, timeZone6);
        org.jfree.chart.axis.TickUnitSource tickUnitSource8 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone6);
        java.util.Locale locale9 = null;
        try {
            org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date1, timeZone6, locale9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(tickUnitSource8);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState1 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo0);
        java.awt.geom.Line2D line2D2 = xYItemRendererState1.workingLine;
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        int int8 = categoryPlot7.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation10 = null;
        categoryPlot7.setRangeAxisLocation(100, axisLocation10);
        int int12 = categoryPlot7.getWeight();
        java.awt.Paint paint13 = categoryPlot7.getRangeGridlinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier14 = null;
        categoryPlot7.setDrawingSupplier(drawingSupplier14, false);
        org.jfree.chart.entity.PlotEntity plotEntity17 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape) line2D2, (org.jfree.chart.plot.Plot) categoryPlot7);
        java.lang.String str18 = plotEntity17.getURLText();
        org.junit.Assert.assertNotNull(line2D2);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(str18);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation(100, axisLocation7);
        int int9 = categoryPlot4.getWeight();
        java.awt.Paint paint10 = categoryPlot4.getRangeGridlinePaint();
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.data.Range range12 = categoryPlot4.getDataRange(valueAxis11);
        java.awt.Stroke stroke13 = categoryPlot4.getRangeMinorGridlineStroke();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D16 = new org.jfree.chart.axis.CategoryAxis3D("ERROR : Relative To String");
        categoryAxis3D16.clearCategoryLabelToolTips();
        categoryPlot4.setDomainAxis((int) '#', (org.jfree.chart.axis.CategoryAxis) categoryAxis3D16, false);
        categoryAxis3D16.setCategoryMargin((double) 7);
        java.lang.Comparable comparable22 = null;
        org.jfree.chart.text.TextBlock textBlock23 = new org.jfree.chart.text.TextBlock();
        java.util.List list24 = textBlock23.getLines();
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.title.TextTitle textTitle27 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle27.setMaximumLinesToDisplay(1);
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = null;
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis31, valueAxis32, categoryItemRenderer33);
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = categoryPlot34.getDomainAxisEdge();
        textTitle27.setPosition(rectangleEdge35);
        try {
            double double37 = categoryAxis3D16.getCategoryMiddle(comparable22, list24, rectangle2D25, rectangleEdge35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid category index: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(list24);
        org.junit.Assert.assertNotNull(rectangleEdge35);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        java.awt.Shape shape4 = null;
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, valueAxis7, categoryItemRenderer8);
        int int10 = categoryPlot9.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation12 = null;
        categoryPlot9.setRangeAxisLocation(100, axisLocation12);
        int int14 = categoryPlot9.getWeight();
        java.awt.Paint paint15 = categoryPlot9.getRangeGridlinePaint();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer16 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer16.clearSeriesStrokes(true);
        java.awt.Stroke stroke20 = xYBarRenderer16.lookupSeriesOutlineStroke(100);
        xYBarRenderer16.setShadowXOffset((double) 100.0f);
        java.awt.Stroke stroke23 = xYBarRenderer16.getBaseOutlineStroke();
        java.awt.Paint paint24 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("", "TextBlockAnchor.TOP_RIGHT", "{0}: ({1}, {2})", "", shape4, paint15, stroke23, paint24);
        java.awt.Color color26 = java.awt.Color.lightGray;
        legendItem25.setLabelPaint((java.awt.Paint) color26);
        java.awt.Shape shape28 = legendItem25.getShape();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer29 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        legendItem25.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer29);
        legendItem25.setDatasetIndex(1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNull(shape28);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("TextBlockAnchor.BOTTOM_RIGHT");
        periodAxis1.configure();
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        int int2 = combinedDomainXYPlot0.getDomainAxisIndex(valueAxis1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = combinedDomainXYPlot0.getRangeAxis();
        combinedDomainXYPlot0.setNotify(true);
        java.awt.geom.Point2D point2D6 = null;
        try {
            combinedDomainXYPlot0.setQuadrantOrigin(point2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'origin' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(valueAxis3);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=0,g=255,b=0]");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer2 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer2.clearSeriesStrokes(true);
        java.awt.Stroke stroke6 = xYBarRenderer2.lookupSeriesOutlineStroke(100);
        xYBarRenderer2.setShadowXOffset((double) 100.0f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState11 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo10);
        java.awt.geom.Line2D line2D12 = xYItemRendererState11.workingLine;
        xYBarRenderer2.setLegendShape(0, (java.awt.Shape) line2D12);
        numberAxis1.setRightArrow((java.awt.Shape) line2D12);
        org.jfree.chart.axis.TickUnitSource tickUnitSource15 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        numberAxis1.setStandardTickUnits(tickUnitSource15);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range18 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range19 = org.jfree.data.Range.combine(range17, range18);
        numberAxis1.setRange(range17, true, false);
        numberAxis1.configure();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(line2D12);
        org.junit.Assert.assertNotNull(tickUnitSource15);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNotNull(range19);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.clearSeriesStrokes(true);
        java.awt.Color color3 = java.awt.Color.CYAN;
        xYBarRenderer0.setBaseFillPaint((java.awt.Paint) color3, false);
        xYBarRenderer0.setUseYInterval(false);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("{0}", graphics2D1, (float) 1, (float) '4', (double) 10L, (float) (-2208960000000L), 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("ClassContext", "ClassContext", "ItemLabelAnchor.INSIDE7", "NO_CHANGE");
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.Color color1 = color0.darker();
        java.awt.image.ColorModel colorModel2 = null;
        java.awt.Rectangle rectangle3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.awt.geom.AffineTransform affineTransform5 = null;
        java.awt.RenderingHints renderingHints6 = null;
        java.awt.PaintContext paintContext7 = color0.createContext(colorModel2, rectangle3, rectangle2D4, affineTransform5, renderingHints6);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(paintContext7);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "", "ERROR : Relative To String", "hi!", "ERROR : Relative To String");
        basicProjectInfo5.setCopyright("ERROR : Relative To String");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo13 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "", "ERROR : Relative To String", "hi!", "ERROR : Relative To String");
        basicProjectInfo13.setCopyright("ERROR : Relative To String");
        basicProjectInfo5.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo13);
        basicProjectInfo13.setInfo("");
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        int int2 = combinedDomainXYPlot0.getDomainAxisIndex(valueAxis1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = combinedDomainXYPlot0.getRangeAxisIndex(valueAxis3);
        java.awt.Paint paint5 = combinedDomainXYPlot0.getDomainZeroBaselinePaint();
        java.awt.Stroke stroke6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        combinedDomainXYPlot0.setRangeZeroBaselineStroke(stroke6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = combinedDomainXYPlot0.getRendererForDataset(xYDataset8);
        java.awt.Paint paint10 = null;
        try {
            combinedDomainXYPlot0.setRangeGridlinePaint(paint10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(xYItemRenderer9);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        java.util.Date date3 = spreadsheetDate1.toDate();
        java.util.TimeZone timeZone4 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date3, timeZone4);
        java.util.Calendar calendar6 = null;
        try {
            long long7 = month5.getMiddleMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot2 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = combinedDomainXYPlot2.getDomainAxisIndex(valueAxis3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = combinedDomainXYPlot2.getRangeAxis();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("WMAP_Plot", font1, (org.jfree.chart.plot.Plot) combinedDomainXYPlot2, true);
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle9.setMaximumLinesToDisplay(1);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, categoryItemRenderer15);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot16.getDomainAxisEdge();
        textTitle9.setPosition(rectangleEdge17);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = textTitle9.getPadding();
        jFreeChart7.removeSubtitle((org.jfree.chart.title.Title) textTitle9);
        org.jfree.chart.title.LegendTitle legendTitle21 = jFreeChart7.getLegend();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = legendTitle21.getItemLabelPadding();
        java.awt.Font font23 = legendTitle21.getItemFont();
        org.jfree.chart.LegendItemSource[] legendItemSourceArray24 = null;
        try {
            legendTitle21.setSources(legendItemSourceArray24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'sources' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(legendTitle21);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(font23);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_BOTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("ERROR : Relative To String");
        categoryAxis3D1.clearCategoryLabelToolTips();
        categoryAxis3D1.configure();
        java.awt.Font font4 = categoryAxis3D1.getLabelFont();
        org.junit.Assert.assertNotNull(font4);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("DomainOrder.NONE", "", "java.awt.Color[r=0,g=255,b=0]", "");
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation(100, axisLocation7);
        int int9 = categoryPlot4.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = categoryPlot4.getDomainAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot4.zoomRangeAxes((double) 10.0f, plotRenderingInfo12, point2D13, false);
        org.jfree.data.category.CategoryDataset categoryDataset16 = categoryPlot4.getDataset();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNull(categoryDataset16);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, 0.0d, (double) 100);
        org.jfree.chart.ChartTheme chartTheme5 = org.jfree.chart.StandardChartTheme.createJFreeTheme();
        boolean boolean6 = columnArrangement4.equals((java.lang.Object) chartTheme5);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(chartTheme5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.awt.Image image1 = projectInfo0.getLogo();
        java.lang.String str2 = projectInfo0.getName();
        org.junit.Assert.assertNull(image1);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = categoryPlot4.getDomainAxisEdge();
        java.awt.Paint paint6 = categoryPlot4.getOutlinePaint();
        categoryPlot4.setBackgroundAlpha((float) 100L);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot4.setRangeAxis(valueAxis9);
        java.awt.Paint paint11 = categoryPlot4.getBackgroundPaint();
        categoryPlot4.clearAnnotations();
        categoryPlot4.clearRangeMarkers((int) '4');
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        try {
            java.lang.Number number3 = timeSeriesCollection0.getEndY((int) (byte) 1, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_STARTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        java.util.TimeZone timeZone0 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.junit.Assert.assertNotNull(timeZone0);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle1.setMaximumLinesToDisplay(1);
        double double4 = textTitle1.getHeight();
        textTitle1.visible = false;
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = textTitle1.getMargin();
        double double8 = rectangleInsets7.getLeft();
        double double10 = rectangleInsets7.calculateBottomOutset(0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.data.Range range2 = xYStepRenderer0.findDomainBounds(xYDataset1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = null;
        xYStepRenderer0.setBaseToolTipGenerator(xYToolTipGenerator3);
        boolean boolean5 = xYStepRenderer0.getBaseShapesVisible();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator6 = null;
        xYStepRenderer0.setBaseToolTipGenerator(xYToolTipGenerator6, true);
        java.awt.Stroke stroke10 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        xYStepRenderer0.setSeriesOutlineStroke((int) (short) 1, stroke10);
        boolean boolean14 = xYStepRenderer0.getItemLineVisible(10, (-9999));
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("TextBlockAnchor.TOP_RIGHT");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) "TextBlockAnchor.TOP_RIGHT");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo3 = seriesChangeEvent2.getSummary();
        org.junit.Assert.assertNull(seriesChangeInfo3);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        java.lang.Class class0 = null;
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date3 = spreadsheetDate2.toDate();
        java.util.TimeZone timeZone4 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date3, timeZone4);
        try {
            org.jfree.data.xy.XYSeries xYSeries6 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) regularTimePeriod5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(regularTimePeriod5);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getCurrencyInstance();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit((double) 100L, numberFormat1);
        numberFormat1.setMinimumFractionDigits(0);
        boolean boolean5 = numberFormat1.isParseIntegerOnly();
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType1 = rectangleConstraint0.getHeightConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = rectangleConstraint0.toFixedHeight(0.08d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType4 = rectangleConstraint3.getHeightConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = rectangleConstraint3.toUnconstrainedHeight();
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertNotNull(lengthConstraintType1);
        org.junit.Assert.assertNotNull(rectangleConstraint3);
        org.junit.Assert.assertNotNull(lengthConstraintType4);
        org.junit.Assert.assertNotNull(rectangleConstraint5);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation(100, axisLocation7);
        int int9 = categoryPlot4.getWeight();
        java.awt.Paint paint10 = categoryPlot4.getRangeGridlinePaint();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent11 = null;
        categoryPlot4.notifyListeners(plotChangeEvent11);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        try {
            categoryPlot4.drawOutline(graphics2D13, rectangle2D14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState5 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo4);
        java.awt.geom.Line2D line2D6 = xYItemRendererState5.workingLine;
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis9, categoryItemRenderer10);
        int int12 = categoryPlot11.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation14 = null;
        categoryPlot11.setRangeAxisLocation(100, axisLocation14);
        int int16 = categoryPlot11.getWeight();
        java.awt.Paint paint17 = categoryPlot11.getRangeGridlinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = null;
        categoryPlot11.setDrawingSupplier(drawingSupplier18, false);
        org.jfree.chart.entity.PlotEntity plotEntity21 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape) line2D6, (org.jfree.chart.plot.Plot) categoryPlot11);
        java.awt.Stroke stroke22 = null;
        java.awt.Paint paint23 = null;
        try {
            org.jfree.chart.LegendItem legendItem24 = new org.jfree.chart.LegendItem("null", "NO_CHANGE", "$8.00", "series", (java.awt.Shape) line2D6, stroke22, paint23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'lineStroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(line2D6);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("[Dec 31, 1969 3:59:59 PM --> Dec 31, 1969 4:00:00 PM]", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        int int2 = combinedDomainXYPlot0.getDomainAxisIndex(valueAxis1);
        org.jfree.chart.axis.AxisLocation axisLocation4 = null;
        combinedDomainXYPlot0.setDomainAxisLocation((int) (byte) 1, axisLocation4);
        org.jfree.chart.LegendItemCollection legendItemCollection6 = null;
        combinedDomainXYPlot0.setFixedLegendItems(legendItemCollection6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        combinedDomainXYPlot0.panDomainAxes((double) 0.0f, plotRenderingInfo9, point2D10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer0.setBaseLinesVisible(true);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator4 = xYStepRenderer0.getSeriesItemLabelGenerator((int) '#');
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator8 = xYStepRenderer0.getItemLabelGenerator((int) (byte) 100, (-1), false);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator9 = null;
        xYStepRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator9);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator14 = xYStepRenderer0.getURLGenerator((int) (short) 0, (int) (short) -1, true);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator15 = null;
        xYStepRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator15);
        org.junit.Assert.assertNull(xYItemLabelGenerator4);
        org.junit.Assert.assertNull(xYItemLabelGenerator8);
        org.junit.Assert.assertNull(xYURLGenerator14);
    }

//    @Test
//    public void test388() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test388");
//        org.jfree.data.time.TimeSeries timeSeries0 = null;
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date4 = spreadsheetDate3.toDate();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        long long7 = day6.getLastMillisecond();
//        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("$8.00", (org.jfree.data.time.RegularTimePeriod) day5, (org.jfree.data.time.RegularTimePeriod) day6);
//        java.lang.String str9 = periodAxis8.getLabelToolTip();
//        java.util.TimeZone timeZone10 = periodAxis8.getTimeZone();
//        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection11 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone10);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560495599999L + "'", long7 == 1560495599999L);
//        org.junit.Assert.assertNull(str9);
//        org.junit.Assert.assertNotNull(timeZone10);
//    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection1, false);
        java.lang.Object obj4 = timeSeriesCollection1.clone();
        java.lang.Object obj5 = timeSeriesCollection1.clone();
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation(100, axisLocation7);
        int int9 = categoryPlot4.getWeight();
        java.awt.Paint paint10 = categoryPlot4.getRangeGridlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation12 = null;
        try {
            categoryPlot4.setDomainAxisLocation((int) (short) -1, axisLocation12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.data.function.Function2D function2D0 = null;
        java.lang.Comparable comparable4 = null;
        try {
            org.jfree.data.xy.XYDataset xYDataset5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, (double) (-10289251), (double) 100, 10, comparable4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType1 = rectangleConstraint0.getHeightConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = rectangleConstraint0.toFixedHeight(0.08d);
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine();
        org.jfree.chart.text.TextFragment textFragment5 = null;
        textLine4.removeFragment(textFragment5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.util.Size2D size2D8 = textLine4.calculateDimensions(graphics2D7);
        size2D8.height = (short) 0;
        size2D8.height = 3;
        double double13 = size2D8.getHeight();
        org.jfree.chart.util.Size2D size2D14 = rectangleConstraint0.calculateConstrainedSize(size2D8);
        double double15 = size2D8.width;
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertNotNull(lengthConstraintType1);
        org.junit.Assert.assertNotNull(rectangleConstraint3);
        org.junit.Assert.assertNotNull(size2D8);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 3.0d + "'", double13 == 3.0d);
        org.junit.Assert.assertNotNull(size2D14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0);
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        int int7 = categoryPlot6.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation9 = null;
        categoryPlot6.setRangeAxisLocation(100, axisLocation9);
        timeSeriesCollection1.removeChangeListener((org.jfree.data.general.DatasetChangeListener) categoryPlot6);
        timeSeriesCollection1.validateObject();
        try {
            int[] intArray16 = org.jfree.chart.renderer.RendererUtilities.findLiveItems((org.jfree.data.xy.XYDataset) timeSeriesCollection1, (-458), Double.NaN, (double) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (-458).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=0,g=255,b=0]");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer2 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer2.clearSeriesStrokes(true);
        java.awt.Stroke stroke6 = xYBarRenderer2.lookupSeriesOutlineStroke(100);
        xYBarRenderer2.setShadowXOffset((double) 100.0f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState11 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo10);
        java.awt.geom.Line2D line2D12 = xYItemRendererState11.workingLine;
        xYBarRenderer2.setLegendShape(0, (java.awt.Shape) line2D12);
        numberAxis1.setRightArrow((java.awt.Shape) line2D12);
        numberAxis1.setMinorTickMarksVisible(true);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot17 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        int int19 = combinedDomainXYPlot17.getDomainAxisIndex(valueAxis18);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        int int21 = combinedDomainXYPlot17.getRangeAxisIndex(valueAxis20);
        java.awt.Paint paint22 = combinedDomainXYPlot17.getDomainZeroBaselinePaint();
        boolean boolean23 = combinedDomainXYPlot17.isDomainZeroBaselineVisible();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder24 = combinedDomainXYPlot17.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation25 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        combinedDomainXYPlot17.setRangeAxisLocation(axisLocation25, true);
        numberAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) combinedDomainXYPlot17);
        try {
            numberAxis1.zoomRange(100.0d, (double) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (100.0) <= upper (-1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(line2D12);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(seriesRenderingOrder24);
        org.junit.Assert.assertNotNull(axisLocation25);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = categoryPlot4.getDomainAxisEdge();
        boolean boolean6 = categoryPlot4.isRangeGridlinesVisible();
        boolean boolean7 = categoryPlot4.isRangeZoomable();
        int int8 = categoryPlot4.getCrosshairDatasetIndex();
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.data.Range range2 = xYStepRenderer0.findDomainBounds(xYDataset1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = null;
        xYStepRenderer0.setBaseToolTipGenerator(xYToolTipGenerator3);
        boolean boolean5 = xYStepRenderer0.getBaseShapesVisible();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator6 = null;
        xYStepRenderer0.setBaseToolTipGenerator(xYToolTipGenerator6, true);
        java.awt.Color color10 = java.awt.Color.lightGray;
        xYStepRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color10);
        xYStepRenderer0.setBaseShapesFilled(true);
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date5 = spreadsheetDate4.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date8 = spreadsheetDate7.toDate();
        boolean boolean9 = spreadsheetDate4.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate7);
        boolean boolean10 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date13 = spreadsheetDate12.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date16 = spreadsheetDate15.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date19 = spreadsheetDate18.toDate();
        boolean boolean20 = spreadsheetDate15.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate18);
        boolean boolean21 = spreadsheetDate12.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean25 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate12, (org.jfree.data.time.SerialDate) spreadsheetDate23, 0);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate23);
        java.util.Calendar calendar27 = null;
        try {
            long long28 = day26.getLastMillisecond(calendar27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.data.Range range2 = xYStepRenderer0.findDomainBounds(xYDataset1);
        java.awt.Shape shape4 = null;
        xYStepRenderer0.setSeriesShape((int) ' ', shape4, false);
        boolean boolean7 = xYStepRenderer0.getBaseLinesVisible();
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0);
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        int int7 = categoryPlot6.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation9 = null;
        categoryPlot6.setRangeAxisLocation(100, axisLocation9);
        timeSeriesCollection1.removeChangeListener((org.jfree.data.general.DatasetChangeListener) categoryPlot6);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate13 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection1, true);
        try {
            java.lang.Number number16 = intervalXYDelegate13.getEndX(2147483647, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2147483647, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle1.setMaximumLinesToDisplay(1);
        textTitle1.setText("ClassContext");
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        int int0 = org.jfree.data.time.SerialDate.SATURDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer0.setBaseLinesVisible(true);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator4 = xYStepRenderer0.getSeriesItemLabelGenerator((int) '#');
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator8 = xYStepRenderer0.getItemLabelGenerator((int) (byte) 100, (-1), false);
        int int9 = xYStepRenderer0.getPassCount();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation10 = null;
        boolean boolean11 = xYStepRenderer0.removeAnnotation(xYAnnotation10);
        org.junit.Assert.assertNull(xYItemLabelGenerator4);
        org.junit.Assert.assertNull(xYItemLabelGenerator8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.chart.axis.SegmentedTimeline.FIRST_MONDAY_AFTER_1900 = 100;
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState1 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo0);
        int int2 = xYItemRendererState1.getFirstItemIndex();
        java.awt.Font font4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot5 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        int int7 = combinedDomainXYPlot5.getDomainAxisIndex(valueAxis6);
        org.jfree.chart.axis.ValueAxis valueAxis8 = combinedDomainXYPlot5.getRangeAxis();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("WMAP_Plot", font4, (org.jfree.chart.plot.Plot) combinedDomainXYPlot5, true);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent11 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) int2, jFreeChart10);
        java.util.List list12 = null;
        try {
            jFreeChart10.setSubtitles(list12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'subtitles' argument.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNull(valueAxis8);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(9999);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("TextBlockAnchor.TOP_RIGHT");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer2 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer2.clearSeriesStrokes(true);
        java.awt.Stroke stroke6 = xYBarRenderer2.lookupSeriesOutlineStroke(100);
        xYBarRenderer2.setShadowXOffset((double) 100.0f);
        java.awt.Stroke stroke9 = xYBarRenderer2.getBaseOutlineStroke();
        java.awt.Paint paint10 = xYBarRenderer2.getBasePaint();
        labelBlock1.setPaint(paint10);
        java.lang.String str12 = labelBlock1.getToolTipText();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getBackgroundImageAlignment();
        java.awt.Image image6 = null;
        categoryPlot4.setBackgroundImage(image6);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0);
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        int int7 = categoryPlot6.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation9 = null;
        categoryPlot6.setRangeAxisLocation(100, axisLocation9);
        timeSeriesCollection1.removeChangeListener((org.jfree.data.general.DatasetChangeListener) categoryPlot6);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate13 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection1, true);
        boolean boolean14 = intervalXYDelegate13.isAutoWidth();
        intervalXYDelegate13.setFixedIntervalWidth((double) '4');
        try {
            java.lang.Number number19 = intervalXYDelegate13.getStartX(8, 2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        int int2 = combinedDomainXYPlot0.getDomainAxisIndex(valueAxis1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = combinedDomainXYPlot0.getRangeAxis();
        combinedDomainXYPlot0.setNotify(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        combinedDomainXYPlot0.panDomainAxes((double) (-9999), plotRenderingInfo7, point2D8);
        boolean boolean10 = combinedDomainXYPlot0.canSelectByPoint();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(false);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        org.jfree.chart.text.TextFragment textFragment1 = null;
        textLine0.removeFragment(textFragment1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.util.Size2D size2D4 = textLine0.calculateDimensions(graphics2D3);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, valueAxis7, categoryItemRenderer8);
        categoryPlot9.setRangeCrosshairValue(0.0d);
        int int12 = categoryPlot9.getRendererCount();
        boolean boolean13 = textLine0.equals((java.lang.Object) categoryPlot9);
        org.junit.Assert.assertNotNull(size2D4);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle1.setMaximumLinesToDisplay(1);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = categoryPlot8.getDomainAxisEdge();
        textTitle1.setPosition(rectangleEdge9);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment11 = textTitle1.getTextAlignment();
        boolean boolean13 = horizontalAlignment11.equals((java.lang.Object) 0.05d);
        java.lang.String str14 = horizontalAlignment11.toString();
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertNotNull(horizontalAlignment11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "HorizontalAlignment.CENTER" + "'", str14.equals("HorizontalAlignment.CENTER"));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation(100, axisLocation7);
        int int9 = categoryPlot4.getWeight();
        java.awt.Paint paint10 = categoryPlot4.getRangeGridlinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier11 = null;
        categoryPlot4.setDrawingSupplier(drawingSupplier11, false);
        boolean boolean14 = categoryPlot4.isSubplot();
        categoryPlot4.setRangeZeroBaselineVisible(true);
        java.awt.Paint paint18 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer19 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer19.clearSeriesStrokes(true);
        java.awt.Stroke stroke23 = xYBarRenderer19.lookupSeriesOutlineStroke(100);
        xYBarRenderer19.setShadowXOffset((double) 100.0f);
        java.awt.Stroke stroke26 = xYBarRenderer19.getBaseOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker(0.05d, paint18, stroke26);
        org.jfree.chart.text.TextAnchor textAnchor28 = valueMarker27.getLabelTextAnchor();
        boolean boolean29 = categoryPlot4.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker27);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(textAnchor28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType4 = rectangleConstraint3.getHeightConstraintType();
        org.jfree.chart.util.Size2D size2D5 = borderArrangement0.arrange(blockContainer1, graphics2D2, rectangleConstraint3);
        org.jfree.chart.block.BlockFrame blockFrame6 = blockContainer1.getFrame();
        org.junit.Assert.assertNotNull(rectangleConstraint3);
        org.junit.Assert.assertNotNull(lengthConstraintType4);
        org.junit.Assert.assertNotNull(size2D5);
        org.junit.Assert.assertNotNull(blockFrame6);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer0.setBaseLinesVisible(true);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator4 = xYStepRenderer0.getSeriesItemLabelGenerator((int) '#');
        xYStepRenderer0.removeAnnotations();
        org.junit.Assert.assertNull(xYItemLabelGenerator4);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        java.lang.String str0 = org.jfree.chart.labels.StandardXYSeriesLabelGenerator.DEFAULT_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(false);
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("TextBlockAnchor.TOP_RIGHT");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        int int8 = categoryPlot7.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation10 = null;
        categoryPlot7.setRangeAxisLocation(100, axisLocation10);
        int int12 = categoryPlot7.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = categoryPlot7.getDomainAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Point2D point2D16 = null;
        categoryPlot7.zoomRangeAxes((double) 10.0f, plotRenderingInfo15, point2D16, false);
        boolean boolean19 = textBlockAnchor2.equals((java.lang.Object) point2D16);
        labelBlock1.setContentAlignmentPoint(textBlockAnchor2);
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=0,g=255,b=0]");
        numberAxis1.setRangeAboutValue((double) (-1.0f), (double) (byte) 0);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.AxisState axisState6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis10, categoryItemRenderer11);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = categoryPlot12.getDomainAxisEdge();
        try {
            java.util.List list14 = numberAxis1.refreshTicks(graphics2D5, axisState6, rectangle2D7, rectangleEdge13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge13);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.lang.Object obj1 = standardPieSectionLabelGenerator0.clone();
        java.text.NumberFormat numberFormat2 = standardPieSectionLabelGenerator0.getNumberFormat();
        java.lang.Object obj3 = standardPieSectionLabelGenerator0.clone();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(numberFormat2);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_UPPER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2958465 + "'", int0 == 2958465);
    }

//    @Test
//    public void test425() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test425");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date3 = spreadsheetDate2.toDate();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        long long6 = day5.getLastMillisecond();
//        org.jfree.chart.axis.PeriodAxis periodAxis7 = new org.jfree.chart.axis.PeriodAxis("$8.00", (org.jfree.data.time.RegularTimePeriod) day4, (org.jfree.data.time.RegularTimePeriod) day5);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date10 = spreadsheetDate9.toDate();
//        java.util.Date date11 = spreadsheetDate9.toDate();
//        java.util.TimeZone timeZone12 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date11, timeZone12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month13.previous();
//        periodAxis7.setFirst((org.jfree.data.time.RegularTimePeriod) month13);
//        int int16 = month13.getYearValue();
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560495599999L + "'", long6 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(timeZone12);
//        org.junit.Assert.assertNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1900 + "'", int16 == 1900);
//    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.clearSeriesStrokes(true);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator3 = xYBarRenderer0.getBaseItemLabelGenerator();
        java.awt.Paint paint5 = xYBarRenderer0.lookupSeriesPaint(9999);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = xYBarRenderer0.getSeriesNegativeItemLabelPosition(6);
        org.jfree.data.time.TimeSeries timeSeries8 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection9 = new org.jfree.data.time.TimeSeriesCollection(timeSeries8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, valueAxis12, categoryItemRenderer13);
        int int15 = categoryPlot14.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation17 = null;
        categoryPlot14.setRangeAxisLocation(100, axisLocation17);
        timeSeriesCollection9.removeChangeListener((org.jfree.data.general.DatasetChangeListener) categoryPlot14);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate21 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection9, true);
        org.jfree.data.Range range22 = xYBarRenderer0.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection9);
        try {
            int int26 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset) timeSeriesCollection9, (int) (byte) 100, (double) (-9999), 9.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (100).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYItemLabelGenerator3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNull(range22);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.general.DatasetGroup datasetGroup1 = timeSeriesCollection0.getGroup();
        java.lang.String str2 = datasetGroup1.getID();
        org.junit.Assert.assertNotNull(datasetGroup1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "NOID" + "'", str2.equals("NOID"));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.HOUR_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 3600000L + "'", long0 == 3600000L);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle1.setMaximumLinesToDisplay(1);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = categoryPlot8.getDomainAxisEdge();
        textTitle1.setPosition(rectangleEdge9);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment11 = textTitle1.getTextAlignment();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState13 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo12);
        int int14 = xYItemRendererState13.getFirstItemIndex();
        boolean boolean15 = horizontalAlignment11.equals((java.lang.Object) xYItemRendererState13);
        org.jfree.chart.plot.XYCrosshairState xYCrosshairState16 = xYItemRendererState13.getCrosshairState();
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertNotNull(horizontalAlignment11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(xYCrosshairState16);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        java.lang.Double double0 = org.jfree.chart.renderer.AbstractRenderer.ZERO;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.0d + "'", double0.equals(0.0d));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_OUTSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 2.0f + "'", float0 == 2.0f);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        java.text.NumberFormat numberFormat2 = java.text.NumberFormat.getCurrencyInstance();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = new org.jfree.chart.axis.NumberTickUnit((double) 100L, numberFormat2);
        java.lang.String str5 = numberFormat2.format((long) 8);
        boolean boolean6 = numberFormat2.isGroupingUsed();
        int int7 = numberFormat2.getMaximumFractionDigits();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit9 = new org.jfree.chart.axis.NumberTickUnit((double) 0.0f, numberFormat2, 2147483647);
        int int10 = numberFormat2.getMaximumIntegerDigits();
        org.junit.Assert.assertNotNull(numberFormat2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "$8.00" + "'", str5.equals("$8.00"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getCurrencyInstance();
        boolean boolean1 = numberFormat0.isParseIntegerOnly();
        java.lang.String str3 = numberFormat0.format((double) (-1L));
        java.util.Currency currency4 = null;
        try {
            numberFormat0.setCurrency(currency4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "($1.00)" + "'", str3.equals("($1.00)"));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.data.Range range4 = xYStepRenderer2.findDomainBounds(xYDataset3);
        java.awt.Color color7 = org.jfree.chart.util.PaintUtilities.stringToColor("ERROR : Relative To String");
        xYStepRenderer2.setSeriesOutlinePaint(1, (java.awt.Paint) color7);
        org.jfree.chart.text.TextLine textLine9 = new org.jfree.chart.text.TextLine("ItemLabelAnchor.INSIDE7", font1, (java.awt.Paint) color7);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) (short) -1, (float) 1L);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D8 = new org.jfree.chart.axis.CategoryAxis3D("ERROR : Relative To String");
        categoryAxis3D8.setCategoryMargin((double) 10L);
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryAxis3D8, jFreeChart11, chartChangeEventType12);
        java.awt.Paint paint15 = categoryAxis3D8.getTickLabelPaint((java.lang.Comparable) '#');
        try {
            org.jfree.chart.LegendItem legendItem16 = new org.jfree.chart.LegendItem(attributedString0, "NOID", "NO_CHANGE", "SerialDate.weekInMonthToString(): invalid code.", shape6, paint15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj2 = objectList0.get(6);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 255);
        java.lang.Object obj7 = timeSeriesDataItem6.clone();
        objectList0.set(8, obj7);
        org.junit.Assert.assertNull(obj2);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState1 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo0);
        int int2 = xYItemRendererState1.getFirstItemIndex();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState4 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo3);
        java.awt.geom.Line2D line2D5 = xYItemRendererState4.workingLine;
        xYItemRendererState1.workingLine = line2D5;
        org.jfree.chart.plot.XYCrosshairState xYCrosshairState7 = null;
        xYItemRendererState1.setCrosshairState(xYCrosshairState7);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(line2D5);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("TextBlockAnchor.TOP_RIGHT");
        java.lang.Throwable[] throwableArray2 = unknownKeyException1.getSuppressed();
        org.jfree.data.UnknownKeyException unknownKeyException4 = new org.jfree.data.UnknownKeyException("TextBlockAnchor.TOP_RIGHT");
        unknownKeyException1.addSuppressed((java.lang.Throwable) unknownKeyException4);
        java.lang.String str6 = unknownKeyException4.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.UnknownKeyException: TextBlockAnchor.TOP_RIGHT" + "'", str6.equals("org.jfree.data.UnknownKeyException: TextBlockAnchor.TOP_RIGHT"));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(1, (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.clearSeriesStrokes(true);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator3 = xYBarRenderer0.getBaseItemLabelGenerator();
        java.awt.Color color4 = java.awt.Color.green;
        xYBarRenderer0.setBasePaint((java.awt.Paint) color4);
        java.awt.Font font8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot9 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        int int11 = combinedDomainXYPlot9.getDomainAxisIndex(valueAxis10);
        org.jfree.chart.axis.ValueAxis valueAxis12 = combinedDomainXYPlot9.getRangeAxis();
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("WMAP_Plot", font8, (org.jfree.chart.plot.Plot) combinedDomainXYPlot9, true);
        boolean boolean15 = jFreeChart14.getAntiAlias();
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        textTitle17.setPadding(rectangleInsets18);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = textTitle17.getMargin();
        jFreeChart14.setPadding(rectangleInsets20);
        java.awt.Color color22 = java.awt.Color.white;
        jFreeChart14.setBorderPaint((java.awt.Paint) color22);
        xYBarRenderer0.setSeriesOutlinePaint(15, (java.awt.Paint) color22, true);
        org.junit.Assert.assertNull(xYItemLabelGenerator3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(color22);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(0);
        org.jfree.data.DomainOrder domainOrder3 = org.jfree.data.DomainOrder.ASCENDING;
        try {
            objectList1.set((int) (byte) 10, (java.lang.Object) domainOrder3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(domainOrder3);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getInstance();
        org.junit.Assert.assertNotNull(numberFormat0);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        java.awt.Paint paint0 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.data.general.DatasetGroup datasetGroup2 = timeSeriesCollection1.getGroup();
        org.jfree.data.general.DatasetGroup datasetGroup3 = timeSeriesCollection1.getGroup();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) datasetGroup3);
        org.junit.Assert.assertNotNull(datasetGroup2);
        org.junit.Assert.assertNotNull(datasetGroup3);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.data.Range range2 = xYStepRenderer0.findDomainBounds(xYDataset1);
        int int3 = xYStepRenderer0.getPassCount();
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2 + "'", int3 == 2);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange((-1.0d), (double) (byte) 100);
        org.jfree.data.Range range5 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange2, (double) '4', false);
        org.jfree.data.Range range7 = org.jfree.data.Range.shift(range5, (double) 2958465);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(range7);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.clearSeriesStrokes(true);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator3 = xYBarRenderer0.getBaseItemLabelGenerator();
        java.awt.Paint paint5 = xYBarRenderer0.lookupSeriesPaint(9999);
        org.jfree.chart.LegendItemCollection legendItemCollection6 = xYBarRenderer0.getLegendItems();
        org.junit.Assert.assertNull(xYItemLabelGenerator3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(legendItemCollection6);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        int int2 = combinedDomainXYPlot0.getDomainAxisIndex(valueAxis1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = combinedDomainXYPlot0.getRangeAxisIndex(valueAxis3);
        java.awt.Paint paint5 = combinedDomainXYPlot0.getDomainZeroBaselinePaint();
        java.awt.Stroke stroke6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        combinedDomainXYPlot0.setRangeZeroBaselineStroke(stroke6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = combinedDomainXYPlot0.getRendererForDataset(xYDataset8);
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        combinedDomainXYPlot0.drawAnnotations(graphics2D10, rectangle2D11, plotRenderingInfo12);
        float float14 = combinedDomainXYPlot0.getForegroundAlpha();
        combinedDomainXYPlot0.setRangeCrosshairLockedOnData(true);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 1.0f + "'", float14 == 1.0f);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("ERROR : Relative To String");
        categoryAxis3D1.setCategoryMargin((double) 10L);
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryAxis3D1, jFreeChart4, chartChangeEventType5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, valueAxis13, categoryItemRenderer14);
        int int16 = categoryPlot15.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation18 = null;
        categoryPlot15.setRangeAxisLocation(100, axisLocation18);
        int int20 = categoryPlot15.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = categoryPlot15.getDomainAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        try {
            org.jfree.chart.axis.AxisState axisState23 = categoryAxis3D1.draw(graphics2D7, (double) (-4126), rectangle2D9, rectangle2D10, rectangleEdge21, plotRenderingInfo22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge21);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation(100, axisLocation7);
        int int9 = categoryPlot4.getWeight();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        int int11 = categoryPlot4.getIndexOf(categoryItemRenderer10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        categoryPlot4.rendererChanged(rendererChangeEvent12);
        org.jfree.chart.axis.AxisLocation axisLocation15 = categoryPlot4.getRangeAxisLocation((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(axisLocation15);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        categoryPlot4.setDataset(categoryDataset5);
        boolean boolean7 = categoryPlot4.isSubplot();
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer8 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer8.setBaseLinesVisible(true);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator12 = xYStepRenderer8.getSeriesItemLabelGenerator((int) '#');
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator16 = xYStepRenderer8.getItemLabelGenerator((int) (byte) 100, (-1), false);
        java.awt.Shape shape18 = xYStepRenderer8.getSeriesShape((int) '#');
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent19 = null;
        xYStepRenderer8.notifyListeners(rendererChangeEvent19);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer21 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.data.Range range23 = xYStepRenderer21.findDomainBounds(xYDataset22);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator24 = null;
        xYStepRenderer21.setBaseToolTipGenerator(xYToolTipGenerator24);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition29 = xYStepRenderer21.getPositiveItemLabelPosition((int) (short) -1, (-458), false);
        xYStepRenderer8.setBaseNegativeItemLabelPosition(itemLabelPosition29, true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer32 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer32.clearSeriesStrokes(true);
        java.awt.Paint paint36 = xYBarRenderer32.getSeriesFillPaint((int) '#');
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator37 = xYBarRenderer32.getLegendItemURLGenerator();
        java.awt.Paint paint41 = xYBarRenderer32.getItemFillPaint((int) ' ', (int) (byte) -1, true);
        xYStepRenderer8.setBasePaint(paint41, true);
        categoryPlot4.setRangeCrosshairPaint(paint41);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(xYItemLabelGenerator12);
        org.junit.Assert.assertNull(xYItemLabelGenerator16);
        org.junit.Assert.assertNull(shape18);
        org.junit.Assert.assertNull(range23);
        org.junit.Assert.assertNotNull(itemLabelPosition29);
        org.junit.Assert.assertNull(paint36);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator37);
        org.junit.Assert.assertNotNull(paint41);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        java.util.Date date3 = spreadsheetDate1.toDate();
        try {
            org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate1.getNearestDayOfWeek((-458));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.data.time.TimeSeries timeSeries1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries1);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2, true);
        boolean boolean5 = verticalAlignment0.equals((java.lang.Object) range4);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=0,g=255,b=0]");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer8 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer8.clearSeriesStrokes(true);
        java.awt.Stroke stroke12 = xYBarRenderer8.lookupSeriesOutlineStroke(100);
        xYBarRenderer8.setShadowXOffset((double) 100.0f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState17 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo16);
        java.awt.geom.Line2D line2D18 = xYItemRendererState17.workingLine;
        xYBarRenderer8.setLegendShape(0, (java.awt.Shape) line2D18);
        numberAxis7.setRightArrow((java.awt.Shape) line2D18);
        org.jfree.chart.axis.TickUnitSource tickUnitSource21 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        numberAxis7.setStandardTickUnits(tickUnitSource21);
        org.jfree.data.Range range23 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range24 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range25 = org.jfree.data.Range.combine(range23, range24);
        numberAxis7.setRange(range23, true, false);
        boolean boolean29 = verticalAlignment0.equals((java.lang.Object) range23);
        org.junit.Assert.assertNotNull(verticalAlignment0);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(line2D18);
        org.junit.Assert.assertNotNull(tickUnitSource21);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isRadiusGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        try {
            polarPlot0.zoomRangeAxes((double) 9999, (double) 1.0f, plotRenderingInfo4, point2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation(100, axisLocation7);
        int int9 = categoryPlot4.getWeight();
        java.awt.Paint paint10 = categoryPlot4.getRangeGridlinePaint();
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.data.Range range12 = categoryPlot4.getDataRange(valueAxis11);
        java.awt.Stroke stroke13 = categoryPlot4.getRangeMinorGridlineStroke();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D16 = new org.jfree.chart.axis.CategoryAxis3D("ERROR : Relative To String");
        categoryAxis3D16.clearCategoryLabelToolTips();
        categoryPlot4.setDomainAxis((int) '#', (org.jfree.chart.axis.CategoryAxis) categoryAxis3D16, false);
        java.awt.Font font20 = categoryAxis3D16.getLabelFont();
        float float21 = categoryAxis3D16.getTickMarkOutsideLength();
        java.lang.String str22 = categoryAxis3D16.getLabelToolTip();
        categoryAxis3D16.setLabelToolTip("LengthConstraintType.FIXED");
        categoryAxis3D16.setUpperMargin((double) ' ');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 2.0f + "'", float21 == 2.0f);
        org.junit.Assert.assertNull(str22);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) 100);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) (short) -1, (float) 1L);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape2, rectangleAnchor3, (double) (short) 0, (double) 1);
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis9, categoryItemRenderer10);
        int int12 = categoryPlot11.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation14 = null;
        categoryPlot11.setRangeAxisLocation(100, axisLocation14);
        int int16 = categoryPlot11.getWeight();
        java.awt.Paint paint17 = categoryPlot11.getRangeGridlinePaint();
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.data.Range range19 = categoryPlot11.getDataRange(valueAxis18);
        java.awt.Stroke stroke20 = categoryPlot11.getRangeMinorGridlineStroke();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D23 = new org.jfree.chart.axis.CategoryAxis3D("ERROR : Relative To String");
        categoryAxis3D23.clearCategoryLabelToolTips();
        categoryPlot11.setDomainAxis((int) '#', (org.jfree.chart.axis.CategoryAxis) categoryAxis3D23, false);
        java.awt.Font font27 = categoryAxis3D23.getLabelFont();
        float float28 = categoryAxis3D23.getTickMarkInsideLength();
        org.jfree.chart.entity.AxisEntity axisEntity29 = new org.jfree.chart.entity.AxisEntity(shape2, (org.jfree.chart.axis.Axis) categoryAxis3D23);
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator30 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator31 = null;
        java.lang.String str32 = axisEntity29.getImageMapAreaTag(toolTipTagFragmentGenerator30, uRLTagFragmentGenerator31);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNull(range19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertTrue("'" + float28 + "' != '" + 0.0f + "'", float28 == 0.0f);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "" + "'", str32.equals(""));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 7);
        java.lang.String str2 = xYSeries1.getDescription();
        org.jfree.data.xy.XYSeries xYSeries5 = xYSeries1.createCopy(3, 5);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        xYSeries1.addPropertyChangeListener(propertyChangeListener6);
        boolean boolean8 = xYSeries1.getNotify();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(xYSeries5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer1 = new org.jfree.chart.text.G2TextMeasurer(graphics2D0);
        try {
            float float5 = g2TextMeasurer1.getStringWidth("ClassContext", 12, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.data.general.DatasetGroup datasetGroup2 = timeSeriesCollection1.getGroup();
        org.jfree.data.general.DatasetGroup datasetGroup3 = new org.jfree.data.general.DatasetGroup();
        timeSeriesCollection1.setGroup(datasetGroup3);
        try {
            int int6 = timeSeriesCollection1.getItemCount(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (1).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(datasetGroup2);
    }

//    @Test
//    public void test463() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test463");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date3 = spreadsheetDate2.toDate();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        long long6 = day5.getLastMillisecond();
//        org.jfree.chart.axis.PeriodAxis periodAxis7 = new org.jfree.chart.axis.PeriodAxis("$8.00", (org.jfree.data.time.RegularTimePeriod) day4, (org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.String str8 = periodAxis7.getLabelToolTip();
//        java.util.TimeZone timeZone9 = periodAxis7.getTimeZone();
//        java.awt.geom.Rectangle2D rectangle2D11 = null;
//        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, categoryItemRenderer15);
//        int int17 = categoryPlot16.getDomainAxisCount();
//        org.jfree.chart.axis.AxisLocation axisLocation19 = null;
//        categoryPlot16.setRangeAxisLocation(100, axisLocation19);
//        int int21 = categoryPlot16.getWeight();
//        org.jfree.chart.util.RectangleEdge rectangleEdge22 = categoryPlot16.getDomainAxisEdge();
//        org.jfree.chart.util.RectangleEdge rectangleEdge23 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge22);
//        try {
//            double double24 = periodAxis7.valueToJava2D((double) 15, rectangle2D11, rectangleEdge23);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560495599999L + "'", long6 == 1560495599999L);
//        org.junit.Assert.assertNull(str8);
//        org.junit.Assert.assertNotNull(timeZone9);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//        org.junit.Assert.assertNotNull(rectangleEdge22);
//        org.junit.Assert.assertNotNull(rectangleEdge23);
//    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date5 = spreadsheetDate4.toDate();
        boolean boolean6 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
        int int7 = spreadsheetDate4.getMonth();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("TextBlockAnchor.TOP_RIGHT");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        labelBlock1.setContentAlignmentPoint(textBlockAnchor2);
        labelBlock1.setWidth((double) 0.0f);
        java.lang.Object obj6 = labelBlock1.clone();
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = categoryPlot4.getDomainAxisEdge();
        java.awt.Paint paint6 = categoryPlot4.getOutlinePaint();
        categoryPlot4.setBackgroundAlpha((float) 100L);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot4.setRangeAxis(valueAxis9);
        java.awt.Paint paint11 = categoryPlot4.getDomainCrosshairPaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot4.zoomDomainAxes((double) 1L, (double) 8, plotRenderingInfo14, point2D15);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        int int2 = combinedDomainXYPlot0.getDomainAxisIndex(valueAxis1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = combinedDomainXYPlot0.getRangeAxisIndex(valueAxis3);
        java.awt.Paint paint5 = combinedDomainXYPlot0.getDomainZeroBaselinePaint();
        java.awt.Stroke stroke6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        combinedDomainXYPlot0.setRangeZeroBaselineStroke(stroke6);
        java.awt.Paint paint8 = combinedDomainXYPlot0.getDomainCrosshairPaint();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation9 = null;
        try {
            combinedDomainXYPlot0.addAnnotation(xYAnnotation9, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double1 = rectangleInsets0.getTop();
        double double3 = rectangleInsets0.calculateTopInset((double) (byte) 10);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.0d + "'", double3 == 3.0d);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        textTitle1.setPadding(rectangleInsets2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = textTitle1.getMargin();
        textTitle1.setNotify(false);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.block.BorderArrangement borderArrangement8 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.block.BlockContainer blockContainer9 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType12 = rectangleConstraint11.getHeightConstraintType();
        org.jfree.chart.util.Size2D size2D13 = borderArrangement8.arrange(blockContainer9, graphics2D10, rectangleConstraint11);
        org.jfree.data.time.DateRange dateRange14 = new org.jfree.data.time.DateRange();
        double double15 = dateRange14.getLength();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = rectangleConstraint11.toRangeWidth((org.jfree.data.Range) dateRange14);
        try {
            org.jfree.chart.util.Size2D size2D17 = textTitle1.arrange(graphics2D7, rectangleConstraint11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(rectangleConstraint11);
        org.junit.Assert.assertNotNull(lengthConstraintType12);
        org.junit.Assert.assertNotNull(size2D13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint16);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot4.setRangeAxisLocation(100, axisLocation7);
        org.jfree.chart.plot.Marker marker9 = null;
        org.jfree.chart.util.Layer layer10 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean11 = categoryPlot4.removeDomainMarker(marker9, layer10);
        boolean boolean12 = categoryPlot4.isRangePannable();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(layer10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle1.setMaximumLinesToDisplay(1);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = categoryPlot8.getDomainAxisEdge();
        textTitle1.setPosition(rectangleEdge9);
        double double11 = textTitle1.getContentXOffset();
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        int int2 = combinedDomainXYPlot0.getDomainAxisIndex(valueAxis1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = combinedDomainXYPlot0.getRangeAxisIndex(valueAxis3);
        java.awt.Paint paint5 = combinedDomainXYPlot0.getDomainZeroBaselinePaint();
        java.awt.Stroke stroke6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        combinedDomainXYPlot0.setRangeZeroBaselineStroke(stroke6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = combinedDomainXYPlot0.getRendererForDataset(xYDataset8);
        org.jfree.chart.axis.AxisLocation axisLocation11 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        combinedDomainXYPlot0.setRangeAxisLocation(0, axisLocation11);
        java.awt.Paint paint14 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer15 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer15.clearSeriesStrokes(true);
        java.awt.Stroke stroke19 = xYBarRenderer15.lookupSeriesOutlineStroke(100);
        xYBarRenderer15.setShadowXOffset((double) 100.0f);
        java.awt.Stroke stroke22 = xYBarRenderer15.getBaseOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker(0.05d, paint14, stroke22);
        java.awt.Paint paint24 = valueMarker23.getPaint();
        java.awt.Paint paint25 = null;
        valueMarker23.setOutlinePaint(paint25);
        org.jfree.chart.util.Layer layer27 = null;
        boolean boolean28 = combinedDomainXYPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker23, layer27);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.util.List list1 = textBlock0.getLines();
        try {
            java.util.Collection collection2 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list1);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.awt.Image image1 = projectInfo0.getLogo();
        projectInfo0.addOptionalLibrary("ERROR : Relative To String");
        projectInfo0.setVersion("series");
        org.jfree.chart.ui.ProjectInfo projectInfo6 = new org.jfree.chart.ui.ProjectInfo();
        java.awt.Image image7 = projectInfo6.getLogo();
        projectInfo6.setLicenceName("hi!");
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo6);
        projectInfo6.setName("ItemLabelAnchor.INSIDE7");
        org.junit.Assert.assertNull(image1);
        org.junit.Assert.assertNull(image7);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0);
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot3 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        int int5 = combinedDomainXYPlot3.getDomainAxisIndex(valueAxis4);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        int int7 = combinedDomainXYPlot3.getRangeAxisIndex(valueAxis6);
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        combinedDomainXYPlot3.setFixedRangeAxisSpace(axisSpace8, false);
        org.jfree.data.time.TimeSeries timeSeries11 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection12 = new org.jfree.data.time.TimeSeriesCollection(timeSeries11);
        org.jfree.data.Range range14 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection12, false);
        java.lang.Object obj15 = timeSeriesCollection12.clone();
        int int16 = combinedDomainXYPlot3.indexOf((org.jfree.data.xy.XYDataset) timeSeriesCollection12);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate18 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection12, false);
        timeSeriesCollection1.addChangeListener((org.jfree.data.general.DatasetChangeListener) intervalXYDelegate18);
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        int int2 = combinedDomainXYPlot0.getDomainAxisIndex(valueAxis1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = combinedDomainXYPlot0.getRangeAxis();
        combinedDomainXYPlot0.setNotify(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        combinedDomainXYPlot0.panDomainAxes((double) (-9999), plotRenderingInfo7, point2D8);
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.text.TextBlock textBlock12 = new org.jfree.chart.text.TextBlock();
        java.util.List list13 = textBlock12.getLines();
        combinedDomainXYPlot0.drawRangeTickBands(graphics2D10, rectangle2D11, list13);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(list13);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.data.Range range2 = xYStepRenderer0.findDomainBounds(xYDataset1);
        java.awt.Color color5 = org.jfree.chart.util.PaintUtilities.stringToColor("ERROR : Relative To String");
        xYStepRenderer0.setSeriesOutlinePaint(1, (java.awt.Paint) color5);
        java.awt.Paint paint7 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        xYStepRenderer0.setBaseLegendTextPaint(paint7);
        org.jfree.chart.block.BlockBorder blockBorder9 = new org.jfree.chart.block.BlockBorder(paint7);
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        try {
            blockBorder9.draw(graphics2D10, rectangle2D11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 6, (double) (byte) 10, (double) 2147483647, 0.0d);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot2 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = combinedDomainXYPlot2.getDomainAxisIndex(valueAxis3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = combinedDomainXYPlot2.getRangeAxis();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("WMAP_Plot", font1, (org.jfree.chart.plot.Plot) combinedDomainXYPlot2, true);
        boolean boolean8 = jFreeChart7.getAntiAlias();
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle10.setMaximumLinesToDisplay(1);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, categoryItemRenderer16);
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = categoryPlot17.getDomainAxisEdge();
        textTitle10.setPosition(rectangleEdge18);
        textTitle10.setPadding((double) '#', (double) (short) -1, 0.0d, (double) (byte) 10);
        boolean boolean25 = jFreeChart7.equals((java.lang.Object) (byte) 10);
        java.awt.Paint paint27 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer28 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer28.clearSeriesStrokes(true);
        java.awt.Stroke stroke32 = xYBarRenderer28.lookupSeriesOutlineStroke(100);
        xYBarRenderer28.setShadowXOffset((double) 100.0f);
        java.awt.Stroke stroke35 = xYBarRenderer28.getBaseOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker36 = new org.jfree.chart.plot.ValueMarker(0.05d, paint27, stroke35);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent37 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) stroke35);
        try {
            jFreeChart7.setTextAntiAlias((java.lang.Object) stroke35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: java.awt.BasicStroke@d1a0003e incompatible with Text-specific antialiasing enable key");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(stroke35);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.data.Range range2 = xYBarRenderer0.findRangeBounds(xYDataset1);
        double double3 = xYBarRenderer0.getShadowXOffset();
        xYBarRenderer0.setBaseCreateEntities(false);
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        textTitle1.setPadding(rectangleInsets2);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        textTitle1.draw(graphics2D4, rectangle2D5);
        java.lang.Object obj7 = textTitle1.clone();
        org.jfree.chart.util.VerticalAlignment verticalAlignment8 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.data.time.TimeSeries timeSeries9 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection10 = new org.jfree.data.time.TimeSeriesCollection(timeSeries9);
        org.jfree.data.Range range12 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection10, true);
        boolean boolean13 = verticalAlignment8.equals((java.lang.Object) range12);
        textTitle1.setVerticalAlignment(verticalAlignment8);
        textTitle1.setMaximumLinesToDisplay(1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(verticalAlignment8);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

//    @Test
//    public void test483() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test483");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date3 = spreadsheetDate2.toDate();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        long long6 = day5.getLastMillisecond();
//        org.jfree.chart.axis.PeriodAxis periodAxis7 = new org.jfree.chart.axis.PeriodAxis("$8.00", (org.jfree.data.time.RegularTimePeriod) day4, (org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.String str8 = periodAxis7.getLabelToolTip();
//        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, valueAxis11, categoryItemRenderer12);
//        int int14 = categoryPlot13.getDomainAxisCount();
//        org.jfree.chart.axis.AxisLocation axisLocation16 = null;
//        categoryPlot13.setRangeAxisLocation(100, axisLocation16);
//        org.jfree.chart.plot.Marker marker18 = null;
//        org.jfree.chart.util.Layer layer19 = org.jfree.chart.util.Layer.FOREGROUND;
//        boolean boolean20 = categoryPlot13.removeDomainMarker(marker18, layer19);
//        periodAxis7.setPlot((org.jfree.chart.plot.Plot) categoryPlot13);
//        java.awt.Graphics2D graphics2D22 = null;
//        java.awt.geom.Rectangle2D rectangle2D24 = null;
//        java.awt.geom.Rectangle2D rectangle2D25 = null;
//        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D27 = new org.jfree.chart.axis.CategoryAxis3D("ERROR : Relative To String");
//        categoryAxis3D27.clearCategoryLabelToolTips();
//        categoryAxis3D27.configure();
//        java.awt.Graphics2D graphics2D30 = null;
//        java.awt.geom.Rectangle2D rectangle2D32 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge33 = org.jfree.chart.util.RectangleEdge.RIGHT;
//        org.jfree.chart.axis.AxisState axisState34 = null;
//        categoryAxis3D27.drawTickMarks(graphics2D30, (double) (-1.0f), rectangle2D32, rectangleEdge33, axisState34);
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
//        try {
//            org.jfree.chart.axis.AxisState axisState37 = periodAxis7.draw(graphics2D22, (double) 2958465, rectangle2D24, rectangle2D25, rectangleEdge33, plotRenderingInfo36);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560495599999L + "'", long6 == 1560495599999L);
//        org.junit.Assert.assertNull(str8);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertNotNull(layer19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(rectangleEdge33);
//    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        java.lang.Class class1 = null;
        java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("java.awt.Color[r=0,g=255,b=0]", class1);
        org.junit.Assert.assertNull(inputStream2);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.setSeriesCreateEntities(31, (java.lang.Boolean) false, false);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot2 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = combinedDomainXYPlot2.getDomainAxisIndex(valueAxis3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = combinedDomainXYPlot2.getRangeAxis();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("WMAP_Plot", font1, (org.jfree.chart.plot.Plot) combinedDomainXYPlot2, true);
        boolean boolean8 = jFreeChart7.getAntiAlias();
        java.awt.Paint paint9 = jFreeChart7.getBorderPaint();
        java.awt.Image image10 = jFreeChart7.getBackgroundImage();
        jFreeChart7.setBackgroundImageAlpha((float) (-4126));
        org.jfree.chart.title.TextTitle textTitle13 = jFreeChart7.getTitle();
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.Color color16 = color15.darker();
        java.awt.Color color17 = java.awt.Color.getColor("$8.00", color16);
        jFreeChart7.setBorderPaint((java.awt.Paint) color16);
        java.awt.Image image19 = jFreeChart7.getBackgroundImage();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(image10);
        org.junit.Assert.assertNotNull(textTitle13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNull(image19);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        java.awt.Shape shape4 = null;
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, valueAxis7, categoryItemRenderer8);
        int int10 = categoryPlot9.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation12 = null;
        categoryPlot9.setRangeAxisLocation(100, axisLocation12);
        int int14 = categoryPlot9.getWeight();
        java.awt.Paint paint15 = categoryPlot9.getRangeGridlinePaint();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer16 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer16.clearSeriesStrokes(true);
        java.awt.Stroke stroke20 = xYBarRenderer16.lookupSeriesOutlineStroke(100);
        xYBarRenderer16.setShadowXOffset((double) 100.0f);
        java.awt.Stroke stroke23 = xYBarRenderer16.getBaseOutlineStroke();
        java.awt.Paint paint24 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("", "TextBlockAnchor.TOP_RIGHT", "{0}: ({1}, {2})", "", shape4, paint15, stroke23, paint24);
        java.awt.Color color26 = java.awt.Color.lightGray;
        legendItem25.setLabelPaint((java.awt.Paint) color26);
        java.awt.Shape shape28 = legendItem25.getShape();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer29 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        legendItem25.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer29);
        java.awt.GradientPaint gradientPaint31 = null;
        java.awt.Shape shape36 = null;
        org.jfree.data.category.CategoryDataset categoryDataset37 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = null;
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer40 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot(categoryDataset37, categoryAxis38, valueAxis39, categoryItemRenderer40);
        int int42 = categoryPlot41.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation44 = null;
        categoryPlot41.setRangeAxisLocation(100, axisLocation44);
        int int46 = categoryPlot41.getWeight();
        java.awt.Paint paint47 = categoryPlot41.getRangeGridlinePaint();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer48 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer48.clearSeriesStrokes(true);
        java.awt.Stroke stroke52 = xYBarRenderer48.lookupSeriesOutlineStroke(100);
        xYBarRenderer48.setShadowXOffset((double) 100.0f);
        java.awt.Stroke stroke55 = xYBarRenderer48.getBaseOutlineStroke();
        java.awt.Paint paint56 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem57 = new org.jfree.chart.LegendItem("", "TextBlockAnchor.TOP_RIGHT", "{0}: ({1}, {2})", "", shape36, paint47, stroke55, paint56);
        java.awt.Color color58 = java.awt.Color.lightGray;
        legendItem57.setLabelPaint((java.awt.Paint) color58);
        java.awt.Shape shape60 = legendItem57.getLine();
        try {
            java.awt.GradientPaint gradientPaint61 = standardGradientPaintTransformer29.transform(gradientPaint31, shape60);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNull(shape28);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNotNull(paint56);
        org.junit.Assert.assertNotNull(color58);
        org.junit.Assert.assertNotNull(shape60);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = categoryPlot4.getDomainAxisEdge();
        java.awt.Paint paint6 = categoryPlot4.getOutlinePaint();
        categoryPlot4.setBackgroundAlpha((float) 100L);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot4.setRangeAxis(valueAxis9);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        categoryPlot4.drawBackgroundImage(graphics2D11, rectangle2D12);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.data.general.DatasetGroup datasetGroup2 = timeSeriesCollection1.getGroup();
        org.jfree.data.general.DatasetGroup datasetGroup3 = timeSeriesCollection1.getGroup();
        try {
            double double6 = timeSeriesCollection1.getYValue((-1), 31);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(datasetGroup2);
        org.junit.Assert.assertNotNull(datasetGroup3);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer1 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.data.Range range3 = xYStepRenderer1.findDomainBounds(xYDataset2);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator4 = null;
        xYStepRenderer1.setBaseToolTipGenerator(xYToolTipGenerator4);
        boolean boolean6 = xYStepRenderer1.getBaseShapesVisible();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
        xYStepRenderer1.setBaseToolTipGenerator(xYToolTipGenerator7, true);
        java.text.DateFormat dateFormat11 = null;
        java.text.DateFormat dateFormat12 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator13 = new org.jfree.chart.labels.StandardXYToolTipGenerator("{0}: ({1}, {2})", dateFormat11, dateFormat12);
        xYStepRenderer1.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator13);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator15 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer16 = new org.jfree.chart.renderer.xy.XYAreaRenderer(3, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator13, xYURLGenerator15);
        boolean boolean17 = xYAreaRenderer16.getPlotLines();
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_START_ANGLE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 90.0d + "'", double0 == 90.0d);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        textTitle1.setPadding(rectangleInsets2);
        double double5 = rectangleInsets2.extendWidth(0.0d);
        double double7 = rectangleInsets2.calculateRightInset(0.0d);
        java.lang.String str8 = rectangleInsets2.toString();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str8.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        int int0 = org.jfree.data.time.SerialDate.FIRST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) (short) -1, (float) 1L);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape2, rectangleAnchor3, (double) (short) 0, (double) 1);
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis9, categoryItemRenderer10);
        int int12 = categoryPlot11.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation14 = null;
        categoryPlot11.setRangeAxisLocation(100, axisLocation14);
        int int16 = categoryPlot11.getWeight();
        java.awt.Paint paint17 = categoryPlot11.getRangeGridlinePaint();
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.data.Range range19 = categoryPlot11.getDataRange(valueAxis18);
        java.awt.Stroke stroke20 = categoryPlot11.getRangeMinorGridlineStroke();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D23 = new org.jfree.chart.axis.CategoryAxis3D("ERROR : Relative To String");
        categoryAxis3D23.clearCategoryLabelToolTips();
        categoryPlot11.setDomainAxis((int) '#', (org.jfree.chart.axis.CategoryAxis) categoryAxis3D23, false);
        java.awt.Font font27 = categoryAxis3D23.getLabelFont();
        float float28 = categoryAxis3D23.getTickMarkInsideLength();
        org.jfree.chart.entity.AxisEntity axisEntity29 = new org.jfree.chart.entity.AxisEntity(shape2, (org.jfree.chart.axis.Axis) categoryAxis3D23);
        boolean boolean30 = categoryAxis3D23.isTickLabelsVisible();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNull(range19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertTrue("'" + float28 + "' != '" + 0.0f + "'", float28 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isRadiusGridlinesVisible();
        java.awt.Color color2 = java.awt.Color.GREEN;
        java.awt.color.ColorSpace colorSpace3 = color2.getColorSpace();
        polarPlot0.setAngleGridlinePaint((java.awt.Paint) color2);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(colorSpace3);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        java.lang.Object obj1 = segmentedTimeline0.clone();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot2 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = combinedDomainXYPlot2.getDomainAxisIndex(valueAxis3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = combinedDomainXYPlot2.getRangeAxis();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("WMAP_Plot", font1, (org.jfree.chart.plot.Plot) combinedDomainXYPlot2, true);
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle9.setMaximumLinesToDisplay(1);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, categoryItemRenderer15);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot16.getDomainAxisEdge();
        textTitle9.setPosition(rectangleEdge17);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = textTitle9.getPadding();
        jFreeChart7.removeSubtitle((org.jfree.chart.title.Title) textTitle9);
        org.jfree.chart.title.LegendTitle legendTitle21 = jFreeChart7.getLegend();
        org.jfree.chart.block.BlockContainer blockContainer22 = legendTitle21.getItemContainer();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment23 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment24 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.ColumnArrangement columnArrangement27 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment23, verticalAlignment24, 0.0d, (double) 100);
        blockContainer22.setArrangement((org.jfree.chart.block.Arrangement) columnArrangement27);
        java.util.TimeZone timeZone29 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection30 = new org.jfree.data.time.TimeSeriesCollection(timeZone29);
        org.jfree.data.Range range32 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection30, true);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer34 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement27, (org.jfree.data.general.Dataset) timeSeriesCollection30, (java.lang.Comparable) 2147483647);
        legendItemBlockContainer34.setToolTipText("TextBlockAnchor.TOP_RIGHT");
        java.awt.Graphics2D graphics2D37 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint38 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.data.Range range39 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range40 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range41 = org.jfree.data.Range.combine(range39, range40);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint42 = rectangleConstraint38.toRangeWidth(range41);
        try {
            org.jfree.chart.util.Size2D size2D43 = legendItemBlockContainer34.arrange(graphics2D37, rectangleConstraint42);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(legendTitle21);
        org.junit.Assert.assertNotNull(blockContainer22);
        org.junit.Assert.assertNotNull(horizontalAlignment23);
        org.junit.Assert.assertNotNull(verticalAlignment24);
        org.junit.Assert.assertNull(range32);
        org.junit.Assert.assertNotNull(rectangleConstraint38);
        org.junit.Assert.assertNotNull(range39);
        org.junit.Assert.assertNotNull(range40);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(rectangleConstraint42);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        int int2 = combinedDomainXYPlot0.getDomainAxisIndex(valueAxis1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = combinedDomainXYPlot0.getRangeAxis();
        boolean boolean4 = combinedDomainXYPlot0.isSubplot();
        combinedDomainXYPlot0.setRangeMinorGridlinesVisible(false);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer7 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer7.clearSeriesStrokes(true);
        java.awt.Stroke stroke11 = xYBarRenderer7.lookupSeriesOutlineStroke(100);
        xYBarRenderer7.setShadowXOffset((double) 100.0f);
        java.awt.Stroke stroke14 = xYBarRenderer7.getBaseOutlineStroke();
        boolean boolean15 = xYBarRenderer7.getBaseItemLabelsVisible();
        combinedDomainXYPlot0.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer7);
        java.awt.Paint paint17 = combinedDomainXYPlot0.getRangeTickBandPaint();
        java.util.TimeZone timeZone19 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection20 = new org.jfree.data.time.TimeSeriesCollection(timeZone19);
        org.jfree.data.Range range22 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection20, true);
        combinedDomainXYPlot0.setDataset(1, (org.jfree.data.xy.XYDataset) timeSeriesCollection20);
        try {
            java.lang.Comparable comparable25 = timeSeriesCollection20.getSeriesKey((-458));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (-458).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertNull(range22);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("series");
    }
}

