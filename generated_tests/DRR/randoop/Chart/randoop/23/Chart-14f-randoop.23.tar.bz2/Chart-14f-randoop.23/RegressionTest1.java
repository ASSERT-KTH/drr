import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        float float4 = categoryAxis3.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        boolean boolean6 = dateAxis5.isAutoTickUnitSelection();
        org.jfree.data.Range range7 = dateAxis5.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot8 = dateAxis5.getPlot();
        dateAxis5.setLabelURL("hi!");
        dateAxis5.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer14);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        dateAxis16.setTickMarksVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource19 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis16.setStandardTickUnits(tickUnitSource19);
        java.text.DateFormat dateFormat21 = null;
        dateAxis16.setDateFormatOverride(dateFormat21);
        dateAxis16.setTickMarksVisible(true);
        dateAxis16.setRange((double) (-1L), 1.0E-8d);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis16, categoryItemRenderer28);
        java.util.List list30 = categoryPlot29.getCategories();
        categoryPlot29.clearRangeMarkers();
        java.awt.Paint[] paintArray32 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Paint[] paintArray33 = new java.awt.Paint[] {};
        java.awt.Stroke[] strokeArray34 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray35 = new java.awt.Stroke[] {};
        java.awt.Shape shape36 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape[] shapeArray37 = new java.awt.Shape[] { shape36 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier38 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray32, paintArray33, strokeArray34, strokeArray35, shapeArray37);
        java.awt.Stroke stroke39 = defaultDrawingSupplier38.getNextStroke();
        categoryPlot29.setRangeCrosshairStroke(stroke39);
        categoryPlot29.setRangeCrosshairVisible(false);
        int int43 = categoryPlot29.getDatasetCount();
        java.awt.Paint paint44 = null;
        try {
            categoryPlot29.setRangeCrosshairPaint(paint44);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(tickUnitSource19);
        org.junit.Assert.assertNull(list30);
        org.junit.Assert.assertNotNull(paintArray32);
        org.junit.Assert.assertNotNull(paintArray33);
        org.junit.Assert.assertNotNull(strokeArray34);
        org.junit.Assert.assertNotNull(strokeArray35);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(shapeArray37);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        xYPlot0.addChangeListener(plotChangeListener1);
        boolean boolean3 = xYPlot0.isDomainGridlinesVisible();
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        xYPlot5.addChangeListener(plotChangeListener6);
        java.awt.Paint paint8 = xYPlot5.getOutlinePaint();
        float float9 = xYPlot5.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation10 = xYPlot5.getRangeAxisLocation();
        xYPlot0.setRangeAxisLocation((int) (byte) 100, axisLocation10, false);
        org.jfree.chart.LegendItemCollection legendItemCollection13 = xYPlot0.getLegendItems();
        java.awt.Paint paint14 = xYPlot0.getRangeCrosshairPaint();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1.0f + "'", float9 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(legendItemCollection13);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.configure();
        java.lang.Object obj4 = numberAxis2.clone();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = numberAxis2.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = dateAxis6.getLabelInsets();
        dateAxis6.setLabel("XY Plot");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis6, xYItemRenderer10);
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        xYPlot12.setRangeCrosshairVisible(true);
        boolean boolean15 = xYPlot12.isRangeCrosshairLockedOnData();
        java.lang.String str16 = xYPlot12.getPlotType();
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis("");
        float float20 = categoryAxis19.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        boolean boolean22 = dateAxis21.isAutoTickUnitSelection();
        org.jfree.data.Range range23 = dateAxis21.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot24 = dateAxis21.getPlot();
        dateAxis21.setLabelURL("hi!");
        dateAxis21.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis21, categoryItemRenderer30);
        org.jfree.chart.plot.Marker marker32 = null;
        boolean boolean33 = categoryPlot31.removeDomainMarker(marker32);
        java.util.List list34 = categoryPlot31.getAnnotations();
        java.awt.Stroke stroke35 = categoryPlot31.getRangeGridlineStroke();
        xYPlot12.setRangeCrosshairStroke(stroke35);
        numberAxis2.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot12);
        xYPlot12.setOutlineVisible(true);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(numberTickUnit5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "XY Plot" + "'", str16.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 0.0f + "'", float20 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertNull(plot24);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(list34);
        org.junit.Assert.assertNotNull(stroke35);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        categoryPlot14.setWeight((int) (byte) 0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener17 = null;
        categoryPlot14.addChangeListener(plotChangeListener17);
        org.jfree.chart.axis.AxisLocation axisLocation20 = null;
        categoryPlot14.setRangeAxisLocation((int) (short) 1, axisLocation20);
        boolean boolean22 = categoryPlot14.isDomainZoomable();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        int int24 = categoryPlot14.getIndexOf(categoryItemRenderer23);
        org.jfree.data.category.CategoryDataset categoryDataset26 = categoryPlot14.getDataset((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNull(categoryDataset26);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        xYPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = xYPlot0.getOutlinePaint();
        org.jfree.chart.util.Layer layer4 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(layer4);
        boolean boolean6 = xYPlot0.isSubplot();
        org.jfree.chart.axis.ValueAxis valueAxis7 = xYPlot0.getRangeAxis();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(layer4);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(valueAxis7);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        xYPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = xYPlot0.getOutlinePaint();
        java.awt.Stroke stroke4 = xYPlot0.getRangeZeroBaselineStroke();
        boolean boolean5 = xYPlot0.isDomainZoomable();
        xYPlot0.setRangeZeroBaselineVisible(false);
        boolean boolean8 = xYPlot0.isRangeCrosshairVisible();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        org.jfree.chart.plot.Marker marker15 = null;
        boolean boolean16 = categoryPlot14.removeDomainMarker(marker15);
        java.util.List list17 = categoryPlot14.getAnnotations();
        java.lang.Object obj18 = categoryPlot14.clone();
        org.jfree.chart.util.SortOrder sortOrder19 = categoryPlot14.getColumnRenderingOrder();
        org.jfree.chart.plot.PlotOrientation plotOrientation20 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        categoryPlot14.setOrientation(plotOrientation20);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(list17);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(sortOrder19);
        org.junit.Assert.assertNotNull(plotOrientation20);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        categoryPlot14.setWeight((int) (byte) 0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener17 = null;
        categoryPlot14.addChangeListener(plotChangeListener17);
        org.jfree.chart.axis.AxisLocation axisLocation20 = null;
        categoryPlot14.setRangeAxisLocation((int) (short) 1, axisLocation20);
        boolean boolean22 = categoryPlot14.isDomainZoomable();
        int int23 = categoryPlot14.getRangeAxisCount();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        categoryPlot14.setRenderer(1, categoryItemRenderer25);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.lang.String str1 = rectangleAnchor0.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleAnchor.BOTTOM_RIGHT" + "'", str1.equals("RectangleAnchor.BOTTOM_RIGHT"));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.lang.Object obj1 = null;
        boolean boolean2 = datasetRenderingOrder0.equals(obj1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) 10, (float) (-83), (float) 8);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType1 = rectangleInsets0.getUnitType();
        double double3 = rectangleInsets0.calculateBottomOutset((double) 2019);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(unitType1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_YELLOW;
        int int1 = color0.getRed();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 192 + "'", int1 == 192);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        xYPlot0.setInsets(rectangleInsets3, true);
        java.awt.Paint paint6 = xYPlot0.getDomainTickBandPaint();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = xYPlot0.getLegendItems();
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(legendItemCollection7);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairValue((double) (-1L));
        org.jfree.chart.axis.ValueAxis valueAxis4 = xYPlot0.getRangeAxis(3);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        xYPlot0.setDataset(xYDataset5);
        org.junit.Assert.assertNull(valueAxis4);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isAutoTickUnitSelection();
        java.awt.Shape shape2 = dateAxis0.getLeftArrow();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition3 = dateAxis0.getTickMarkPosition();
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        dateAxis5.setTickMarksVisible(true);
        java.lang.Object obj8 = dateAxis5.clone();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        boolean boolean10 = dateAxis9.isAutoTickUnitSelection();
        org.jfree.data.Range range11 = dateAxis9.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot12 = dateAxis9.getPlot();
        dateAxis9.setLabelURL("hi!");
        dateAxis9.setLowerMargin(0.0d);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset4, (org.jfree.chart.axis.ValueAxis) dateAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis9, xYItemRenderer17);
        boolean boolean19 = dateAxis0.equals((java.lang.Object) xYItemRenderer17);
        java.awt.Font font20 = dateAxis0.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        boolean boolean22 = dateAxis21.isAutoTickUnitSelection();
        org.jfree.data.Range range23 = dateAxis21.getDefaultAutoRange();
        dateAxis0.setRangeWithMargins(range23, true, false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(dateTickMarkPosition3);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNull(plot12);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(range23);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat2 = numberAxis1.getNumberFormatOverride();
        org.jfree.data.RangeType rangeType3 = numberAxis1.getRangeType();
        boolean boolean4 = numberAxis1.isTickMarksVisible();
        double double5 = numberAxis1.getUpperMargin();
        numberAxis1.setFixedDimension((double) 3);
        java.awt.Shape shape8 = numberAxis1.getUpArrow();
        java.awt.Shape shape9 = numberAxis1.getUpArrow();
        org.junit.Assert.assertNull(numberFormat2);
        org.junit.Assert.assertNotNull(rangeType3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(shape9);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ChartChangeEventType.DATASET_UPDATED");
        numberAxis1.setLowerBound((double) 1560409200000L);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis5.configure();
        double double7 = numberAxis5.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat10 = numberAxis9.getNumberFormatOverride();
        org.jfree.data.RangeType rangeType11 = numberAxis9.getRangeType();
        numberAxis5.setRangeType(rangeType11);
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener14 = null;
        xYPlot13.addChangeListener(plotChangeListener14);
        java.awt.Paint paint16 = xYPlot13.getOutlinePaint();
        java.awt.Stroke stroke17 = xYPlot13.getRangeZeroBaselineStroke();
        numberAxis5.setTickMarkStroke(stroke17);
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis20.configure();
        java.lang.Object obj22 = numberAxis20.clone();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit23 = numberAxis20.getTickUnit();
        numberAxis5.setTickUnit(numberTickUnit23);
        numberAxis1.setTickUnit(numberTickUnit23, false, false);
        java.awt.Graphics2D graphics2D28 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        try {
            org.jfree.chart.axis.AxisState axisState34 = numberAxis1.draw(graphics2D28, (double) 12, rectangle2D30, rectangle2D31, rectangleEdge32, plotRenderingInfo33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNull(numberFormat10);
        org.junit.Assert.assertNotNull(rangeType11);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(numberTickUnit23);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        org.jfree.chart.plot.Marker marker15 = null;
        boolean boolean16 = categoryPlot14.removeDomainMarker(marker15);
        java.util.List list17 = categoryPlot14.getAnnotations();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = categoryPlot14.getAxisOffset();
        categoryPlot14.setAnchorValue((double) (short) 100);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(list17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isAutoTickUnitSelection();
        java.awt.Shape shape2 = dateAxis0.getLeftArrow();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition3 = dateAxis0.getTickMarkPosition();
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        dateAxis5.setTickMarksVisible(true);
        java.lang.Object obj8 = dateAxis5.clone();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        boolean boolean10 = dateAxis9.isAutoTickUnitSelection();
        org.jfree.data.Range range11 = dateAxis9.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot12 = dateAxis9.getPlot();
        dateAxis9.setLabelURL("hi!");
        dateAxis9.setLowerMargin(0.0d);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset4, (org.jfree.chart.axis.ValueAxis) dateAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis9, xYItemRenderer17);
        boolean boolean19 = dateAxis0.equals((java.lang.Object) xYItemRenderer17);
        java.awt.Font font20 = dateAxis0.getLabelFont();
        java.util.Date date21 = dateAxis0.getMinimumDate();
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis23.configure();
        java.lang.Object obj25 = numberAxis23.clone();
        numberAxis23.setAutoRangeIncludesZero(true);
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis29.configure();
        java.lang.Object obj31 = numberAxis29.clone();
        java.awt.Shape shape32 = numberAxis29.getDownArrow();
        numberAxis23.setRightArrow(shape32);
        dateAxis0.setUpArrow(shape32);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(dateTickMarkPosition3);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNull(plot12);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertNotNull(obj31);
        org.junit.Assert.assertNotNull(shape32);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        xYPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        int int6 = xYPlot0.getRangeAxisIndex(valueAxis5);
        xYPlot0.setDomainZeroBaselineVisible(false);
        java.awt.Color color9 = java.awt.Color.red;
        java.awt.image.ColorModel colorModel10 = null;
        java.awt.Rectangle rectangle11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.awt.geom.AffineTransform affineTransform13 = null;
        java.awt.RenderingHints renderingHints14 = null;
        java.awt.PaintContext paintContext15 = color9.createContext(colorModel10, rectangle11, rectangle2D12, affineTransform13, renderingHints14);
        java.awt.Color color16 = color9.darker();
        java.awt.color.ColorSpace colorSpace17 = color9.getColorSpace();
        int int18 = color9.getGreen();
        java.awt.Color color19 = color9.darker();
        xYPlot0.setOutlinePaint((java.awt.Paint) color19);
        xYPlot0.clearDomainAxes();
        java.awt.Color color22 = java.awt.Color.YELLOW;
        java.awt.Color color23 = color22.darker();
        java.awt.Color color24 = java.awt.Color.red;
        java.awt.image.ColorModel colorModel25 = null;
        java.awt.Rectangle rectangle26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        java.awt.geom.AffineTransform affineTransform28 = null;
        java.awt.RenderingHints renderingHints29 = null;
        java.awt.PaintContext paintContext30 = color24.createContext(colorModel25, rectangle26, rectangle2D27, affineTransform28, renderingHints29);
        java.awt.Color color31 = color24.darker();
        java.awt.color.ColorSpace colorSpace32 = color24.getColorSpace();
        float[] floatArray38 = new float[] { 2, (byte) 0, 0L, '4', 9 };
        float[] floatArray39 = color24.getRGBComponents(floatArray38);
        float[] floatArray40 = color23.getColorComponents(floatArray38);
        xYPlot0.setRangeTickBandPaint((java.awt.Paint) color23);
        java.awt.Paint paint42 = xYPlot0.getOutlinePaint();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(paintContext15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(colorSpace17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(paintContext30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(colorSpace32);
        org.junit.Assert.assertNotNull(floatArray38);
        org.junit.Assert.assertNotNull(floatArray39);
        org.junit.Assert.assertNotNull(floatArray40);
        org.junit.Assert.assertNotNull(paint42);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        xYPlot0.markerChanged(markerChangeEvent1);
        java.awt.Paint paint3 = xYPlot0.getDomainGridlinePaint();
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        xYPlot0.setInsets(rectangleInsets3, true);
        java.awt.Paint paint6 = xYPlot0.getDomainTickBandPaint();
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("");
        float float12 = categoryAxis11.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        boolean boolean14 = dateAxis13.isAutoTickUnitSelection();
        org.jfree.data.Range range15 = dateAxis13.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot16 = dateAxis13.getPlot();
        dateAxis13.setLabelURL("hi!");
        dateAxis13.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis13, categoryItemRenderer22);
        org.jfree.chart.plot.Marker marker24 = null;
        boolean boolean25 = categoryPlot23.removeDomainMarker(marker24);
        java.util.List list26 = categoryPlot23.getAnnotations();
        xYPlot0.drawDomainTickBands(graphics2D7, rectangle2D8, list26);
        xYPlot0.clearRangeMarkers((-1));
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 0.0f + "'", float12 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNull(plot16);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(list26);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat2 = numberAxis1.getNumberFormatOverride();
        org.jfree.data.RangeType rangeType3 = numberAxis1.getRangeType();
        boolean boolean4 = numberAxis1.isTickMarksVisible();
        numberAxis1.setTickLabelsVisible(false);
        boolean boolean7 = numberAxis1.isAxisLineVisible();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        dateAxis8.setTickMarksVisible(true);
        org.jfree.chart.event.AxisChangeListener axisChangeListener11 = null;
        dateAxis8.removeChangeListener(axisChangeListener11);
        java.awt.Font font13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis8.setTickLabelFont(font13);
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        boolean boolean16 = dateAxis15.isAutoTickUnitSelection();
        org.jfree.data.Range range17 = dateAxis15.getDefaultAutoRange();
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        boolean boolean19 = dateAxis18.isAutoTickUnitSelection();
        org.jfree.data.Range range20 = dateAxis18.getDefaultAutoRange();
        dateAxis15.setRangeWithMargins(range20);
        dateAxis8.setRange(range20, true, false);
        numberAxis1.setDefaultAutoRange(range20);
        org.junit.Assert.assertNull(numberFormat2);
        org.junit.Assert.assertNotNull(rangeType3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(range20);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setTickMarksVisible(true);
        org.jfree.chart.event.AxisChangeListener axisChangeListener3 = null;
        dateAxis0.removeChangeListener(axisChangeListener3);
        java.awt.Font font5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis0.setTickLabelFont(font5);
        dateAxis0.setNegativeArrowVisible(false);
        org.jfree.chart.axis.Timeline timeline9 = null;
        dateAxis0.setTimeline(timeline9);
        java.util.Date date11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("");
        float float17 = categoryAxis16.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        boolean boolean19 = dateAxis18.isAutoTickUnitSelection();
        org.jfree.data.Range range20 = dateAxis18.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot21 = dateAxis18.getPlot();
        dateAxis18.setLabelURL("hi!");
        dateAxis18.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis16, (org.jfree.chart.axis.ValueAxis) dateAxis18, categoryItemRenderer27);
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis();
        dateAxis29.setTickMarksVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource32 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis29.setStandardTickUnits(tickUnitSource32);
        java.text.DateFormat dateFormat34 = null;
        dateAxis29.setDateFormatOverride(dateFormat34);
        dateAxis29.setTickMarksVisible(true);
        dateAxis29.setRange((double) (-1L), 1.0E-8d);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer41 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis16, (org.jfree.chart.axis.ValueAxis) dateAxis29, categoryItemRenderer41);
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = categoryPlot42.getRangeAxisEdge();
        try {
            double double44 = dateAxis0.dateToJava2D(date11, rectangle2D12, rectangleEdge43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.0f + "'", float17 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertNotNull(tickUnitSource32);
        org.junit.Assert.assertNotNull(rectangleEdge43);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        boolean boolean16 = dateAxis15.isAutoTickUnitSelection();
        org.jfree.data.Range range17 = dateAxis15.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot18 = dateAxis15.getPlot();
        dateAxis15.setLabelURL("hi!");
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        boolean boolean22 = dateAxis21.isAutoTickUnitSelection();
        org.jfree.data.Range range23 = dateAxis21.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot24 = dateAxis21.getPlot();
        java.util.Date date25 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis21.setMinimumDate(date25);
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        boolean boolean28 = dateAxis27.isAutoTickUnitSelection();
        org.jfree.data.Range range29 = dateAxis27.getDefaultAutoRange();
        dateAxis21.setRangeWithMargins(range29, false, false);
        dateAxis15.setRange(range29, false, false);
        dateAxis4.setRange(range29, false, true);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(plot18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertNull(plot24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(range29);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        xYPlot0.setInsets(rectangleInsets3, true);
        java.awt.Paint paint6 = xYPlot0.getDomainTickBandPaint();
        java.lang.String str7 = xYPlot0.getPlotType();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape9 = dateAxis8.getLeftArrow();
        java.awt.Paint paint10 = dateAxis8.getAxisLinePaint();
        int int11 = xYPlot0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis8);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setTickMarksVisible(true);
        org.jfree.chart.event.AxisChangeListener axisChangeListener15 = null;
        dateAxis12.removeChangeListener(axisChangeListener15);
        java.awt.Font font17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis12.setTickLabelFont(font17);
        dateAxis12.setNegativeArrowVisible(false);
        xYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis12);
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        dateAxis22.setTickMarksVisible(true);
        org.jfree.chart.event.AxisChangeListener axisChangeListener25 = null;
        dateAxis22.removeChangeListener(axisChangeListener25);
        java.awt.Font font27 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis22.setTickLabelFont(font27);
        java.util.TimeZone timeZone29 = dateAxis22.getTimeZone();
        org.jfree.data.general.Dataset dataset30 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent31 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) timeZone29, dataset30);
        xYPlot0.datasetChanged(datasetChangeEvent31);
        org.jfree.data.general.Dataset dataset33 = datasetChangeEvent31.getDataset();
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "XY Plot" + "'", str7.equals("XY Plot"));
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNull(dataset33);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        categoryPlot14.addChangeListener(plotChangeListener15);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        dateAxis20.setTickMarksVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource23 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis20.setStandardTickUnits(tickUnitSource23);
        java.text.DateFormat dateFormat25 = null;
        dateAxis20.setDateFormatOverride(dateFormat25);
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = dateAxis27.getLabelInsets();
        dateAxis20.setTickLabelInsets(rectangleInsets28);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis20, categoryItemRenderer30);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray32 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot31.setRangeAxes(valueAxisArray32);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent34 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot31);
        categoryPlot14.notifyListeners(plotChangeEvent34);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(tickUnitSource23);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(valueAxisArray32);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        float float4 = categoryAxis3.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        boolean boolean6 = dateAxis5.isAutoTickUnitSelection();
        org.jfree.data.Range range7 = dateAxis5.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot8 = dateAxis5.getPlot();
        dateAxis5.setLabelURL("hi!");
        dateAxis5.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer14);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        dateAxis16.setTickMarksVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource19 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis16.setStandardTickUnits(tickUnitSource19);
        java.text.DateFormat dateFormat21 = null;
        dateAxis16.setDateFormatOverride(dateFormat21);
        dateAxis16.setTickMarksVisible(true);
        dateAxis16.setRange((double) (-1L), 1.0E-8d);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis16, categoryItemRenderer28);
        java.awt.Paint paint30 = categoryAxis3.getTickMarkPaint();
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat34 = numberAxis33.getNumberFormatOverride();
        org.jfree.data.RangeType rangeType35 = numberAxis33.getRangeType();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand36 = null;
        numberAxis33.setMarkerBand(markerAxisBand36);
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis39.configure();
        double double41 = numberAxis39.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis43 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat44 = numberAxis43.getNumberFormatOverride();
        org.jfree.data.RangeType rangeType45 = numberAxis43.getRangeType();
        numberAxis39.setRangeType(rangeType45);
        numberAxis33.setRangeType(rangeType45);
        org.jfree.data.RangeType rangeType48 = numberAxis33.getRangeType();
        org.jfree.chart.axis.NumberAxis numberAxis50 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis50.configure();
        java.lang.Object obj52 = numberAxis50.clone();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit53 = numberAxis50.getTickUnit();
        numberAxis33.setTickUnit(numberTickUnit53);
        numberAxis31.setTickUnit(numberTickUnit53);
        org.jfree.chart.axis.DateAxis dateAxis56 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape57 = dateAxis56.getLeftArrow();
        java.util.TimeZone timeZone58 = dateAxis56.getTimeZone();
        java.awt.Font font59 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis56.setTickLabelFont(font59);
        categoryAxis3.setTickLabelFont((java.lang.Comparable) numberTickUnit53, font59);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(tickUnitSource19);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNull(numberFormat34);
        org.junit.Assert.assertNotNull(rangeType35);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNull(numberFormat44);
        org.junit.Assert.assertNotNull(rangeType45);
        org.junit.Assert.assertNotNull(rangeType48);
        org.junit.Assert.assertNotNull(obj52);
        org.junit.Assert.assertNotNull(numberTickUnit53);
        org.junit.Assert.assertNotNull(shape57);
        org.junit.Assert.assertNotNull(timeZone58);
        org.junit.Assert.assertNotNull(font59);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        float float4 = categoryAxis3.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        boolean boolean6 = dateAxis5.isAutoTickUnitSelection();
        org.jfree.data.Range range7 = dateAxis5.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot8 = dateAxis5.getPlot();
        dateAxis5.setLabelURL("hi!");
        dateAxis5.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer14);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        dateAxis16.setTickMarksVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource19 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis16.setStandardTickUnits(tickUnitSource19);
        java.text.DateFormat dateFormat21 = null;
        dateAxis16.setDateFormatOverride(dateFormat21);
        dateAxis16.setTickMarksVisible(true);
        dateAxis16.setRange((double) (-1L), 1.0E-8d);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis16, categoryItemRenderer28);
        int int30 = categoryPlot29.getBackgroundImageAlignment();
        categoryPlot29.setRangeCrosshairValue((double) 1.0f, true);
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = categoryPlot29.getDomainAxisEdge();
        int int35 = categoryPlot29.getDomainAxisCount();
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(tickUnitSource19);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 15 + "'", int30 == 15);
        org.junit.Assert.assertNotNull(rectangleEdge34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        boolean boolean2 = axisLocation0.equals((java.lang.Object) rectangleInsets1);
        java.lang.String str3 = axisLocation0.toString();
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "AxisLocation.BOTTOM_OR_LEFT" + "'", str3.equals("AxisLocation.BOTTOM_OR_LEFT"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        java.awt.Color color0 = java.awt.Color.DARK_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat2 = numberAxis1.getNumberFormatOverride();
        org.jfree.data.RangeType rangeType3 = numberAxis1.getRangeType();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape5 = dateAxis4.getLeftArrow();
        numberAxis1.setDownArrow(shape5);
        numberAxis1.setUpperBound((double) '4');
        org.junit.Assert.assertNull(numberFormat2);
        org.junit.Assert.assertNotNull(rangeType3);
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        xYPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = xYPlot0.getOutlinePaint();
        float float4 = xYPlot0.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot0.getRangeAxisLocation();
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        xYPlot6.setRangeCrosshairVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        xYPlot6.setInsets(rectangleInsets9, true);
        java.awt.Paint paint12 = xYPlot6.getDomainTickBandPaint();
        java.lang.String str13 = xYPlot6.getPlotType();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape15 = dateAxis14.getLeftArrow();
        java.awt.Paint paint16 = dateAxis14.getAxisLinePaint();
        int int17 = xYPlot6.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis14);
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis("");
        float float22 = categoryAxis21.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        boolean boolean24 = dateAxis23.isAutoTickUnitSelection();
        org.jfree.data.Range range25 = dateAxis23.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot26 = dateAxis23.getPlot();
        dateAxis23.setLabelURL("hi!");
        dateAxis23.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer32 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis21, (org.jfree.chart.axis.ValueAxis) dateAxis23, categoryItemRenderer32);
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        dateAxis34.setTickMarksVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource37 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis34.setStandardTickUnits(tickUnitSource37);
        java.text.DateFormat dateFormat39 = null;
        dateAxis34.setDateFormatOverride(dateFormat39);
        dateAxis34.setTickMarksVisible(true);
        dateAxis34.setRange((double) (-1L), 1.0E-8d);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer46 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot47 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis21, (org.jfree.chart.axis.ValueAxis) dateAxis34, categoryItemRenderer46);
        dateAxis34.setTickMarkOutsideLength((float) 'a');
        java.awt.Font font50 = dateAxis34.getTickLabelFont();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray51 = new org.jfree.chart.axis.ValueAxis[] { dateAxis34 };
        xYPlot6.setRangeAxes(valueAxisArray51);
        xYPlot0.setDomainAxes(valueAxisArray51);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "XY Plot" + "'", str13.equals("XY Plot"));
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 0.0f + "'", float22 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertNull(plot26);
        org.junit.Assert.assertNotNull(tickUnitSource37);
        org.junit.Assert.assertNotNull(font50);
        org.junit.Assert.assertNotNull(valueAxisArray51);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        xYPlot0.setInsets(rectangleInsets3, true);
        java.awt.Paint paint6 = xYPlot0.getDomainTickBandPaint();
        java.lang.String str7 = xYPlot0.getPlotType();
        boolean boolean8 = xYPlot0.isRangeZeroBaselineVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = xYPlot0.getRenderer(0);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "XY Plot" + "'", str7.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(xYItemRenderer10);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        org.jfree.chart.axis.ValueAxis valueAxis15 = categoryPlot14.getRangeAxis();
        java.awt.Stroke stroke16 = categoryPlot14.getRangeGridlineStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker19 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) true);
        org.jfree.chart.util.Layer layer20 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean21 = categoryPlot14.removeRangeMarker((int) (byte) 1, (org.jfree.chart.plot.Marker) categoryMarker19, layer20);
        int int22 = categoryPlot14.getDatasetCount();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        try {
            categoryPlot14.setRenderer((-83), categoryItemRenderer24, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(valueAxis15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(layer20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        categoryPlot14.setWeight((int) (byte) 0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener17 = null;
        categoryPlot14.addChangeListener(plotChangeListener17);
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener20 = null;
        xYPlot19.addChangeListener(plotChangeListener20);
        java.awt.Paint paint22 = xYPlot19.getOutlinePaint();
        java.awt.Stroke stroke23 = xYPlot19.getRangeZeroBaselineStroke();
        categoryPlot14.setDomainGridlineStroke(stroke23);
        org.jfree.chart.axis.AxisSpace axisSpace25 = categoryPlot14.getFixedDomainAxisSpace();
        categoryPlot14.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        java.awt.geom.Point2D point2D30 = null;
        categoryPlot14.zoomDomainAxes((double) '4', plotRenderingInfo29, point2D30);
        org.jfree.chart.util.SortOrder sortOrder32 = categoryPlot14.getRowRenderingOrder();
        java.awt.Graphics2D graphics2D33 = null;
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        boolean boolean37 = categoryPlot14.render(graphics2D33, rectangle2D34, (int) (short) 1, plotRenderingInfo36);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNull(axisSpace25);
        org.junit.Assert.assertNotNull(sortOrder32);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        categoryPlot14.setWeight((int) (byte) 0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener17 = null;
        categoryPlot14.addChangeListener(plotChangeListener17);
        org.jfree.chart.axis.AxisLocation axisLocation20 = null;
        categoryPlot14.setRangeAxisLocation((int) (short) 1, axisLocation20);
        boolean boolean22 = categoryPlot14.isDomainZoomable();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        int int24 = categoryPlot14.getIndexOf(categoryItemRenderer23);
        java.lang.Object obj25 = categoryPlot14.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = categoryPlot14.getAxisOffset();
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis();
        double double29 = categoryAxis28.getLowerMargin();
        categoryPlot14.setDomainAxis((int) '#', categoryAxis28, true);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.05d + "'", double29 == 0.05d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        categoryPlot14.setWeight((int) (byte) 0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener17 = null;
        categoryPlot14.addChangeListener(plotChangeListener17);
        java.awt.Color color19 = java.awt.Color.YELLOW;
        categoryPlot14.setDomainGridlinePaint((java.awt.Paint) color19);
        boolean boolean21 = categoryPlot14.isDomainZoomable();
        org.jfree.data.general.DatasetGroup datasetGroup22 = categoryPlot14.getDatasetGroup();
        org.jfree.chart.plot.PlotOrientation plotOrientation23 = categoryPlot14.getOrientation();
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis("");
        float float26 = categoryAxis25.getMaximumCategoryLabelWidthRatio();
        categoryPlot14.setDomainAxis(categoryAxis25);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(datasetGroup22);
        org.junit.Assert.assertNotNull(plotOrientation23);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 0.0f + "'", float26 == 0.0f);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        java.lang.Object obj1 = null;
        boolean boolean2 = lengthAdjustmentType0.equals(obj1);
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        int int1 = color0.getTransparency();
        java.awt.Color color2 = java.awt.Color.darkGray;
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_GREEN;
        float[] floatArray4 = null;
        float[] floatArray5 = color3.getColorComponents(floatArray4);
        float[] floatArray6 = color2.getRGBComponents(floatArray4);
        float[] floatArray7 = color0.getRGBComponents(floatArray6);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray7);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        categoryPlot14.setWeight((int) (byte) 0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener17 = null;
        categoryPlot14.addChangeListener(plotChangeListener17);
        java.awt.Color color19 = java.awt.Color.YELLOW;
        categoryPlot14.setDomainGridlinePaint((java.awt.Paint) color19);
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        categoryPlot14.setDataset((int) (short) 10, categoryDataset22);
        float float24 = categoryPlot14.getBackgroundAlpha();
        boolean boolean25 = categoryPlot14.isDomainZoomable();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 1.0f + "'", float24 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        categoryPlot14.setWeight((int) (byte) 0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener17 = null;
        categoryPlot14.addChangeListener(plotChangeListener17);
        java.awt.Color color19 = java.awt.Color.YELLOW;
        categoryPlot14.setDomainGridlinePaint((java.awt.Paint) color19);
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        categoryPlot14.setDataset((int) (short) 10, categoryDataset22);
        float float24 = categoryPlot14.getBackgroundAlpha();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot();
        xYPlot27.configureDomainAxes();
        java.awt.geom.Point2D point2D29 = xYPlot27.getQuadrantOrigin();
        categoryPlot14.zoomDomainAxes(0.0d, plotRenderingInfo26, point2D29, false);
        java.awt.Stroke stroke32 = categoryPlot14.getRangeGridlineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset33 = categoryPlot14.getDataset();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor37 = null;
        java.awt.geom.Point2D point2D38 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D36, rectangleAnchor37);
        categoryPlot14.zoomDomainAxes(0.0d, plotRenderingInfo35, point2D38);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 1.0f + "'", float24 == 1.0f);
        org.junit.Assert.assertNotNull(point2D29);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNull(categoryDataset33);
        org.junit.Assert.assertNotNull(point2D38);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        xYPlot1.configureDomainAxes();
        java.lang.String str3 = xYPlot1.getNoDataMessage();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis("");
        float float9 = categoryAxis8.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        boolean boolean11 = dateAxis10.isAutoTickUnitSelection();
        org.jfree.data.Range range12 = dateAxis10.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot13 = dateAxis10.getPlot();
        dateAxis10.setLabelURL("hi!");
        dateAxis10.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis10, categoryItemRenderer19);
        org.jfree.chart.plot.Marker marker21 = null;
        boolean boolean22 = categoryPlot20.removeDomainMarker(marker21);
        java.util.List list23 = categoryPlot20.getAnnotations();
        xYPlot1.drawDomainTickBands(graphics2D4, rectangle2D5, list23);
        boolean boolean25 = day0.equals((java.lang.Object) xYPlot1);
        java.util.Calendar calendar26 = null;
        try {
            long long27 = day0.getFirstMillisecond(calendar26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.0f + "'", float9 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNull(plot13);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(list23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        boolean boolean3 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        xYPlot4.configureDomainAxes();
        org.jfree.chart.util.Layer layer6 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection7 = xYPlot4.getDomainMarkers(layer6);
        java.util.Collection collection8 = xYPlot0.getRangeMarkers(layer6);
        java.awt.Stroke stroke9 = xYPlot0.getDomainZeroBaselineStroke();
        java.lang.Object obj10 = xYPlot0.clone();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        xYPlot0.setRenderer((int) (short) 100, xYItemRenderer12);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder14 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot0.setDatasetRenderingOrder(datasetRenderingOrder14);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        try {
            xYPlot0.handleClick(0, 12, plotRenderingInfo18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(layer6);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(datasetRenderingOrder14);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        xYPlot16.setRangeCrosshairVisible(true);
        boolean boolean19 = xYPlot16.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        xYPlot20.configureDomainAxes();
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection23 = xYPlot20.getDomainMarkers(layer22);
        java.util.Collection collection24 = xYPlot16.getRangeMarkers(layer22);
        java.util.Collection collection25 = categoryPlot14.getRangeMarkers((int) (byte) 1, layer22);
        java.util.List list26 = categoryPlot14.getCategories();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = categoryPlot14.getAxisOffset();
        double double29 = rectangleInsets27.extendHeight((double) 10);
        double double31 = rectangleInsets27.calculateTopOutset((double) 8);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertNull(collection23);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertNull(list26);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 18.0d + "'", double29 == 18.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 4.0d + "'", double31 == 4.0d);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        categoryPlot14.setWeight((int) (byte) 0);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        categoryPlot14.setRenderer(categoryItemRenderer17);
        categoryPlot14.clearRangeMarkers(10);
        org.jfree.chart.axis.AxisSpace axisSpace21 = categoryPlot14.getFixedDomainAxisSpace();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNull(axisSpace21);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat2 = numberAxis1.getNumberFormatOverride();
        org.jfree.data.RangeType rangeType3 = numberAxis1.getRangeType();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis1.setMarkerBand(markerAxisBand4);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis7.configure();
        double double9 = numberAxis7.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat12 = numberAxis11.getNumberFormatOverride();
        org.jfree.data.RangeType rangeType13 = numberAxis11.getRangeType();
        numberAxis7.setRangeType(rangeType13);
        numberAxis1.setRangeType(rangeType13);
        numberAxis1.setLabelAngle((double) 5);
        org.junit.Assert.assertNull(numberFormat2);
        org.junit.Assert.assertNotNull(rangeType3);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNull(numberFormat12);
        org.junit.Assert.assertNotNull(rangeType13);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        xYPlot0.setInsets(rectangleInsets3, true);
        java.lang.Object obj6 = xYPlot0.clone();
        xYPlot0.setDomainZeroBaselineVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation9 = xYPlot0.getDomainAxisLocation();
        xYPlot0.setDomainCrosshairVisible(false);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(axisLocation9);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setTickMarksVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource3 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis0.setStandardTickUnits(tickUnitSource3);
        java.text.DateFormat dateFormat5 = null;
        dateAxis0.setDateFormatOverride(dateFormat5);
        java.util.Date date7 = dateAxis0.getMinimumDate();
        org.junit.Assert.assertNotNull(tickUnitSource3);
        org.junit.Assert.assertNotNull(date7);
    }

//    @Test
//    public void test054() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test054");
//        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
//        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
//        float float4 = categoryAxis3.getMaximumCategoryLabelWidthRatio();
//        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
//        boolean boolean6 = dateAxis5.isAutoTickUnitSelection();
//        org.jfree.data.Range range7 = dateAxis5.getDefaultAutoRange();
//        org.jfree.chart.plot.Plot plot8 = dateAxis5.getPlot();
//        dateAxis5.setLabelURL("hi!");
//        dateAxis5.zoomRange((double) 0.0f, (double) 7);
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer14);
//        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
//        dateAxis16.setTickMarksVisible(true);
//        org.jfree.chart.axis.TickUnitSource tickUnitSource19 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
//        dateAxis16.setStandardTickUnits(tickUnitSource19);
//        java.text.DateFormat dateFormat21 = null;
//        dateAxis16.setDateFormatOverride(dateFormat21);
//        dateAxis16.setTickMarksVisible(true);
//        dateAxis16.setRange((double) (-1L), 1.0E-8d);
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis16, categoryItemRenderer28);
//        java.awt.Font font31 = categoryAxis3.getTickLabelFont((java.lang.Comparable) 'a');
//        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
//        boolean boolean33 = dateAxis32.isAutoTickUnitSelection();
//        org.jfree.data.Range range34 = dateAxis32.getDefaultAutoRange();
//        org.jfree.chart.plot.Plot plot35 = dateAxis32.getPlot();
//        java.util.Date date36 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        dateAxis32.setMinimumDate(date36);
//        java.lang.String str38 = categoryAxis3.getCategoryLabelToolTip((java.lang.Comparable) date36);
//        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis();
//        dateAxis39.setTickMarksVisible(true);
//        org.jfree.chart.event.AxisChangeListener axisChangeListener42 = null;
//        dateAxis39.removeChangeListener(axisChangeListener42);
//        java.awt.Font font44 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
//        dateAxis39.setTickLabelFont(font44);
//        java.util.TimeZone timeZone46 = dateAxis39.getTimeZone();
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(date36, timeZone46);
//        java.lang.String str48 = day47.toString();
//        long long49 = day47.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(range7);
//        org.junit.Assert.assertNull(plot8);
//        org.junit.Assert.assertNotNull(tickUnitSource19);
//        org.junit.Assert.assertNotNull(font31);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
//        org.junit.Assert.assertNotNull(range34);
//        org.junit.Assert.assertNull(plot35);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNull(str38);
//        org.junit.Assert.assertNotNull(font44);
//        org.junit.Assert.assertNotNull(timeZone46);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "13-June-2019" + "'", str48.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 43629L + "'", long49 == 43629L);
//    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        java.awt.Color color0 = java.awt.Color.gray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        xYPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        int int6 = xYPlot0.getRangeAxisIndex(valueAxis5);
        xYPlot0.setDomainZeroBaselineVisible(false);
        java.awt.Color color9 = java.awt.Color.red;
        java.awt.image.ColorModel colorModel10 = null;
        java.awt.Rectangle rectangle11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.awt.geom.AffineTransform affineTransform13 = null;
        java.awt.RenderingHints renderingHints14 = null;
        java.awt.PaintContext paintContext15 = color9.createContext(colorModel10, rectangle11, rectangle2D12, affineTransform13, renderingHints14);
        java.awt.Color color16 = color9.darker();
        java.awt.color.ColorSpace colorSpace17 = color9.getColorSpace();
        int int18 = color9.getGreen();
        java.awt.Color color19 = color9.darker();
        xYPlot0.setOutlinePaint((java.awt.Paint) color19);
        int int21 = xYPlot0.getDatasetCount();
        boolean boolean22 = xYPlot0.isRangeZoomable();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(paintContext15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(colorSpace17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        boolean boolean3 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        xYPlot4.configureDomainAxes();
        org.jfree.chart.util.Layer layer6 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection7 = xYPlot4.getDomainMarkers(layer6);
        java.util.Collection collection8 = xYPlot0.getRangeMarkers(layer6);
        java.awt.Stroke stroke9 = xYPlot0.getDomainZeroBaselineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        float float14 = categoryAxis13.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        boolean boolean16 = dateAxis15.isAutoTickUnitSelection();
        org.jfree.data.Range range17 = dateAxis15.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot18 = dateAxis15.getPlot();
        dateAxis15.setLabelURL("hi!");
        dateAxis15.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis13, (org.jfree.chart.axis.ValueAxis) dateAxis15, categoryItemRenderer24);
        org.jfree.chart.axis.ValueAxis valueAxis26 = categoryPlot25.getRangeAxis();
        java.awt.Stroke stroke27 = categoryPlot25.getRangeGridlineStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker30 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) true);
        org.jfree.chart.util.Layer layer31 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean32 = categoryPlot25.removeRangeMarker((int) (byte) 1, (org.jfree.chart.plot.Marker) categoryMarker30, layer31);
        java.util.Collection collection33 = xYPlot0.getRangeMarkers((int) ' ', layer31);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(layer6);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(plot18);
        org.junit.Assert.assertNotNull(valueAxis26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(layer31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNull(collection33);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        xYPlot16.setRangeCrosshairVisible(true);
        boolean boolean19 = xYPlot16.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        xYPlot20.configureDomainAxes();
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection23 = xYPlot20.getDomainMarkers(layer22);
        java.util.Collection collection24 = xYPlot16.getRangeMarkers(layer22);
        java.util.Collection collection25 = categoryPlot14.getRangeMarkers((int) (byte) 1, layer22);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = categoryPlot14.getRangeAxisEdge((int) ' ');
        categoryPlot14.setRangeGridlinesVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis31 = categoryPlot14.getRangeAxisForDataset((int) '#');
        categoryPlot14.clearRangeMarkers(12);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertNull(collection23);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertNotNull(valueAxis31);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isTickLabelsVisible();
        double double2 = dateAxis0.getLabelAngle();
        java.lang.Object obj3 = dateAxis0.clone();
        boolean boolean5 = dateAxis0.isHiddenValue((long) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        categoryPlot14.setWeight((int) (byte) 0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener17 = null;
        categoryPlot14.addChangeListener(plotChangeListener17);
        java.awt.Color color19 = java.awt.Color.YELLOW;
        categoryPlot14.setDomainGridlinePaint((java.awt.Paint) color19);
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        categoryPlot14.setDataset((int) (short) 10, categoryDataset22);
        categoryPlot14.clearDomainMarkers();
        double double25 = categoryPlot14.getRangeCrosshairValue();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        categoryPlot14.setRenderer(categoryItemRenderer26, false);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        float float4 = categoryAxis3.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        boolean boolean6 = dateAxis5.isAutoTickUnitSelection();
        org.jfree.data.Range range7 = dateAxis5.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot8 = dateAxis5.getPlot();
        dateAxis5.setLabelURL("hi!");
        dateAxis5.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer14);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        dateAxis16.setTickMarksVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource19 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis16.setStandardTickUnits(tickUnitSource19);
        java.text.DateFormat dateFormat21 = null;
        dateAxis16.setDateFormatOverride(dateFormat21);
        dateAxis16.setTickMarksVisible(true);
        dateAxis16.setRange((double) (-1L), 1.0E-8d);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis16, categoryItemRenderer28);
        java.util.List list30 = categoryPlot29.getCategories();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer32 = null;
        categoryPlot29.setRenderer(11, categoryItemRenderer32, true);
        org.jfree.chart.axis.AxisLocation axisLocation35 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot29.setDomainAxisLocation(axisLocation35);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(tickUnitSource19);
        org.junit.Assert.assertNull(list30);
        org.junit.Assert.assertNotNull(axisLocation35);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        org.jfree.chart.plot.Marker marker15 = null;
        boolean boolean16 = categoryPlot14.removeDomainMarker(marker15);
        categoryPlot14.zoom(2.0d);
        org.jfree.chart.axis.AxisSpace axisSpace19 = categoryPlot14.getFixedRangeAxisSpace();
        java.awt.Color color20 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryPlot14.setDomainGridlinePaint((java.awt.Paint) color20);
        categoryPlot14.clearRangeAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = categoryPlot14.getDomainAxis();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(axisSpace19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(categoryAxis23);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        xYPlot0.setInsets(rectangleInsets3, true);
        java.awt.Paint paint6 = xYPlot0.getDomainTickBandPaint();
        java.lang.String str7 = xYPlot0.getPlotType();
        org.jfree.chart.plot.Marker marker9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        xYPlot10.setRangeCrosshairVisible(true);
        boolean boolean13 = xYPlot10.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot();
        xYPlot14.configureDomainAxes();
        org.jfree.chart.util.Layer layer16 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection17 = xYPlot14.getDomainMarkers(layer16);
        java.util.Collection collection18 = xYPlot10.getRangeMarkers(layer16);
        boolean boolean20 = xYPlot0.removeDomainMarker((int) ' ', marker9, layer16, false);
        org.jfree.chart.plot.Marker marker21 = null;
        org.jfree.chart.util.Layer layer22 = null;
        boolean boolean23 = xYPlot0.removeDomainMarker(marker21, layer22);
        boolean boolean24 = xYPlot0.isRangeGridlinesVisible();
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "XY Plot" + "'", str7.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(layer16);
        org.junit.Assert.assertNull(collection17);
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairValue((double) (-1L));
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = dateAxis3.getLabelInsets();
        double double5 = rectangleInsets4.getBottom();
        xYPlot0.setAxisOffset(rectangleInsets4);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 3.0d + "'", double5 == 3.0d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        org.jfree.chart.plot.Marker marker15 = null;
        boolean boolean16 = categoryPlot14.removeDomainMarker(marker15);
        categoryPlot14.zoom(2.0d);
        categoryPlot14.setBackgroundImageAlignment((int) '#');
        boolean boolean21 = categoryPlot14.isRangeZoomable();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        float float4 = categoryAxis3.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        boolean boolean6 = dateAxis5.isAutoTickUnitSelection();
        org.jfree.data.Range range7 = dateAxis5.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot8 = dateAxis5.getPlot();
        dateAxis5.setLabelURL("hi!");
        dateAxis5.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer14);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        dateAxis16.setTickMarksVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource19 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis16.setStandardTickUnits(tickUnitSource19);
        java.text.DateFormat dateFormat21 = null;
        dateAxis16.setDateFormatOverride(dateFormat21);
        dateAxis16.setTickMarksVisible(true);
        dateAxis16.setRange((double) (-1L), 1.0E-8d);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis16, categoryItemRenderer28);
        java.util.List list30 = categoryPlot29.getCategories();
        categoryPlot29.clearRangeMarkers();
        java.awt.Paint[] paintArray32 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Paint[] paintArray33 = new java.awt.Paint[] {};
        java.awt.Stroke[] strokeArray34 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray35 = new java.awt.Stroke[] {};
        java.awt.Shape shape36 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape[] shapeArray37 = new java.awt.Shape[] { shape36 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier38 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray32, paintArray33, strokeArray34, strokeArray35, shapeArray37);
        java.awt.Stroke stroke39 = defaultDrawingSupplier38.getNextStroke();
        categoryPlot29.setRangeCrosshairStroke(stroke39);
        org.jfree.data.category.CategoryDataset categoryDataset42 = categoryPlot29.getDataset(5);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(tickUnitSource19);
        org.junit.Assert.assertNull(list30);
        org.junit.Assert.assertNotNull(paintArray32);
        org.junit.Assert.assertNotNull(paintArray33);
        org.junit.Assert.assertNotNull(strokeArray34);
        org.junit.Assert.assertNotNull(strokeArray35);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(shapeArray37);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNull(categoryDataset42);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setTickMarksVisible(true);
        org.jfree.chart.event.AxisChangeListener axisChangeListener3 = null;
        dateAxis0.removeChangeListener(axisChangeListener3);
        java.awt.Font font5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis0.setTickLabelFont(font5);
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isAutoTickUnitSelection();
        org.jfree.data.Range range9 = dateAxis7.getDefaultAutoRange();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        boolean boolean11 = dateAxis10.isAutoTickUnitSelection();
        org.jfree.data.Range range12 = dateAxis10.getDefaultAutoRange();
        dateAxis7.setRangeWithMargins(range12);
        dateAxis0.setRange(range12, true, false);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        boolean boolean18 = dateAxis17.isAutoTickUnitSelection();
        org.jfree.data.Range range19 = dateAxis17.getDefaultAutoRange();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean21 = dateAxis20.isAutoTickUnitSelection();
        org.jfree.data.Range range22 = dateAxis20.getDefaultAutoRange();
        dateAxis17.setRangeWithMargins(range22);
        dateAxis0.setRange(range22, true, false);
        dateAxis0.configure();
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(range22);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        boolean boolean3 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        xYPlot4.configureDomainAxes();
        org.jfree.chart.util.Layer layer6 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection7 = xYPlot4.getDomainMarkers(layer6);
        java.util.Collection collection8 = xYPlot0.getRangeMarkers(layer6);
        java.awt.Stroke stroke9 = xYPlot0.getDomainZeroBaselineStroke();
        java.lang.Object obj10 = xYPlot0.clone();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        xYPlot0.setRenderer((int) (short) 100, xYItemRenderer12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        dateAxis17.setTickMarksVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource20 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis17.setStandardTickUnits(tickUnitSource20);
        java.text.DateFormat dateFormat22 = null;
        dateAxis17.setDateFormatOverride(dateFormat22);
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = dateAxis24.getLabelInsets();
        dateAxis17.setTickLabelInsets(rectangleInsets25);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis16, (org.jfree.chart.axis.ValueAxis) dateAxis17, categoryItemRenderer27);
        int int29 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis17);
        java.awt.Paint paint30 = xYPlot0.getRangeZeroBaselinePaint();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(layer6);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(tickUnitSource20);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(paint30);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) true);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType2 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        java.lang.String str3 = lengthAdjustmentType2.toString();
        categoryMarker1.setLabelOffsetType(lengthAdjustmentType2);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryMarker1.setOutlineStroke(stroke5);
        java.awt.Stroke stroke7 = categoryMarker1.getOutlineStroke();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = org.jfree.chart.util.RectangleAnchor.LEFT;
        categoryMarker1.setLabelAnchor(rectangleAnchor8);
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape11 = dateAxis10.getLeftArrow();
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis("");
        float float16 = categoryAxis15.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        boolean boolean18 = dateAxis17.isAutoTickUnitSelection();
        org.jfree.data.Range range19 = dateAxis17.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot20 = dateAxis17.getPlot();
        dateAxis17.setLabelURL("hi!");
        dateAxis17.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis15, (org.jfree.chart.axis.ValueAxis) dateAxis17, categoryItemRenderer26);
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis();
        dateAxis28.setTickMarksVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource31 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis28.setStandardTickUnits(tickUnitSource31);
        java.text.DateFormat dateFormat33 = null;
        dateAxis28.setDateFormatOverride(dateFormat33);
        dateAxis28.setTickMarksVisible(true);
        dateAxis28.setRange((double) (-1L), 1.0E-8d);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer40 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis15, (org.jfree.chart.axis.ValueAxis) dateAxis28, categoryItemRenderer40);
        java.awt.Font font43 = categoryAxis15.getTickLabelFont((java.lang.Comparable) 'a');
        dateAxis10.setLabelFont(font43);
        java.util.Date date45 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis10.setMinimumDate(date45);
        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date45, timeZone47);
        categoryMarker1.setKey((java.lang.Comparable) date45);
        org.junit.Assert.assertNotNull(lengthAdjustmentType2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "EXPAND" + "'", str3.equals("EXPAND"));
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 0.0f + "'", float16 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertNull(plot20);
        org.junit.Assert.assertNotNull(tickUnitSource31);
        org.junit.Assert.assertNotNull(font43);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(timeZone47);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat2 = numberAxis1.getNumberFormatOverride();
        org.jfree.data.RangeType rangeType3 = numberAxis1.getRangeType();
        boolean boolean4 = numberAxis1.isTickMarksVisible();
        double double5 = numberAxis1.getUpperMargin();
        boolean boolean6 = numberAxis1.isTickLabelsVisible();
        java.text.NumberFormat numberFormat7 = null;
        numberAxis1.setNumberFormatOverride(numberFormat7);
        org.junit.Assert.assertNull(numberFormat2);
        org.junit.Assert.assertNotNull(rangeType3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

//    @Test
//    public void test072() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test072");
//        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
//        java.awt.Shape shape1 = dateAxis0.getLeftArrow();
//        java.awt.Paint paint2 = dateAxis0.getAxisLinePaint();
//        dateAxis0.setAutoRangeMinimumSize(3.0d);
//        boolean boolean5 = dateAxis0.isInverted();
//        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
//        double double7 = categoryAxis6.getLowerMargin();
//        categoryAxis6.removeCategoryLabelToolTip((java.lang.Comparable) 1);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        long long11 = day10.getFirstMillisecond();
//        java.lang.String str12 = day10.toString();
//        java.lang.String str13 = categoryAxis6.getCategoryLabelToolTip((java.lang.Comparable) day10);
//        java.util.Date date14 = day10.getStart();
//        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("EXPAND");
//        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
//        java.awt.Shape shape18 = dateAxis17.getLeftArrow();
//        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
//        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis("");
//        float float23 = categoryAxis22.getMaximumCategoryLabelWidthRatio();
//        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis();
//        boolean boolean25 = dateAxis24.isAutoTickUnitSelection();
//        org.jfree.data.Range range26 = dateAxis24.getDefaultAutoRange();
//        org.jfree.chart.plot.Plot plot27 = dateAxis24.getPlot();
//        dateAxis24.setLabelURL("hi!");
//        dateAxis24.zoomRange((double) 0.0f, (double) 7);
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis22, (org.jfree.chart.axis.ValueAxis) dateAxis24, categoryItemRenderer33);
//        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis();
//        dateAxis35.setTickMarksVisible(true);
//        org.jfree.chart.axis.TickUnitSource tickUnitSource38 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
//        dateAxis35.setStandardTickUnits(tickUnitSource38);
//        java.text.DateFormat dateFormat40 = null;
//        dateAxis35.setDateFormatOverride(dateFormat40);
//        dateAxis35.setTickMarksVisible(true);
//        dateAxis35.setRange((double) (-1L), 1.0E-8d);
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer47 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot48 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis22, (org.jfree.chart.axis.ValueAxis) dateAxis35, categoryItemRenderer47);
//        java.awt.Font font50 = categoryAxis22.getTickLabelFont((java.lang.Comparable) 'a');
//        dateAxis17.setLabelFont(font50);
//        java.util.Date date52 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        dateAxis17.setMinimumDate(date52);
//        java.awt.Font font54 = categoryAxis16.getTickLabelFont((java.lang.Comparable) date52);
//        dateAxis0.setRange(date14, date52);
//        org.junit.Assert.assertNotNull(shape1);
//        org.junit.Assert.assertNotNull(paint2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "13-June-2019" + "'", str12.equals("13-June-2019"));
//        org.junit.Assert.assertNull(str13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(shape18);
//        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 0.0f + "'", float23 == 0.0f);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertNotNull(range26);
//        org.junit.Assert.assertNull(plot27);
//        org.junit.Assert.assertNotNull(tickUnitSource38);
//        org.junit.Assert.assertNotNull(font50);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertNotNull(font54);
//    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        xYPlot0.setInsets(rectangleInsets3, true);
        java.awt.Paint paint6 = xYPlot0.getDomainTickBandPaint();
        java.lang.String str7 = xYPlot0.getPlotType();
        boolean boolean8 = xYPlot0.isRangeZeroBaselineVisible();
        xYPlot0.clearDomainAxes();
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        java.util.List list12 = null;
        xYPlot0.drawDomainTickBands(graphics2D10, rectangle2D11, list12);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "XY Plot" + "'", str7.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureDomainAxes();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat4 = numberAxis3.getNumberFormatOverride();
        org.jfree.data.RangeType rangeType5 = numberAxis3.getRangeType();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis3.setMarkerBand(markerAxisBand6);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis9.configure();
        double double11 = numberAxis9.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat14 = numberAxis13.getNumberFormatOverride();
        org.jfree.data.RangeType rangeType15 = numberAxis13.getRangeType();
        numberAxis9.setRangeType(rangeType15);
        numberAxis3.setRangeType(rangeType15);
        xYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis3);
        org.jfree.chart.axis.AxisLocation axisLocation19 = null;
        try {
            xYPlot0.setDomainAxisLocation(axisLocation19, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(numberFormat4);
        org.junit.Assert.assertNotNull(rangeType5);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNull(numberFormat14);
        org.junit.Assert.assertNotNull(rangeType15);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        xYPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = xYPlot0.getOutlinePaint();
        java.awt.Stroke stroke4 = xYPlot0.getRangeZeroBaselineStroke();
        boolean boolean5 = xYPlot0.isDomainZoomable();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = null;
        java.awt.geom.Point2D point2D8 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D6, rectangleAnchor7);
        xYPlot0.setQuadrantOrigin(point2D8);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(point2D8);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        java.awt.Color color0 = java.awt.Color.yellow;
        org.junit.Assert.assertNotNull(color0);
    }

//    @Test
//    public void test077() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test077");
//        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
//        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
//        float float4 = categoryAxis3.getMaximumCategoryLabelWidthRatio();
//        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
//        boolean boolean6 = dateAxis5.isAutoTickUnitSelection();
//        org.jfree.data.Range range7 = dateAxis5.getDefaultAutoRange();
//        org.jfree.chart.plot.Plot plot8 = dateAxis5.getPlot();
//        dateAxis5.setLabelURL("hi!");
//        dateAxis5.zoomRange((double) 0.0f, (double) 7);
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer14);
//        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
//        dateAxis16.setTickMarksVisible(true);
//        org.jfree.chart.axis.TickUnitSource tickUnitSource19 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
//        dateAxis16.setStandardTickUnits(tickUnitSource19);
//        java.text.DateFormat dateFormat21 = null;
//        dateAxis16.setDateFormatOverride(dateFormat21);
//        dateAxis16.setTickMarksVisible(true);
//        dateAxis16.setRange((double) (-1L), 1.0E-8d);
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis16, categoryItemRenderer28);
//        java.awt.Font font31 = categoryAxis3.getTickLabelFont((java.lang.Comparable) 'a');
//        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
//        boolean boolean33 = dateAxis32.isAutoTickUnitSelection();
//        org.jfree.data.Range range34 = dateAxis32.getDefaultAutoRange();
//        org.jfree.chart.plot.Plot plot35 = dateAxis32.getPlot();
//        java.util.Date date36 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        dateAxis32.setMinimumDate(date36);
//        java.lang.String str38 = categoryAxis3.getCategoryLabelToolTip((java.lang.Comparable) date36);
//        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis();
//        dateAxis39.setTickMarksVisible(true);
//        org.jfree.chart.event.AxisChangeListener axisChangeListener42 = null;
//        dateAxis39.removeChangeListener(axisChangeListener42);
//        java.awt.Font font44 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
//        dateAxis39.setTickLabelFont(font44);
//        java.util.TimeZone timeZone46 = dateAxis39.getTimeZone();
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(date36, timeZone46);
//        java.lang.String str48 = day47.toString();
//        int int49 = day47.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(range7);
//        org.junit.Assert.assertNull(plot8);
//        org.junit.Assert.assertNotNull(tickUnitSource19);
//        org.junit.Assert.assertNotNull(font31);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
//        org.junit.Assert.assertNotNull(range34);
//        org.junit.Assert.assertNull(plot35);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNull(str38);
//        org.junit.Assert.assertNotNull(font44);
//        org.junit.Assert.assertNotNull(timeZone46);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "13-June-2019" + "'", str48.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 13 + "'", int49 == 13);
//    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        xYPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = xYPlot0.getOutlinePaint();
        org.jfree.chart.util.Layer layer4 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(layer4);
        boolean boolean6 = xYPlot0.isSubplot();
        java.awt.Paint paint7 = xYPlot0.getRangeGridlinePaint();
        xYPlot0.mapDatasetToDomainAxis(0, (int) (byte) -1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener11 = null;
        xYPlot0.removeChangeListener(plotChangeListener11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("");
        float float18 = categoryAxis17.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        boolean boolean20 = dateAxis19.isAutoTickUnitSelection();
        org.jfree.data.Range range21 = dateAxis19.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot22 = dateAxis19.getPlot();
        dateAxis19.setLabelURL("hi!");
        dateAxis19.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis17, (org.jfree.chart.axis.ValueAxis) dateAxis19, categoryItemRenderer28);
        categoryPlot29.setWeight((int) (byte) 0);
        org.jfree.chart.util.SortOrder sortOrder32 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot29.setRowRenderingOrder(sortOrder32);
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        boolean boolean35 = dateAxis34.isAutoTickUnitSelection();
        org.jfree.data.Range range36 = dateAxis34.getDefaultAutoRange();
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis();
        boolean boolean38 = dateAxis37.isAutoTickUnitSelection();
        org.jfree.data.Range range39 = dateAxis37.getDefaultAutoRange();
        dateAxis34.setRangeWithMargins(range39);
        categoryPlot29.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis34);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo43 = null;
        org.jfree.chart.plot.XYPlot xYPlot44 = new org.jfree.chart.plot.XYPlot();
        xYPlot44.configureDomainAxes();
        java.awt.geom.Point2D point2D46 = xYPlot44.getQuadrantOrigin();
        categoryPlot29.zoomDomainAxes((double) 1560409200000L, plotRenderingInfo43, point2D46, false);
        xYPlot0.zoomDomainAxes((double) 2019, plotRenderingInfo14, point2D46, true);
        java.awt.Paint paint51 = xYPlot0.getDomainTickBandPaint();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(layer4);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.0f + "'", float18 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(sortOrder32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(range36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(range39);
        org.junit.Assert.assertNotNull(point2D46);
        org.junit.Assert.assertNull(paint51);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis1.configure();
        double double3 = numberAxis1.getFixedAutoRange();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis1.setMarkerBand(markerAxisBand4);
        java.lang.Object obj6 = numberAxis1.clone();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        xYPlot16.setRangeCrosshairVisible(true);
        boolean boolean19 = xYPlot16.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        xYPlot20.configureDomainAxes();
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection23 = xYPlot20.getDomainMarkers(layer22);
        java.util.Collection collection24 = xYPlot16.getRangeMarkers(layer22);
        java.util.Collection collection25 = categoryPlot14.getRangeMarkers((int) (byte) 1, layer22);
        java.util.List list26 = categoryPlot14.getCategories();
        categoryPlot14.clearAnnotations();
        org.jfree.chart.util.SortOrder sortOrder28 = categoryPlot14.getColumnRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation30 = categoryPlot14.getDomainAxisLocation((int) 'a');
        boolean boolean31 = categoryPlot14.isRangeCrosshairVisible();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertNull(collection23);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertNull(list26);
        org.junit.Assert.assertNotNull(sortOrder28);
        org.junit.Assert.assertNotNull(axisLocation30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        java.lang.String str1 = categoryAnchor0.toString();
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CategoryAnchor.MIDDLE" + "'", str1.equals("CategoryAnchor.MIDDLE"));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis1.configure();
        java.lang.Object obj3 = numberAxis1.clone();
        numberAxis1.setAutoRangeIncludesZero(true);
        java.text.NumberFormat numberFormat6 = numberAxis1.getNumberFormatOverride();
        numberAxis1.setRangeWithMargins((double) (-16777216), (double) (byte) 10);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNull(numberFormat6);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis1.configure();
        double double3 = numberAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat6 = numberAxis5.getNumberFormatOverride();
        org.jfree.data.RangeType rangeType7 = numberAxis5.getRangeType();
        numberAxis1.setRangeType(rangeType7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        xYPlot9.addChangeListener(plotChangeListener10);
        java.awt.Paint paint12 = xYPlot9.getOutlinePaint();
        java.awt.Stroke stroke13 = xYPlot9.getRangeZeroBaselineStroke();
        numberAxis1.setTickMarkStroke(stroke13);
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis16.configure();
        java.lang.Object obj18 = numberAxis16.clone();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit19 = numberAxis16.getTickUnit();
        numberAxis1.setTickUnit(numberTickUnit19);
        java.text.NumberFormat numberFormat21 = numberAxis1.getNumberFormatOverride();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNull(numberFormat6);
        org.junit.Assert.assertNotNull(rangeType7);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(numberTickUnit19);
        org.junit.Assert.assertNull(numberFormat21);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis1.configure();
        double double3 = numberAxis1.getFixedAutoRange();
        numberAxis1.setAutoRangeStickyZero(true);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis1.configure();
        double double3 = numberAxis1.getFixedAutoRange();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis1.setMarkerBand(markerAxisBand4);
        numberAxis1.setTickMarkOutsideLength((float) 1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        org.jfree.chart.plot.Marker marker15 = null;
        boolean boolean16 = categoryPlot14.removeDomainMarker(marker15);
        java.util.List list17 = categoryPlot14.getAnnotations();
        java.awt.Stroke stroke18 = categoryPlot14.getRangeGridlineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent19 = null;
        categoryPlot14.rendererChanged(rendererChangeEvent19);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis("");
        float float26 = categoryAxis25.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        boolean boolean28 = dateAxis27.isAutoTickUnitSelection();
        org.jfree.data.Range range29 = dateAxis27.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot30 = dateAxis27.getPlot();
        dateAxis27.setLabelURL("hi!");
        dateAxis27.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis25, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer36);
        categoryPlot37.setWeight((int) (byte) 0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener40 = null;
        categoryPlot37.addChangeListener(plotChangeListener40);
        java.awt.Color color42 = java.awt.Color.YELLOW;
        categoryPlot37.setDomainGridlinePaint((java.awt.Paint) color42);
        org.jfree.data.category.CategoryDataset categoryDataset45 = null;
        categoryPlot37.setDataset((int) (short) 10, categoryDataset45);
        float float47 = categoryPlot37.getBackgroundAlpha();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo49 = null;
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot();
        xYPlot50.configureDomainAxes();
        java.awt.geom.Point2D point2D52 = xYPlot50.getQuadrantOrigin();
        categoryPlot37.zoomDomainAxes(0.0d, plotRenderingInfo49, point2D52, false);
        categoryPlot14.zoomDomainAxes(18.0d, plotRenderingInfo22, point2D52);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(list17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 0.0f + "'", float26 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertNull(plot30);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertTrue("'" + float47 + "' != '" + 1.0f + "'", float47 == 1.0f);
        org.junit.Assert.assertNotNull(point2D52);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        boolean boolean3 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        xYPlot0.removeChangeListener(plotChangeListener4);
        double double6 = xYPlot0.getRangeCrosshairValue();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        xYPlot3.setRangeCrosshairVisible(true);
        boolean boolean6 = xYPlot3.isRangeCrosshairLockedOnData();
        java.lang.String str7 = xYPlot3.getPlotType();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis("");
        float float11 = categoryAxis10.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        boolean boolean13 = dateAxis12.isAutoTickUnitSelection();
        org.jfree.data.Range range14 = dateAxis12.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot15 = dateAxis12.getPlot();
        dateAxis12.setLabelURL("hi!");
        dateAxis12.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis12, categoryItemRenderer21);
        org.jfree.chart.plot.Marker marker23 = null;
        boolean boolean24 = categoryPlot22.removeDomainMarker(marker23);
        java.util.List list25 = categoryPlot22.getAnnotations();
        java.awt.Stroke stroke26 = categoryPlot22.getRangeGridlineStroke();
        xYPlot3.setRangeCrosshairStroke(stroke26);
        xYPlot0.setDomainCrosshairStroke(stroke26);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "XY Plot" + "'", str7.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.0f + "'", float11 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNull(plot15);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(list25);
        org.junit.Assert.assertNotNull(stroke26);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        float float4 = categoryAxis3.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        boolean boolean6 = dateAxis5.isAutoTickUnitSelection();
        org.jfree.data.Range range7 = dateAxis5.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot8 = dateAxis5.getPlot();
        dateAxis5.setLabelURL("hi!");
        dateAxis5.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer14);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        dateAxis16.setTickMarksVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource19 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis16.setStandardTickUnits(tickUnitSource19);
        java.text.DateFormat dateFormat21 = null;
        dateAxis16.setDateFormatOverride(dateFormat21);
        dateAxis16.setTickMarksVisible(true);
        dateAxis16.setRange((double) (-1L), 1.0E-8d);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis16, categoryItemRenderer28);
        java.awt.Font font31 = categoryAxis3.getTickLabelFont((java.lang.Comparable) 'a');
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
        boolean boolean33 = dateAxis32.isAutoTickUnitSelection();
        org.jfree.data.Range range34 = dateAxis32.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot35 = dateAxis32.getPlot();
        java.util.Date date36 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis32.setMinimumDate(date36);
        java.lang.String str38 = categoryAxis3.getCategoryLabelToolTip((java.lang.Comparable) date36);
        categoryAxis3.clearCategoryLabelToolTips();
        double double40 = categoryAxis3.getCategoryMargin();
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.data.category.CategoryDataset categoryDataset44 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = new org.jfree.chart.axis.CategoryAxis("");
        float float47 = categoryAxis46.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis48 = new org.jfree.chart.axis.DateAxis();
        boolean boolean49 = dateAxis48.isAutoTickUnitSelection();
        org.jfree.data.Range range50 = dateAxis48.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot51 = dateAxis48.getPlot();
        dateAxis48.setLabelURL("hi!");
        dateAxis48.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer57 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot58 = new org.jfree.chart.plot.CategoryPlot(categoryDataset44, categoryAxis46, (org.jfree.chart.axis.ValueAxis) dateAxis48, categoryItemRenderer57);
        org.jfree.chart.plot.XYPlot xYPlot60 = new org.jfree.chart.plot.XYPlot();
        xYPlot60.setRangeCrosshairVisible(true);
        boolean boolean63 = xYPlot60.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot64 = new org.jfree.chart.plot.XYPlot();
        xYPlot64.configureDomainAxes();
        org.jfree.chart.util.Layer layer66 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection67 = xYPlot64.getDomainMarkers(layer66);
        java.util.Collection collection68 = xYPlot60.getRangeMarkers(layer66);
        java.util.Collection collection69 = categoryPlot58.getRangeMarkers((int) (byte) 1, layer66);
        org.jfree.chart.util.RectangleEdge rectangleEdge71 = categoryPlot58.getRangeAxisEdge((int) ' ');
        try {
            double double72 = categoryAxis3.getCategoryEnd(2019, (int) (byte) 100, rectangle2D43, rectangleEdge71);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(tickUnitSource19);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(range34);
        org.junit.Assert.assertNull(plot35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.2d + "'", double40 == 0.2d);
        org.junit.Assert.assertTrue("'" + float47 + "' != '" + 0.0f + "'", float47 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(range50);
        org.junit.Assert.assertNull(plot51);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNotNull(layer66);
        org.junit.Assert.assertNull(collection67);
        org.junit.Assert.assertNull(collection68);
        org.junit.Assert.assertNull(collection69);
        org.junit.Assert.assertNotNull(rectangleEdge71);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        xYPlot1.configureDomainAxes();
        java.lang.String str3 = xYPlot1.getNoDataMessage();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis("");
        float float9 = categoryAxis8.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        boolean boolean11 = dateAxis10.isAutoTickUnitSelection();
        org.jfree.data.Range range12 = dateAxis10.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot13 = dateAxis10.getPlot();
        dateAxis10.setLabelURL("hi!");
        dateAxis10.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis10, categoryItemRenderer19);
        org.jfree.chart.plot.Marker marker21 = null;
        boolean boolean22 = categoryPlot20.removeDomainMarker(marker21);
        java.util.List list23 = categoryPlot20.getAnnotations();
        xYPlot1.drawDomainTickBands(graphics2D4, rectangle2D5, list23);
        boolean boolean25 = day0.equals((java.lang.Object) xYPlot1);
        org.jfree.chart.axis.AxisSpace axisSpace26 = null;
        xYPlot1.setFixedRangeAxisSpace(axisSpace26);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.0f + "'", float9 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNull(plot13);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(list23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        boolean boolean3 = xYPlot0.isRangeCrosshairLockedOnData();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.util.List list6 = null;
        xYPlot0.drawDomainTickBands(graphics2D4, rectangle2D5, list6);
        double double8 = xYPlot0.getRangeCrosshairValue();
        java.awt.Stroke stroke9 = xYPlot0.getOutlineStroke();
        xYPlot0.mapDatasetToRangeAxis((int) (short) -1, 6);
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        xYPlot13.setRangeCrosshairValue((double) (-1L));
        xYPlot0.setParent((org.jfree.chart.plot.Plot) xYPlot13);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder17 = xYPlot13.getSeriesRenderingOrder();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(seriesRenderingOrder17);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureDomainAxes();
        xYPlot0.zoom((double) 10);
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean6 = xYPlot0.removeDomainMarker(marker4, layer5);
        double double7 = xYPlot0.getRangeCrosshairValue();
        java.awt.Paint paint8 = xYPlot0.getDomainGridlinePaint();
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        int int10 = xYPlot0.indexOf(xYDataset9);
        int int11 = xYPlot0.getDomainAxisCount();
        org.junit.Assert.assertNotNull(layer5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureDomainAxes();
        xYPlot0.zoom((double) 10);
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean6 = xYPlot0.removeDomainMarker(marker4, layer5);
        double double7 = xYPlot0.getRangeCrosshairValue();
        java.awt.Paint paint8 = xYPlot0.getDomainGridlinePaint();
        xYPlot0.setRangeCrosshairValue(0.2d);
        org.junit.Assert.assertNotNull(layer5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        float float4 = categoryAxis3.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        boolean boolean6 = dateAxis5.isAutoTickUnitSelection();
        org.jfree.data.Range range7 = dateAxis5.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot8 = dateAxis5.getPlot();
        dateAxis5.setLabelURL("hi!");
        dateAxis5.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer14);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        dateAxis16.setTickMarksVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource19 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis16.setStandardTickUnits(tickUnitSource19);
        java.text.DateFormat dateFormat21 = null;
        dateAxis16.setDateFormatOverride(dateFormat21);
        dateAxis16.setTickMarksVisible(true);
        dateAxis16.setRange((double) (-1L), 1.0E-8d);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis16, categoryItemRenderer28);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray30 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot29.setRenderers(categoryItemRendererArray30);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor32 = categoryPlot29.getDomainGridlinePosition();
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(tickUnitSource19);
        org.junit.Assert.assertNotNull(categoryItemRendererArray30);
        org.junit.Assert.assertNotNull(categoryAnchor32);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        java.awt.Stroke stroke0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 100L, (double) 'a', (double) 100, (double) 15);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureDomainAxes();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat4 = numberAxis3.getNumberFormatOverride();
        org.jfree.data.RangeType rangeType5 = numberAxis3.getRangeType();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis3.setMarkerBand(markerAxisBand6);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis9.configure();
        double double11 = numberAxis9.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat14 = numberAxis13.getNumberFormatOverride();
        org.jfree.data.RangeType rangeType15 = numberAxis13.getRangeType();
        numberAxis9.setRangeType(rangeType15);
        numberAxis3.setRangeType(rangeType15);
        xYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis3);
        java.text.NumberFormat numberFormat19 = numberAxis3.getNumberFormatOverride();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand20 = numberAxis3.getMarkerBand();
        org.junit.Assert.assertNull(numberFormat4);
        org.junit.Assert.assertNotNull(rangeType5);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNull(numberFormat14);
        org.junit.Assert.assertNotNull(rangeType15);
        org.junit.Assert.assertNull(numberFormat19);
        org.junit.Assert.assertNull(markerAxisBand20);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        java.lang.String str1 = lengthAdjustmentType0.toString();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        xYPlot2.setRangeCrosshairVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        xYPlot2.setInsets(rectangleInsets5, true);
        java.awt.Paint paint8 = xYPlot2.getDomainTickBandPaint();
        java.lang.String str9 = xYPlot2.getPlotType();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape11 = dateAxis10.getLeftArrow();
        java.awt.Paint paint12 = dateAxis10.getAxisLinePaint();
        int int13 = xYPlot2.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis10);
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot();
        xYPlot14.setRangeCrosshairVisible(true);
        boolean boolean17 = xYPlot14.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        xYPlot18.configureDomainAxes();
        org.jfree.chart.util.Layer layer20 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection21 = xYPlot18.getDomainMarkers(layer20);
        java.util.Collection collection22 = xYPlot14.getRangeMarkers(layer20);
        java.awt.Stroke stroke23 = xYPlot14.getDomainZeroBaselineStroke();
        dateAxis10.setTickMarkStroke(stroke23);
        boolean boolean25 = lengthAdjustmentType0.equals((java.lang.Object) dateAxis10);
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis("");
        float float29 = categoryAxis28.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis();
        boolean boolean31 = dateAxis30.isAutoTickUnitSelection();
        org.jfree.data.Range range32 = dateAxis30.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot33 = dateAxis30.getPlot();
        dateAxis30.setLabelURL("hi!");
        dateAxis30.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset26, categoryAxis28, (org.jfree.chart.axis.ValueAxis) dateAxis30, categoryItemRenderer39);
        org.jfree.chart.axis.ValueAxis valueAxis41 = categoryPlot40.getRangeAxis();
        boolean boolean42 = lengthAdjustmentType0.equals((java.lang.Object) categoryPlot40);
        java.awt.Color color46 = java.awt.Color.red;
        java.awt.image.ColorModel colorModel47 = null;
        java.awt.Rectangle rectangle48 = null;
        java.awt.geom.Rectangle2D rectangle2D49 = null;
        java.awt.geom.AffineTransform affineTransform50 = null;
        java.awt.RenderingHints renderingHints51 = null;
        java.awt.PaintContext paintContext52 = color46.createContext(colorModel47, rectangle48, rectangle2D49, affineTransform50, renderingHints51);
        java.awt.Color color53 = color46.darker();
        java.awt.color.ColorSpace colorSpace54 = color46.getColorSpace();
        float[] floatArray60 = new float[] { 2, (byte) 0, 0L, '4', 9 };
        float[] floatArray61 = color46.getRGBComponents(floatArray60);
        float[] floatArray62 = java.awt.Color.RGBtoHSB(8, 6, (int) ' ', floatArray60);
        boolean boolean63 = lengthAdjustmentType0.equals((java.lang.Object) 8);
        java.awt.Paint[] paintArray64 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Paint[] paintArray65 = new java.awt.Paint[] {};
        java.awt.Stroke[] strokeArray66 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray67 = new java.awt.Stroke[] {};
        java.awt.Shape shape68 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape[] shapeArray69 = new java.awt.Shape[] { shape68 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier70 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray64, paintArray65, strokeArray66, strokeArray67, shapeArray69);
        java.awt.Stroke stroke71 = defaultDrawingSupplier70.getNextStroke();
        java.awt.Paint paint72 = defaultDrawingSupplier70.getNextFillPaint();
        java.awt.Stroke stroke73 = defaultDrawingSupplier70.getNextStroke();
        boolean boolean74 = lengthAdjustmentType0.equals((java.lang.Object) defaultDrawingSupplier70);
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "EXPAND" + "'", str1.equals("EXPAND"));
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "XY Plot" + "'", str9.equals("XY Plot"));
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(layer20);
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 0.0f + "'", float29 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertNull(plot33);
        org.junit.Assert.assertNotNull(valueAxis41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(paintContext52);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertNotNull(colorSpace54);
        org.junit.Assert.assertNotNull(floatArray60);
        org.junit.Assert.assertNotNull(floatArray61);
        org.junit.Assert.assertNotNull(floatArray62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(paintArray64);
        org.junit.Assert.assertNotNull(paintArray65);
        org.junit.Assert.assertNotNull(strokeArray66);
        org.junit.Assert.assertNotNull(strokeArray67);
        org.junit.Assert.assertNotNull(shape68);
        org.junit.Assert.assertNotNull(shapeArray69);
        org.junit.Assert.assertNotNull(stroke71);
        org.junit.Assert.assertNotNull(paint72);
        org.junit.Assert.assertNotNull(stroke73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        org.jfree.chart.plot.Marker marker15 = null;
        boolean boolean16 = categoryPlot14.removeDomainMarker(marker15);
        java.util.List list17 = categoryPlot14.getAnnotations();
        categoryPlot14.setBackgroundImageAlignment((int) (short) 100);
        categoryPlot14.configureRangeAxes();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(list17);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        xYPlot0.setInsets(rectangleInsets3, true);
        java.awt.Paint paint6 = xYPlot0.getDomainTickBandPaint();
        java.lang.String str7 = xYPlot0.getPlotType();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape9 = dateAxis8.getLeftArrow();
        java.awt.Paint paint10 = dateAxis8.getAxisLinePaint();
        int int11 = xYPlot0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis8);
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        dateAxis8.setLabelPaint(paint12);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        dateAxis14.setTickMarksVisible(true);
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener18 = null;
        xYPlot17.addChangeListener(plotChangeListener18);
        dateAxis14.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot17);
        org.jfree.chart.axis.DateTickUnit dateTickUnit21 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date22 = dateAxis14.calculateHighestVisibleTickValue(dateTickUnit21);
        dateAxis8.setTickUnit(dateTickUnit21, true, true);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "XY Plot" + "'", str7.equals("XY Plot"));
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(dateTickUnit21);
        org.junit.Assert.assertNotNull(date22);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        xYPlot0.setInsets(rectangleInsets3, true);
        java.awt.Paint paint6 = xYPlot0.getDomainTickBandPaint();
        java.lang.String str7 = xYPlot0.getPlotType();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape9 = dateAxis8.getLeftArrow();
        java.awt.Paint paint10 = dateAxis8.getAxisLinePaint();
        int int11 = xYPlot0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis8);
        xYPlot0.configureRangeAxes();
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "XY Plot" + "'", str7.equals("XY Plot"));
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isAutoTickUnitSelection();
        org.jfree.data.Range range2 = dateAxis0.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot3 = dateAxis0.getPlot();
        dateAxis0.setLabelURL("hi!");
        dateAxis0.setLowerMargin(0.0d);
        org.jfree.chart.axis.Timeline timeline8 = dateAxis0.getTimeline();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(timeline8);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType1 = rectangleInsets0.getUnitType();
        double double3 = rectangleInsets0.calculateRightInset((double) (byte) -1);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(unitType1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getLeftArrow();
        dateAxis0.setRangeWithMargins((double) (byte) -1, (double) (short) 1);
        java.util.Date date5 = dateAxis0.getMaximumDate();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        boolean boolean3 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        xYPlot4.configureDomainAxes();
        org.jfree.chart.util.Layer layer6 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection7 = xYPlot4.getDomainMarkers(layer6);
        java.util.Collection collection8 = xYPlot0.getRangeMarkers(layer6);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = xYPlot0.getInsets();
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        xYPlot0.setDataset(xYDataset10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(layer6);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(rectangleInsets9);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        xYPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = xYPlot0.getOutlinePaint();
        org.jfree.chart.util.Layer layer4 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(layer4);
        boolean boolean6 = xYPlot0.isSubplot();
        java.awt.Paint paint7 = xYPlot0.getRangeGridlinePaint();
        xYPlot0.mapDatasetToDomainAxis(0, (int) (byte) -1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener11 = null;
        xYPlot0.removeChangeListener(plotChangeListener11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("");
        float float18 = categoryAxis17.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        boolean boolean20 = dateAxis19.isAutoTickUnitSelection();
        org.jfree.data.Range range21 = dateAxis19.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot22 = dateAxis19.getPlot();
        dateAxis19.setLabelURL("hi!");
        dateAxis19.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis17, (org.jfree.chart.axis.ValueAxis) dateAxis19, categoryItemRenderer28);
        categoryPlot29.setWeight((int) (byte) 0);
        org.jfree.chart.util.SortOrder sortOrder32 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot29.setRowRenderingOrder(sortOrder32);
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        boolean boolean35 = dateAxis34.isAutoTickUnitSelection();
        org.jfree.data.Range range36 = dateAxis34.getDefaultAutoRange();
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis();
        boolean boolean38 = dateAxis37.isAutoTickUnitSelection();
        org.jfree.data.Range range39 = dateAxis37.getDefaultAutoRange();
        dateAxis34.setRangeWithMargins(range39);
        categoryPlot29.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis34);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo43 = null;
        org.jfree.chart.plot.XYPlot xYPlot44 = new org.jfree.chart.plot.XYPlot();
        xYPlot44.configureDomainAxes();
        java.awt.geom.Point2D point2D46 = xYPlot44.getQuadrantOrigin();
        categoryPlot29.zoomDomainAxes((double) 1560409200000L, plotRenderingInfo43, point2D46, false);
        xYPlot0.zoomDomainAxes((double) 2019, plotRenderingInfo14, point2D46, true);
        org.jfree.chart.plot.Marker marker52 = null;
        org.jfree.chart.plot.XYPlot xYPlot53 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener54 = null;
        xYPlot53.addChangeListener(plotChangeListener54);
        java.awt.Paint paint56 = xYPlot53.getOutlinePaint();
        org.jfree.chart.util.Layer layer57 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection58 = xYPlot53.getRangeMarkers(layer57);
        try {
            xYPlot0.addDomainMarker(3, marker52, layer57);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(layer4);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.0f + "'", float18 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(sortOrder32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(range36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(range39);
        org.junit.Assert.assertNotNull(point2D46);
        org.junit.Assert.assertNotNull(paint56);
        org.junit.Assert.assertNotNull(layer57);
        org.junit.Assert.assertNull(collection58);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        xYPlot0.clearDomainMarkers((int) (short) 10);
        double double5 = xYPlot0.getDomainCrosshairValue();
        org.jfree.data.general.DatasetGroup datasetGroup6 = xYPlot0.getDatasetGroup();
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) true);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType10 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        java.lang.String str11 = lengthAdjustmentType10.toString();
        categoryMarker9.setLabelOffsetType(lengthAdjustmentType10);
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryMarker9.setOutlineStroke(stroke13);
        java.awt.Stroke stroke15 = categoryMarker9.getOutlineStroke();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        categoryMarker9.setLabelAnchor(rectangleAnchor16);
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        xYPlot18.configureDomainAxes();
        xYPlot18.zoom((double) 10);
        org.jfree.chart.plot.Marker marker22 = null;
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean24 = xYPlot18.removeDomainMarker(marker22, layer23);
        xYPlot0.addDomainMarker(12, (org.jfree.chart.plot.Marker) categoryMarker9, layer23);
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis("");
        float float29 = categoryAxis28.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis();
        boolean boolean31 = dateAxis30.isAutoTickUnitSelection();
        org.jfree.data.Range range32 = dateAxis30.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot33 = dateAxis30.getPlot();
        dateAxis30.setLabelURL("hi!");
        dateAxis30.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset26, categoryAxis28, (org.jfree.chart.axis.ValueAxis) dateAxis30, categoryItemRenderer39);
        org.jfree.chart.plot.Marker marker41 = null;
        boolean boolean42 = categoryPlot40.removeDomainMarker(marker41);
        categoryMarker9.addChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot40);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNull(datasetGroup6);
        org.junit.Assert.assertNotNull(lengthAdjustmentType10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "EXPAND" + "'", str11.equals("EXPAND"));
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(rectangleAnchor16);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 0.0f + "'", float29 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertNull(plot33);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        boolean boolean3 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        xYPlot4.configureDomainAxes();
        org.jfree.chart.util.Layer layer6 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection7 = xYPlot4.getDomainMarkers(layer6);
        java.util.Collection collection8 = xYPlot0.getRangeMarkers(layer6);
        java.awt.Stroke stroke9 = xYPlot0.getDomainZeroBaselineStroke();
        int int10 = xYPlot0.getRangeAxisCount();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isTickLabelsVisible();
        xYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis11);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        xYPlot0.drawAnnotations(graphics2D14, rectangle2D15, plotRenderingInfo16);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(layer6);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        xYPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = xYPlot0.getOutlinePaint();
        java.awt.Stroke stroke4 = xYPlot0.getRangeZeroBaselineStroke();
        boolean boolean5 = xYPlot0.isDomainZoomable();
        int int6 = xYPlot0.getDatasetCount();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat10 = numberAxis9.getNumberFormatOverride();
        org.jfree.data.RangeType rangeType11 = numberAxis9.getRangeType();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand12 = null;
        numberAxis9.setMarkerBand(markerAxisBand12);
        xYPlot0.setDomainAxis((int) (short) 100, (org.jfree.chart.axis.ValueAxis) numberAxis9);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(numberFormat10);
        org.junit.Assert.assertNotNull(rangeType11);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        org.jfree.chart.plot.Marker marker15 = null;
        boolean boolean16 = categoryPlot14.removeDomainMarker(marker15);
        java.util.List list17 = categoryPlot14.getAnnotations();
        categoryPlot14.setBackgroundImageAlignment((int) (short) 100);
        org.jfree.chart.plot.CategoryMarker categoryMarker21 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) true);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType22 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        java.lang.String str23 = lengthAdjustmentType22.toString();
        categoryMarker21.setLabelOffsetType(lengthAdjustmentType22);
        java.awt.Stroke stroke25 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryMarker21.setOutlineStroke(stroke25);
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = new org.jfree.chart.axis.CategoryAxis("");
        float float30 = categoryAxis29.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis();
        boolean boolean32 = dateAxis31.isAutoTickUnitSelection();
        org.jfree.data.Range range33 = dateAxis31.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot34 = dateAxis31.getPlot();
        dateAxis31.setLabelURL("hi!");
        dateAxis31.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer40 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis29, (org.jfree.chart.axis.ValueAxis) dateAxis31, categoryItemRenderer40);
        org.jfree.chart.plot.XYPlot xYPlot43 = new org.jfree.chart.plot.XYPlot();
        xYPlot43.setRangeCrosshairVisible(true);
        boolean boolean46 = xYPlot43.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot47 = new org.jfree.chart.plot.XYPlot();
        xYPlot47.configureDomainAxes();
        org.jfree.chart.util.Layer layer49 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection50 = xYPlot47.getDomainMarkers(layer49);
        java.util.Collection collection51 = xYPlot43.getRangeMarkers(layer49);
        java.util.Collection collection52 = categoryPlot41.getRangeMarkers((int) (byte) 1, layer49);
        categoryPlot14.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker21, layer49);
        java.lang.Class class54 = null;
        try {
            java.util.EventListener[] eventListenerArray55 = categoryMarker21.getListeners(class54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(list17);
        org.junit.Assert.assertNotNull(lengthAdjustmentType22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "EXPAND" + "'", str23.equals("EXPAND"));
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 0.0f + "'", float30 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(range33);
        org.junit.Assert.assertNull(plot34);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(layer49);
        org.junit.Assert.assertNull(collection50);
        org.junit.Assert.assertNull(collection51);
        org.junit.Assert.assertNull(collection52);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.BOTTOM_RIGHT");
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        xYPlot16.setRangeCrosshairVisible(true);
        boolean boolean19 = xYPlot16.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        xYPlot20.configureDomainAxes();
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection23 = xYPlot20.getDomainMarkers(layer22);
        java.util.Collection collection24 = xYPlot16.getRangeMarkers(layer22);
        java.util.Collection collection25 = categoryPlot14.getRangeMarkers((int) (byte) 1, layer22);
        org.jfree.chart.LegendItemCollection legendItemCollection26 = categoryPlot14.getFixedLegendItems();
        java.awt.Paint paint27 = categoryPlot14.getRangeCrosshairPaint();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertNull(collection23);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertNull(legendItemCollection26);
        org.junit.Assert.assertNotNull(paint27);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        java.awt.Color color0 = java.awt.Color.blue;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        boolean boolean3 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        xYPlot4.configureDomainAxes();
        org.jfree.chart.util.Layer layer6 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection7 = xYPlot4.getDomainMarkers(layer6);
        java.util.Collection collection8 = xYPlot0.getRangeMarkers(layer6);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setParent((org.jfree.chart.plot.Plot) xYPlot9);
        xYPlot9.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.axis.ValueAxis valueAxis13 = xYPlot9.getDomainAxis();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(layer6);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNull(valueAxis13);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ChartChangeEventType.DATASET_UPDATED");
        numberAxis1.setLowerBound((double) 1560409200000L);
        org.jfree.chart.plot.CategoryMarker categoryMarker5 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) true);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType6 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        java.lang.String str7 = lengthAdjustmentType6.toString();
        categoryMarker5.setLabelOffsetType(lengthAdjustmentType6);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryMarker5.setOutlineStroke(stroke9);
        java.awt.Stroke stroke11 = categoryMarker5.getOutlineStroke();
        numberAxis1.setTickMarkStroke(stroke11);
        org.junit.Assert.assertNotNull(lengthAdjustmentType6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "EXPAND" + "'", str7.equals("EXPAND"));
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) textAnchor0);
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_OUTSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 2.0f + "'", float0 == 2.0f);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        java.lang.String str1 = unitType0.toString();
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UnitType.RELATIVE" + "'", str1.equals("UnitType.RELATIVE"));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat2 = numberAxis1.getNumberFormatOverride();
        org.jfree.data.RangeType rangeType3 = numberAxis1.getRangeType();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis1.setMarkerBand(markerAxisBand4);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis7.configure();
        double double9 = numberAxis7.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat12 = numberAxis11.getNumberFormatOverride();
        org.jfree.data.RangeType rangeType13 = numberAxis11.getRangeType();
        numberAxis7.setRangeType(rangeType13);
        numberAxis1.setRangeType(rangeType13);
        org.jfree.data.RangeType rangeType16 = numberAxis1.getRangeType();
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis18.configure();
        java.lang.Object obj20 = numberAxis18.clone();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit21 = numberAxis18.getTickUnit();
        numberAxis1.setTickUnit(numberTickUnit21);
        try {
            numberAxis1.setAutoRangeMinimumSize((double) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(numberFormat2);
        org.junit.Assert.assertNotNull(rangeType3);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNull(numberFormat12);
        org.junit.Assert.assertNotNull(rangeType13);
        org.junit.Assert.assertNotNull(rangeType16);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(numberTickUnit21);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        categoryPlot14.setWeight((int) (byte) 0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener17 = null;
        categoryPlot14.addChangeListener(plotChangeListener17);
        java.awt.Color color19 = java.awt.Color.YELLOW;
        categoryPlot14.setDomainGridlinePaint((java.awt.Paint) color19);
        boolean boolean21 = categoryPlot14.isDomainZoomable();
        org.jfree.data.general.DatasetGroup datasetGroup22 = categoryPlot14.getDatasetGroup();
        java.awt.Paint paint23 = categoryPlot14.getRangeCrosshairPaint();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(datasetGroup22);
        org.junit.Assert.assertNotNull(paint23);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        org.jfree.chart.plot.Marker marker15 = null;
        boolean boolean16 = categoryPlot14.removeDomainMarker(marker15);
        java.util.List list17 = categoryPlot14.getAnnotations();
        java.lang.Object obj18 = categoryPlot14.clone();
        org.jfree.chart.util.SortOrder sortOrder19 = categoryPlot14.getColumnRenderingOrder();
        categoryPlot14.clearDomainMarkers();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(list17);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(sortOrder19);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.color.ColorSpace colorSpace1 = color0.getColorSpace();
        int int2 = color0.getRed();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(colorSpace1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 64 + "'", int2 == 64);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        categoryPlot14.setWeight((int) (byte) 0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener17 = null;
        categoryPlot14.addChangeListener(plotChangeListener17);
        org.jfree.chart.axis.AxisLocation axisLocation20 = null;
        categoryPlot14.setRangeAxisLocation((int) (short) 1, axisLocation20);
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot();
        xYPlot22.setRangeCrosshairVisible(true);
        boolean boolean25 = xYPlot22.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot();
        xYPlot26.configureDomainAxes();
        org.jfree.chart.util.Layer layer28 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection29 = xYPlot26.getDomainMarkers(layer28);
        java.util.Collection collection30 = xYPlot22.getRangeMarkers(layer28);
        java.awt.Stroke stroke31 = xYPlot22.getDomainZeroBaselineStroke();
        categoryPlot14.setRangeGridlineStroke(stroke31);
        java.awt.Color color33 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.color.ColorSpace colorSpace34 = color33.getColorSpace();
        categoryPlot14.setOutlinePaint((java.awt.Paint) color33);
        org.jfree.chart.plot.Plot plot36 = categoryPlot14.getParent();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(layer28);
        org.junit.Assert.assertNull(collection29);
        org.junit.Assert.assertNull(collection30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(colorSpace34);
        org.junit.Assert.assertNull(plot36);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        boolean boolean3 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureDomainAxes();
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat9 = numberAxis8.getNumberFormatOverride();
        org.jfree.data.RangeType rangeType10 = numberAxis8.getRangeType();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand11 = null;
        numberAxis8.setMarkerBand(markerAxisBand11);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis14.configure();
        double double16 = numberAxis14.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat19 = numberAxis18.getNumberFormatOverride();
        org.jfree.data.RangeType rangeType20 = numberAxis18.getRangeType();
        numberAxis14.setRangeType(rangeType20);
        numberAxis8.setRangeType(rangeType20);
        xYPlot5.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis8);
        xYPlot0.setRangeAxis(255, (org.jfree.chart.axis.ValueAxis) numberAxis8, false);
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis28.configure();
        java.lang.Object obj30 = numberAxis28.clone();
        numberAxis28.setAutoRangeIncludesZero(true);
        java.text.NumberFormat numberFormat33 = numberAxis28.getNumberFormatOverride();
        xYPlot0.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) numberAxis28);
        org.jfree.chart.plot.CategoryMarker categoryMarker37 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) true);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType38 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        java.lang.String str39 = lengthAdjustmentType38.toString();
        categoryMarker37.setLabelOffsetType(lengthAdjustmentType38);
        org.jfree.chart.plot.XYPlot xYPlot41 = new org.jfree.chart.plot.XYPlot();
        xYPlot41.configureDomainAxes();
        xYPlot41.zoom((double) 10);
        org.jfree.chart.plot.Marker marker45 = null;
        org.jfree.chart.util.Layer layer46 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean47 = xYPlot41.removeDomainMarker(marker45, layer46);
        boolean boolean49 = xYPlot0.removeDomainMarker(4, (org.jfree.chart.plot.Marker) categoryMarker37, layer46, true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(numberFormat9);
        org.junit.Assert.assertNotNull(rangeType10);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNull(numberFormat19);
        org.junit.Assert.assertNotNull(rangeType20);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertNull(numberFormat33);
        org.junit.Assert.assertNotNull(lengthAdjustmentType38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "EXPAND" + "'", str39.equals("EXPAND"));
        org.junit.Assert.assertNotNull(layer46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit0 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        org.junit.Assert.assertNotNull(numberTickUnit0);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        categoryPlot14.setWeight((int) (byte) 0);
        org.jfree.chart.util.SortOrder sortOrder17 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot14.setRowRenderingOrder(sortOrder17);
        org.jfree.chart.LegendItemCollection legendItemCollection19 = categoryPlot14.getFixedLegendItems();
        categoryPlot14.setAnchorValue((double) 255);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = categoryPlot14.getDomainAxisForDataset((int) (short) 10);
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis("");
        float float27 = categoryAxis26.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis();
        boolean boolean29 = dateAxis28.isAutoTickUnitSelection();
        org.jfree.data.Range range30 = dateAxis28.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot31 = dateAxis28.getPlot();
        dateAxis28.setLabelURL("hi!");
        dateAxis28.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis26, (org.jfree.chart.axis.ValueAxis) dateAxis28, categoryItemRenderer37);
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot();
        xYPlot40.setRangeCrosshairVisible(true);
        boolean boolean43 = xYPlot40.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot44 = new org.jfree.chart.plot.XYPlot();
        xYPlot44.configureDomainAxes();
        org.jfree.chart.util.Layer layer46 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection47 = xYPlot44.getDomainMarkers(layer46);
        java.util.Collection collection48 = xYPlot40.getRangeMarkers(layer46);
        java.util.Collection collection49 = categoryPlot38.getRangeMarkers((int) (byte) 1, layer46);
        java.util.List list50 = categoryPlot38.getCategories();
        org.jfree.chart.util.RectangleInsets rectangleInsets51 = categoryPlot38.getAxisOffset();
        categoryAxis23.setLabelInsets(rectangleInsets51);
        double double53 = categoryAxis23.getLowerMargin();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(sortOrder17);
        org.junit.Assert.assertNull(legendItemCollection19);
        org.junit.Assert.assertNotNull(categoryAxis23);
        org.junit.Assert.assertTrue("'" + float27 + "' != '" + 0.0f + "'", float27 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNull(plot31);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(layer46);
        org.junit.Assert.assertNull(collection47);
        org.junit.Assert.assertNull(collection48);
        org.junit.Assert.assertNull(collection49);
        org.junit.Assert.assertNull(list50);
        org.junit.Assert.assertNotNull(rectangleInsets51);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.05d + "'", double53 == 0.05d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        xYPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = xYPlot0.getOutlinePaint();
        org.jfree.chart.util.Layer layer4 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(layer4);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        xYPlot6.setRangeCrosshairVisible(true);
        xYPlot6.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        int int12 = xYPlot6.getRangeAxisIndex(valueAxis11);
        xYPlot6.setDomainZeroBaselineVisible(false);
        java.awt.Color color15 = java.awt.Color.red;
        java.awt.image.ColorModel colorModel16 = null;
        java.awt.Rectangle rectangle17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        java.awt.geom.AffineTransform affineTransform19 = null;
        java.awt.RenderingHints renderingHints20 = null;
        java.awt.PaintContext paintContext21 = color15.createContext(colorModel16, rectangle17, rectangle2D18, affineTransform19, renderingHints20);
        java.awt.Color color22 = color15.darker();
        java.awt.color.ColorSpace colorSpace23 = color15.getColorSpace();
        int int24 = color15.getGreen();
        java.awt.Color color25 = color15.darker();
        xYPlot6.setOutlinePaint((java.awt.Paint) color25);
        xYPlot6.clearDomainAxes();
        java.awt.Color color28 = java.awt.Color.YELLOW;
        java.awt.Color color29 = color28.darker();
        java.awt.Color color30 = java.awt.Color.red;
        java.awt.image.ColorModel colorModel31 = null;
        java.awt.Rectangle rectangle32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        java.awt.geom.AffineTransform affineTransform34 = null;
        java.awt.RenderingHints renderingHints35 = null;
        java.awt.PaintContext paintContext36 = color30.createContext(colorModel31, rectangle32, rectangle2D33, affineTransform34, renderingHints35);
        java.awt.Color color37 = color30.darker();
        java.awt.color.ColorSpace colorSpace38 = color30.getColorSpace();
        float[] floatArray44 = new float[] { 2, (byte) 0, 0L, '4', 9 };
        float[] floatArray45 = color30.getRGBComponents(floatArray44);
        float[] floatArray46 = color29.getColorComponents(floatArray44);
        xYPlot6.setRangeTickBandPaint((java.awt.Paint) color29);
        xYPlot0.setRangeGridlinePaint((java.awt.Paint) color29);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(layer4);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(paintContext21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(colorSpace23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(paintContext36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(colorSpace38);
        org.junit.Assert.assertNotNull(floatArray44);
        org.junit.Assert.assertNotNull(floatArray45);
        org.junit.Assert.assertNotNull(floatArray46);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        xYPlot16.setRangeCrosshairVisible(true);
        boolean boolean19 = xYPlot16.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        xYPlot20.configureDomainAxes();
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection23 = xYPlot20.getDomainMarkers(layer22);
        java.util.Collection collection24 = xYPlot16.getRangeMarkers(layer22);
        java.util.Collection collection25 = categoryPlot14.getRangeMarkers((int) (byte) 1, layer22);
        java.util.List list26 = categoryPlot14.getCategories();
        categoryPlot14.clearAnnotations();
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = categoryPlot14.getRangeAxisEdge();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = categoryPlot14.getRenderer(7);
        org.jfree.data.category.CategoryDataset categoryDataset31 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis("");
        float float34 = categoryAxis33.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis();
        boolean boolean36 = dateAxis35.isAutoTickUnitSelection();
        org.jfree.data.Range range37 = dateAxis35.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot38 = dateAxis35.getPlot();
        dateAxis35.setLabelURL("hi!");
        dateAxis35.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer44 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot(categoryDataset31, categoryAxis33, (org.jfree.chart.axis.ValueAxis) dateAxis35, categoryItemRenderer44);
        org.jfree.chart.util.SortOrder sortOrder46 = categoryPlot45.getColumnRenderingOrder();
        categoryPlot14.setRowRenderingOrder(sortOrder46);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertNull(collection23);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertNull(list26);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertNull(categoryItemRenderer30);
        org.junit.Assert.assertTrue("'" + float34 + "' != '" + 0.0f + "'", float34 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertNull(plot38);
        org.junit.Assert.assertNotNull(sortOrder46);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        boolean boolean3 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        xYPlot4.configureDomainAxes();
        org.jfree.chart.util.Layer layer6 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection7 = xYPlot4.getDomainMarkers(layer6);
        java.util.Collection collection8 = xYPlot0.getRangeMarkers(layer6);
        java.awt.Stroke stroke9 = xYPlot0.getDomainZeroBaselineStroke();
        int int10 = xYPlot0.getRangeAxisCount();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        dateAxis11.setTickMarksVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource14 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis11.setStandardTickUnits(tickUnitSource14);
        boolean boolean16 = dateAxis11.isAutoRange();
        int int17 = xYPlot0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis11);
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        xYPlot0.setDomainTickBandPaint((java.awt.Paint) color18);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(layer6);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(tickUnitSource14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(color18);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        org.jfree.chart.axis.ValueAxis valueAxis15 = categoryPlot14.getRangeAxis();
        java.awt.Stroke stroke16 = categoryPlot14.getRangeGridlineStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker19 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) true);
        org.jfree.chart.util.Layer layer20 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean21 = categoryPlot14.removeRangeMarker((int) (byte) 1, (org.jfree.chart.plot.Marker) categoryMarker19, layer20);
        java.lang.String str22 = layer20.toString();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(valueAxis15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(layer20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Layer.FOREGROUND" + "'", str22.equals("Layer.FOREGROUND"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        org.jfree.chart.plot.Marker marker15 = null;
        boolean boolean16 = categoryPlot14.removeDomainMarker(marker15);
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        categoryPlot14.setFixedRangeAxisSpace(axisSpace17, false);
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis("");
        float float23 = categoryAxis22.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis();
        boolean boolean25 = dateAxis24.isAutoTickUnitSelection();
        org.jfree.data.Range range26 = dateAxis24.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot27 = dateAxis24.getPlot();
        dateAxis24.setLabelURL("hi!");
        dateAxis24.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis22, (org.jfree.chart.axis.ValueAxis) dateAxis24, categoryItemRenderer33);
        java.awt.Font font36 = categoryAxis22.getTickLabelFont((java.lang.Comparable) 0.0f);
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = new org.jfree.chart.axis.CategoryAxis("");
        float float39 = categoryAxis38.getMaximumCategoryLabelWidthRatio();
        categoryAxis38.setLabel("hi!");
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray42 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis22, categoryAxis38 };
        categoryPlot14.setDomainAxes(categoryAxisArray42);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 0.0f + "'", float23 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertTrue("'" + float39 + "' != '" + 0.0f + "'", float39 == 0.0f);
        org.junit.Assert.assertNotNull(categoryAxisArray42);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        xYPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = xYPlot0.getOutlinePaint();
        org.jfree.chart.util.Layer layer4 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(layer4);
        boolean boolean6 = xYPlot0.isSubplot();
        java.awt.Paint paint7 = xYPlot0.getRangeGridlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation9 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot0.setDomainAxisLocation((int) (byte) 1, axisLocation9, false);
        xYPlot0.clearDomainAxes();
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener14 = null;
        xYPlot13.addChangeListener(plotChangeListener14);
        java.awt.Paint paint16 = xYPlot13.getOutlinePaint();
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection18 = xYPlot13.getRangeMarkers(layer17);
        java.util.Collection collection19 = xYPlot0.getDomainMarkers(layer17);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(layer4);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertNull(collection19);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        xYPlot16.setRangeCrosshairVisible(true);
        boolean boolean19 = xYPlot16.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        xYPlot20.configureDomainAxes();
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection23 = xYPlot20.getDomainMarkers(layer22);
        java.util.Collection collection24 = xYPlot16.getRangeMarkers(layer22);
        java.util.Collection collection25 = categoryPlot14.getRangeMarkers((int) (byte) 1, layer22);
        java.util.List list26 = categoryPlot14.getCategories();
        java.awt.Graphics2D graphics2D27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        boolean boolean31 = categoryPlot14.render(graphics2D27, rectangle2D28, 0, plotRenderingInfo30);
        int int32 = categoryPlot14.getWeight();
        java.awt.Paint paint33 = categoryPlot14.getRangeCrosshairPaint();
        org.jfree.chart.axis.AxisSpace axisSpace34 = null;
        categoryPlot14.setFixedRangeAxisSpace(axisSpace34);
        org.jfree.data.xy.XYDataset xYDataset37 = null;
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis();
        dateAxis38.setTickMarksVisible(true);
        java.lang.Object obj41 = dateAxis38.clone();
        org.jfree.chart.axis.DateAxis dateAxis42 = new org.jfree.chart.axis.DateAxis();
        boolean boolean43 = dateAxis42.isAutoTickUnitSelection();
        org.jfree.data.Range range44 = dateAxis42.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot45 = dateAxis42.getPlot();
        dateAxis42.setLabelURL("hi!");
        dateAxis42.setLowerMargin(0.0d);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer50 = null;
        org.jfree.chart.plot.XYPlot xYPlot51 = new org.jfree.chart.plot.XYPlot(xYDataset37, (org.jfree.chart.axis.ValueAxis) dateAxis38, (org.jfree.chart.axis.ValueAxis) dateAxis42, xYItemRenderer50);
        categoryPlot14.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis38, false);
        org.jfree.chart.axis.ValueAxis valueAxis55 = categoryPlot14.getRangeAxisForDataset(15);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertNull(collection23);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertNull(list26);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(obj41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(range44);
        org.junit.Assert.assertNull(plot45);
        org.junit.Assert.assertNotNull(valueAxis55);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        boolean boolean3 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        xYPlot4.configureDomainAxes();
        org.jfree.chart.util.Layer layer6 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection7 = xYPlot4.getDomainMarkers(layer6);
        java.util.Collection collection8 = xYPlot0.getRangeMarkers(layer6);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setParent((org.jfree.chart.plot.Plot) xYPlot9);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        xYPlot9.rendererChanged(rendererChangeEvent11);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = xYPlot9.getDomainAxisEdge();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(layer6);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(rectangleEdge13);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureDomainAxes();
        org.jfree.chart.util.Layer layer2 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection3 = xYPlot0.getDomainMarkers(layer2);
        boolean boolean4 = xYPlot0.isDomainGridlinesVisible();
        xYPlot0.mapDatasetToRangeAxis((int) (byte) 100, 0);
        xYPlot0.clearRangeAxes();
        org.junit.Assert.assertNotNull(layer2);
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat2 = numberAxis1.getNumberFormatOverride();
        org.jfree.data.RangeType rangeType3 = numberAxis1.getRangeType();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis1.setMarkerBand(markerAxisBand4);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis7.configure();
        double double9 = numberAxis7.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat12 = numberAxis11.getNumberFormatOverride();
        org.jfree.data.RangeType rangeType13 = numberAxis11.getRangeType();
        numberAxis7.setRangeType(rangeType13);
        numberAxis1.setRangeType(rangeType13);
        org.jfree.data.RangeType rangeType16 = numberAxis1.getRangeType();
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis18.configure();
        java.lang.Object obj20 = numberAxis18.clone();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit21 = numberAxis18.getTickUnit();
        numberAxis1.setTickUnit(numberTickUnit21);
        boolean boolean23 = numberAxis1.isAutoRange();
        org.junit.Assert.assertNull(numberFormat2);
        org.junit.Assert.assertNotNull(rangeType3);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNull(numberFormat12);
        org.junit.Assert.assertNotNull(rangeType13);
        org.junit.Assert.assertNotNull(rangeType16);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(numberTickUnit21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        xYPlot16.setRangeCrosshairVisible(true);
        boolean boolean19 = xYPlot16.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        xYPlot20.configureDomainAxes();
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection23 = xYPlot20.getDomainMarkers(layer22);
        java.util.Collection collection24 = xYPlot16.getRangeMarkers(layer22);
        java.util.Collection collection25 = categoryPlot14.getRangeMarkers((int) (byte) 1, layer22);
        java.util.List list26 = categoryPlot14.getCategories();
        java.awt.Graphics2D graphics2D27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        boolean boolean31 = categoryPlot14.render(graphics2D27, rectangle2D28, 0, plotRenderingInfo30);
        categoryPlot14.clearDomainAxes();
        org.jfree.data.category.CategoryDataset categoryDataset33 = null;
        categoryPlot14.setDataset(categoryDataset33);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertNull(collection23);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertNull(list26);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat2 = numberAxis1.getNumberFormatOverride();
        org.jfree.data.RangeType rangeType3 = numberAxis1.getRangeType();
        boolean boolean4 = numberAxis1.isTickMarksVisible();
        double double5 = numberAxis1.getUpperMargin();
        numberAxis1.setFixedDimension((double) 3);
        java.awt.Stroke stroke8 = numberAxis1.getTickMarkStroke();
        org.junit.Assert.assertNull(numberFormat2);
        org.junit.Assert.assertNotNull(rangeType3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat2 = numberAxis1.getNumberFormatOverride();
        org.jfree.data.RangeType rangeType3 = numberAxis1.getRangeType();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis1.setMarkerBand(markerAxisBand4);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis7.configure();
        double double9 = numberAxis7.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat12 = numberAxis11.getNumberFormatOverride();
        org.jfree.data.RangeType rangeType13 = numberAxis11.getRangeType();
        numberAxis7.setRangeType(rangeType13);
        numberAxis1.setRangeType(rangeType13);
        org.jfree.data.RangeType rangeType16 = numberAxis1.getRangeType();
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis18.configure();
        java.lang.Object obj20 = numberAxis18.clone();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit21 = numberAxis18.getTickUnit();
        numberAxis1.setTickUnit(numberTickUnit21);
        java.awt.Shape shape23 = numberAxis1.getLeftArrow();
        org.junit.Assert.assertNull(numberFormat2);
        org.junit.Assert.assertNotNull(rangeType3);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNull(numberFormat12);
        org.junit.Assert.assertNotNull(rangeType13);
        org.junit.Assert.assertNotNull(rangeType16);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(numberTickUnit21);
        org.junit.Assert.assertNotNull(shape23);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat2 = numberAxis1.getNumberFormatOverride();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        boolean boolean4 = dateAxis3.isAutoTickUnitSelection();
        org.jfree.data.Range range5 = dateAxis3.getDefaultAutoRange();
        numberAxis1.setRangeWithMargins(range5);
        numberAxis1.setAutoRangeMinimumSize(1.0E-8d);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color9);
        org.junit.Assert.assertNull(numberFormat2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        boolean boolean3 = xYPlot0.isRangeCrosshairLockedOnData();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.util.List list6 = null;
        xYPlot0.drawDomainTickBands(graphics2D4, rectangle2D5, list6);
        double double8 = xYPlot0.getRangeCrosshairValue();
        java.awt.Stroke stroke9 = xYPlot0.getOutlineStroke();
        xYPlot0.mapDatasetToRangeAxis((int) (short) -1, 6);
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        xYPlot13.setRangeCrosshairValue((double) (-1L));
        xYPlot0.setParent((org.jfree.chart.plot.Plot) xYPlot13);
        boolean boolean17 = xYPlot13.isDomainGridlinesVisible();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureDomainAxes();
        xYPlot0.zoom((double) 10);
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean6 = xYPlot0.removeDomainMarker(marker4, layer5);
        java.awt.Color color7 = java.awt.Color.darkGray;
        xYPlot0.setDomainGridlinePaint((java.awt.Paint) color7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = xYPlot0.getFixedDomainAxisSpace();
        org.junit.Assert.assertNotNull(layer5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(axisSpace9);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        boolean boolean3 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        xYPlot4.configureDomainAxes();
        org.jfree.chart.util.Layer layer6 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection7 = xYPlot4.getDomainMarkers(layer6);
        java.util.Collection collection8 = xYPlot0.getRangeMarkers(layer6);
        java.awt.Stroke stroke9 = xYPlot0.getDomainZeroBaselineStroke();
        int int10 = xYPlot0.getRangeAxisCount();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isTickLabelsVisible();
        xYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis11);
        dateAxis11.setLowerBound((double) (-128));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(layer6);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis1.configure();
        double double3 = numberAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat6 = numberAxis5.getNumberFormatOverride();
        org.jfree.data.RangeType rangeType7 = numberAxis5.getRangeType();
        numberAxis1.setRangeType(rangeType7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        xYPlot9.addChangeListener(plotChangeListener10);
        java.awt.Paint paint12 = xYPlot9.getOutlinePaint();
        java.awt.Stroke stroke13 = xYPlot9.getRangeZeroBaselineStroke();
        numberAxis1.setTickMarkStroke(stroke13);
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        dateAxis15.setTickMarksVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis15.setStandardTickUnits(tickUnitSource18);
        java.text.DateFormat dateFormat20 = null;
        dateAxis15.setDateFormatOverride(dateFormat20);
        dateAxis15.setTickMarksVisible(true);
        dateAxis15.setRange((double) (-1L), 1.0E-8d);
        java.util.Date date27 = dateAxis15.getMinimumDate();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat30 = numberAxis29.getNumberFormatOverride();
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis();
        boolean boolean32 = dateAxis31.isAutoTickUnitSelection();
        org.jfree.data.Range range33 = dateAxis31.getDefaultAutoRange();
        numberAxis29.setRangeWithMargins(range33);
        dateAxis15.setRange(range33);
        numberAxis1.setRange(range33, false, true);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNull(numberFormat6);
        org.junit.Assert.assertNotNull(rangeType7);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(tickUnitSource18);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNull(numberFormat30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(range33);
    }
}

