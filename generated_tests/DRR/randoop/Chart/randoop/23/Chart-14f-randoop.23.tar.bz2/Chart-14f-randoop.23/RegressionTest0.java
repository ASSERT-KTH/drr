import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        java.awt.Paint paint1 = null;
        java.awt.Stroke stroke2 = null;
        java.awt.Paint paint3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        java.awt.Stroke stroke4 = null;
        try {
            org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", paint1, stroke2, paint3, stroke4, (float) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = null;
        try {
            dateAxis0.setRightArrow(shape1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrow' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.jfree.chart.plot.Plot plot0 = null;
        try {
            org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent(plot0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isAutoTickUnitSelection();
        org.jfree.data.Range range2 = dateAxis0.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot3 = dateAxis0.getPlot();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        try {
            org.jfree.chart.axis.AxisState axisState10 = dateAxis0.draw(graphics2D4, (double) 0L, rectangle2D6, rectangle2D7, rectangleEdge8, plotRenderingInfo9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_INSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0 == 0.0f);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isAutoTickUnitSelection();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = null;
        try {
            java.util.Date date3 = dateAxis0.calculateHighestVisibleTickValue(dateTickUnit2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isAutoTickUnitSelection();
        try {
            dateAxis0.zoomRange((double) 0.0f, (-1.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (0.0) <= upper (-1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setTickMarksVisible(true);
        java.awt.Shape shape3 = null;
        try {
            dateAxis0.setRightArrow(shape3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrow' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        try {
            org.jfree.chart.axis.AxisState axisState8 = numberAxis1.draw(graphics2D2, 0.0d, rectangle2D4, rectangle2D5, rectangleEdge6, plotRenderingInfo7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.jfree.data.time.DateRange dateRange0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.junit.Assert.assertNotNull(dateRange0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABELS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        try {
            org.jfree.chart.axis.AxisState axisState8 = numberAxis1.draw(graphics2D2, (double) (byte) 1, rectangle2D4, rectangle2D5, rectangleEdge6, plotRenderingInfo7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-8d + "'", double0 == 1.0E-8d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            rectangleInsets0.trim(rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        xYPlot0.addChangeListener(plotChangeListener1);
        org.jfree.chart.plot.Marker marker3 = null;
        try {
            xYPlot0.addRangeMarker(marker3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.junit.Assert.assertNotNull(range0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        boolean boolean3 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.Marker marker4 = null;
        try {
            boolean boolean5 = xYPlot0.removeRangeMarker(marker4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        int int3 = java.awt.Color.HSBtoRGB((float) 0L, 0.0f, (float) 0L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getLeftArrow();
        dateAxis0.setAxisLineVisible(false);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat2 = numberAxis1.getNumberFormatOverride();
        org.jfree.data.RangeType rangeType3 = numberAxis1.getRangeType();
        boolean boolean4 = numberAxis1.isAxisLineVisible();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = numberAxis1.valueToJava2D((double) 1, rectangle2D6, rectangleEdge7);
        org.junit.Assert.assertNull(numberFormat2);
        org.junit.Assert.assertNotNull(rangeType3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        xYPlot0.setInsets(rectangleInsets3, true);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D7 = rectangleInsets3.createOutsetRectangle(rectangle2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets3);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        boolean boolean3 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.axis.AxisLocation axisLocation4 = null;
        try {
            xYPlot0.setDomainAxisLocation(axisLocation4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isAutoTickUnitSelection();
        org.jfree.data.Range range2 = dateAxis0.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot3 = dateAxis0.getPlot();
        java.awt.Shape shape4 = null;
        try {
            dateAxis0.setDownArrow(shape4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrow' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        org.jfree.chart.plot.Marker marker15 = null;
        try {
            categoryPlot14.addRangeMarker(marker15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        java.awt.Color color0 = java.awt.Color.RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        categoryAxis2.setCategoryLabelPositionOffset(7);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.axis.AxisState axisState18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        try {
            java.util.List list21 = categoryAxis2.refreshTicks(graphics2D17, axisState18, rectangle2D19, rectangleEdge20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        boolean boolean3 = xYPlot0.isRangeCrosshairLockedOnData();
        xYPlot0.setRangeCrosshairVisible(false);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.geom.Point2D point2D8 = null;
        org.jfree.chart.plot.PlotState plotState9 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        try {
            xYPlot0.draw(graphics2D6, rectangle2D7, point2D8, plotState9, plotRenderingInfo10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        xYPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = xYPlot0.getOutlinePaint();
        float float4 = xYPlot0.getForegroundAlpha();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            xYPlot0.drawOutline(graphics2D5, rectangle2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isAutoTickUnitSelection();
        org.jfree.data.Range range2 = dateAxis0.getDefaultAutoRange();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        boolean boolean4 = dateAxis3.isAutoTickUnitSelection();
        org.jfree.data.Range range5 = dateAxis3.getDefaultAutoRange();
        dateAxis0.setRangeWithMargins(range5);
        java.awt.Paint paint7 = null;
        try {
            dateAxis0.setTickMarkPaint(paint7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(range5);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isTickLabelsVisible();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = null;
        try {
            java.util.Date date3 = dateAxis0.calculateHighestVisibleTickValue(dateTickUnit2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        java.awt.Color color1 = java.awt.Color.getColor("java.awt.Color[r=178,g=178,b=0]");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        boolean boolean3 = xYPlot0.isRangeCrosshairLockedOnData();
        xYPlot0.setRangeCrosshairVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        try {
            xYPlot0.setDomainAxisLocation(axisLocation6, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        xYPlot0.setInsets(rectangleInsets3, true);
        java.awt.Paint paint6 = xYPlot0.getDomainTickBandPaint();
        org.jfree.chart.plot.Marker marker8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        xYPlot9.addChangeListener(plotChangeListener10);
        java.awt.Paint paint12 = xYPlot9.getOutlinePaint();
        org.jfree.chart.util.Layer layer13 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection14 = xYPlot9.getRangeMarkers(layer13);
        try {
            boolean boolean16 = xYPlot0.removeRangeMarker(0, marker8, layer13, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(layer13);
        org.junit.Assert.assertNull(collection14);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_TICK_UNIT_SELECTION;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        xYPlot0.setInsets(rectangleInsets3, true);
        int int6 = xYPlot0.getSeriesCount();
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isAutoTickUnitSelection();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = null;
        try {
            java.util.Date date3 = dateAxis0.calculateLowestVisibleTickValue(dateTickUnit2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        float float4 = categoryAxis3.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        boolean boolean6 = dateAxis5.isAutoTickUnitSelection();
        org.jfree.data.Range range7 = dateAxis5.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot8 = dateAxis5.getPlot();
        dateAxis5.setLabelURL("hi!");
        dateAxis5.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer14);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        dateAxis16.setTickMarksVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource19 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis16.setStandardTickUnits(tickUnitSource19);
        java.text.DateFormat dateFormat21 = null;
        dateAxis16.setDateFormatOverride(dateFormat21);
        dateAxis16.setTickMarksVisible(true);
        dateAxis16.setRange((double) (-1L), 1.0E-8d);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis16, categoryItemRenderer28);
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.data.category.CategoryDataset categoryDataset33 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = new org.jfree.chart.axis.CategoryAxis("");
        float float36 = categoryAxis35.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis();
        boolean boolean38 = dateAxis37.isAutoTickUnitSelection();
        org.jfree.data.Range range39 = dateAxis37.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot40 = dateAxis37.getPlot();
        dateAxis37.setLabelURL("hi!");
        dateAxis37.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer46 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot47 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, categoryAxis35, (org.jfree.chart.axis.ValueAxis) dateAxis37, categoryItemRenderer46);
        org.jfree.chart.plot.XYPlot xYPlot49 = new org.jfree.chart.plot.XYPlot();
        xYPlot49.setRangeCrosshairVisible(true);
        boolean boolean52 = xYPlot49.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot53 = new org.jfree.chart.plot.XYPlot();
        xYPlot53.configureDomainAxes();
        org.jfree.chart.util.Layer layer55 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection56 = xYPlot53.getDomainMarkers(layer55);
        java.util.Collection collection57 = xYPlot49.getRangeMarkers(layer55);
        java.util.Collection collection58 = categoryPlot47.getRangeMarkers((int) (byte) 1, layer55);
        org.jfree.chart.util.RectangleEdge rectangleEdge60 = categoryPlot47.getRangeAxisEdge((int) ' ');
        try {
            double double61 = categoryAxis3.getCategoryEnd((int) (short) -1, (-1), rectangle2D32, rectangleEdge60);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(tickUnitSource19);
        org.junit.Assert.assertTrue("'" + float36 + "' != '" + 0.0f + "'", float36 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(range39);
        org.junit.Assert.assertNull(plot40);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(layer55);
        org.junit.Assert.assertNull(collection56);
        org.junit.Assert.assertNull(collection57);
        org.junit.Assert.assertNull(collection58);
        org.junit.Assert.assertNotNull(rectangleEdge60);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        java.util.Date date15 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis("");
        float float20 = categoryAxis19.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        boolean boolean22 = dateAxis21.isAutoTickUnitSelection();
        org.jfree.data.Range range23 = dateAxis21.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot24 = dateAxis21.getPlot();
        dateAxis21.setLabelURL("hi!");
        dateAxis21.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis21, categoryItemRenderer30);
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot();
        xYPlot33.setRangeCrosshairVisible(true);
        boolean boolean36 = xYPlot33.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot37 = new org.jfree.chart.plot.XYPlot();
        xYPlot37.configureDomainAxes();
        org.jfree.chart.util.Layer layer39 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection40 = xYPlot37.getDomainMarkers(layer39);
        java.util.Collection collection41 = xYPlot33.getRangeMarkers(layer39);
        java.util.Collection collection42 = categoryPlot31.getRangeMarkers((int) (byte) 1, layer39);
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = categoryPlot31.getRangeAxisEdge((int) ' ');
        try {
            double double45 = dateAxis4.dateToJava2D(date15, rectangle2D16, rectangleEdge44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 0.0f + "'", float20 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertNull(plot24);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(layer39);
        org.junit.Assert.assertNull(collection40);
        org.junit.Assert.assertNull(collection41);
        org.junit.Assert.assertNull(collection42);
        org.junit.Assert.assertNotNull(rectangleEdge44);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isAutoTickUnitSelection();
        double double2 = dateAxis0.getUpperBound();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        categoryPlot14.setWeight((int) (byte) 0);
        org.jfree.chart.plot.Marker marker17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        xYPlot18.configureDomainAxes();
        org.jfree.chart.util.Layer layer20 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection21 = xYPlot18.getDomainMarkers(layer20);
        try {
            boolean boolean22 = categoryPlot14.removeRangeMarker(marker17, layer20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(layer20);
        org.junit.Assert.assertNull(collection21);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isAutoTickUnitSelection();
        org.jfree.data.Range range2 = dateAxis0.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot3 = dateAxis0.getPlot();
        dateAxis0.setLabelURL("hi!");
        dateAxis0.setLowerMargin(0.0d);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.axis.AxisState axisState9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        float float14 = categoryAxis13.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        boolean boolean16 = dateAxis15.isAutoTickUnitSelection();
        org.jfree.data.Range range17 = dateAxis15.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot18 = dateAxis15.getPlot();
        dateAxis15.setLabelURL("hi!");
        dateAxis15.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis13, (org.jfree.chart.axis.ValueAxis) dateAxis15, categoryItemRenderer24);
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot();
        xYPlot27.setRangeCrosshairVisible(true);
        boolean boolean30 = xYPlot27.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot();
        xYPlot31.configureDomainAxes();
        org.jfree.chart.util.Layer layer33 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection34 = xYPlot31.getDomainMarkers(layer33);
        java.util.Collection collection35 = xYPlot27.getRangeMarkers(layer33);
        java.util.Collection collection36 = categoryPlot25.getRangeMarkers((int) (byte) 1, layer33);
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = categoryPlot25.getRangeAxisEdge((int) ' ');
        try {
            java.util.List list39 = dateAxis0.refreshTicks(graphics2D8, axisState9, rectangle2D10, rectangleEdge38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(plot18);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(layer33);
        org.junit.Assert.assertNull(collection34);
        org.junit.Assert.assertNull(collection35);
        org.junit.Assert.assertNull(collection36);
        org.junit.Assert.assertNotNull(rectangleEdge38);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        java.lang.Object obj0 = null;
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent(obj0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        java.awt.Color color2 = java.awt.Color.getColor("hi!", (-1));
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat2 = numberAxis1.getNumberFormatOverride();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        boolean boolean4 = dateAxis3.isAutoTickUnitSelection();
        org.jfree.data.Range range5 = dateAxis3.getDefaultAutoRange();
        numberAxis1.setRangeWithMargins(range5);
        java.text.NumberFormat numberFormat7 = numberAxis1.getNumberFormatOverride();
        org.junit.Assert.assertNull(numberFormat2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        java.awt.Font font0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setTickMarksVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource3 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis0.setStandardTickUnits(tickUnitSource3);
        java.text.DateFormat dateFormat5 = null;
        dateAxis0.setDateFormatOverride(dateFormat5);
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = dateAxis7.getLabelInsets();
        dateAxis0.setTickLabelInsets(rectangleInsets8);
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        xYPlot10.configureDomainAxes();
        java.lang.String str12 = xYPlot10.getNoDataMessage();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Point2D point2D16 = null;
        xYPlot10.zoomRangeAxes((double) 10.0f, (double) 1L, plotRenderingInfo15, point2D16);
        boolean boolean18 = rectangleInsets8.equals((java.lang.Object) 10.0f);
        org.junit.Assert.assertNotNull(tickUnitSource3);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        categoryPlot14.setWeight((int) (byte) 0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener17 = null;
        categoryPlot14.addChangeListener(plotChangeListener17);
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener20 = null;
        xYPlot19.addChangeListener(plotChangeListener20);
        java.awt.Paint paint22 = xYPlot19.getOutlinePaint();
        java.awt.Stroke stroke23 = xYPlot19.getRangeZeroBaselineStroke();
        categoryPlot14.setDomainGridlineStroke(stroke23);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        try {
            categoryPlot14.handleClick(6, (int) (byte) 100, plotRenderingInfo27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(stroke23);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        boolean boolean2 = datasetRenderingOrder0.equals((java.lang.Object) "");
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        boolean boolean3 = xYPlot0.isRangeCrosshairLockedOnData();
        java.lang.String str4 = xYPlot0.getPlotType();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation5 = null;
        try {
            xYPlot0.addAnnotation(xYAnnotation5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "XY Plot" + "'", str4.equals("XY Plot"));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.ASCENDING;
        java.lang.String str1 = sortOrder0.toString();
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SortOrder.ASCENDING" + "'", str1.equals("SortOrder.ASCENDING"));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        int int1 = color0.getRGB();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-128) + "'", int1 == (-128));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.junit.Assert.assertNotNull(sortOrder0);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        java.awt.Color color1 = java.awt.Color.getColor("SortOrder.ASCENDING");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        double double2 = numberAxis1.getUpperMargin();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        java.awt.Font font16 = categoryAxis2.getTickLabelFont((java.lang.Comparable) 0.0f);
        float float17 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.0f + "'", float17 == 0.0f);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        float float4 = categoryAxis3.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        boolean boolean6 = dateAxis5.isAutoTickUnitSelection();
        org.jfree.data.Range range7 = dateAxis5.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot8 = dateAxis5.getPlot();
        dateAxis5.setLabelURL("hi!");
        dateAxis5.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer14);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        dateAxis16.setTickMarksVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource19 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis16.setStandardTickUnits(tickUnitSource19);
        java.text.DateFormat dateFormat21 = null;
        dateAxis16.setDateFormatOverride(dateFormat21);
        dateAxis16.setTickMarksVisible(true);
        dateAxis16.setRange((double) (-1L), 1.0E-8d);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis16, categoryItemRenderer28);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray30 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot29.setRenderers(categoryItemRendererArray30);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation32 = null;
        try {
            boolean boolean33 = categoryPlot29.removeAnnotation(categoryAnnotation32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(tickUnitSource19);
        org.junit.Assert.assertNotNull(categoryItemRendererArray30);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        float float4 = categoryAxis3.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        boolean boolean6 = dateAxis5.isAutoTickUnitSelection();
        org.jfree.data.Range range7 = dateAxis5.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot8 = dateAxis5.getPlot();
        dateAxis5.setLabelURL("hi!");
        dateAxis5.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer14);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        dateAxis16.setTickMarksVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource19 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis16.setStandardTickUnits(tickUnitSource19);
        java.text.DateFormat dateFormat21 = null;
        dateAxis16.setDateFormatOverride(dateFormat21);
        dateAxis16.setTickMarksVisible(true);
        dateAxis16.setRange((double) (-1L), 1.0E-8d);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis16, categoryItemRenderer28);
        double double30 = dateAxis16.getLabelAngle();
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(tickUnitSource19);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        boolean boolean3 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        xYPlot4.configureDomainAxes();
        org.jfree.chart.util.Layer layer6 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection7 = xYPlot4.getDomainMarkers(layer6);
        java.util.Collection collection8 = xYPlot0.getRangeMarkers(layer6);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setParent((org.jfree.chart.plot.Plot) xYPlot9);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        xYPlot9.rendererChanged(rendererChangeEvent11);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray13 = null;
        try {
            xYPlot9.setDomainAxes(valueAxisArray13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(layer6);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(collection8);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        boolean boolean0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_UPPER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        categoryPlot14.setWeight((int) (byte) 0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener17 = null;
        categoryPlot14.addChangeListener(plotChangeListener17);
        org.jfree.chart.axis.AxisLocation axisLocation20 = null;
        categoryPlot14.setRangeAxisLocation((int) (short) 1, axisLocation20);
        org.jfree.chart.plot.Marker marker22 = null;
        org.jfree.chart.util.Layer layer23 = null;
        try {
            boolean boolean24 = categoryPlot14.removeRangeMarker(marker22, layer23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("");
        float float5 = categoryAxis4.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        boolean boolean7 = dateAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = dateAxis6.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot9 = dateAxis6.getPlot();
        dateAxis6.setLabelURL("hi!");
        dateAxis6.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis6, categoryItemRenderer15);
        java.awt.Font font18 = categoryAxis4.getTickLabelFont((java.lang.Comparable) 0.0f);
        try {
            objectList0.set((-16777216), (java.lang.Object) categoryAxis4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNull(plot9);
        org.junit.Assert.assertNotNull(font18);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        categoryPlot14.setWeight((int) (byte) 0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener17 = null;
        categoryPlot14.addChangeListener(plotChangeListener17);
        org.jfree.chart.axis.AxisLocation axisLocation20 = null;
        categoryPlot14.setRangeAxisLocation((int) (short) 1, axisLocation20);
        org.jfree.chart.plot.Marker marker23 = null;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot();
        xYPlot24.setRangeCrosshairVisible(true);
        boolean boolean27 = xYPlot24.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot();
        xYPlot28.configureDomainAxes();
        org.jfree.chart.util.Layer layer30 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection31 = xYPlot28.getDomainMarkers(layer30);
        java.util.Collection collection32 = xYPlot24.getRangeMarkers(layer30);
        boolean boolean34 = categoryPlot14.removeDomainMarker((-16777216), marker23, layer30, false);
        org.jfree.chart.plot.Marker marker35 = null;
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot();
        xYPlot36.configureDomainAxes();
        org.jfree.chart.util.Layer layer38 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection39 = xYPlot36.getDomainMarkers(layer38);
        try {
            boolean boolean40 = categoryPlot14.removeRangeMarker(marker35, layer38);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(layer30);
        org.junit.Assert.assertNull(collection31);
        org.junit.Assert.assertNull(collection32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(layer38);
        org.junit.Assert.assertNull(collection39);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureDomainAxes();
        xYPlot0.zoom((double) 10);
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean6 = xYPlot0.removeDomainMarker(marker4, layer5);
        double double7 = xYPlot0.getRangeCrosshairValue();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis9.setUpperBound((double) 10);
        int int12 = xYPlot0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis9);
        org.junit.Assert.assertNotNull(layer5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        org.jfree.chart.plot.Marker marker15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener17 = null;
        xYPlot16.addChangeListener(plotChangeListener17);
        java.awt.Paint paint19 = xYPlot16.getOutlinePaint();
        org.jfree.chart.util.Layer layer20 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection21 = xYPlot16.getRangeMarkers(layer20);
        try {
            categoryPlot14.addRangeMarker(marker15, layer20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(layer20);
        org.junit.Assert.assertNull(collection21);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 5, (double) 100, (double) (byte) 10, (double) 'a');
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setTickMarksVisible(true);
        org.jfree.chart.event.AxisChangeListener axisChangeListener3 = null;
        dateAxis0.removeChangeListener(axisChangeListener3);
        java.awt.Shape shape5 = dateAxis0.getDownArrow();
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        xYPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = xYPlot0.getOutlinePaint();
        float float4 = xYPlot0.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot0.getRangeAxisLocation();
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge7 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation5, plotOrientation6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation5);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        boolean boolean3 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        xYPlot4.configureDomainAxes();
        org.jfree.chart.util.Layer layer6 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection7 = xYPlot4.getDomainMarkers(layer6);
        java.util.Collection collection8 = xYPlot0.getRangeMarkers(layer6);
        java.awt.Stroke stroke9 = xYPlot0.getDomainZeroBaselineStroke();
        int int10 = xYPlot0.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation11 = null;
        try {
            xYPlot0.setOrientation(plotOrientation11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(layer6);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        boolean boolean3 = xYPlot0.isRangeCrosshairLockedOnData();
        java.lang.String str4 = xYPlot0.getPlotType();
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("");
        float float8 = categoryAxis7.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        boolean boolean10 = dateAxis9.isAutoTickUnitSelection();
        org.jfree.data.Range range11 = dateAxis9.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot12 = dateAxis9.getPlot();
        dateAxis9.setLabelURL("hi!");
        dateAxis9.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis9, categoryItemRenderer18);
        org.jfree.chart.plot.Marker marker20 = null;
        boolean boolean21 = categoryPlot19.removeDomainMarker(marker20);
        java.util.List list22 = categoryPlot19.getAnnotations();
        java.awt.Stroke stroke23 = categoryPlot19.getRangeGridlineStroke();
        xYPlot0.setRangeCrosshairStroke(stroke23);
        xYPlot0.clearAnnotations();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "XY Plot" + "'", str4.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.0f + "'", float8 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNull(plot12);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(list22);
        org.junit.Assert.assertNotNull(stroke23);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        java.lang.String str1 = chartChangeEventType0.toString();
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str1.equals("ChartChangeEventType.DATASET_UPDATED"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isAutoTickUnitSelection();
        org.jfree.data.Range range2 = dateAxis0.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot3 = dateAxis0.getPlot();
        dateAxis0.setLabelURL("hi!");
        dateAxis0.zoomRange((double) 0.0f, (double) 7);
        try {
            dateAxis0.setRange((double) 255, (double) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        boolean boolean3 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        xYPlot4.configureDomainAxes();
        org.jfree.chart.util.Layer layer6 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection7 = xYPlot4.getDomainMarkers(layer6);
        java.util.Collection collection8 = xYPlot0.getRangeMarkers(layer6);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setParent((org.jfree.chart.plot.Plot) xYPlot9);
        xYPlot9.setRangeCrosshairValue((double) (byte) 0);
        int int13 = xYPlot9.getWeight();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(layer6);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setTickMarksVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource3 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis0.setStandardTickUnits(tickUnitSource3);
        java.text.DateFormat dateFormat5 = null;
        dateAxis0.setDateFormatOverride(dateFormat5);
        dateAxis0.setTickMarksVisible(true);
        try {
            dateAxis0.setAutoRangeMinimumSize(0.0d, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(tickUnitSource3);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Paint[] paintArray1 = new java.awt.Paint[] {};
        java.awt.Stroke[] strokeArray2 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray3 = new java.awt.Stroke[] {};
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape[] shapeArray5 = new java.awt.Shape[] { shape4 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier6 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, strokeArray2, strokeArray3, shapeArray5);
        try {
            java.awt.Stroke stroke7 = defaultDrawingSupplier6.getNextOutlineStroke();
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(strokeArray2);
        org.junit.Assert.assertNotNull(strokeArray3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shapeArray5);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        int int2 = categoryAxis1.getMaximumCategoryLabelLines();
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis("");
        float float11 = categoryAxis10.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        boolean boolean13 = dateAxis12.isAutoTickUnitSelection();
        org.jfree.data.Range range14 = dateAxis12.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot15 = dateAxis12.getPlot();
        dateAxis12.setLabelURL("hi!");
        dateAxis12.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis12, categoryItemRenderer21);
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot();
        xYPlot24.setRangeCrosshairVisible(true);
        boolean boolean27 = xYPlot24.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot();
        xYPlot28.configureDomainAxes();
        org.jfree.chart.util.Layer layer30 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection31 = xYPlot28.getDomainMarkers(layer30);
        java.util.Collection collection32 = xYPlot24.getRangeMarkers(layer30);
        java.util.Collection collection33 = categoryPlot22.getRangeMarkers((int) (byte) 1, layer30);
        java.util.List list34 = categoryPlot22.getCategories();
        categoryPlot22.clearAnnotations();
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = categoryPlot22.getRangeAxisEdge();
        try {
            double double37 = categoryAxis1.getCategorySeriesMiddle((java.lang.Comparable) (short) 0, (java.lang.Comparable) 0.05d, categoryDataset5, 0.05d, rectangle2D7, rectangleEdge36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.0f + "'", float11 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNull(plot15);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(layer30);
        org.junit.Assert.assertNull(collection31);
        org.junit.Assert.assertNull(collection32);
        org.junit.Assert.assertNull(collection33);
        org.junit.Assert.assertNull(list34);
        org.junit.Assert.assertNotNull(rectangleEdge36);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        int int3 = java.awt.Color.HSBtoRGB((float) (byte) 100, (float) 100, (float) 100L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-83) + "'", int3 == (-83));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        java.awt.Color color0 = java.awt.Color.ORANGE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        double double0 = org.jfree.chart.axis.DateAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE_IN_MILLISECONDS;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.0d + "'", double0 == 2.0d);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor15 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        boolean boolean17 = categoryAnchor15.equals((java.lang.Object) 0.0d);
        java.lang.String str18 = categoryAnchor15.toString();
        categoryPlot14.setDomainGridlinePosition(categoryAnchor15);
        org.jfree.chart.plot.CategoryMarker categoryMarker21 = null;
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis("");
        float float25 = categoryAxis24.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        boolean boolean27 = dateAxis26.isAutoTickUnitSelection();
        org.jfree.data.Range range28 = dateAxis26.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot29 = dateAxis26.getPlot();
        dateAxis26.setLabelURL("hi!");
        dateAxis26.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis24, (org.jfree.chart.axis.ValueAxis) dateAxis26, categoryItemRenderer35);
        org.jfree.chart.plot.XYPlot xYPlot38 = new org.jfree.chart.plot.XYPlot();
        xYPlot38.setRangeCrosshairVisible(true);
        boolean boolean41 = xYPlot38.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot42 = new org.jfree.chart.plot.XYPlot();
        xYPlot42.configureDomainAxes();
        org.jfree.chart.util.Layer layer44 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection45 = xYPlot42.getDomainMarkers(layer44);
        java.util.Collection collection46 = xYPlot38.getRangeMarkers(layer44);
        java.util.Collection collection47 = categoryPlot36.getRangeMarkers((int) (byte) 1, layer44);
        try {
            categoryPlot14.addDomainMarker((-128), categoryMarker21, layer44);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(categoryAnchor15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "CategoryAnchor.MIDDLE" + "'", str18.equals("CategoryAnchor.MIDDLE"));
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.0f + "'", float25 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertNull(plot29);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(layer44);
        org.junit.Assert.assertNull(collection45);
        org.junit.Assert.assertNull(collection46);
        org.junit.Assert.assertNull(collection47);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        boolean boolean3 = xYPlot0.isRangeCrosshairLockedOnData();
        java.lang.String str4 = xYPlot0.getPlotType();
        java.awt.Color color6 = java.awt.Color.YELLOW;
        java.awt.Color color7 = color6.darker();
        java.lang.String str8 = color7.toString();
        try {
            xYPlot0.setQuadrantPaint((int) (short) 10, (java.awt.Paint) color7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (10) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "XY Plot" + "'", str4.equals("XY Plot"));
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "java.awt.Color[r=178,g=178,b=0]" + "'", str8.equals("java.awt.Color[r=178,g=178,b=0]"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        categoryPlot14.setWeight((int) (byte) 0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener17 = null;
        categoryPlot14.addChangeListener(plotChangeListener17);
        org.jfree.chart.axis.AxisLocation axisLocation20 = null;
        categoryPlot14.setRangeAxisLocation((int) (short) 1, axisLocation20);
        org.jfree.chart.plot.Marker marker23 = null;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot();
        xYPlot24.setRangeCrosshairVisible(true);
        boolean boolean27 = xYPlot24.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot();
        xYPlot28.configureDomainAxes();
        org.jfree.chart.util.Layer layer30 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection31 = xYPlot28.getDomainMarkers(layer30);
        java.util.Collection collection32 = xYPlot24.getRangeMarkers(layer30);
        boolean boolean34 = categoryPlot14.removeDomainMarker((-16777216), marker23, layer30, false);
        org.jfree.chart.axis.AxisLocation axisLocation35 = null;
        try {
            categoryPlot14.setDomainAxisLocation(axisLocation35, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(layer30);
        org.junit.Assert.assertNull(collection31);
        org.junit.Assert.assertNull(collection32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getLeftArrow();
        java.util.TimeZone timeZone2 = dateAxis0.getTimeZone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource3 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone2);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(tickUnitSource3);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        xYPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = xYPlot0.getOutlinePaint();
        float float4 = xYPlot0.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot0.getRangeAxisLocation();
        org.jfree.chart.axis.AxisSpace axisSpace6 = xYPlot0.getFixedDomainAxisSpace();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNull(axisSpace6);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        boolean boolean3 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        xYPlot4.configureDomainAxes();
        org.jfree.chart.util.Layer layer6 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection7 = xYPlot4.getDomainMarkers(layer6);
        java.util.Collection collection8 = xYPlot0.getRangeMarkers(layer6);
        java.awt.Stroke stroke9 = xYPlot0.getDomainZeroBaselineStroke();
        org.jfree.chart.plot.Marker marker10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        xYPlot11.setRangeCrosshairVisible(true);
        boolean boolean14 = xYPlot11.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        xYPlot15.configureDomainAxes();
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection18 = xYPlot15.getDomainMarkers(layer17);
        java.util.Collection collection19 = xYPlot11.getRangeMarkers(layer17);
        try {
            boolean boolean20 = xYPlot0.removeRangeMarker(marker10, layer17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(layer6);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertNull(collection19);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Paint[] paintArray1 = new java.awt.Paint[] {};
        java.awt.Stroke[] strokeArray2 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray3 = new java.awt.Stroke[] {};
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape[] shapeArray5 = new java.awt.Shape[] { shape4 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier6 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, strokeArray2, strokeArray3, shapeArray5);
        java.awt.Paint paint7 = defaultDrawingSupplier6.getNextFillPaint();
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(strokeArray2);
        org.junit.Assert.assertNotNull(strokeArray3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shapeArray5);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor15 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        boolean boolean17 = categoryAnchor15.equals((java.lang.Object) 0.0d);
        java.lang.String str18 = categoryAnchor15.toString();
        categoryPlot14.setDomainGridlinePosition(categoryAnchor15);
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot();
        xYPlot21.configureDomainAxes();
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection24 = xYPlot21.getDomainMarkers(layer23);
        try {
            categoryPlot14.addDomainMarker(categoryMarker20, layer23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(categoryAnchor15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "CategoryAnchor.MIDDLE" + "'", str18.equals("CategoryAnchor.MIDDLE"));
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertNull(collection24);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_GREEN;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        xYPlot2.setRangeCrosshairVisible(true);
        boolean boolean5 = xYPlot2.isRangeCrosshairLockedOnData();
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.util.List list8 = null;
        xYPlot2.drawDomainTickBands(graphics2D6, rectangle2D7, list8);
        double double10 = xYPlot2.getRangeCrosshairValue();
        java.awt.Stroke stroke11 = xYPlot2.getOutlineStroke();
        java.awt.Color color12 = java.awt.Color.YELLOW;
        java.awt.Color color13 = color12.darker();
        java.awt.Color color14 = color13.brighter();
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        xYPlot15.addChangeListener(plotChangeListener16);
        java.awt.Paint paint18 = xYPlot15.getOutlinePaint();
        java.awt.Stroke stroke19 = xYPlot15.getRangeZeroBaselineStroke();
        try {
            org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker((double) 10L, (java.awt.Paint) color1, stroke11, (java.awt.Paint) color14, stroke19, (float) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(stroke19);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        xYPlot1.configureDomainAxes();
        java.lang.String str3 = xYPlot1.getNoDataMessage();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot1.zoomRangeAxes((double) 10.0f, (double) 1L, plotRenderingInfo6, point2D7);
        int int9 = objectList0.indexOf((java.lang.Object) point2D7);
        java.awt.Paint[] paintArray10 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Paint[] paintArray11 = new java.awt.Paint[] {};
        java.awt.Stroke[] strokeArray12 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray13 = new java.awt.Stroke[] {};
        java.awt.Shape shape14 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape[] shapeArray15 = new java.awt.Shape[] { shape14 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier16 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray10, paintArray11, strokeArray12, strokeArray13, shapeArray15);
        java.awt.Stroke stroke17 = defaultDrawingSupplier16.getNextStroke();
        int int18 = objectList0.indexOf((java.lang.Object) defaultDrawingSupplier16);
        java.awt.Paint paint19 = defaultDrawingSupplier16.getNextPaint();
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(paintArray10);
        org.junit.Assert.assertNotNull(paintArray11);
        org.junit.Assert.assertNotNull(strokeArray12);
        org.junit.Assert.assertNotNull(strokeArray13);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(shapeArray15);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        boolean boolean3 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        xYPlot4.configureDomainAxes();
        org.jfree.chart.util.Layer layer6 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection7 = xYPlot4.getDomainMarkers(layer6);
        java.util.Collection collection8 = xYPlot0.getRangeMarkers(layer6);
        boolean boolean9 = xYPlot0.isSubplot();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(layer6);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isAutoTickUnitSelection();
        org.jfree.data.Range range2 = dateAxis0.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot3 = dateAxis0.getPlot();
        dateAxis0.setLabelURL("hi!");
        boolean boolean6 = dateAxis0.isAutoTickUnitSelection();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat2 = numberAxis1.getNumberFormatOverride();
        org.jfree.data.RangeType rangeType3 = numberAxis1.getRangeType();
        boolean boolean4 = numberAxis1.isTickMarksVisible();
        java.text.NumberFormat numberFormat5 = numberAxis1.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit6 = null;
        try {
            numberAxis1.setTickUnit(numberTickUnit6, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unit' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(numberFormat2);
        org.junit.Assert.assertNotNull(rangeType3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(numberFormat5);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureDomainAxes();
        xYPlot0.zoom((double) 10);
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean6 = xYPlot0.removeDomainMarker(marker4, layer5);
        xYPlot0.setDomainCrosshairLockedOnData(false);
        org.junit.Assert.assertNotNull(layer5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        boolean boolean3 = xYPlot0.isRangeCrosshairLockedOnData();
        java.lang.String str4 = xYPlot0.getPlotType();
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("");
        float float8 = categoryAxis7.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        boolean boolean10 = dateAxis9.isAutoTickUnitSelection();
        org.jfree.data.Range range11 = dateAxis9.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot12 = dateAxis9.getPlot();
        dateAxis9.setLabelURL("hi!");
        dateAxis9.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis9, categoryItemRenderer18);
        org.jfree.chart.plot.Marker marker20 = null;
        boolean boolean21 = categoryPlot19.removeDomainMarker(marker20);
        java.util.List list22 = categoryPlot19.getAnnotations();
        java.awt.Stroke stroke23 = categoryPlot19.getRangeGridlineStroke();
        xYPlot0.setRangeCrosshairStroke(stroke23);
        try {
            java.awt.Paint paint26 = xYPlot0.getQuadrantPaint((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (32) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "XY Plot" + "'", str4.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.0f + "'", float8 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNull(plot12);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(list22);
        org.junit.Assert.assertNotNull(stroke23);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = dateAxis0.getLabelInsets();
        double double2 = rectangleInsets1.getBottom();
        double double4 = rectangleInsets1.calculateLeftInset(10.0d);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.0d + "'", double4 == 3.0d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_LOWER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        java.awt.Color color0 = java.awt.Color.cyan;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        java.awt.Color color0 = java.awt.Color.lightGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        java.awt.Font font16 = categoryAxis2.getTickLabelFont((java.lang.Comparable) 0.0f);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.axis.AxisState axisState18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis("");
        float float23 = categoryAxis22.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis();
        boolean boolean25 = dateAxis24.isAutoTickUnitSelection();
        org.jfree.data.Range range26 = dateAxis24.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot27 = dateAxis24.getPlot();
        dateAxis24.setLabelURL("hi!");
        dateAxis24.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis22, (org.jfree.chart.axis.ValueAxis) dateAxis24, categoryItemRenderer33);
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot();
        xYPlot36.setRangeCrosshairVisible(true);
        boolean boolean39 = xYPlot36.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot();
        xYPlot40.configureDomainAxes();
        org.jfree.chart.util.Layer layer42 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection43 = xYPlot40.getDomainMarkers(layer42);
        java.util.Collection collection44 = xYPlot36.getRangeMarkers(layer42);
        java.util.Collection collection45 = categoryPlot34.getRangeMarkers((int) (byte) 1, layer42);
        java.util.List list46 = categoryPlot34.getCategories();
        categoryPlot34.clearAnnotations();
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = categoryPlot34.getRangeAxisEdge();
        try {
            java.util.List list49 = categoryAxis2.refreshTicks(graphics2D17, axisState18, rectangle2D19, rectangleEdge48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 0.0f + "'", float23 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(layer42);
        org.junit.Assert.assertNull(collection43);
        org.junit.Assert.assertNull(collection44);
        org.junit.Assert.assertNull(collection45);
        org.junit.Assert.assertNull(list46);
        org.junit.Assert.assertNotNull(rectangleEdge48);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isAutoTickUnitSelection();
        org.jfree.data.Range range2 = dateAxis0.getDefaultAutoRange();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("");
        float float7 = categoryAxis6.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        boolean boolean9 = dateAxis8.isAutoTickUnitSelection();
        org.jfree.data.Range range10 = dateAxis8.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot11 = dateAxis8.getPlot();
        dateAxis8.setLabelURL("hi!");
        dateAxis8.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis8, categoryItemRenderer17);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        dateAxis19.setTickMarksVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource22 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis19.setStandardTickUnits(tickUnitSource22);
        java.text.DateFormat dateFormat24 = null;
        dateAxis19.setDateFormatOverride(dateFormat24);
        dateAxis19.setTickMarksVisible(true);
        dateAxis19.setRange((double) (-1L), 1.0E-8d);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis19, categoryItemRenderer31);
        java.awt.Font font34 = categoryAxis6.getTickLabelFont((java.lang.Comparable) 'a');
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis();
        boolean boolean36 = dateAxis35.isAutoTickUnitSelection();
        org.jfree.data.Range range37 = dateAxis35.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot38 = dateAxis35.getPlot();
        java.util.Date date39 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis35.setMinimumDate(date39);
        java.lang.String str41 = categoryAxis6.getCategoryLabelToolTip((java.lang.Comparable) date39);
        java.util.Date date42 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        try {
            dateAxis0.setRange(date39, date42);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNull(plot11);
        org.junit.Assert.assertNotNull(tickUnitSource22);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertNull(plot38);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNull(str41);
        org.junit.Assert.assertNotNull(date42);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setTickMarksVisible(true);
        org.jfree.chart.event.AxisChangeListener axisChangeListener3 = null;
        dateAxis0.removeChangeListener(axisChangeListener3);
        java.awt.Font font5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis0.setTickLabelFont(font5);
        java.util.TimeZone timeZone7 = dateAxis0.getTimeZone();
        try {
            dateAxis0.setAutoRangeMinimumSize(0.0d, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(timeZone7);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat2 = numberAxis1.getNumberFormatOverride();
        org.jfree.data.RangeType rangeType3 = numberAxis1.getRangeType();
        boolean boolean4 = numberAxis1.isAxisLineVisible();
        boolean boolean5 = numberAxis1.getAutoRangeIncludesZero();
        org.junit.Assert.assertNull(numberFormat2);
        org.junit.Assert.assertNotNull(rangeType3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        xYPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = xYPlot0.getOutlinePaint();
        org.jfree.chart.util.Layer layer4 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(layer4);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation6 = null;
        try {
            boolean boolean8 = xYPlot0.removeAnnotation(xYAnnotation6, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(layer4);
        org.junit.Assert.assertNull(collection5);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        float float4 = categoryAxis3.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        boolean boolean6 = dateAxis5.isAutoTickUnitSelection();
        org.jfree.data.Range range7 = dateAxis5.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot8 = dateAxis5.getPlot();
        dateAxis5.setLabelURL("hi!");
        dateAxis5.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer14);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        dateAxis16.setTickMarksVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource19 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis16.setStandardTickUnits(tickUnitSource19);
        java.text.DateFormat dateFormat21 = null;
        dateAxis16.setDateFormatOverride(dateFormat21);
        dateAxis16.setTickMarksVisible(true);
        dateAxis16.setRange((double) (-1L), 1.0E-8d);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis16, categoryItemRenderer28);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray30 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot29.setRenderers(categoryItemRendererArray30);
        int int32 = categoryPlot29.getDomainAxisCount();
        org.jfree.chart.plot.Marker marker33 = null;
        org.jfree.data.category.CategoryDataset categoryDataset34 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = new org.jfree.chart.axis.CategoryAxis("");
        float float37 = categoryAxis36.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis();
        boolean boolean39 = dateAxis38.isAutoTickUnitSelection();
        org.jfree.data.Range range40 = dateAxis38.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot41 = dateAxis38.getPlot();
        dateAxis38.setLabelURL("hi!");
        dateAxis38.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer47 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot48 = new org.jfree.chart.plot.CategoryPlot(categoryDataset34, categoryAxis36, (org.jfree.chart.axis.ValueAxis) dateAxis38, categoryItemRenderer47);
        categoryPlot48.setWeight((int) (byte) 0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener51 = null;
        categoryPlot48.addChangeListener(plotChangeListener51);
        org.jfree.chart.axis.AxisLocation axisLocation54 = null;
        categoryPlot48.setRangeAxisLocation((int) (short) 1, axisLocation54);
        org.jfree.chart.plot.Marker marker57 = null;
        org.jfree.chart.plot.XYPlot xYPlot58 = new org.jfree.chart.plot.XYPlot();
        xYPlot58.setRangeCrosshairVisible(true);
        boolean boolean61 = xYPlot58.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot62 = new org.jfree.chart.plot.XYPlot();
        xYPlot62.configureDomainAxes();
        org.jfree.chart.util.Layer layer64 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection65 = xYPlot62.getDomainMarkers(layer64);
        java.util.Collection collection66 = xYPlot58.getRangeMarkers(layer64);
        boolean boolean68 = categoryPlot48.removeDomainMarker((-16777216), marker57, layer64, false);
        try {
            categoryPlot29.addRangeMarker(marker33, layer64);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(tickUnitSource19);
        org.junit.Assert.assertNotNull(categoryItemRendererArray30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + float37 + "' != '" + 0.0f + "'", float37 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(range40);
        org.junit.Assert.assertNull(plot41);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(layer64);
        org.junit.Assert.assertNull(collection65);
        org.junit.Assert.assertNull(collection66);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        categoryPlot14.setWeight((int) (byte) 0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener17 = null;
        categoryPlot14.addChangeListener(plotChangeListener17);
        org.jfree.chart.plot.Marker marker19 = null;
        try {
            categoryPlot14.addRangeMarker(marker19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        boolean boolean3 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        xYPlot4.configureDomainAxes();
        org.jfree.chart.util.Layer layer6 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection7 = xYPlot4.getDomainMarkers(layer6);
        java.util.Collection collection8 = xYPlot0.getRangeMarkers(layer6);
        java.awt.Stroke stroke9 = xYPlot0.getDomainZeroBaselineStroke();
        java.lang.Object obj10 = xYPlot0.clone();
        xYPlot0.setRangeCrosshairVisible(false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(layer6);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isAutoTickUnitSelection();
        org.jfree.data.Range range2 = dateAxis0.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot3 = dateAxis0.getPlot();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis5.configure();
        java.lang.Object obj7 = numberAxis5.clone();
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        dateAxis0.setLeftArrow(shape8);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(shape8);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat2 = numberAxis1.getNumberFormatOverride();
        org.jfree.data.RangeType rangeType3 = numberAxis1.getRangeType();
        boolean boolean4 = numberAxis1.isTickMarksVisible();
        double double5 = numberAxis1.getUpperMargin();
        java.awt.Paint paint6 = numberAxis1.getTickMarkPaint();
        org.junit.Assert.assertNull(numberFormat2);
        org.junit.Assert.assertNotNull(rangeType3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        xYPlot2.addChangeListener(plotChangeListener3);
        java.awt.Paint paint5 = xYPlot2.getOutlinePaint();
        org.jfree.chart.util.Layer layer6 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection7 = xYPlot2.getRangeMarkers(layer6);
        boolean boolean8 = xYPlot2.isSubplot();
        java.awt.Paint paint9 = xYPlot2.getRangeGridlinePaint();
        java.awt.Stroke stroke10 = null;
        java.awt.Color color11 = java.awt.Color.WHITE;
        java.awt.Stroke stroke12 = null;
        try {
            org.jfree.chart.plot.IntervalMarker intervalMarker14 = new org.jfree.chart.plot.IntervalMarker(2.0d, (double) 8, paint9, stroke10, (java.awt.Paint) color11, stroke12, (float) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(layer6);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureDomainAxes();
        xYPlot0.zoom((double) 10);
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean6 = xYPlot0.removeDomainMarker(marker4, layer5);
        xYPlot0.clearRangeMarkers();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        boolean boolean10 = dateAxis9.isAutoTickUnitSelection();
        org.jfree.data.Range range11 = dateAxis9.getDefaultAutoRange();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        boolean boolean13 = dateAxis12.isAutoTickUnitSelection();
        org.jfree.data.Range range14 = dateAxis12.getDefaultAutoRange();
        dateAxis9.setRangeWithMargins(range14);
        xYPlot0.setRangeAxis(5, (org.jfree.chart.axis.ValueAxis) dateAxis9, false);
        org.jfree.chart.plot.Marker marker19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        xYPlot20.setRangeCrosshairVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        xYPlot20.setInsets(rectangleInsets23, true);
        java.awt.Paint paint26 = xYPlot20.getDomainTickBandPaint();
        java.lang.String str27 = xYPlot20.getPlotType();
        org.jfree.chart.plot.Marker marker29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot();
        xYPlot30.setRangeCrosshairVisible(true);
        boolean boolean33 = xYPlot30.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot();
        xYPlot34.configureDomainAxes();
        org.jfree.chart.util.Layer layer36 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection37 = xYPlot34.getDomainMarkers(layer36);
        java.util.Collection collection38 = xYPlot30.getRangeMarkers(layer36);
        boolean boolean40 = xYPlot20.removeDomainMarker((int) ' ', marker29, layer36, false);
        try {
            xYPlot0.addDomainMarker(6, marker19, layer36, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(layer5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNull(paint26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "XY Plot" + "'", str27.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(layer36);
        org.junit.Assert.assertNull(collection37);
        org.junit.Assert.assertNull(collection38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        categoryPlot14.setWeight((int) (byte) 0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener17 = null;
        categoryPlot14.addChangeListener(plotChangeListener17);
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener20 = null;
        xYPlot19.addChangeListener(plotChangeListener20);
        java.awt.Paint paint22 = xYPlot19.getOutlinePaint();
        java.awt.Stroke stroke23 = xYPlot19.getRangeZeroBaselineStroke();
        categoryPlot14.setDomainGridlineStroke(stroke23);
        org.jfree.chart.axis.AxisSpace axisSpace25 = categoryPlot14.getFixedDomainAxisSpace();
        categoryPlot14.clearRangeAxes();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNull(axisSpace25);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setTickMarksVisible(true);
        org.jfree.chart.event.AxisChangeListener axisChangeListener3 = null;
        dateAxis0.removeChangeListener(axisChangeListener3);
        java.awt.Font font5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis0.setTickLabelFont(font5);
        dateAxis0.setNegativeArrowVisible(false);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        float float14 = categoryAxis13.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        boolean boolean16 = dateAxis15.isAutoTickUnitSelection();
        org.jfree.data.Range range17 = dateAxis15.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot18 = dateAxis15.getPlot();
        dateAxis15.setLabelURL("hi!");
        dateAxis15.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis13, (org.jfree.chart.axis.ValueAxis) dateAxis15, categoryItemRenderer24);
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot();
        xYPlot27.setRangeCrosshairVisible(true);
        boolean boolean30 = xYPlot27.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot();
        xYPlot31.configureDomainAxes();
        org.jfree.chart.util.Layer layer33 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection34 = xYPlot31.getDomainMarkers(layer33);
        java.util.Collection collection35 = xYPlot27.getRangeMarkers(layer33);
        java.util.Collection collection36 = categoryPlot25.getRangeMarkers((int) (byte) 1, layer33);
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = categoryPlot25.getRangeAxisEdge((int) ' ');
        try {
            double double39 = dateAxis0.java2DToValue((double) ' ', rectangle2D10, rectangleEdge38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(plot18);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(layer33);
        org.junit.Assert.assertNull(collection34);
        org.junit.Assert.assertNull(collection35);
        org.junit.Assert.assertNull(collection36);
        org.junit.Assert.assertNotNull(rectangleEdge38);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = dateAxis0.getLabelInsets();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = null;
        dateAxis0.setTickUnit(dateTickUnit2, false, false);
        org.junit.Assert.assertNotNull(rectangleInsets1);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureDomainAxes();
        xYPlot0.zoom((double) 10);
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean6 = xYPlot0.removeDomainMarker(marker4, layer5);
        xYPlot0.clearRangeMarkers();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = xYPlot0.getInsets();
        double double9 = rectangleInsets8.getRight();
        org.junit.Assert.assertNotNull(layer5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 8.0d + "'", double9 == 8.0d);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureDomainAxes();
        xYPlot0.zoom((double) 10);
        xYPlot0.setDomainCrosshairLockedOnData(true);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        xYPlot0.addChangeListener(plotChangeListener1);
        boolean boolean3 = xYPlot0.isDomainGridlinesVisible();
        org.jfree.chart.plot.Marker marker5 = null;
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis("");
        float float9 = categoryAxis8.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        boolean boolean11 = dateAxis10.isAutoTickUnitSelection();
        org.jfree.data.Range range12 = dateAxis10.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot13 = dateAxis10.getPlot();
        dateAxis10.setLabelURL("hi!");
        dateAxis10.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis10, categoryItemRenderer19);
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot();
        xYPlot22.setRangeCrosshairVisible(true);
        boolean boolean25 = xYPlot22.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot();
        xYPlot26.configureDomainAxes();
        org.jfree.chart.util.Layer layer28 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection29 = xYPlot26.getDomainMarkers(layer28);
        java.util.Collection collection30 = xYPlot22.getRangeMarkers(layer28);
        java.util.Collection collection31 = categoryPlot20.getRangeMarkers((int) (byte) 1, layer28);
        java.awt.Paint paint32 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        boolean boolean33 = layer28.equals((java.lang.Object) paint32);
        try {
            xYPlot0.addDomainMarker((int) 'a', marker5, layer28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.0f + "'", float9 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNull(plot13);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(layer28);
        org.junit.Assert.assertNull(collection29);
        org.junit.Assert.assertNull(collection30);
        org.junit.Assert.assertNull(collection31);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor15 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        boolean boolean17 = categoryAnchor15.equals((java.lang.Object) 0.0d);
        java.lang.String str18 = categoryAnchor15.toString();
        categoryPlot14.setDomainGridlinePosition(categoryAnchor15);
        java.lang.String str20 = categoryAnchor15.toString();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(categoryAnchor15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "CategoryAnchor.MIDDLE" + "'", str18.equals("CategoryAnchor.MIDDLE"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "CategoryAnchor.MIDDLE" + "'", str20.equals("CategoryAnchor.MIDDLE"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        org.jfree.chart.plot.Marker marker15 = null;
        boolean boolean16 = categoryPlot14.removeDomainMarker(marker15);
        java.util.List list17 = categoryPlot14.getAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        try {
            categoryPlot14.handleClick(0, (int) (byte) 100, plotRenderingInfo20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(list17);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        xYPlot0.clearDomainMarkers((int) (short) 10);
        double double5 = xYPlot0.getDomainCrosshairValue();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape7 = dateAxis6.getLeftArrow();
        java.util.TimeZone timeZone8 = dateAxis6.getTimeZone();
        java.awt.Font font9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis6.setTickLabelFont(font9);
        xYPlot0.setNoDataMessageFont(font9);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(font9);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        boolean boolean3 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        xYPlot4.configureDomainAxes();
        org.jfree.chart.util.Layer layer6 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection7 = xYPlot4.getDomainMarkers(layer6);
        java.util.Collection collection8 = xYPlot0.getRangeMarkers(layer6);
        java.awt.Stroke stroke9 = xYPlot0.getDomainZeroBaselineStroke();
        int int10 = xYPlot0.getRangeAxisCount();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isTickLabelsVisible();
        xYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis11);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis("");
        float float19 = categoryAxis18.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean21 = dateAxis20.isAutoTickUnitSelection();
        org.jfree.data.Range range22 = dateAxis20.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot23 = dateAxis20.getPlot();
        dateAxis20.setLabelURL("hi!");
        dateAxis20.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis20, categoryItemRenderer29);
        org.jfree.chart.plot.Marker marker31 = null;
        boolean boolean32 = categoryPlot30.removeDomainMarker(marker31);
        java.util.List list33 = categoryPlot30.getAnnotations();
        xYPlot0.drawDomainTickBands(graphics2D14, rectangle2D15, list33);
        boolean boolean35 = xYPlot0.isDomainZeroBaselineVisible();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(layer6);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 0.0f + "'", float19 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNull(plot23);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(list33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setTickMarksVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource3 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis0.setStandardTickUnits(tickUnitSource3);
        boolean boolean5 = dateAxis0.isAutoRange();
        org.jfree.data.Range range6 = null;
        try {
            dateAxis0.setRangeWithMargins(range6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(tickUnitSource3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.axis.AxisState axisState16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("");
        float float21 = categoryAxis20.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        boolean boolean23 = dateAxis22.isAutoTickUnitSelection();
        org.jfree.data.Range range24 = dateAxis22.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot25 = dateAxis22.getPlot();
        dateAxis22.setLabelURL("hi!");
        dateAxis22.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis20, (org.jfree.chart.axis.ValueAxis) dateAxis22, categoryItemRenderer31);
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot();
        xYPlot34.setRangeCrosshairVisible(true);
        boolean boolean37 = xYPlot34.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot38 = new org.jfree.chart.plot.XYPlot();
        xYPlot38.configureDomainAxes();
        org.jfree.chart.util.Layer layer40 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection41 = xYPlot38.getDomainMarkers(layer40);
        java.util.Collection collection42 = xYPlot34.getRangeMarkers(layer40);
        java.util.Collection collection43 = categoryPlot32.getRangeMarkers((int) (byte) 1, layer40);
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = categoryPlot32.getRangeAxisEdge((int) ' ');
        try {
            java.util.List list46 = categoryAxis2.refreshTicks(graphics2D15, axisState16, rectangle2D17, rectangleEdge45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 0.0f + "'", float21 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNull(plot25);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(layer40);
        org.junit.Assert.assertNull(collection41);
        org.junit.Assert.assertNull(collection42);
        org.junit.Assert.assertNull(collection43);
        org.junit.Assert.assertNotNull(rectangleEdge45);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType1 = rectangleInsets0.getUnitType();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat4 = numberAxis3.getNumberFormatOverride();
        org.jfree.data.RangeType rangeType5 = numberAxis3.getRangeType();
        boolean boolean6 = numberAxis3.isTickMarksVisible();
        double double7 = numberAxis3.getUpperMargin();
        boolean boolean8 = numberAxis3.isTickLabelsVisible();
        boolean boolean9 = unitType1.equals((java.lang.Object) boolean8);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(unitType1);
        org.junit.Assert.assertNull(numberFormat4);
        org.junit.Assert.assertNotNull(rangeType5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        boolean boolean3 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        xYPlot4.configureDomainAxes();
        org.jfree.chart.util.Layer layer6 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection7 = xYPlot4.getDomainMarkers(layer6);
        java.util.Collection collection8 = xYPlot0.getRangeMarkers(layer6);
        java.awt.Stroke stroke9 = xYPlot0.getDomainZeroBaselineStroke();
        int int10 = xYPlot0.getRangeAxisCount();
        java.awt.Image image11 = xYPlot0.getBackgroundImage();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation12 = null;
        try {
            boolean boolean14 = xYPlot0.removeAnnotation(xYAnnotation12, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(layer6);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNull(image11);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        java.awt.Color color0 = java.awt.Color.PINK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getLeftArrow();
        java.awt.Shape shape2 = dateAxis0.getUpArrow();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        java.awt.Color color0 = java.awt.Color.GRAY;
        int int1 = color0.getAlpha();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        categoryPlot14.setWeight((int) (byte) 0);
        org.jfree.chart.util.SortOrder sortOrder17 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot14.setRowRenderingOrder(sortOrder17);
        org.jfree.chart.LegendItemCollection legendItemCollection19 = categoryPlot14.getFixedLegendItems();
        org.jfree.chart.plot.CategoryMarker categoryMarker21 = null;
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis("");
        float float25 = categoryAxis24.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        boolean boolean27 = dateAxis26.isAutoTickUnitSelection();
        org.jfree.data.Range range28 = dateAxis26.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot29 = dateAxis26.getPlot();
        dateAxis26.setLabelURL("hi!");
        dateAxis26.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis24, (org.jfree.chart.axis.ValueAxis) dateAxis26, categoryItemRenderer35);
        categoryPlot36.setWeight((int) (byte) 0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener39 = null;
        categoryPlot36.addChangeListener(plotChangeListener39);
        org.jfree.chart.axis.AxisLocation axisLocation42 = null;
        categoryPlot36.setRangeAxisLocation((int) (short) 1, axisLocation42);
        org.jfree.chart.plot.Marker marker45 = null;
        org.jfree.chart.plot.XYPlot xYPlot46 = new org.jfree.chart.plot.XYPlot();
        xYPlot46.setRangeCrosshairVisible(true);
        boolean boolean49 = xYPlot46.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot();
        xYPlot50.configureDomainAxes();
        org.jfree.chart.util.Layer layer52 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection53 = xYPlot50.getDomainMarkers(layer52);
        java.util.Collection collection54 = xYPlot46.getRangeMarkers(layer52);
        boolean boolean56 = categoryPlot36.removeDomainMarker((-16777216), marker45, layer52, false);
        try {
            categoryPlot14.addDomainMarker((int) (byte) 0, categoryMarker21, layer52);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(sortOrder17);
        org.junit.Assert.assertNull(legendItemCollection19);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.0f + "'", float25 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertNull(plot29);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(layer52);
        org.junit.Assert.assertNull(collection53);
        org.junit.Assert.assertNull(collection54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        float float4 = categoryAxis3.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        boolean boolean6 = dateAxis5.isAutoTickUnitSelection();
        org.jfree.data.Range range7 = dateAxis5.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot8 = dateAxis5.getPlot();
        dateAxis5.setLabelURL("hi!");
        dateAxis5.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer14);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        dateAxis16.setTickMarksVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource19 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis16.setStandardTickUnits(tickUnitSource19);
        java.text.DateFormat dateFormat21 = null;
        dateAxis16.setDateFormatOverride(dateFormat21);
        dateAxis16.setTickMarksVisible(true);
        dateAxis16.setRange((double) (-1L), 1.0E-8d);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis16, categoryItemRenderer28);
        java.awt.Paint paint30 = categoryAxis3.getTickMarkPaint();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions31 = null;
        try {
            categoryAxis3.setCategoryLabelPositions(categoryLabelPositions31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'positions' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(tickUnitSource19);
        org.junit.Assert.assertNotNull(paint30);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        float float4 = categoryAxis3.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        boolean boolean6 = dateAxis5.isAutoTickUnitSelection();
        org.jfree.data.Range range7 = dateAxis5.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot8 = dateAxis5.getPlot();
        dateAxis5.setLabelURL("hi!");
        dateAxis5.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer14);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        dateAxis16.setTickMarksVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource19 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis16.setStandardTickUnits(tickUnitSource19);
        java.text.DateFormat dateFormat21 = null;
        dateAxis16.setDateFormatOverride(dateFormat21);
        dateAxis16.setTickMarksVisible(true);
        dateAxis16.setRange((double) (-1L), 1.0E-8d);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis16, categoryItemRenderer28);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray30 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot29.setRenderers(categoryItemRendererArray30);
        int int32 = categoryPlot29.getDomainAxisCount();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent33 = null;
        categoryPlot29.rendererChanged(rendererChangeEvent33);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(tickUnitSource19);
        org.junit.Assert.assertNotNull(categoryItemRendererArray30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        boolean boolean3 = xYPlot0.isRangeCrosshairLockedOnData();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.util.List list6 = null;
        xYPlot0.drawDomainTickBands(graphics2D4, rectangle2D5, list6);
        double double8 = xYPlot0.getRangeCrosshairValue();
        java.awt.Stroke stroke9 = xYPlot0.getOutlineStroke();
        xYPlot0.mapDatasetToRangeAxis((int) (short) -1, 6);
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        xYPlot13.setRangeCrosshairValue((double) (-1L));
        xYPlot0.setParent((org.jfree.chart.plot.Plot) xYPlot13);
        java.lang.String str17 = xYPlot0.getPlotType();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "XY Plot" + "'", str17.equals("XY Plot"));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        float float4 = categoryAxis3.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        boolean boolean6 = dateAxis5.isAutoTickUnitSelection();
        org.jfree.data.Range range7 = dateAxis5.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot8 = dateAxis5.getPlot();
        dateAxis5.setLabelURL("hi!");
        dateAxis5.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer14);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        dateAxis16.setTickMarksVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource19 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis16.setStandardTickUnits(tickUnitSource19);
        java.text.DateFormat dateFormat21 = null;
        dateAxis16.setDateFormatOverride(dateFormat21);
        dateAxis16.setTickMarksVisible(true);
        dateAxis16.setRange((double) (-1L), 1.0E-8d);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis16, categoryItemRenderer28);
        java.awt.Font font31 = categoryAxis3.getTickLabelFont((java.lang.Comparable) 'a');
        float float32 = categoryAxis3.getMaximumCategoryLabelWidthRatio();
        java.awt.Graphics2D graphics2D33 = null;
        org.jfree.chart.axis.AxisState axisState34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        org.jfree.data.category.CategoryDataset categoryDataset36 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = new org.jfree.chart.axis.CategoryAxis("");
        float float39 = categoryAxis38.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis();
        boolean boolean41 = dateAxis40.isAutoTickUnitSelection();
        org.jfree.data.Range range42 = dateAxis40.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot43 = dateAxis40.getPlot();
        dateAxis40.setLabelURL("hi!");
        dateAxis40.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer49 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot50 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis38, (org.jfree.chart.axis.ValueAxis) dateAxis40, categoryItemRenderer49);
        org.jfree.chart.plot.XYPlot xYPlot52 = new org.jfree.chart.plot.XYPlot();
        xYPlot52.setRangeCrosshairVisible(true);
        boolean boolean55 = xYPlot52.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot56 = new org.jfree.chart.plot.XYPlot();
        xYPlot56.configureDomainAxes();
        org.jfree.chart.util.Layer layer58 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection59 = xYPlot56.getDomainMarkers(layer58);
        java.util.Collection collection60 = xYPlot52.getRangeMarkers(layer58);
        java.util.Collection collection61 = categoryPlot50.getRangeMarkers((int) (byte) 1, layer58);
        org.jfree.chart.util.RectangleEdge rectangleEdge63 = categoryPlot50.getRangeAxisEdge((int) ' ');
        try {
            java.util.List list64 = categoryAxis3.refreshTicks(graphics2D33, axisState34, rectangle2D35, rectangleEdge63);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(tickUnitSource19);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertTrue("'" + float32 + "' != '" + 0.0f + "'", float32 == 0.0f);
        org.junit.Assert.assertTrue("'" + float39 + "' != '" + 0.0f + "'", float39 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(range42);
        org.junit.Assert.assertNull(plot43);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(layer58);
        org.junit.Assert.assertNull(collection59);
        org.junit.Assert.assertNull(collection60);
        org.junit.Assert.assertNull(collection61);
        org.junit.Assert.assertNotNull(rectangleEdge63);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        float float2 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        categoryAxis1.setLabel("hi!");
        float float5 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureDomainAxes();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat4 = numberAxis3.getNumberFormatOverride();
        org.jfree.data.RangeType rangeType5 = numberAxis3.getRangeType();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis3.setMarkerBand(markerAxisBand6);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis9.configure();
        double double11 = numberAxis9.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat14 = numberAxis13.getNumberFormatOverride();
        org.jfree.data.RangeType rangeType15 = numberAxis13.getRangeType();
        numberAxis9.setRangeType(rangeType15);
        numberAxis3.setRangeType(rangeType15);
        xYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot();
        xYPlot21.configureDomainAxes();
        java.awt.geom.Point2D point2D23 = xYPlot21.getQuadrantOrigin();
        try {
            xYPlot0.zoomRangeAxes((double) '#', plotRenderingInfo20, point2D23, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(numberFormat4);
        org.junit.Assert.assertNotNull(rangeType5);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNull(numberFormat14);
        org.junit.Assert.assertNotNull(rangeType15);
        org.junit.Assert.assertNotNull(point2D23);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        org.jfree.chart.plot.Marker marker15 = null;
        boolean boolean16 = categoryPlot14.removeDomainMarker(marker15);
        java.util.List list17 = categoryPlot14.getAnnotations();
        java.awt.Stroke stroke18 = categoryPlot14.getRangeGridlineStroke();
        java.awt.Image image19 = categoryPlot14.getBackgroundImage();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(list17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNull(image19);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isAutoTickUnitSelection();
        org.jfree.data.Range range2 = dateAxis0.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot3 = dateAxis0.getPlot();
        java.util.Date date4 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis0.setMinimumDate(date4);
        org.jfree.chart.axis.Timeline timeline6 = dateAxis0.getTimeline();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeline6);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        org.jfree.chart.plot.Marker marker15 = null;
        boolean boolean16 = categoryPlot14.removeDomainMarker(marker15);
        categoryPlot14.zoom(2.0d);
        boolean boolean19 = categoryPlot14.isRangeCrosshairLockedOnData();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("XY Plot");
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        boolean boolean3 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        xYPlot4.configureDomainAxes();
        org.jfree.chart.util.Layer layer6 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection7 = xYPlot4.getDomainMarkers(layer6);
        java.util.Collection collection8 = xYPlot0.getRangeMarkers(layer6);
        java.awt.Stroke stroke9 = xYPlot0.getDomainZeroBaselineStroke();
        int int10 = xYPlot0.getRangeAxisCount();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isTickLabelsVisible();
        xYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis11);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition14 = dateAxis11.getTickMarkPosition();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(layer6);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(dateTickMarkPosition14);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setTickMarksVisible(true);
        java.lang.Object obj4 = dateAxis1.clone();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        boolean boolean6 = dateAxis5.isAutoTickUnitSelection();
        org.jfree.data.Range range7 = dateAxis5.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot8 = dateAxis5.getPlot();
        dateAxis5.setLabelURL("hi!");
        dateAxis5.setLowerMargin(0.0d);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer13);
        boolean boolean15 = dateAxis5.isInverted();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureDomainAxes();
        xYPlot0.zoom((double) 10);
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean6 = xYPlot0.removeDomainMarker(marker4, layer5);
        double double7 = xYPlot0.getRangeCrosshairValue();
        float float8 = xYPlot0.getBackgroundImageAlpha();
        org.junit.Assert.assertNotNull(layer5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.5f + "'", float8 == 0.5f);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        dateAxis3.setTickMarksVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource6 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis3.setStandardTickUnits(tickUnitSource6);
        java.text.DateFormat dateFormat8 = null;
        dateAxis3.setDateFormatOverride(dateFormat8);
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = dateAxis10.getLabelInsets();
        dateAxis3.setTickLabelInsets(rectangleInsets11);
        xYPlot0.setInsets(rectangleInsets11);
        org.jfree.chart.util.UnitType unitType14 = rectangleInsets11.getUnitType();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D18 = rectangleInsets11.createOutsetRectangle(rectangle2D15, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(tickUnitSource6);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(unitType14);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairValue((double) (-1L));
        boolean boolean3 = xYPlot0.isRangeZoomable();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        boolean boolean3 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        xYPlot4.configureDomainAxes();
        org.jfree.chart.util.Layer layer6 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection7 = xYPlot4.getDomainMarkers(layer6);
        java.util.Collection collection8 = xYPlot0.getRangeMarkers(layer6);
        java.awt.Stroke stroke9 = xYPlot0.getDomainZeroBaselineStroke();
        java.lang.Object obj10 = xYPlot0.clone();
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        xYPlot11.setRangeCrosshairValue((double) (-1L));
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder14 = xYPlot11.getSeriesRenderingOrder();
        xYPlot0.setSeriesRenderingOrder(seriesRenderingOrder14);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation16 = null;
        try {
            boolean boolean18 = xYPlot0.removeAnnotation(xYAnnotation16, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(layer6);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(seriesRenderingOrder14);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isAutoTickUnitSelection();
        org.jfree.data.Range range2 = dateAxis0.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot3 = dateAxis0.getPlot();
        dateAxis0.setLabelURL("hi!");
        dateAxis0.zoomRange((double) 0.0f, (double) 7);
        java.awt.Paint paint9 = dateAxis0.getTickMarkPaint();
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis("");
        float float16 = categoryAxis15.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        boolean boolean18 = dateAxis17.isAutoTickUnitSelection();
        org.jfree.data.Range range19 = dateAxis17.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot20 = dateAxis17.getPlot();
        dateAxis17.setLabelURL("hi!");
        dateAxis17.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis15, (org.jfree.chart.axis.ValueAxis) dateAxis17, categoryItemRenderer26);
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis();
        dateAxis28.setTickMarksVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource31 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis28.setStandardTickUnits(tickUnitSource31);
        java.text.DateFormat dateFormat33 = null;
        dateAxis28.setDateFormatOverride(dateFormat33);
        dateAxis28.setTickMarksVisible(true);
        dateAxis28.setRange((double) (-1L), 1.0E-8d);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer40 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis15, (org.jfree.chart.axis.ValueAxis) dateAxis28, categoryItemRenderer40);
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = categoryPlot41.getRangeAxisEdge();
        try {
            double double43 = dateAxis0.java2DToValue(0.0d, rectangle2D11, rectangleEdge42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 0.0f + "'", float16 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertNull(plot20);
        org.junit.Assert.assertNotNull(tickUnitSource31);
        org.junit.Assert.assertNotNull(rectangleEdge42);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureDomainAxes();
        xYPlot0.zoom((double) 10);
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean6 = xYPlot0.removeDomainMarker(marker4, layer5);
        xYPlot0.clearRangeMarkers();
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        xYPlot0.drawAnnotations(graphics2D8, rectangle2D9, plotRenderingInfo10);
        org.junit.Assert.assertNotNull(layer5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        xYPlot16.setRangeCrosshairVisible(true);
        boolean boolean19 = xYPlot16.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        xYPlot20.configureDomainAxes();
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection23 = xYPlot20.getDomainMarkers(layer22);
        java.util.Collection collection24 = xYPlot16.getRangeMarkers(layer22);
        java.util.Collection collection25 = categoryPlot14.getRangeMarkers((int) (byte) 1, layer22);
        java.util.List list26 = categoryPlot14.getCategories();
        categoryPlot14.clearAnnotations();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = categoryPlot14.getDrawingSupplier();
        org.jfree.chart.plot.Marker marker29 = null;
        boolean boolean30 = categoryPlot14.removeDomainMarker(marker29);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertNull(collection23);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertNull(list26);
        org.junit.Assert.assertNotNull(drawingSupplier28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.configure();
        java.lang.Object obj4 = numberAxis2.clone();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = numberAxis2.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = dateAxis6.getLabelInsets();
        dateAxis6.setLabel("XY Plot");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis6, xYItemRenderer10);
        try {
            numberAxis2.setRange((double) 100, (double) 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (100.0) <= upper (8.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(numberTickUnit5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        try {
            java.awt.geom.Point2D point2D2 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor1);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        xYPlot16.setRangeCrosshairVisible(true);
        boolean boolean19 = xYPlot16.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        xYPlot20.configureDomainAxes();
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection23 = xYPlot20.getDomainMarkers(layer22);
        java.util.Collection collection24 = xYPlot16.getRangeMarkers(layer22);
        java.util.Collection collection25 = categoryPlot14.getRangeMarkers((int) (byte) 1, layer22);
        java.util.List list26 = categoryPlot14.getCategories();
        categoryPlot14.clearAnnotations();
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = categoryPlot14.getRangeAxisEdge();
        org.jfree.chart.event.PlotChangeListener plotChangeListener29 = null;
        categoryPlot14.addChangeListener(plotChangeListener29);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertNull(collection23);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertNull(list26);
        org.junit.Assert.assertNotNull(rectangleEdge28);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        float float4 = categoryAxis3.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        boolean boolean6 = dateAxis5.isAutoTickUnitSelection();
        org.jfree.data.Range range7 = dateAxis5.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot8 = dateAxis5.getPlot();
        dateAxis5.setLabelURL("hi!");
        dateAxis5.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer14);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        dateAxis16.setTickMarksVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource19 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis16.setStandardTickUnits(tickUnitSource19);
        java.text.DateFormat dateFormat21 = null;
        dateAxis16.setDateFormatOverride(dateFormat21);
        dateAxis16.setTickMarksVisible(true);
        dateAxis16.setRange((double) (-1L), 1.0E-8d);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis16, categoryItemRenderer28);
        java.awt.Paint paint30 = categoryAxis3.getTickMarkPaint();
        java.awt.Paint paint31 = categoryAxis3.getAxisLinePaint();
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(tickUnitSource19);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(paint31);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        org.jfree.chart.plot.Marker marker15 = null;
        boolean boolean16 = categoryPlot14.removeDomainMarker(marker15);
        categoryPlot14.zoom(2.0d);
        org.jfree.chart.LegendItemCollection legendItemCollection19 = categoryPlot14.getFixedLegendItems();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(legendItemCollection19);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        categoryPlot14.setWeight((int) (byte) 0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener17 = null;
        categoryPlot14.addChangeListener(plotChangeListener17);
        org.jfree.chart.axis.AxisLocation axisLocation20 = null;
        categoryPlot14.setRangeAxisLocation((int) (short) 1, axisLocation20);
        boolean boolean22 = categoryPlot14.isDomainZoomable();
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot();
        xYPlot23.setRangeCrosshairVisible(true);
        xYPlot23.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        int int29 = xYPlot23.getRangeAxisIndex(valueAxis28);
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis("");
        float float33 = categoryAxis32.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        boolean boolean35 = dateAxis34.isAutoTickUnitSelection();
        org.jfree.data.Range range36 = dateAxis34.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot37 = dateAxis34.getPlot();
        dateAxis34.setLabelURL("hi!");
        dateAxis34.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer43 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis32, (org.jfree.chart.axis.ValueAxis) dateAxis34, categoryItemRenderer43);
        categoryPlot44.setWeight((int) (byte) 0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener47 = null;
        categoryPlot44.addChangeListener(plotChangeListener47);
        org.jfree.chart.axis.AxisLocation axisLocation50 = null;
        categoryPlot44.setRangeAxisLocation((int) (short) 1, axisLocation50);
        org.jfree.chart.plot.XYPlot xYPlot52 = new org.jfree.chart.plot.XYPlot();
        xYPlot52.setRangeCrosshairVisible(true);
        boolean boolean55 = xYPlot52.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot56 = new org.jfree.chart.plot.XYPlot();
        xYPlot56.configureDomainAxes();
        org.jfree.chart.util.Layer layer58 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection59 = xYPlot56.getDomainMarkers(layer58);
        java.util.Collection collection60 = xYPlot52.getRangeMarkers(layer58);
        java.awt.Stroke stroke61 = xYPlot52.getDomainZeroBaselineStroke();
        categoryPlot44.setRangeGridlineStroke(stroke61);
        xYPlot23.setDomainCrosshairStroke(stroke61);
        categoryPlot14.setDomainGridlineStroke(stroke61);
        java.awt.Graphics2D graphics2D65 = null;
        java.awt.geom.Rectangle2D rectangle2D66 = null;
        org.jfree.chart.plot.XYPlot xYPlot67 = new org.jfree.chart.plot.XYPlot();
        xYPlot67.configureDomainAxes();
        java.awt.geom.Point2D point2D69 = xYPlot67.getQuadrantOrigin();
        org.jfree.chart.plot.PlotState plotState70 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo71 = null;
        try {
            categoryPlot14.draw(graphics2D65, rectangle2D66, point2D69, plotState70, plotRenderingInfo71);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.0f + "'", float33 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(range36);
        org.junit.Assert.assertNull(plot37);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(layer58);
        org.junit.Assert.assertNull(collection59);
        org.junit.Assert.assertNull(collection60);
        org.junit.Assert.assertNotNull(stroke61);
        org.junit.Assert.assertNotNull(point2D69);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.axis.AxisState axisState16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("");
        float float21 = categoryAxis20.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        boolean boolean23 = dateAxis22.isAutoTickUnitSelection();
        org.jfree.data.Range range24 = dateAxis22.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot25 = dateAxis22.getPlot();
        dateAxis22.setLabelURL("hi!");
        dateAxis22.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis20, (org.jfree.chart.axis.ValueAxis) dateAxis22, categoryItemRenderer31);
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot();
        xYPlot34.setRangeCrosshairVisible(true);
        boolean boolean37 = xYPlot34.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot38 = new org.jfree.chart.plot.XYPlot();
        xYPlot38.configureDomainAxes();
        org.jfree.chart.util.Layer layer40 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection41 = xYPlot38.getDomainMarkers(layer40);
        java.util.Collection collection42 = xYPlot34.getRangeMarkers(layer40);
        java.util.Collection collection43 = categoryPlot32.getRangeMarkers((int) (byte) 1, layer40);
        java.util.List list44 = categoryPlot32.getCategories();
        categoryPlot32.clearAnnotations();
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = categoryPlot32.getRangeAxisEdge();
        try {
            java.util.List list47 = categoryAxis2.refreshTicks(graphics2D15, axisState16, rectangle2D17, rectangleEdge46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 0.0f + "'", float21 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNull(plot25);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(layer40);
        org.junit.Assert.assertNull(collection41);
        org.junit.Assert.assertNull(collection42);
        org.junit.Assert.assertNull(collection43);
        org.junit.Assert.assertNull(list44);
        org.junit.Assert.assertNotNull(rectangleEdge46);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis1.configure();
        org.jfree.chart.plot.Plot plot3 = numberAxis1.getPlot();
        org.junit.Assert.assertNull(plot3);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.chart.plot.Marker marker0 = null;
        try {
            org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = new org.jfree.chart.event.MarkerChangeEvent(marker0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        boolean boolean3 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        xYPlot4.configureDomainAxes();
        org.jfree.chart.util.Layer layer6 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection7 = xYPlot4.getDomainMarkers(layer6);
        java.util.Collection collection8 = xYPlot0.getRangeMarkers(layer6);
        java.awt.Stroke stroke9 = xYPlot0.getDomainZeroBaselineStroke();
        int int10 = xYPlot0.getRangeAxisCount();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent11 = null;
        xYPlot0.markerChanged(markerChangeEvent11);
        org.jfree.chart.plot.Marker marker13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot();
        xYPlot14.setRangeCrosshairVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        xYPlot14.setInsets(rectangleInsets17, true);
        java.awt.Paint paint20 = xYPlot14.getDomainTickBandPaint();
        java.lang.String str21 = xYPlot14.getPlotType();
        org.jfree.chart.plot.Marker marker23 = null;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot();
        xYPlot24.setRangeCrosshairVisible(true);
        boolean boolean27 = xYPlot24.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot();
        xYPlot28.configureDomainAxes();
        org.jfree.chart.util.Layer layer30 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection31 = xYPlot28.getDomainMarkers(layer30);
        java.util.Collection collection32 = xYPlot24.getRangeMarkers(layer30);
        boolean boolean34 = xYPlot14.removeDomainMarker((int) ' ', marker23, layer30, false);
        try {
            xYPlot0.addRangeMarker(marker13, layer30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(layer6);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNull(paint20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "XY Plot" + "'", str21.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(layer30);
        org.junit.Assert.assertNull(collection31);
        org.junit.Assert.assertNull(collection32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        xYPlot16.setRangeCrosshairVisible(true);
        boolean boolean19 = xYPlot16.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        xYPlot20.configureDomainAxes();
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection23 = xYPlot20.getDomainMarkers(layer22);
        java.util.Collection collection24 = xYPlot16.getRangeMarkers(layer22);
        java.util.Collection collection25 = categoryPlot14.getRangeMarkers((int) (byte) 1, layer22);
        java.util.List list26 = categoryPlot14.getCategories();
        categoryPlot14.clearAnnotations();
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = categoryPlot14.getRangeAxisEdge();
        org.jfree.chart.plot.Marker marker30 = null;
        org.jfree.chart.util.Layer layer31 = null;
        try {
            boolean boolean33 = categoryPlot14.removeRangeMarker((int) (short) 100, marker30, layer31, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertNull(collection23);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertNull(list26);
        org.junit.Assert.assertNotNull(rectangleEdge28);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.configure();
        java.lang.Object obj4 = numberAxis2.clone();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = numberAxis2.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = dateAxis6.getLabelInsets();
        dateAxis6.setLabel("XY Plot");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis6, xYItemRenderer10);
        dateAxis6.setLowerBound((double) (byte) 1);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(numberTickUnit5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = chartChangeEventType0.equals((java.lang.Object) dateAxis1);
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        float float4 = categoryAxis3.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        boolean boolean6 = dateAxis5.isAutoTickUnitSelection();
        org.jfree.data.Range range7 = dateAxis5.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot8 = dateAxis5.getPlot();
        dateAxis5.setLabelURL("hi!");
        dateAxis5.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer14);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        dateAxis16.setTickMarksVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource19 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis16.setStandardTickUnits(tickUnitSource19);
        java.text.DateFormat dateFormat21 = null;
        dateAxis16.setDateFormatOverride(dateFormat21);
        dateAxis16.setTickMarksVisible(true);
        dateAxis16.setRange((double) (-1L), 1.0E-8d);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis16, categoryItemRenderer28);
        java.awt.Font font31 = categoryAxis3.getTickLabelFont((java.lang.Comparable) 'a');
        float float32 = categoryAxis3.getMaximumCategoryLabelWidthRatio();
        categoryAxis3.setMaximumCategoryLabelWidthRatio((float) (byte) 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(tickUnitSource19);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertTrue("'" + float32 + "' != '" + 0.0f + "'", float32 == 0.0f);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isAutoTickUnitSelection();
        org.jfree.data.Range range2 = dateAxis0.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot3 = dateAxis0.getPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = dateAxis0.getTickLabelInsets();
        double double6 = rectangleInsets4.trimWidth((double) 7);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureDomainAxes();
        xYPlot0.zoom((double) 10);
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean6 = xYPlot0.removeDomainMarker(marker4, layer5);
        xYPlot0.clearRangeMarkers();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        boolean boolean10 = dateAxis9.isAutoTickUnitSelection();
        org.jfree.data.Range range11 = dateAxis9.getDefaultAutoRange();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        boolean boolean13 = dateAxis12.isAutoTickUnitSelection();
        org.jfree.data.Range range14 = dateAxis12.getDefaultAutoRange();
        dateAxis9.setRangeWithMargins(range14);
        xYPlot0.setRangeAxis(5, (org.jfree.chart.axis.ValueAxis) dateAxis9, false);
        java.awt.Stroke stroke18 = xYPlot0.getDomainZeroBaselineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Point2D point2D21 = null;
        xYPlot0.zoomDomainAxes((double) 0, plotRenderingInfo20, point2D21, true);
        org.junit.Assert.assertNotNull(layer5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        xYPlot0.setInsets(rectangleInsets3, true);
        java.awt.Paint paint6 = xYPlot0.getDomainTickBandPaint();
        java.lang.String str7 = xYPlot0.getPlotType();
        double double8 = xYPlot0.getDomainCrosshairValue();
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "XY Plot" + "'", str7.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        java.awt.Color color0 = java.awt.Color.WHITE;
        int int1 = color0.getAlpha();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isAutoTickUnitSelection();
        org.jfree.data.Range range2 = dateAxis0.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot3 = dateAxis0.getPlot();
        dateAxis0.setLabelURL("hi!");
        dateAxis0.zoomRange((double) 0.0f, (double) 7);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("");
        float float17 = categoryAxis16.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        boolean boolean19 = dateAxis18.isAutoTickUnitSelection();
        org.jfree.data.Range range20 = dateAxis18.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot21 = dateAxis18.getPlot();
        dateAxis18.setLabelURL("hi!");
        dateAxis18.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis16, (org.jfree.chart.axis.ValueAxis) dateAxis18, categoryItemRenderer27);
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis();
        dateAxis29.setTickMarksVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource32 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis29.setStandardTickUnits(tickUnitSource32);
        java.text.DateFormat dateFormat34 = null;
        dateAxis29.setDateFormatOverride(dateFormat34);
        dateAxis29.setTickMarksVisible(true);
        dateAxis29.setRange((double) (-1L), 1.0E-8d);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer41 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis16, (org.jfree.chart.axis.ValueAxis) dateAxis29, categoryItemRenderer41);
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = categoryPlot42.getRangeAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo44 = null;
        try {
            org.jfree.chart.axis.AxisState axisState45 = dateAxis0.draw(graphics2D9, (double) 6, rectangle2D11, rectangle2D12, rectangleEdge43, plotRenderingInfo44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.0f + "'", float17 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertNotNull(tickUnitSource32);
        org.junit.Assert.assertNotNull(rectangleEdge43);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Calendar calendar1 = null;
        try {
            day0.peg(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 255, jFreeChart1);
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 1, jFreeChart4, chartChangeEventType5);
        chartChangeEvent2.setType(chartChangeEventType5);
        org.jfree.chart.JFreeChart jFreeChart8 = chartChangeEvent2.getChart();
        org.junit.Assert.assertNotNull(chartChangeEventType5);
        org.junit.Assert.assertNull(jFreeChart8);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        xYPlot1.configureDomainAxes();
        java.awt.Paint paint3 = xYPlot1.getRangeTickBandPaint();
        org.jfree.chart.plot.PlotOrientation plotOrientation4 = xYPlot1.getOrientation();
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge5 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation0, plotOrientation4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNotNull(plotOrientation4);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        categoryPlot14.setWeight((int) (byte) 0);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        categoryPlot14.setRenderer(categoryItemRenderer17);
        java.util.List list19 = categoryPlot14.getCategories();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNull(list19);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureDomainAxes();
        xYPlot0.zoom((double) 10);
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean6 = xYPlot0.removeDomainMarker(marker4, layer5);
        xYPlot0.clearRangeMarkers();
        xYPlot0.clearRangeMarkers(0);
        org.junit.Assert.assertNotNull(layer5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        float float4 = categoryAxis3.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        boolean boolean6 = dateAxis5.isAutoTickUnitSelection();
        org.jfree.data.Range range7 = dateAxis5.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot8 = dateAxis5.getPlot();
        dateAxis5.setLabelURL("hi!");
        dateAxis5.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer14);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        dateAxis16.setTickMarksVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource19 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis16.setStandardTickUnits(tickUnitSource19);
        java.text.DateFormat dateFormat21 = null;
        dateAxis16.setDateFormatOverride(dateFormat21);
        dateAxis16.setTickMarksVisible(true);
        dateAxis16.setRange((double) (-1L), 1.0E-8d);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis16, categoryItemRenderer28);
        dateAxis16.setTickMarkOutsideLength((float) 'a');
        java.awt.Font font32 = dateAxis16.getTickLabelFont();
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(tickUnitSource19);
        org.junit.Assert.assertNotNull(font32);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        dateAxis3.setTickMarksVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource6 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis3.setStandardTickUnits(tickUnitSource6);
        java.text.DateFormat dateFormat8 = null;
        dateAxis3.setDateFormatOverride(dateFormat8);
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = dateAxis10.getLabelInsets();
        dateAxis3.setTickLabelInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer13);
        java.awt.Color color16 = java.awt.Color.YELLOW;
        java.awt.Color color17 = color16.darker();
        java.awt.Color color18 = color17.brighter();
        categoryAxis2.setTickLabelPaint((java.lang.Comparable) (-1.0d), (java.awt.Paint) color18);
        org.junit.Assert.assertNotNull(tickUnitSource6);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color18);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        categoryPlot14.setWeight((int) (byte) 0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener17 = null;
        categoryPlot14.addChangeListener(plotChangeListener17);
        org.jfree.data.category.CategoryDataset categoryDataset20 = categoryPlot14.getDataset(6);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNull(categoryDataset20);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        xYPlot16.setRangeCrosshairVisible(true);
        boolean boolean19 = xYPlot16.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        xYPlot20.configureDomainAxes();
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection23 = xYPlot20.getDomainMarkers(layer22);
        java.util.Collection collection24 = xYPlot16.getRangeMarkers(layer22);
        java.util.Collection collection25 = categoryPlot14.getRangeMarkers((int) (byte) 1, layer22);
        java.util.List list26 = categoryPlot14.getCategories();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = categoryPlot14.getAxisOffset();
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = categoryPlot14.getDomainAxisForDataset((-83));
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertNull(collection23);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertNull(list26);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(categoryAxis29);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        categoryPlot14.setWeight((int) (byte) 0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener17 = null;
        categoryPlot14.addChangeListener(plotChangeListener17);
        java.awt.Color color19 = java.awt.Color.YELLOW;
        categoryPlot14.setDomainGridlinePaint((java.awt.Paint) color19);
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = categoryPlot14.getDomainAxis();
        java.lang.Comparable comparable22 = null;
        try {
            java.lang.String str23 = categoryAxis21.getCategoryLabelToolTip(comparable22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(categoryAxis21);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_INVERTED;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        xYPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = xYPlot0.getOutlinePaint();
        java.awt.Stroke stroke4 = xYPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.plot.Marker marker6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        xYPlot7.configureDomainAxes();
        xYPlot7.zoom((double) 10);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean13 = xYPlot7.removeDomainMarker(marker11, layer12);
        try {
            xYPlot0.addDomainMarker((int) (byte) 0, marker6, layer12, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(layer12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat2 = numberAxis1.getNumberFormatOverride();
        org.jfree.data.RangeType rangeType3 = numberAxis1.getRangeType();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis1.setMarkerBand(markerAxisBand4);
        java.text.NumberFormat numberFormat6 = numberAxis1.getNumberFormatOverride();
        org.junit.Assert.assertNull(numberFormat2);
        org.junit.Assert.assertNotNull(rangeType3);
        org.junit.Assert.assertNull(numberFormat6);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat2 = numberAxis1.getNumberFormatOverride();
        org.jfree.data.RangeType rangeType3 = numberAxis1.getRangeType();
        boolean boolean4 = numberAxis1.isTickMarksVisible();
        double double5 = numberAxis1.getUpperMargin();
        boolean boolean6 = numberAxis1.isTickLabelsVisible();
        boolean boolean7 = numberAxis1.getAutoRangeIncludesZero();
        org.junit.Assert.assertNull(numberFormat2);
        org.junit.Assert.assertNotNull(rangeType3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        java.awt.Paint paint3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setBackgroundPaint(paint3);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        int int6 = xYPlot0.getIndexOf(xYItemRenderer5);
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        float float10 = categoryAxis9.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isAutoTickUnitSelection();
        org.jfree.data.Range range13 = dateAxis11.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot14 = dateAxis11.getPlot();
        dateAxis11.setLabelURL("hi!");
        dateAxis11.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis11, categoryItemRenderer20);
        org.jfree.chart.plot.Marker marker22 = null;
        boolean boolean23 = categoryPlot21.removeDomainMarker(marker22);
        java.util.List list24 = categoryPlot21.getAnnotations();
        java.awt.Stroke stroke25 = categoryPlot21.getRangeGridlineStroke();
        xYPlot0.setRangeZeroBaselineStroke(stroke25);
        xYPlot0.setNoDataMessage("hi!");
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNull(plot14);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(list24);
        org.junit.Assert.assertNotNull(stroke25);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = dateAxis0.getLabelInsets();
        double double2 = rectangleInsets1.getBottom();
        double double4 = rectangleInsets1.calculateLeftInset(0.0d);
        double double6 = rectangleInsets1.calculateBottomInset((double) (short) 0);
        double double7 = rectangleInsets1.getTop();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.0d + "'", double4 == 3.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.0d + "'", double6 == 3.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.0d + "'", double7 == 3.0d);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        boolean boolean3 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        xYPlot4.configureDomainAxes();
        org.jfree.chart.util.Layer layer6 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection7 = xYPlot4.getDomainMarkers(layer6);
        java.util.Collection collection8 = xYPlot0.getRangeMarkers(layer6);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setParent((org.jfree.chart.plot.Plot) xYPlot9);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        xYPlot9.rendererChanged(rendererChangeEvent11);
        boolean boolean13 = xYPlot9.isRangeGridlinesVisible();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(layer6);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        categoryPlot14.setWeight((int) (byte) 0);
        org.jfree.chart.util.SortOrder sortOrder17 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot14.setRowRenderingOrder(sortOrder17);
        java.util.List list19 = categoryPlot14.getCategories();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(sortOrder17);
        org.junit.Assert.assertNull(list19);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isAutoTickUnitSelection();
        java.awt.Shape shape2 = dateAxis0.getLeftArrow();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition3 = dateAxis0.getTickMarkPosition();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        java.awt.Shape shape6 = dateAxis4.getLeftArrow();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition7 = dateAxis4.getTickMarkPosition();
        dateAxis0.setTickMarkPosition(dateTickMarkPosition7);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(dateTickMarkPosition3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(dateTickMarkPosition7);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat2 = numberAxis1.getNumberFormatOverride();
        org.jfree.data.RangeType rangeType3 = numberAxis1.getRangeType();
        boolean boolean4 = numberAxis1.isTickMarksVisible();
        double double5 = numberAxis1.getUpperMargin();
        boolean boolean6 = numberAxis1.isTickLabelsVisible();
        numberAxis1.setVerticalTickLabels(false);
        numberAxis1.setTickMarkOutsideLength((float) 100L);
        org.junit.Assert.assertNull(numberFormat2);
        org.junit.Assert.assertNotNull(rangeType3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        xYPlot16.setRangeCrosshairVisible(true);
        boolean boolean19 = xYPlot16.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        xYPlot20.configureDomainAxes();
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection23 = xYPlot20.getDomainMarkers(layer22);
        java.util.Collection collection24 = xYPlot16.getRangeMarkers(layer22);
        java.util.Collection collection25 = categoryPlot14.getRangeMarkers((int) (byte) 1, layer22);
        double double26 = categoryPlot14.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = new org.jfree.chart.axis.CategoryAxis("");
        float float30 = categoryAxis29.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis();
        boolean boolean32 = dateAxis31.isAutoTickUnitSelection();
        org.jfree.data.Range range33 = dateAxis31.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot34 = dateAxis31.getPlot();
        dateAxis31.setLabelURL("hi!");
        dateAxis31.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer40 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis29, (org.jfree.chart.axis.ValueAxis) dateAxis31, categoryItemRenderer40);
        org.jfree.chart.util.SortOrder sortOrder42 = categoryPlot41.getColumnRenderingOrder();
        categoryPlot14.setColumnRenderingOrder(sortOrder42);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation44 = null;
        try {
            categoryPlot14.addAnnotation(categoryAnnotation44);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertNull(collection23);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 0.0f + "'", float30 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(range33);
        org.junit.Assert.assertNull(plot34);
        org.junit.Assert.assertNotNull(sortOrder42);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getLeftArrow();
        double double2 = dateAxis0.getUpperBound();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        boolean boolean3 = xYPlot0.isRangeCrosshairLockedOnData();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.util.List list6 = null;
        xYPlot0.drawDomainTickBands(graphics2D4, rectangle2D5, list6);
        double double8 = xYPlot0.getRangeCrosshairValue();
        java.awt.Stroke stroke9 = xYPlot0.getOutlineStroke();
        xYPlot0.mapDatasetToRangeAxis((int) (short) -1, 6);
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        xYPlot13.setRangeCrosshairValue((double) (-1L));
        xYPlot0.setParent((org.jfree.chart.plot.Plot) xYPlot13);
        org.jfree.chart.axis.AxisLocation axisLocation17 = null;
        try {
            xYPlot0.setDomainAxisLocation(axisLocation17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        boolean boolean3 = xYPlot0.isRangeCrosshairLockedOnData();
        java.lang.String str4 = xYPlot0.getPlotType();
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("");
        float float8 = categoryAxis7.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        boolean boolean10 = dateAxis9.isAutoTickUnitSelection();
        org.jfree.data.Range range11 = dateAxis9.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot12 = dateAxis9.getPlot();
        dateAxis9.setLabelURL("hi!");
        dateAxis9.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis9, categoryItemRenderer18);
        org.jfree.chart.plot.Marker marker20 = null;
        boolean boolean21 = categoryPlot19.removeDomainMarker(marker20);
        java.util.List list22 = categoryPlot19.getAnnotations();
        java.awt.Stroke stroke23 = categoryPlot19.getRangeGridlineStroke();
        xYPlot0.setRangeCrosshairStroke(stroke23);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation25 = null;
        try {
            xYPlot0.addAnnotation(xYAnnotation25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "XY Plot" + "'", str4.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.0f + "'", float8 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNull(plot12);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(list22);
        org.junit.Assert.assertNotNull(stroke23);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        categoryPlot14.setWeight((int) (byte) 0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener17 = null;
        categoryPlot14.addChangeListener(plotChangeListener17);
        java.awt.Color color19 = java.awt.Color.YELLOW;
        categoryPlot14.setDomainGridlinePaint((java.awt.Paint) color19);
        categoryPlot14.clearDomainMarkers();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(color19);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        float float4 = categoryAxis3.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        boolean boolean6 = dateAxis5.isAutoTickUnitSelection();
        org.jfree.data.Range range7 = dateAxis5.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot8 = dateAxis5.getPlot();
        dateAxis5.setLabelURL("hi!");
        dateAxis5.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer14);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        dateAxis16.setTickMarksVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource19 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis16.setStandardTickUnits(tickUnitSource19);
        java.text.DateFormat dateFormat21 = null;
        dateAxis16.setDateFormatOverride(dateFormat21);
        dateAxis16.setTickMarksVisible(true);
        dateAxis16.setRange((double) (-1L), 1.0E-8d);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis16, categoryItemRenderer28);
        java.util.List list30 = categoryPlot29.getCategories();
        categoryPlot29.clearRangeMarkers();
        java.awt.Graphics2D graphics2D32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot();
        xYPlot34.configureDomainAxes();
        java.awt.geom.Point2D point2D36 = xYPlot34.getQuadrantOrigin();
        org.jfree.chart.plot.PlotState plotState37 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = null;
        try {
            categoryPlot29.draw(graphics2D32, rectangle2D33, point2D36, plotState37, plotRenderingInfo38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(tickUnitSource19);
        org.junit.Assert.assertNull(list30);
        org.junit.Assert.assertNotNull(point2D36);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setTickMarksVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource3 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis0.setStandardTickUnits(tickUnitSource3);
        java.text.DateFormat dateFormat5 = null;
        dateAxis0.setDateFormatOverride(dateFormat5);
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = dateAxis0.valueToJava2D((double) 10.0f, rectangle2D8, rectangleEdge9);
        dateAxis0.setAutoRange(false);
        boolean boolean13 = dateAxis0.isVisible();
        org.junit.Assert.assertNotNull(tickUnitSource3);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        categoryPlot14.setWeight((int) (byte) 0);
        org.jfree.chart.util.SortOrder sortOrder17 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot14.setRowRenderingOrder(sortOrder17);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        boolean boolean20 = dateAxis19.isAutoTickUnitSelection();
        org.jfree.data.Range range21 = dateAxis19.getDefaultAutoRange();
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        boolean boolean23 = dateAxis22.isAutoTickUnitSelection();
        org.jfree.data.Range range24 = dateAxis22.getDefaultAutoRange();
        dateAxis19.setRangeWithMargins(range24);
        categoryPlot14.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis19);
        dateAxis19.setLowerBound((double) 1L);
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis();
        boolean boolean30 = dateAxis29.isAutoTickUnitSelection();
        org.jfree.data.Range range31 = dateAxis29.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot32 = dateAxis29.getPlot();
        java.util.Date date33 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis29.setMinimumDate(date33);
        dateAxis19.setMaximumDate(date33);
        dateAxis19.setUpperBound((double) (short) 100);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(sortOrder17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertNull(plot32);
        org.junit.Assert.assertNotNull(date33);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_DOMAIN_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        categoryPlot14.setWeight((int) (byte) 0);
        org.jfree.chart.util.SortOrder sortOrder17 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot14.setRowRenderingOrder(sortOrder17);
        org.jfree.chart.LegendItemCollection legendItemCollection19 = categoryPlot14.getFixedLegendItems();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean21 = dateAxis20.isAutoTickUnitSelection();
        org.jfree.data.Range range22 = dateAxis20.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot23 = dateAxis20.getPlot();
        dateAxis20.setLabelURL("hi!");
        dateAxis20.setLowerMargin(0.0d);
        int int28 = categoryPlot14.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis20);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(sortOrder17);
        org.junit.Assert.assertNull(legendItemCollection19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNull(plot23);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
    }

//    @Test
//    public void test241() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test241");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getFirstMillisecond();
//        java.util.Calendar calendar2 = null;
//        try {
//            long long3 = day0.getLastMillisecond(calendar2);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560409200000L + "'", long1 == 1560409200000L);
//    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        categoryPlot14.setWeight((int) (byte) 0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener17 = null;
        categoryPlot14.addChangeListener(plotChangeListener17);
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        try {
            categoryPlot14.drawOutline(graphics2D19, rectangle2D20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 1, jFreeChart1, chartChangeEventType2);
        java.lang.String str4 = chartChangeEventType2.toString();
        org.junit.Assert.assertNotNull(chartChangeEventType2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str4.equals("ChartChangeEventType.DATASET_UPDATED"));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        int int2 = categoryAxis1.getMaximumCategoryLabelLines();
        java.awt.Font font4 = categoryAxis1.getTickLabelFont((java.lang.Comparable) 1);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("");
        float float8 = categoryAxis7.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        boolean boolean10 = dateAxis9.isAutoTickUnitSelection();
        org.jfree.data.Range range11 = dateAxis9.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot12 = dateAxis9.getPlot();
        dateAxis9.setLabelURL("hi!");
        dateAxis9.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis9, categoryItemRenderer18);
        java.awt.Font font21 = categoryAxis7.getTickLabelFont((java.lang.Comparable) 0.0f);
        categoryAxis1.setLabelFont(font21);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.0f + "'", float8 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNull(plot12);
        org.junit.Assert.assertNotNull(font21);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        categoryPlot14.setWeight((int) (byte) 0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener17 = null;
        categoryPlot14.addChangeListener(plotChangeListener17);
        org.jfree.chart.axis.AxisLocation axisLocation20 = null;
        categoryPlot14.setRangeAxisLocation((int) (short) 1, axisLocation20);
        boolean boolean22 = categoryPlot14.isDomainZoomable();
        categoryPlot14.clearDomainMarkers((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        int int1 = color0.getRGB();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-8388608) + "'", int1 == (-8388608));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureDomainAxes();
        java.lang.String str2 = xYPlot0.getNoDataMessage();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        xYPlot0.zoomRangeAxes((double) 10.0f, (double) 1L, plotRenderingInfo5, point2D6);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent8 = null;
        xYPlot0.axisChanged(axisChangeEvent8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = xYPlot0.getRenderer();
        xYPlot0.clearDomainMarkers((-128));
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(xYItemRenderer10);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        org.jfree.chart.plot.Marker marker15 = null;
        boolean boolean16 = categoryPlot14.removeDomainMarker(marker15);
        categoryPlot14.zoom(2.0d);
        categoryPlot14.setBackgroundImageAlignment((int) '#');
        java.lang.String str21 = categoryPlot14.getPlotType();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Category Plot" + "'", str21.equals("Category Plot"));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        xYPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = xYPlot0.getOutlinePaint();
        org.jfree.chart.util.Layer layer4 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(layer4);
        boolean boolean6 = xYPlot0.isSubplot();
        java.awt.Paint paint7 = xYPlot0.getRangeGridlinePaint();
        java.awt.Color color8 = java.awt.Color.red;
        java.awt.image.ColorModel colorModel9 = null;
        java.awt.Rectangle rectangle10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        java.awt.geom.AffineTransform affineTransform12 = null;
        java.awt.RenderingHints renderingHints13 = null;
        java.awt.PaintContext paintContext14 = color8.createContext(colorModel9, rectangle10, rectangle2D11, affineTransform12, renderingHints13);
        java.awt.Color color15 = color8.darker();
        java.awt.color.ColorSpace colorSpace16 = color8.getColorSpace();
        xYPlot0.setRangeGridlinePaint((java.awt.Paint) color8);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(layer4);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paintContext14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(colorSpace16);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis1.configure();
        java.lang.Object obj3 = numberAxis1.clone();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit4 = numberAxis1.getTickUnit();
        java.awt.Paint paint5 = numberAxis1.getTickMarkPaint();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(numberTickUnit4);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        org.jfree.chart.plot.Marker marker15 = null;
        boolean boolean16 = categoryPlot14.removeDomainMarker(marker15);
        java.util.List list17 = categoryPlot14.getAnnotations();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = categoryPlot14.getAxisOffset();
        boolean boolean19 = categoryPlot14.isRangeCrosshairVisible();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(list17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        java.awt.Font font16 = categoryAxis2.getTickLabelFont((java.lang.Comparable) 0.0f);
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis("");
        float float23 = categoryAxis22.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis();
        boolean boolean25 = dateAxis24.isAutoTickUnitSelection();
        org.jfree.data.Range range26 = dateAxis24.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot27 = dateAxis24.getPlot();
        dateAxis24.setLabelURL("hi!");
        dateAxis24.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis22, (org.jfree.chart.axis.ValueAxis) dateAxis24, categoryItemRenderer33);
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot();
        xYPlot36.setRangeCrosshairVisible(true);
        boolean boolean39 = xYPlot36.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot();
        xYPlot40.configureDomainAxes();
        org.jfree.chart.util.Layer layer42 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection43 = xYPlot40.getDomainMarkers(layer42);
        java.util.Collection collection44 = xYPlot36.getRangeMarkers(layer42);
        java.util.Collection collection45 = categoryPlot34.getRangeMarkers((int) (byte) 1, layer42);
        java.util.List list46 = categoryPlot34.getCategories();
        categoryPlot34.clearAnnotations();
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = categoryPlot34.getRangeAxisEdge();
        try {
            double double49 = categoryAxis2.getCategoryEnd(0, 11, rectangle2D19, rectangleEdge48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 0.0f + "'", float23 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(layer42);
        org.junit.Assert.assertNull(collection43);
        org.junit.Assert.assertNull(collection44);
        org.junit.Assert.assertNull(collection45);
        org.junit.Assert.assertNull(list46);
        org.junit.Assert.assertNotNull(rectangleEdge48);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        xYPlot0.setInsets(rectangleInsets3, true);
        java.awt.Paint paint6 = xYPlot0.getDomainTickBandPaint();
        java.lang.String str7 = xYPlot0.getPlotType();
        boolean boolean8 = xYPlot0.isRangeZeroBaselineVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        try {
            xYPlot0.setRenderer((-83), xYItemRenderer10, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "XY Plot" + "'", str7.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat2 = numberAxis1.getNumberFormatOverride();
        org.jfree.data.RangeType rangeType3 = numberAxis1.getRangeType();
        boolean boolean4 = numberAxis1.isTickMarksVisible();
        double double5 = numberAxis1.getUpperMargin();
        numberAxis1.setFixedDimension((double) 3);
        org.jfree.chart.plot.Plot plot8 = numberAxis1.getPlot();
        org.junit.Assert.assertNull(numberFormat2);
        org.junit.Assert.assertNotNull(rangeType3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNull(plot8);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        java.awt.Color color0 = java.awt.Color.BLACK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        xYPlot16.setRangeCrosshairVisible(true);
        boolean boolean19 = xYPlot16.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        xYPlot20.configureDomainAxes();
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection23 = xYPlot20.getDomainMarkers(layer22);
        java.util.Collection collection24 = xYPlot16.getRangeMarkers(layer22);
        java.util.Collection collection25 = categoryPlot14.getRangeMarkers((int) (byte) 1, layer22);
        java.util.List list26 = categoryPlot14.getCategories();
        java.awt.Graphics2D graphics2D27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        boolean boolean31 = categoryPlot14.render(graphics2D27, rectangle2D28, 0, plotRenderingInfo30);
        categoryPlot14.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.Marker marker35 = null;
        org.jfree.data.category.CategoryDataset categoryDataset36 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = new org.jfree.chart.axis.CategoryAxis("");
        float float39 = categoryAxis38.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis();
        boolean boolean41 = dateAxis40.isAutoTickUnitSelection();
        org.jfree.data.Range range42 = dateAxis40.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot43 = dateAxis40.getPlot();
        dateAxis40.setLabelURL("hi!");
        dateAxis40.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer49 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot50 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis38, (org.jfree.chart.axis.ValueAxis) dateAxis40, categoryItemRenderer49);
        org.jfree.chart.plot.XYPlot xYPlot52 = new org.jfree.chart.plot.XYPlot();
        xYPlot52.setRangeCrosshairVisible(true);
        boolean boolean55 = xYPlot52.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot56 = new org.jfree.chart.plot.XYPlot();
        xYPlot56.configureDomainAxes();
        org.jfree.chart.util.Layer layer58 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection59 = xYPlot56.getDomainMarkers(layer58);
        java.util.Collection collection60 = xYPlot52.getRangeMarkers(layer58);
        java.util.Collection collection61 = categoryPlot50.getRangeMarkers((int) (byte) 1, layer58);
        java.awt.Paint paint62 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        boolean boolean63 = layer58.equals((java.lang.Object) paint62);
        try {
            boolean boolean64 = categoryPlot14.removeRangeMarker((int) ' ', marker35, layer58);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertNull(collection23);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertNull(list26);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + float39 + "' != '" + 0.0f + "'", float39 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(range42);
        org.junit.Assert.assertNull(plot43);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(layer58);
        org.junit.Assert.assertNull(collection59);
        org.junit.Assert.assertNull(collection60);
        org.junit.Assert.assertNull(collection61);
        org.junit.Assert.assertNotNull(paint62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = dateAxis0.getLabelInsets();
        dateAxis0.setLabel("XY Plot");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = dateAxis0.getTickLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        boolean boolean6 = dateAxis5.isAutoTickUnitSelection();
        org.jfree.data.Range range7 = dateAxis5.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot8 = dateAxis5.getPlot();
        java.util.Date date9 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis5.setMinimumDate(date9);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isAutoTickUnitSelection();
        org.jfree.data.Range range13 = dateAxis11.getDefaultAutoRange();
        dateAxis5.setRangeWithMargins(range13, false, false);
        dateAxis0.setRange(range13);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(range13);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Paint[] paintArray1 = new java.awt.Paint[] {};
        java.awt.Stroke[] strokeArray2 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray3 = new java.awt.Stroke[] {};
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape[] shapeArray5 = new java.awt.Shape[] { shape4 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier6 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, strokeArray2, strokeArray3, shapeArray5);
        java.awt.Shape shape7 = defaultDrawingSupplier6.getNextShape();
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(strokeArray2);
        org.junit.Assert.assertNotNull(strokeArray3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shapeArray5);
        org.junit.Assert.assertNotNull(shape7);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = dateAxis0.getLabelInsets();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = rectangleInsets1.createInsetRectangle(rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        categoryPlot14.setWeight((int) (byte) 0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener17 = null;
        categoryPlot14.addChangeListener(plotChangeListener17);
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener20 = null;
        xYPlot19.addChangeListener(plotChangeListener20);
        java.awt.Paint paint22 = xYPlot19.getOutlinePaint();
        java.awt.Stroke stroke23 = xYPlot19.getRangeZeroBaselineStroke();
        categoryPlot14.setDomainGridlineStroke(stroke23);
        org.jfree.chart.axis.AxisSpace axisSpace25 = categoryPlot14.getFixedDomainAxisSpace();
        categoryPlot14.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        java.awt.geom.Point2D point2D30 = null;
        categoryPlot14.zoomDomainAxes((double) '4', plotRenderingInfo29, point2D30);
        org.jfree.data.category.CategoryDataset categoryDataset32 = categoryPlot14.getDataset();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNull(axisSpace25);
        org.junit.Assert.assertNull(categoryDataset32);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        boolean boolean3 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureDomainAxes();
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat9 = numberAxis8.getNumberFormatOverride();
        org.jfree.data.RangeType rangeType10 = numberAxis8.getRangeType();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand11 = null;
        numberAxis8.setMarkerBand(markerAxisBand11);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis14.configure();
        double double16 = numberAxis14.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat19 = numberAxis18.getNumberFormatOverride();
        org.jfree.data.RangeType rangeType20 = numberAxis18.getRangeType();
        numberAxis14.setRangeType(rangeType20);
        numberAxis8.setRangeType(rangeType20);
        xYPlot5.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis8);
        xYPlot0.setRangeAxis(255, (org.jfree.chart.axis.ValueAxis) numberAxis8, false);
        java.text.NumberFormat numberFormat26 = null;
        numberAxis8.setNumberFormatOverride(numberFormat26);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(numberFormat9);
        org.junit.Assert.assertNotNull(rangeType10);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNull(numberFormat19);
        org.junit.Assert.assertNotNull(rangeType20);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        boolean boolean3 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        xYPlot4.configureDomainAxes();
        org.jfree.chart.util.Layer layer6 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection7 = xYPlot4.getDomainMarkers(layer6);
        java.util.Collection collection8 = xYPlot0.getRangeMarkers(layer6);
        java.awt.Stroke stroke9 = xYPlot0.getDomainZeroBaselineStroke();
        int int10 = xYPlot0.getRangeAxisCount();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        dateAxis11.setTickMarksVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource14 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis11.setStandardTickUnits(tickUnitSource14);
        boolean boolean16 = dateAxis11.isAutoRange();
        int int17 = xYPlot0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis11);
        dateAxis11.setAxisLineVisible(false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(layer6);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(tickUnitSource14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ChartChangeEventType.DATASET_UPDATED");
        numberAxis1.setLowerBound((double) 1560409200000L);
        boolean boolean4 = numberAxis1.isNegativeArrowVisible();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        float float4 = categoryAxis3.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        boolean boolean6 = dateAxis5.isAutoTickUnitSelection();
        org.jfree.data.Range range7 = dateAxis5.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot8 = dateAxis5.getPlot();
        dateAxis5.setLabelURL("hi!");
        dateAxis5.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer14);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        dateAxis16.setTickMarksVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource19 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis16.setStandardTickUnits(tickUnitSource19);
        java.text.DateFormat dateFormat21 = null;
        dateAxis16.setDateFormatOverride(dateFormat21);
        dateAxis16.setTickMarksVisible(true);
        dateAxis16.setRange((double) (-1L), 1.0E-8d);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis16, categoryItemRenderer28);
        int int30 = categoryPlot29.getBackgroundImageAlignment();
        org.jfree.chart.axis.AxisLocation axisLocation32 = categoryPlot29.getDomainAxisLocation((-128));
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent33 = null;
        categoryPlot29.axisChanged(axisChangeEvent33);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(tickUnitSource19);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 15 + "'", int30 == 15);
        org.junit.Assert.assertNotNull(axisLocation32);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureDomainAxes();
        java.awt.geom.Point2D point2D2 = xYPlot0.getQuadrantOrigin();
        java.awt.Stroke stroke3 = xYPlot0.getDomainGridlineStroke();
        org.junit.Assert.assertNotNull(point2D2);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        float float4 = categoryAxis3.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        boolean boolean6 = dateAxis5.isAutoTickUnitSelection();
        org.jfree.data.Range range7 = dateAxis5.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot8 = dateAxis5.getPlot();
        dateAxis5.setLabelURL("hi!");
        dateAxis5.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer14);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        dateAxis16.setTickMarksVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource19 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis16.setStandardTickUnits(tickUnitSource19);
        java.text.DateFormat dateFormat21 = null;
        dateAxis16.setDateFormatOverride(dateFormat21);
        dateAxis16.setTickMarksVisible(true);
        dateAxis16.setRange((double) (-1L), 1.0E-8d);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis16, categoryItemRenderer28);
        java.util.List list30 = categoryPlot29.getCategories();
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = categoryPlot29.getRangeAxisEdge(3);
        org.jfree.chart.plot.PlotOrientation plotOrientation33 = categoryPlot29.getOrientation();
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(tickUnitSource19);
        org.junit.Assert.assertNull(list30);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertNotNull(plotOrientation33);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        org.jfree.chart.plot.Marker marker15 = null;
        boolean boolean16 = categoryPlot14.removeDomainMarker(marker15);
        java.util.List list17 = categoryPlot14.getAnnotations();
        java.awt.Stroke stroke18 = categoryPlot14.getRangeGridlineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent19 = null;
        categoryPlot14.rendererChanged(rendererChangeEvent19);
        categoryPlot14.clearAnnotations();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(list17);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent15 = null;
        categoryPlot14.notifyListeners(plotChangeEvent15);
        org.jfree.chart.axis.ValueAxis valueAxis18 = categoryPlot14.getRangeAxisForDataset((int) (byte) -1);
        java.awt.Paint paint19 = categoryPlot14.getRangeGridlinePaint();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(valueAxis18);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        xYPlot0.addChangeListener(plotChangeListener1);
        boolean boolean3 = xYPlot0.isDomainGridlinesVisible();
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        xYPlot5.addChangeListener(plotChangeListener6);
        java.awt.Paint paint8 = xYPlot5.getOutlinePaint();
        float float9 = xYPlot5.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation10 = xYPlot5.getRangeAxisLocation();
        xYPlot0.setRangeAxisLocation((int) (byte) 100, axisLocation10, false);
        org.jfree.chart.LegendItemCollection legendItemCollection13 = xYPlot0.getLegendItems();
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        int int15 = xYPlot0.indexOf(xYDataset14);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1.0f + "'", float9 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(legendItemCollection13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis1.configure();
        double double3 = numberAxis1.getFixedAutoRange();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis1.setMarkerBand(markerAxisBand4);
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis1.setUpArrow(shape6);
        boolean boolean8 = numberAxis1.getAutoRangeStickyZero();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        xYPlot0.setInsets(rectangleInsets3, true);
        java.awt.Paint paint6 = xYPlot0.getDomainTickBandPaint();
        java.lang.String str7 = xYPlot0.getPlotType();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape9 = dateAxis8.getLeftArrow();
        java.awt.Paint paint10 = dateAxis8.getAxisLinePaint();
        int int11 = xYPlot0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis8);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setTickMarksVisible(true);
        org.jfree.chart.event.AxisChangeListener axisChangeListener15 = null;
        dateAxis12.removeChangeListener(axisChangeListener15);
        java.awt.Font font17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis12.setTickLabelFont(font17);
        dateAxis12.setNegativeArrowVisible(false);
        xYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis12);
        org.jfree.chart.axis.AxisLocation axisLocation22 = xYPlot0.getRangeAxisLocation();
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "XY Plot" + "'", str7.equals("XY Plot"));
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(axisLocation22);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        xYPlot16.setRangeCrosshairVisible(true);
        boolean boolean19 = xYPlot16.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        xYPlot20.configureDomainAxes();
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection23 = xYPlot20.getDomainMarkers(layer22);
        java.util.Collection collection24 = xYPlot16.getRangeMarkers(layer22);
        java.util.Collection collection25 = categoryPlot14.getRangeMarkers((int) (byte) 1, layer22);
        org.jfree.chart.axis.AxisLocation axisLocation26 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        boolean boolean28 = axisLocation26.equals((java.lang.Object) rectangleInsets27);
        categoryPlot14.setAxisOffset(rectangleInsets27);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertNull(collection23);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType1 = rectangleInsets0.getUnitType();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor2 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        boolean boolean4 = categoryAnchor2.equals((java.lang.Object) stroke3);
        boolean boolean5 = unitType1.equals((java.lang.Object) stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(unitType1);
        org.junit.Assert.assertNotNull(categoryAnchor2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        xYPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = xYPlot0.getOutlinePaint();
        boolean boolean4 = xYPlot0.isDomainZeroBaselineVisible();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        boolean boolean3 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        xYPlot4.configureDomainAxes();
        org.jfree.chart.util.Layer layer6 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection7 = xYPlot4.getDomainMarkers(layer6);
        java.util.Collection collection8 = xYPlot0.getRangeMarkers(layer6);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setParent((org.jfree.chart.plot.Plot) xYPlot9);
        xYPlot9.setRangeCrosshairValue((double) (byte) 0);
        boolean boolean13 = xYPlot9.isRangeCrosshairLockedOnData();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(layer6);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent15 = null;
        categoryPlot14.notifyListeners(plotChangeEvent15);
        categoryPlot14.clearRangeMarkers();
        org.jfree.chart.axis.AxisSpace axisSpace18 = categoryPlot14.getFixedDomainAxisSpace();
        boolean boolean19 = categoryPlot14.isRangeCrosshairLockedOnData();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNull(axisSpace18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setTickMarksVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource3 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis0.setStandardTickUnits(tickUnitSource3);
        java.text.DateFormat dateFormat5 = null;
        dateAxis0.setDateFormatOverride(dateFormat5);
        dateAxis0.setTickMarksVisible(true);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        float float14 = categoryAxis13.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        boolean boolean16 = dateAxis15.isAutoTickUnitSelection();
        org.jfree.data.Range range17 = dateAxis15.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot18 = dateAxis15.getPlot();
        dateAxis15.setLabelURL("hi!");
        dateAxis15.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis13, (org.jfree.chart.axis.ValueAxis) dateAxis15, categoryItemRenderer24);
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot();
        xYPlot27.setRangeCrosshairVisible(true);
        boolean boolean30 = xYPlot27.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot();
        xYPlot31.configureDomainAxes();
        org.jfree.chart.util.Layer layer33 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection34 = xYPlot31.getDomainMarkers(layer33);
        java.util.Collection collection35 = xYPlot27.getRangeMarkers(layer33);
        java.util.Collection collection36 = categoryPlot25.getRangeMarkers((int) (byte) 1, layer33);
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = categoryPlot25.getRangeAxisEdge((int) ' ');
        try {
            double double39 = dateAxis0.java2DToValue((double) (-83), rectangle2D10, rectangleEdge38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(tickUnitSource3);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(plot18);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(layer33);
        org.junit.Assert.assertNull(collection34);
        org.junit.Assert.assertNull(collection35);
        org.junit.Assert.assertNull(collection36);
        org.junit.Assert.assertNotNull(rectangleEdge38);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        java.awt.Color color0 = java.awt.Color.white;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        int int2 = categoryAxis1.getMaximumCategoryLabelLines();
        java.awt.Paint paint4 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) 5);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isAutoTickUnitSelection();
        org.jfree.data.Range range2 = dateAxis0.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot3 = dateAxis0.getPlot();
        java.util.Date date4 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis0.setMinimumDate(date4);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        boolean boolean7 = dateAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = dateAxis6.getDefaultAutoRange();
        dateAxis0.setRangeWithMargins(range8, false, false);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("");
        float float15 = categoryAxis14.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        boolean boolean17 = dateAxis16.isAutoTickUnitSelection();
        org.jfree.data.Range range18 = dateAxis16.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot19 = dateAxis16.getPlot();
        dateAxis16.setLabelURL("hi!");
        dateAxis16.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis16, categoryItemRenderer25);
        java.awt.Font font28 = categoryAxis14.getTickLabelFont((java.lang.Comparable) 0.0f);
        dateAxis0.setLabelFont(font28);
        dateAxis0.setLowerBound((double) 11);
        dateAxis0.setTickLabelsVisible(true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.0f + "'", float15 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNull(plot19);
        org.junit.Assert.assertNotNull(font28);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureDomainAxes();
        java.awt.geom.Point2D point2D2 = xYPlot0.getQuadrantOrigin();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        float float6 = categoryAxis5.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isAutoTickUnitSelection();
        org.jfree.data.Range range9 = dateAxis7.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot10 = dateAxis7.getPlot();
        dateAxis7.setLabelURL("hi!");
        dateAxis7.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer16);
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot();
        xYPlot19.setRangeCrosshairVisible(true);
        boolean boolean22 = xYPlot19.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot();
        xYPlot23.configureDomainAxes();
        org.jfree.chart.util.Layer layer25 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection26 = xYPlot23.getDomainMarkers(layer25);
        java.util.Collection collection27 = xYPlot19.getRangeMarkers(layer25);
        java.util.Collection collection28 = categoryPlot17.getRangeMarkers((int) (byte) 1, layer25);
        java.util.List list29 = categoryPlot17.getCategories();
        categoryPlot17.clearAnnotations();
        org.jfree.chart.util.SortOrder sortOrder31 = categoryPlot17.getColumnRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation33 = categoryPlot17.getDomainAxisLocation((int) 'a');
        org.jfree.chart.axis.AxisLocation axisLocation34 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.plot.PlotOrientation plotOrientation35 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation34, plotOrientation35);
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation33, plotOrientation35);
        xYPlot0.setOrientation(plotOrientation35);
        org.junit.Assert.assertNotNull(point2D2);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNull(plot10);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(layer25);
        org.junit.Assert.assertNull(collection26);
        org.junit.Assert.assertNull(collection27);
        org.junit.Assert.assertNull(collection28);
        org.junit.Assert.assertNull(list29);
        org.junit.Assert.assertNotNull(sortOrder31);
        org.junit.Assert.assertNotNull(axisLocation33);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertNotNull(plotOrientation35);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertNotNull(rectangleEdge37);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        xYPlot0.setInsets(rectangleInsets3, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = null;
        try {
            xYPlot0.setAxisOffset(rectangleInsets6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'offset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets3);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isAutoTickUnitSelection();
        java.awt.Shape shape2 = dateAxis0.getLeftArrow();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition3 = dateAxis0.getTickMarkPosition();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("EXPAND");
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape7 = dateAxis6.getLeftArrow();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("");
        float float12 = categoryAxis11.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        boolean boolean14 = dateAxis13.isAutoTickUnitSelection();
        org.jfree.data.Range range15 = dateAxis13.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot16 = dateAxis13.getPlot();
        dateAxis13.setLabelURL("hi!");
        dateAxis13.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis13, categoryItemRenderer22);
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis();
        dateAxis24.setTickMarksVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource27 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis24.setStandardTickUnits(tickUnitSource27);
        java.text.DateFormat dateFormat29 = null;
        dateAxis24.setDateFormatOverride(dateFormat29);
        dateAxis24.setTickMarksVisible(true);
        dateAxis24.setRange((double) (-1L), 1.0E-8d);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis24, categoryItemRenderer36);
        java.awt.Font font39 = categoryAxis11.getTickLabelFont((java.lang.Comparable) 'a');
        dateAxis6.setLabelFont(font39);
        java.util.Date date41 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis6.setMinimumDate(date41);
        java.awt.Font font43 = categoryAxis5.getTickLabelFont((java.lang.Comparable) date41);
        org.jfree.data.category.CategoryDataset categoryDataset44 = null;
        org.jfree.data.category.CategoryDataset categoryDataset45 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = new org.jfree.chart.axis.CategoryAxis("");
        float float48 = categoryAxis47.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis49 = new org.jfree.chart.axis.DateAxis();
        boolean boolean50 = dateAxis49.isAutoTickUnitSelection();
        org.jfree.data.Range range51 = dateAxis49.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot52 = dateAxis49.getPlot();
        dateAxis49.setLabelURL("hi!");
        dateAxis49.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer58 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot59 = new org.jfree.chart.plot.CategoryPlot(categoryDataset45, categoryAxis47, (org.jfree.chart.axis.ValueAxis) dateAxis49, categoryItemRenderer58);
        org.jfree.chart.axis.DateAxis dateAxis60 = new org.jfree.chart.axis.DateAxis();
        dateAxis60.setTickMarksVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource63 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis60.setStandardTickUnits(tickUnitSource63);
        java.text.DateFormat dateFormat65 = null;
        dateAxis60.setDateFormatOverride(dateFormat65);
        dateAxis60.setTickMarksVisible(true);
        dateAxis60.setRange((double) (-1L), 1.0E-8d);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer72 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot73 = new org.jfree.chart.plot.CategoryPlot(categoryDataset44, categoryAxis47, (org.jfree.chart.axis.ValueAxis) dateAxis60, categoryItemRenderer72);
        java.awt.Font font75 = categoryAxis47.getTickLabelFont((java.lang.Comparable) 'a');
        org.jfree.chart.axis.DateAxis dateAxis76 = new org.jfree.chart.axis.DateAxis();
        boolean boolean77 = dateAxis76.isAutoTickUnitSelection();
        org.jfree.data.Range range78 = dateAxis76.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot79 = dateAxis76.getPlot();
        java.util.Date date80 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis76.setMinimumDate(date80);
        java.lang.String str82 = categoryAxis47.getCategoryLabelToolTip((java.lang.Comparable) date80);
        org.jfree.chart.axis.DateAxis dateAxis83 = new org.jfree.chart.axis.DateAxis();
        dateAxis83.setTickMarksVisible(true);
        org.jfree.chart.event.AxisChangeListener axisChangeListener86 = null;
        dateAxis83.removeChangeListener(axisChangeListener86);
        java.awt.Font font88 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis83.setTickLabelFont(font88);
        java.util.TimeZone timeZone90 = dateAxis83.getTimeZone();
        org.jfree.data.time.Day day91 = new org.jfree.data.time.Day(date80, timeZone90);
        try {
            dateAxis0.setRange(date41, date80);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(dateTickMarkPosition3);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 0.0f + "'", float12 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNull(plot16);
        org.junit.Assert.assertNotNull(tickUnitSource27);
        org.junit.Assert.assertNotNull(font39);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(font43);
        org.junit.Assert.assertTrue("'" + float48 + "' != '" + 0.0f + "'", float48 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(range51);
        org.junit.Assert.assertNull(plot52);
        org.junit.Assert.assertNotNull(tickUnitSource63);
        org.junit.Assert.assertNotNull(font75);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
        org.junit.Assert.assertNotNull(range78);
        org.junit.Assert.assertNull(plot79);
        org.junit.Assert.assertNotNull(date80);
        org.junit.Assert.assertNull(str82);
        org.junit.Assert.assertNotNull(font88);
        org.junit.Assert.assertNotNull(timeZone90);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        float float2 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        categoryAxis1.configure();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        xYPlot1.configureDomainAxes();
        java.lang.String str3 = xYPlot1.getNoDataMessage();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot1.zoomRangeAxes((double) 10.0f, (double) 1L, plotRenderingInfo6, point2D7);
        int int9 = objectList0.indexOf((java.lang.Object) point2D7);
        java.awt.Paint[] paintArray10 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Paint[] paintArray11 = new java.awt.Paint[] {};
        java.awt.Stroke[] strokeArray12 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray13 = new java.awt.Stroke[] {};
        java.awt.Shape shape14 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape[] shapeArray15 = new java.awt.Shape[] { shape14 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier16 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray10, paintArray11, strokeArray12, strokeArray13, shapeArray15);
        java.awt.Stroke stroke17 = defaultDrawingSupplier16.getNextStroke();
        int int18 = objectList0.indexOf((java.lang.Object) defaultDrawingSupplier16);
        org.jfree.chart.JFreeChart jFreeChart20 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType21 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent22 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 1, jFreeChart20, chartChangeEventType21);
        java.lang.Object obj23 = chartChangeEvent22.getSource();
        int int24 = objectList0.indexOf((java.lang.Object) chartChangeEvent22);
        objectList0.clear();
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(paintArray10);
        org.junit.Assert.assertNotNull(paintArray11);
        org.junit.Assert.assertNotNull(strokeArray12);
        org.junit.Assert.assertNotNull(strokeArray13);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(shapeArray15);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(chartChangeEventType21);
        org.junit.Assert.assertTrue("'" + obj23 + "' != '" + 1 + "'", obj23.equals(1));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isAutoTickUnitSelection();
        java.awt.Shape shape2 = dateAxis0.getLeftArrow();
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        xYPlot3.setRangeCrosshairVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        xYPlot3.setInsets(rectangleInsets6, true);
        java.awt.Paint paint9 = xYPlot3.getDomainTickBandPaint();
        java.lang.String str10 = xYPlot3.getPlotType();
        boolean boolean11 = dateAxis0.hasListener((java.util.EventListener) xYPlot3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("");
        float float17 = categoryAxis16.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        boolean boolean19 = dateAxis18.isAutoTickUnitSelection();
        org.jfree.data.Range range20 = dateAxis18.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot21 = dateAxis18.getPlot();
        dateAxis18.setLabelURL("hi!");
        dateAxis18.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis16, (org.jfree.chart.axis.ValueAxis) dateAxis18, categoryItemRenderer27);
        categoryPlot28.setWeight((int) (byte) 0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener31 = null;
        categoryPlot28.addChangeListener(plotChangeListener31);
        java.awt.Color color33 = java.awt.Color.YELLOW;
        categoryPlot28.setDomainGridlinePaint((java.awt.Paint) color33);
        org.jfree.data.category.CategoryDataset categoryDataset36 = null;
        categoryPlot28.setDataset((int) (short) 10, categoryDataset36);
        float float38 = categoryPlot28.getBackgroundAlpha();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo40 = null;
        org.jfree.chart.plot.XYPlot xYPlot41 = new org.jfree.chart.plot.XYPlot();
        xYPlot41.configureDomainAxes();
        java.awt.geom.Point2D point2D43 = xYPlot41.getQuadrantOrigin();
        categoryPlot28.zoomDomainAxes(0.0d, plotRenderingInfo40, point2D43, false);
        xYPlot3.zoomDomainAxes((-1.0d), plotRenderingInfo13, point2D43, true);
        org.jfree.chart.axis.NumberAxis numberAxis50 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat51 = numberAxis50.getNumberFormatOverride();
        org.jfree.data.RangeType rangeType52 = numberAxis50.getRangeType();
        boolean boolean53 = numberAxis50.isTickMarksVisible();
        boolean boolean54 = numberAxis50.isTickLabelsVisible();
        try {
            xYPlot3.setDomainAxis((-128), (org.jfree.chart.axis.ValueAxis) numberAxis50);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "XY Plot" + "'", str10.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.0f + "'", float17 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + float38 + "' != '" + 1.0f + "'", float38 == 1.0f);
        org.junit.Assert.assertNotNull(point2D43);
        org.junit.Assert.assertNull(numberFormat51);
        org.junit.Assert.assertNotNull(rangeType52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        java.awt.Color color1 = java.awt.Color.getColor("");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setTickMarksVisible(true);
        org.jfree.chart.event.AxisChangeListener axisChangeListener3 = null;
        dateAxis0.removeChangeListener(axisChangeListener3);
        java.awt.Font font5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis0.setTickLabelFont(font5);
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isAutoTickUnitSelection();
        org.jfree.data.Range range9 = dateAxis7.getDefaultAutoRange();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        boolean boolean11 = dateAxis10.isAutoTickUnitSelection();
        org.jfree.data.Range range12 = dateAxis10.getDefaultAutoRange();
        dateAxis7.setRangeWithMargins(range12);
        dateAxis0.setRange(range12, true, false);
        java.util.TimeZone timeZone17 = dateAxis0.getTimeZone();
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(timeZone17);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        dateAxis3.setTickMarksVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource6 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis3.setStandardTickUnits(tickUnitSource6);
        java.text.DateFormat dateFormat8 = null;
        dateAxis3.setDateFormatOverride(dateFormat8);
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = dateAxis10.getLabelInsets();
        dateAxis3.setTickLabelInsets(rectangleInsets11);
        xYPlot0.setInsets(rectangleInsets11);
        xYPlot0.setRangeCrosshairValue(0.05d, false);
        java.awt.Paint paint17 = xYPlot0.getDomainGridlinePaint();
        org.junit.Assert.assertNotNull(tickUnitSource6);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        categoryPlot14.addChangeListener(plotChangeListener15);
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot();
        xYPlot19.configureDomainAxes();
        java.awt.geom.Point2D point2D21 = xYPlot19.getQuadrantOrigin();
        org.jfree.chart.plot.PlotState plotState22 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        try {
            categoryPlot14.draw(graphics2D17, rectangle2D18, point2D21, plotState22, plotRenderingInfo23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(point2D21);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        xYPlot0.setInsets(rectangleInsets3, true);
        java.awt.Paint paint6 = xYPlot0.getDomainTickBandPaint();
        java.lang.String str7 = xYPlot0.getPlotType();
        java.awt.Paint paint8 = xYPlot0.getBackgroundPaint();
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "XY Plot" + "'", str7.equals("XY Plot"));
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat2 = numberAxis1.getNumberFormatOverride();
        org.jfree.data.RangeType rangeType3 = numberAxis1.getRangeType();
        boolean boolean4 = numberAxis1.isTickMarksVisible();
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Shape shape7 = numberAxis1.getRightArrow();
        org.junit.Assert.assertNull(numberFormat2);
        org.junit.Assert.assertNotNull(rangeType3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(shape7);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureDomainAxes();
        java.awt.Paint paint2 = xYPlot0.getRangeTickBandPaint();
        org.jfree.chart.plot.PlotOrientation plotOrientation3 = xYPlot0.getOrientation();
        boolean boolean4 = xYPlot0.isDomainGridlinesVisible();
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNotNull(plotOrientation3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        categoryPlot14.setWeight((int) (byte) 0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener17 = null;
        categoryPlot14.addChangeListener(plotChangeListener17);
        java.awt.Color color19 = java.awt.Color.YELLOW;
        categoryPlot14.setDomainGridlinePaint((java.awt.Paint) color19);
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        categoryPlot14.setDataset((int) (short) 10, categoryDataset22);
        categoryPlot14.clearDomainMarkers();
        double double25 = categoryPlot14.getRangeCrosshairValue();
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot14.getRangeAxisEdge();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge26);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        xYPlot0.setInsets(rectangleInsets3, true);
        java.lang.Object obj6 = xYPlot0.clone();
        xYPlot0.setDomainZeroBaselineVisible(false);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        float float14 = categoryAxis13.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        boolean boolean16 = dateAxis15.isAutoTickUnitSelection();
        org.jfree.data.Range range17 = dateAxis15.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot18 = dateAxis15.getPlot();
        dateAxis15.setLabelURL("hi!");
        dateAxis15.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis13, (org.jfree.chart.axis.ValueAxis) dateAxis15, categoryItemRenderer24);
        categoryPlot25.setWeight((int) (byte) 0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener28 = null;
        categoryPlot25.addChangeListener(plotChangeListener28);
        java.awt.Color color30 = java.awt.Color.YELLOW;
        categoryPlot25.setDomainGridlinePaint((java.awt.Paint) color30);
        org.jfree.data.category.CategoryDataset categoryDataset33 = null;
        categoryPlot25.setDataset((int) (short) 10, categoryDataset33);
        float float35 = categoryPlot25.getBackgroundAlpha();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo37 = null;
        org.jfree.chart.plot.XYPlot xYPlot38 = new org.jfree.chart.plot.XYPlot();
        xYPlot38.configureDomainAxes();
        java.awt.geom.Point2D point2D40 = xYPlot38.getQuadrantOrigin();
        categoryPlot25.zoomDomainAxes(0.0d, plotRenderingInfo37, point2D40, false);
        org.jfree.chart.plot.PlotState plotState43 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo44 = null;
        try {
            xYPlot0.draw(graphics2D9, rectangle2D10, point2D40, plotState43, plotRenderingInfo44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(plot18);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + float35 + "' != '" + 1.0f + "'", float35 == 1.0f);
        org.junit.Assert.assertNotNull(point2D40);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isAutoTickUnitSelection();
        org.jfree.data.Range range2 = dateAxis0.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot3 = dateAxis0.getPlot();
        dateAxis0.setLabelURL("hi!");
        dateAxis0.setLowerMargin(0.0d);
        dateAxis0.setAutoTickUnitSelection(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        java.awt.Color color1 = null;
        java.awt.Color color2 = java.awt.Color.getColor("TextAnchor.HALF_ASCENT_CENTER", color1);
        org.junit.Assert.assertNull(color2);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        int int3 = java.awt.Color.HSBtoRGB((float) (-16777216), 0.0f, (float) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (byte) 0, 6, 15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        xYPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = xYPlot0.getOutlinePaint();
        org.jfree.chart.util.Layer layer4 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(layer4);
        boolean boolean6 = xYPlot0.isSubplot();
        java.awt.Paint paint7 = xYPlot0.getRangeGridlinePaint();
        xYPlot0.mapDatasetToDomainAxis(0, (int) (byte) -1);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        xYPlot0.rendererChanged(rendererChangeEvent11);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(layer4);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        xYPlot0.setInsets(rectangleInsets3, true);
        java.awt.Paint paint6 = xYPlot0.getDomainTickBandPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier7 = xYPlot0.getDrawingSupplier();
        boolean boolean8 = xYPlot0.isDomainZeroBaselineVisible();
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("");
        float float12 = categoryAxis11.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        boolean boolean14 = dateAxis13.isAutoTickUnitSelection();
        org.jfree.data.Range range15 = dateAxis13.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot16 = dateAxis13.getPlot();
        dateAxis13.setLabelURL("hi!");
        dateAxis13.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis13, categoryItemRenderer22);
        categoryPlot23.setWeight((int) (byte) 0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener26 = null;
        categoryPlot23.addChangeListener(plotChangeListener26);
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener29 = null;
        xYPlot28.addChangeListener(plotChangeListener29);
        java.awt.Paint paint31 = xYPlot28.getOutlinePaint();
        java.awt.Stroke stroke32 = xYPlot28.getRangeZeroBaselineStroke();
        categoryPlot23.setDomainGridlineStroke(stroke32);
        xYPlot0.setDomainZeroBaselineStroke(stroke32);
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis();
        dateAxis35.setTickMarksVisible(true);
        java.lang.Object obj38 = dateAxis35.clone();
        boolean boolean39 = xYPlot0.equals((java.lang.Object) dateAxis35);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(drawingSupplier7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 0.0f + "'", float12 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNull(plot16);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(obj38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        xYPlot16.setRangeCrosshairVisible(true);
        boolean boolean19 = xYPlot16.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        xYPlot20.configureDomainAxes();
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection23 = xYPlot20.getDomainMarkers(layer22);
        java.util.Collection collection24 = xYPlot16.getRangeMarkers(layer22);
        java.util.Collection collection25 = categoryPlot14.getRangeMarkers((int) (byte) 1, layer22);
        java.util.List list26 = categoryPlot14.getCategories();
        java.awt.Graphics2D graphics2D27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        boolean boolean31 = categoryPlot14.render(graphics2D27, rectangle2D28, 0, plotRenderingInfo30);
        int int32 = categoryPlot14.getWeight();
        java.awt.Paint paint33 = categoryPlot14.getRangeCrosshairPaint();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent34 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) paint33);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertNull(collection23);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertNull(list26);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(paint33);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_VERTICAL_TICK_LABELS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureDomainAxes();
        xYPlot0.zoom((double) 10);
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean6 = xYPlot0.removeDomainMarker(marker4, layer5);
        xYPlot0.clearRangeMarkers();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = xYPlot0.getInsets();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        xYPlot0.zoomRangeAxes((double) 3, plotRenderingInfo10, point2D11, false);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        xYPlot16.setRangeCrosshairVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        xYPlot16.setInsets(rectangleInsets19, true);
        java.awt.Paint paint22 = xYPlot16.getDomainTickBandPaint();
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis("");
        float float28 = categoryAxis27.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis();
        boolean boolean30 = dateAxis29.isAutoTickUnitSelection();
        org.jfree.data.Range range31 = dateAxis29.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot32 = dateAxis29.getPlot();
        dateAxis29.setLabelURL("hi!");
        dateAxis29.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset25, categoryAxis27, (org.jfree.chart.axis.ValueAxis) dateAxis29, categoryItemRenderer38);
        org.jfree.chart.plot.Marker marker40 = null;
        boolean boolean41 = categoryPlot39.removeDomainMarker(marker40);
        java.util.List list42 = categoryPlot39.getAnnotations();
        xYPlot16.drawDomainTickBands(graphics2D23, rectangle2D24, list42);
        xYPlot0.drawDomainTickBands(graphics2D14, rectangle2D15, list42);
        org.junit.Assert.assertNotNull(layer5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNull(paint22);
        org.junit.Assert.assertTrue("'" + float28 + "' != '" + 0.0f + "'", float28 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertNull(plot32);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(list42);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        xYPlot16.setRangeCrosshairVisible(true);
        boolean boolean19 = xYPlot16.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        xYPlot20.configureDomainAxes();
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection23 = xYPlot20.getDomainMarkers(layer22);
        java.util.Collection collection24 = xYPlot16.getRangeMarkers(layer22);
        java.util.Collection collection25 = categoryPlot14.getRangeMarkers((int) (byte) 1, layer22);
        java.util.List list26 = categoryPlot14.getCategories();
        java.awt.Graphics2D graphics2D27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        boolean boolean31 = categoryPlot14.render(graphics2D27, rectangle2D28, 0, plotRenderingInfo30);
        int int32 = categoryPlot14.getWeight();
        java.awt.Paint paint33 = categoryPlot14.getRangeCrosshairPaint();
        org.jfree.chart.axis.AxisSpace axisSpace34 = null;
        categoryPlot14.setFixedRangeAxisSpace(axisSpace34);
        java.awt.Paint paint36 = categoryPlot14.getRangeGridlinePaint();
        categoryPlot14.clearRangeMarkers(0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertNull(collection23);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertNull(list26);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(paint36);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        int int2 = categoryAxis1.getMaximumCategoryLabelLines();
        java.awt.Font font4 = categoryAxis1.getTickLabelFont((java.lang.Comparable) 1);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor5 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        boolean boolean7 = categoryAnchor5.equals((java.lang.Object) stroke6);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("");
        float float15 = categoryAxis14.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        boolean boolean17 = dateAxis16.isAutoTickUnitSelection();
        org.jfree.data.Range range18 = dateAxis16.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot19 = dateAxis16.getPlot();
        dateAxis16.setLabelURL("hi!");
        dateAxis16.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis16, categoryItemRenderer25);
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        dateAxis27.setTickMarksVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource30 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis27.setStandardTickUnits(tickUnitSource30);
        java.text.DateFormat dateFormat32 = null;
        dateAxis27.setDateFormatOverride(dateFormat32);
        dateAxis27.setTickMarksVisible(true);
        dateAxis27.setRange((double) (-1L), 1.0E-8d);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer39);
        java.util.List list41 = categoryPlot40.getCategories();
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = categoryPlot40.getRangeAxisEdge(3);
        try {
            double double44 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor5, (-128), 255, rectangle2D10, rectangleEdge43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(categoryAnchor5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.0f + "'", float15 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNull(plot19);
        org.junit.Assert.assertNotNull(tickUnitSource30);
        org.junit.Assert.assertNull(list41);
        org.junit.Assert.assertNotNull(rectangleEdge43);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isAutoTickUnitSelection();
        org.jfree.data.Range range2 = dateAxis0.getDefaultAutoRange();
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        xYPlot3.setRangeCrosshairVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        xYPlot3.setInsets(rectangleInsets6, true);
        dateAxis0.setLabelInsets(rectangleInsets6);
        double double10 = rectangleInsets6.getBottom();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) true);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType2 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        java.lang.String str3 = lengthAdjustmentType2.toString();
        categoryMarker1.setLabelOffsetType(lengthAdjustmentType2);
        java.lang.Comparable comparable5 = categoryMarker1.getKey();
        org.junit.Assert.assertNotNull(lengthAdjustmentType2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "EXPAND" + "'", str3.equals("EXPAND"));
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + true + "'", comparable5.equals(true));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureDomainAxes();
        xYPlot0.zoom((double) 10);
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean6 = xYPlot0.removeDomainMarker(marker4, layer5);
        xYPlot0.clearRangeMarkers();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = xYPlot0.getInsets();
        java.util.List list9 = xYPlot0.getAnnotations();
        org.junit.Assert.assertNotNull(layer5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(list9);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setTickMarksVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource3 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis0.setStandardTickUnits(tickUnitSource3);
        java.text.DateFormat dateFormat5 = null;
        dateAxis0.setDateFormatOverride(dateFormat5);
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = dateAxis7.getLabelInsets();
        dateAxis0.setTickLabelInsets(rectangleInsets8);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        xYPlot11.configureDomainAxes();
        xYPlot11.zoom((double) 10);
        org.jfree.chart.plot.Marker marker15 = null;
        org.jfree.chart.util.Layer layer16 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean17 = xYPlot11.removeDomainMarker(marker15, layer16);
        double double18 = xYPlot11.getRangeCrosshairValue();
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("");
        float float24 = categoryAxis23.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        boolean boolean26 = dateAxis25.isAutoTickUnitSelection();
        org.jfree.data.Range range27 = dateAxis25.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot28 = dateAxis25.getPlot();
        dateAxis25.setLabelURL("hi!");
        dateAxis25.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis23, (org.jfree.chart.axis.ValueAxis) dateAxis25, categoryItemRenderer34);
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis();
        dateAxis36.setTickMarksVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource39 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis36.setStandardTickUnits(tickUnitSource39);
        java.text.DateFormat dateFormat41 = null;
        dateAxis36.setDateFormatOverride(dateFormat41);
        dateAxis36.setTickMarksVisible(true);
        dateAxis36.setRange((double) (-1L), 1.0E-8d);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer48 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot49 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis23, (org.jfree.chart.axis.ValueAxis) dateAxis36, categoryItemRenderer48);
        java.util.List list50 = categoryPlot49.getCategories();
        org.jfree.chart.util.RectangleEdge rectangleEdge52 = categoryPlot49.getRangeAxisEdge(3);
        org.jfree.chart.axis.AxisSpace axisSpace53 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace54 = dateAxis0.reserveSpace(graphics2D10, (org.jfree.chart.plot.Plot) xYPlot11, rectangle2D19, rectangleEdge52, axisSpace53);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(tickUnitSource3);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(layer16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 0.0f + "'", float24 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertNull(plot28);
        org.junit.Assert.assertNotNull(tickUnitSource39);
        org.junit.Assert.assertNull(list50);
        org.junit.Assert.assertNotNull(rectangleEdge52);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getLeftArrow();
        java.awt.Paint paint2 = dateAxis0.getAxisLinePaint();
        dateAxis0.setAutoRangeMinimumSize(3.0d);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        float float10 = categoryAxis9.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isAutoTickUnitSelection();
        org.jfree.data.Range range13 = dateAxis11.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot14 = dateAxis11.getPlot();
        dateAxis11.setLabelURL("hi!");
        dateAxis11.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis11, categoryItemRenderer20);
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot();
        xYPlot23.setRangeCrosshairVisible(true);
        boolean boolean26 = xYPlot23.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot();
        xYPlot27.configureDomainAxes();
        org.jfree.chart.util.Layer layer29 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection30 = xYPlot27.getDomainMarkers(layer29);
        java.util.Collection collection31 = xYPlot23.getRangeMarkers(layer29);
        java.util.Collection collection32 = categoryPlot21.getRangeMarkers((int) (byte) 1, layer29);
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = categoryPlot21.getRangeAxisEdge((int) ' ');
        try {
            double double35 = dateAxis0.java2DToValue((double) (byte) 0, rectangle2D6, rectangleEdge34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNull(plot14);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(layer29);
        org.junit.Assert.assertNull(collection30);
        org.junit.Assert.assertNull(collection31);
        org.junit.Assert.assertNull(collection32);
        org.junit.Assert.assertNotNull(rectangleEdge34);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("SortOrder.ASCENDING");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        xYPlot0.setInsets(rectangleInsets3, true);
        java.awt.Paint paint6 = xYPlot0.getDomainTickBandPaint();
        java.lang.String str7 = xYPlot0.getPlotType();
        boolean boolean8 = xYPlot0.isRangeZeroBaselineVisible();
        xYPlot0.mapDatasetToDomainAxis(0, 0);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "XY Plot" + "'", str7.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        xYPlot0.setInsets(rectangleInsets3, true);
        java.awt.Paint paint6 = xYPlot0.getDomainTickBandPaint();
        java.lang.String str7 = xYPlot0.getPlotType();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape9 = dateAxis8.getLeftArrow();
        java.awt.Paint paint10 = dateAxis8.getAxisLinePaint();
        int int11 = xYPlot0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis8);
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("");
        float float18 = categoryAxis17.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        boolean boolean20 = dateAxis19.isAutoTickUnitSelection();
        org.jfree.data.Range range21 = dateAxis19.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot22 = dateAxis19.getPlot();
        dateAxis19.setLabelURL("hi!");
        dateAxis19.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis17, (org.jfree.chart.axis.ValueAxis) dateAxis19, categoryItemRenderer28);
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis();
        dateAxis30.setTickMarksVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource33 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis30.setStandardTickUnits(tickUnitSource33);
        java.text.DateFormat dateFormat35 = null;
        dateAxis30.setDateFormatOverride(dateFormat35);
        dateAxis30.setTickMarksVisible(true);
        dateAxis30.setRange((double) (-1L), 1.0E-8d);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer42 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis17, (org.jfree.chart.axis.ValueAxis) dateAxis30, categoryItemRenderer42);
        java.util.List list44 = categoryPlot43.getCategories();
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = categoryPlot43.getRangeAxisEdge(3);
        try {
            double double47 = dateAxis8.java2DToValue((double) 3, rectangle2D13, rectangleEdge46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "XY Plot" + "'", str7.equals("XY Plot"));
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.0f + "'", float18 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(tickUnitSource33);
        org.junit.Assert.assertNull(list44);
        org.junit.Assert.assertNotNull(rectangleEdge46);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        java.lang.Class class0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("EXPAND");
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape4 = dateAxis3.getLeftArrow();
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis("");
        float float9 = categoryAxis8.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        boolean boolean11 = dateAxis10.isAutoTickUnitSelection();
        org.jfree.data.Range range12 = dateAxis10.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot13 = dateAxis10.getPlot();
        dateAxis10.setLabelURL("hi!");
        dateAxis10.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis10, categoryItemRenderer19);
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        dateAxis21.setTickMarksVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource24 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis21.setStandardTickUnits(tickUnitSource24);
        java.text.DateFormat dateFormat26 = null;
        dateAxis21.setDateFormatOverride(dateFormat26);
        dateAxis21.setTickMarksVisible(true);
        dateAxis21.setRange((double) (-1L), 1.0E-8d);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis21, categoryItemRenderer33);
        java.awt.Font font36 = categoryAxis8.getTickLabelFont((java.lang.Comparable) 'a');
        dateAxis3.setLabelFont(font36);
        java.util.Date date38 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis3.setMinimumDate(date38);
        java.awt.Font font40 = categoryAxis2.getTickLabelFont((java.lang.Comparable) date38);
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis();
        dateAxis41.setTickMarksVisible(true);
        org.jfree.chart.event.AxisChangeListener axisChangeListener44 = null;
        dateAxis41.removeChangeListener(axisChangeListener44);
        java.awt.Font font46 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis41.setTickLabelFont(font46);
        java.util.TimeZone timeZone48 = dateAxis41.getTimeZone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date38, timeZone48);
        org.jfree.chart.axis.TickUnitSource tickUnitSource50 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone48);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.0f + "'", float9 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNull(plot13);
        org.junit.Assert.assertNotNull(tickUnitSource24);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(font40);
        org.junit.Assert.assertNotNull(font46);
        org.junit.Assert.assertNotNull(timeZone48);
        org.junit.Assert.assertNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(tickUnitSource50);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setTickMarksVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource3 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis0.setStandardTickUnits(tickUnitSource3);
        boolean boolean5 = dateAxis0.isAutoRange();
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        float float14 = categoryAxis13.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        boolean boolean16 = dateAxis15.isAutoTickUnitSelection();
        org.jfree.data.Range range17 = dateAxis15.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot18 = dateAxis15.getPlot();
        dateAxis15.setLabelURL("hi!");
        dateAxis15.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis13, (org.jfree.chart.axis.ValueAxis) dateAxis15, categoryItemRenderer24);
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        dateAxis26.setTickMarksVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource29 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis26.setStandardTickUnits(tickUnitSource29);
        java.text.DateFormat dateFormat31 = null;
        dateAxis26.setDateFormatOverride(dateFormat31);
        dateAxis26.setTickMarksVisible(true);
        dateAxis26.setRange((double) (-1L), 1.0E-8d);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis13, (org.jfree.chart.axis.ValueAxis) dateAxis26, categoryItemRenderer38);
        java.util.List list40 = categoryPlot39.getCategories();
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = categoryPlot39.getRangeAxisEdge(3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo43 = null;
        try {
            org.jfree.chart.axis.AxisState axisState44 = dateAxis0.draw(graphics2D6, 0.0d, rectangle2D8, rectangle2D9, rectangleEdge42, plotRenderingInfo43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(tickUnitSource3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(plot18);
        org.junit.Assert.assertNotNull(tickUnitSource29);
        org.junit.Assert.assertNull(list40);
        org.junit.Assert.assertNotNull(rectangleEdge42);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setNegativeArrowVisible(false);
        boolean boolean3 = numberAxis0.isInverted();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        float float4 = categoryAxis3.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        boolean boolean6 = dateAxis5.isAutoTickUnitSelection();
        org.jfree.data.Range range7 = dateAxis5.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot8 = dateAxis5.getPlot();
        dateAxis5.setLabelURL("hi!");
        dateAxis5.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer14);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        dateAxis16.setTickMarksVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource19 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis16.setStandardTickUnits(tickUnitSource19);
        java.text.DateFormat dateFormat21 = null;
        dateAxis16.setDateFormatOverride(dateFormat21);
        dateAxis16.setTickMarksVisible(true);
        dateAxis16.setRange((double) (-1L), 1.0E-8d);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis16, categoryItemRenderer28);
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = categoryPlot29.getRangeAxisEdge();
        categoryPlot29.setRangeCrosshairValue(0.2d, false);
        org.jfree.chart.axis.ValueAxis valueAxis35 = categoryPlot29.getRangeAxisForDataset((int) '#');
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(tickUnitSource19);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertNotNull(valueAxis35);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        xYPlot16.setRangeCrosshairVisible(true);
        boolean boolean19 = xYPlot16.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        xYPlot20.configureDomainAxes();
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection23 = xYPlot20.getDomainMarkers(layer22);
        java.util.Collection collection24 = xYPlot16.getRangeMarkers(layer22);
        java.util.Collection collection25 = categoryPlot14.getRangeMarkers((int) (byte) 1, layer22);
        java.util.List list26 = categoryPlot14.getCategories();
        java.awt.Graphics2D graphics2D27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        boolean boolean31 = categoryPlot14.render(graphics2D27, rectangle2D28, 0, plotRenderingInfo30);
        int int32 = categoryPlot14.getWeight();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = categoryPlot14.getRenderer();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertNull(collection23);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertNull(list26);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNull(categoryItemRenderer33);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(11, 0, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) '#');
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        java.awt.Color color2 = java.awt.Color.getColor("EXPAND", 1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        dateAxis3.setTickMarksVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource6 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis3.setStandardTickUnits(tickUnitSource6);
        java.text.DateFormat dateFormat8 = null;
        dateAxis3.setDateFormatOverride(dateFormat8);
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = dateAxis10.getLabelInsets();
        dateAxis3.setTickLabelInsets(rectangleInsets11);
        xYPlot0.setInsets(rectangleInsets11);
        xYPlot0.setRangeCrosshairValue(0.05d, false);
        org.jfree.chart.axis.ValueAxis valueAxis18 = xYPlot0.getRangeAxis(100);
        org.junit.Assert.assertNotNull(tickUnitSource6);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNull(valueAxis18);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        float float4 = categoryAxis3.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        boolean boolean6 = dateAxis5.isAutoTickUnitSelection();
        org.jfree.data.Range range7 = dateAxis5.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot8 = dateAxis5.getPlot();
        dateAxis5.setLabelURL("hi!");
        dateAxis5.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer14);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        dateAxis16.setTickMarksVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource19 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis16.setStandardTickUnits(tickUnitSource19);
        java.text.DateFormat dateFormat21 = null;
        dateAxis16.setDateFormatOverride(dateFormat21);
        dateAxis16.setTickMarksVisible(true);
        dateAxis16.setRange((double) (-1L), 1.0E-8d);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis16, categoryItemRenderer28);
        java.util.List list30 = categoryPlot29.getCategories();
        categoryPlot29.clearRangeMarkers();
        java.awt.Paint[] paintArray32 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Paint[] paintArray33 = new java.awt.Paint[] {};
        java.awt.Stroke[] strokeArray34 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray35 = new java.awt.Stroke[] {};
        java.awt.Shape shape36 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape[] shapeArray37 = new java.awt.Shape[] { shape36 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier38 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray32, paintArray33, strokeArray34, strokeArray35, shapeArray37);
        java.awt.Stroke stroke39 = defaultDrawingSupplier38.getNextStroke();
        categoryPlot29.setRangeCrosshairStroke(stroke39);
        categoryPlot29.setAnchorValue(0.0d);
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = null;
        categoryPlot29.setDomainAxis((int) (byte) 10, categoryAxis44, false);
        java.awt.Stroke stroke47 = categoryPlot29.getDomainGridlineStroke();
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(tickUnitSource19);
        org.junit.Assert.assertNull(list30);
        org.junit.Assert.assertNotNull(paintArray32);
        org.junit.Assert.assertNotNull(paintArray33);
        org.junit.Assert.assertNotNull(strokeArray34);
        org.junit.Assert.assertNotNull(strokeArray35);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(shapeArray37);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(stroke47);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        org.jfree.chart.util.SortOrder sortOrder15 = categoryPlot14.getColumnRenderingOrder();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation16 = null;
        try {
            categoryPlot14.addAnnotation(categoryAnnotation16, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(sortOrder15);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        float float4 = categoryAxis3.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        boolean boolean6 = dateAxis5.isAutoTickUnitSelection();
        org.jfree.data.Range range7 = dateAxis5.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot8 = dateAxis5.getPlot();
        dateAxis5.setLabelURL("hi!");
        dateAxis5.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer14);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        dateAxis16.setTickMarksVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource19 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis16.setStandardTickUnits(tickUnitSource19);
        java.text.DateFormat dateFormat21 = null;
        dateAxis16.setDateFormatOverride(dateFormat21);
        dateAxis16.setTickMarksVisible(true);
        dateAxis16.setRange((double) (-1L), 1.0E-8d);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis16, categoryItemRenderer28);
        java.awt.Paint paint30 = categoryAxis3.getTickMarkPaint();
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        org.jfree.data.category.CategoryDataset categoryDataset34 = null;
        org.jfree.data.category.CategoryDataset categoryDataset35 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = new org.jfree.chart.axis.CategoryAxis("");
        float float38 = categoryAxis37.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis();
        boolean boolean40 = dateAxis39.isAutoTickUnitSelection();
        org.jfree.data.Range range41 = dateAxis39.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot42 = dateAxis39.getPlot();
        dateAxis39.setLabelURL("hi!");
        dateAxis39.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer48 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot49 = new org.jfree.chart.plot.CategoryPlot(categoryDataset35, categoryAxis37, (org.jfree.chart.axis.ValueAxis) dateAxis39, categoryItemRenderer48);
        org.jfree.chart.axis.DateAxis dateAxis50 = new org.jfree.chart.axis.DateAxis();
        dateAxis50.setTickMarksVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource53 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis50.setStandardTickUnits(tickUnitSource53);
        java.text.DateFormat dateFormat55 = null;
        dateAxis50.setDateFormatOverride(dateFormat55);
        dateAxis50.setTickMarksVisible(true);
        dateAxis50.setRange((double) (-1L), 1.0E-8d);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer62 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot63 = new org.jfree.chart.plot.CategoryPlot(categoryDataset34, categoryAxis37, (org.jfree.chart.axis.ValueAxis) dateAxis50, categoryItemRenderer62);
        org.jfree.chart.util.RectangleEdge rectangleEdge64 = categoryPlot63.getRangeAxisEdge();
        try {
            double double65 = categoryAxis3.getCategoryStart(255, (int) (short) -1, rectangle2D33, rectangleEdge64);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(tickUnitSource19);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + float38 + "' != '" + 0.0f + "'", float38 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNull(plot42);
        org.junit.Assert.assertNotNull(tickUnitSource53);
        org.junit.Assert.assertNotNull(rectangleEdge64);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis1.configure();
        double double3 = numberAxis1.getFixedAutoRange();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis1.setMarkerBand(markerAxisBand4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        float float10 = categoryAxis9.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isAutoTickUnitSelection();
        org.jfree.data.Range range13 = dateAxis11.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot14 = dateAxis11.getPlot();
        dateAxis11.setLabelURL("hi!");
        dateAxis11.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis11, categoryItemRenderer20);
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        dateAxis22.setTickMarksVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource25 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis22.setStandardTickUnits(tickUnitSource25);
        java.text.DateFormat dateFormat27 = null;
        dateAxis22.setDateFormatOverride(dateFormat27);
        dateAxis22.setTickMarksVisible(true);
        dateAxis22.setRange((double) (-1L), 1.0E-8d);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis22, categoryItemRenderer34);
        java.util.List list36 = categoryPlot35.getCategories();
        categoryPlot35.clearRangeMarkers();
        java.awt.Paint[] paintArray38 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Paint[] paintArray39 = new java.awt.Paint[] {};
        java.awt.Stroke[] strokeArray40 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray41 = new java.awt.Stroke[] {};
        java.awt.Shape shape42 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape[] shapeArray43 = new java.awt.Shape[] { shape42 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier44 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray38, paintArray39, strokeArray40, strokeArray41, shapeArray43);
        java.awt.Stroke stroke45 = defaultDrawingSupplier44.getNextStroke();
        categoryPlot35.setRangeCrosshairStroke(stroke45);
        numberAxis1.setAxisLineStroke(stroke45);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNull(plot14);
        org.junit.Assert.assertNotNull(tickUnitSource25);
        org.junit.Assert.assertNull(list36);
        org.junit.Assert.assertNotNull(paintArray38);
        org.junit.Assert.assertNotNull(paintArray39);
        org.junit.Assert.assertNotNull(strokeArray40);
        org.junit.Assert.assertNotNull(strokeArray41);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertNotNull(shapeArray43);
        org.junit.Assert.assertNotNull(stroke45);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        xYPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        int int6 = xYPlot0.getRangeAxisIndex(valueAxis5);
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        float float10 = categoryAxis9.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isAutoTickUnitSelection();
        org.jfree.data.Range range13 = dateAxis11.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot14 = dateAxis11.getPlot();
        dateAxis11.setLabelURL("hi!");
        dateAxis11.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis11, categoryItemRenderer20);
        categoryPlot21.setWeight((int) (byte) 0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener24 = null;
        categoryPlot21.addChangeListener(plotChangeListener24);
        org.jfree.chart.axis.AxisLocation axisLocation27 = null;
        categoryPlot21.setRangeAxisLocation((int) (short) 1, axisLocation27);
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot();
        xYPlot29.setRangeCrosshairVisible(true);
        boolean boolean32 = xYPlot29.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot();
        xYPlot33.configureDomainAxes();
        org.jfree.chart.util.Layer layer35 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection36 = xYPlot33.getDomainMarkers(layer35);
        java.util.Collection collection37 = xYPlot29.getRangeMarkers(layer35);
        java.awt.Stroke stroke38 = xYPlot29.getDomainZeroBaselineStroke();
        categoryPlot21.setRangeGridlineStroke(stroke38);
        xYPlot0.setDomainCrosshairStroke(stroke38);
        xYPlot0.setForegroundAlpha((float) (short) 10);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNull(plot14);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(layer35);
        org.junit.Assert.assertNull(collection36);
        org.junit.Assert.assertNull(collection37);
        org.junit.Assert.assertNotNull(stroke38);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureDomainAxes();
        org.jfree.chart.util.Layer layer2 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection3 = xYPlot0.getDomainMarkers(layer2);
        boolean boolean4 = xYPlot0.isDomainGridlinesVisible();
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.setRangeCrosshairVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        xYPlot5.setInsets(rectangleInsets8, true);
        java.awt.Paint paint11 = xYPlot5.getDomainTickBandPaint();
        java.lang.String str12 = xYPlot5.getPlotType();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape14 = dateAxis13.getLeftArrow();
        java.awt.Paint paint15 = dateAxis13.getAxisLinePaint();
        int int16 = xYPlot5.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis13);
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot();
        xYPlot17.setRangeCrosshairVisible(true);
        boolean boolean20 = xYPlot17.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot();
        xYPlot21.configureDomainAxes();
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection24 = xYPlot21.getDomainMarkers(layer23);
        java.util.Collection collection25 = xYPlot17.getRangeMarkers(layer23);
        java.awt.Stroke stroke26 = xYPlot17.getDomainZeroBaselineStroke();
        dateAxis13.setTickMarkStroke(stroke26);
        xYPlot0.setOutlineStroke(stroke26);
        org.jfree.chart.axis.AxisSpace axisSpace29 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace29);
        java.awt.Stroke stroke31 = xYPlot0.getDomainGridlineStroke();
        java.awt.Paint paint33 = xYPlot0.getQuadrantPaint(3);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray34 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot0.setRenderers(xYItemRendererArray34);
        org.junit.Assert.assertNotNull(layer2);
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "XY Plot" + "'", str12.equals("XY Plot"));
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNull(paint33);
        org.junit.Assert.assertNotNull(xYItemRendererArray34);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis1.configure();
        java.lang.Object obj3 = numberAxis1.clone();
        numberAxis1.setAutoRangeIncludesZero(true);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis7.configure();
        java.lang.Object obj9 = numberAxis7.clone();
        java.awt.Shape shape10 = numberAxis7.getDownArrow();
        numberAxis1.setRightArrow(shape10);
        try {
            numberAxis1.setRangeWithMargins(18.0d, (-1.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (18.0) <= upper (-1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(shape10);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        xYPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        int int6 = xYPlot0.getRangeAxisIndex(valueAxis5);
        xYPlot0.setDomainZeroBaselineVisible(false);
        org.jfree.chart.axis.AxisSpace axisSpace9 = xYPlot0.getFixedRangeAxisSpace();
        float float10 = xYPlot0.getForegroundAlpha();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNull(axisSpace9);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 1.0f + "'", float10 == 1.0f);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isAutoTickUnitSelection();
        org.jfree.data.Range range2 = dateAxis0.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot3 = dateAxis0.getPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = dateAxis0.getTickLabelInsets();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D8 = rectangleInsets4.createOutsetRectangle(rectangle2D5, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat2 = numberAxis1.getNumberFormatOverride();
        org.jfree.data.RangeType rangeType3 = numberAxis1.getRangeType();
        boolean boolean4 = numberAxis1.isAxisLineVisible();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        dateAxis10.setTickMarksVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource13 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis10.setStandardTickUnits(tickUnitSource13);
        java.text.DateFormat dateFormat15 = null;
        dateAxis10.setDateFormatOverride(dateFormat15);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = dateAxis17.getLabelInsets();
        dateAxis10.setTickLabelInsets(rectangleInsets18);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis10, categoryItemRenderer20);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray22 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot21.setRangeAxes(valueAxisArray22);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = categoryPlot21.getDomainAxisEdge();
        try {
            double double25 = numberAxis1.java2DToValue((double) 10, rectangle2D6, rectangleEdge24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(numberFormat2);
        org.junit.Assert.assertNotNull(rangeType3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(tickUnitSource13);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(valueAxisArray22);
        org.junit.Assert.assertNotNull(rectangleEdge24);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent15 = null;
        categoryPlot14.notifyListeners(plotChangeEvent15);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        categoryPlot14.setRenderer(categoryItemRenderer17, false);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        boolean boolean3 = xYPlot0.isRangeCrosshairLockedOnData();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.util.List list6 = null;
        xYPlot0.drawDomainTickBands(graphics2D4, rectangle2D5, list6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        xYPlot0.drawAnnotations(graphics2D8, rectangle2D9, plotRenderingInfo10);
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) true);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType15 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        java.lang.String str16 = lengthAdjustmentType15.toString();
        categoryMarker14.setLabelOffsetType(lengthAdjustmentType15);
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryMarker14.setOutlineStroke(stroke18);
        categoryMarker14.setAlpha(0.0f);
        org.jfree.chart.util.Layer layer22 = null;
        try {
            xYPlot0.addDomainMarker((-1), (org.jfree.chart.plot.Marker) categoryMarker14, layer22, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(lengthAdjustmentType15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "EXPAND" + "'", str16.equals("EXPAND"));
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        xYPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat8 = numberAxis7.getNumberFormatOverride();
        org.jfree.data.RangeType rangeType9 = numberAxis7.getRangeType();
        boolean boolean10 = numberAxis7.isTickMarksVisible();
        double double11 = numberAxis7.getUpperMargin();
        boolean boolean12 = numberAxis7.isTickLabelsVisible();
        numberAxis7.setVerticalTickLabels(false);
        java.lang.Object obj15 = null;
        boolean boolean16 = numberAxis7.equals(obj15);
        try {
            xYPlot0.setDomainAxis((int) (byte) -1, (org.jfree.chart.axis.ValueAxis) numberAxis7, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(numberFormat8);
        org.junit.Assert.assertNotNull(rangeType9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) true);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType2 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        java.lang.String str3 = lengthAdjustmentType2.toString();
        categoryMarker1.setLabelOffsetType(lengthAdjustmentType2);
        java.awt.Font font5 = categoryMarker1.getLabelFont();
        categoryMarker1.setLabel("");
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        xYPlot8.setRangeCrosshairVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        xYPlot8.setInsets(rectangleInsets11, true);
        java.awt.Paint paint14 = xYPlot8.getDomainTickBandPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier15 = xYPlot8.getDrawingSupplier();
        boolean boolean16 = xYPlot8.isDomainZeroBaselineVisible();
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis("");
        float float20 = categoryAxis19.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        boolean boolean22 = dateAxis21.isAutoTickUnitSelection();
        org.jfree.data.Range range23 = dateAxis21.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot24 = dateAxis21.getPlot();
        dateAxis21.setLabelURL("hi!");
        dateAxis21.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis21, categoryItemRenderer30);
        categoryPlot31.setWeight((int) (byte) 0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener34 = null;
        categoryPlot31.addChangeListener(plotChangeListener34);
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener37 = null;
        xYPlot36.addChangeListener(plotChangeListener37);
        java.awt.Paint paint39 = xYPlot36.getOutlinePaint();
        java.awt.Stroke stroke40 = xYPlot36.getRangeZeroBaselineStroke();
        categoryPlot31.setDomainGridlineStroke(stroke40);
        xYPlot8.setDomainZeroBaselineStroke(stroke40);
        categoryMarker1.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot8);
        org.junit.Assert.assertNotNull(lengthAdjustmentType2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "EXPAND" + "'", str3.equals("EXPAND"));
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNull(paint14);
        org.junit.Assert.assertNotNull(drawingSupplier15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 0.0f + "'", float20 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertNull(plot24);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(stroke40);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        xYPlot16.setRangeCrosshairVisible(true);
        boolean boolean19 = xYPlot16.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        xYPlot20.configureDomainAxes();
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection23 = xYPlot20.getDomainMarkers(layer22);
        java.util.Collection collection24 = xYPlot16.getRangeMarkers(layer22);
        java.util.Collection collection25 = categoryPlot14.getRangeMarkers((int) (byte) 1, layer22);
        java.util.List list26 = categoryPlot14.getCategories();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = categoryPlot14.getAxisOffset();
        double double29 = rectangleInsets27.calculateTopInset(10.0d);
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D33 = rectangleInsets27.createOutsetRectangle(rectangle2D30, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertNull(collection23);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertNull(list26);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 4.0d + "'", double29 == 4.0d);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = dateAxis0.getLabelInsets();
        dateAxis0.setFixedAutoRange((double) (byte) 10);
        java.awt.Color color4 = java.awt.Color.red;
        java.awt.image.ColorModel colorModel5 = null;
        java.awt.Rectangle rectangle6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.geom.AffineTransform affineTransform8 = null;
        java.awt.RenderingHints renderingHints9 = null;
        java.awt.PaintContext paintContext10 = color4.createContext(colorModel5, rectangle6, rectangle2D7, affineTransform8, renderingHints9);
        java.awt.Color color11 = color4.darker();
        java.awt.color.ColorSpace colorSpace12 = color4.getColorSpace();
        dateAxis0.setAxisLinePaint((java.awt.Paint) color4);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paintContext10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(colorSpace12);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        xYPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = xYPlot0.getOutlinePaint();
        org.jfree.chart.axis.AxisSpace axisSpace4 = xYPlot0.getFixedRangeAxisSpace();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(axisSpace4);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        categoryPlot14.setWeight((int) (byte) 0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener17 = null;
        categoryPlot14.addChangeListener(plotChangeListener17);
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        try {
            categoryPlot14.drawBackground(graphics2D19, rectangle2D20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat6 = numberAxis5.getNumberFormatOverride();
        org.jfree.data.RangeType rangeType7 = numberAxis5.getRangeType();
        boolean boolean8 = numberAxis5.isTickMarksVisible();
        numberAxis5.setTickLabelsVisible(false);
        boolean boolean11 = categoryAxis2.equals((java.lang.Object) false);
        double double12 = categoryAxis2.getCategoryMargin();
        double double13 = categoryAxis2.getCategoryMargin();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat16 = numberAxis15.getNumberFormatOverride();
        org.jfree.data.RangeType rangeType17 = numberAxis15.getRangeType();
        boolean boolean18 = numberAxis15.isAxisLineVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer19);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNull(numberFormat6);
        org.junit.Assert.assertNotNull(rangeType7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.2d + "'", double12 == 0.2d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.2d + "'", double13 == 0.2d);
        org.junit.Assert.assertNull(numberFormat16);
        org.junit.Assert.assertNotNull(rangeType17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isAutoTickUnitSelection();
        java.awt.Shape shape2 = dateAxis0.getLeftArrow();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition3 = dateAxis0.getTickMarkPosition();
        try {
            dateAxis0.zoomRange(100.0d, (double) 10.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (100.0) <= upper (10.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(dateTickMarkPosition3);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setTickMarksVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource3 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis0.setStandardTickUnits(tickUnitSource3);
        boolean boolean5 = dateAxis0.isAutoRange();
        double double6 = dateAxis0.getAutoRangeMinimumSize();
        org.junit.Assert.assertNotNull(tickUnitSource3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.0d + "'", double6 == 2.0d);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        java.awt.Color color0 = java.awt.Color.green;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        java.awt.Paint paint2 = null;
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        xYPlot3.setRangeCrosshairVisible(true);
        xYPlot3.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        int int9 = xYPlot3.getRangeAxisIndex(valueAxis8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("");
        float float13 = categoryAxis12.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        boolean boolean15 = dateAxis14.isAutoTickUnitSelection();
        org.jfree.data.Range range16 = dateAxis14.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot17 = dateAxis14.getPlot();
        dateAxis14.setLabelURL("hi!");
        dateAxis14.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis14, categoryItemRenderer23);
        categoryPlot24.setWeight((int) (byte) 0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener27 = null;
        categoryPlot24.addChangeListener(plotChangeListener27);
        org.jfree.chart.axis.AxisLocation axisLocation30 = null;
        categoryPlot24.setRangeAxisLocation((int) (short) 1, axisLocation30);
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot();
        xYPlot32.setRangeCrosshairVisible(true);
        boolean boolean35 = xYPlot32.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot();
        xYPlot36.configureDomainAxes();
        org.jfree.chart.util.Layer layer38 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection39 = xYPlot36.getDomainMarkers(layer38);
        java.util.Collection collection40 = xYPlot32.getRangeMarkers(layer38);
        java.awt.Stroke stroke41 = xYPlot32.getDomainZeroBaselineStroke();
        categoryPlot24.setRangeGridlineStroke(stroke41);
        xYPlot3.setDomainCrosshairStroke(stroke41);
        org.jfree.chart.plot.XYPlot xYPlot44 = new org.jfree.chart.plot.XYPlot();
        xYPlot44.setRangeCrosshairVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        xYPlot44.setInsets(rectangleInsets47, true);
        java.awt.Paint paint50 = xYPlot44.getDomainTickBandPaint();
        java.lang.String str51 = xYPlot44.getPlotType();
        org.jfree.chart.axis.DateAxis dateAxis52 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape53 = dateAxis52.getLeftArrow();
        java.awt.Paint paint54 = dateAxis52.getAxisLinePaint();
        int int55 = xYPlot44.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis52);
        java.awt.Paint paint56 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        dateAxis52.setLabelPaint(paint56);
        org.jfree.data.category.CategoryDataset categoryDataset58 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis60 = new org.jfree.chart.axis.CategoryAxis("");
        float float61 = categoryAxis60.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis62 = new org.jfree.chart.axis.DateAxis();
        boolean boolean63 = dateAxis62.isAutoTickUnitSelection();
        org.jfree.data.Range range64 = dateAxis62.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot65 = dateAxis62.getPlot();
        dateAxis62.setLabelURL("hi!");
        dateAxis62.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer71 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot72 = new org.jfree.chart.plot.CategoryPlot(categoryDataset58, categoryAxis60, (org.jfree.chart.axis.ValueAxis) dateAxis62, categoryItemRenderer71);
        categoryPlot72.setWeight((int) (byte) 0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener75 = null;
        categoryPlot72.addChangeListener(plotChangeListener75);
        org.jfree.chart.plot.XYPlot xYPlot77 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener78 = null;
        xYPlot77.addChangeListener(plotChangeListener78);
        java.awt.Paint paint80 = xYPlot77.getOutlinePaint();
        java.awt.Stroke stroke81 = xYPlot77.getRangeZeroBaselineStroke();
        categoryPlot72.setDomainGridlineStroke(stroke81);
        try {
            org.jfree.chart.plot.IntervalMarker intervalMarker84 = new org.jfree.chart.plot.IntervalMarker((double) (byte) 1, (double) ' ', paint2, stroke41, paint56, stroke81, 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.0f + "'", float13 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNull(plot17);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(layer38);
        org.junit.Assert.assertNull(collection39);
        org.junit.Assert.assertNull(collection40);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(rectangleInsets47);
        org.junit.Assert.assertNull(paint50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "XY Plot" + "'", str51.equals("XY Plot"));
        org.junit.Assert.assertNotNull(shape53);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1) + "'", int55 == (-1));
        org.junit.Assert.assertNotNull(paint56);
        org.junit.Assert.assertTrue("'" + float61 + "' != '" + 0.0f + "'", float61 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNotNull(range64);
        org.junit.Assert.assertNull(plot65);
        org.junit.Assert.assertNotNull(paint80);
        org.junit.Assert.assertNotNull(stroke81);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        xYPlot16.setRangeCrosshairVisible(true);
        boolean boolean19 = xYPlot16.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        xYPlot20.configureDomainAxes();
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection23 = xYPlot20.getDomainMarkers(layer22);
        java.util.Collection collection24 = xYPlot16.getRangeMarkers(layer22);
        java.util.Collection collection25 = categoryPlot14.getRangeMarkers((int) (byte) 1, layer22);
        java.util.List list26 = categoryPlot14.getCategories();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = categoryPlot14.getAxisOffset();
        double double29 = rectangleInsets27.extendHeight((double) 10);
        double double30 = rectangleInsets27.getRight();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertNull(collection23);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertNull(list26);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 18.0d + "'", double29 == 18.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 4.0d + "'", double30 == 4.0d);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        dateAxis3.setTickMarksVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource6 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis3.setStandardTickUnits(tickUnitSource6);
        java.text.DateFormat dateFormat8 = null;
        dateAxis3.setDateFormatOverride(dateFormat8);
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = dateAxis10.getLabelInsets();
        dateAxis3.setTickLabelInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer13);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray15 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot14.setRangeAxes(valueAxisArray15);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot14.getDomainAxisEdge();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor18 = null;
        try {
            categoryPlot14.setDomainGridlinePosition(categoryAnchor18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(tickUnitSource6);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(valueAxisArray15);
        org.junit.Assert.assertNotNull(rectangleEdge17);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        xYPlot16.setRangeCrosshairVisible(true);
        boolean boolean19 = xYPlot16.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        xYPlot20.configureDomainAxes();
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection23 = xYPlot20.getDomainMarkers(layer22);
        java.util.Collection collection24 = xYPlot16.getRangeMarkers(layer22);
        java.util.Collection collection25 = categoryPlot14.getRangeMarkers((int) (byte) 1, layer22);
        java.util.List list26 = categoryPlot14.getCategories();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = categoryPlot14.getAxisOffset();
        double double29 = rectangleInsets27.extendHeight((double) 10);
        org.jfree.chart.util.UnitType unitType30 = rectangleInsets27.getUnitType();
        java.lang.String str31 = unitType30.toString();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertNull(collection23);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertNull(list26);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 18.0d + "'", double29 == 18.0d);
        org.junit.Assert.assertNotNull(unitType30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "UnitType.ABSOLUTE" + "'", str31.equals("UnitType.ABSOLUTE"));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getLeftArrow();
        dateAxis0.setPositiveArrowVisible(false);
        org.junit.Assert.assertNotNull(shape1);
    }

//    @Test
//    public void test359() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test359");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getFirstMillisecond();
//        java.lang.String str2 = day0.toString();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = day0.getFirstMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560409200000L + "'", long1 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis1.configure();
        double double3 = numberAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat6 = numberAxis5.getNumberFormatOverride();
        org.jfree.data.RangeType rangeType7 = numberAxis5.getRangeType();
        numberAxis1.setRangeType(rangeType7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        xYPlot9.addChangeListener(plotChangeListener10);
        java.awt.Paint paint12 = xYPlot9.getOutlinePaint();
        java.awt.Stroke stroke13 = xYPlot9.getRangeZeroBaselineStroke();
        numberAxis1.setTickMarkStroke(stroke13);
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis16.configure();
        java.lang.Object obj18 = numberAxis16.clone();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit19 = numberAxis16.getTickUnit();
        numberAxis1.setTickUnit(numberTickUnit19);
        numberAxis1.setTickMarkOutsideLength((float) 1560409200000L);
        double double23 = numberAxis1.getAutoRangeMinimumSize();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNull(numberFormat6);
        org.junit.Assert.assertNotNull(rangeType7);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(numberTickUnit19);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0E-8d + "'", double23 == 1.0E-8d);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        categoryPlot14.setWeight((int) (byte) 0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener17 = null;
        categoryPlot14.addChangeListener(plotChangeListener17);
        org.jfree.chart.axis.AxisLocation axisLocation20 = null;
        categoryPlot14.setRangeAxisLocation((int) (short) 1, axisLocation20);
        boolean boolean22 = categoryPlot14.isDomainZoomable();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        int int24 = categoryPlot14.getIndexOf(categoryItemRenderer23);
        java.lang.Object obj25 = categoryPlot14.clone();
        java.awt.Stroke stroke26 = categoryPlot14.getDomainGridlineStroke();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertNotNull(stroke26);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        boolean boolean3 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        xYPlot4.configureDomainAxes();
        org.jfree.chart.util.Layer layer6 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection7 = xYPlot4.getDomainMarkers(layer6);
        java.util.Collection collection8 = xYPlot0.getRangeMarkers(layer6);
        java.awt.Stroke stroke9 = xYPlot0.getDomainZeroBaselineStroke();
        int int10 = xYPlot0.getRangeAxisCount();
        try {
            org.jfree.chart.axis.ValueAxis valueAxis12 = xYPlot0.getDomainAxisForDataset(7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 7 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(layer6);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureDomainAxes();
        java.awt.Stroke stroke2 = xYPlot0.getDomainGridlineStroke();
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairValue((double) (-1L));
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        float float6 = categoryAxis5.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isAutoTickUnitSelection();
        org.jfree.data.Range range9 = dateAxis7.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot10 = dateAxis7.getPlot();
        dateAxis7.setLabelURL("hi!");
        dateAxis7.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer16);
        categoryPlot17.setWeight((int) (byte) 0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener20 = null;
        categoryPlot17.addChangeListener(plotChangeListener20);
        java.awt.Color color22 = java.awt.Color.YELLOW;
        categoryPlot17.setDomainGridlinePaint((java.awt.Paint) color22);
        xYPlot0.setRangeTickBandPaint((java.awt.Paint) color22);
        java.awt.Stroke stroke25 = xYPlot0.getDomainZeroBaselineStroke();
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNull(plot10);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke25);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        float float4 = categoryAxis3.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        boolean boolean6 = dateAxis5.isAutoTickUnitSelection();
        org.jfree.data.Range range7 = dateAxis5.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot8 = dateAxis5.getPlot();
        dateAxis5.setLabelURL("hi!");
        dateAxis5.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer14);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        dateAxis16.setTickMarksVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource19 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis16.setStandardTickUnits(tickUnitSource19);
        java.text.DateFormat dateFormat21 = null;
        dateAxis16.setDateFormatOverride(dateFormat21);
        dateAxis16.setTickMarksVisible(true);
        dateAxis16.setRange((double) (-1L), 1.0E-8d);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis16, categoryItemRenderer28);
        int int30 = categoryPlot29.getBackgroundImageAlignment();
        org.jfree.chart.axis.AxisLocation axisLocation32 = categoryPlot29.getDomainAxisLocation((-128));
        org.jfree.chart.axis.AxisLocation axisLocation33 = axisLocation32.getOpposite();
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(tickUnitSource19);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 15 + "'", int30 == 15);
        org.junit.Assert.assertNotNull(axisLocation32);
        org.junit.Assert.assertNotNull(axisLocation33);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        java.awt.Color color0 = java.awt.Color.LIGHT_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        xYPlot0.setInsets(rectangleInsets3, true);
        java.awt.Paint paint6 = xYPlot0.getDomainTickBandPaint();
        java.lang.String str7 = xYPlot0.getPlotType();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape9 = dateAxis8.getLeftArrow();
        java.awt.Paint paint10 = dateAxis8.getAxisLinePaint();
        int int11 = xYPlot0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis8);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setTickMarksVisible(true);
        org.jfree.chart.event.AxisChangeListener axisChangeListener15 = null;
        dateAxis12.removeChangeListener(axisChangeListener15);
        java.awt.Font font17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis12.setTickLabelFont(font17);
        dateAxis12.setNegativeArrowVisible(false);
        xYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis12);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation22 = null;
        try {
            xYPlot0.addAnnotation(xYAnnotation22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "XY Plot" + "'", str7.equals("XY Plot"));
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(font17);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        boolean boolean3 = xYPlot0.isRangeCrosshairLockedOnData();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.util.List list6 = null;
        xYPlot0.drawDomainTickBands(graphics2D4, rectangle2D5, list6);
        double double8 = xYPlot0.getRangeCrosshairValue();
        java.awt.Stroke stroke9 = xYPlot0.getOutlineStroke();
        xYPlot0.mapDatasetToRangeAxis((int) (short) -1, 6);
        java.awt.Stroke stroke13 = xYPlot0.getRangeCrosshairStroke();
        xYPlot0.setDomainZeroBaselineVisible(false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (-128), 0.0d, (double) 10, (double) (byte) 100);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getYear();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        boolean boolean3 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        xYPlot4.configureDomainAxes();
        org.jfree.chart.util.Layer layer6 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection7 = xYPlot4.getDomainMarkers(layer6);
        java.util.Collection collection8 = xYPlot0.getRangeMarkers(layer6);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent9 = null;
        xYPlot0.datasetChanged(datasetChangeEvent9);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(layer6);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(collection8);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.CENTER;
        try {
            java.awt.geom.Point2D point2D2 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor1);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isAutoTickUnitSelection();
        org.jfree.data.Range range2 = dateAxis0.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot3 = dateAxis0.getPlot();
        dateAxis0.setLabelURL("hi!");
        try {
            dateAxis0.setAutoRangeMinimumSize((double) 0L, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        float float4 = categoryAxis3.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        boolean boolean6 = dateAxis5.isAutoTickUnitSelection();
        org.jfree.data.Range range7 = dateAxis5.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot8 = dateAxis5.getPlot();
        dateAxis5.setLabelURL("hi!");
        dateAxis5.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer14);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        dateAxis16.setTickMarksVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource19 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis16.setStandardTickUnits(tickUnitSource19);
        java.text.DateFormat dateFormat21 = null;
        dateAxis16.setDateFormatOverride(dateFormat21);
        dateAxis16.setTickMarksVisible(true);
        dateAxis16.setRange((double) (-1L), 1.0E-8d);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis16, categoryItemRenderer28);
        java.awt.Font font31 = categoryAxis3.getTickLabelFont((java.lang.Comparable) 'a');
        categoryAxis3.setVisible(false);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(tickUnitSource19);
        org.junit.Assert.assertNotNull(font31);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis1.configure();
        java.lang.Object obj3 = numberAxis1.clone();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit4 = numberAxis1.getTickUnit();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        float float10 = categoryAxis9.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isAutoTickUnitSelection();
        org.jfree.data.Range range13 = dateAxis11.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot14 = dateAxis11.getPlot();
        dateAxis11.setLabelURL("hi!");
        dateAxis11.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis11, categoryItemRenderer20);
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot();
        xYPlot23.setRangeCrosshairVisible(true);
        boolean boolean26 = xYPlot23.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot();
        xYPlot27.configureDomainAxes();
        org.jfree.chart.util.Layer layer29 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection30 = xYPlot27.getDomainMarkers(layer29);
        java.util.Collection collection31 = xYPlot23.getRangeMarkers(layer29);
        java.util.Collection collection32 = categoryPlot21.getRangeMarkers((int) (byte) 1, layer29);
        java.util.List list33 = categoryPlot21.getCategories();
        categoryPlot21.clearAnnotations();
        org.jfree.chart.util.SortOrder sortOrder35 = categoryPlot21.getColumnRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation37 = categoryPlot21.getDomainAxisLocation((int) 'a');
        org.jfree.chart.axis.AxisLocation axisLocation38 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.plot.PlotOrientation plotOrientation39 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation38, plotOrientation39);
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation37, plotOrientation39);
        try {
            double double42 = numberAxis1.valueToJava2D((double) 0.0f, rectangle2D6, rectangleEdge41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(numberTickUnit4);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNull(plot14);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(layer29);
        org.junit.Assert.assertNull(collection30);
        org.junit.Assert.assertNull(collection31);
        org.junit.Assert.assertNull(collection32);
        org.junit.Assert.assertNull(list33);
        org.junit.Assert.assertNotNull(sortOrder35);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNotNull(axisLocation38);
        org.junit.Assert.assertNotNull(plotOrientation39);
        org.junit.Assert.assertNotNull(rectangleEdge40);
        org.junit.Assert.assertNotNull(rectangleEdge41);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureDomainAxes();
        xYPlot0.zoom((double) 10);
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean6 = xYPlot0.removeDomainMarker(marker4, layer5);
        xYPlot0.clearRangeMarkers();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = xYPlot0.getInsets();
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("");
        float float13 = categoryAxis12.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        boolean boolean15 = dateAxis14.isAutoTickUnitSelection();
        org.jfree.data.Range range16 = dateAxis14.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot17 = dateAxis14.getPlot();
        dateAxis14.setLabelURL("hi!");
        dateAxis14.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis14, categoryItemRenderer23);
        categoryPlot24.setWeight((int) (byte) 0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener27 = null;
        categoryPlot24.addChangeListener(plotChangeListener27);
        java.awt.Color color29 = java.awt.Color.YELLOW;
        categoryPlot24.setDomainGridlinePaint((java.awt.Paint) color29);
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = categoryPlot24.getDomainAxis();
        org.jfree.data.category.CategoryDataset categoryDataset33 = null;
        org.jfree.data.category.CategoryDataset categoryDataset34 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = new org.jfree.chart.axis.CategoryAxis("");
        float float37 = categoryAxis36.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis();
        boolean boolean39 = dateAxis38.isAutoTickUnitSelection();
        org.jfree.data.Range range40 = dateAxis38.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot41 = dateAxis38.getPlot();
        dateAxis38.setLabelURL("hi!");
        dateAxis38.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer47 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot48 = new org.jfree.chart.plot.CategoryPlot(categoryDataset34, categoryAxis36, (org.jfree.chart.axis.ValueAxis) dateAxis38, categoryItemRenderer47);
        org.jfree.chart.axis.DateAxis dateAxis49 = new org.jfree.chart.axis.DateAxis();
        dateAxis49.setTickMarksVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource52 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis49.setStandardTickUnits(tickUnitSource52);
        java.text.DateFormat dateFormat54 = null;
        dateAxis49.setDateFormatOverride(dateFormat54);
        dateAxis49.setTickMarksVisible(true);
        dateAxis49.setRange((double) (-1L), 1.0E-8d);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, categoryAxis36, (org.jfree.chart.axis.ValueAxis) dateAxis49, categoryItemRenderer61);
        int int63 = categoryPlot62.getBackgroundImageAlignment();
        org.jfree.chart.axis.AxisLocation axisLocation65 = categoryPlot62.getDomainAxisLocation((-128));
        categoryPlot24.setDomainAxisLocation(0, axisLocation65, false);
        org.jfree.chart.plot.CategoryMarker categoryMarker69 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) true);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType70 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        java.lang.String str71 = lengthAdjustmentType70.toString();
        categoryMarker69.setLabelOffsetType(lengthAdjustmentType70);
        boolean boolean73 = axisLocation65.equals((java.lang.Object) lengthAdjustmentType70);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType74 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        java.lang.String str75 = lengthAdjustmentType74.toString();
        try {
            java.awt.geom.Rectangle2D rectangle2D76 = rectangleInsets8.createAdjustedRectangle(rectangle2D9, lengthAdjustmentType70, lengthAdjustmentType74);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(layer5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.0f + "'", float13 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNull(plot17);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(categoryAxis31);
        org.junit.Assert.assertTrue("'" + float37 + "' != '" + 0.0f + "'", float37 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(range40);
        org.junit.Assert.assertNull(plot41);
        org.junit.Assert.assertNotNull(tickUnitSource52);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 15 + "'", int63 == 15);
        org.junit.Assert.assertNotNull(axisLocation65);
        org.junit.Assert.assertNotNull(lengthAdjustmentType70);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "EXPAND" + "'", str71.equals("EXPAND"));
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(lengthAdjustmentType74);
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "EXPAND" + "'", str75.equals("EXPAND"));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        java.awt.Color color0 = java.awt.Color.red;
        java.awt.image.ColorModel colorModel1 = null;
        java.awt.Rectangle rectangle2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.AffineTransform affineTransform4 = null;
        java.awt.RenderingHints renderingHints5 = null;
        java.awt.PaintContext paintContext6 = color0.createContext(colorModel1, rectangle2, rectangle2D3, affineTransform4, renderingHints5);
        java.awt.Color color7 = color0.darker();
        java.awt.color.ColorSpace colorSpace8 = color0.getColorSpace();
        int int9 = color0.getGreen();
        java.awt.Color color10 = color0.darker();
        java.awt.Color color11 = color10.brighter();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paintContext6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(colorSpace8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        xYPlot16.setRangeCrosshairVisible(true);
        boolean boolean19 = xYPlot16.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        xYPlot20.configureDomainAxes();
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection23 = xYPlot20.getDomainMarkers(layer22);
        java.util.Collection collection24 = xYPlot16.getRangeMarkers(layer22);
        java.util.Collection collection25 = categoryPlot14.getRangeMarkers((int) (byte) 1, layer22);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = categoryPlot14.getRangeAxisEdge((int) ' ');
        categoryPlot14.setRangeGridlinesVisible(true);
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot();
        xYPlot30.setRangeCrosshairVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        xYPlot30.setInsets(rectangleInsets33, true);
        categoryPlot14.setAxisOffset(rectangleInsets33);
        double double38 = rectangleInsets33.trimWidth((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertNull(collection23);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + (-1.0d) + "'", double38 == (-1.0d));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        xYPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = xYPlot0.getOutlinePaint();
        org.jfree.chart.util.Layer layer4 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(layer4);
        boolean boolean6 = xYPlot0.isSubplot();
        org.jfree.chart.axis.AxisLocation axisLocation8 = null;
        xYPlot0.setRangeAxisLocation(8, axisLocation8, false);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(layer4);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.chart.util.Layer layer0 = org.jfree.chart.util.Layer.BACKGROUND;
        org.junit.Assert.assertNotNull(layer0);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        dateAxis3.setTickMarksVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource6 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis3.setStandardTickUnits(tickUnitSource6);
        java.text.DateFormat dateFormat8 = null;
        dateAxis3.setDateFormatOverride(dateFormat8);
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = dateAxis10.getLabelInsets();
        dateAxis3.setTickLabelInsets(rectangleInsets11);
        xYPlot0.setInsets(rectangleInsets11);
        org.jfree.chart.util.UnitType unitType14 = rectangleInsets11.getUnitType();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D18 = rectangleInsets11.createInsetRectangle(rectangle2D15, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(tickUnitSource6);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(unitType14);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        xYPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        int int6 = xYPlot0.getRangeAxisIndex(valueAxis5);
        xYPlot0.setDomainZeroBaselineVisible(false);
        boolean boolean9 = xYPlot0.isDomainGridlinesVisible();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat2 = numberAxis1.getNumberFormatOverride();
        org.jfree.data.RangeType rangeType3 = numberAxis1.getRangeType();
        boolean boolean4 = numberAxis1.isTickMarksVisible();
        double double5 = numberAxis1.getUpperMargin();
        boolean boolean6 = numberAxis1.isTickLabelsVisible();
        numberAxis1.setVerticalTickLabels(false);
        java.lang.Object obj9 = null;
        boolean boolean10 = numberAxis1.equals(obj9);
        boolean boolean11 = numberAxis1.getAutoRangeIncludesZero();
        org.junit.Assert.assertNull(numberFormat2);
        org.junit.Assert.assertNotNull(rangeType3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        xYPlot1.configureDomainAxes();
        java.lang.String str3 = xYPlot1.getNoDataMessage();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot1.zoomRangeAxes((double) 10.0f, (double) 1L, plotRenderingInfo6, point2D7);
        int int9 = objectList0.indexOf((java.lang.Object) point2D7);
        java.awt.Paint[] paintArray10 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Paint[] paintArray11 = new java.awt.Paint[] {};
        java.awt.Stroke[] strokeArray12 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray13 = new java.awt.Stroke[] {};
        java.awt.Shape shape14 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape[] shapeArray15 = new java.awt.Shape[] { shape14 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier16 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray10, paintArray11, strokeArray12, strokeArray13, shapeArray15);
        java.awt.Stroke stroke17 = defaultDrawingSupplier16.getNextStroke();
        int int18 = objectList0.indexOf((java.lang.Object) defaultDrawingSupplier16);
        int int19 = objectList0.size();
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(paintArray10);
        org.junit.Assert.assertNotNull(paintArray11);
        org.junit.Assert.assertNotNull(strokeArray12);
        org.junit.Assert.assertNotNull(strokeArray13);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(shapeArray15);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        java.awt.Color color1 = java.awt.Color.orange;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("");
        float float5 = categoryAxis4.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        boolean boolean7 = dateAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = dateAxis6.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot9 = dateAxis6.getPlot();
        dateAxis6.setLabelURL("hi!");
        dateAxis6.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis6, categoryItemRenderer15);
        org.jfree.chart.plot.Marker marker17 = null;
        boolean boolean18 = categoryPlot16.removeDomainMarker(marker17);
        java.util.List list19 = categoryPlot16.getAnnotations();
        java.awt.Stroke stroke20 = categoryPlot16.getRangeGridlineStroke();
        java.awt.Color color21 = org.jfree.chart.ChartColor.LIGHT_RED;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot();
        xYPlot22.setRangeCrosshairVisible(true);
        boolean boolean25 = xYPlot22.isRangeCrosshairLockedOnData();
        java.awt.Graphics2D graphics2D26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        java.util.List list28 = null;
        xYPlot22.drawDomainTickBands(graphics2D26, rectangle2D27, list28);
        double double30 = xYPlot22.getRangeCrosshairValue();
        java.awt.Stroke stroke31 = xYPlot22.getOutlineStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker33 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0, (java.awt.Paint) color1, stroke20, (java.awt.Paint) color21, stroke31, (float) (short) 1);
        java.awt.Stroke stroke34 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryMarker33.setOutlineStroke(stroke34);
        try {
            categoryMarker33.setAlpha((float) 1560409200000L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNull(plot9);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(stroke34);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        float float4 = categoryAxis3.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        boolean boolean6 = dateAxis5.isAutoTickUnitSelection();
        org.jfree.data.Range range7 = dateAxis5.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot8 = dateAxis5.getPlot();
        dateAxis5.setLabelURL("hi!");
        dateAxis5.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer14);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        dateAxis16.setTickMarksVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource19 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis16.setStandardTickUnits(tickUnitSource19);
        java.text.DateFormat dateFormat21 = null;
        dateAxis16.setDateFormatOverride(dateFormat21);
        dateAxis16.setTickMarksVisible(true);
        dateAxis16.setRange((double) (-1L), 1.0E-8d);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis16, categoryItemRenderer28);
        int int30 = categoryPlot29.getBackgroundImageAlignment();
        categoryPlot29.setRangeCrosshairValue((double) 1.0f, true);
        boolean boolean34 = categoryPlot29.isRangeCrosshairVisible();
        org.jfree.chart.util.SortOrder sortOrder35 = categoryPlot29.getRowRenderingOrder();
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(tickUnitSource19);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 15 + "'", int30 == 15);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(sortOrder35);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) true);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType2 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        java.lang.String str3 = lengthAdjustmentType2.toString();
        categoryMarker1.setLabelOffsetType(lengthAdjustmentType2);
        java.awt.Font font5 = categoryMarker1.getLabelFont();
        java.awt.Stroke stroke6 = categoryMarker1.getStroke();
        org.junit.Assert.assertNotNull(lengthAdjustmentType2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "EXPAND" + "'", str3.equals("EXPAND"));
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        xYPlot0.setInsets(rectangleInsets3, true);
        java.awt.Paint paint6 = xYPlot0.getDomainTickBandPaint();
        java.lang.String str7 = xYPlot0.getPlotType();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = xYPlot0.getInsets();
        double double9 = rectangleInsets8.getRight();
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "XY Plot" + "'", str7.equals("XY Plot"));
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        boolean boolean3 = xYPlot0.isDomainZeroBaselineVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        try {
            xYPlot0.handleClick(0, 1, plotRenderingInfo6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        xYPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = xYPlot0.getOutlinePaint();
        org.jfree.chart.util.Layer layer4 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(layer4);
        boolean boolean6 = xYPlot0.isSubplot();
        java.awt.Paint paint7 = xYPlot0.getRangeGridlinePaint();
        xYPlot0.mapDatasetToDomainAxis(0, (int) (byte) -1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener11 = null;
        xYPlot0.removeChangeListener(plotChangeListener11);
        java.awt.Color color15 = java.awt.Color.orange;
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis("");
        float float19 = categoryAxis18.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean21 = dateAxis20.isAutoTickUnitSelection();
        org.jfree.data.Range range22 = dateAxis20.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot23 = dateAxis20.getPlot();
        dateAxis20.setLabelURL("hi!");
        dateAxis20.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis20, categoryItemRenderer29);
        org.jfree.chart.plot.Marker marker31 = null;
        boolean boolean32 = categoryPlot30.removeDomainMarker(marker31);
        java.util.List list33 = categoryPlot30.getAnnotations();
        java.awt.Stroke stroke34 = categoryPlot30.getRangeGridlineStroke();
        java.awt.Color color35 = org.jfree.chart.ChartColor.LIGHT_RED;
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot();
        xYPlot36.setRangeCrosshairVisible(true);
        boolean boolean39 = xYPlot36.isRangeCrosshairLockedOnData();
        java.awt.Graphics2D graphics2D40 = null;
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        java.util.List list42 = null;
        xYPlot36.drawDomainTickBands(graphics2D40, rectangle2D41, list42);
        double double44 = xYPlot36.getRangeCrosshairValue();
        java.awt.Stroke stroke45 = xYPlot36.getOutlineStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker47 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0, (java.awt.Paint) color15, stroke34, (java.awt.Paint) color35, stroke45, (float) (short) 1);
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener49 = null;
        xYPlot48.addChangeListener(plotChangeListener49);
        java.awt.Paint paint51 = xYPlot48.getOutlinePaint();
        org.jfree.chart.util.Layer layer52 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection53 = xYPlot48.getRangeMarkers(layer52);
        xYPlot0.addDomainMarker(0, (org.jfree.chart.plot.Marker) categoryMarker47, layer52);
        categoryMarker47.setAlpha(0.0f);
        categoryMarker47.setDrawAsLine(true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(layer4);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 0.0f + "'", float19 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNull(plot23);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(list33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertNotNull(layer52);
        org.junit.Assert.assertNull(collection53);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        categoryPlot14.setWeight((int) (byte) 0);
        org.jfree.chart.util.SortOrder sortOrder17 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot14.setRowRenderingOrder(sortOrder17);
        org.jfree.chart.LegendItemCollection legendItemCollection19 = categoryPlot14.getFixedLegendItems();
        categoryPlot14.setAnchorValue((double) 255);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = categoryPlot14.getDomainAxisForDataset((int) (short) 10);
        java.awt.Graphics2D graphics2D24 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.data.category.CategoryDataset categoryDataset29 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = new org.jfree.chart.axis.CategoryAxis("");
        float float32 = categoryAxis31.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis();
        boolean boolean34 = dateAxis33.isAutoTickUnitSelection();
        org.jfree.data.Range range35 = dateAxis33.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot36 = dateAxis33.getPlot();
        dateAxis33.setLabelURL("hi!");
        dateAxis33.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer42 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset29, categoryAxis31, (org.jfree.chart.axis.ValueAxis) dateAxis33, categoryItemRenderer42);
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis();
        dateAxis44.setTickMarksVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource47 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis44.setStandardTickUnits(tickUnitSource47);
        java.text.DateFormat dateFormat49 = null;
        dateAxis44.setDateFormatOverride(dateFormat49);
        dateAxis44.setTickMarksVisible(true);
        dateAxis44.setRange((double) (-1L), 1.0E-8d);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer56 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot57 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis31, (org.jfree.chart.axis.ValueAxis) dateAxis44, categoryItemRenderer56);
        org.jfree.chart.util.RectangleEdge rectangleEdge58 = categoryPlot57.getRangeAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo59 = null;
        try {
            org.jfree.chart.axis.AxisState axisState60 = categoryAxis23.draw(graphics2D24, (double) 10, rectangle2D26, rectangle2D27, rectangleEdge58, plotRenderingInfo59);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(sortOrder17);
        org.junit.Assert.assertNull(legendItemCollection19);
        org.junit.Assert.assertNotNull(categoryAxis23);
        org.junit.Assert.assertTrue("'" + float32 + "' != '" + 0.0f + "'", float32 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertNull(plot36);
        org.junit.Assert.assertNotNull(tickUnitSource47);
        org.junit.Assert.assertNotNull(rectangleEdge58);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        int int1 = color0.getBlue();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        xYPlot16.setRangeCrosshairVisible(true);
        boolean boolean19 = xYPlot16.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        xYPlot20.configureDomainAxes();
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection23 = xYPlot20.getDomainMarkers(layer22);
        java.util.Collection collection24 = xYPlot16.getRangeMarkers(layer22);
        java.util.Collection collection25 = categoryPlot14.getRangeMarkers((int) (byte) 1, layer22);
        java.util.List list26 = categoryPlot14.getCategories();
        java.awt.Graphics2D graphics2D27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        boolean boolean31 = categoryPlot14.render(graphics2D27, rectangle2D28, 0, plotRenderingInfo30);
        org.jfree.chart.axis.AxisSpace axisSpace32 = null;
        categoryPlot14.setFixedRangeAxisSpace(axisSpace32, true);
        org.jfree.chart.axis.AxisLocation axisLocation36 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot14.setDomainAxisLocation((int) (short) 100, axisLocation36, false);
        boolean boolean39 = categoryPlot14.isDomainGridlinesVisible();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertNull(collection23);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertNull(list26);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        dateAxis3.setTickMarksVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource6 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis3.setStandardTickUnits(tickUnitSource6);
        java.text.DateFormat dateFormat8 = null;
        dateAxis3.setDateFormatOverride(dateFormat8);
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = dateAxis10.getLabelInsets();
        dateAxis3.setTickLabelInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer13);
        dateAxis3.setLabelAngle((double) '#');
        boolean boolean17 = dateAxis3.isAxisLineVisible();
        org.junit.Assert.assertNotNull(tickUnitSource6);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = dateAxis0.getLabelInsets();
        dateAxis0.setLabel("XY Plot");
        double double4 = dateAxis0.getFixedDimension();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = dateAxis0.getLabelInsets();
        double double2 = rectangleInsets1.getBottom();
        double double4 = rectangleInsets1.calculateRightOutset(0.0d);
        org.jfree.chart.util.UnitType unitType5 = rectangleInsets1.getUnitType();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.0d + "'", double4 == 3.0d);
        org.junit.Assert.assertNotNull(unitType5);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        categoryPlot14.setWeight((int) (byte) 0);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        categoryPlot14.setRenderer(categoryItemRenderer17);
        categoryPlot14.clearRangeMarkers(10);
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = categoryPlot14.getDomainAxis();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(categoryAxis21);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        try {
            java.awt.Color color1 = java.awt.Color.decode("java.awt.Color[r=178,g=178,b=0]");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"java.awt.Color[r=178,g=178,b=0]\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        dateAxis3.setTickMarksVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource6 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis3.setStandardTickUnits(tickUnitSource6);
        java.text.DateFormat dateFormat8 = null;
        dateAxis3.setDateFormatOverride(dateFormat8);
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = dateAxis10.getLabelInsets();
        dateAxis3.setTickLabelInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer13);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray15 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot14.setRangeAxes(valueAxisArray15);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot14.getDomainAxisEdge();
        categoryPlot14.mapDatasetToRangeAxis(7, 7);
        org.junit.Assert.assertNotNull(tickUnitSource6);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(valueAxisArray15);
        org.junit.Assert.assertNotNull(rectangleEdge17);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        xYPlot0.setInsets(rectangleInsets3, true);
        java.lang.Object obj6 = xYPlot0.clone();
        xYPlot0.setDomainZeroBaselineVisible(false);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("");
        float float13 = categoryAxis12.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        boolean boolean15 = dateAxis14.isAutoTickUnitSelection();
        org.jfree.data.Range range16 = dateAxis14.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot17 = dateAxis14.getPlot();
        dateAxis14.setLabelURL("hi!");
        dateAxis14.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis14, categoryItemRenderer23);
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot();
        xYPlot26.setRangeCrosshairVisible(true);
        boolean boolean29 = xYPlot26.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot();
        xYPlot30.configureDomainAxes();
        org.jfree.chart.util.Layer layer32 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection33 = xYPlot30.getDomainMarkers(layer32);
        java.util.Collection collection34 = xYPlot26.getRangeMarkers(layer32);
        java.util.Collection collection35 = categoryPlot24.getRangeMarkers((int) (byte) 1, layer32);
        java.util.List list36 = categoryPlot24.getCategories();
        categoryPlot24.clearAnnotations();
        org.jfree.chart.util.SortOrder sortOrder38 = categoryPlot24.getColumnRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation40 = categoryPlot24.getDomainAxisLocation((int) 'a');
        xYPlot0.setDomainAxisLocation((int) (short) 1, axisLocation40, false);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.0f + "'", float13 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNull(plot17);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(layer32);
        org.junit.Assert.assertNull(collection33);
        org.junit.Assert.assertNull(collection34);
        org.junit.Assert.assertNull(collection35);
        org.junit.Assert.assertNull(list36);
        org.junit.Assert.assertNotNull(sortOrder38);
        org.junit.Assert.assertNotNull(axisLocation40);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        xYPlot0.setInsets(rectangleInsets3, true);
        java.awt.Paint paint6 = xYPlot0.getDomainTickBandPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier7 = xYPlot0.getDrawingSupplier();
        boolean boolean8 = xYPlot0.isDomainZeroBaselineVisible();
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("");
        float float12 = categoryAxis11.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        boolean boolean14 = dateAxis13.isAutoTickUnitSelection();
        org.jfree.data.Range range15 = dateAxis13.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot16 = dateAxis13.getPlot();
        dateAxis13.setLabelURL("hi!");
        dateAxis13.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis13, categoryItemRenderer22);
        categoryPlot23.setWeight((int) (byte) 0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener26 = null;
        categoryPlot23.addChangeListener(plotChangeListener26);
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener29 = null;
        xYPlot28.addChangeListener(plotChangeListener29);
        java.awt.Paint paint31 = xYPlot28.getOutlinePaint();
        java.awt.Stroke stroke32 = xYPlot28.getRangeZeroBaselineStroke();
        categoryPlot23.setDomainGridlineStroke(stroke32);
        xYPlot0.setDomainZeroBaselineStroke(stroke32);
        xYPlot0.clearDomainMarkers();
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(drawingSupplier7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 0.0f + "'", float12 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNull(plot16);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(stroke32);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        int int3 = java.awt.Color.HSBtoRGB((float) 1, (float) 10, (float) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isAutoTickUnitSelection();
        java.awt.Shape shape2 = dateAxis0.getLeftArrow();
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        xYPlot3.setRangeCrosshairVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        xYPlot3.setInsets(rectangleInsets6, true);
        java.awt.Paint paint9 = xYPlot3.getDomainTickBandPaint();
        java.lang.String str10 = xYPlot3.getPlotType();
        boolean boolean11 = dateAxis0.hasListener((java.util.EventListener) xYPlot3);
        java.lang.Object obj12 = dateAxis0.clone();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "XY Plot" + "'", str10.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(obj12);
    }

//    @Test
//    public void test409() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test409");
//        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
//        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
//        float float4 = categoryAxis3.getMaximumCategoryLabelWidthRatio();
//        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
//        boolean boolean6 = dateAxis5.isAutoTickUnitSelection();
//        org.jfree.data.Range range7 = dateAxis5.getDefaultAutoRange();
//        org.jfree.chart.plot.Plot plot8 = dateAxis5.getPlot();
//        dateAxis5.setLabelURL("hi!");
//        dateAxis5.zoomRange((double) 0.0f, (double) 7);
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer14);
//        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
//        dateAxis16.setTickMarksVisible(true);
//        org.jfree.chart.axis.TickUnitSource tickUnitSource19 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
//        dateAxis16.setStandardTickUnits(tickUnitSource19);
//        java.text.DateFormat dateFormat21 = null;
//        dateAxis16.setDateFormatOverride(dateFormat21);
//        dateAxis16.setTickMarksVisible(true);
//        dateAxis16.setRange((double) (-1L), 1.0E-8d);
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis16, categoryItemRenderer28);
//        java.awt.Font font31 = categoryAxis3.getTickLabelFont((java.lang.Comparable) 'a');
//        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
//        boolean boolean33 = dateAxis32.isAutoTickUnitSelection();
//        org.jfree.data.Range range34 = dateAxis32.getDefaultAutoRange();
//        org.jfree.chart.plot.Plot plot35 = dateAxis32.getPlot();
//        java.util.Date date36 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        dateAxis32.setMinimumDate(date36);
//        java.lang.String str38 = categoryAxis3.getCategoryLabelToolTip((java.lang.Comparable) date36);
//        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis();
//        dateAxis39.setTickMarksVisible(true);
//        org.jfree.chart.event.AxisChangeListener axisChangeListener42 = null;
//        dateAxis39.removeChangeListener(axisChangeListener42);
//        java.awt.Font font44 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
//        dateAxis39.setTickLabelFont(font44);
//        java.util.TimeZone timeZone46 = dateAxis39.getTimeZone();
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(date36, timeZone46);
//        long long48 = day47.getFirstMillisecond();
//        int int49 = day47.getMonth();
//        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(range7);
//        org.junit.Assert.assertNull(plot8);
//        org.junit.Assert.assertNotNull(tickUnitSource19);
//        org.junit.Assert.assertNotNull(font31);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
//        org.junit.Assert.assertNotNull(range34);
//        org.junit.Assert.assertNull(plot35);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNull(str38);
//        org.junit.Assert.assertNotNull(font44);
//        org.junit.Assert.assertNotNull(timeZone46);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1560409200000L + "'", long48 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 6 + "'", int49 == 6);
//    }

//    @Test
//    public void test410() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test410");
//        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
//        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
//        xYPlot0.addChangeListener(plotChangeListener1);
//        java.awt.Paint paint3 = xYPlot0.getOutlinePaint();
//        org.jfree.chart.util.Layer layer4 = org.jfree.chart.util.Layer.FOREGROUND;
//        java.util.Collection collection5 = xYPlot0.getRangeMarkers(layer4);
//        boolean boolean6 = xYPlot0.isSubplot();
//        java.awt.Paint paint7 = xYPlot0.getRangeGridlinePaint();
//        xYPlot0.mapDatasetToDomainAxis(0, (int) (byte) -1);
//        org.jfree.chart.event.PlotChangeListener plotChangeListener11 = null;
//        xYPlot0.removeChangeListener(plotChangeListener11);
//        java.awt.Color color15 = java.awt.Color.orange;
//        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis("");
//        float float19 = categoryAxis18.getMaximumCategoryLabelWidthRatio();
//        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
//        boolean boolean21 = dateAxis20.isAutoTickUnitSelection();
//        org.jfree.data.Range range22 = dateAxis20.getDefaultAutoRange();
//        org.jfree.chart.plot.Plot plot23 = dateAxis20.getPlot();
//        dateAxis20.setLabelURL("hi!");
//        dateAxis20.zoomRange((double) 0.0f, (double) 7);
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis20, categoryItemRenderer29);
//        org.jfree.chart.plot.Marker marker31 = null;
//        boolean boolean32 = categoryPlot30.removeDomainMarker(marker31);
//        java.util.List list33 = categoryPlot30.getAnnotations();
//        java.awt.Stroke stroke34 = categoryPlot30.getRangeGridlineStroke();
//        java.awt.Color color35 = org.jfree.chart.ChartColor.LIGHT_RED;
//        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot();
//        xYPlot36.setRangeCrosshairVisible(true);
//        boolean boolean39 = xYPlot36.isRangeCrosshairLockedOnData();
//        java.awt.Graphics2D graphics2D40 = null;
//        java.awt.geom.Rectangle2D rectangle2D41 = null;
//        java.util.List list42 = null;
//        xYPlot36.drawDomainTickBands(graphics2D40, rectangle2D41, list42);
//        double double44 = xYPlot36.getRangeCrosshairValue();
//        java.awt.Stroke stroke45 = xYPlot36.getOutlineStroke();
//        org.jfree.chart.plot.CategoryMarker categoryMarker47 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0, (java.awt.Paint) color15, stroke34, (java.awt.Paint) color35, stroke45, (float) (short) 1);
//        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot();
//        org.jfree.chart.event.PlotChangeListener plotChangeListener49 = null;
//        xYPlot48.addChangeListener(plotChangeListener49);
//        java.awt.Paint paint51 = xYPlot48.getOutlinePaint();
//        org.jfree.chart.util.Layer layer52 = org.jfree.chart.util.Layer.FOREGROUND;
//        java.util.Collection collection53 = xYPlot48.getRangeMarkers(layer52);
//        xYPlot0.addDomainMarker(0, (org.jfree.chart.plot.Marker) categoryMarker47, layer52);
//        java.lang.Comparable comparable55 = categoryMarker47.getKey();
//        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day();
//        long long57 = day56.getFirstMillisecond();
//        categoryMarker47.setKey((java.lang.Comparable) day56);
//        java.util.Date date59 = day56.getEnd();
//        org.junit.Assert.assertNotNull(paint3);
//        org.junit.Assert.assertNotNull(layer4);
//        org.junit.Assert.assertNull(collection5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(paint7);
//        org.junit.Assert.assertNotNull(color15);
//        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 0.0f + "'", float19 == 0.0f);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertNotNull(range22);
//        org.junit.Assert.assertNull(plot23);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(list33);
//        org.junit.Assert.assertNotNull(stroke34);
//        org.junit.Assert.assertNotNull(color35);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
//        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
//        org.junit.Assert.assertNotNull(stroke45);
//        org.junit.Assert.assertNotNull(paint51);
//        org.junit.Assert.assertNotNull(layer52);
//        org.junit.Assert.assertNull(collection53);
//        org.junit.Assert.assertTrue("'" + comparable55 + "' != '" + 0 + "'", comparable55.equals(0));
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1560409200000L + "'", long57 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date59);
//    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor15 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        boolean boolean17 = categoryAnchor15.equals((java.lang.Object) 0.0d);
        java.lang.String str18 = categoryAnchor15.toString();
        categoryPlot14.setDomainGridlinePosition(categoryAnchor15);
        org.jfree.chart.axis.AxisSpace axisSpace20 = null;
        categoryPlot14.setFixedRangeAxisSpace(axisSpace20);
        categoryPlot14.mapDatasetToDomainAxis(9, (-16777216));
        org.jfree.chart.util.SortOrder sortOrder25 = categoryPlot14.getRowRenderingOrder();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(categoryAnchor15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "CategoryAnchor.MIDDLE" + "'", str18.equals("CategoryAnchor.MIDDLE"));
        org.junit.Assert.assertNotNull(sortOrder25);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.configure();
        java.lang.Object obj4 = numberAxis2.clone();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = numberAxis2.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = dateAxis6.getLabelInsets();
        dateAxis6.setLabel("XY Plot");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis6, xYItemRenderer10);
        java.awt.Stroke stroke12 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot11.setDomainGridlineStroke(stroke12);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(numberTickUnit5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        xYPlot0.setInsets(rectangleInsets3, true);
        java.awt.Paint paint6 = xYPlot0.getDomainTickBandPaint();
        java.lang.String str7 = xYPlot0.getPlotType();
        java.util.List list8 = xYPlot0.getAnnotations();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot0.getRenderer();
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "XY Plot" + "'", str7.equals("XY Plot"));
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNull(xYItemRenderer9);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        categoryPlot14.setWeight((int) (byte) 0);
        org.jfree.chart.util.SortOrder sortOrder17 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot14.setRowRenderingOrder(sortOrder17);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        boolean boolean20 = dateAxis19.isAutoTickUnitSelection();
        org.jfree.data.Range range21 = dateAxis19.getDefaultAutoRange();
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        boolean boolean23 = dateAxis22.isAutoTickUnitSelection();
        org.jfree.data.Range range24 = dateAxis22.getDefaultAutoRange();
        dateAxis19.setRangeWithMargins(range24);
        categoryPlot14.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis19);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot();
        xYPlot29.configureDomainAxes();
        java.awt.geom.Point2D point2D31 = xYPlot29.getQuadrantOrigin();
        categoryPlot14.zoomDomainAxes((double) 1560409200000L, plotRenderingInfo28, point2D31, false);
        boolean boolean34 = categoryPlot14.isRangeZoomable();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(sortOrder17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNotNull(point2D31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isAutoTickUnitSelection();
        org.jfree.data.Range range2 = dateAxis0.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot3 = dateAxis0.getPlot();
        dateAxis0.setLabelURL("hi!");
        dateAxis0.setLowerMargin(0.0d);
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        boolean boolean9 = dateAxis8.isAutoTickUnitSelection();
        org.jfree.data.Range range10 = dateAxis8.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot11 = dateAxis8.getPlot();
        java.text.DateFormat dateFormat12 = null;
        dateAxis8.setDateFormatOverride(dateFormat12);
        java.lang.String str14 = dateAxis8.getLabel();
        org.jfree.chart.axis.DateTickUnit dateTickUnit15 = dateAxis8.getTickUnit();
        java.util.Date date16 = dateAxis0.calculateHighestVisibleTickValue(dateTickUnit15);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNull(plot11);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(dateTickUnit15);
        org.junit.Assert.assertNotNull(date16);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        xYPlot16.setRangeCrosshairVisible(true);
        boolean boolean19 = xYPlot16.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        xYPlot20.configureDomainAxes();
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection23 = xYPlot20.getDomainMarkers(layer22);
        java.util.Collection collection24 = xYPlot16.getRangeMarkers(layer22);
        java.util.Collection collection25 = categoryPlot14.getRangeMarkers((int) (byte) 1, layer22);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener29 = null;
        xYPlot28.addChangeListener(plotChangeListener29);
        java.awt.Paint paint31 = xYPlot28.getOutlinePaint();
        org.jfree.chart.util.Layer layer32 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection33 = xYPlot28.getRangeMarkers(layer32);
        boolean boolean34 = xYPlot28.isSubplot();
        java.awt.Paint paint35 = xYPlot28.getRangeGridlinePaint();
        org.jfree.chart.axis.ValueAxis valueAxis37 = xYPlot28.getDomainAxisForDataset(0);
        org.jfree.data.category.CategoryDataset categoryDataset38 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = new org.jfree.chart.axis.CategoryAxis("");
        float float41 = categoryAxis40.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis42 = new org.jfree.chart.axis.DateAxis();
        boolean boolean43 = dateAxis42.isAutoTickUnitSelection();
        org.jfree.data.Range range44 = dateAxis42.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot45 = dateAxis42.getPlot();
        dateAxis42.setLabelURL("hi!");
        dateAxis42.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer51 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot52 = new org.jfree.chart.plot.CategoryPlot(categoryDataset38, categoryAxis40, (org.jfree.chart.axis.ValueAxis) dateAxis42, categoryItemRenderer51);
        categoryPlot52.setWeight((int) (byte) 0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener55 = null;
        categoryPlot52.addChangeListener(plotChangeListener55);
        java.awt.Color color57 = java.awt.Color.YELLOW;
        categoryPlot52.setDomainGridlinePaint((java.awt.Paint) color57);
        org.jfree.data.category.CategoryDataset categoryDataset60 = null;
        categoryPlot52.setDataset((int) (short) 10, categoryDataset60);
        float float62 = categoryPlot52.getBackgroundAlpha();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo64 = null;
        org.jfree.chart.plot.XYPlot xYPlot65 = new org.jfree.chart.plot.XYPlot();
        xYPlot65.configureDomainAxes();
        java.awt.geom.Point2D point2D67 = xYPlot65.getQuadrantOrigin();
        categoryPlot52.zoomDomainAxes(0.0d, plotRenderingInfo64, point2D67, false);
        xYPlot28.setQuadrantOrigin(point2D67);
        try {
            categoryPlot14.zoomRangeAxes((double) (-83), plotRenderingInfo27, point2D67, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertNull(collection23);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(layer32);
        org.junit.Assert.assertNull(collection33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNull(valueAxis37);
        org.junit.Assert.assertTrue("'" + float41 + "' != '" + 0.0f + "'", float41 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(range44);
        org.junit.Assert.assertNull(plot45);
        org.junit.Assert.assertNotNull(color57);
        org.junit.Assert.assertTrue("'" + float62 + "' != '" + 1.0f + "'", float62 == 1.0f);
        org.junit.Assert.assertNotNull(point2D67);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = dateAxis0.getLabelInsets();
        dateAxis0.setLabel("XY Plot");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = dateAxis0.getTickLabelInsets();
        double double6 = rectangleInsets4.trimWidth((double) 11);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.0d + "'", double6 == 3.0d);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType1 = rectangleInsets0.getUnitType();
        java.lang.Object obj2 = null;
        boolean boolean3 = unitType1.equals(obj2);
        java.lang.Object obj4 = null;
        boolean boolean5 = unitType1.equals(obj4);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(unitType1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) true);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType2 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        java.lang.String str3 = lengthAdjustmentType2.toString();
        categoryMarker1.setLabelOffsetType(lengthAdjustmentType2);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryMarker1.setOutlineStroke(stroke5);
        java.awt.Stroke stroke7 = categoryMarker1.getOutlineStroke();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType8 = null;
        try {
            categoryMarker1.setLabelOffsetType(lengthAdjustmentType8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'adj' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(lengthAdjustmentType2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "EXPAND" + "'", str3.equals("EXPAND"));
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        categoryPlot14.setWeight((int) (byte) 0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener17 = null;
        categoryPlot14.addChangeListener(plotChangeListener17);
        org.jfree.chart.axis.AxisLocation axisLocation20 = null;
        categoryPlot14.setRangeAxisLocation((int) (short) 1, axisLocation20);
        org.jfree.chart.plot.Marker marker23 = null;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot();
        xYPlot24.setRangeCrosshairVisible(true);
        boolean boolean27 = xYPlot24.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot();
        xYPlot28.configureDomainAxes();
        org.jfree.chart.util.Layer layer30 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection31 = xYPlot28.getDomainMarkers(layer30);
        java.util.Collection collection32 = xYPlot24.getRangeMarkers(layer30);
        boolean boolean34 = categoryPlot14.removeDomainMarker((-16777216), marker23, layer30, false);
        java.awt.Paint paint35 = null;
        try {
            categoryPlot14.setDomainGridlinePaint(paint35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(layer30);
        org.junit.Assert.assertNull(collection31);
        org.junit.Assert.assertNull(collection32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureDomainAxes();
        java.awt.geom.Point2D point2D2 = xYPlot0.getQuadrantOrigin();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        boolean boolean4 = dateAxis3.isAutoTickUnitSelection();
        java.awt.Shape shape5 = dateAxis3.getLeftArrow();
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        xYPlot6.setRangeCrosshairVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        xYPlot6.setInsets(rectangleInsets9, true);
        java.awt.Paint paint12 = xYPlot6.getDomainTickBandPaint();
        java.lang.String str13 = xYPlot6.getPlotType();
        boolean boolean14 = dateAxis3.hasListener((java.util.EventListener) xYPlot6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis("");
        float float20 = categoryAxis19.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        boolean boolean22 = dateAxis21.isAutoTickUnitSelection();
        org.jfree.data.Range range23 = dateAxis21.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot24 = dateAxis21.getPlot();
        dateAxis21.setLabelURL("hi!");
        dateAxis21.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis21, categoryItemRenderer30);
        categoryPlot31.setWeight((int) (byte) 0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener34 = null;
        categoryPlot31.addChangeListener(plotChangeListener34);
        java.awt.Color color36 = java.awt.Color.YELLOW;
        categoryPlot31.setDomainGridlinePaint((java.awt.Paint) color36);
        org.jfree.data.category.CategoryDataset categoryDataset39 = null;
        categoryPlot31.setDataset((int) (short) 10, categoryDataset39);
        float float41 = categoryPlot31.getBackgroundAlpha();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo43 = null;
        org.jfree.chart.plot.XYPlot xYPlot44 = new org.jfree.chart.plot.XYPlot();
        xYPlot44.configureDomainAxes();
        java.awt.geom.Point2D point2D46 = xYPlot44.getQuadrantOrigin();
        categoryPlot31.zoomDomainAxes(0.0d, plotRenderingInfo43, point2D46, false);
        xYPlot6.zoomDomainAxes((-1.0d), plotRenderingInfo16, point2D46, true);
        xYPlot0.setQuadrantOrigin(point2D46);
        org.junit.Assert.assertNotNull(point2D2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "XY Plot" + "'", str13.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 0.0f + "'", float20 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertNull(plot24);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertTrue("'" + float41 + "' != '" + 1.0f + "'", float41 == 1.0f);
        org.junit.Assert.assertNotNull(point2D46);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        categoryPlot14.setWeight((int) (byte) 0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener17 = null;
        categoryPlot14.addChangeListener(plotChangeListener17);
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener20 = null;
        xYPlot19.addChangeListener(plotChangeListener20);
        java.awt.Paint paint22 = xYPlot19.getOutlinePaint();
        java.awt.Stroke stroke23 = xYPlot19.getRangeZeroBaselineStroke();
        categoryPlot14.setDomainGridlineStroke(stroke23);
        org.jfree.chart.axis.AxisSpace axisSpace25 = categoryPlot14.getFixedDomainAxisSpace();
        categoryPlot14.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        java.awt.geom.Point2D point2D30 = null;
        categoryPlot14.zoomDomainAxes((double) '4', plotRenderingInfo29, point2D30);
        org.jfree.chart.util.SortOrder sortOrder32 = categoryPlot14.getRowRenderingOrder();
        java.awt.Stroke stroke33 = categoryPlot14.getDomainGridlineStroke();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNull(axisSpace25);
        org.junit.Assert.assertNotNull(sortOrder32);
        org.junit.Assert.assertNotNull(stroke33);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        categoryPlot14.setWeight((int) (byte) 0);
        org.jfree.chart.util.SortOrder sortOrder17 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot14.setRowRenderingOrder(sortOrder17);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        boolean boolean20 = dateAxis19.isAutoTickUnitSelection();
        org.jfree.data.Range range21 = dateAxis19.getDefaultAutoRange();
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        boolean boolean23 = dateAxis22.isAutoTickUnitSelection();
        org.jfree.data.Range range24 = dateAxis22.getDefaultAutoRange();
        dateAxis19.setRangeWithMargins(range24);
        categoryPlot14.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis19);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = categoryPlot14.getDomainAxisEdge(0);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = categoryPlot14.getRenderer(255);
        java.awt.Graphics2D graphics2D31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        try {
            categoryPlot14.drawBackground(graphics2D31, rectangle2D32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(sortOrder17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertNull(categoryItemRenderer30);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat2 = numberAxis1.getNumberFormatOverride();
        org.jfree.data.RangeType rangeType3 = numberAxis1.getRangeType();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.setRangeCrosshairVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        xYPlot5.setInsets(rectangleInsets8, true);
        java.awt.Paint paint11 = xYPlot5.getDomainTickBandPaint();
        java.lang.String str12 = xYPlot5.getPlotType();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = xYPlot5.getInsets();
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("");
        float float18 = categoryAxis17.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        boolean boolean20 = dateAxis19.isAutoTickUnitSelection();
        org.jfree.data.Range range21 = dateAxis19.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot22 = dateAxis19.getPlot();
        dateAxis19.setLabelURL("hi!");
        dateAxis19.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis17, (org.jfree.chart.axis.ValueAxis) dateAxis19, categoryItemRenderer28);
        categoryPlot29.setWeight((int) (byte) 0);
        org.jfree.chart.util.SortOrder sortOrder32 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot29.setRowRenderingOrder(sortOrder32);
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        boolean boolean35 = dateAxis34.isAutoTickUnitSelection();
        org.jfree.data.Range range36 = dateAxis34.getDefaultAutoRange();
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis();
        boolean boolean38 = dateAxis37.isAutoTickUnitSelection();
        org.jfree.data.Range range39 = dateAxis37.getDefaultAutoRange();
        dateAxis34.setRangeWithMargins(range39);
        categoryPlot29.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis34);
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = categoryPlot29.getDomainAxisEdge(0);
        org.jfree.chart.axis.AxisSpace axisSpace44 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace45 = numberAxis1.reserveSpace(graphics2D4, (org.jfree.chart.plot.Plot) xYPlot5, rectangle2D14, rectangleEdge43, axisSpace44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(numberFormat2);
        org.junit.Assert.assertNotNull(rangeType3);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "XY Plot" + "'", str12.equals("XY Plot"));
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.0f + "'", float18 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(sortOrder32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(range36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(range39);
        org.junit.Assert.assertNotNull(rectangleEdge43);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureDomainAxes();
        org.jfree.chart.util.Layer layer2 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection3 = xYPlot0.getDomainMarkers(layer2);
        boolean boolean4 = xYPlot0.isDomainGridlinesVisible();
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.setRangeCrosshairVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        xYPlot5.setInsets(rectangleInsets8, true);
        java.awt.Paint paint11 = xYPlot5.getDomainTickBandPaint();
        java.lang.String str12 = xYPlot5.getPlotType();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape14 = dateAxis13.getLeftArrow();
        java.awt.Paint paint15 = dateAxis13.getAxisLinePaint();
        int int16 = xYPlot5.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis13);
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot();
        xYPlot17.setRangeCrosshairVisible(true);
        boolean boolean20 = xYPlot17.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot();
        xYPlot21.configureDomainAxes();
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection24 = xYPlot21.getDomainMarkers(layer23);
        java.util.Collection collection25 = xYPlot17.getRangeMarkers(layer23);
        java.awt.Stroke stroke26 = xYPlot17.getDomainZeroBaselineStroke();
        dateAxis13.setTickMarkStroke(stroke26);
        xYPlot0.setOutlineStroke(stroke26);
        java.awt.Paint paint29 = xYPlot0.getRangeTickBandPaint();
        org.junit.Assert.assertNotNull(layer2);
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "XY Plot" + "'", str12.equals("XY Plot"));
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNull(paint29);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        xYPlot1.configureDomainAxes();
        java.lang.String str3 = xYPlot1.getNoDataMessage();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot1.zoomRangeAxes((double) 10.0f, (double) 1L, plotRenderingInfo6, point2D7);
        int int9 = objectList0.indexOf((java.lang.Object) point2D7);
        java.awt.Paint[] paintArray10 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Paint[] paintArray11 = new java.awt.Paint[] {};
        java.awt.Stroke[] strokeArray12 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray13 = new java.awt.Stroke[] {};
        java.awt.Shape shape14 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape[] shapeArray15 = new java.awt.Shape[] { shape14 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier16 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray10, paintArray11, strokeArray12, strokeArray13, shapeArray15);
        java.awt.Stroke stroke17 = defaultDrawingSupplier16.getNextStroke();
        int int18 = objectList0.indexOf((java.lang.Object) defaultDrawingSupplier16);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape20 = dateAxis19.getLeftArrow();
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis("");
        float float25 = categoryAxis24.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        boolean boolean27 = dateAxis26.isAutoTickUnitSelection();
        org.jfree.data.Range range28 = dateAxis26.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot29 = dateAxis26.getPlot();
        dateAxis26.setLabelURL("hi!");
        dateAxis26.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis24, (org.jfree.chart.axis.ValueAxis) dateAxis26, categoryItemRenderer35);
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis();
        dateAxis37.setTickMarksVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource40 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis37.setStandardTickUnits(tickUnitSource40);
        java.text.DateFormat dateFormat42 = null;
        dateAxis37.setDateFormatOverride(dateFormat42);
        dateAxis37.setTickMarksVisible(true);
        dateAxis37.setRange((double) (-1L), 1.0E-8d);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer49 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot50 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis24, (org.jfree.chart.axis.ValueAxis) dateAxis37, categoryItemRenderer49);
        java.awt.Font font52 = categoryAxis24.getTickLabelFont((java.lang.Comparable) 'a');
        dateAxis19.setLabelFont(font52);
        java.util.Date date54 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis19.setMinimumDate(date54);
        java.util.TimeZone timeZone56 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day(date54, timeZone56);
        int int58 = objectList0.indexOf((java.lang.Object) date54);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(paintArray10);
        org.junit.Assert.assertNotNull(paintArray11);
        org.junit.Assert.assertNotNull(strokeArray12);
        org.junit.Assert.assertNotNull(strokeArray13);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(shapeArray15);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.0f + "'", float25 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertNull(plot29);
        org.junit.Assert.assertNotNull(tickUnitSource40);
        org.junit.Assert.assertNotNull(font52);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertNotNull(timeZone56);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + (-1) + "'", int58 == (-1));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        java.awt.Color color0 = java.awt.Color.magenta;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getLeftArrow();
        java.util.TimeZone timeZone2 = dateAxis0.getTimeZone();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("");
        float float8 = categoryAxis7.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        boolean boolean10 = dateAxis9.isAutoTickUnitSelection();
        org.jfree.data.Range range11 = dateAxis9.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot12 = dateAxis9.getPlot();
        dateAxis9.setLabelURL("hi!");
        dateAxis9.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis9, categoryItemRenderer18);
        categoryPlot19.setWeight((int) (byte) 0);
        org.jfree.chart.util.SortOrder sortOrder22 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot19.setRowRenderingOrder(sortOrder22);
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis();
        boolean boolean25 = dateAxis24.isAutoTickUnitSelection();
        org.jfree.data.Range range26 = dateAxis24.getDefaultAutoRange();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        boolean boolean28 = dateAxis27.isAutoTickUnitSelection();
        org.jfree.data.Range range29 = dateAxis27.getDefaultAutoRange();
        dateAxis24.setRangeWithMargins(range29);
        categoryPlot19.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis24);
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = categoryPlot19.getDomainAxisEdge(0);
        try {
            double double34 = dateAxis0.lengthToJava2D((double) 1L, rectangle2D4, rectangleEdge33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.0f + "'", float8 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNull(plot12);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertNotNull(rectangleEdge33);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        boolean boolean3 = xYPlot0.isRangeCrosshairLockedOnData();
        java.lang.String str4 = xYPlot0.getPlotType();
        java.awt.Stroke stroke5 = xYPlot0.getRangeGridlineStroke();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "XY Plot" + "'", str4.equals("XY Plot"));
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        categoryPlot14.setWeight((int) (byte) 0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener17 = null;
        categoryPlot14.addChangeListener(plotChangeListener17);
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener20 = null;
        xYPlot19.addChangeListener(plotChangeListener20);
        java.awt.Paint paint22 = xYPlot19.getOutlinePaint();
        java.awt.Stroke stroke23 = xYPlot19.getRangeZeroBaselineStroke();
        categoryPlot14.setDomainGridlineStroke(stroke23);
        org.jfree.chart.plot.CategoryMarker categoryMarker27 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) true);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType28 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        java.lang.String str29 = lengthAdjustmentType28.toString();
        categoryMarker27.setLabelOffsetType(lengthAdjustmentType28);
        java.awt.Stroke stroke31 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryMarker27.setOutlineStroke(stroke31);
        java.awt.Stroke stroke33 = categoryMarker27.getOutlineStroke();
        org.jfree.chart.util.Layer layer34 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot14.addDomainMarker(0, categoryMarker27, layer34, false);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(lengthAdjustmentType28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "EXPAND" + "'", str29.equals("EXPAND"));
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(layer34);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 255, jFreeChart1);
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 1, jFreeChart4, chartChangeEventType5);
        chartChangeEvent2.setType(chartChangeEventType5);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        xYPlot8.setRangeCrosshairVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        xYPlot8.setInsets(rectangleInsets11, true);
        java.lang.Object obj14 = xYPlot8.clone();
        xYPlot8.setDomainZeroBaselineVisible(false);
        boolean boolean17 = chartChangeEventType5.equals((java.lang.Object) xYPlot8);
        org.junit.Assert.assertNotNull(chartChangeEventType5);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.ASCENDING;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        float float4 = categoryAxis3.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        boolean boolean6 = dateAxis5.isAutoTickUnitSelection();
        org.jfree.data.Range range7 = dateAxis5.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot8 = dateAxis5.getPlot();
        dateAxis5.setLabelURL("hi!");
        dateAxis5.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer14);
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot();
        xYPlot17.setRangeCrosshairVisible(true);
        boolean boolean20 = xYPlot17.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot();
        xYPlot21.configureDomainAxes();
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection24 = xYPlot21.getDomainMarkers(layer23);
        java.util.Collection collection25 = xYPlot17.getRangeMarkers(layer23);
        java.util.Collection collection26 = categoryPlot15.getRangeMarkers((int) (byte) 1, layer23);
        java.util.List list27 = categoryPlot15.getCategories();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = categoryPlot15.getAxisOffset();
        double double30 = rectangleInsets28.extendHeight((double) 10);
        org.jfree.chart.util.UnitType unitType31 = rectangleInsets28.getUnitType();
        boolean boolean32 = sortOrder0.equals((java.lang.Object) rectangleInsets28);
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertNull(collection26);
        org.junit.Assert.assertNull(list27);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 18.0d + "'", double30 == 18.0d);
        org.junit.Assert.assertNotNull(unitType31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        boolean boolean3 = xYPlot0.isRangeCrosshairLockedOnData();
        xYPlot0.setRangeCrosshairVisible(false);
        boolean boolean6 = xYPlot0.isDomainGridlinesVisible();
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = xYPlot0.getOrientation();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(plotOrientation7);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        xYPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = xYPlot0.getOutlinePaint();
        org.jfree.chart.util.Layer layer4 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(layer4);
        boolean boolean6 = xYPlot0.isSubplot();
        java.awt.Paint paint7 = xYPlot0.getRangeGridlinePaint();
        xYPlot0.mapDatasetToDomainAxis(0, (int) (byte) -1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener11 = null;
        xYPlot0.removeChangeListener(plotChangeListener11);
        java.awt.Color color15 = java.awt.Color.orange;
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis("");
        float float19 = categoryAxis18.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean21 = dateAxis20.isAutoTickUnitSelection();
        org.jfree.data.Range range22 = dateAxis20.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot23 = dateAxis20.getPlot();
        dateAxis20.setLabelURL("hi!");
        dateAxis20.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis20, categoryItemRenderer29);
        org.jfree.chart.plot.Marker marker31 = null;
        boolean boolean32 = categoryPlot30.removeDomainMarker(marker31);
        java.util.List list33 = categoryPlot30.getAnnotations();
        java.awt.Stroke stroke34 = categoryPlot30.getRangeGridlineStroke();
        java.awt.Color color35 = org.jfree.chart.ChartColor.LIGHT_RED;
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot();
        xYPlot36.setRangeCrosshairVisible(true);
        boolean boolean39 = xYPlot36.isRangeCrosshairLockedOnData();
        java.awt.Graphics2D graphics2D40 = null;
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        java.util.List list42 = null;
        xYPlot36.drawDomainTickBands(graphics2D40, rectangle2D41, list42);
        double double44 = xYPlot36.getRangeCrosshairValue();
        java.awt.Stroke stroke45 = xYPlot36.getOutlineStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker47 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0, (java.awt.Paint) color15, stroke34, (java.awt.Paint) color35, stroke45, (float) (short) 1);
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener49 = null;
        xYPlot48.addChangeListener(plotChangeListener49);
        java.awt.Paint paint51 = xYPlot48.getOutlinePaint();
        org.jfree.chart.util.Layer layer52 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection53 = xYPlot48.getRangeMarkers(layer52);
        xYPlot0.addDomainMarker(0, (org.jfree.chart.plot.Marker) categoryMarker47, layer52);
        categoryMarker47.setAlpha(0.0f);
        org.jfree.chart.text.TextAnchor textAnchor57 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        java.lang.String str58 = textAnchor57.toString();
        categoryMarker47.setLabelTextAnchor(textAnchor57);
        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day();
        java.util.Date date61 = day60.getEnd();
        boolean boolean62 = textAnchor57.equals((java.lang.Object) day60);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(layer4);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 0.0f + "'", float19 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNull(plot23);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(list33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertNotNull(layer52);
        org.junit.Assert.assertNull(collection53);
        org.junit.Assert.assertNotNull(textAnchor57);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "TextAnchor.HALF_ASCENT_CENTER" + "'", str58.equals("TextAnchor.HALF_ASCENT_CENTER"));
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        categoryAxis2.setLabel("hi!");
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        xYPlot6.configureDomainAxes();
        org.jfree.chart.util.Layer layer8 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection9 = xYPlot6.getDomainMarkers(layer8);
        double double10 = xYPlot6.getRangeCrosshairValue();
        categoryAxis2.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot6);
        boolean boolean12 = datasetRenderingOrder0.equals((java.lang.Object) xYPlot6);
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNotNull(layer8);
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        boolean boolean3 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        xYPlot4.configureDomainAxes();
        org.jfree.chart.util.Layer layer6 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection7 = xYPlot4.getDomainMarkers(layer6);
        java.util.Collection collection8 = xYPlot0.getRangeMarkers(layer6);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setParent((org.jfree.chart.plot.Plot) xYPlot9);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        xYPlot9.rendererChanged(rendererChangeEvent11);
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        xYPlot13.setRangeCrosshairVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        xYPlot13.setInsets(rectangleInsets16, true);
        java.awt.Paint paint19 = xYPlot13.getDomainTickBandPaint();
        java.lang.String str20 = xYPlot13.getPlotType();
        org.jfree.chart.LegendItemCollection legendItemCollection21 = xYPlot13.getLegendItems();
        xYPlot9.setFixedLegendItems(legendItemCollection21);
        java.awt.Paint paint23 = xYPlot9.getRangeGridlinePaint();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(layer6);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNull(paint19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "XY Plot" + "'", str20.equals("XY Plot"));
        org.junit.Assert.assertNotNull(legendItemCollection21);
        org.junit.Assert.assertNotNull(paint23);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        java.lang.String str1 = textAnchor0.toString();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextAnchor.HALF_ASCENT_LEFT" + "'", str1.equals("TextAnchor.HALF_ASCENT_LEFT"));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat2 = numberAxis1.getNumberFormatOverride();
        org.jfree.data.RangeType rangeType3 = numberAxis1.getRangeType();
        boolean boolean4 = numberAxis1.isTickMarksVisible();
        double double5 = numberAxis1.getUpperMargin();
        numberAxis1.setFixedDimension((double) 3);
        java.awt.Shape shape8 = numberAxis1.getUpArrow();
        numberAxis1.setAutoRangeMinimumSize(100.0d, true);
        org.junit.Assert.assertNull(numberFormat2);
        org.junit.Assert.assertNotNull(rangeType3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairValue((double) (-1L));
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        float float6 = categoryAxis5.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isAutoTickUnitSelection();
        org.jfree.data.Range range9 = dateAxis7.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot10 = dateAxis7.getPlot();
        dateAxis7.setLabelURL("hi!");
        dateAxis7.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer16);
        categoryPlot17.setWeight((int) (byte) 0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener20 = null;
        categoryPlot17.addChangeListener(plotChangeListener20);
        java.awt.Color color22 = java.awt.Color.YELLOW;
        categoryPlot17.setDomainGridlinePaint((java.awt.Paint) color22);
        xYPlot0.setRangeTickBandPaint((java.awt.Paint) color22);
        java.awt.Color color25 = java.awt.Color.YELLOW;
        java.awt.Color color26 = color25.darker();
        java.awt.Color color27 = java.awt.Color.red;
        java.awt.image.ColorModel colorModel28 = null;
        java.awt.Rectangle rectangle29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        java.awt.geom.AffineTransform affineTransform31 = null;
        java.awt.RenderingHints renderingHints32 = null;
        java.awt.PaintContext paintContext33 = color27.createContext(colorModel28, rectangle29, rectangle2D30, affineTransform31, renderingHints32);
        java.awt.Color color34 = color27.darker();
        java.awt.color.ColorSpace colorSpace35 = color27.getColorSpace();
        float[] floatArray41 = new float[] { 2, (byte) 0, 0L, '4', 9 };
        float[] floatArray42 = color27.getRGBComponents(floatArray41);
        float[] floatArray43 = color26.getColorComponents(floatArray41);
        float[] floatArray44 = color22.getColorComponents(floatArray41);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNull(plot10);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(paintContext33);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(colorSpace35);
        org.junit.Assert.assertNotNull(floatArray41);
        org.junit.Assert.assertNotNull(floatArray42);
        org.junit.Assert.assertNotNull(floatArray43);
        org.junit.Assert.assertNotNull(floatArray44);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        xYPlot16.setRangeCrosshairVisible(true);
        boolean boolean19 = xYPlot16.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        xYPlot20.configureDomainAxes();
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection23 = xYPlot20.getDomainMarkers(layer22);
        java.util.Collection collection24 = xYPlot16.getRangeMarkers(layer22);
        java.util.Collection collection25 = categoryPlot14.getRangeMarkers((int) (byte) 1, layer22);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = categoryPlot14.getRangeAxisEdge((int) ' ');
        categoryPlot14.setRangeGridlinesVisible(true);
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot();
        xYPlot30.setRangeCrosshairVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        xYPlot30.setInsets(rectangleInsets33, true);
        categoryPlot14.setAxisOffset(rectangleInsets33);
        java.awt.Paint paint37 = categoryPlot14.getDomainGridlinePaint();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertNull(collection23);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertNotNull(paint37);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        java.awt.Color color0 = java.awt.Color.YELLOW;
        int int1 = color0.getGreen();
        int int2 = color0.getTransparency();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_INCLUDES_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        org.jfree.chart.plot.Marker marker15 = null;
        boolean boolean16 = categoryPlot14.removeDomainMarker(marker15);
        java.util.List list17 = categoryPlot14.getAnnotations();
        java.awt.Stroke stroke18 = categoryPlot14.getRangeGridlineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        categoryPlot14.setDataset(categoryDataset19);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(list17);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        xYPlot0.setInsets(rectangleInsets3, true);
        java.awt.Paint paint6 = xYPlot0.getDomainTickBandPaint();
        java.lang.String str7 = xYPlot0.getPlotType();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape9 = dateAxis8.getLeftArrow();
        java.awt.Paint paint10 = dateAxis8.getAxisLinePaint();
        int int11 = xYPlot0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis8);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setTickMarksVisible(true);
        org.jfree.chart.event.AxisChangeListener axisChangeListener15 = null;
        dateAxis12.removeChangeListener(axisChangeListener15);
        java.awt.Font font17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis12.setTickLabelFont(font17);
        dateAxis12.setNegativeArrowVisible(false);
        xYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis12);
        java.awt.Stroke stroke22 = xYPlot0.getOutlineStroke();
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYPlot0.setDomainZeroBaselinePaint((java.awt.Paint) color23);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "XY Plot" + "'", str7.equals("XY Plot"));
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(color23);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setTickMarksVisible(true);
        org.jfree.chart.event.AxisChangeListener axisChangeListener3 = null;
        dateAxis0.removeChangeListener(axisChangeListener3);
        java.awt.Font font5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis0.setTickLabelFont(font5);
        java.util.TimeZone timeZone7 = dateAxis0.getTimeZone();
        dateAxis0.setInverted(false);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(timeZone7);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        categoryPlot14.setWeight((int) (byte) 0);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        categoryPlot14.setRenderer(categoryItemRenderer17);
        org.jfree.chart.axis.ValueAxis valueAxis20 = categoryPlot14.getRangeAxis(3);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = categoryPlot14.getDomainAxis((-16777216));
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNull(valueAxis20);
        org.junit.Assert.assertNull(categoryAxis22);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        java.awt.Color color0 = java.awt.Color.MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat2 = numberAxis1.getNumberFormatOverride();
        org.jfree.data.RangeType rangeType3 = numberAxis1.getRangeType();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis1.setMarkerBand(markerAxisBand4);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis7.configure();
        double double9 = numberAxis7.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat12 = numberAxis11.getNumberFormatOverride();
        org.jfree.data.RangeType rangeType13 = numberAxis11.getRangeType();
        numberAxis7.setRangeType(rangeType13);
        numberAxis1.setRangeType(rangeType13);
        numberAxis1.setLabelToolTip("EXPAND");
        numberAxis1.setFixedAutoRange((double) (-1.0f));
        org.junit.Assert.assertNull(numberFormat2);
        org.junit.Assert.assertNotNull(rangeType3);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNull(numberFormat12);
        org.junit.Assert.assertNotNull(rangeType13);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat2 = numberAxis1.getNumberFormatOverride();
        org.jfree.data.RangeType rangeType3 = numberAxis1.getRangeType();
        boolean boolean4 = numberAxis1.getAutoRangeIncludesZero();
        java.awt.Color color5 = java.awt.Color.orange;
        numberAxis1.setTickMarkPaint((java.awt.Paint) color5);
        org.junit.Assert.assertNull(numberFormat2);
        org.junit.Assert.assertNotNull(rangeType3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isAutoTickUnitSelection();
        org.jfree.data.Range range2 = dateAxis0.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot3 = dateAxis0.getPlot();
        boolean boolean4 = dateAxis0.isNegativeArrowVisible();
        org.jfree.data.general.Dataset dataset5 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent6 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) boolean4, dataset5);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        float float4 = categoryAxis3.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        boolean boolean6 = dateAxis5.isAutoTickUnitSelection();
        org.jfree.data.Range range7 = dateAxis5.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot8 = dateAxis5.getPlot();
        dateAxis5.setLabelURL("hi!");
        dateAxis5.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer14);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        dateAxis16.setTickMarksVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource19 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis16.setStandardTickUnits(tickUnitSource19);
        java.text.DateFormat dateFormat21 = null;
        dateAxis16.setDateFormatOverride(dateFormat21);
        dateAxis16.setTickMarksVisible(true);
        dateAxis16.setRange((double) (-1L), 1.0E-8d);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis16, categoryItemRenderer28);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray30 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot29.setRenderers(categoryItemRendererArray30);
        int int32 = categoryPlot29.getDomainAxisCount();
        org.jfree.chart.axis.AxisSpace axisSpace33 = null;
        categoryPlot29.setFixedDomainAxisSpace(axisSpace33, true);
        int int36 = categoryPlot29.getDomainAxisCount();
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(tickUnitSource19);
        org.junit.Assert.assertNotNull(categoryItemRendererArray30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        categoryPlot14.setWeight((int) (byte) 0);
        org.jfree.chart.util.SortOrder sortOrder17 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot14.setRowRenderingOrder(sortOrder17);
        org.jfree.chart.LegendItemCollection legendItemCollection19 = categoryPlot14.getFixedLegendItems();
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = categoryPlot14.getDomainAxisForDataset(0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(sortOrder17);
        org.junit.Assert.assertNull(legendItemCollection19);
        org.junit.Assert.assertNotNull(categoryAxis21);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ChartChangeEventType.DATASET_UPDATED");
        numberAxis1.setLowerBound((double) 1560409200000L);
        boolean boolean4 = numberAxis1.isPositiveArrowVisible();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        boolean boolean6 = dateAxis5.isAutoTickUnitSelection();
        org.jfree.data.Range range7 = dateAxis5.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot8 = dateAxis5.getPlot();
        java.util.Date date9 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis5.setMinimumDate(date9);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isAutoTickUnitSelection();
        org.jfree.data.Range range13 = dateAxis11.getDefaultAutoRange();
        dateAxis5.setRangeWithMargins(range13, false, false);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis("");
        float float20 = categoryAxis19.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        boolean boolean22 = dateAxis21.isAutoTickUnitSelection();
        org.jfree.data.Range range23 = dateAxis21.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot24 = dateAxis21.getPlot();
        dateAxis21.setLabelURL("hi!");
        dateAxis21.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis21, categoryItemRenderer30);
        java.awt.Font font33 = categoryAxis19.getTickLabelFont((java.lang.Comparable) 0.0f);
        dateAxis5.setLabelFont(font33);
        numberAxis1.setTickLabelFont(font33);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 0.0f + "'", float20 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertNull(plot24);
        org.junit.Assert.assertNotNull(font33);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        xYPlot16.setRangeCrosshairVisible(true);
        boolean boolean19 = xYPlot16.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        xYPlot20.configureDomainAxes();
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection23 = xYPlot20.getDomainMarkers(layer22);
        java.util.Collection collection24 = xYPlot16.getRangeMarkers(layer22);
        java.util.Collection collection25 = categoryPlot14.getRangeMarkers((int) (byte) 1, layer22);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = categoryPlot14.getRangeAxisEdge((int) ' ');
        categoryPlot14.setRangeGridlinesVisible(true);
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot();
        xYPlot30.setRangeCrosshairVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        xYPlot30.setInsets(rectangleInsets33, true);
        categoryPlot14.setAxisOffset(rectangleInsets33);
        double double37 = rectangleInsets33.getBottom();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertNull(collection23);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat2 = numberAxis1.getNumberFormatOverride();
        org.jfree.data.RangeType rangeType3 = numberAxis1.getRangeType();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis1.setMarkerBand(markerAxisBand4);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis7.configure();
        double double9 = numberAxis7.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat12 = numberAxis11.getNumberFormatOverride();
        org.jfree.data.RangeType rangeType13 = numberAxis11.getRangeType();
        numberAxis7.setRangeType(rangeType13);
        numberAxis1.setRangeType(rangeType13);
        org.jfree.data.RangeType rangeType16 = numberAxis1.getRangeType();
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis18.configure();
        java.lang.Object obj20 = numberAxis18.clone();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit21 = numberAxis18.getTickUnit();
        numberAxis1.setTickUnit(numberTickUnit21);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand23 = numberAxis1.getMarkerBand();
        org.junit.Assert.assertNull(numberFormat2);
        org.junit.Assert.assertNotNull(rangeType3);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNull(numberFormat12);
        org.junit.Assert.assertNotNull(rangeType13);
        org.junit.Assert.assertNotNull(rangeType16);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(numberTickUnit21);
        org.junit.Assert.assertNull(markerAxisBand23);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setTickMarksVisible(true);
        java.lang.Object obj4 = dateAxis1.clone();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        boolean boolean6 = dateAxis5.isAutoTickUnitSelection();
        org.jfree.data.Range range7 = dateAxis5.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot8 = dateAxis5.getPlot();
        dateAxis5.setLabelURL("hi!");
        dateAxis5.setLowerMargin(0.0d);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer13);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("");
        float float18 = categoryAxis17.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        boolean boolean20 = dateAxis19.isAutoTickUnitSelection();
        org.jfree.data.Range range21 = dateAxis19.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot22 = dateAxis19.getPlot();
        dateAxis19.setLabelURL("hi!");
        dateAxis19.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis17, (org.jfree.chart.axis.ValueAxis) dateAxis19, categoryItemRenderer28);
        categoryPlot29.setWeight((int) (byte) 0);
        org.jfree.chart.util.SortOrder sortOrder32 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot29.setRowRenderingOrder(sortOrder32);
        org.jfree.chart.LegendItemCollection legendItemCollection34 = categoryPlot29.getFixedLegendItems();
        categoryPlot29.setAnchorValue((double) 255);
        org.jfree.chart.plot.XYPlot xYPlot37 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener38 = null;
        xYPlot37.addChangeListener(plotChangeListener38);
        java.awt.Paint paint40 = xYPlot37.getOutlinePaint();
        float float41 = xYPlot37.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation42 = xYPlot37.getRangeAxisLocation();
        categoryPlot29.setDomainAxisLocation(axisLocation42);
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets45 = dateAxis44.getLabelInsets();
        dateAxis44.setLabel("XY Plot");
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = dateAxis44.getTickLabelInsets();
        categoryPlot29.setInsets(rectangleInsets48);
        xYPlot14.setInsets(rectangleInsets48);
        double double51 = xYPlot14.getRangeCrosshairValue();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.0f + "'", float18 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(sortOrder32);
        org.junit.Assert.assertNull(legendItemCollection34);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertTrue("'" + float41 + "' != '" + 1.0f + "'", float41 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation42);
        org.junit.Assert.assertNotNull(rectangleInsets45);
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        java.awt.Color color1 = java.awt.Color.YELLOW;
        int int2 = color1.getGreen();
        int int3 = color1.getRed();
        int int4 = color1.getTransparency();
        java.awt.Color color5 = java.awt.Color.getColor("SortOrder.ASCENDING", color1);
        java.awt.Color color6 = java.awt.Color.red;
        java.awt.image.ColorModel colorModel7 = null;
        java.awt.Rectangle rectangle8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.awt.geom.AffineTransform affineTransform10 = null;
        java.awt.RenderingHints renderingHints11 = null;
        java.awt.PaintContext paintContext12 = color6.createContext(colorModel7, rectangle8, rectangle2D9, affineTransform10, renderingHints11);
        java.awt.Color color13 = color6.darker();
        java.awt.color.ColorSpace colorSpace14 = color6.getColorSpace();
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_GREEN;
        float[] floatArray16 = null;
        float[] floatArray17 = color15.getColorComponents(floatArray16);
        try {
            float[] floatArray18 = color1.getComponents(colorSpace14, floatArray17);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 255 + "'", int2 == 255);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 255 + "'", int3 == 255);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paintContext12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(colorSpace14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(floatArray17);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        org.jfree.chart.plot.Marker marker15 = null;
        boolean boolean16 = categoryPlot14.removeDomainMarker(marker15);
        categoryPlot14.zoom(2.0d);
        org.jfree.chart.axis.AxisSpace axisSpace19 = categoryPlot14.getFixedRangeAxisSpace();
        java.awt.Color color20 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryPlot14.setDomainGridlinePaint((java.awt.Paint) color20);
        categoryPlot14.clearRangeAxes();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier23 = categoryPlot14.getDrawingSupplier();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(axisSpace19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(drawingSupplier23);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        float float4 = categoryAxis3.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        boolean boolean6 = dateAxis5.isAutoTickUnitSelection();
        org.jfree.data.Range range7 = dateAxis5.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot8 = dateAxis5.getPlot();
        dateAxis5.setLabelURL("hi!");
        dateAxis5.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer14);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        dateAxis16.setTickMarksVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource19 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis16.setStandardTickUnits(tickUnitSource19);
        java.text.DateFormat dateFormat21 = null;
        dateAxis16.setDateFormatOverride(dateFormat21);
        dateAxis16.setTickMarksVisible(true);
        dateAxis16.setRange((double) (-1L), 1.0E-8d);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis16, categoryItemRenderer28);
        java.awt.Font font31 = categoryAxis3.getTickLabelFont((java.lang.Comparable) 'a');
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
        boolean boolean33 = dateAxis32.isAutoTickUnitSelection();
        org.jfree.data.Range range34 = dateAxis32.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot35 = dateAxis32.getPlot();
        java.util.Date date36 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis32.setMinimumDate(date36);
        java.lang.String str38 = categoryAxis3.getCategoryLabelToolTip((java.lang.Comparable) date36);
        categoryAxis3.clearCategoryLabelToolTips();
        org.jfree.chart.axis.NumberAxis numberAxis41 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis41.configure();
        java.lang.Object obj43 = numberAxis41.clone();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit44 = numberAxis41.getTickUnit();
        java.awt.Paint paint45 = categoryAxis3.getTickLabelPaint((java.lang.Comparable) numberTickUnit44);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(tickUnitSource19);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(range34);
        org.junit.Assert.assertNull(plot35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertNotNull(obj43);
        org.junit.Assert.assertNotNull(numberTickUnit44);
        org.junit.Assert.assertNotNull(paint45);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        categoryPlot14.setWeight((int) (byte) 0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener17 = null;
        categoryPlot14.addChangeListener(plotChangeListener17);
        org.jfree.chart.axis.AxisLocation axisLocation20 = null;
        categoryPlot14.setRangeAxisLocation((int) (short) 1, axisLocation20);
        org.jfree.chart.plot.Marker marker23 = null;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot();
        xYPlot24.setRangeCrosshairVisible(true);
        boolean boolean27 = xYPlot24.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot();
        xYPlot28.configureDomainAxes();
        org.jfree.chart.util.Layer layer30 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection31 = xYPlot28.getDomainMarkers(layer30);
        java.util.Collection collection32 = xYPlot24.getRangeMarkers(layer30);
        boolean boolean34 = categoryPlot14.removeDomainMarker((-16777216), marker23, layer30, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor35 = categoryPlot14.getDomainGridlinePosition();
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = categoryPlot14.getRangeAxisEdge(100);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(layer30);
        org.junit.Assert.assertNull(collection31);
        org.junit.Assert.assertNull(collection32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(categoryAnchor35);
        org.junit.Assert.assertNotNull(rectangleEdge37);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isAutoTickUnitSelection();
        org.jfree.data.Range range2 = dateAxis0.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot3 = dateAxis0.getPlot();
        java.util.Date date4 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis0.setMinimumDate(date4);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        boolean boolean7 = dateAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = dateAxis6.getDefaultAutoRange();
        dateAxis0.setRangeWithMargins(range8, false, false);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("");
        float float15 = categoryAxis14.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        boolean boolean17 = dateAxis16.isAutoTickUnitSelection();
        org.jfree.data.Range range18 = dateAxis16.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot19 = dateAxis16.getPlot();
        dateAxis16.setLabelURL("hi!");
        dateAxis16.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis16, categoryItemRenderer25);
        java.awt.Font font28 = categoryAxis14.getTickLabelFont((java.lang.Comparable) 0.0f);
        dateAxis0.setLabelFont(font28);
        dateAxis0.setLowerBound((double) 11);
        try {
            dateAxis0.setRangeWithMargins((double) 4, (double) 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (4.0) <= upper (3.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.0f + "'", float15 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNull(plot19);
        org.junit.Assert.assertNotNull(font28);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        categoryPlot14.setWeight((int) (byte) 0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener17 = null;
        categoryPlot14.addChangeListener(plotChangeListener17);
        java.awt.Color color19 = java.awt.Color.YELLOW;
        categoryPlot14.setDomainGridlinePaint((java.awt.Paint) color19);
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = categoryPlot14.getDomainAxis();
        categoryAxis21.setAxisLineVisible(true);
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot();
        xYPlot25.setRangeCrosshairVisible(true);
        boolean boolean28 = xYPlot25.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot();
        xYPlot29.configureDomainAxes();
        org.jfree.chart.util.Layer layer31 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection32 = xYPlot29.getDomainMarkers(layer31);
        java.util.Collection collection33 = xYPlot25.getRangeMarkers(layer31);
        java.awt.Stroke stroke34 = xYPlot25.getDomainZeroBaselineStroke();
        int int35 = xYPlot25.getRangeAxisCount();
        java.awt.Image image36 = xYPlot25.getBackgroundImage();
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        org.jfree.data.category.CategoryDataset categoryDataset38 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = new org.jfree.chart.axis.CategoryAxis("");
        float float41 = categoryAxis40.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis42 = new org.jfree.chart.axis.DateAxis();
        boolean boolean43 = dateAxis42.isAutoTickUnitSelection();
        org.jfree.data.Range range44 = dateAxis42.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot45 = dateAxis42.getPlot();
        dateAxis42.setLabelURL("hi!");
        dateAxis42.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer51 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot52 = new org.jfree.chart.plot.CategoryPlot(categoryDataset38, categoryAxis40, (org.jfree.chart.axis.ValueAxis) dateAxis42, categoryItemRenderer51);
        org.jfree.chart.plot.XYPlot xYPlot54 = new org.jfree.chart.plot.XYPlot();
        xYPlot54.setRangeCrosshairVisible(true);
        boolean boolean57 = xYPlot54.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot58 = new org.jfree.chart.plot.XYPlot();
        xYPlot58.configureDomainAxes();
        org.jfree.chart.util.Layer layer60 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection61 = xYPlot58.getDomainMarkers(layer60);
        java.util.Collection collection62 = xYPlot54.getRangeMarkers(layer60);
        java.util.Collection collection63 = categoryPlot52.getRangeMarkers((int) (byte) 1, layer60);
        org.jfree.chart.util.RectangleEdge rectangleEdge65 = categoryPlot52.getRangeAxisEdge((int) ' ');
        org.jfree.chart.axis.AxisSpace axisSpace66 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace67 = categoryAxis21.reserveSpace(graphics2D24, (org.jfree.chart.plot.Plot) xYPlot25, rectangle2D37, rectangleEdge65, axisSpace66);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(categoryAxis21);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(layer31);
        org.junit.Assert.assertNull(collection32);
        org.junit.Assert.assertNull(collection33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNull(image36);
        org.junit.Assert.assertTrue("'" + float41 + "' != '" + 0.0f + "'", float41 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(range44);
        org.junit.Assert.assertNull(plot45);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertNotNull(layer60);
        org.junit.Assert.assertNull(collection61);
        org.junit.Assert.assertNull(collection62);
        org.junit.Assert.assertNull(collection63);
        org.junit.Assert.assertNotNull(rectangleEdge65);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        float float4 = categoryAxis3.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        boolean boolean6 = dateAxis5.isAutoTickUnitSelection();
        org.jfree.data.Range range7 = dateAxis5.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot8 = dateAxis5.getPlot();
        dateAxis5.setLabelURL("hi!");
        dateAxis5.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer14);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        dateAxis16.setTickMarksVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource19 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis16.setStandardTickUnits(tickUnitSource19);
        java.text.DateFormat dateFormat21 = null;
        dateAxis16.setDateFormatOverride(dateFormat21);
        dateAxis16.setTickMarksVisible(true);
        dateAxis16.setRange((double) (-1L), 1.0E-8d);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis16, categoryItemRenderer28);
        java.util.List list30 = categoryPlot29.getCategories();
        categoryPlot29.clearRangeMarkers();
        java.awt.Paint[] paintArray32 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Paint[] paintArray33 = new java.awt.Paint[] {};
        java.awt.Stroke[] strokeArray34 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray35 = new java.awt.Stroke[] {};
        java.awt.Shape shape36 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape[] shapeArray37 = new java.awt.Shape[] { shape36 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier38 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray32, paintArray33, strokeArray34, strokeArray35, shapeArray37);
        java.awt.Stroke stroke39 = defaultDrawingSupplier38.getNextStroke();
        categoryPlot29.setRangeCrosshairStroke(stroke39);
        categoryPlot29.setAnchorValue(0.0d);
        int int43 = categoryPlot29.getWeight();
        boolean boolean44 = categoryPlot29.isSubplot();
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(tickUnitSource19);
        org.junit.Assert.assertNull(list30);
        org.junit.Assert.assertNotNull(paintArray32);
        org.junit.Assert.assertNotNull(paintArray33);
        org.junit.Assert.assertNotNull(strokeArray34);
        org.junit.Assert.assertNotNull(strokeArray35);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(shapeArray37);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureDomainAxes();
        xYPlot0.zoom((double) 10);
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean6 = xYPlot0.removeDomainMarker(marker4, layer5);
        xYPlot0.clearRangeMarkers();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        boolean boolean10 = dateAxis9.isAutoTickUnitSelection();
        org.jfree.data.Range range11 = dateAxis9.getDefaultAutoRange();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        boolean boolean13 = dateAxis12.isAutoTickUnitSelection();
        org.jfree.data.Range range14 = dateAxis12.getDefaultAutoRange();
        dateAxis9.setRangeWithMargins(range14);
        xYPlot0.setRangeAxis(5, (org.jfree.chart.axis.ValueAxis) dateAxis9, false);
        java.awt.Stroke stroke18 = xYPlot0.getDomainZeroBaselineStroke();
        xYPlot0.clearDomainAxes();
        org.junit.Assert.assertNotNull(layer5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) true);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType2 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        java.lang.String str3 = lengthAdjustmentType2.toString();
        categoryMarker1.setLabelOffsetType(lengthAdjustmentType2);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryMarker1.setOutlineStroke(stroke5);
        java.awt.Stroke stroke7 = categoryMarker1.getOutlineStroke();
        java.awt.Paint paint8 = categoryMarker1.getOutlinePaint();
        org.junit.Assert.assertNotNull(lengthAdjustmentType2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "EXPAND" + "'", str3.equals("EXPAND"));
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        float float4 = categoryAxis3.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        boolean boolean6 = dateAxis5.isAutoTickUnitSelection();
        org.jfree.data.Range range7 = dateAxis5.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot8 = dateAxis5.getPlot();
        dateAxis5.setLabelURL("hi!");
        dateAxis5.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer14);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        dateAxis16.setTickMarksVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource19 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis16.setStandardTickUnits(tickUnitSource19);
        java.text.DateFormat dateFormat21 = null;
        dateAxis16.setDateFormatOverride(dateFormat21);
        dateAxis16.setTickMarksVisible(true);
        dateAxis16.setRange((double) (-1L), 1.0E-8d);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis16, categoryItemRenderer28);
        java.util.List list30 = categoryPlot29.getCategories();
        categoryPlot29.clearRangeMarkers();
        java.awt.Paint[] paintArray32 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Paint[] paintArray33 = new java.awt.Paint[] {};
        java.awt.Stroke[] strokeArray34 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray35 = new java.awt.Stroke[] {};
        java.awt.Shape shape36 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape[] shapeArray37 = new java.awt.Shape[] { shape36 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier38 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray32, paintArray33, strokeArray34, strokeArray35, shapeArray37);
        java.awt.Stroke stroke39 = defaultDrawingSupplier38.getNextStroke();
        categoryPlot29.setRangeCrosshairStroke(stroke39);
        categoryPlot29.setAnchorValue(0.0d);
        int int43 = categoryPlot29.getWeight();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer44 = null;
        categoryPlot29.setRenderer(categoryItemRenderer44);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(tickUnitSource19);
        org.junit.Assert.assertNull(list30);
        org.junit.Assert.assertNotNull(paintArray32);
        org.junit.Assert.assertNotNull(paintArray33);
        org.junit.Assert.assertNotNull(strokeArray34);
        org.junit.Assert.assertNotNull(strokeArray35);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(shapeArray37);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        org.jfree.chart.axis.ValueAxis valueAxis15 = categoryPlot14.getRangeAxis();
        java.awt.Stroke stroke16 = categoryPlot14.getRangeGridlineStroke();
        java.awt.Color color17 = java.awt.Color.red;
        java.awt.image.ColorModel colorModel18 = null;
        java.awt.Rectangle rectangle19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        java.awt.geom.AffineTransform affineTransform21 = null;
        java.awt.RenderingHints renderingHints22 = null;
        java.awt.PaintContext paintContext23 = color17.createContext(colorModel18, rectangle19, rectangle2D20, affineTransform21, renderingHints22);
        java.awt.Color color24 = color17.darker();
        java.awt.color.ColorSpace colorSpace25 = color17.getColorSpace();
        int int26 = color17.getTransparency();
        categoryPlot14.setDomainGridlinePaint((java.awt.Paint) color17);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(valueAxis15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(paintContext23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(colorSpace25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ChartChangeEventType.DATASET_UPDATED");
        numberAxis1.setLowerBound((double) 1560409200000L);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis5.configure();
        double double7 = numberAxis5.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat10 = numberAxis9.getNumberFormatOverride();
        org.jfree.data.RangeType rangeType11 = numberAxis9.getRangeType();
        numberAxis5.setRangeType(rangeType11);
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener14 = null;
        xYPlot13.addChangeListener(plotChangeListener14);
        java.awt.Paint paint16 = xYPlot13.getOutlinePaint();
        java.awt.Stroke stroke17 = xYPlot13.getRangeZeroBaselineStroke();
        numberAxis5.setTickMarkStroke(stroke17);
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis20.configure();
        java.lang.Object obj22 = numberAxis20.clone();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit23 = numberAxis20.getTickUnit();
        numberAxis5.setTickUnit(numberTickUnit23);
        numberAxis1.setTickUnit(numberTickUnit23, false, false);
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = new org.jfree.chart.axis.CategoryAxis("");
        float float31 = categoryAxis30.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
        boolean boolean33 = dateAxis32.isAutoTickUnitSelection();
        org.jfree.data.Range range34 = dateAxis32.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot35 = dateAxis32.getPlot();
        dateAxis32.setLabelURL("hi!");
        dateAxis32.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer41 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis30, (org.jfree.chart.axis.ValueAxis) dateAxis32, categoryItemRenderer41);
        categoryPlot42.setWeight((int) (byte) 0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener45 = null;
        categoryPlot42.addChangeListener(plotChangeListener45);
        java.awt.Color color47 = java.awt.Color.YELLOW;
        categoryPlot42.setDomainGridlinePaint((java.awt.Paint) color47);
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = categoryPlot42.getDomainAxis();
        categoryAxis49.setAxisLineVisible(true);
        boolean boolean52 = numberAxis1.equals((java.lang.Object) categoryAxis49);
        boolean boolean53 = numberAxis1.getAutoRangeStickyZero();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNull(numberFormat10);
        org.junit.Assert.assertNotNull(rangeType11);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(numberTickUnit23);
        org.junit.Assert.assertTrue("'" + float31 + "' != '" + 0.0f + "'", float31 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(range34);
        org.junit.Assert.assertNull(plot35);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(categoryAxis49);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("ChartChangeEventType.DATASET_UPDATED");
        numberAxis2.setLowerBound((double) 1560409200000L);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis6.configure();
        double double8 = numberAxis6.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.data.RangeType rangeType12 = numberAxis10.getRangeType();
        numberAxis6.setRangeType(rangeType12);
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        xYPlot14.addChangeListener(plotChangeListener15);
        java.awt.Paint paint17 = xYPlot14.getOutlinePaint();
        java.awt.Stroke stroke18 = xYPlot14.getRangeZeroBaselineStroke();
        numberAxis6.setTickMarkStroke(stroke18);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis21.configure();
        java.lang.Object obj23 = numberAxis21.clone();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit24 = numberAxis21.getTickUnit();
        numberAxis6.setTickUnit(numberTickUnit24);
        numberAxis2.setTickUnit(numberTickUnit24, false, false);
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis30.setUpperBound((double) 10);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = null;
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis30, xYItemRenderer33);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(rangeType12);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertNotNull(numberTickUnit24);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        float float4 = categoryAxis3.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        boolean boolean6 = dateAxis5.isAutoTickUnitSelection();
        org.jfree.data.Range range7 = dateAxis5.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot8 = dateAxis5.getPlot();
        dateAxis5.setLabelURL("hi!");
        dateAxis5.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer14);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        dateAxis16.setTickMarksVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource19 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis16.setStandardTickUnits(tickUnitSource19);
        java.text.DateFormat dateFormat21 = null;
        dateAxis16.setDateFormatOverride(dateFormat21);
        dateAxis16.setTickMarksVisible(true);
        dateAxis16.setRange((double) (-1L), 1.0E-8d);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis16, categoryItemRenderer28);
        java.awt.Font font31 = categoryAxis3.getTickLabelFont((java.lang.Comparable) 'a');
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions32 = categoryAxis3.getCategoryLabelPositions();
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(tickUnitSource19);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(categoryLabelPositions32);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.configure();
        java.lang.Object obj4 = numberAxis2.clone();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = numberAxis2.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = dateAxis6.getLabelInsets();
        dateAxis6.setLabel("XY Plot");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis6, xYItemRenderer10);
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        xYPlot12.setRangeCrosshairVisible(true);
        boolean boolean15 = xYPlot12.isRangeCrosshairLockedOnData();
        java.lang.String str16 = xYPlot12.getPlotType();
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis("");
        float float20 = categoryAxis19.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        boolean boolean22 = dateAxis21.isAutoTickUnitSelection();
        org.jfree.data.Range range23 = dateAxis21.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot24 = dateAxis21.getPlot();
        dateAxis21.setLabelURL("hi!");
        dateAxis21.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis21, categoryItemRenderer30);
        org.jfree.chart.plot.Marker marker32 = null;
        boolean boolean33 = categoryPlot31.removeDomainMarker(marker32);
        java.util.List list34 = categoryPlot31.getAnnotations();
        java.awt.Stroke stroke35 = categoryPlot31.getRangeGridlineStroke();
        xYPlot12.setRangeCrosshairStroke(stroke35);
        numberAxis2.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot12);
        boolean boolean38 = xYPlot12.isRangeGridlinesVisible();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(numberTickUnit5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "XY Plot" + "'", str16.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 0.0f + "'", float20 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertNull(plot24);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(list34);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        float float4 = categoryAxis3.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        boolean boolean6 = dateAxis5.isAutoTickUnitSelection();
        org.jfree.data.Range range7 = dateAxis5.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot8 = dateAxis5.getPlot();
        dateAxis5.setLabelURL("hi!");
        dateAxis5.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer14);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        dateAxis16.setTickMarksVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource19 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis16.setStandardTickUnits(tickUnitSource19);
        java.text.DateFormat dateFormat21 = null;
        dateAxis16.setDateFormatOverride(dateFormat21);
        dateAxis16.setTickMarksVisible(true);
        dateAxis16.setRange((double) (-1L), 1.0E-8d);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis16, categoryItemRenderer28);
        java.util.List list30 = categoryPlot29.getCategories();
        categoryPlot29.clearRangeMarkers();
        java.awt.Paint[] paintArray32 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Paint[] paintArray33 = new java.awt.Paint[] {};
        java.awt.Stroke[] strokeArray34 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray35 = new java.awt.Stroke[] {};
        java.awt.Shape shape36 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape[] shapeArray37 = new java.awt.Shape[] { shape36 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier38 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray32, paintArray33, strokeArray34, strokeArray35, shapeArray37);
        java.awt.Stroke stroke39 = defaultDrawingSupplier38.getNextStroke();
        categoryPlot29.setRangeCrosshairStroke(stroke39);
        categoryPlot29.setRangeCrosshairVisible(false);
        int int43 = categoryPlot29.getDatasetCount();
        categoryPlot29.clearRangeMarkers((int) '#');
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(tickUnitSource19);
        org.junit.Assert.assertNull(list30);
        org.junit.Assert.assertNotNull(paintArray32);
        org.junit.Assert.assertNotNull(paintArray33);
        org.junit.Assert.assertNotNull(strokeArray34);
        org.junit.Assert.assertNotNull(strokeArray35);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(shapeArray37);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        xYPlot1.configureDomainAxes();
        java.lang.String str3 = xYPlot1.getNoDataMessage();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot1.zoomRangeAxes((double) 10.0f, (double) 1L, plotRenderingInfo6, point2D7);
        int int9 = objectList0.indexOf((java.lang.Object) point2D7);
        java.awt.Paint[] paintArray10 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Paint[] paintArray11 = new java.awt.Paint[] {};
        java.awt.Stroke[] strokeArray12 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray13 = new java.awt.Stroke[] {};
        java.awt.Shape shape14 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape[] shapeArray15 = new java.awt.Shape[] { shape14 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier16 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray10, paintArray11, strokeArray12, strokeArray13, shapeArray15);
        java.awt.Stroke stroke17 = defaultDrawingSupplier16.getNextStroke();
        int int18 = objectList0.indexOf((java.lang.Object) defaultDrawingSupplier16);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        dateAxis19.setTickMarksVisible(true);
        org.jfree.chart.event.AxisChangeListener axisChangeListener22 = null;
        dateAxis19.removeChangeListener(axisChangeListener22);
        java.awt.Font font24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis19.setTickLabelFont(font24);
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        boolean boolean27 = dateAxis26.isAutoTickUnitSelection();
        org.jfree.data.Range range28 = dateAxis26.getDefaultAutoRange();
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis();
        boolean boolean30 = dateAxis29.isAutoTickUnitSelection();
        org.jfree.data.Range range31 = dateAxis29.getDefaultAutoRange();
        dateAxis26.setRangeWithMargins(range31);
        dateAxis19.setRange(range31, true, false);
        int int36 = objectList0.indexOf((java.lang.Object) range31);
        java.lang.Object obj37 = objectList0.clone();
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(paintArray10);
        org.junit.Assert.assertNotNull(paintArray11);
        org.junit.Assert.assertNotNull(strokeArray12);
        org.junit.Assert.assertNotNull(strokeArray13);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(shapeArray15);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertNotNull(obj37);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        float float4 = categoryAxis3.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        boolean boolean6 = dateAxis5.isAutoTickUnitSelection();
        org.jfree.data.Range range7 = dateAxis5.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot8 = dateAxis5.getPlot();
        dateAxis5.setLabelURL("hi!");
        dateAxis5.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer14);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        dateAxis16.setTickMarksVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource19 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis16.setStandardTickUnits(tickUnitSource19);
        java.text.DateFormat dateFormat21 = null;
        dateAxis16.setDateFormatOverride(dateFormat21);
        dateAxis16.setTickMarksVisible(true);
        dateAxis16.setRange((double) (-1L), 1.0E-8d);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis16, categoryItemRenderer28);
        java.util.List list30 = categoryPlot29.getCategories();
        java.awt.Font font31 = categoryPlot29.getNoDataMessageFont();
        categoryPlot29.zoom(10.0d);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(tickUnitSource19);
        org.junit.Assert.assertNull(list30);
        org.junit.Assert.assertNotNull(font31);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        xYPlot16.setRangeCrosshairVisible(true);
        boolean boolean19 = xYPlot16.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        xYPlot20.configureDomainAxes();
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection23 = xYPlot20.getDomainMarkers(layer22);
        java.util.Collection collection24 = xYPlot16.getRangeMarkers(layer22);
        java.util.Collection collection25 = categoryPlot14.getRangeMarkers((int) (byte) 1, layer22);
        java.util.List list26 = categoryPlot14.getCategories();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = categoryPlot14.getAxisOffset();
        categoryPlot14.configureRangeAxes();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertNull(collection23);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertNull(list26);
        org.junit.Assert.assertNotNull(rectangleInsets27);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat3 = numberAxis2.getNumberFormatOverride();
        org.jfree.data.RangeType rangeType4 = numberAxis2.getRangeType();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand5 = null;
        numberAxis2.setMarkerBand(markerAxisBand5);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis8.configure();
        double double10 = numberAxis8.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat13 = numberAxis12.getNumberFormatOverride();
        org.jfree.data.RangeType rangeType14 = numberAxis12.getRangeType();
        numberAxis8.setRangeType(rangeType14);
        numberAxis2.setRangeType(rangeType14);
        org.jfree.data.RangeType rangeType17 = numberAxis2.getRangeType();
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis19.configure();
        java.lang.Object obj21 = numberAxis19.clone();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit22 = numberAxis19.getTickUnit();
        numberAxis2.setTickUnit(numberTickUnit22);
        numberAxis0.setTickUnit(numberTickUnit22);
        boolean boolean25 = numberAxis0.isNegativeArrowVisible();
        org.junit.Assert.assertNull(numberFormat3);
        org.junit.Assert.assertNotNull(rangeType4);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNull(numberFormat13);
        org.junit.Assert.assertNotNull(rangeType14);
        org.junit.Assert.assertNotNull(rangeType17);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(numberTickUnit22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis1.configure();
        java.lang.Object obj3 = numberAxis1.clone();
        numberAxis1.setAutoRangeIncludesZero(true);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        boolean boolean7 = dateAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = dateAxis6.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot9 = dateAxis6.getPlot();
        java.util.Date date10 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis6.setMinimumDate(date10);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        boolean boolean13 = dateAxis12.isAutoTickUnitSelection();
        org.jfree.data.Range range14 = dateAxis12.getDefaultAutoRange();
        dateAxis6.setRangeWithMargins(range14, false, false);
        numberAxis1.setRange(range14);
        numberAxis1.setRangeWithMargins(0.0d, 18.0d);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNull(plot9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(range14);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        java.awt.Color color0 = java.awt.Color.black;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isAutoTickUnitSelection();
        java.awt.Shape shape2 = dateAxis0.getLeftArrow();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition3 = dateAxis0.getTickMarkPosition();
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        dateAxis5.setTickMarksVisible(true);
        java.lang.Object obj8 = dateAxis5.clone();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        boolean boolean10 = dateAxis9.isAutoTickUnitSelection();
        org.jfree.data.Range range11 = dateAxis9.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot12 = dateAxis9.getPlot();
        dateAxis9.setLabelURL("hi!");
        dateAxis9.setLowerMargin(0.0d);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset4, (org.jfree.chart.axis.ValueAxis) dateAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis9, xYItemRenderer17);
        boolean boolean19 = dateAxis0.equals((java.lang.Object) xYItemRenderer17);
        java.awt.Font font20 = dateAxis0.getLabelFont();
        java.awt.Paint paint21 = null;
        try {
            dateAxis0.setTickLabelPaint(paint21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(dateTickMarkPosition3);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNull(plot12);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(font20);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureDomainAxes();
        xYPlot0.zoom((double) 10);
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean6 = xYPlot0.removeDomainMarker(marker4, layer5);
        xYPlot0.clearRangeMarkers();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = xYPlot0.getInsets();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        xYPlot0.zoomRangeAxes((double) 3, plotRenderingInfo10, point2D11, false);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis("");
        float float19 = categoryAxis18.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean21 = dateAxis20.isAutoTickUnitSelection();
        org.jfree.data.Range range22 = dateAxis20.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot23 = dateAxis20.getPlot();
        dateAxis20.setLabelURL("hi!");
        dateAxis20.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis20, categoryItemRenderer29);
        org.jfree.chart.plot.Marker marker31 = null;
        boolean boolean32 = categoryPlot30.removeDomainMarker(marker31);
        java.util.List list33 = categoryPlot30.getAnnotations();
        xYPlot0.drawRangeTickBands(graphics2D14, rectangle2D15, list33);
        org.junit.Assert.assertNotNull(layer5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 0.0f + "'", float19 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNull(plot23);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(list33);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        boolean boolean3 = xYPlot0.isRangeCrosshairLockedOnData();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.util.List list6 = null;
        xYPlot0.drawDomainTickBands(graphics2D4, rectangle2D5, list6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        xYPlot0.drawAnnotations(graphics2D8, rectangle2D9, plotRenderingInfo10);
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) true);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType14 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        java.lang.String str15 = lengthAdjustmentType14.toString();
        categoryMarker13.setLabelOffsetType(lengthAdjustmentType14);
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot();
        xYPlot17.setRangeCrosshairVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        xYPlot17.setInsets(rectangleInsets20, true);
        java.awt.Paint paint23 = xYPlot17.getDomainTickBandPaint();
        java.lang.String str24 = xYPlot17.getPlotType();
        org.jfree.chart.plot.Marker marker26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot();
        xYPlot27.setRangeCrosshairVisible(true);
        boolean boolean30 = xYPlot27.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot();
        xYPlot31.configureDomainAxes();
        org.jfree.chart.util.Layer layer33 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection34 = xYPlot31.getDomainMarkers(layer33);
        java.util.Collection collection35 = xYPlot27.getRangeMarkers(layer33);
        boolean boolean37 = xYPlot17.removeDomainMarker((int) ' ', marker26, layer33, false);
        boolean boolean38 = xYPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker13, layer33);
        java.lang.Class class39 = null;
        try {
            java.util.EventListener[] eventListenerArray40 = categoryMarker13.getListeners(class39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(lengthAdjustmentType14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "EXPAND" + "'", str15.equals("EXPAND"));
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNull(paint23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "XY Plot" + "'", str24.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(layer33);
        org.junit.Assert.assertNull(collection34);
        org.junit.Assert.assertNull(collection35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        org.jfree.chart.axis.ValueAxis valueAxis15 = categoryPlot14.getRangeAxis();
        java.awt.Stroke stroke16 = categoryPlot14.getRangeGridlineStroke();
        categoryPlot14.clearRangeAxes();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(valueAxis15);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        java.lang.String str1 = lengthAdjustmentType0.toString();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        xYPlot2.setRangeCrosshairVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        xYPlot2.setInsets(rectangleInsets5, true);
        java.awt.Paint paint8 = xYPlot2.getDomainTickBandPaint();
        java.lang.String str9 = xYPlot2.getPlotType();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape11 = dateAxis10.getLeftArrow();
        java.awt.Paint paint12 = dateAxis10.getAxisLinePaint();
        int int13 = xYPlot2.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis10);
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot();
        xYPlot14.setRangeCrosshairVisible(true);
        boolean boolean17 = xYPlot14.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        xYPlot18.configureDomainAxes();
        org.jfree.chart.util.Layer layer20 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection21 = xYPlot18.getDomainMarkers(layer20);
        java.util.Collection collection22 = xYPlot14.getRangeMarkers(layer20);
        java.awt.Stroke stroke23 = xYPlot14.getDomainZeroBaselineStroke();
        dateAxis10.setTickMarkStroke(stroke23);
        boolean boolean25 = lengthAdjustmentType0.equals((java.lang.Object) dateAxis10);
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis("");
        float float29 = categoryAxis28.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis();
        boolean boolean31 = dateAxis30.isAutoTickUnitSelection();
        org.jfree.data.Range range32 = dateAxis30.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot33 = dateAxis30.getPlot();
        dateAxis30.setLabelURL("hi!");
        dateAxis30.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset26, categoryAxis28, (org.jfree.chart.axis.ValueAxis) dateAxis30, categoryItemRenderer39);
        org.jfree.chart.axis.ValueAxis valueAxis41 = categoryPlot40.getRangeAxis();
        boolean boolean42 = lengthAdjustmentType0.equals((java.lang.Object) categoryPlot40);
        org.jfree.chart.plot.XYPlot xYPlot44 = new org.jfree.chart.plot.XYPlot();
        xYPlot44.configureDomainAxes();
        xYPlot44.zoom((double) 10);
        org.jfree.chart.plot.Marker marker48 = null;
        org.jfree.chart.util.Layer layer49 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean50 = xYPlot44.removeDomainMarker(marker48, layer49);
        double double51 = xYPlot44.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation53 = xYPlot44.getRangeAxisLocation(9);
        try {
            categoryPlot40.setRangeAxisLocation((-128), axisLocation53);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "EXPAND" + "'", str1.equals("EXPAND"));
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "XY Plot" + "'", str9.equals("XY Plot"));
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(layer20);
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 0.0f + "'", float29 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertNull(plot33);
        org.junit.Assert.assertNotNull(valueAxis41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(layer49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation53);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setTickMarksVisible(true);
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        xYPlot3.setRangeCrosshairVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        dateAxis6.setTickMarksVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource9 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis6.setStandardTickUnits(tickUnitSource9);
        java.text.DateFormat dateFormat11 = null;
        dateAxis6.setDateFormatOverride(dateFormat11);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = dateAxis13.getLabelInsets();
        dateAxis6.setTickLabelInsets(rectangleInsets14);
        xYPlot3.setInsets(rectangleInsets14);
        org.jfree.chart.util.UnitType unitType17 = rectangleInsets14.getUnitType();
        dateAxis0.setLabelInsets(rectangleInsets14);
        org.junit.Assert.assertNotNull(tickUnitSource9);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(unitType17);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isAutoTickUnitSelection();
        org.jfree.data.Range range2 = dateAxis0.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot3 = dateAxis0.getPlot();
        java.text.DateFormat dateFormat4 = null;
        dateAxis0.setDateFormatOverride(dateFormat4);
        java.util.Date date6 = null;
        try {
            dateAxis0.setMinimumDate(date6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'date' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        xYPlot16.setRangeCrosshairVisible(true);
        boolean boolean19 = xYPlot16.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        xYPlot20.configureDomainAxes();
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection23 = xYPlot20.getDomainMarkers(layer22);
        java.util.Collection collection24 = xYPlot16.getRangeMarkers(layer22);
        java.util.Collection collection25 = categoryPlot14.getRangeMarkers((int) (byte) 1, layer22);
        double double26 = categoryPlot14.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = new org.jfree.chart.axis.CategoryAxis("");
        float float30 = categoryAxis29.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis();
        boolean boolean32 = dateAxis31.isAutoTickUnitSelection();
        org.jfree.data.Range range33 = dateAxis31.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot34 = dateAxis31.getPlot();
        dateAxis31.setLabelURL("hi!");
        dateAxis31.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer40 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis29, (org.jfree.chart.axis.ValueAxis) dateAxis31, categoryItemRenderer40);
        org.jfree.chart.util.SortOrder sortOrder42 = categoryPlot41.getColumnRenderingOrder();
        categoryPlot14.setColumnRenderingOrder(sortOrder42);
        boolean boolean44 = categoryPlot14.isRangeCrosshairLockedOnData();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertNull(collection23);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 0.0f + "'", float30 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(range33);
        org.junit.Assert.assertNull(plot34);
        org.junit.Assert.assertNotNull(sortOrder42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
    }

//    @Test
//    public void test494() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test494");
//        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
//        double double1 = categoryAxis0.getLowerMargin();
//        categoryAxis0.removeCategoryLabelToolTip((java.lang.Comparable) 1);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        long long5 = day4.getFirstMillisecond();
//        java.lang.String str6 = day4.toString();
//        java.lang.String str7 = categoryAxis0.getCategoryLabelToolTip((java.lang.Comparable) day4);
//        float float8 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
//        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.05d + "'", double1 == 0.05d);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560409200000L + "'", long5 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(str7);
//        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.0f + "'", float8 == 0.0f);
//    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 1, jFreeChart1, chartChangeEventType2);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType4 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.lang.Object obj5 = null;
        boolean boolean6 = chartChangeEventType4.equals(obj5);
        chartChangeEvent3.setType(chartChangeEventType4);
        org.junit.Assert.assertNotNull(chartChangeEventType2);
        org.junit.Assert.assertNotNull(chartChangeEventType4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        org.jfree.chart.plot.Marker marker15 = null;
        boolean boolean16 = categoryPlot14.removeDomainMarker(marker15);
        java.util.List list17 = categoryPlot14.getAnnotations();
        org.jfree.chart.plot.CategoryMarker categoryMarker19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        xYPlot20.setRangeCrosshairVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        xYPlot20.setInsets(rectangleInsets23, true);
        java.awt.Paint paint26 = xYPlot20.getDomainTickBandPaint();
        java.lang.String str27 = xYPlot20.getPlotType();
        org.jfree.chart.plot.Marker marker29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot();
        xYPlot30.setRangeCrosshairVisible(true);
        boolean boolean33 = xYPlot30.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot();
        xYPlot34.configureDomainAxes();
        org.jfree.chart.util.Layer layer36 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection37 = xYPlot34.getDomainMarkers(layer36);
        java.util.Collection collection38 = xYPlot30.getRangeMarkers(layer36);
        boolean boolean40 = xYPlot20.removeDomainMarker((int) ' ', marker29, layer36, false);
        try {
            categoryPlot14.addDomainMarker((int) (byte) -1, categoryMarker19, layer36);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(list17);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNull(paint26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "XY Plot" + "'", str27.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(layer36);
        org.junit.Assert.assertNull(collection37);
        org.junit.Assert.assertNull(collection38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.data.Range range6 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot7 = dateAxis4.getPlot();
        dateAxis4.setLabelURL("hi!");
        dateAxis4.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer13);
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        xYPlot16.setRangeCrosshairVisible(true);
        boolean boolean19 = xYPlot16.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        xYPlot20.configureDomainAxes();
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection23 = xYPlot20.getDomainMarkers(layer22);
        java.util.Collection collection24 = xYPlot16.getRangeMarkers(layer22);
        java.util.Collection collection25 = categoryPlot14.getRangeMarkers((int) (byte) 1, layer22);
        java.util.List list26 = categoryPlot14.getCategories();
        categoryPlot14.clearAnnotations();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = categoryPlot14.getDrawingSupplier();
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = new org.jfree.chart.axis.CategoryAxis("");
        float float31 = categoryAxis30.getMaximumCategoryLabelWidthRatio();
        categoryPlot14.setDomainAxis(categoryAxis30);
        boolean boolean33 = categoryPlot14.isSubplot();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertNull(collection23);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertNull(list26);
        org.junit.Assert.assertNotNull(drawingSupplier28);
        org.junit.Assert.assertTrue("'" + float31 + "' != '" + 0.0f + "'", float31 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = dateAxis0.getLabelInsets();
        dateAxis0.setFixedAutoRange((double) (byte) 10);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("");
        float float7 = categoryAxis6.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        boolean boolean9 = dateAxis8.isAutoTickUnitSelection();
        org.jfree.data.Range range10 = dateAxis8.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot11 = dateAxis8.getPlot();
        dateAxis8.setLabelURL("hi!");
        dateAxis8.zoomRange((double) 0.0f, (double) 7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis8, categoryItemRenderer17);
        categoryPlot18.setWeight((int) (byte) 0);
        org.jfree.chart.util.SortOrder sortOrder21 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot18.setRowRenderingOrder(sortOrder21);
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        boolean boolean24 = dateAxis23.isAutoTickUnitSelection();
        org.jfree.data.Range range25 = dateAxis23.getDefaultAutoRange();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        boolean boolean27 = dateAxis26.isAutoTickUnitSelection();
        org.jfree.data.Range range28 = dateAxis26.getDefaultAutoRange();
        dateAxis23.setRangeWithMargins(range28);
        categoryPlot18.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis23);
        dateAxis23.setLowerBound((double) 1L);
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis();
        boolean boolean34 = dateAxis33.isAutoTickUnitSelection();
        org.jfree.data.Range range35 = dateAxis33.getDefaultAutoRange();
        org.jfree.chart.plot.Plot plot36 = dateAxis33.getPlot();
        java.util.Date date37 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis33.setMinimumDate(date37);
        dateAxis23.setMaximumDate(date37);
        dateAxis0.setMaximumDate(date37);
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date37);
        java.util.Calendar calendar42 = null;
        try {
            long long43 = day41.getMiddleMillisecond(calendar42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNull(plot11);
        org.junit.Assert.assertNotNull(sortOrder21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertNull(plot36);
        org.junit.Assert.assertNotNull(date37);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat2 = numberAxis1.getNumberFormatOverride();
        org.jfree.data.RangeType rangeType3 = numberAxis1.getRangeType();
        boolean boolean4 = numberAxis1.isTickMarksVisible();
        numberAxis1.setTickLabelsVisible(false);
        boolean boolean7 = numberAxis1.isTickLabelsVisible();
        org.junit.Assert.assertNull(numberFormat2);
        org.junit.Assert.assertNotNull(rangeType3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }
}

