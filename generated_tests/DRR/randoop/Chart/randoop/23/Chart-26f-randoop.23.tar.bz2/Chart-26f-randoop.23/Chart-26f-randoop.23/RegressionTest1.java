import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean1 = lineAndShapeRenderer0.getDrawOutlines();
        java.lang.Boolean boolean3 = lineAndShapeRenderer0.getSeriesLinesVisible(5);
        lineAndShapeRenderer0.setSeriesLinesVisible((int) (short) 100, true);
        boolean boolean9 = lineAndShapeRenderer0.getItemShapeFilled(100, 0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(boolean3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D6 = labelBlock5.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D6, "", "Preceding");
        numberAxis1.setDownArrow((java.awt.Shape) rectangle2D6);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis1.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        double double13 = numberAxis12.getUpperBound();
        boolean boolean14 = numberAxis12.getAutoRangeStickyZero();
        boolean boolean15 = numberAxis12.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer16);
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = xYPlot17.getRendererForDataset(xYDataset18);
        org.jfree.chart.axis.AxisSpace axisSpace20 = xYPlot17.getFixedDomainAxisSpace();
        xYPlot17.setRangeZeroBaselineVisible(true);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = xYPlot17.getRangeAxisEdge((int) (byte) 100);
        java.awt.Paint paint25 = xYPlot17.getRangeGridlinePaint();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(xYItemRenderer19);
        org.junit.Assert.assertNull(axisSpace20);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertNotNull(paint25);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        boolean boolean0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        java.awt.Color color0 = java.awt.Color.YELLOW;
        int int1 = color0.getTransparency();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D6 = labelBlock5.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D6, "", "Preceding");
        numberAxis1.setDownArrow((java.awt.Shape) rectangle2D6);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis1.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        double double13 = numberAxis12.getUpperBound();
        boolean boolean14 = numberAxis12.getAutoRangeStickyZero();
        boolean boolean15 = numberAxis12.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer16);
        numberAxis12.resizeRange((double) 2.0f, 0.5d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.CenterArrangement centerArrangement1 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle();
        boolean boolean3 = textTitle2.getExpandToFitSpace();
        textTitle2.setNotify(false);
        org.jfree.chart.block.LabelBlock labelBlock7 = new org.jfree.chart.block.LabelBlock("");
        java.awt.Font font8 = labelBlock7.getFont();
        centerArrangement1.add((org.jfree.chart.block.Block) textTitle2, (java.lang.Object) labelBlock7);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier10 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke11 = defaultDrawingSupplier10.getNextStroke();
        columnArrangement0.add((org.jfree.chart.block.Block) labelBlock7, (java.lang.Object) defaultDrawingSupplier10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        java.util.Date date2 = month0.getEnd();
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor5 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor5, textAnchor6);
        org.jfree.chart.axis.DateTick dateTick9 = new org.jfree.chart.axis.DateTick(date2, "CONTRACT", textAnchor4, textAnchor6, 0.2d);
        double double10 = dateTick9.getValue();
        org.jfree.chart.text.TextAnchor textAnchor11 = dateTick9.getTextAnchor();
        org.jfree.data.time.DateRange dateRange12 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double13 = dateRange12.getCentralValue();
        org.jfree.data.time.DateRange dateRange14 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double15 = dateRange14.getCentralValue();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange12, (org.jfree.data.Range) dateRange14);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = rectangleConstraint16.toFixedHeight((double) 10.0f);
        org.jfree.data.Range range19 = rectangleConstraint16.getWidthRange();
        boolean boolean20 = dateTick9.equals((java.lang.Object) rectangleConstraint16);
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean22 = categoryPlot21.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = categoryPlot21.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation26 = categoryPlot21.getDomainAxisLocation((int) '4');
        org.jfree.chart.axis.AxisSpace axisSpace27 = new org.jfree.chart.axis.AxisSpace();
        categoryPlot21.setFixedRangeAxisSpace(axisSpace27);
        org.jfree.chart.title.LegendTitle legendTitle29 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot21);
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis();
        double double31 = numberAxis30.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock34 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D35 = labelBlock34.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity38 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D35, "", "Preceding");
        numberAxis30.setDownArrow((java.awt.Shape) rectangle2D35);
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = numberAxis30.getLabelInsets();
        java.awt.Shape shape42 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
        numberAxis30.setRightArrow(shape42);
        java.awt.Paint paint44 = numberAxis30.getLabelPaint();
        boolean boolean45 = legendTitle29.equals((java.lang.Object) numberAxis30);
        legendTitle29.setMargin((double) 15, (double) (byte) 10, (double) 3, (double) 9);
        java.awt.Graphics2D graphics2D51 = null;
        org.jfree.chart.util.Size2D size2D52 = legendTitle29.arrange(graphics2D51);
        org.jfree.chart.util.Size2D size2D53 = rectangleConstraint16.calculateConstrainedSize(size2D52);
        size2D52.height = 1.0f;
        size2D52.setHeight((double) 500);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(itemLabelAnchor5);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.561964399999E12d + "'", double10 == 1.561964399999E12d);
        org.junit.Assert.assertNotNull(textAnchor11);
        org.junit.Assert.assertNotNull(dateRange12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.5d + "'", double13 == 0.5d);
        org.junit.Assert.assertNotNull(dateRange14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.5d + "'", double15 == 0.5d);
        org.junit.Assert.assertNotNull(rectangleConstraint18);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.0d + "'", double31 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D35);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(size2D52);
        org.junit.Assert.assertNotNull(size2D53);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.CENTER;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge((int) (short) 0);
        categoryPlot0.setAnchorValue((double) 10.0f, false);
        org.jfree.data.category.CategoryDataset categoryDataset8 = categoryPlot0.getDataset(2019);
        categoryPlot0.mapDatasetToRangeAxis(100, (int) (short) 10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        try {
            categoryPlot0.handleClick((int) (byte) 10, 0, plotRenderingInfo14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNull(categoryDataset8);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation5 = categoryPlot0.getDomainAxisLocation((int) '4');
        org.jfree.chart.axis.AxisSpace axisSpace6 = new org.jfree.chart.axis.AxisSpace();
        categoryPlot0.setFixedRangeAxisSpace(axisSpace6);
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot0);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        double double10 = numberAxis9.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock13 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D14 = labelBlock13.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity17 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D14, "", "Preceding");
        numberAxis9.setDownArrow((java.awt.Shape) rectangle2D14);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = numberAxis9.getLabelInsets();
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
        numberAxis9.setRightArrow(shape21);
        java.awt.Paint paint23 = numberAxis9.getLabelPaint();
        boolean boolean24 = legendTitle8.equals((java.lang.Object) numberAxis9);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot25.setRangeCrosshairValue((double) (byte) 1);
        double[] doubleArray35 = new double[] { (-1L), 0.0d };
        double[] doubleArray38 = new double[] { (-1L), 0.0d };
        double[] doubleArray41 = new double[] { (-1L), 0.0d };
        double[] doubleArray44 = new double[] { (-1L), 0.0d };
        double[][] doubleArray45 = new double[][] { doubleArray35, doubleArray38, doubleArray41, doubleArray44 };
        org.jfree.data.category.CategoryDataset categoryDataset46 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", doubleArray45);
        org.jfree.data.category.CategoryDataset categoryDataset47 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray45);
        double[] doubleArray54 = new double[] { (-1L), 0.0d };
        double[] doubleArray57 = new double[] { (-1L), 0.0d };
        double[] doubleArray60 = new double[] { (-1L), 0.0d };
        double[] doubleArray63 = new double[] { (-1L), 0.0d };
        double[][] doubleArray64 = new double[][] { doubleArray54, doubleArray57, doubleArray60, doubleArray63 };
        org.jfree.data.category.CategoryDataset categoryDataset65 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", doubleArray64);
        org.jfree.data.category.CategoryDataset categoryDataset66 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray64);
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset67 = new org.jfree.data.category.DefaultIntervalCategoryDataset(doubleArray45, doubleArray64);
        categoryPlot25.setDataset(100, (org.jfree.data.category.CategoryDataset) defaultIntervalCategoryDataset67);
        boolean boolean69 = legendTitle8.equals((java.lang.Object) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets70 = legendTitle8.getMargin();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(categoryDataset46);
        org.junit.Assert.assertNotNull(categoryDataset47);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(categoryDataset65);
        org.junit.Assert.assertNotNull(categoryDataset66);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(rectangleInsets70);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot0.setDomainAxisLocation(axisLocation2);
        categoryPlot0.clearRangeMarkers((-1));
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = categoryPlot0.getDomainAxis(100);
        java.awt.Font font8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        categoryPlot0.setNoDataMessageFont(font8);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection10 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent11 = null;
        taskSeriesCollection10.seriesChanged(seriesChangeEvent11);
        java.lang.Number number13 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection10);
        categoryPlot0.setDataset((org.jfree.data.category.CategoryDataset) taskSeriesCollection10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNull(categoryAxis7);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 0.0d + "'", number13.equals(0.0d));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator2 = piePlot1.getToolTipGenerator();
        java.awt.Font font3 = piePlot1.getLabelFont();
        java.awt.Stroke stroke5 = piePlot1.getSectionOutlineStroke((java.lang.Comparable) 0L);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        double double8 = numberAxis7.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock11 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D12 = labelBlock11.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity15 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D12, "", "Preceding");
        numberAxis7.setDownArrow((java.awt.Shape) rectangle2D12);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = numberAxis7.getLabelInsets();
        numberAxis7.setVerticalTickLabels(true);
        java.awt.Stroke stroke20 = numberAxis7.getAxisLineStroke();
        piePlot1.setSectionOutlineStroke((java.lang.Comparable) "({0}, {1}) = {2}", stroke20);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator22 = piePlot1.getLegendLabelURLGenerator();
        java.awt.Shape shape23 = piePlot1.getLegendItemShape();
        java.awt.Paint paint24 = piePlot1.getLabelShadowPaint();
        org.junit.Assert.assertNull(pieToolTipGenerator2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNull(pieURLGenerator22);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(paint24);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        double double4 = numberAxis3.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock7 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D8 = labelBlock7.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity11 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D8, "", "Preceding");
        numberAxis3.setDownArrow((java.awt.Shape) rectangle2D8);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = numberAxis3.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        double double15 = numberAxis14.getUpperBound();
        boolean boolean16 = numberAxis14.getAutoRangeStickyZero();
        boolean boolean17 = numberAxis14.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis14, xYItemRenderer18);
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        xYPlot19.setDataset(5, xYDataset21);
        org.jfree.chart.JFreeChart jFreeChart24 = new org.jfree.chart.JFreeChart("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", font1, (org.jfree.chart.plot.Plot) xYPlot19, true);
        boolean boolean25 = jFreeChart24.isBorderVisible();
        jFreeChart24.setTextAntiAlias(true);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D5 = labelBlock4.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity8 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D5, "", "Preceding");
        org.jfree.chart.entity.LegendItemEntity legendItemEntity9 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D5);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer10 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint11 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        statisticalBarRenderer10.setBasePaint(paint11);
        org.jfree.chart.title.LegendGraphic legendGraphic13 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape) rectangle2D5, paint11);
        org.jfree.chart.text.TextMeasurer textMeasurer15 = null;
        org.jfree.chart.text.TextBlock textBlock16 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint11, (float) (short) 0, textMeasurer15);
        org.jfree.chart.text.TextLine textLine17 = textBlock16.getLastLine();
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.util.Size2D size2D19 = textBlock16.calculateDimensions(graphics2D18);
        org.jfree.chart.text.TextLine textLine21 = new org.jfree.chart.text.TextLine("CategoryLabelEntity: category=false, tooltip=, url=Preceding");
        textBlock16.addLine(textLine21);
        org.jfree.chart.text.TextFragment textFragment23 = textLine21.getLastTextFragment();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(textBlock16);
        org.junit.Assert.assertNull(textLine17);
        org.junit.Assert.assertNotNull(size2D19);
        org.junit.Assert.assertNotNull(textFragment23);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge((int) (short) 0);
        categoryPlot0.setAnchorValue((double) 10.0f, false);
        org.jfree.data.category.CategoryDataset categoryDataset8 = categoryPlot0.getDataset(2019);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = categoryPlot0.getRendererForDataset(categoryDataset9);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNull(categoryDataset8);
        org.junit.Assert.assertNull(categoryItemRenderer10);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.data.DefaultKeyedValue defaultKeyedValue2 = new org.jfree.data.DefaultKeyedValue((java.lang.Comparable) 0.0d, (java.lang.Number) 100.0f);
        java.lang.Comparable comparable3 = defaultKeyedValue2.getKey();
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + 0.0d + "'", comparable3.equals(0.0d));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        blockParams0.setTranslateX(0.5d);
        blockParams0.setTranslateY((double) 2.0f);
        blockParams0.setGenerateEntities(false);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLowerMargin((double) 10.0f);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent3 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        float float2 = waferMapPlot1.getForegroundAlpha();
        org.jfree.data.general.WaferMapDataset waferMapDataset3 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot4 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset3);
        float float5 = waferMapPlot4.getForegroundAlpha();
        java.awt.Color color6 = java.awt.Color.orange;
        waferMapPlot4.setNoDataMessagePaint((java.awt.Paint) color6);
        waferMapPlot1.setBackgroundPaint((java.awt.Paint) color6);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 1.0f + "'", float5 == 1.0f);
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge((int) (short) 0);
        float float4 = categoryPlot0.getForegroundAlpha();
        categoryPlot0.setDrawSharedDomainAxis(true);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier7 = categoryPlot0.getDrawingSupplier();
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = categoryPlot0.getDomainAxisEdge(3);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(drawingSupplier7);
        org.junit.Assert.assertNotNull(rectangleEdge9);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        double double4 = numberAxis3.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock7 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D8 = labelBlock7.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity11 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D8, "", "Preceding");
        numberAxis3.setDownArrow((java.awt.Shape) rectangle2D8);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = numberAxis3.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        double double15 = numberAxis14.getUpperBound();
        boolean boolean16 = numberAxis14.getAutoRangeStickyZero();
        boolean boolean17 = numberAxis14.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis14, xYItemRenderer18);
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        xYPlot19.setDataset(5, xYDataset21);
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        double[] doubleArray28 = new double[] { (-1L), 0.0d };
        double[] doubleArray31 = new double[] { (-1L), 0.0d };
        double[] doubleArray34 = new double[] { (-1L), 0.0d };
        double[] doubleArray37 = new double[] { (-1L), 0.0d };
        double[][] doubleArray38 = new double[][] { doubleArray28, doubleArray31, doubleArray34, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", doubleArray38);
        org.jfree.data.Range range40 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset39);
        java.lang.Number number41 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset39);
        java.lang.Number number42 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset39);
        java.lang.Number number43 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset39);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent44 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) color23, (org.jfree.data.general.Dataset) categoryDataset39);
        xYPlot19.datasetChanged(datasetChangeEvent44);
        boolean boolean46 = standardGradientPaintTransformer1.equals((java.lang.Object) xYPlot19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        int int48 = xYPlot19.getIndexOf(xYItemRenderer47);
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range40);
        org.junit.Assert.assertTrue("'" + number41 + "' != '" + 0.0d + "'", number41.equals(0.0d));
        org.junit.Assert.assertTrue("'" + number42 + "' != '" + 0.0d + "'", number42.equals(0.0d));
        org.junit.Assert.assertTrue("'" + number43 + "' != '" + 0.0d + "'", number43.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.addValue((java.lang.Number) 15, (java.lang.Comparable) 4, (java.lang.Comparable) "DateTickMarkPosition.START");
        java.util.List list5 = defaultCategoryDataset0.getRowKeys();
        org.junit.Assert.assertNotNull(list5);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        double double3 = numberAxis2.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D7 = labelBlock6.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity10 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D7, "", "Preceding");
        numberAxis2.setDownArrow((java.awt.Shape) rectangle2D7);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = numberAxis2.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        double double14 = numberAxis13.getUpperBound();
        boolean boolean15 = numberAxis13.getAutoRangeStickyZero();
        boolean boolean16 = numberAxis13.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis13, xYItemRenderer17);
        xYPlot18.setRangeCrosshairVisible(false);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("WMAP_Plot", (org.jfree.chart.plot.Plot) xYPlot18);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D24 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 1L, (double) 31);
        boolean boolean26 = stackedBarRenderer3D24.equals((java.lang.Object) (-1.0f));
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator27 = null;
        stackedBarRenderer3D24.setLegendItemToolTipGenerator(categorySeriesLabelGenerator27);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer30 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator32 = statisticalBarRenderer30.getSeriesURLGenerator((int) (short) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer33 = null;
        statisticalBarRenderer30.setGradientPaintTransformer(gradientPaintTransformer33);
        java.awt.Paint paint36 = statisticalBarRenderer30.lookupSeriesFillPaint(0);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator37 = null;
        statisticalBarRenderer30.setBaseToolTipGenerator(categoryToolTipGenerator37, true);
        statisticalBarRenderer30.setSeriesVisible(0, (java.lang.Boolean) true, true);
        java.awt.Stroke stroke46 = statisticalBarRenderer30.getItemOutlineStroke((int) (byte) 1, (int) (short) 100);
        stackedBarRenderer3D24.setSeriesOutlineStroke((int) (byte) 1, stroke46);
        jFreeChart21.setBorderStroke(stroke46);
        jFreeChart21.setTextAntiAlias(false);
        java.lang.Object obj51 = null;
        try {
            jFreeChart21.setTextAntiAlias(obj51);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null incompatible with Text-specific antialiasing enable key");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(categoryURLGenerator32);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(stroke46);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.removeValue((java.lang.Comparable) "({0}, {1}) = {2}", (java.lang.Comparable) "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        int int5 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) "XY Plot");
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        statisticalBarRenderer0.setBasePaint(paint1);
        boolean boolean3 = statisticalBarRenderer0.getIncludeBaseInRange();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer4.setSeriesLinesVisible((int) '4', (java.lang.Boolean) true);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor9 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE7;
        org.jfree.chart.text.TextAnchor textAnchor10 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor11 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor9, textAnchor10, textAnchor11, (double) 0L);
        lineAndShapeRenderer4.setSeriesNegativeItemLabelPosition((int) '4', itemLabelPosition13);
        statisticalBarRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition13);
        statisticalBarRenderer0.setBaseSeriesVisible(false, false);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis();
        double double21 = numberAxis20.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock24 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D25 = labelBlock24.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity28 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D25, "", "Preceding");
        numberAxis20.setDownArrow((java.awt.Shape) rectangle2D25);
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = numberAxis20.getLabelInsets();
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot31.setRangeCrosshairValue((double) (byte) 1);
        org.jfree.chart.axis.ValueAxis valueAxis34 = categoryPlot31.getRangeAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = categoryPlot31.getDomainAxis((int) ' ');
        boolean boolean37 = numberAxis20.hasListener((java.util.EventListener) categoryPlot31);
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = categoryPlot31.getRangeAxisEdge((int) (byte) 0);
        org.jfree.data.general.WaferMapDataset waferMapDataset40 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot41 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset40);
        java.awt.Graphics2D graphics2D42 = null;
        org.jfree.chart.block.LabelBlock labelBlock45 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D46 = labelBlock45.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity49 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D46, "", "Preceding");
        waferMapPlot41.drawBackgroundImage(graphics2D42, rectangle2D46);
        org.jfree.chart.entity.ChartEntity chartEntity52 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D46, "Preceding");
        try {
            statisticalBarRenderer0.drawOutline(graphics2D19, categoryPlot31, rectangle2D46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(itemLabelAnchor9);
        org.junit.Assert.assertNotNull(textAnchor10);
        org.junit.Assert.assertNotNull(textAnchor11);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNull(valueAxis34);
        org.junit.Assert.assertNull(categoryAxis36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(rectangleEdge39);
        org.junit.Assert.assertNotNull(rectangle2D46);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        double double0 = org.jfree.chart.renderer.category.LineRenderer3D.DEFAULT_Y_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 8.0d + "'", double0 == 8.0d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        java.lang.String str1 = licences0.getGPL();
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("Preceding", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE7;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor1 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE7;
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor1, textAnchor2, textAnchor3, (double) 0L);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor2);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(itemLabelAnchor1);
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit0 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        org.junit.Assert.assertNotNull(numberTickUnit0);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = statisticalBarRenderer0.getSeriesURLGenerator((int) (short) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        statisticalBarRenderer0.setGradientPaintTransformer(gradientPaintTransformer3);
        java.awt.Paint paint6 = statisticalBarRenderer0.lookupSeriesFillPaint(0);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        statisticalBarRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator7, true);
        statisticalBarRenderer0.setSeriesVisible(0, (java.lang.Boolean) true, true);
        java.awt.Stroke stroke16 = statisticalBarRenderer0.getItemOutlineStroke((int) (byte) 1, (int) (short) 100);
        statisticalBarRenderer0.setAutoPopulateSeriesShape(false);
        org.junit.Assert.assertNull(categoryURLGenerator2);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = null;
        taskSeriesCollection0.seriesChanged(seriesChangeEvent1);
        org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, 9);
        org.jfree.data.Range range5 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        boolean boolean6 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        try {
            java.lang.Number number9 = taskSeriesCollection0.getStartValue((int) '4', (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(pieDataset4);
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        int int0 = org.jfree.data.time.SerialDate.MONDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        java.lang.String str2 = waferMapPlot1.getPlotType();
        org.jfree.data.general.WaferMapDataset waferMapDataset3 = null;
        waferMapPlot1.setDataset(waferMapDataset3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "WMAP_Plot" + "'", str2.equals("WMAP_Plot"));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = statisticalBarRenderer0.getSeriesURLGenerator((int) (short) 100);
        int int3 = statisticalBarRenderer0.getColumnCount();
        boolean boolean5 = statisticalBarRenderer0.isSeriesVisibleInLegend(0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = statisticalBarRenderer0.getLegendItemURLGenerator();
        org.jfree.chart.LegendItem legendItem9 = statisticalBarRenderer0.getLegendItem(1900, (int) 'a');
        org.junit.Assert.assertNull(categoryURLGenerator2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator6);
        org.junit.Assert.assertNull(legendItem9);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range1 = numberAxis0.getDefaultAutoRange();
        boolean boolean3 = numberAxis0.equals((java.lang.Object) (byte) -1);
        java.awt.Color color4 = java.awt.Color.RED;
        java.awt.Color color5 = color4.darker();
        numberAxis0.setTickLabelPaint((java.awt.Paint) color4);
        numberAxis0.setLowerMargin((double) 7);
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        java.awt.geom.Line2D line2D0 = null;
        try {
            java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(line2D0, 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = statisticalBarRenderer0.getSeriesURLGenerator((int) (short) 100);
        boolean boolean3 = statisticalBarRenderer0.getAutoPopulateSeriesPaint();
        boolean boolean4 = statisticalBarRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.junit.Assert.assertNull(categoryURLGenerator2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = null;
        taskSeriesCollection0.seriesChanged(seriesChangeEvent1);
        org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, 9);
        int int6 = taskSeriesCollection0.indexOf((java.lang.Comparable) 1.0E-8d);
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        double double9 = numberAxis8.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock12 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D13 = labelBlock12.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity16 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D13, "", "Preceding");
        numberAxis8.setDownArrow((java.awt.Shape) rectangle2D13);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = numberAxis8.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis();
        double double20 = numberAxis19.getUpperBound();
        boolean boolean21 = numberAxis19.getAutoRangeStickyZero();
        boolean boolean22 = numberAxis19.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = null;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) numberAxis8, (org.jfree.chart.axis.ValueAxis) numberAxis19, xYItemRenderer23);
        xYPlot24.setRangeCrosshairVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = xYPlot24.getRangeAxisEdge(1);
        taskSeriesCollection0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) xYPlot24);
        try {
            java.lang.Number number33 = taskSeriesCollection0.getStartValue(128, (int) (short) 1, 31);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 128, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(pieDataset4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(rectangleEdge28);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        axisState0.cursorUp((double) 1.0f);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D6 = labelBlock5.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D6, "", "Preceding");
        numberAxis1.setDownArrow((java.awt.Shape) rectangle2D6);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis1.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        double double13 = numberAxis12.getUpperBound();
        boolean boolean14 = numberAxis12.getAutoRangeStickyZero();
        boolean boolean15 = numberAxis12.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer16);
        xYPlot17.setRangeCrosshairVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = xYPlot17.getRangeAxisEdge(1);
        xYPlot17.mapDatasetToRangeAxis(500, 0);
        xYPlot17.zoom((double) 6);
        xYPlot17.clearRangeMarkers(500);
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = xYPlot17.getDomainAxisEdge((int) (short) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertNotNull(rectangleEdge30);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj1 = defaultDrawingSupplier0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = statisticalBarRenderer0.getSeriesURLGenerator((int) (short) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        statisticalBarRenderer0.setGradientPaintTransformer(gradientPaintTransformer3);
        java.awt.Paint paint7 = statisticalBarRenderer0.getItemPaint((int) (byte) 100, (int) '#');
        statisticalBarRenderer0.setSeriesCreateEntities(31, (java.lang.Boolean) true);
        org.jfree.chart.LegendItemCollection legendItemCollection11 = statisticalBarRenderer0.getLegendItems();
        org.jfree.chart.LegendItemCollection legendItemCollection12 = null;
        try {
            legendItemCollection11.addAll(legendItemCollection12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryURLGenerator2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(legendItemCollection11);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = null;
        taskSeriesCollection0.seriesChanged(seriesChangeEvent1);
        org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, 9);
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        org.junit.Assert.assertNotNull(pieDataset4);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str1 = projectInfo0.getCopyright();
        projectInfo0.setInfo("({0}, {1}) = {2}");
        projectInfo0.setLicenceText("RectangleAnchor.BOTTOM_RIGHT");
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge((int) (short) 0);
        categoryPlot0.setAnchorValue((double) 10.0f, false);
        org.jfree.data.category.CategoryDataset categoryDataset8 = categoryPlot0.getDataset(2019);
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        categoryPlot0.removeChangeListener(plotChangeListener9);
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        double double12 = numberAxis11.getUpperBound();
        boolean boolean13 = numberAxis11.getAutoRangeStickyZero();
        boolean boolean14 = numberAxis11.isAutoRange();
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis11);
        org.jfree.data.time.DateRange dateRange16 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double17 = dateRange16.getCentralValue();
        org.jfree.data.time.DateRange dateRange18 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double19 = dateRange18.getCentralValue();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange16, (org.jfree.data.Range) dateRange18);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = rectangleConstraint20.toFixedHeight((double) 10.0f);
        org.jfree.data.Range range23 = rectangleConstraint20.getWidthRange();
        numberAxis11.setDefaultAutoRange(range23);
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.data.RangeType rangeType26 = org.jfree.data.RangeType.NEGATIVE;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean28 = categoryPlot27.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = categoryPlot27.getDomainAxisEdge((int) (short) 0);
        categoryPlot27.setAnchorValue((double) 10.0f, false);
        org.jfree.data.category.CategoryDataset categoryDataset35 = categoryPlot27.getDataset(2019);
        org.jfree.chart.event.PlotChangeListener plotChangeListener36 = null;
        categoryPlot27.removeChangeListener(plotChangeListener36);
        boolean boolean38 = rangeType26.equals((java.lang.Object) categoryPlot27);
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = null;
        org.jfree.chart.axis.AxisSpace axisSpace41 = new org.jfree.chart.axis.AxisSpace();
        try {
            org.jfree.chart.axis.AxisSpace axisSpace42 = numberAxis11.reserveSpace(graphics2D25, (org.jfree.chart.plot.Plot) categoryPlot27, rectangle2D39, rectangleEdge40, axisSpace41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNull(categoryDataset8);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateRange16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.5d + "'", double17 == 0.5d);
        org.junit.Assert.assertNotNull(dateRange18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.5d + "'", double19 == 0.5d);
        org.junit.Assert.assertNotNull(rectangleConstraint22);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertNotNull(rangeType26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertNull(categoryDataset35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation5 = categoryPlot0.getDomainAxisLocation((int) '4');
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis6.setLowerMargin((double) 10.0f);
        org.jfree.data.general.WaferMapDataset waferMapDataset9 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot10 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset9);
        float float11 = waferMapPlot10.getForegroundAlpha();
        java.lang.String str12 = waferMapPlot10.getPlotType();
        boolean boolean13 = categoryAxis6.equals((java.lang.Object) str12);
        categoryAxis6.clearCategoryLabelToolTips();
        java.util.List list15 = categoryPlot0.getCategoriesForAxis(categoryAxis6);
        org.jfree.chart.plot.CategoryMarker categoryMarker16 = null;
        org.jfree.chart.util.Layer layer17 = null;
        try {
            categoryPlot0.addDomainMarker(categoryMarker16, layer17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 1.0f + "'", float11 == 1.0f);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "WMAP_Plot" + "'", str12.equals("WMAP_Plot"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(list15);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        java.awt.geom.Line2D line2D0 = null;
        try {
            java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(line2D0, (float) 31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean1 = lineAndShapeRenderer0.getDrawOutlines();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer2 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint3 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        statisticalBarRenderer2.setBasePaint(paint3);
        boolean boolean5 = statisticalBarRenderer2.getIncludeBaseInRange();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer6.setSeriesLinesVisible((int) '4', (java.lang.Boolean) true);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor11 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE7;
        org.jfree.chart.text.TextAnchor textAnchor12 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor13 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor11, textAnchor12, textAnchor13, (double) 0L);
        lineAndShapeRenderer6.setSeriesNegativeItemLabelPosition((int) '4', itemLabelPosition15);
        statisticalBarRenderer2.setBaseNegativeItemLabelPosition(itemLabelPosition15);
        lineAndShapeRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition15);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator19 = lineAndShapeRenderer0.getLegendItemLabelGenerator();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(itemLabelAnchor11);
        org.junit.Assert.assertNotNull(textAnchor12);
        org.junit.Assert.assertNotNull(textAnchor13);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator19);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit(0, 5);
        int int3 = dateTickUnit2.getUnit();
        int int4 = dateTickUnit2.getCount();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 5 + "'", int4 == 5);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge((int) (short) 0);
        categoryPlot0.setAnchorValue((double) 10.0f, false);
        org.jfree.data.category.CategoryDataset categoryDataset8 = categoryPlot0.getDataset(2019);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        categoryPlot0.setRangeCrosshairStroke(stroke9);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = null;
        try {
            categoryPlot0.setAxisOffset(rectangleInsets11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'offset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNull(categoryDataset8);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Paint paint1 = waterfallBarRenderer0.getPositiveBarPaint();
        waterfallBarRenderer0.setMaximumBarWidth(0.0d);
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation5 = categoryPlot0.getDomainAxisLocation((int) '4');
        org.jfree.chart.axis.AxisSpace axisSpace6 = new org.jfree.chart.axis.AxisSpace();
        categoryPlot0.setFixedRangeAxisSpace(axisSpace6);
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot0);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        double double10 = numberAxis9.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock13 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D14 = labelBlock13.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity17 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D14, "", "Preceding");
        numberAxis9.setDownArrow((java.awt.Shape) rectangle2D14);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = numberAxis9.getLabelInsets();
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
        numberAxis9.setRightArrow(shape21);
        java.awt.Paint paint23 = numberAxis9.getLabelPaint();
        boolean boolean24 = legendTitle8.equals((java.lang.Object) numberAxis9);
        java.lang.String str25 = numberAxis9.getLabelURL();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(str25);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateRightInset(0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairValue((double) (byte) 1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis((int) ' ');
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = categoryPlot0.getRenderer();
        boolean boolean7 = categoryPlot0.getDrawSharedDomainAxis();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNull(categoryItemRenderer6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        levelRenderer0.setItemMargin(100.0d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 1L, (double) 31);
        boolean boolean4 = stackedBarRenderer3D2.equals((java.lang.Object) (-1.0f));
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = null;
        stackedBarRenderer3D2.setLegendItemToolTipGenerator(categorySeriesLabelGenerator5);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = statisticalBarRenderer8.getSeriesURLGenerator((int) (short) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer11 = null;
        statisticalBarRenderer8.setGradientPaintTransformer(gradientPaintTransformer11);
        java.awt.Paint paint14 = statisticalBarRenderer8.lookupSeriesFillPaint(0);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator15 = null;
        statisticalBarRenderer8.setBaseToolTipGenerator(categoryToolTipGenerator15, true);
        statisticalBarRenderer8.setSeriesVisible(0, (java.lang.Boolean) true, true);
        java.awt.Stroke stroke24 = statisticalBarRenderer8.getItemOutlineStroke((int) (byte) 1, (int) (short) 100);
        stackedBarRenderer3D2.setSeriesOutlineStroke((int) (byte) 1, stroke24);
        boolean boolean26 = stackedBarRenderer3D2.getRenderAsPercentages();
        org.jfree.data.time.DateRange dateRange27 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double28 = dateRange27.getCentralValue();
        org.jfree.data.time.DateRange dateRange29 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double30 = dateRange29.getCentralValue();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint31 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange27, (org.jfree.data.Range) dateRange29);
        org.jfree.data.time.DateRange dateRange32 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double33 = dateRange32.getCentralValue();
        org.jfree.data.time.DateRange dateRange34 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double35 = dateRange34.getCentralValue();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint36 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange32, (org.jfree.data.Range) dateRange34);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint38 = rectangleConstraint36.toFixedHeight((double) 10.0f);
        org.jfree.data.Range range39 = rectangleConstraint36.getWidthRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint40 = rectangleConstraint31.toRangeHeight(range39);
        boolean boolean41 = stackedBarRenderer3D2.equals((java.lang.Object) range39);
        double double42 = stackedBarRenderer3D2.getXOffset();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(categoryURLGenerator10);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(dateRange27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.5d + "'", double28 == 0.5d);
        org.junit.Assert.assertNotNull(dateRange29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.5d + "'", double30 == 0.5d);
        org.junit.Assert.assertNotNull(dateRange32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.5d + "'", double33 == 0.5d);
        org.junit.Assert.assertNotNull(dateRange34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.5d + "'", double35 == 0.5d);
        org.junit.Assert.assertNotNull(rectangleConstraint38);
        org.junit.Assert.assertNotNull(range39);
        org.junit.Assert.assertNotNull(rectangleConstraint40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 1.0d + "'", double42 == 1.0d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.jfree.data.DefaultKeyedValue defaultKeyedValue3 = new org.jfree.data.DefaultKeyedValue((java.lang.Comparable) 0.0d, (java.lang.Number) 100.0f);
        java.lang.Number number4 = defaultKeyedValue3.getValue();
        boolean boolean5 = textBlockAnchor0.equals((java.lang.Object) defaultKeyedValue3);
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 100.0f + "'", number4.equals(100.0f));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint3 = piePlot1.getSectionOutlinePaint((java.lang.Comparable) 2019);
        org.jfree.chart.ChartColor chartColor7 = new org.jfree.chart.ChartColor(7, (int) (byte) 100, 0);
        piePlot1.setLabelBackgroundPaint((java.awt.Paint) chartColor7);
        org.junit.Assert.assertNull(paint3);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.addValue((java.lang.Number) 15, (java.lang.Comparable) 4, (java.lang.Comparable) "DateTickMarkPosition.START");
        try {
            java.lang.Comparable comparable6 = defaultCategoryDataset0.getColumnKey((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        boolean boolean3 = month0.equals((java.lang.Object) chartChangeEventType2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month0.previous();
        long long5 = month0.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(chartChangeEventType2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 24234L + "'", long5 == 24234L);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint3 = piePlot1.getSectionOutlinePaint((java.lang.Comparable) 2019);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent4 = null;
        piePlot1.markerChanged(markerChangeEvent4);
        java.awt.Color color6 = java.awt.Color.ORANGE;
        piePlot1.setLabelShadowPaint((java.awt.Paint) color6);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = statisticalBarRenderer0.getSeriesURLGenerator((int) (short) 100);
        boolean boolean3 = statisticalBarRenderer0.getAutoPopulateSeriesPaint();
        statisticalBarRenderer0.setAutoPopulateSeriesPaint(false);
        double double6 = statisticalBarRenderer0.getBase();
        org.junit.Assert.assertNull(categoryURLGenerator2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D6 = labelBlock5.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D6, "", "Preceding");
        numberAxis1.setDownArrow((java.awt.Shape) rectangle2D6);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis1.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        double double13 = numberAxis12.getUpperBound();
        boolean boolean14 = numberAxis12.getAutoRangeStickyZero();
        boolean boolean15 = numberAxis12.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer16);
        xYPlot17.setRangeCrosshairVisible(false);
        boolean boolean20 = xYPlot17.isRangeCrosshairLockedOnData();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = xYPlot17.getRenderer(8);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNull(xYItemRenderer22);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        java.util.TimeZone timeZone0 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.junit.Assert.assertNotNull(timeZone0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.data.time.DateRange dateRange0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.util.Date date1 = dateRange0.getLowerDate();
        org.junit.Assert.assertNotNull(dateRange0);
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertNotNull(year2);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) categoryPlot0, jFreeChart1, 200, (int) (byte) 0);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        double double8 = numberAxis7.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock11 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D12 = labelBlock11.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity15 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D12, "", "Preceding");
        numberAxis7.setDownArrow((java.awt.Shape) rectangle2D12);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = numberAxis7.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis();
        double double19 = numberAxis18.getUpperBound();
        boolean boolean20 = numberAxis18.getAutoRangeStickyZero();
        boolean boolean21 = numberAxis18.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) numberAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis18, xYItemRenderer22);
        xYPlot23.setRangeCrosshairVisible(false);
        org.jfree.chart.JFreeChart jFreeChart26 = new org.jfree.chart.JFreeChart("WMAP_Plot", (org.jfree.chart.plot.Plot) xYPlot23);
        boolean boolean27 = jFreeChart26.isNotify();
        chartProgressEvent4.setChart(jFreeChart26);
        int int29 = chartProgressEvent4.getPercent();
        chartProgressEvent4.setType(128);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range1 = numberAxis0.getDefaultAutoRange();
        org.jfree.data.time.DateRange dateRange2 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double3 = dateRange2.getCentralValue();
        double double4 = dateRange2.getUpperBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint(range1, (org.jfree.data.Range) dateRange2);
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNotNull(dateRange2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.5d + "'", double3 == 0.5d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = statisticalBarRenderer0.getSeriesURLGenerator((int) (short) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        statisticalBarRenderer0.setGradientPaintTransformer(gradientPaintTransformer3);
        java.awt.Paint paint7 = statisticalBarRenderer0.getItemPaint((int) (byte) 100, (int) '#');
        statisticalBarRenderer0.setSeriesCreateEntities(31, (java.lang.Boolean) true);
        org.jfree.chart.LegendItemCollection legendItemCollection11 = statisticalBarRenderer0.getLegendItems();
        java.lang.Object obj12 = legendItemCollection11.clone();
        org.junit.Assert.assertNull(categoryURLGenerator2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(legendItemCollection11);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        int int0 = org.jfree.data.time.SerialDate.FOURTH_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D6 = labelBlock5.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D6, "", "Preceding");
        numberAxis1.setDownArrow((java.awt.Shape) rectangle2D6);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis1.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        double double13 = numberAxis12.getUpperBound();
        boolean boolean14 = numberAxis12.getAutoRangeStickyZero();
        boolean boolean15 = numberAxis12.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer16);
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        xYPlot17.setDataset(5, xYDataset19);
        int int21 = xYPlot17.getDatasetCount();
        boolean boolean22 = xYPlot17.isDomainCrosshairVisible();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getUpperBound();
        boolean boolean2 = numberAxis0.getAutoRangeStickyZero();
        numberAxis0.setLowerMargin((double) 3600000L);
        boolean boolean5 = numberAxis0.isAutoRange();
        boolean boolean6 = numberAxis0.getAutoRangeIncludesZero();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer7 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = statisticalBarRenderer7.getSeriesURLGenerator((int) (short) 100);
        boolean boolean10 = statisticalBarRenderer7.getAutoPopulateSeriesPaint();
        java.awt.Stroke stroke12 = statisticalBarRenderer7.getSeriesOutlineStroke(0);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean14 = categoryPlot13.isDomainGridlinesVisible();
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot13.setDomainAxisLocation(axisLocation15);
        categoryPlot13.clearRangeMarkers((-1));
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = categoryPlot13.getDomainAxis(100);
        java.awt.Font font21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        categoryPlot13.setNoDataMessageFont(font21);
        statisticalBarRenderer7.setBaseItemLabelFont(font21);
        numberAxis0.setLabelFont(font21);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(categoryURLGenerator9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNull(categoryAxis20);
        org.junit.Assert.assertNotNull(font21);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = statisticalBarRenderer0.getSeriesURLGenerator((int) (short) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        statisticalBarRenderer0.setGradientPaintTransformer(gradientPaintTransformer3);
        java.awt.Paint paint7 = statisticalBarRenderer0.getItemPaint((int) (byte) 100, (int) '#');
        statisticalBarRenderer0.setSeriesCreateEntities(31, (java.lang.Boolean) true);
        org.jfree.chart.LegendItemCollection legendItemCollection11 = statisticalBarRenderer0.getLegendItems();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator12 = null;
        statisticalBarRenderer0.setBaseURLGenerator(categoryURLGenerator12);
        java.awt.Font font14 = statisticalBarRenderer0.getBaseItemLabelFont();
        statisticalBarRenderer0.setBaseCreateEntities(true, false);
        org.junit.Assert.assertNull(categoryURLGenerator2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(legendItemCollection11);
        org.junit.Assert.assertNotNull(font14);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = statisticalBarRenderer0.getSeriesURLGenerator((int) (short) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        statisticalBarRenderer0.setGradientPaintTransformer(gradientPaintTransformer3);
        java.awt.Paint paint7 = statisticalBarRenderer0.getItemPaint((int) (byte) 100, (int) '#');
        statisticalBarRenderer0.setSeriesCreateEntities(31, (java.lang.Boolean) true);
        org.jfree.chart.LegendItemCollection legendItemCollection11 = statisticalBarRenderer0.getLegendItems();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator12 = null;
        statisticalBarRenderer0.setBaseURLGenerator(categoryURLGenerator12);
        java.awt.Paint paint15 = statisticalBarRenderer0.getSeriesOutlinePaint((int) (byte) -1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator17 = null;
        statisticalBarRenderer0.setSeriesItemLabelGenerator(200, categoryItemLabelGenerator17);
        org.junit.Assert.assertNull(categoryURLGenerator2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(legendItemCollection11);
        org.junit.Assert.assertNull(paint15);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D6 = labelBlock5.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D6, "", "Preceding");
        numberAxis1.setDownArrow((java.awt.Shape) rectangle2D6);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis1.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        double double13 = numberAxis12.getUpperBound();
        boolean boolean14 = numberAxis12.getAutoRangeStickyZero();
        boolean boolean15 = numberAxis12.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer16);
        xYPlot17.setRangeCrosshairVisible(false);
        java.lang.String str20 = xYPlot17.getPlotType();
        org.jfree.chart.axis.ValueAxis valueAxis21 = xYPlot17.getDomainAxis();
        valueAxis21.setTickMarkOutsideLength(0.0f);
        java.awt.Shape shape24 = valueAxis21.getRightArrow();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "XY Plot" + "'", str20.equals("XY Plot"));
        org.junit.Assert.assertNotNull(valueAxis21);
        org.junit.Assert.assertNotNull(shape24);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getUpperBound();
        boolean boolean2 = numberAxis0.getAutoRangeStickyZero();
        numberAxis0.setLowerMargin((double) 3600000L);
        boolean boolean5 = numberAxis0.isAutoRange();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit6 = numberAxis0.getTickUnit();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(numberTickUnit6);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D3 = labelBlock2.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity6 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D3, "", "Preceding");
        org.jfree.chart.entity.LegendItemEntity legendItemEntity7 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D3);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint9 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        statisticalBarRenderer8.setBasePaint(paint9);
        org.jfree.chart.title.LegendGraphic legendGraphic11 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape) rectangle2D3, paint9);
        java.awt.Shape shape12 = legendGraphic11.getLine();
        double double13 = legendGraphic11.getContentYOffset();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D16 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 1L, (double) 31);
        boolean boolean18 = stackedBarRenderer3D16.equals((java.lang.Object) (-1.0f));
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator19 = null;
        stackedBarRenderer3D16.setLegendItemToolTipGenerator(categorySeriesLabelGenerator19);
        java.awt.Color color21 = java.awt.Color.YELLOW;
        stackedBarRenderer3D16.setBaseItemLabelPaint((java.awt.Paint) color21);
        legendGraphic11.setLinePaint((java.awt.Paint) color21);
        java.awt.Paint paint24 = legendGraphic11.getFillPaint();
        boolean boolean25 = legendGraphic11.isShapeFilled();
        org.junit.Assert.assertNotNull(rectangle2D3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(shape12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.0d + "'", double13 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairValue((double) (byte) 1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis((int) ' ');
        org.jfree.chart.axis.CategoryAnchor categoryAnchor6 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range8 = numberAxis7.getDefaultAutoRange();
        boolean boolean10 = numberAxis7.equals((java.lang.Object) (byte) -1);
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis7);
        numberAxis7.setRangeWithMargins(0.0d, 90.0d);
        java.lang.String str15 = numberAxis7.getLabelToolTip();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(categoryAnchor6);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(str15);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        java.lang.Comparable comparable0 = null;
        org.jfree.data.DefaultKeyedValue defaultKeyedValue2 = new org.jfree.data.DefaultKeyedValue(comparable0, (java.lang.Number) 100L);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) 100L);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge((int) (short) 0);
        float float4 = categoryPlot0.getForegroundAlpha();
        categoryPlot0.setDrawSharedDomainAxis(true);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier7 = categoryPlot0.getDrawingSupplier();
        java.awt.Font font9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock12 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D13 = labelBlock12.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity16 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D13, "", "Preceding");
        org.jfree.chart.entity.LegendItemEntity legendItemEntity17 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D13);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer18 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint19 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        statisticalBarRenderer18.setBasePaint(paint19);
        org.jfree.chart.title.LegendGraphic legendGraphic21 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape) rectangle2D13, paint19);
        org.jfree.chart.text.TextMeasurer textMeasurer23 = null;
        org.jfree.chart.text.TextBlock textBlock24 = org.jfree.chart.text.TextUtilities.createTextBlock("", font9, paint19, (float) (short) 0, textMeasurer23);
        categoryPlot0.setRangeGridlinePaint(paint19);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(drawingSupplier7);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(textBlock24);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = statisticalBarRenderer0.getSeriesURLGenerator((int) (short) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        statisticalBarRenderer0.setGradientPaintTransformer(gradientPaintTransformer3);
        java.awt.Paint paint6 = statisticalBarRenderer0.lookupSeriesFillPaint(0);
        java.awt.Font font9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock12 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D13 = labelBlock12.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity16 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D13, "", "Preceding");
        org.jfree.chart.entity.LegendItemEntity legendItemEntity17 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D13);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer18 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint19 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        statisticalBarRenderer18.setBasePaint(paint19);
        org.jfree.chart.title.LegendGraphic legendGraphic21 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape) rectangle2D13, paint19);
        org.jfree.chart.text.TextMeasurer textMeasurer23 = null;
        org.jfree.chart.text.TextBlock textBlock24 = org.jfree.chart.text.TextUtilities.createTextBlock("", font9, paint19, (float) (short) 0, textMeasurer23);
        statisticalBarRenderer0.setSeriesItemLabelFont((int) ' ', font9, true);
        org.junit.Assert.assertNull(categoryURLGenerator2);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(textBlock24);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator2 = piePlot1.getToolTipGenerator();
        java.awt.Color color3 = java.awt.Color.gray;
        piePlot1.setLabelShadowPaint((java.awt.Paint) color3);
        piePlot1.setExplodePercent((java.lang.Comparable) 8.0d, (double) 7);
        piePlot1.setMaximumLabelWidth((double) 128);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator10 = piePlot1.getLegendLabelURLGenerator();
        org.junit.Assert.assertNull(pieToolTipGenerator2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(pieURLGenerator10);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = statisticalBarRenderer0.getSeriesURLGenerator((int) (short) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        statisticalBarRenderer0.setGradientPaintTransformer(gradientPaintTransformer3);
        java.awt.Paint paint6 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        statisticalBarRenderer0.setSeriesOutlinePaint(2019, paint6);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator8 = statisticalBarRenderer0.getLegendItemURLGenerator();
        java.lang.Object obj9 = statisticalBarRenderer0.clone();
        boolean boolean10 = statisticalBarRenderer0.getBaseSeriesVisible();
        org.junit.Assert.assertNull(categoryURLGenerator2);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator8);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_VERTICAL_TICK_LABELS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.chart.renderer.OutlierListCollection outlierListCollection0 = new org.jfree.chart.renderer.OutlierListCollection();
        org.jfree.chart.renderer.Outlier outlier1 = null;
        boolean boolean2 = outlierListCollection0.add(outlier1);
        outlierListCollection0.setHighFarOut(false);
        outlierListCollection0.setHighFarOut(true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation5 = categoryPlot0.getDomainAxisLocation((int) '4');
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D8 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 1L, (double) 31);
        boolean boolean10 = stackedBarRenderer3D8.equals((java.lang.Object) (-1.0f));
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator11 = null;
        stackedBarRenderer3D8.setLegendItemToolTipGenerator(categorySeriesLabelGenerator11);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer14 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator16 = statisticalBarRenderer14.getSeriesURLGenerator((int) (short) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer17 = null;
        statisticalBarRenderer14.setGradientPaintTransformer(gradientPaintTransformer17);
        java.awt.Paint paint20 = statisticalBarRenderer14.lookupSeriesFillPaint(0);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator21 = null;
        statisticalBarRenderer14.setBaseToolTipGenerator(categoryToolTipGenerator21, true);
        statisticalBarRenderer14.setSeriesVisible(0, (java.lang.Boolean) true, true);
        java.awt.Stroke stroke30 = statisticalBarRenderer14.getItemOutlineStroke((int) (byte) 1, (int) (short) 100);
        stackedBarRenderer3D8.setSeriesOutlineStroke((int) (byte) 1, stroke30);
        categoryPlot0.setRangeGridlineStroke(stroke30);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer33 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke34 = statisticalBarRenderer33.getBaseStroke();
        java.awt.Color color35 = java.awt.Color.PINK;
        statisticalBarRenderer33.setBaseItemLabelPaint((java.awt.Paint) color35, false);
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color35);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(categoryURLGenerator16);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(color35);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        int int0 = org.jfree.data.time.SerialDate.SATURDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str1 = projectInfo0.getCopyright();
        projectInfo0.setVersion("({0}, {1}) = {2}");
        org.jfree.chart.ui.ProjectInfo projectInfo4 = new org.jfree.chart.ui.ProjectInfo();
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo4);
        java.lang.String str6 = projectInfo4.getName();
        org.jfree.chart.ui.Library[] libraryArray7 = projectInfo4.getOptionalLibraries();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(libraryArray7);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Stroke stroke1 = org.jfree.chart.util.SerialUtilities.readStroke(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean1 = categoryAxis3D0.isAxisLineVisible();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint4 = statisticalBarRenderer3.getBaseOutlinePaint();
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("");
        java.awt.Font font7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        labelBlock6.setFont(font7);
        statisticalBarRenderer3.setBaseItemLabelFont(font7);
        categoryAxis3D0.setTickLabelFont((java.lang.Comparable) 11, font7);
        categoryAxis3D0.setAxisLineVisible(true);
        java.awt.Graphics2D graphics2D13 = null;
        java.lang.Comparable comparable15 = null;
        org.jfree.chart.block.LabelBlock labelBlock17 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D18 = labelBlock17.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity21 = new org.jfree.chart.entity.CategoryLabelEntity(comparable15, (java.awt.Shape) rectangle2D18, "ThreadContext", "Fourth");
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = categoryPlot24.getAxisOffset();
        org.jfree.chart.block.LabelBlock labelBlock28 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D29 = labelBlock28.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity32 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D29, "", "Preceding");
        org.jfree.chart.entity.LegendItemEntity legendItemEntity33 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D29);
        java.awt.geom.Rectangle2D rectangle2D34 = rectangleInsets25.createOutsetRectangle(rectangle2D29);
        java.awt.geom.Point2D point2D35 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(0.0d, (double) 900000L, rectangle2D29);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean37 = categoryPlot36.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = categoryPlot36.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.entity.EntityCollection entityCollection40 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo41 = new org.jfree.chart.ChartRenderingInfo(entityCollection40);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo42 = chartRenderingInfo41.getPlotInfo();
        try {
            org.jfree.chart.axis.AxisState axisState43 = categoryAxis3D0.draw(graphics2D13, 0.5d, rectangle2D18, rectangle2D29, rectangleEdge39, plotRenderingInfo42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNotNull(point2D35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(rectangleEdge39);
        org.junit.Assert.assertNotNull(plotRenderingInfo42);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE4;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) '4', (double) 'a', false);
        boolean boolean4 = stackedBarRenderer3D3.getBaseItemLabelsVisible();
        stackedBarRenderer3D3.setBaseSeriesVisibleInLegend(true, false);
        java.awt.Stroke stroke9 = stackedBarRenderer3D3.getSeriesOutlineStroke(200);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(stroke9);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        try {
            org.jfree.data.gantt.TaskSeries taskSeries3 = taskSeriesCollection0.getSeries((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range1);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D3 = labelBlock2.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity6 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D3, "", "Preceding");
        org.jfree.chart.entity.LegendItemEntity legendItemEntity7 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D3);
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        try {
            boolean boolean9 = org.jfree.chart.util.ShapeUtilities.contains(rectangle2D3, rectangle2D8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D3);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        boolean boolean1 = waterfallBarRenderer0.getBaseCreateEntities();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        double double3 = numberAxis2.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D7 = labelBlock6.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity10 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D7, "", "Preceding");
        numberAxis2.setDownArrow((java.awt.Shape) rectangle2D7);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = numberAxis2.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        double double14 = numberAxis13.getUpperBound();
        boolean boolean15 = numberAxis13.getAutoRangeStickyZero();
        boolean boolean16 = numberAxis13.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis13, xYItemRenderer17);
        xYPlot18.setRangeCrosshairVisible(false);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("WMAP_Plot", (org.jfree.chart.plot.Plot) xYPlot18);
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle();
        jFreeChart21.addSubtitle((org.jfree.chart.title.Title) textTitle22);
        java.awt.Font font25 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock28 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D29 = labelBlock28.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity32 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D29, "", "Preceding");
        org.jfree.chart.entity.LegendItemEntity legendItemEntity33 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D29);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer34 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint35 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        statisticalBarRenderer34.setBasePaint(paint35);
        org.jfree.chart.title.LegendGraphic legendGraphic37 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape) rectangle2D29, paint35);
        org.jfree.chart.text.TextMeasurer textMeasurer39 = null;
        org.jfree.chart.text.TextBlock textBlock40 = org.jfree.chart.text.TextUtilities.createTextBlock("", font25, paint35, (float) (short) 0, textMeasurer39);
        org.jfree.chart.text.TextLine textLine41 = textBlock40.getLastLine();
        java.awt.Graphics2D graphics2D42 = null;
        org.jfree.chart.util.Size2D size2D43 = textBlock40.calculateDimensions(graphics2D42);
        org.jfree.chart.text.TextLine textLine45 = new org.jfree.chart.text.TextLine("CategoryLabelEntity: category=false, tooltip=, url=Preceding");
        textBlock40.addLine(textLine45);
        java.util.List list47 = textBlock40.getLines();
        try {
            jFreeChart21.setSubtitles(list47);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.text.TextLine cannot be cast to org.jfree.chart.title.Title");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(textBlock40);
        org.junit.Assert.assertNull(textLine41);
        org.junit.Assert.assertNotNull(size2D43);
        org.junit.Assert.assertNotNull(list47);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D5 = labelBlock4.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity8 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D5, "", "Preceding");
        numberAxis0.setDownArrow((java.awt.Shape) rectangle2D5);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = numberAxis0.getLabelInsets();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot11.setRangeCrosshairValue((double) (byte) 1);
        org.jfree.chart.axis.ValueAxis valueAxis14 = categoryPlot11.getRangeAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = categoryPlot11.getDomainAxis((int) ' ');
        boolean boolean17 = numberAxis0.hasListener((java.util.EventListener) categoryPlot11);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = categoryPlot11.getRangeAxisEdge((int) '4');
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis();
        double double22 = numberAxis21.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock25 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D26 = labelBlock25.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity29 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D26, "", "Preceding");
        numberAxis21.setDownArrow((java.awt.Shape) rectangle2D26);
        try {
            categoryPlot11.drawBackground(graphics2D20, rectangle2D26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNull(valueAxis14);
        org.junit.Assert.assertNull(categoryAxis16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D26);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE3;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.data.KeyToGroupMap keyToGroupMap1 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable) 10.0f);
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.previous();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType4 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        boolean boolean5 = month2.equals((java.lang.Object) chartChangeEventType4);
        java.lang.Comparable comparable6 = keyToGroupMap1.getGroup((java.lang.Comparable) month2);
        java.util.Calendar calendar7 = null;
        try {
            long long8 = month2.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(chartChangeEventType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 10.0f + "'", comparable6.equals(10.0f));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str1 = projectInfo0.getCopyright();
        projectInfo0.setInfo("({0}, {1}) = {2}");
        java.lang.String str4 = projectInfo0.getCopyright();
        projectInfo0.setInfo("SortOrder.ASCENDING");
        java.awt.Image image7 = projectInfo0.getLogo();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(image7);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("RectangleEdge.TOP");
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D5 = labelBlock4.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity8 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D5, "", "Preceding");
        numberAxis0.setDownArrow((java.awt.Shape) rectangle2D5);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = numberAxis0.getLabelInsets();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot11.setRangeCrosshairValue((double) (byte) 1);
        org.jfree.chart.axis.ValueAxis valueAxis14 = categoryPlot11.getRangeAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = categoryPlot11.getDomainAxis((int) ' ');
        boolean boolean17 = numberAxis0.hasListener((java.util.EventListener) categoryPlot11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = categoryPlot11.getRenderer();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNull(valueAxis14);
        org.junit.Assert.assertNull(categoryAxis16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(categoryItemRenderer18);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("darkGray", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=10.0]", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=10.0]", image3, "Size2D[width=0.0, height=0.0]", "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "Size2D[width=0.0, height=0.0]");
        java.lang.String str8 = projectInfo7.getCopyright();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Size2D[width=0.0, height=0.0]" + "'", str8.equals("Size2D[width=0.0, height=0.0]"));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = null;
        taskSeriesCollection0.seriesChanged(seriesChangeEvent1);
        int int4 = taskSeriesCollection0.indexOf((java.lang.Comparable) (-1L));
        int int6 = taskSeriesCollection0.getRowIndex((java.lang.Comparable) 31);
        int int8 = taskSeriesCollection0.getRowIndex((java.lang.Comparable) "CategoryLabelEntity: category=false, tooltip=, url=Preceding");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE8;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLowerMargin((double) 10.0f);
        java.awt.Paint paint4 = categoryAxis0.getTickLabelPaint((java.lang.Comparable) 7);
        categoryAxis0.setLowerMargin((double) 31);
        categoryAxis0.clearCategoryLabelToolTips();
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        double double5 = numberAxis4.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock8 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D9 = labelBlock8.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity12 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D9, "", "Preceding");
        numberAxis4.setDownArrow((java.awt.Shape) rectangle2D9);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = numberAxis4.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis();
        double double16 = numberAxis15.getUpperBound();
        boolean boolean17 = numberAxis15.getAutoRangeStickyZero();
        boolean boolean18 = numberAxis15.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) numberAxis4, (org.jfree.chart.axis.ValueAxis) numberAxis15, xYItemRenderer19);
        boolean boolean21 = xYPlot20.isDomainCrosshairVisible();
        org.jfree.chart.axis.AxisLocation axisLocation23 = xYPlot20.getRangeAxisLocation((int) (short) -1);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer24 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke25 = statisticalBarRenderer24.getBaseStroke();
        xYPlot20.setDomainZeroBaselineStroke(stroke25);
        int int27 = year2.compareTo((java.lang.Object) stroke25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year2.previous();
        java.util.Calendar calendar29 = null;
        try {
            long long30 = year2.getLastMillisecond(calendar29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D9);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint1 = statisticalBarRenderer0.getBaseOutlinePaint();
        org.jfree.chart.block.LabelBlock labelBlock3 = new org.jfree.chart.block.LabelBlock("");
        java.awt.Font font4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        labelBlock3.setFont(font4);
        statisticalBarRenderer0.setBaseItemLabelFont(font4);
        java.awt.Stroke stroke7 = null;
        try {
            statisticalBarRenderer0.setBaseStroke(stroke7, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(font4);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        org.jfree.data.time.Year year2 = month0.getYear();
        int int3 = year2.getYear();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        org.jfree.chart.block.BlockBorder blockBorder2 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color1);
        java.awt.Paint paint3 = blockBorder2.getPaint();
        java.awt.Stroke stroke4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.block.LabelBlock labelBlock7 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D8 = labelBlock7.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity11 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D8, "", "Preceding");
        org.jfree.chart.entity.LegendItemEntity legendItemEntity12 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D8);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer13 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint14 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        statisticalBarRenderer13.setBasePaint(paint14);
        org.jfree.chart.title.LegendGraphic legendGraphic16 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape) rectangle2D8, paint14);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = legendGraphic16.getShapeAnchor();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor18 = legendGraphic16.getShapeAnchor();
        java.awt.Paint paint19 = legendGraphic16.getFillPaint();
        java.awt.Stroke stroke20 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        try {
            org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker(0.0d, paint3, stroke4, paint19, stroke20, (float) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(rectangleAnchor17);
        org.junit.Assert.assertNotNull(rectangleAnchor18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "", "Preceding", "({0}, {1}) = {2}");
        java.lang.String str5 = library4.getInfo();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "({0}, {1}) = {2}" + "'", str5.equals("({0}, {1}) = {2}"));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D3 = labelBlock2.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity6 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D3, "", "Preceding");
        org.jfree.chart.entity.LegendItemEntity legendItemEntity7 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D3);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint9 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        statisticalBarRenderer8.setBasePaint(paint9);
        org.jfree.chart.title.LegendGraphic legendGraphic11 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape) rectangle2D3, paint9);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = legendGraphic11.getShapeAnchor();
        boolean boolean13 = legendGraphic11.isShapeOutlineVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = legendGraphic11.getMargin();
        double double15 = rectangleInsets14.getBottom();
        org.junit.Assert.assertNotNull(rectangle2D3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("CategoryLabelEntity: category=false, tooltip=, url=Preceding");
        org.jfree.chart.text.TextFragment textFragment2 = textLine1.getFirstTextFragment();
        org.junit.Assert.assertNotNull(textFragment2);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D3 = labelBlock2.getBounds();
        boolean boolean5 = labelBlock2.equals((java.lang.Object) 1);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        double double8 = numberAxis7.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock11 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D12 = labelBlock11.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity15 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D12, "", "Preceding");
        numberAxis7.setDownArrow((java.awt.Shape) rectangle2D12);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = numberAxis7.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis();
        double double19 = numberAxis18.getUpperBound();
        boolean boolean20 = numberAxis18.getAutoRangeStickyZero();
        boolean boolean21 = numberAxis18.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) numberAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis18, xYItemRenderer22);
        xYPlot23.setRangeCrosshairVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = xYPlot23.getRangeAxisEdge(1);
        int int28 = xYPlot23.getDomainAxisCount();
        columnArrangement0.add((org.jfree.chart.block.Block) labelBlock2, (java.lang.Object) xYPlot23);
        org.jfree.data.KeyedObjects keyedObjects30 = new org.jfree.data.KeyedObjects();
        int int31 = keyedObjects30.getItemCount();
        java.lang.Object obj32 = keyedObjects30.clone();
        org.jfree.chart.block.CenterArrangement centerArrangement34 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.block.BlockContainer blockContainer35 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) centerArrangement34);
        keyedObjects30.addObject((java.lang.Comparable) 128, (java.lang.Object) blockContainer35);
        java.awt.Graphics2D graphics2D37 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint38 = null;
        try {
            org.jfree.chart.util.Size2D size2D39 = columnArrangement0.arrange(blockContainer35, graphics2D37, rectangleConstraint38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(obj32);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 1L, (double) 31);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        double double6 = numberAxis5.getUpperBound();
        boolean boolean7 = numberAxis5.getAutoRangeStickyZero();
        org.jfree.chart.plot.Marker marker8 = null;
        org.jfree.data.general.WaferMapDataset waferMapDataset9 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot10 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset9);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.block.LabelBlock labelBlock14 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D15 = labelBlock14.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity18 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D15, "", "Preceding");
        waferMapPlot10.drawBackgroundImage(graphics2D11, rectangle2D15);
        stackedBarRenderer3D2.drawRangeMarker(graphics2D3, categoryPlot4, (org.jfree.chart.axis.ValueAxis) numberAxis5, marker8, rectangle2D15);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = categoryPlot4.getAxisOffset();
        boolean boolean22 = categoryPlot4.isRangeCrosshairVisible();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D6 = labelBlock5.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D6, "", "Preceding");
        numberAxis1.setDownArrow((java.awt.Shape) rectangle2D6);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis1.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        double double13 = numberAxis12.getUpperBound();
        boolean boolean14 = numberAxis12.getAutoRangeStickyZero();
        boolean boolean15 = numberAxis12.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer16);
        xYPlot17.setRangeCrosshairVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = xYPlot17.getRangeAxisEdge(1);
        int int22 = xYPlot17.getDomainAxisCount();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        xYPlot17.setRenderer(12, xYItemRenderer24, true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("TextBlockAnchor.TOP_RIGHT", "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "ClassContext", "VerticalAlignment.BOTTOM", "");
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D2 = labelBlock1.getBounds();
        labelBlock1.setPadding(1.0d, 10.0d, (double) 10L, (double) (-1));
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = labelBlock1.getPadding();
        double double10 = rectangleInsets8.calculateBottomInset(12.0d);
        org.junit.Assert.assertNotNull(rectangle2D2);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.0d + "'", double10 == 10.0d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean1 = lineAndShapeRenderer0.getDrawOutlines();
        java.lang.Boolean boolean3 = lineAndShapeRenderer0.getSeriesLinesVisible(5);
        lineAndShapeRenderer0.setSeriesLinesVisible((int) (short) 100, true);
        org.jfree.chart.LegendItem legendItem9 = lineAndShapeRenderer0.getLegendItem((int) (byte) 0, 10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(boolean3);
        org.junit.Assert.assertNull(legendItem9);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        statisticalBarRenderer0.setBasePaint(paint1);
        boolean boolean3 = statisticalBarRenderer0.getIncludeBaseInRange();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer4.setSeriesLinesVisible((int) '4', (java.lang.Boolean) true);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor9 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE7;
        org.jfree.chart.text.TextAnchor textAnchor10 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor11 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor9, textAnchor10, textAnchor11, (double) 0L);
        lineAndShapeRenderer4.setSeriesNegativeItemLabelPosition((int) '4', itemLabelPosition13);
        statisticalBarRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition13);
        boolean boolean17 = statisticalBarRenderer0.isSeriesVisible(200);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(itemLabelAnchor9);
        org.junit.Assert.assertNotNull(textAnchor10);
        org.junit.Assert.assertNotNull(textAnchor11);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE12;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D2 = labelBlock1.getBounds();
        labelBlock1.setMargin(0.05d, (double) 0.0f, (double) 0.0f, (double) (short) 0);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = null;
        try {
            org.jfree.chart.util.Size2D size2D10 = labelBlock1.arrange(graphics2D8, rectangleConstraint9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D2);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        double double1 = levelRenderer0.getItemMargin();
        levelRenderer0.setItemMargin(1.561964399999E12d);
        levelRenderer0.setItemMargin(0.5d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D5 = labelBlock4.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity8 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D5, "", "Preceding");
        numberAxis0.setDownArrow((java.awt.Shape) rectangle2D5);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = numberAxis0.getLabelInsets();
        numberAxis0.setVerticalTickLabels(true);
        org.jfree.data.Range range13 = numberAxis0.getDefaultAutoRange();
        org.jfree.chart.axis.TickUnitSource tickUnitSource14 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        numberAxis0.setStandardTickUnits(tickUnitSource14);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNotNull(tickUnitSource14);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor4 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE7;
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor4, textAnchor5, textAnchor6, (double) 0L);
        org.jfree.chart.text.TextAnchor textAnchor10 = null;
        try {
            java.awt.Shape shape11 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("CategoryLabelWidthType.CATEGORY", graphics2D1, 10.0f, 0.0f, textAnchor6, (-3.0d), textAnchor10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelAnchor4);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        double double3 = numberAxis2.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D7 = labelBlock6.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity10 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D7, "", "Preceding");
        numberAxis2.setDownArrow((java.awt.Shape) rectangle2D7);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = numberAxis2.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        double double14 = numberAxis13.getUpperBound();
        boolean boolean15 = numberAxis13.getAutoRangeStickyZero();
        boolean boolean16 = numberAxis13.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis13, xYItemRenderer17);
        xYPlot18.setRangeCrosshairVisible(false);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("WMAP_Plot", (org.jfree.chart.plot.Plot) xYPlot18);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D24 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 1L, (double) 31);
        boolean boolean26 = stackedBarRenderer3D24.equals((java.lang.Object) (-1.0f));
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator27 = null;
        stackedBarRenderer3D24.setLegendItemToolTipGenerator(categorySeriesLabelGenerator27);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer30 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator32 = statisticalBarRenderer30.getSeriesURLGenerator((int) (short) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer33 = null;
        statisticalBarRenderer30.setGradientPaintTransformer(gradientPaintTransformer33);
        java.awt.Paint paint36 = statisticalBarRenderer30.lookupSeriesFillPaint(0);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator37 = null;
        statisticalBarRenderer30.setBaseToolTipGenerator(categoryToolTipGenerator37, true);
        statisticalBarRenderer30.setSeriesVisible(0, (java.lang.Boolean) true, true);
        java.awt.Stroke stroke46 = statisticalBarRenderer30.getItemOutlineStroke((int) (byte) 1, (int) (short) 100);
        stackedBarRenderer3D24.setSeriesOutlineStroke((int) (byte) 1, stroke46);
        jFreeChart21.setBorderStroke(stroke46);
        jFreeChart21.setTextAntiAlias(false);
        org.jfree.chart.title.TextTitle textTitle51 = null;
        jFreeChart21.setTitle(textTitle51);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(categoryURLGenerator32);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(stroke46);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D3 = labelBlock2.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity6 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D3, "", "Preceding");
        org.jfree.chart.entity.LegendItemEntity legendItemEntity7 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D3);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint9 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        statisticalBarRenderer8.setBasePaint(paint9);
        org.jfree.chart.title.LegendGraphic legendGraphic11 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape) rectangle2D3, paint9);
        java.awt.Paint paint12 = legendGraphic11.getFillPaint();
        java.lang.Object obj13 = legendGraphic11.clone();
        org.junit.Assert.assertNotNull(rectangle2D3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(obj13);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.data.time.DateRange dateRange1 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double2 = dateRange1.getCentralValue();
        double double3 = dateRange1.getUpperBound();
        java.util.Date date4 = dateRange1.getLowerDate();
        org.jfree.data.time.DateRange dateRange5 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double6 = dateRange5.getCentralValue();
        org.jfree.data.time.DateRange dateRange7 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double8 = dateRange7.getCentralValue();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange5, (org.jfree.data.Range) dateRange7);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType10 = rectangleConstraint9.getWidthConstraintType();
        org.jfree.data.time.DateRange dateRange12 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange12, (double) '#');
        org.jfree.data.Range range17 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange12, (double) (-1.0f), false);
        org.jfree.data.time.DateRange dateRange18 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double19 = dateRange18.getCentralValue();
        org.jfree.data.time.DateRange dateRange20 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double21 = dateRange20.getCentralValue();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange18, (org.jfree.data.Range) dateRange20);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType23 = rectangleConstraint22.getWidthConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint24 = new org.jfree.chart.block.RectangleConstraint((double) 500, (org.jfree.data.Range) dateRange1, lengthConstraintType10, (double) (byte) 100, (org.jfree.data.Range) dateRange12, lengthConstraintType23);
        org.junit.Assert.assertNotNull(dateRange1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5d + "'", double2 == 0.5d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(dateRange5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.5d + "'", double6 == 0.5d);
        org.junit.Assert.assertNotNull(dateRange7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.5d + "'", double8 == 0.5d);
        org.junit.Assert.assertNotNull(lengthConstraintType10);
        org.junit.Assert.assertNotNull(dateRange12);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNotNull(dateRange18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.5d + "'", double19 == 0.5d);
        org.junit.Assert.assertNotNull(dateRange20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.5d + "'", double21 == 0.5d);
        org.junit.Assert.assertNotNull(lengthConstraintType23);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 1L, (double) 31);
        boolean boolean4 = stackedBarRenderer3D2.equals((java.lang.Object) (-1.0f));
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = null;
        stackedBarRenderer3D2.setLegendItemToolTipGenerator(categorySeriesLabelGenerator5);
        java.awt.Paint paint8 = stackedBarRenderer3D2.lookupSeriesFillPaint((int) ' ');
        java.awt.Paint paint9 = stackedBarRenderer3D2.getBasePaint();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType1 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lengthAdjustmentType1.equals((java.lang.Object) lineAndShapeRenderer2);
        java.lang.String str4 = lengthAdjustmentType1.toString();
        org.jfree.chart.block.LabelBlock labelBlock7 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D8 = labelBlock7.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity11 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D8, "", "Preceding");
        boolean boolean12 = lengthAdjustmentType1.equals((java.lang.Object) rectangle2D8);
        java.awt.geom.Rectangle2D rectangle2D15 = rectangleInsets0.createInsetRectangle(rectangle2D8, true, false);
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D17 = rectangleInsets0.createInsetRectangle(rectangle2D16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(lengthAdjustmentType1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "CONTRACT" + "'", str4.equals("CONTRACT"));
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(rectangle2D15);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 500);
        java.awt.Stroke stroke2 = valueMarker1.getOutlineStroke();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType3 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean5 = lengthAdjustmentType3.equals((java.lang.Object) lineAndShapeRenderer4);
        java.lang.String str6 = lengthAdjustmentType3.toString();
        valueMarker1.setLabelOffsetType(lengthAdjustmentType3);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.lang.String str9 = rectangleAnchor8.toString();
        valueMarker1.setLabelAnchor(rectangleAnchor8);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(lengthAdjustmentType3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "CONTRACT" + "'", str6.equals("CONTRACT"));
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "RectangleAnchor.BOTTOM_RIGHT" + "'", str9.equals("RectangleAnchor.BOTTOM_RIGHT"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        boolean boolean1 = textTitle0.getExpandToFitSpace();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        double double4 = numberAxis3.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock7 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D8 = labelBlock7.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity11 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D8, "", "Preceding");
        numberAxis3.setDownArrow((java.awt.Shape) rectangle2D8);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = numberAxis3.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        double double15 = numberAxis14.getUpperBound();
        boolean boolean16 = numberAxis14.getAutoRangeStickyZero();
        boolean boolean17 = numberAxis14.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis14, xYItemRenderer18);
        boolean boolean20 = xYPlot19.isDomainCrosshairVisible();
        boolean boolean21 = textTitle0.equals((java.lang.Object) xYPlot19);
        boolean boolean22 = xYPlot19.isRangeCrosshairVisible();
        boolean boolean23 = xYPlot19.isRangeZeroBaselineVisible();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean1 = lineAndShapeRenderer0.getDrawOutlines();
        java.lang.Boolean boolean3 = lineAndShapeRenderer0.getSeriesLinesVisible(5);
        boolean boolean4 = lineAndShapeRenderer0.getDrawOutlines();
        lineAndShapeRenderer0.setAutoPopulateSeriesStroke(true);
        java.lang.Boolean boolean8 = lineAndShapeRenderer0.getSeriesShapesVisible(5);
        lineAndShapeRenderer0.setBaseLinesVisible(true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(boolean3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(boolean8);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) categoryPlot0, jFreeChart1, 200, (int) (byte) 0);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor5 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        categoryPlot0.zoomDomainAxes(100.0d, plotRenderingInfo7, point2D8);
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        double double12 = numberAxis11.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock15 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D16 = labelBlock15.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity19 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D16, "", "Preceding");
        numberAxis11.setDownArrow((java.awt.Shape) rectangle2D16);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = numberAxis11.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        double double23 = numberAxis22.getUpperBound();
        boolean boolean24 = numberAxis22.getAutoRangeStickyZero();
        boolean boolean25 = numberAxis22.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot(xYDataset10, (org.jfree.chart.axis.ValueAxis) numberAxis11, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer26);
        xYPlot27.setRangeCrosshairVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean32 = categoryPlot31.isDomainGridlinesVisible();
        org.jfree.chart.axis.AxisLocation axisLocation33 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot31.setDomainAxisLocation(axisLocation33);
        xYPlot27.setRangeAxisLocation((int) (byte) 10, axisLocation33);
        categoryPlot0.setDomainAxisLocation(axisLocation33, false);
        categoryPlot0.setRangeCrosshairLockedOnData(true);
        java.awt.Font font40 = categoryPlot0.getNoDataMessageFont();
        categoryPlot0.setBackgroundAlpha((float) 0L);
        org.junit.Assert.assertNotNull(categoryAnchor5);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(axisLocation33);
        org.junit.Assert.assertNotNull(font40);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = statisticalBarRenderer0.getSeriesURLGenerator((int) (short) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        statisticalBarRenderer0.setGradientPaintTransformer(gradientPaintTransformer3);
        java.awt.Paint paint6 = statisticalBarRenderer0.lookupSeriesFillPaint(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = null;
        statisticalBarRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition7);
        boolean boolean9 = statisticalBarRenderer0.getBaseCreateEntities();
        org.junit.Assert.assertNull(categoryURLGenerator2);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        double double4 = numberAxis3.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock7 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D8 = labelBlock7.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity11 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D8, "", "Preceding");
        numberAxis3.setDownArrow((java.awt.Shape) rectangle2D8);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = numberAxis3.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        double double15 = numberAxis14.getUpperBound();
        boolean boolean16 = numberAxis14.getAutoRangeStickyZero();
        boolean boolean17 = numberAxis14.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis14, xYItemRenderer18);
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        xYPlot19.setDataset(5, xYDataset21);
        org.jfree.chart.JFreeChart jFreeChart24 = new org.jfree.chart.JFreeChart("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", font1, (org.jfree.chart.plot.Plot) xYPlot19, true);
        xYPlot19.clearAnnotations();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D6 = labelBlock5.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D6, "", "Preceding");
        numberAxis1.setDownArrow((java.awt.Shape) rectangle2D6);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis1.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        double double13 = numberAxis12.getUpperBound();
        boolean boolean14 = numberAxis12.getAutoRangeStickyZero();
        boolean boolean15 = numberAxis12.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer16);
        xYPlot17.setRangeCrosshairVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = xYPlot17.getRangeAxisEdge(1);
        xYPlot17.mapDatasetToRangeAxis(500, 0);
        org.jfree.data.general.PieDataset pieDataset25 = null;
        org.jfree.chart.plot.PiePlot piePlot26 = new org.jfree.chart.plot.PiePlot(pieDataset25);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator27 = piePlot26.getToolTipGenerator();
        double double28 = piePlot26.getMaximumLabelWidth();
        piePlot26.setStartAngle((double) 200);
        xYPlot17.setParent((org.jfree.chart.plot.Plot) piePlot26);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier32 = piePlot26.getDrawingSupplier();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertNull(pieToolTipGenerator27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.2d + "'", double28 == 0.2d);
        org.junit.Assert.assertNotNull(drawingSupplier32);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        double double4 = numberAxis3.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock7 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D8 = labelBlock7.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity11 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D8, "", "Preceding");
        numberAxis3.setDownArrow((java.awt.Shape) rectangle2D8);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = numberAxis3.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        double double15 = numberAxis14.getUpperBound();
        boolean boolean16 = numberAxis14.getAutoRangeStickyZero();
        boolean boolean17 = numberAxis14.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis14, xYItemRenderer18);
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        xYPlot19.setDataset(5, xYDataset21);
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        double[] doubleArray28 = new double[] { (-1L), 0.0d };
        double[] doubleArray31 = new double[] { (-1L), 0.0d };
        double[] doubleArray34 = new double[] { (-1L), 0.0d };
        double[] doubleArray37 = new double[] { (-1L), 0.0d };
        double[][] doubleArray38 = new double[][] { doubleArray28, doubleArray31, doubleArray34, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", doubleArray38);
        org.jfree.data.Range range40 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset39);
        java.lang.Number number41 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset39);
        java.lang.Number number42 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset39);
        java.lang.Number number43 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset39);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent44 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) color23, (org.jfree.data.general.Dataset) categoryDataset39);
        xYPlot19.datasetChanged(datasetChangeEvent44);
        boolean boolean46 = standardGradientPaintTransformer1.equals((java.lang.Object) xYPlot19);
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType47 = standardGradientPaintTransformer1.getType();
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range40);
        org.junit.Assert.assertTrue("'" + number41 + "' != '" + 0.0d + "'", number41.equals(0.0d));
        org.junit.Assert.assertTrue("'" + number42 + "' != '" + 0.0d + "'", number42.equals(0.0d));
        org.junit.Assert.assertTrue("'" + number43 + "' != '" + 0.0d + "'", number43.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(gradientPaintTransformType47);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 1L);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator3 = piePlot2.getToolTipGenerator();
        java.awt.Color color4 = java.awt.Color.gray;
        piePlot2.setLabelShadowPaint((java.awt.Paint) color4);
        piePlot2.setExplodePercent((java.lang.Comparable) 8.0d, (double) 7);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        double double10 = numberAxis9.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock13 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D14 = labelBlock13.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity17 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D14, "", "Preceding");
        numberAxis9.setDownArrow((java.awt.Shape) rectangle2D14);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = numberAxis9.getLabelInsets();
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
        numberAxis9.setRightArrow(shape21);
        java.awt.Paint paint23 = numberAxis9.getLabelPaint();
        piePlot2.setBaseSectionPaint(paint23);
        org.jfree.chart.util.Rotation rotation25 = piePlot2.getDirection();
        boolean boolean26 = piePlot2.getSectionOutlinesVisible();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit28 = new org.jfree.chart.axis.NumberTickUnit((double) 100L);
        java.awt.Paint paint29 = piePlot2.getSectionOutlinePaint((java.lang.Comparable) numberTickUnit28);
        int int30 = keyedObjects2D0.getRowIndex((java.lang.Comparable) numberTickUnit28);
        keyedObjects2D0.removeObject((java.lang.Comparable) 200, (java.lang.Comparable) "darkGray");
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = month34.previous();
        org.jfree.data.time.Year year36 = month34.getYear();
        int int37 = keyedObjects2D0.getRowIndex((java.lang.Comparable) month34);
        try {
            java.lang.Object obj40 = keyedObjects2D0.getObject((int) ' ', (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(pieToolTipGenerator3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(rotation25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNull(paint29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(year36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        double double3 = numberAxis2.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D7 = labelBlock6.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity10 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D7, "", "Preceding");
        numberAxis2.setDownArrow((java.awt.Shape) rectangle2D7);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = numberAxis2.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        double double14 = numberAxis13.getUpperBound();
        boolean boolean15 = numberAxis13.getAutoRangeStickyZero();
        boolean boolean16 = numberAxis13.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis13, xYItemRenderer17);
        xYPlot18.setRangeCrosshairVisible(false);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("WMAP_Plot", (org.jfree.chart.plot.Plot) xYPlot18);
        boolean boolean22 = jFreeChart21.isNotify();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo25 = null;
        java.awt.image.BufferedImage bufferedImage26 = jFreeChart21.createBufferedImage(1, 6, chartRenderingInfo25);
        int int27 = jFreeChart21.getSubtitleCount();
        try {
            jFreeChart21.setTextAntiAlias((java.lang.Object) 3.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 3.0 incompatible with Text-specific antialiasing enable key");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(bufferedImage26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D6 = labelBlock5.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D6, "", "Preceding");
        numberAxis1.setDownArrow((java.awt.Shape) rectangle2D6);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis1.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        double double13 = numberAxis12.getUpperBound();
        boolean boolean14 = numberAxis12.getAutoRangeStickyZero();
        boolean boolean15 = numberAxis12.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer16);
        xYPlot17.setRangeCrosshairVisible(false);
        java.lang.String str20 = xYPlot17.getPlotType();
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis();
        double double22 = numberAxis21.getUpperBound();
        boolean boolean23 = numberAxis21.getAutoRangeStickyZero();
        boolean boolean24 = numberAxis21.isAutoRange();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand25 = numberAxis21.getMarkerBand();
        java.awt.Shape shape26 = numberAxis21.getUpArrow();
        boolean boolean27 = numberAxis21.isPositiveArrowVisible();
        xYPlot17.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis21);
        int int29 = xYPlot17.getWeight();
        xYPlot17.mapDatasetToDomainAxis((int) (byte) 100, 0);
        double double33 = xYPlot17.getRangeCrosshairValue();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "XY Plot" + "'", str20.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNull(markerAxisBand25);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = statisticalBarRenderer0.getSeriesURLGenerator((int) (short) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        statisticalBarRenderer0.setGradientPaintTransformer(gradientPaintTransformer3);
        java.awt.Paint paint7 = statisticalBarRenderer0.getItemPaint((int) (byte) 100, (int) '#');
        statisticalBarRenderer0.setSeriesCreateEntities(31, (java.lang.Boolean) true);
        org.jfree.chart.LegendItemCollection legendItemCollection11 = statisticalBarRenderer0.getLegendItems();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator12 = null;
        statisticalBarRenderer0.setBaseURLGenerator(categoryURLGenerator12);
        java.awt.Paint paint15 = statisticalBarRenderer0.getSeriesOutlinePaint((int) (byte) -1);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean18 = categoryPlot17.isDomainGridlinesVisible();
        org.jfree.chart.axis.AxisLocation axisLocation19 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot17.setDomainAxisLocation(axisLocation19);
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot21.setRangeCrosshairValue((double) (byte) 1);
        org.jfree.chart.axis.ValueAxis valueAxis24 = categoryPlot21.getRangeAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = categoryPlot21.getDomainAxis((int) ' ');
        org.jfree.chart.axis.CategoryAnchor categoryAnchor27 = categoryPlot21.getDomainGridlinePosition();
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range29 = numberAxis28.getDefaultAutoRange();
        boolean boolean31 = numberAxis28.equals((java.lang.Object) (byte) -1);
        categoryPlot21.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis28);
        numberAxis28.setRangeWithMargins(0.0d, 90.0d);
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis36.setLowerMargin((double) 10.0f);
        categoryAxis36.configure();
        categoryAxis36.removeCategoryLabelToolTip((java.lang.Comparable) "First");
        org.jfree.chart.block.LabelBlock labelBlock46 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D47 = labelBlock46.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity50 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D47, "", "Preceding");
        org.jfree.chart.entity.LegendItemEntity legendItemEntity51 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D47);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer52 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint53 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        statisticalBarRenderer52.setBasePaint(paint53);
        org.jfree.chart.title.LegendGraphic legendGraphic55 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape) rectangle2D47, paint53);
        org.jfree.chart.util.RectangleEdge rectangleEdge56 = null;
        double double57 = categoryAxis36.getCategoryMiddle(0, 4, rectangle2D47, rectangleEdge56);
        statisticalBarRenderer0.drawRangeGridline(graphics2D16, categoryPlot17, (org.jfree.chart.axis.ValueAxis) numberAxis28, rectangle2D47, (double) 100L);
        org.jfree.data.category.CategoryDataset categoryDataset60 = categoryPlot17.getDataset();
        org.junit.Assert.assertNull(categoryURLGenerator2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(legendItemCollection11);
        org.junit.Assert.assertNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNull(valueAxis24);
        org.junit.Assert.assertNull(categoryAxis26);
        org.junit.Assert.assertNotNull(categoryAnchor27);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(rectangle2D47);
        org.junit.Assert.assertNotNull(paint53);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset60);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator6 = statisticalBarRenderer4.getSeriesURLGenerator((int) (short) 100);
        int int7 = statisticalBarRenderer4.getColumnCount();
        double double8 = statisticalBarRenderer4.getItemMargin();
        java.lang.Class<?> wildcardClass9 = statisticalBarRenderer4.getClass();
        java.io.InputStream inputStream10 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("SortOrder.ASCENDING", (java.lang.Class) wildcardClass9);
        java.net.URL uRL11 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", (java.lang.Class) wildcardClass9);
        java.lang.Object obj12 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("java.awt.Color[r=128,g=128,b=128]", (java.lang.Class) wildcardClass9);
        java.io.InputStream inputStream13 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", (java.lang.Class) wildcardClass9);
        org.junit.Assert.assertNull(categoryURLGenerator6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.2d + "'", double8 == 0.2d);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNull(inputStream10);
        org.junit.Assert.assertNull(uRL11);
        org.junit.Assert.assertNull(obj12);
        org.junit.Assert.assertNull(inputStream13);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairValue((double) (byte) 1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis((int) ' ');
        org.jfree.chart.axis.CategoryAnchor categoryAnchor6 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range8 = numberAxis7.getDefaultAutoRange();
        boolean boolean10 = numberAxis7.equals((java.lang.Object) (byte) -1);
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis7);
        numberAxis7.setRangeWithMargins(0.0d, 90.0d);
        try {
            numberAxis7.zoomRange((double) (short) 0, (double) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (-4.5) <= upper (-103.5).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(categoryAnchor6);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.data.DefaultKeyedValue defaultKeyedValue2 = new org.jfree.data.DefaultKeyedValue((java.lang.Comparable) "", (java.lang.Number) 10.0f);
        org.jfree.chart.renderer.category.AreaRenderer areaRenderer3 = new org.jfree.chart.renderer.category.AreaRenderer();
        org.jfree.chart.renderer.AreaRendererEndType areaRendererEndType4 = org.jfree.chart.renderer.AreaRendererEndType.TAPER;
        areaRenderer3.setEndType(areaRendererEndType4);
        boolean boolean6 = defaultKeyedValue2.equals((java.lang.Object) areaRenderer3);
        org.junit.Assert.assertNotNull(areaRendererEndType4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer2 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D6 = labelBlock5.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D6, "", "Preceding");
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double11 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D6, rectangleEdge10);
        statisticalBarRenderer2.setBaseShape((java.awt.Shape) rectangle2D6, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator16 = statisticalBarRenderer2.getItemLabelGenerator((int) (byte) -1, 10);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent17 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10);
        java.lang.Object obj18 = seriesChangeEvent17.getSource();
        taskSeriesCollection0.seriesChanged(seriesChangeEvent17);
        org.jfree.data.general.PieDataset pieDataset21 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, (int) (short) 100);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNull(categoryItemLabelGenerator16);
        org.junit.Assert.assertTrue("'" + obj18 + "' != '" + 10 + "'", obj18.equals(10));
        org.junit.Assert.assertNotNull(pieDataset21);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D6 = labelBlock5.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D6, "", "Preceding");
        numberAxis1.setDownArrow((java.awt.Shape) rectangle2D6);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis1.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        double double13 = numberAxis12.getUpperBound();
        boolean boolean14 = numberAxis12.getAutoRangeStickyZero();
        boolean boolean15 = numberAxis12.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer16);
        org.jfree.chart.axis.AxisSpace axisSpace18 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = org.jfree.chart.util.RectangleEdge.LEFT;
        axisSpace18.ensureAtLeast((double) ' ', rectangleEdge20);
        xYPlot17.setFixedDomainAxisSpace(axisSpace18);
        java.awt.Paint paint23 = xYPlot17.getDomainGridlinePaint();
        boolean boolean24 = xYPlot17.isRangeZoomable();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D6 = labelBlock5.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D6, "", "Preceding");
        numberAxis1.setDownArrow((java.awt.Shape) rectangle2D6);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis1.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        double double13 = numberAxis12.getUpperBound();
        boolean boolean14 = numberAxis12.getAutoRangeStickyZero();
        boolean boolean15 = numberAxis12.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer16);
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        xYPlot17.setDataset(5, xYDataset19);
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        double[] doubleArray26 = new double[] { (-1L), 0.0d };
        double[] doubleArray29 = new double[] { (-1L), 0.0d };
        double[] doubleArray32 = new double[] { (-1L), 0.0d };
        double[] doubleArray35 = new double[] { (-1L), 0.0d };
        double[][] doubleArray36 = new double[][] { doubleArray26, doubleArray29, doubleArray32, doubleArray35 };
        org.jfree.data.category.CategoryDataset categoryDataset37 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", doubleArray36);
        org.jfree.data.Range range38 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset37);
        java.lang.Number number39 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset37);
        java.lang.Number number40 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset37);
        java.lang.Number number41 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset37);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent42 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) color21, (org.jfree.data.general.Dataset) categoryDataset37);
        xYPlot17.datasetChanged(datasetChangeEvent42);
        org.jfree.data.general.Dataset dataset44 = datasetChangeEvent42.getDataset();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(categoryDataset37);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertTrue("'" + number39 + "' != '" + 0.0d + "'", number39.equals(0.0d));
        org.junit.Assert.assertTrue("'" + number40 + "' != '" + 0.0d + "'", number40.equals(0.0d));
        org.junit.Assert.assertTrue("'" + number41 + "' != '" + 0.0d + "'", number41.equals(0.0d));
        org.junit.Assert.assertNotNull(dataset44);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D3 = labelBlock2.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity6 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D3, "", "Preceding");
        org.jfree.chart.entity.LegendItemEntity legendItemEntity7 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D3);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint9 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        statisticalBarRenderer8.setBasePaint(paint9);
        org.jfree.chart.title.LegendGraphic legendGraphic11 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape) rectangle2D3, paint9);
        boolean boolean12 = legendGraphic11.isShapeOutlineVisible();
        org.junit.Assert.assertNotNull(rectangle2D3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairValue((double) (byte) 1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis((int) ' ');
        org.jfree.chart.axis.CategoryAnchor categoryAnchor6 = categoryPlot0.getDomainGridlinePosition();
        java.util.List list7 = categoryPlot0.getCategories();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(categoryAnchor6);
        org.junit.Assert.assertNull(list7);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) 6, (double) ' ');
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_FIRST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        java.lang.Object obj2 = null;
        boolean boolean3 = blockBorder1.equals(obj2);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.lang.String str1 = textTitle0.getURLText();
        java.lang.String str2 = textTitle0.getURLText();
        org.jfree.chart.block.LineBorder lineBorder3 = new org.jfree.chart.block.LineBorder();
        textTitle0.setFrame((org.jfree.chart.block.BlockFrame) lineBorder3);
        textTitle0.setToolTipText("SortOrder.ASCENDING");
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_STICKY_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) (byte) 100, (double) (short) 100);
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4);
        org.jfree.chart.block.BlockContainer blockContainer6 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 1L, (double) 31);
        boolean boolean4 = stackedBarRenderer3D2.equals((java.lang.Object) (-1.0f));
        stackedBarRenderer3D2.setRenderAsPercentages(true);
        java.awt.Stroke stroke9 = stackedBarRenderer3D2.getItemOutlineStroke(100, 3);
        double double10 = stackedBarRenderer3D2.getXOffset();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D5 = labelBlock4.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity8 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D5, "", "Preceding");
        numberAxis0.setDownArrow((java.awt.Shape) rectangle2D5);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = numberAxis0.getLabelInsets();
        numberAxis0.setVerticalTickLabels(true);
        boolean boolean13 = numberAxis0.isInverted();
        numberAxis0.setAutoTickUnitSelection(true, true);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryPlot0.getAxisOffset();
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D5 = labelBlock4.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity8 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D5, "", "Preceding");
        org.jfree.chart.entity.LegendItemEntity legendItemEntity9 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D5);
        java.awt.geom.Rectangle2D rectangle2D10 = rectangleInsets1.createOutsetRectangle(rectangle2D5);
        double double11 = rectangleInsets1.getBottom();
        org.jfree.chart.util.UnitType unitType12 = rectangleInsets1.getUnitType();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(unitType12);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addYears((int) ' ', serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.junit.Assert.assertNotNull(date0);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        int int1 = segmentedTimeline0.getSegmentsIncluded();
        java.util.Date date2 = null;
        try {
            segmentedTimeline0.addBaseTimelineException(date2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 5 + "'", int1 == 5);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        try {
            java.lang.Number number4 = taskSeriesCollection0.getEndValue(11, 128);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range1);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (byte) 1, jFreeChart1);
        org.jfree.chart.JFreeChart jFreeChart3 = null;
        chartChangeEvent2.setChart(jFreeChart3);
        org.jfree.chart.JFreeChart jFreeChart5 = chartChangeEvent2.getChart();
        org.junit.Assert.assertNull(jFreeChart5);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        axisSpace0.setTop((double) 1900);
        org.jfree.chart.axis.AxisSpace axisSpace3 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = org.jfree.chart.util.RectangleEdge.LEFT;
        axisSpace3.ensureAtLeast((double) ' ', rectangleEdge5);
        axisSpace3.setRight((double) 1L);
        axisSpace0.ensureAtLeast(axisSpace3);
        org.junit.Assert.assertNotNull(rectangleEdge5);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = statisticalBarRenderer0.getSeriesURLGenerator((int) (short) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        statisticalBarRenderer0.setGradientPaintTransformer(gradientPaintTransformer3);
        java.awt.Paint paint6 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        statisticalBarRenderer0.setSeriesOutlinePaint(2019, paint6);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer9 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.block.LabelBlock labelBlock12 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D13 = labelBlock12.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity16 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D13, "", "Preceding");
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double18 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D13, rectangleEdge17);
        statisticalBarRenderer9.setBaseShape((java.awt.Shape) rectangle2D13, true);
        statisticalBarRenderer0.setSeriesShape(1, (java.awt.Shape) rectangle2D13);
        boolean boolean22 = statisticalBarRenderer0.getAutoPopulateSeriesStroke();
        java.awt.Paint paint23 = statisticalBarRenderer0.getBaseItemLabelPaint();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer24 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator26 = statisticalBarRenderer24.getSeriesURLGenerator((int) (short) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer27 = null;
        statisticalBarRenderer24.setGradientPaintTransformer(gradientPaintTransformer27);
        java.awt.Paint paint30 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        statisticalBarRenderer24.setSeriesOutlinePaint(2019, paint30);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier32 = statisticalBarRenderer24.getDrawingSupplier();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator33 = statisticalBarRenderer24.getLegendItemLabelGenerator();
        statisticalBarRenderer0.setLegendItemURLGenerator(categorySeriesLabelGenerator33);
        org.junit.Assert.assertNull(categoryURLGenerator2);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNull(categoryURLGenerator26);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNull(drawingSupplier32);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator33);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D6 = labelBlock5.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D6, "", "Preceding");
        numberAxis1.setDownArrow((java.awt.Shape) rectangle2D6);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis1.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        double double13 = numberAxis12.getUpperBound();
        boolean boolean14 = numberAxis12.getAutoRangeStickyZero();
        boolean boolean15 = numberAxis12.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer16);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Point2D point2D21 = null;
        xYPlot17.zoomRangeAxes(0.0d, (double) 100L, plotRenderingInfo20, point2D21);
        org.jfree.chart.axis.AxisSpace axisSpace23 = xYPlot17.getFixedRangeAxisSpace();
        xYPlot17.setDomainCrosshairValue(2.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(axisSpace23);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("SortOrder.ASCENDING");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = new org.jfree.chart.axis.AxisState();
        axisState3.cursorRight((double) (byte) 1);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean8 = categoryPlot7.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = categoryPlot7.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot7.getDomainAxisLocation((int) '4');
        org.jfree.chart.axis.AxisSpace axisSpace13 = new org.jfree.chart.axis.AxisSpace();
        categoryPlot7.setFixedRangeAxisSpace(axisSpace13);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = categoryPlot7.getDomainAxisEdge((int) (byte) 10);
        try {
            java.util.List list17 = categoryAxis3D1.refreshTicks(graphics2D2, axisState3, rectangle2D6, rectangleEdge16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(rectangleEdge16);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(xYDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.chart.block.LabelBlock labelBlock3 = new org.jfree.chart.block.LabelBlock("");
        java.awt.Font font4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        labelBlock3.setFont(font4);
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("ERROR : Relative To String", font4);
        java.awt.Color color7 = java.awt.Color.BLACK;
        int int8 = color7.getAlpha();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer11 = new org.jfree.chart.text.G2TextMeasurer(graphics2D10);
        try {
            org.jfree.chart.text.TextBlock textBlock12 = org.jfree.chart.text.TextUtilities.createTextBlock("Preceding", font4, (java.awt.Paint) color7, (float) 24234L, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 255 + "'", int8 == 255);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        long long2 = month0.getLastMillisecond();
        org.jfree.data.time.Year year3 = month0.getYear();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year3.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertNotNull(year3);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.data.KeyToGroupMap keyToGroupMap1 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable) 10.0f);
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.previous();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType4 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        boolean boolean5 = month2.equals((java.lang.Object) chartChangeEventType4);
        java.lang.Comparable comparable6 = keyToGroupMap1.getGroup((java.lang.Comparable) month2);
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker((double) 500);
        valueMarker8.setLabel("ThreadContext");
        float float11 = valueMarker8.getAlpha();
        boolean boolean12 = keyToGroupMap1.equals((java.lang.Object) valueMarker8);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) keyToGroupMap1);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(chartChangeEventType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 10.0f + "'", comparable6.equals(10.0f));
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.8f + "'", float11 == 0.8f);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.chart.entity.EntityCollection entityCollection0 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo1 = new org.jfree.chart.ChartRenderingInfo(entityCollection0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = chartRenderingInfo1.getPlotInfo();
        int int3 = plotRenderingInfo2.getSubplotCount();
        try {
            org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = plotRenderingInfo2.getSubplotInfo(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(plotRenderingInfo2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) centerArrangement0);
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean3 = categoryPlot2.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = categoryPlot2.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot2.getDomainAxisLocation((int) '4');
        org.jfree.chart.axis.AxisSpace axisSpace8 = new org.jfree.chart.axis.AxisSpace();
        categoryPlot2.setFixedRangeAxisSpace(axisSpace8);
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot2);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color11);
        centerArrangement0.add((org.jfree.chart.block.Block) legendTitle10, (java.lang.Object) blockBorder12);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray14 = legendTitle10.getSources();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(legendItemSourceArray14);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D6 = labelBlock5.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D6, "", "Preceding");
        numberAxis1.setDownArrow((java.awt.Shape) rectangle2D6);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis1.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        double double13 = numberAxis12.getUpperBound();
        boolean boolean14 = numberAxis12.getAutoRangeStickyZero();
        boolean boolean15 = numberAxis12.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer16);
        xYPlot17.setRangeCrosshairVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = xYPlot17.getRangeAxisEdge(1);
        xYPlot17.mapDatasetToRangeAxis(500, 0);
        xYPlot17.zoom((double) 6);
        xYPlot17.clearRangeMarkers(500);
        boolean boolean29 = xYPlot17.isDomainZeroBaselineVisible();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge((int) (short) 0);
        categoryPlot0.setOutlineVisible(true);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation6 = null;
        try {
            categoryPlot0.addAnnotation(categoryAnnotation6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(rectangleEdge3);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D6 = labelBlock5.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D6, "", "Preceding");
        numberAxis1.setDownArrow((java.awt.Shape) rectangle2D6);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis1.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        double double13 = numberAxis12.getUpperBound();
        boolean boolean14 = numberAxis12.getAutoRangeStickyZero();
        boolean boolean15 = numberAxis12.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer16);
        xYPlot17.clearDomainAxes();
        xYPlot17.clearDomainMarkers();
        org.jfree.chart.axis.AxisSpace axisSpace20 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = org.jfree.chart.util.RectangleEdge.LEFT;
        axisSpace20.ensureAtLeast((double) ' ', rectangleEdge22);
        axisSpace20.setTop((double) 'a');
        xYPlot17.setFixedDomainAxisSpace(axisSpace20);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(rectangleEdge22);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D6 = labelBlock5.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D6, "", "Preceding");
        waferMapPlot1.drawBackgroundImage(graphics2D2, rectangle2D6);
        org.jfree.chart.entity.ChartEntity chartEntity12 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D6, "Preceding");
        java.lang.Object obj13 = chartEntity12.clone();
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(obj13);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator2 = piePlot1.getToolTipGenerator();
        double double3 = piePlot1.getMaximumLabelWidth();
        piePlot1.setOutlineVisible(false);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator6 = piePlot1.getLegendLabelGenerator();
        org.junit.Assert.assertNull(pieToolTipGenerator2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator6);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        double double3 = numberAxis2.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D7 = labelBlock6.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity10 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D7, "", "Preceding");
        numberAxis2.setDownArrow((java.awt.Shape) rectangle2D7);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = numberAxis2.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        double double14 = numberAxis13.getUpperBound();
        boolean boolean15 = numberAxis13.getAutoRangeStickyZero();
        boolean boolean16 = numberAxis13.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis13, xYItemRenderer17);
        xYPlot18.setRangeCrosshairVisible(false);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("WMAP_Plot", (org.jfree.chart.plot.Plot) xYPlot18);
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle();
        jFreeChart21.addSubtitle((org.jfree.chart.title.Title) textTitle22);
        org.jfree.chart.title.TextTitle textTitle24 = new org.jfree.chart.title.TextTitle();
        boolean boolean25 = textTitle24.getExpandToFitSpace();
        jFreeChart21.setTitle(textTitle24);
        java.awt.Paint paint27 = null;
        try {
            textTitle24.setPaint(paint27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation5 = categoryPlot0.getDomainAxisLocation((int) '4');
        org.jfree.chart.axis.AxisSpace axisSpace6 = new org.jfree.chart.axis.AxisSpace();
        categoryPlot0.setFixedRangeAxisSpace(axisSpace6);
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot0);
        int int9 = categoryPlot0.getBackgroundImageAlignment();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (byte) 1, jFreeChart1);
        java.lang.String str3 = chartChangeEvent2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=1]" + "'", str3.equals("org.jfree.chart.event.ChartChangeEvent[source=1]"));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 500);
        java.awt.Stroke stroke2 = valueMarker1.getOutlineStroke();
        java.lang.String str3 = valueMarker1.getLabel();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D3 = labelBlock2.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity6 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D3, "", "Preceding");
        org.jfree.chart.entity.LegendItemEntity legendItemEntity7 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D3);
        java.lang.Comparable comparable8 = legendItemEntity7.getSeriesKey();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset9 = new org.jfree.data.category.DefaultCategoryDataset();
        legendItemEntity7.setDataset((org.jfree.data.general.Dataset) defaultCategoryDataset9);
        int int12 = defaultCategoryDataset9.getRowIndex((java.lang.Comparable) "RectangleAnchor.BOTTOM_RIGHT");
        try {
            java.lang.Number number15 = defaultCategoryDataset9.getValue((java.lang.Comparable) 0.05d, (java.lang.Comparable) 0.25d);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unrecognised columnKey: 0.25");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D3);
        org.junit.Assert.assertNull(comparable8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) categoryPlot0, jFreeChart1, 200, (int) (byte) 0);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        double double8 = numberAxis7.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock11 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D12 = labelBlock11.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity15 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D12, "", "Preceding");
        numberAxis7.setDownArrow((java.awt.Shape) rectangle2D12);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = numberAxis7.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis();
        double double19 = numberAxis18.getUpperBound();
        boolean boolean20 = numberAxis18.getAutoRangeStickyZero();
        boolean boolean21 = numberAxis18.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) numberAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis18, xYItemRenderer22);
        xYPlot23.setRangeCrosshairVisible(false);
        org.jfree.chart.JFreeChart jFreeChart26 = new org.jfree.chart.JFreeChart("WMAP_Plot", (org.jfree.chart.plot.Plot) xYPlot23);
        boolean boolean27 = jFreeChart26.isNotify();
        chartProgressEvent4.setChart(jFreeChart26);
        boolean boolean29 = jFreeChart26.getAntiAlias();
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        java.awt.Font font2 = barRenderer3D0.getSeriesItemLabelFont(100);
        org.junit.Assert.assertNull(font2);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = statisticalBarRenderer0.getSeriesURLGenerator((int) (short) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        statisticalBarRenderer0.setGradientPaintTransformer(gradientPaintTransformer3);
        java.awt.Paint paint7 = statisticalBarRenderer0.getItemPaint((int) (byte) 100, (int) '#');
        statisticalBarRenderer0.setSeriesCreateEntities(31, (java.lang.Boolean) true);
        org.jfree.chart.LegendItemCollection legendItemCollection11 = statisticalBarRenderer0.getLegendItems();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator12 = null;
        statisticalBarRenderer0.setBaseURLGenerator(categoryURLGenerator12);
        java.awt.Paint paint15 = statisticalBarRenderer0.getSeriesOutlinePaint((int) (byte) -1);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean18 = categoryPlot17.isDomainGridlinesVisible();
        org.jfree.chart.axis.AxisLocation axisLocation19 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot17.setDomainAxisLocation(axisLocation19);
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot21.setRangeCrosshairValue((double) (byte) 1);
        org.jfree.chart.axis.ValueAxis valueAxis24 = categoryPlot21.getRangeAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = categoryPlot21.getDomainAxis((int) ' ');
        org.jfree.chart.axis.CategoryAnchor categoryAnchor27 = categoryPlot21.getDomainGridlinePosition();
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range29 = numberAxis28.getDefaultAutoRange();
        boolean boolean31 = numberAxis28.equals((java.lang.Object) (byte) -1);
        categoryPlot21.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis28);
        numberAxis28.setRangeWithMargins(0.0d, 90.0d);
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis36.setLowerMargin((double) 10.0f);
        categoryAxis36.configure();
        categoryAxis36.removeCategoryLabelToolTip((java.lang.Comparable) "First");
        org.jfree.chart.block.LabelBlock labelBlock46 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D47 = labelBlock46.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity50 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D47, "", "Preceding");
        org.jfree.chart.entity.LegendItemEntity legendItemEntity51 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D47);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer52 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint53 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        statisticalBarRenderer52.setBasePaint(paint53);
        org.jfree.chart.title.LegendGraphic legendGraphic55 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape) rectangle2D47, paint53);
        org.jfree.chart.util.RectangleEdge rectangleEdge56 = null;
        double double57 = categoryAxis36.getCategoryMiddle(0, 4, rectangle2D47, rectangleEdge56);
        statisticalBarRenderer0.drawRangeGridline(graphics2D16, categoryPlot17, (org.jfree.chart.axis.ValueAxis) numberAxis28, rectangle2D47, (double) 100L);
        numberAxis28.setPositiveArrowVisible(false);
        org.junit.Assert.assertNull(categoryURLGenerator2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(legendItemCollection11);
        org.junit.Assert.assertNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNull(valueAxis24);
        org.junit.Assert.assertNull(categoryAxis26);
        org.junit.Assert.assertNotNull(categoryAnchor27);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(rectangle2D47);
        org.junit.Assert.assertNotNull(paint53);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge((int) (short) 0);
        categoryPlot0.setOutlineVisible(true);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis7.setLowerMargin((double) 10.0f);
        org.jfree.data.general.WaferMapDataset waferMapDataset10 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot11 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset10);
        float float12 = waferMapPlot11.getForegroundAlpha();
        java.lang.String str13 = waferMapPlot11.getPlotType();
        boolean boolean14 = categoryAxis7.equals((java.lang.Object) str13);
        float float15 = categoryAxis7.getMaximumCategoryLabelWidthRatio();
        categoryPlot0.setDomainAxis(2958465, categoryAxis7);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 1.0f + "'", float12 == 1.0f);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "WMAP_Plot" + "'", str13.equals("WMAP_Plot"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.0f + "'", float15 == 0.0f);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        java.awt.Color color2 = java.awt.Color.getColor("({0}, {1}) = {3} - {4}", 0);
        int int3 = color2.getTransparency();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getUpperBound();
        boolean boolean3 = numberAxis1.getAutoRangeStickyZero();
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        double double5 = numberAxis4.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock8 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D9 = labelBlock8.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity12 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D9, "", "Preceding");
        numberAxis4.setDownArrow((java.awt.Shape) rectangle2D9);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = numberAxis4.getLabelInsets();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot15.setRangeCrosshairValue((double) (byte) 1);
        org.jfree.chart.axis.ValueAxis valueAxis18 = categoryPlot15.getRangeAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = categoryPlot15.getDomainAxis((int) ' ');
        boolean boolean21 = numberAxis4.hasListener((java.util.EventListener) categoryPlot15);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis4, xYItemRenderer22);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        xYPlot23.setRenderer(xYItemRenderer24);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder26 = xYPlot23.getSeriesRenderingOrder();
        org.jfree.chart.axis.ValueAxis valueAxis27 = xYPlot23.getDomainAxis();
        double double28 = valueAxis27.getUpperBound();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D9);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNull(valueAxis18);
        org.junit.Assert.assertNull(categoryAxis20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(seriesRenderingOrder26);
        org.junit.Assert.assertNotNull(valueAxis27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.05d + "'", double28 == 1.05d);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        java.util.Date date2 = month0.getEnd();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity6 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) month0, shape3, "Size2D[width=0.0, height=0.0]", "");
        int int7 = month0.getMonth();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        double[] doubleArray7 = new double[] { (-1L), 0.0d };
        double[] doubleArray10 = new double[] { (-1L), 0.0d };
        double[] doubleArray13 = new double[] { (-1L), 0.0d };
        double[] doubleArray16 = new double[] { (-1L), 0.0d };
        double[][] doubleArray17 = new double[][] { doubleArray7, doubleArray10, doubleArray13, doubleArray16 };
        org.jfree.data.category.CategoryDataset categoryDataset18 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", doubleArray17);
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray17);
        double[] doubleArray26 = new double[] { (-1L), 0.0d };
        double[] doubleArray29 = new double[] { (-1L), 0.0d };
        double[] doubleArray32 = new double[] { (-1L), 0.0d };
        double[] doubleArray35 = new double[] { (-1L), 0.0d };
        double[][] doubleArray36 = new double[][] { doubleArray26, doubleArray29, doubleArray32, doubleArray35 };
        org.jfree.data.category.CategoryDataset categoryDataset37 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", doubleArray36);
        org.jfree.data.category.CategoryDataset categoryDataset38 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray36);
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset39 = new org.jfree.data.category.DefaultIntervalCategoryDataset(doubleArray17, doubleArray36);
        java.util.List list40 = defaultIntervalCategoryDataset39.getColumnKeys();
        org.jfree.data.xy.XYDataset xYDataset42 = null;
        org.jfree.chart.axis.NumberAxis numberAxis43 = new org.jfree.chart.axis.NumberAxis();
        double double44 = numberAxis43.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock47 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D48 = labelBlock47.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity51 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D48, "", "Preceding");
        numberAxis43.setDownArrow((java.awt.Shape) rectangle2D48);
        org.jfree.chart.util.RectangleInsets rectangleInsets53 = numberAxis43.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis54 = new org.jfree.chart.axis.NumberAxis();
        double double55 = numberAxis54.getUpperBound();
        boolean boolean56 = numberAxis54.getAutoRangeStickyZero();
        boolean boolean57 = numberAxis54.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer58 = null;
        org.jfree.chart.plot.XYPlot xYPlot59 = new org.jfree.chart.plot.XYPlot(xYDataset42, (org.jfree.chart.axis.ValueAxis) numberAxis43, (org.jfree.chart.axis.ValueAxis) numberAxis54, xYItemRenderer58);
        xYPlot59.setRangeCrosshairVisible(false);
        org.jfree.chart.JFreeChart jFreeChart62 = new org.jfree.chart.JFreeChart("WMAP_Plot", (org.jfree.chart.plot.Plot) xYPlot59);
        boolean boolean63 = jFreeChart62.isNotify();
        org.jfree.chart.JFreeChart jFreeChart65 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent66 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (byte) 1, jFreeChart65);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType67 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        chartChangeEvent66.setType(chartChangeEventType67);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent69 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) list40, jFreeChart62, chartChangeEventType67);
        boolean boolean70 = booleanList0.equals((java.lang.Object) list40);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(categoryDataset18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(categoryDataset37);
        org.junit.Assert.assertNotNull(categoryDataset38);
        org.junit.Assert.assertNotNull(list40);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 1.0d + "'", double44 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D48);
        org.junit.Assert.assertNotNull(rectangleInsets53);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 1.0d + "'", double55 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNotNull(chartChangeEventType67);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        boolean boolean3 = segmentedTimeline0.containsDomainRange((long) 1, (long) 15);
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = new org.jfree.chart.axis.DateTickUnit(0, 5);
        int int7 = dateTickUnit6.getRollUnit();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month8.previous();
        java.util.Date date10 = month8.getEnd();
        org.jfree.chart.text.TextAnchor textAnchor12 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor13 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor14 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor13, textAnchor14);
        org.jfree.chart.axis.DateTick dateTick17 = new org.jfree.chart.axis.DateTick(date10, "CONTRACT", textAnchor12, textAnchor14, 0.2d);
        java.util.Date date18 = dateTickUnit6.addToDate(date10);
        boolean boolean19 = segmentedTimeline0.containsDomainValue(date18);
        boolean boolean20 = segmentedTimeline0.getAdjustForDaylightSaving();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(textAnchor12);
        org.junit.Assert.assertNotNull(itemLabelAnchor13);
        org.junit.Assert.assertNotNull(textAnchor14);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLowerMargin((double) 10.0f);
        org.jfree.data.general.WaferMapDataset waferMapDataset3 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot4 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset3);
        float float5 = waferMapPlot4.getForegroundAlpha();
        java.lang.String str6 = waferMapPlot4.getPlotType();
        boolean boolean7 = categoryAxis0.equals((java.lang.Object) str6);
        float float8 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        float float9 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 1.0f + "'", float5 == 1.0f);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "WMAP_Plot" + "'", str6.equals("WMAP_Plot"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.0f + "'", float8 == 0.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.0f + "'", float9 == 0.0f);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("WMAP_Plot");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: WMAP_Plot" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: WMAP_Plot"));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = statisticalBarRenderer0.getSeriesURLGenerator((int) (short) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        statisticalBarRenderer0.setGradientPaintTransformer(gradientPaintTransformer3);
        java.awt.Paint paint6 = statisticalBarRenderer0.lookupSeriesFillPaint(0);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        statisticalBarRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator7, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = null;
        statisticalBarRenderer0.setSeriesNegativeItemLabelPosition(0, itemLabelPosition11);
        statisticalBarRenderer0.setSeriesItemLabelsVisible(200, false);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D18 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 1L, (double) 31);
        boolean boolean20 = stackedBarRenderer3D18.equals((java.lang.Object) (-1.0f));
        stackedBarRenderer3D18.setRenderAsPercentages(true);
        java.awt.Stroke stroke25 = stackedBarRenderer3D18.getItemOutlineStroke(100, 3);
        statisticalBarRenderer0.setBaseStroke(stroke25, false);
        boolean boolean28 = statisticalBarRenderer0.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator29 = null;
        statisticalBarRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator29, true);
        org.junit.Assert.assertNull(categoryURLGenerator2);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator2 = piePlot1.getToolTipGenerator();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = null;
        piePlot1.setLabelGenerator(pieSectionLabelGenerator3);
        java.awt.Paint paint5 = piePlot1.getLabelBackgroundPaint();
        piePlot1.setPieIndex((int) (short) -1);
        org.junit.Assert.assertNull(pieToolTipGenerator2);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.junit.Assert.assertNotNull(plotOrientation0);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setSeriesLinesVisible((int) '4', (java.lang.Boolean) true);
        boolean boolean4 = lineAndShapeRenderer0.getBaseShapesFilled();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        lineAndShapeRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator5);
        int int7 = lineAndShapeRenderer0.getPassCount();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getUpperBound();
        numberAxis0.setTickMarkOutsideLength((float) (-1L));
        org.jfree.chart.plot.ValueMarker valueMarker5 = new org.jfree.chart.plot.ValueMarker((double) 500);
        java.awt.Stroke stroke6 = valueMarker5.getOutlineStroke();
        numberAxis0.setTickMarkStroke(stroke6);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = null;
        taskSeriesCollection0.seriesChanged(seriesChangeEvent1);
        org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, 9);
        org.jfree.data.Range range5 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        boolean boolean6 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        int int7 = taskSeriesCollection0.getColumnCount();
        org.junit.Assert.assertNotNull(pieDataset4);
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = statisticalBarRenderer0.getSeriesURLGenerator((int) (short) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        statisticalBarRenderer0.setGradientPaintTransformer(gradientPaintTransformer3);
        java.awt.Paint paint6 = statisticalBarRenderer0.lookupSeriesFillPaint(0);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        statisticalBarRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator7, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = null;
        statisticalBarRenderer0.setSeriesNegativeItemLabelPosition(0, itemLabelPosition11);
        double[] doubleArray19 = new double[] { (-1L), 0.0d };
        double[] doubleArray22 = new double[] { (-1L), 0.0d };
        double[] doubleArray25 = new double[] { (-1L), 0.0d };
        double[] doubleArray28 = new double[] { (-1L), 0.0d };
        double[][] doubleArray29 = new double[][] { doubleArray19, doubleArray22, doubleArray25, doubleArray28 };
        org.jfree.data.category.CategoryDataset categoryDataset30 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", doubleArray29);
        org.jfree.data.category.CategoryDataset categoryDataset31 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray29);
        double[] doubleArray38 = new double[] { (-1L), 0.0d };
        double[] doubleArray41 = new double[] { (-1L), 0.0d };
        double[] doubleArray44 = new double[] { (-1L), 0.0d };
        double[] doubleArray47 = new double[] { (-1L), 0.0d };
        double[][] doubleArray48 = new double[][] { doubleArray38, doubleArray41, doubleArray44, doubleArray47 };
        org.jfree.data.category.CategoryDataset categoryDataset49 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", doubleArray48);
        org.jfree.data.category.CategoryDataset categoryDataset50 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray48);
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset51 = new org.jfree.data.category.DefaultIntervalCategoryDataset(doubleArray29, doubleArray48);
        double[] doubleArray56 = new double[] { (-1L), 0.0d };
        double[] doubleArray59 = new double[] { (-1L), 0.0d };
        double[] doubleArray62 = new double[] { (-1L), 0.0d };
        double[] doubleArray65 = new double[] { (-1L), 0.0d };
        double[][] doubleArray66 = new double[][] { doubleArray56, doubleArray59, doubleArray62, doubleArray65 };
        org.jfree.data.category.CategoryDataset categoryDataset67 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", doubleArray66);
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset68 = new org.jfree.data.category.DefaultIntervalCategoryDataset(doubleArray29, doubleArray66);
        org.jfree.data.Range range69 = statisticalBarRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultIntervalCategoryDataset68);
        try {
            java.lang.Comparable comparable71 = defaultIntervalCategoryDataset68.getRowKey((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'row' argument is out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryURLGenerator2);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(categoryDataset30);
        org.junit.Assert.assertNotNull(categoryDataset31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(categoryDataset49);
        org.junit.Assert.assertNotNull(categoryDataset50);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(categoryDataset67);
        org.junit.Assert.assertNotNull(range69);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D5 = labelBlock4.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity8 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D5, "", "Preceding");
        numberAxis0.setDownArrow((java.awt.Shape) rectangle2D5);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = numberAxis0.getLabelInsets();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot11.setRangeCrosshairValue((double) (byte) 1);
        org.jfree.chart.axis.ValueAxis valueAxis14 = categoryPlot11.getRangeAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = categoryPlot11.getDomainAxis((int) ' ');
        boolean boolean17 = numberAxis0.hasListener((java.util.EventListener) categoryPlot11);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = categoryPlot11.getRangeAxisEdge((int) '4');
        org.jfree.chart.plot.Plot plot20 = categoryPlot11.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation22 = categoryPlot11.getRangeAxisLocation((int) (short) 10);
        org.jfree.chart.axis.AxisLocation axisLocation24 = categoryPlot11.getRangeAxisLocation(6);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNull(valueAxis14);
        org.junit.Assert.assertNull(categoryAxis16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertNull(plot20);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertNotNull(axisLocation24);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer1 = new org.jfree.chart.renderer.category.StackedBarRenderer(false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = stackedBarRenderer1.getSeriesURLGenerator(6);
        org.junit.Assert.assertNull(categoryURLGenerator3);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = null;
        taskSeriesCollection0.seriesChanged(seriesChangeEvent1);
        org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, 9);
        org.jfree.data.Range range5 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        boolean boolean6 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        try {
            java.lang.Number number9 = taskSeriesCollection0.getEndValue((java.lang.Comparable) 90.0d, (java.lang.Comparable) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(pieDataset4);
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator2 = piePlot1.getToolTipGenerator();
        java.awt.Color color3 = java.awt.Color.gray;
        piePlot1.setLabelShadowPaint((java.awt.Paint) color3);
        piePlot1.setExplodePercent((java.lang.Comparable) 8.0d, (double) 7);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        double double9 = numberAxis8.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock12 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D13 = labelBlock12.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity16 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D13, "", "Preceding");
        numberAxis8.setDownArrow((java.awt.Shape) rectangle2D13);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = numberAxis8.getLabelInsets();
        java.awt.Shape shape20 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
        numberAxis8.setRightArrow(shape20);
        java.awt.Paint paint22 = numberAxis8.getLabelPaint();
        piePlot1.setBaseSectionPaint(paint22);
        java.awt.Color color24 = java.awt.Color.BLUE;
        piePlot1.setLabelBackgroundPaint((java.awt.Paint) color24);
        double double26 = piePlot1.getShadowXOffset();
        piePlot1.setCircular(false);
        org.junit.Assert.assertNull(pieToolTipGenerator2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 4.0d + "'", double26 == 4.0d);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        int int1 = categoryAxis3D0.getMaximumCategoryLabelLines();
        categoryAxis3D0.setCategoryLabelPositionOffset(128);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        double double7 = numberAxis6.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock10 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D11 = labelBlock10.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity14 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D11, "", "Preceding");
        numberAxis6.setDownArrow((java.awt.Shape) rectangle2D11);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = numberAxis6.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis();
        double double18 = numberAxis17.getUpperBound();
        boolean boolean19 = numberAxis17.getAutoRangeStickyZero();
        boolean boolean20 = numberAxis17.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis17, xYItemRenderer21);
        org.jfree.chart.axis.AxisSpace axisSpace23 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = org.jfree.chart.util.RectangleEdge.LEFT;
        axisSpace23.ensureAtLeast((double) ' ', rectangleEdge25);
        xYPlot22.setFixedDomainAxisSpace(axisSpace23);
        java.awt.Paint paint28 = xYPlot22.getDomainGridlinePaint();
        org.jfree.data.general.WaferMapDataset waferMapDataset29 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot30 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset29);
        java.awt.Graphics2D graphics2D31 = null;
        org.jfree.chart.block.LabelBlock labelBlock34 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D35 = labelBlock34.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity38 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D35, "", "Preceding");
        waferMapPlot30.drawBackgroundImage(graphics2D31, rectangle2D35);
        org.jfree.chart.entity.ChartEntity chartEntity41 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D35, "Preceding");
        java.awt.Shape shape44 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape) rectangle2D35, 12.0d, (double) 10);
        org.jfree.data.xy.XYDataset xYDataset45 = null;
        org.jfree.chart.axis.NumberAxis numberAxis46 = new org.jfree.chart.axis.NumberAxis();
        double double47 = numberAxis46.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock50 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D51 = labelBlock50.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity54 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D51, "", "Preceding");
        numberAxis46.setDownArrow((java.awt.Shape) rectangle2D51);
        org.jfree.chart.util.RectangleInsets rectangleInsets56 = numberAxis46.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis57 = new org.jfree.chart.axis.NumberAxis();
        double double58 = numberAxis57.getUpperBound();
        boolean boolean59 = numberAxis57.getAutoRangeStickyZero();
        boolean boolean60 = numberAxis57.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer61 = null;
        org.jfree.chart.plot.XYPlot xYPlot62 = new org.jfree.chart.plot.XYPlot(xYDataset45, (org.jfree.chart.axis.ValueAxis) numberAxis46, (org.jfree.chart.axis.ValueAxis) numberAxis57, xYItemRenderer61);
        xYPlot62.setRangeCrosshairVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge66 = xYPlot62.getRangeAxisEdge(1);
        xYPlot62.mapDatasetToRangeAxis(500, 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge71 = xYPlot62.getRangeAxisEdge((int) '4');
        org.jfree.chart.axis.AxisSpace axisSpace72 = new org.jfree.chart.axis.AxisSpace();
        try {
            org.jfree.chart.axis.AxisSpace axisSpace73 = categoryAxis3D0.reserveSpace(graphics2D4, (org.jfree.chart.plot.Plot) xYPlot22, rectangle2D35, rectangleEdge71, axisSpace72);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(rectangleEdge25);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(rectangle2D35);
        org.junit.Assert.assertNotNull(shape44);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.0d + "'", double47 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D51);
        org.junit.Assert.assertNotNull(rectangleInsets56);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 1.0d + "'", double58 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertNotNull(rectangleEdge66);
        org.junit.Assert.assertNotNull(rectangleEdge71);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int2 = defaultCategoryDataset0.getColumnIndex((java.lang.Comparable) 10);
        java.lang.Comparable comparable3 = null;
        defaultCategoryDataset0.removeColumn(comparable3);
        java.lang.Comparable comparable6 = null;
        try {
            defaultCategoryDataset0.addValue((double) 200, comparable6, (java.lang.Comparable) false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit(0, 5);
        int int3 = dateTickUnit2.getRollUnit();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month4.previous();
        java.util.Date date6 = month4.getEnd();
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor9 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor10 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor9, textAnchor10);
        org.jfree.chart.axis.DateTick dateTick13 = new org.jfree.chart.axis.DateTick(date6, "CONTRACT", textAnchor8, textAnchor10, 0.2d);
        java.util.Date date14 = dateTickUnit2.addToDate(date6);
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date14, timeZone15);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertNotNull(itemLabelAnchor9);
        org.junit.Assert.assertNotNull(textAnchor10);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        java.lang.ClassLoader classLoader0 = null;
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader0);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 1L, (double) 31);
        boolean boolean4 = stackedBarRenderer3D2.equals((java.lang.Object) (-1.0f));
        stackedBarRenderer3D2.setRenderAsPercentages(true);
        boolean boolean7 = stackedBarRenderer3D2.getRenderAsPercentages();
        stackedBarRenderer3D2.setBaseSeriesVisibleInLegend(false, true);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator13 = statisticalBarRenderer11.getSeriesURLGenerator((int) (short) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer14 = null;
        statisticalBarRenderer11.setGradientPaintTransformer(gradientPaintTransformer14);
        java.awt.Paint paint17 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        statisticalBarRenderer11.setSeriesOutlinePaint(2019, paint17);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier19 = statisticalBarRenderer11.getDrawingSupplier();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator20 = statisticalBarRenderer11.getLegendItemLabelGenerator();
        stackedBarRenderer3D2.setLegendItemURLGenerator(categorySeriesLabelGenerator20);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(categoryURLGenerator13);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNull(drawingSupplier19);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator20);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 1L, (double) 31);
        boolean boolean4 = stackedBarRenderer3D2.equals((java.lang.Object) (-1.0f));
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = null;
        stackedBarRenderer3D2.setLegendItemToolTipGenerator(categorySeriesLabelGenerator5);
        java.awt.Paint paint8 = stackedBarRenderer3D2.lookupSeriesFillPaint((int) ' ');
        org.jfree.chart.block.LabelBlock labelBlock11 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D12 = labelBlock11.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity15 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D12, "", "Preceding");
        stackedBarRenderer3D2.setBaseShape((java.awt.Shape) rectangle2D12, false);
        java.lang.Boolean boolean19 = stackedBarRenderer3D2.getSeriesVisibleInLegend(7);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator20 = null;
        stackedBarRenderer3D2.setBaseItemLabelGenerator(categoryItemLabelGenerator20);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertNull(boolean19);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        boolean boolean1 = textTitle0.getExpandToFitSpace();
        textTitle0.setNotify(false);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryPlot5.getAxisOffset();
        org.jfree.chart.block.LabelBlock labelBlock9 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D10 = labelBlock9.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity13 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D10, "", "Preceding");
        org.jfree.chart.entity.LegendItemEntity legendItemEntity14 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D10);
        java.awt.geom.Rectangle2D rectangle2D15 = rectangleInsets6.createOutsetRectangle(rectangle2D10);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean17 = categoryPlot16.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = categoryPlot16.getDomainAxisEdge((int) (short) 0);
        categoryPlot16.setAnchorValue((double) 10.0f, false);
        org.jfree.data.category.CategoryDataset categoryDataset24 = categoryPlot16.getDataset(2019);
        org.jfree.chart.event.PlotChangeListener plotChangeListener25 = null;
        categoryPlot16.removeChangeListener(plotChangeListener25);
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis();
        double double28 = numberAxis27.getUpperBound();
        boolean boolean29 = numberAxis27.getAutoRangeStickyZero();
        boolean boolean30 = numberAxis27.isAutoRange();
        categoryPlot16.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis27);
        java.lang.Object obj32 = textTitle0.draw(graphics2D4, rectangle2D10, (java.lang.Object) categoryPlot16);
        java.awt.Paint paint33 = categoryPlot16.getOutlinePaint();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertNull(categoryDataset24);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0d + "'", double28 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNull(obj32);
        org.junit.Assert.assertNotNull(paint33);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D5 = labelBlock4.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity8 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D5, "", "Preceding");
        org.jfree.chart.entity.LegendItemEntity legendItemEntity9 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D5);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer10 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint11 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        statisticalBarRenderer10.setBasePaint(paint11);
        org.jfree.chart.title.LegendGraphic legendGraphic13 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape) rectangle2D5, paint11);
        org.jfree.chart.text.TextMeasurer textMeasurer15 = null;
        org.jfree.chart.text.TextBlock textBlock16 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint11, (float) (short) 0, textMeasurer15);
        org.jfree.chart.text.TextLine textLine17 = textBlock16.getLastLine();
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.util.Size2D size2D19 = textBlock16.calculateDimensions(graphics2D18);
        org.jfree.chart.text.TextLine textLine21 = new org.jfree.chart.text.TextLine("CategoryLabelEntity: category=false, tooltip=, url=Preceding");
        textBlock16.addLine(textLine21);
        org.jfree.chart.text.TextLine textLine23 = textBlock16.getLastLine();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(textBlock16);
        org.junit.Assert.assertNull(textLine17);
        org.junit.Assert.assertNotNull(size2D19);
        org.junit.Assert.assertNotNull(textLine23);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D6 = labelBlock5.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D6, "", "Preceding");
        numberAxis1.setDownArrow((java.awt.Shape) rectangle2D6);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis1.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        double double13 = numberAxis12.getUpperBound();
        boolean boolean14 = numberAxis12.getAutoRangeStickyZero();
        boolean boolean15 = numberAxis12.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer16);
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = xYPlot17.getRendererForDataset(xYDataset18);
        org.jfree.chart.axis.AxisSpace axisSpace20 = xYPlot17.getFixedDomainAxisSpace();
        boolean boolean21 = xYPlot17.isDomainZeroBaselineVisible();
        org.jfree.chart.plot.Marker marker22 = null;
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis();
        double double25 = numberAxis24.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock28 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D29 = labelBlock28.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity32 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D29, "", "Preceding");
        numberAxis24.setDownArrow((java.awt.Shape) rectangle2D29);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = numberAxis24.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis();
        double double36 = numberAxis35.getUpperBound();
        boolean boolean37 = numberAxis35.getAutoRangeStickyZero();
        boolean boolean38 = numberAxis35.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer39 = null;
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot(xYDataset23, (org.jfree.chart.axis.ValueAxis) numberAxis24, (org.jfree.chart.axis.ValueAxis) numberAxis35, xYItemRenderer39);
        org.jfree.data.xy.XYDataset xYDataset42 = null;
        xYPlot40.setDataset(5, xYDataset42);
        org.jfree.chart.util.Layer layer44 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection45 = xYPlot40.getRangeMarkers(layer44);
        try {
            xYPlot17.addRangeMarker(marker22, layer44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(xYItemRenderer19);
        org.junit.Assert.assertNull(axisSpace20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.0d + "'", double36 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(layer44);
        org.junit.Assert.assertNull(collection45);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        double[] doubleArray6 = new double[] { (-1L), 0.0d };
        double[] doubleArray9 = new double[] { (-1L), 0.0d };
        double[] doubleArray12 = new double[] { (-1L), 0.0d };
        double[] doubleArray15 = new double[] { (-1L), 0.0d };
        double[][] doubleArray16 = new double[][] { doubleArray6, doubleArray9, doubleArray12, doubleArray15 };
        org.jfree.data.category.CategoryDataset categoryDataset17 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", doubleArray16);
        org.jfree.data.category.CategoryDataset categoryDataset18 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray16);
        double[] doubleArray25 = new double[] { (-1L), 0.0d };
        double[] doubleArray28 = new double[] { (-1L), 0.0d };
        double[] doubleArray31 = new double[] { (-1L), 0.0d };
        double[] doubleArray34 = new double[] { (-1L), 0.0d };
        double[][] doubleArray35 = new double[][] { doubleArray25, doubleArray28, doubleArray31, doubleArray34 };
        org.jfree.data.category.CategoryDataset categoryDataset36 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", doubleArray35);
        org.jfree.data.category.CategoryDataset categoryDataset37 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray35);
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset38 = new org.jfree.data.category.DefaultIntervalCategoryDataset(doubleArray16, doubleArray35);
        double[] doubleArray43 = new double[] { (-1L), 0.0d };
        double[] doubleArray46 = new double[] { (-1L), 0.0d };
        double[] doubleArray49 = new double[] { (-1L), 0.0d };
        double[] doubleArray52 = new double[] { (-1L), 0.0d };
        double[][] doubleArray53 = new double[][] { doubleArray43, doubleArray46, doubleArray49, doubleArray52 };
        org.jfree.data.category.CategoryDataset categoryDataset54 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", doubleArray53);
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset55 = new org.jfree.data.category.DefaultIntervalCategoryDataset(doubleArray16, doubleArray53);
        org.jfree.data.KeyedObjects2D keyedObjects2D56 = new org.jfree.data.KeyedObjects2D();
        org.jfree.data.general.PieDataset pieDataset57 = null;
        org.jfree.chart.plot.PiePlot piePlot58 = new org.jfree.chart.plot.PiePlot(pieDataset57);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator59 = piePlot58.getToolTipGenerator();
        java.awt.Color color60 = java.awt.Color.gray;
        piePlot58.setLabelShadowPaint((java.awt.Paint) color60);
        piePlot58.setExplodePercent((java.lang.Comparable) 8.0d, (double) 7);
        org.jfree.chart.axis.NumberAxis numberAxis65 = new org.jfree.chart.axis.NumberAxis();
        double double66 = numberAxis65.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock69 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D70 = labelBlock69.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity73 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D70, "", "Preceding");
        numberAxis65.setDownArrow((java.awt.Shape) rectangle2D70);
        org.jfree.chart.util.RectangleInsets rectangleInsets75 = numberAxis65.getLabelInsets();
        java.awt.Shape shape77 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
        numberAxis65.setRightArrow(shape77);
        java.awt.Paint paint79 = numberAxis65.getLabelPaint();
        piePlot58.setBaseSectionPaint(paint79);
        org.jfree.chart.util.Rotation rotation81 = piePlot58.getDirection();
        boolean boolean82 = piePlot58.getSectionOutlinesVisible();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit84 = new org.jfree.chart.axis.NumberTickUnit((double) 100L);
        java.awt.Paint paint85 = piePlot58.getSectionOutlinePaint((java.lang.Comparable) numberTickUnit84);
        int int86 = keyedObjects2D56.getRowIndex((java.lang.Comparable) numberTickUnit84);
        int int87 = defaultIntervalCategoryDataset55.getRowIndex((java.lang.Comparable) numberTickUnit84);
        java.lang.Object obj88 = defaultIntervalCategoryDataset55.clone();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(categoryDataset17);
        org.junit.Assert.assertNotNull(categoryDataset18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(categoryDataset36);
        org.junit.Assert.assertNotNull(categoryDataset37);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(categoryDataset54);
        org.junit.Assert.assertNull(pieToolTipGenerator59);
        org.junit.Assert.assertNotNull(color60);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 1.0d + "'", double66 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D70);
        org.junit.Assert.assertNotNull(rectangleInsets75);
        org.junit.Assert.assertNotNull(shape77);
        org.junit.Assert.assertNotNull(paint79);
        org.junit.Assert.assertNotNull(rotation81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
        org.junit.Assert.assertNull(paint85);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + (-1) + "'", int86 == (-1));
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + (-1) + "'", int87 == (-1));
        org.junit.Assert.assertNotNull(obj88);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        java.awt.Paint paint0 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePaint(paint0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        double double3 = numberAxis2.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D7 = labelBlock6.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity10 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D7, "", "Preceding");
        numberAxis2.setDownArrow((java.awt.Shape) rectangle2D7);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = numberAxis2.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        double double14 = numberAxis13.getUpperBound();
        boolean boolean15 = numberAxis13.getAutoRangeStickyZero();
        boolean boolean16 = numberAxis13.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis13, xYItemRenderer17);
        xYPlot18.setRangeCrosshairVisible(false);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("WMAP_Plot", (org.jfree.chart.plot.Plot) xYPlot18);
        boolean boolean22 = jFreeChart21.isNotify();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo25 = null;
        java.awt.image.BufferedImage bufferedImage26 = jFreeChart21.createBufferedImage(1, 6, chartRenderingInfo25);
        org.jfree.chart.event.ChartChangeListener chartChangeListener27 = null;
        try {
            jFreeChart21.removeChangeListener(chartChangeListener27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(bufferedImage26);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.awt.Image image1 = null;
        projectInfo0.setLogo(image1);
        java.lang.String str3 = projectInfo0.getLicenceName();
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Comparable comparable2 = keyedObjects0.getKey(0);
        org.junit.Assert.assertNull(comparable2);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        java.text.AttributedString attributedString0 = null;
        org.jfree.data.general.WaferMapDataset waferMapDataset4 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot5 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.block.LabelBlock labelBlock9 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D10 = labelBlock9.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity13 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D10, "", "Preceding");
        waferMapPlot5.drawBackgroundImage(graphics2D6, rectangle2D10);
        java.awt.Color color15 = java.awt.Color.YELLOW;
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month16.previous();
        org.jfree.data.time.Year year18 = month16.getYear();
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis();
        double double21 = numberAxis20.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock24 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D25 = labelBlock24.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity28 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D25, "", "Preceding");
        numberAxis20.setDownArrow((java.awt.Shape) rectangle2D25);
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = numberAxis20.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis();
        double double32 = numberAxis31.getUpperBound();
        boolean boolean33 = numberAxis31.getAutoRangeStickyZero();
        boolean boolean34 = numberAxis31.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = null;
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot(xYDataset19, (org.jfree.chart.axis.ValueAxis) numberAxis20, (org.jfree.chart.axis.ValueAxis) numberAxis31, xYItemRenderer35);
        boolean boolean37 = xYPlot36.isDomainCrosshairVisible();
        org.jfree.chart.axis.AxisLocation axisLocation39 = xYPlot36.getRangeAxisLocation((int) (short) -1);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer40 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke41 = statisticalBarRenderer40.getBaseStroke();
        xYPlot36.setDomainZeroBaselineStroke(stroke41);
        int int43 = year18.compareTo((java.lang.Object) stroke41);
        org.jfree.chart.block.LabelBlock labelBlock47 = new org.jfree.chart.block.LabelBlock("");
        java.awt.Font font48 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        labelBlock47.setFont(font48);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer50 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator52 = statisticalBarRenderer50.getSeriesURLGenerator((int) (short) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer53 = null;
        statisticalBarRenderer50.setGradientPaintTransformer(gradientPaintTransformer53);
        java.awt.Paint paint56 = statisticalBarRenderer50.lookupSeriesFillPaint(0);
        org.jfree.chart.text.TextFragment textFragment57 = new org.jfree.chart.text.TextFragment("", font48, paint56);
        java.awt.Color color58 = java.awt.Color.orange;
        org.jfree.chart.block.LabelBlock labelBlock59 = new org.jfree.chart.block.LabelBlock("Preceding", font48, (java.awt.Paint) color58);
        try {
            org.jfree.chart.LegendItem legendItem60 = new org.jfree.chart.LegendItem(attributedString0, "ClassContext", "rect", "", (java.awt.Shape) rectangle2D10, (java.awt.Paint) color15, stroke41, (java.awt.Paint) color58);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(year18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0d + "'", double32 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(axisLocation39);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertNotNull(font48);
        org.junit.Assert.assertNull(categoryURLGenerator52);
        org.junit.Assert.assertNotNull(paint56);
        org.junit.Assert.assertNotNull(color58);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.chart.renderer.category.AreaRenderer areaRenderer0 = new org.jfree.chart.renderer.category.AreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.JFreeChart jFreeChart2 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent5 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) categoryPlot1, jFreeChart2, 200, (int) (byte) 0);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor6 = categoryPlot1.getDomainGridlinePosition();
        categoryPlot1.setAnchorValue((double) 900000L, false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer10 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke11 = statisticalBarRenderer10.getBaseStroke();
        categoryPlot1.setRangeCrosshairStroke(stroke11);
        areaRenderer0.setBaseOutlineStroke(stroke11, true);
        org.junit.Assert.assertNotNull(categoryAnchor6);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.data.time.DateRange dateRange0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double1 = dateRange0.getCentralValue();
        org.jfree.data.time.DateRange dateRange2 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double3 = dateRange2.getCentralValue();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange0, (org.jfree.data.Range) dateRange2);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType5 = rectangleConstraint4.getWidthConstraintType();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType6 = rectangleConstraint4.getWidthConstraintType();
        org.junit.Assert.assertNotNull(dateRange0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5d + "'", double1 == 0.5d);
        org.junit.Assert.assertNotNull(dateRange2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.5d + "'", double3 == 0.5d);
        org.junit.Assert.assertNotNull(lengthConstraintType5);
        org.junit.Assert.assertNotNull(lengthConstraintType6);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.chart.entity.EntityCollection entityCollection0 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo1 = new org.jfree.chart.ChartRenderingInfo(entityCollection0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = chartRenderingInfo1.getPlotInfo();
        org.jfree.data.general.WaferMapDataset waferMapDataset3 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot4 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.block.LabelBlock labelBlock8 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D9 = labelBlock8.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity12 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D9, "", "Preceding");
        waferMapPlot4.drawBackgroundImage(graphics2D5, rectangle2D9);
        chartRenderingInfo1.setChartArea(rectangle2D9);
        org.junit.Assert.assertNotNull(plotRenderingInfo2);
        org.junit.Assert.assertNotNull(rectangle2D9);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D6 = labelBlock5.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D6, "", "Preceding");
        numberAxis1.setDownArrow((java.awt.Shape) rectangle2D6);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis1.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        double double13 = numberAxis12.getUpperBound();
        boolean boolean14 = numberAxis12.getAutoRangeStickyZero();
        boolean boolean15 = numberAxis12.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer16);
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = xYPlot17.getRendererForDataset(xYDataset18);
        java.lang.Object obj20 = xYPlot17.clone();
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = xYPlot17.getRangeAxisEdge(11);
        xYPlot17.setDomainGridlinesVisible(false);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(xYItemRenderer19);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(rectangleEdge22);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.data.time.DateRange dateRange0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange0, (double) '#');
        double double3 = dateRange0.getCentralValue();
        org.junit.Assert.assertNotNull(dateRange0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.5d + "'", double3 == 0.5d);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        double double3 = numberAxis2.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D7 = labelBlock6.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity10 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D7, "", "Preceding");
        numberAxis2.setDownArrow((java.awt.Shape) rectangle2D7);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = numberAxis2.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        double double14 = numberAxis13.getUpperBound();
        boolean boolean15 = numberAxis13.getAutoRangeStickyZero();
        boolean boolean16 = numberAxis13.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis13, xYItemRenderer17);
        xYPlot18.setRangeCrosshairVisible(false);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("WMAP_Plot", (org.jfree.chart.plot.Plot) xYPlot18);
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle();
        jFreeChart21.addSubtitle((org.jfree.chart.title.Title) textTitle22);
        jFreeChart21.setBackgroundImageAlpha((float) 1900);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        double double4 = numberAxis3.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock7 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D8 = labelBlock7.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity11 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D8, "", "Preceding");
        numberAxis3.setDownArrow((java.awt.Shape) rectangle2D8);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = numberAxis3.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        double double15 = numberAxis14.getUpperBound();
        boolean boolean16 = numberAxis14.getAutoRangeStickyZero();
        boolean boolean17 = numberAxis14.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis14, xYItemRenderer18);
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        xYPlot19.setDataset(5, xYDataset21);
        org.jfree.chart.JFreeChart jFreeChart24 = new org.jfree.chart.JFreeChart("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", font1, (org.jfree.chart.plot.Plot) xYPlot19, true);
        org.jfree.chart.title.TextTitle textTitle25 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj26 = textTitle25.clone();
        jFreeChart24.removeSubtitle((org.jfree.chart.title.Title) textTitle25);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = jFreeChart24.getPadding();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertNotNull(rectangleInsets28);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.data.time.DateRange dateRange0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double1 = dateRange0.getCentralValue();
        double double2 = dateRange0.getUpperBound();
        java.util.Date date3 = dateRange0.getLowerDate();
        org.jfree.data.Range range5 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange0, 3.0d);
        org.junit.Assert.assertNotNull(dateRange0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5d + "'", double1 == 0.5d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(range5);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        labelBlock1.setFont(font2);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.data.time.DateRange dateRange5 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double6 = dateRange5.getCentralValue();
        org.jfree.data.time.DateRange dateRange7 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double8 = dateRange7.getCentralValue();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange5, (org.jfree.data.Range) dateRange7);
        org.jfree.data.time.DateRange dateRange10 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double11 = dateRange10.getCentralValue();
        org.jfree.data.time.DateRange dateRange12 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double13 = dateRange12.getCentralValue();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange10, (org.jfree.data.Range) dateRange12);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = rectangleConstraint14.toFixedHeight((double) 10.0f);
        org.jfree.data.Range range17 = rectangleConstraint14.getWidthRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = rectangleConstraint9.toRangeHeight(range17);
        try {
            org.jfree.chart.util.Size2D size2D19 = labelBlock1.arrange(graphics2D4, rectangleConstraint18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(dateRange5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.5d + "'", double6 == 0.5d);
        org.junit.Assert.assertNotNull(dateRange7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.5d + "'", double8 == 0.5d);
        org.junit.Assert.assertNotNull(dateRange10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.5d + "'", double11 == 0.5d);
        org.junit.Assert.assertNotNull(dateRange12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.5d + "'", double13 == 0.5d);
        org.junit.Assert.assertNotNull(rectangleConstraint16);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNotNull(rectangleConstraint18);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        int int0 = org.jfree.data.time.SerialDate.PRECEDING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 1L, (double) 31);
        boolean boolean4 = stackedBarRenderer3D2.equals((java.lang.Object) (-1.0f));
        stackedBarRenderer3D2.setRenderAsPercentages(true);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier7 = stackedBarRenderer3D2.getDrawingSupplier();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent8 = null;
        stackedBarRenderer3D2.notifyListeners(rendererChangeEvent8);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(drawingSupplier7);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D6 = labelBlock5.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D6, "", "Preceding");
        numberAxis1.setDownArrow((java.awt.Shape) rectangle2D6);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis1.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        double double13 = numberAxis12.getUpperBound();
        boolean boolean14 = numberAxis12.getAutoRangeStickyZero();
        boolean boolean15 = numberAxis12.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer16);
        xYPlot17.setRangeCrosshairVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = xYPlot17.getRangeAxisEdge(1);
        xYPlot17.mapDatasetToRangeAxis(500, 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = xYPlot17.getRangeAxisEdge((int) '4');
        boolean boolean27 = xYPlot17.isRangeZeroBaselineVisible();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D5 = labelBlock4.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity8 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D5, "", "Preceding");
        numberAxis0.setDownArrow((java.awt.Shape) rectangle2D5);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = numberAxis0.getLabelInsets();
        numberAxis0.setVerticalTickLabels(true);
        org.jfree.data.Range range13 = numberAxis0.getDefaultAutoRange();
        org.jfree.data.Range range14 = numberAxis0.getRange();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNotNull(range14);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        double[] doubleArray8 = new double[] { (-1L), 0.0d };
        double[] doubleArray11 = new double[] { (-1L), 0.0d };
        double[] doubleArray14 = new double[] { (-1L), 0.0d };
        double[] doubleArray17 = new double[] { (-1L), 0.0d };
        double[][] doubleArray18 = new double[][] { doubleArray8, doubleArray11, doubleArray14, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", doubleArray18);
        org.jfree.data.category.CategoryDataset categoryDataset20 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray18);
        double[] doubleArray27 = new double[] { (-1L), 0.0d };
        double[] doubleArray30 = new double[] { (-1L), 0.0d };
        double[] doubleArray33 = new double[] { (-1L), 0.0d };
        double[] doubleArray36 = new double[] { (-1L), 0.0d };
        double[][] doubleArray37 = new double[][] { doubleArray27, doubleArray30, doubleArray33, doubleArray36 };
        org.jfree.data.category.CategoryDataset categoryDataset38 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", doubleArray37);
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray37);
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset40 = new org.jfree.data.category.DefaultIntervalCategoryDataset(doubleArray18, doubleArray37);
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "ThreadContext", doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertNotNull(categoryDataset20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(categoryDataset38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(categoryDataset41);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType2 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition4 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1, categoryLabelWidthType2, (float) 2958465);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor5 = null;
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month6.previous();
        java.util.Date date8 = month6.getEnd();
        org.jfree.chart.text.TextAnchor textAnchor10 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor11 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor12 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor11, textAnchor12);
        org.jfree.chart.axis.DateTick dateTick15 = new org.jfree.chart.axis.DateTick(date8, "CONTRACT", textAnchor10, textAnchor12, 0.2d);
        double double16 = dateTick15.getValue();
        org.jfree.chart.text.TextAnchor textAnchor17 = dateTick15.getTextAnchor();
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType19 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition21 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor5, textAnchor17, (double) '#', categoryLabelWidthType19, (float) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'labelAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(categoryLabelWidthType2);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(textAnchor10);
        org.junit.Assert.assertNotNull(itemLabelAnchor11);
        org.junit.Assert.assertNotNull(textAnchor12);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.561964399999E12d + "'", double16 == 1.561964399999E12d);
        org.junit.Assert.assertNotNull(textAnchor17);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        boolean boolean3 = month0.equals((java.lang.Object) chartChangeEventType2);
        java.util.Calendar calendar4 = null;
        try {
            month0.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(chartChangeEventType2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean1 = lineAndShapeRenderer0.getDrawOutlines();
        java.lang.Boolean boolean3 = lineAndShapeRenderer0.getSeriesLinesVisible(5);
        boolean boolean4 = lineAndShapeRenderer0.getDrawOutlines();
        lineAndShapeRenderer0.setAutoPopulateSeriesStroke(true);
        java.lang.Boolean boolean8 = lineAndShapeRenderer0.getSeriesShapesVisible(5);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer10 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint11 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        statisticalBarRenderer10.setBasePaint(paint11);
        boolean boolean13 = statisticalBarRenderer10.getIncludeBaseInRange();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer14.setSeriesLinesVisible((int) '4', (java.lang.Boolean) true);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor19 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE7;
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor21 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition23 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor19, textAnchor20, textAnchor21, (double) 0L);
        lineAndShapeRenderer14.setSeriesNegativeItemLabelPosition((int) '4', itemLabelPosition23);
        statisticalBarRenderer10.setBaseNegativeItemLabelPosition(itemLabelPosition23);
        org.jfree.data.RangeType rangeType26 = org.jfree.data.RangeType.NEGATIVE;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean28 = categoryPlot27.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = categoryPlot27.getDomainAxisEdge((int) (short) 0);
        categoryPlot27.setAnchorValue((double) 10.0f, false);
        org.jfree.data.category.CategoryDataset categoryDataset35 = categoryPlot27.getDataset(2019);
        org.jfree.chart.event.PlotChangeListener plotChangeListener36 = null;
        categoryPlot27.removeChangeListener(plotChangeListener36);
        boolean boolean38 = rangeType26.equals((java.lang.Object) categoryPlot27);
        statisticalBarRenderer10.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot27);
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        org.jfree.chart.plot.Marker marker41 = null;
        org.jfree.chart.block.LabelBlock labelBlock44 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D45 = labelBlock44.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity48 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D45, "", "Preceding");
        org.jfree.chart.entity.LegendItemEntity legendItemEntity49 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D45);
        lineAndShapeRenderer0.drawRangeMarker(graphics2D9, categoryPlot27, valueAxis40, marker41, rectangle2D45);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(boolean3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(boolean8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(itemLabelAnchor19);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(textAnchor21);
        org.junit.Assert.assertNotNull(rangeType26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertNull(categoryDataset35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(rectangle2D45);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        java.awt.Paint paint0 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("VerticalAlignment.BOTTOM");
        java.lang.Object obj2 = datasetGroup1.clone();
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getUpperBound();
        boolean boolean3 = numberAxis1.getAutoRangeStickyZero();
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        double double5 = numberAxis4.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock8 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D9 = labelBlock8.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity12 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D9, "", "Preceding");
        numberAxis4.setDownArrow((java.awt.Shape) rectangle2D9);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = numberAxis4.getLabelInsets();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot15.setRangeCrosshairValue((double) (byte) 1);
        org.jfree.chart.axis.ValueAxis valueAxis18 = categoryPlot15.getRangeAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = categoryPlot15.getDomainAxis((int) ' ');
        boolean boolean21 = numberAxis4.hasListener((java.util.EventListener) categoryPlot15);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis4, xYItemRenderer22);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        xYPlot23.setRenderer(xYItemRenderer24);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder26 = xYPlot23.getSeriesRenderingOrder();
        org.jfree.chart.axis.ValueAxis valueAxis27 = xYPlot23.getDomainAxis();
        org.jfree.data.xy.XYDataset xYDataset28 = null;
        xYPlot23.setDataset(xYDataset28);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D9);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNull(valueAxis18);
        org.junit.Assert.assertNull(categoryAxis20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(seriesRenderingOrder26);
        org.junit.Assert.assertNotNull(valueAxis27);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation5 = categoryPlot0.getDomainAxisLocation((int) '4');
        org.jfree.chart.axis.AxisSpace axisSpace6 = new org.jfree.chart.axis.AxisSpace();
        categoryPlot0.setFixedRangeAxisSpace(axisSpace6);
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot0);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        double double10 = numberAxis9.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock13 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D14 = labelBlock13.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity17 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D14, "", "Preceding");
        numberAxis9.setDownArrow((java.awt.Shape) rectangle2D14);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = numberAxis9.getLabelInsets();
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
        numberAxis9.setRightArrow(shape21);
        java.awt.Paint paint23 = numberAxis9.getLabelPaint();
        boolean boolean24 = legendTitle8.equals((java.lang.Object) numberAxis9);
        legendTitle8.setMargin((double) 15, (double) (byte) 10, (double) 3, (double) 9);
        java.awt.Paint paint30 = legendTitle8.getBackgroundPaint();
        java.awt.Graphics2D graphics2D31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = categoryPlot32.getAxisOffset();
        org.jfree.chart.block.LabelBlock labelBlock36 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D37 = labelBlock36.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity40 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D37, "", "Preceding");
        org.jfree.chart.entity.LegendItemEntity legendItemEntity41 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D37);
        java.awt.geom.Rectangle2D rectangle2D42 = rectangleInsets33.createOutsetRectangle(rectangle2D37);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D45 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 1L, (double) 31);
        java.awt.Graphics2D graphics2D46 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot47 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis48 = new org.jfree.chart.axis.NumberAxis();
        double double49 = numberAxis48.getUpperBound();
        boolean boolean50 = numberAxis48.getAutoRangeStickyZero();
        org.jfree.chart.plot.Marker marker51 = null;
        org.jfree.data.general.WaferMapDataset waferMapDataset52 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot53 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset52);
        java.awt.Graphics2D graphics2D54 = null;
        org.jfree.chart.block.LabelBlock labelBlock57 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D58 = labelBlock57.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity61 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D58, "", "Preceding");
        waferMapPlot53.drawBackgroundImage(graphics2D54, rectangle2D58);
        stackedBarRenderer3D45.drawRangeMarker(graphics2D46, categoryPlot47, (org.jfree.chart.axis.ValueAxis) numberAxis48, marker51, rectangle2D58);
        org.jfree.chart.util.RectangleInsets rectangleInsets64 = categoryPlot47.getAxisOffset();
        boolean boolean65 = categoryPlot47.getDrawSharedDomainAxis();
        try {
            java.lang.Object obj66 = legendTitle8.draw(graphics2D31, rectangle2D37, (java.lang.Object) categoryPlot47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(paint30);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertNotNull(rectangle2D37);
        org.junit.Assert.assertNotNull(rectangle2D42);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 1.0d + "'", double49 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(rectangle2D58);
        org.junit.Assert.assertNotNull(rectangleInsets64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.data.DefaultKeyedValue defaultKeyedValue2 = new org.jfree.data.DefaultKeyedValue((java.lang.Comparable) 0.0d, (java.lang.Number) 100.0f);
        java.lang.Number number3 = defaultKeyedValue2.getValue();
        defaultKeyedValue2.setValue((java.lang.Number) (-3.0d));
        java.lang.Number number6 = defaultKeyedValue2.getValue();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 100.0f + "'", number3.equals(100.0f));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-3.0d) + "'", number6.equals((-3.0d)));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D3 = labelBlock2.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity6 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D3, "", "Preceding");
        org.jfree.chart.entity.LegendItemEntity legendItemEntity7 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D3);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint9 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        statisticalBarRenderer8.setBasePaint(paint9);
        org.jfree.chart.title.LegendGraphic legendGraphic11 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape) rectangle2D3, paint9);
        java.awt.Shape shape12 = legendGraphic11.getLine();
        double double13 = legendGraphic11.getContentYOffset();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D16 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 1L, (double) 31);
        boolean boolean18 = stackedBarRenderer3D16.equals((java.lang.Object) (-1.0f));
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator19 = null;
        stackedBarRenderer3D16.setLegendItemToolTipGenerator(categorySeriesLabelGenerator19);
        java.awt.Color color21 = java.awt.Color.YELLOW;
        stackedBarRenderer3D16.setBaseItemLabelPaint((java.awt.Paint) color21);
        legendGraphic11.setLinePaint((java.awt.Paint) color21);
        java.awt.Paint paint24 = legendGraphic11.getFillPaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor25 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor26 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType27 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition29 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor25, textBlockAnchor26, categoryLabelWidthType27, (float) 2958465);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor30 = categoryLabelPosition29.getCategoryAnchor();
        legendGraphic11.setShapeLocation(rectangleAnchor30);
        org.junit.Assert.assertNotNull(rectangle2D3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(shape12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.0d + "'", double13 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(rectangleAnchor25);
        org.junit.Assert.assertNotNull(textBlockAnchor26);
        org.junit.Assert.assertNotNull(categoryLabelWidthType27);
        org.junit.Assert.assertNotNull(rectangleAnchor30);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator0 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        java.awt.Color color1 = java.awt.Color.getColor("CONTRACT");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        levelRenderer0.setItemMargin((double) '#');
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D6 = labelBlock5.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D6, "", "Preceding");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer10 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator12 = statisticalBarRenderer10.getSeriesURLGenerator((int) (short) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer13 = null;
        statisticalBarRenderer10.setGradientPaintTransformer(gradientPaintTransformer13);
        java.awt.Paint paint16 = statisticalBarRenderer10.lookupSeriesFillPaint(0);
        boolean boolean17 = categoryLabelEntity9.equals((java.lang.Object) statisticalBarRenderer10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer18 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer18.setSeriesLinesVisible((int) '4', (java.lang.Boolean) true);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor23 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE7;
        org.jfree.chart.text.TextAnchor textAnchor24 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor25 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition27 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor23, textAnchor24, textAnchor25, (double) 0L);
        lineAndShapeRenderer18.setSeriesNegativeItemLabelPosition((int) '4', itemLabelPosition27);
        org.jfree.data.DefaultKeyedValue defaultKeyedValue31 = new org.jfree.data.DefaultKeyedValue((java.lang.Comparable) 0.0d, (java.lang.Number) 100.0f);
        boolean boolean32 = itemLabelPosition27.equals((java.lang.Object) 0.0d);
        statisticalBarRenderer10.setPositiveItemLabelPositionFallback(itemLabelPosition27);
        levelRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition27, false);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNull(categoryURLGenerator12);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor23);
        org.junit.Assert.assertNotNull(textAnchor24);
        org.junit.Assert.assertNotNull(textAnchor25);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", numberArray2);
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D6 = labelBlock5.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D6, "", "Preceding");
        numberAxis1.setDownArrow((java.awt.Shape) rectangle2D6);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis1.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        double double13 = numberAxis12.getUpperBound();
        boolean boolean14 = numberAxis12.getAutoRangeStickyZero();
        boolean boolean15 = numberAxis12.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer16);
        xYPlot17.setRangeCrosshairVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean22 = categoryPlot21.isDomainGridlinesVisible();
        org.jfree.chart.axis.AxisLocation axisLocation23 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot21.setDomainAxisLocation(axisLocation23);
        xYPlot17.setRangeAxisLocation((int) (byte) 10, axisLocation23);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = xYPlot17.getRenderer((int) (short) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertNull(xYItemRenderer27);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        int int1 = segmentedTimeline0.getSegmentsIncluded();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = new org.jfree.chart.axis.DateTickUnit(0, 5);
        int int5 = dateTickUnit4.getRollUnit();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month6.previous();
        java.util.Date date8 = month6.getEnd();
        org.jfree.chart.text.TextAnchor textAnchor10 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor11 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor12 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor11, textAnchor12);
        org.jfree.chart.axis.DateTick dateTick15 = new org.jfree.chart.axis.DateTick(date8, "CONTRACT", textAnchor10, textAnchor12, 0.2d);
        java.util.Date date16 = dateTickUnit4.addToDate(date8);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment17 = segmentedTimeline0.getSegment(date16);
        org.jfree.chart.text.TextAnchor textAnchor19 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker((double) 500);
        java.awt.Stroke stroke22 = valueMarker21.getOutlineStroke();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType23 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer24 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean25 = lengthAdjustmentType23.equals((java.lang.Object) lineAndShapeRenderer24);
        java.lang.String str26 = lengthAdjustmentType23.toString();
        valueMarker21.setLabelOffsetType(lengthAdjustmentType23);
        java.awt.Paint paint28 = valueMarker21.getOutlinePaint();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor29 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE7;
        org.jfree.chart.text.TextAnchor textAnchor30 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor31 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition33 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor29, textAnchor30, textAnchor31, (double) 0L);
        valueMarker21.setLabelTextAnchor(textAnchor30);
        org.jfree.chart.axis.DateTick dateTick36 = new org.jfree.chart.axis.DateTick(date16, "CONTRACT", textAnchor19, textAnchor30, (double) (short) 10);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 5 + "'", int1 == 5);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(textAnchor10);
        org.junit.Assert.assertNotNull(itemLabelAnchor11);
        org.junit.Assert.assertNotNull(textAnchor12);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(segment17);
        org.junit.Assert.assertNotNull(textAnchor19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(lengthAdjustmentType23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "CONTRACT" + "'", str26.equals("CONTRACT"));
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(itemLabelAnchor29);
        org.junit.Assert.assertNotNull(textAnchor30);
        org.junit.Assert.assertNotNull(textAnchor31);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        java.text.DateFormat dateFormat4 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit5 = new org.jfree.chart.axis.DateTickUnit((int) 'a', 0, 0, (int) 'a', dateFormat4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DateTickUnit.getMillisecondCount() : unit must be one of the constants YEAR, MONTH, DAY, HOUR, MINUTE, SECOND or MILLISECOND defined in the DateTickUnit class. Do *not* use the constants defined in java.util.Calendar.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.data.time.DateRange dateRange0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double1 = dateRange0.getCentralValue();
        org.jfree.data.time.DateRange dateRange2 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double3 = dateRange2.getCentralValue();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange0, (org.jfree.data.Range) dateRange2);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType5 = rectangleConstraint4.getHeightConstraintType();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType6 = rectangleConstraint4.getHeightConstraintType();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent7 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) rectangleConstraint4);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType8 = chartChangeEvent7.getType();
        org.junit.Assert.assertNotNull(dateRange0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5d + "'", double1 == 0.5d);
        org.junit.Assert.assertNotNull(dateRange2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.5d + "'", double3 == 0.5d);
        org.junit.Assert.assertNotNull(lengthConstraintType5);
        org.junit.Assert.assertNotNull(lengthConstraintType6);
        org.junit.Assert.assertNotNull(chartChangeEventType8);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairValue((double) (byte) 1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        categoryPlot0.setRangeCrosshairValue((double) '#');
        org.jfree.chart.util.SortOrder sortOrder6 = org.jfree.chart.util.SortOrder.ASCENDING;
        java.awt.Paint paint7 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        boolean boolean8 = sortOrder6.equals((java.lang.Object) paint7);
        categoryPlot0.setRowRenderingOrder(sortOrder6);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(sortOrder6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D3 = labelBlock2.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity6 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D3, "", "Preceding");
        org.jfree.chart.entity.LegendItemEntity legendItemEntity7 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D3);
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator8 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator9 = null;
        java.lang.String str10 = legendItemEntity7.getImageMapAreaTag(toolTipTagFragmentGenerator8, uRLTagFragmentGenerator9);
        java.lang.Comparable comparable11 = legendItemEntity7.getSeriesKey();
        org.junit.Assert.assertNotNull(rectangle2D3);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNull(comparable11);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean1 = lineAndShapeRenderer0.getDrawOutlines();
        java.lang.Boolean boolean3 = lineAndShapeRenderer0.getSeriesLinesVisible(5);
        lineAndShapeRenderer0.setSeriesItemLabelsVisible(2, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = lineAndShapeRenderer0.getNegativeItemLabelPosition(0, 12);
        org.jfree.chart.text.TextAnchor textAnchor10 = itemLabelPosition9.getRotationAnchor();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(boolean3);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(textAnchor10);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        boolean boolean1 = textTitle0.getExpandToFitSpace();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        double double4 = numberAxis3.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock7 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D8 = labelBlock7.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity11 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D8, "", "Preceding");
        numberAxis3.setDownArrow((java.awt.Shape) rectangle2D8);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = numberAxis3.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        double double15 = numberAxis14.getUpperBound();
        boolean boolean16 = numberAxis14.getAutoRangeStickyZero();
        boolean boolean17 = numberAxis14.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis14, xYItemRenderer18);
        boolean boolean20 = xYPlot19.isDomainCrosshairVisible();
        boolean boolean21 = textTitle0.equals((java.lang.Object) xYPlot19);
        xYPlot19.setDomainCrosshairValue(0.0d, false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer25 = null;
        xYPlot19.setRenderer(xYItemRenderer25);
        org.jfree.chart.axis.AxisLocation axisLocation28 = xYPlot19.getDomainAxisLocation(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(axisLocation28);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.data.KeyToGroupMap keyToGroupMap1 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable) 10.0f);
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.previous();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType4 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        boolean boolean5 = month2.equals((java.lang.Object) chartChangeEventType4);
        java.lang.Comparable comparable6 = keyToGroupMap1.getGroup((java.lang.Comparable) month2);
        java.util.Calendar calendar7 = null;
        try {
            month2.peg(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(chartChangeEventType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 10.0f + "'", comparable6.equals(10.0f));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) categoryPlot0, jFreeChart1, 200, (int) (byte) 0);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor5 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        categoryPlot0.zoomDomainAxes(100.0d, plotRenderingInfo7, point2D8);
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        double double12 = numberAxis11.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock15 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D16 = labelBlock15.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity19 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D16, "", "Preceding");
        numberAxis11.setDownArrow((java.awt.Shape) rectangle2D16);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = numberAxis11.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        double double23 = numberAxis22.getUpperBound();
        boolean boolean24 = numberAxis22.getAutoRangeStickyZero();
        boolean boolean25 = numberAxis22.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot(xYDataset10, (org.jfree.chart.axis.ValueAxis) numberAxis11, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer26);
        xYPlot27.setRangeCrosshairVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean32 = categoryPlot31.isDomainGridlinesVisible();
        org.jfree.chart.axis.AxisLocation axisLocation33 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot31.setDomainAxisLocation(axisLocation33);
        xYPlot27.setRangeAxisLocation((int) (byte) 10, axisLocation33);
        categoryPlot0.setDomainAxisLocation(axisLocation33, false);
        categoryPlot0.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D42 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 1L, (double) 31);
        boolean boolean44 = stackedBarRenderer3D42.equals((java.lang.Object) (-1.0f));
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D42);
        try {
            org.jfree.chart.LegendItem legendItem48 = stackedBarRenderer3D42.getLegendItem(1900, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryAnchor5);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(axisLocation33);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D5 = labelBlock4.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity8 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D5, "", "Preceding");
        org.jfree.chart.entity.LegendItemEntity legendItemEntity9 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D5);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer10 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint11 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        statisticalBarRenderer10.setBasePaint(paint11);
        org.jfree.chart.title.LegendGraphic legendGraphic13 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape) rectangle2D5, paint11);
        org.jfree.chart.text.TextMeasurer textMeasurer15 = null;
        org.jfree.chart.text.TextBlock textBlock16 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint11, (float) (short) 0, textMeasurer15);
        org.jfree.chart.text.TextLine textLine17 = textBlock16.getLastLine();
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.util.Size2D size2D19 = textBlock16.calculateDimensions(graphics2D18);
        org.jfree.chart.text.TextLine textLine21 = new org.jfree.chart.text.TextLine("CategoryLabelEntity: category=false, tooltip=, url=Preceding");
        textBlock16.addLine(textLine21);
        org.jfree.chart.text.TextFragment textFragment24 = new org.jfree.chart.text.TextFragment("");
        textLine21.addFragment(textFragment24);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(textBlock16);
        org.junit.Assert.assertNull(textLine17);
        org.junit.Assert.assertNotNull(size2D19);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj1 = textTitle0.clone();
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        double double5 = numberAxis4.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock8 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D9 = labelBlock8.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity12 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D9, "", "Preceding");
        numberAxis4.setDownArrow((java.awt.Shape) rectangle2D9);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = numberAxis4.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis();
        double double16 = numberAxis15.getUpperBound();
        boolean boolean17 = numberAxis15.getAutoRangeStickyZero();
        boolean boolean18 = numberAxis15.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) numberAxis4, (org.jfree.chart.axis.ValueAxis) numberAxis15, xYItemRenderer19);
        xYPlot20.setRangeCrosshairVisible(false);
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart("WMAP_Plot", (org.jfree.chart.plot.Plot) xYPlot20);
        boolean boolean24 = jFreeChart23.isNotify();
        org.jfree.chart.title.LegendTitle legendTitle26 = jFreeChart23.getLegend((int) (byte) 10);
        textTitle0.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart23);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D9);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNull(legendTitle26);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D6 = labelBlock5.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D6, "", "Preceding");
        numberAxis1.setDownArrow((java.awt.Shape) rectangle2D6);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis1.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        double double13 = numberAxis12.getUpperBound();
        boolean boolean14 = numberAxis12.getAutoRangeStickyZero();
        boolean boolean15 = numberAxis12.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer16);
        xYPlot17.setRangeCrosshairVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = xYPlot17.getRangeAxisEdge(1);
        xYPlot17.mapDatasetToRangeAxis(500, 0);
        xYPlot17.zoom((double) 6);
        xYPlot17.setRangeCrosshairLockedOnData(true);
        int int29 = xYPlot17.getSeriesCount();
        boolean boolean30 = xYPlot17.isDomainZoomable();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator2 = piePlot1.getToolTipGenerator();
        double double3 = piePlot1.getMaximumLabelWidth();
        piePlot1.setOutlineVisible(false);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator6 = piePlot1.getToolTipGenerator();
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator9 = piePlot8.getToolTipGenerator();
        java.awt.Color color10 = java.awt.Color.gray;
        piePlot8.setLabelShadowPaint((java.awt.Paint) color10);
        piePlot8.setExplodePercent((java.lang.Comparable) 8.0d, (double) 7);
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis();
        double double16 = numberAxis15.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock19 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D20 = labelBlock19.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity23 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D20, "", "Preceding");
        numberAxis15.setDownArrow((java.awt.Shape) rectangle2D20);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = numberAxis15.getLabelInsets();
        java.awt.Shape shape27 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
        numberAxis15.setRightArrow(shape27);
        java.awt.Paint paint29 = numberAxis15.getLabelPaint();
        piePlot8.setBaseSectionPaint(paint29);
        java.awt.Color color31 = java.awt.Color.BLUE;
        piePlot8.setLabelBackgroundPaint((java.awt.Paint) color31);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator33 = piePlot8.getLegendLabelGenerator();
        piePlot1.setLabelGenerator(pieSectionLabelGenerator33);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator35 = piePlot1.getLegendLabelToolTipGenerator();
        org.junit.Assert.assertNull(pieToolTipGenerator2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertNull(pieToolTipGenerator6);
        org.junit.Assert.assertNull(pieToolTipGenerator9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator33);
        org.junit.Assert.assertNull(pieSectionLabelGenerator35);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("ERROR : Relative To String");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D5 = labelBlock4.getBounds();
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D5);
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D5);
        java.lang.Object obj8 = null;
        try {
            java.lang.Object obj9 = labelBlock1.draw(graphics2D2, rectangle2D5, obj8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D5);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = statisticalLineAndShapeRenderer2.getLegendItemToolTipGenerator();
        org.junit.Assert.assertNull(categorySeriesLabelGenerator3);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D6 = labelBlock5.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D6, "", "Preceding");
        numberAxis1.setDownArrow((java.awt.Shape) rectangle2D6);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis1.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        double double13 = numberAxis12.getUpperBound();
        boolean boolean14 = numberAxis12.getAutoRangeStickyZero();
        boolean boolean15 = numberAxis12.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer16);
        xYPlot17.clearDomainAxes();
        java.awt.Color color20 = java.awt.Color.YELLOW;
        xYPlot17.setQuadrantPaint(3, (java.awt.Paint) color20);
        xYPlot17.setOutlineVisible(true);
        java.awt.Paint paint24 = xYPlot17.getRangeCrosshairPaint();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(paint24);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        double double4 = numberAxis3.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock7 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D8 = labelBlock7.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity11 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D8, "", "Preceding");
        numberAxis3.setDownArrow((java.awt.Shape) rectangle2D8);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = numberAxis3.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        double double15 = numberAxis14.getUpperBound();
        boolean boolean16 = numberAxis14.getAutoRangeStickyZero();
        boolean boolean17 = numberAxis14.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis14, xYItemRenderer18);
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        xYPlot19.setDataset(5, xYDataset21);
        org.jfree.chart.JFreeChart jFreeChart24 = new org.jfree.chart.JFreeChart("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", font1, (org.jfree.chart.plot.Plot) xYPlot19, true);
        org.jfree.chart.title.TextTitle textTitle25 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj26 = textTitle25.clone();
        jFreeChart24.removeSubtitle((org.jfree.chart.title.Title) textTitle25);
        boolean boolean28 = textTitle25.getExpandToFitSpace();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D6 = labelBlock5.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D6, "", "Preceding");
        numberAxis1.setDownArrow((java.awt.Shape) rectangle2D6);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis1.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        double double13 = numberAxis12.getUpperBound();
        boolean boolean14 = numberAxis12.getAutoRangeStickyZero();
        boolean boolean15 = numberAxis12.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer16);
        xYPlot17.setRangeCrosshairVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = xYPlot17.getRangeAxisEdge(1);
        xYPlot17.mapDatasetToRangeAxis(500, 0);
        org.jfree.data.general.PieDataset pieDataset25 = null;
        org.jfree.chart.plot.PiePlot piePlot26 = new org.jfree.chart.plot.PiePlot(pieDataset25);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator27 = piePlot26.getToolTipGenerator();
        double double28 = piePlot26.getMaximumLabelWidth();
        piePlot26.setStartAngle((double) 200);
        xYPlot17.setParent((org.jfree.chart.plot.Plot) piePlot26);
        java.awt.geom.Point2D point2D32 = xYPlot17.getQuadrantOrigin();
        java.io.ObjectOutputStream objectOutputStream33 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePoint2D(point2D32, objectOutputStream33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertNull(pieToolTipGenerator27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.2d + "'", double28 == 0.2d);
        org.junit.Assert.assertNotNull(point2D32);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D6 = labelBlock5.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D6, "", "Preceding");
        numberAxis1.setDownArrow((java.awt.Shape) rectangle2D6);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis1.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        double double13 = numberAxis12.getUpperBound();
        boolean boolean14 = numberAxis12.getAutoRangeStickyZero();
        boolean boolean15 = numberAxis12.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer16);
        xYPlot17.setRangeCrosshairVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = xYPlot17.getRangeAxisEdge(1);
        int int22 = xYPlot17.getDomainAxisCount();
        java.awt.Paint paint23 = xYPlot17.getDomainGridlinePaint();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(paint23);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D6 = labelBlock5.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D6, "", "Preceding");
        numberAxis1.setDownArrow((java.awt.Shape) rectangle2D6);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis1.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        double double13 = numberAxis12.getUpperBound();
        boolean boolean14 = numberAxis12.getAutoRangeStickyZero();
        boolean boolean15 = numberAxis12.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer16);
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = xYPlot17.getRendererForDataset(xYDataset18);
        org.jfree.chart.axis.AxisSpace axisSpace20 = xYPlot17.getFixedDomainAxisSpace();
        boolean boolean21 = xYPlot17.isDomainZeroBaselineVisible();
        java.awt.Stroke stroke22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYPlot17.setDomainCrosshairStroke(stroke22);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent24 = null;
        xYPlot17.rendererChanged(rendererChangeEvent24);
        java.awt.Color color26 = java.awt.Color.YELLOW;
        xYPlot17.setRangeCrosshairPaint((java.awt.Paint) color26);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        xYPlot17.setRenderer((int) (byte) 1, xYItemRenderer29, true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(xYItemRenderer19);
        org.junit.Assert.assertNull(axisSpace20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(color26);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        double[] doubleArray6 = new double[] { (-1L), 0.0d };
        double[] doubleArray9 = new double[] { (-1L), 0.0d };
        double[] doubleArray12 = new double[] { (-1L), 0.0d };
        double[] doubleArray15 = new double[] { (-1L), 0.0d };
        double[][] doubleArray16 = new double[][] { doubleArray6, doubleArray9, doubleArray12, doubleArray15 };
        org.jfree.data.category.CategoryDataset categoryDataset17 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", doubleArray16);
        org.jfree.data.category.CategoryDataset categoryDataset18 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray16);
        double[] doubleArray25 = new double[] { (-1L), 0.0d };
        double[] doubleArray28 = new double[] { (-1L), 0.0d };
        double[] doubleArray31 = new double[] { (-1L), 0.0d };
        double[] doubleArray34 = new double[] { (-1L), 0.0d };
        double[][] doubleArray35 = new double[][] { doubleArray25, doubleArray28, doubleArray31, doubleArray34 };
        org.jfree.data.category.CategoryDataset categoryDataset36 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", doubleArray35);
        org.jfree.data.category.CategoryDataset categoryDataset37 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray35);
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset38 = new org.jfree.data.category.DefaultIntervalCategoryDataset(doubleArray16, doubleArray35);
        double[] doubleArray43 = new double[] { (-1L), 0.0d };
        double[] doubleArray46 = new double[] { (-1L), 0.0d };
        double[] doubleArray49 = new double[] { (-1L), 0.0d };
        double[] doubleArray52 = new double[] { (-1L), 0.0d };
        double[][] doubleArray53 = new double[][] { doubleArray43, doubleArray46, doubleArray49, doubleArray52 };
        org.jfree.data.category.CategoryDataset categoryDataset54 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", doubleArray53);
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset55 = new org.jfree.data.category.DefaultIntervalCategoryDataset(doubleArray16, doubleArray53);
        boolean boolean56 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.category.CategoryDataset) defaultIntervalCategoryDataset55);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(categoryDataset17);
        org.junit.Assert.assertNotNull(categoryDataset18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(categoryDataset36);
        org.junit.Assert.assertNotNull(categoryDataset37);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(categoryDataset54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj1 = textTitle0.clone();
        java.awt.Paint paint2 = textTitle0.getPaint();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        textTitle0.setHorizontalAlignment(horizontalAlignment3);
        java.lang.Object obj5 = textTitle0.clone();
        java.awt.Paint paint6 = null;
        textTitle0.setBackgroundPaint(paint6);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(horizontalAlignment3);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getUpperBound();
        boolean boolean3 = numberAxis1.getAutoRangeStickyZero();
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        double double5 = numberAxis4.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock8 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D9 = labelBlock8.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity12 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D9, "", "Preceding");
        numberAxis4.setDownArrow((java.awt.Shape) rectangle2D9);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = numberAxis4.getLabelInsets();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot15.setRangeCrosshairValue((double) (byte) 1);
        org.jfree.chart.axis.ValueAxis valueAxis18 = categoryPlot15.getRangeAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = categoryPlot15.getDomainAxis((int) ' ');
        boolean boolean21 = numberAxis4.hasListener((java.util.EventListener) categoryPlot15);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis4, xYItemRenderer22);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        xYPlot23.setRenderer(xYItemRenderer24);
        java.awt.Color color26 = java.awt.Color.orange;
        xYPlot23.setRangeCrosshairPaint((java.awt.Paint) color26);
        org.jfree.chart.axis.AxisLocation axisLocation28 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        xYPlot23.setRangeAxisLocation(axisLocation28, false);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D9);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNull(valueAxis18);
        org.junit.Assert.assertNull(categoryAxis20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(axisLocation28);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        java.awt.geom.Line2D line2D0 = null;
        try {
            java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(line2D0, (float) 200);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        java.awt.Paint paint0 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        java.awt.Color color2 = java.awt.Color.darkGray;
        boolean boolean3 = defaultCategoryDataset1.equals((java.lang.Object) color2);
        java.lang.String str4 = org.jfree.chart.util.PaintUtilities.colorToString(color2);
        boolean boolean5 = org.jfree.chart.util.PaintUtilities.equal(paint0, (java.awt.Paint) color2);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "darkGray" + "'", str4.equals("darkGray"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D3 = labelBlock2.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity6 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D3, "", "Preceding");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection9 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection9);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity13 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D3, "CategoryLabelEntity: category=false, tooltip=, url=Preceding", "ThreadContext", (org.jfree.data.category.CategoryDataset) taskSeriesCollection9, (java.lang.Comparable) 'a', (java.lang.Comparable) 0L);
        org.jfree.data.gantt.TaskSeries taskSeries14 = null;
        try {
            taskSeriesCollection9.add(taskSeries14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'series' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D3);
        org.junit.Assert.assertNull(range10);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.data.time.DateRange dateRange1 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str2 = dateRange1.toString();
        java.util.Date date3 = dateRange1.getUpperDate();
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double5 = dateRange4.getCentralValue();
        org.jfree.data.time.DateRange dateRange6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double7 = dateRange6.getCentralValue();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, (org.jfree.data.Range) dateRange6);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType9 = rectangleConstraint8.getHeightConstraintType();
        org.jfree.data.time.DateRange dateRange11 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange11, (double) '#');
        org.jfree.chart.block.LengthConstraintType lengthConstraintType14 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = new org.jfree.chart.block.RectangleConstraint((double) (byte) -1, (org.jfree.data.Range) dateRange1, lengthConstraintType9, 0.0d, (org.jfree.data.Range) dateRange11, lengthConstraintType14);
        org.junit.Assert.assertNotNull(dateRange1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str2.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.5d + "'", double5 == 0.5d);
        org.junit.Assert.assertNotNull(dateRange6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.5d + "'", double7 == 0.5d);
        org.junit.Assert.assertNotNull(lengthConstraintType9);
        org.junit.Assert.assertNotNull(dateRange11);
        org.junit.Assert.assertNotNull(lengthConstraintType14);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D5 = labelBlock4.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity8 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D5, "", "Preceding");
        numberAxis0.setDownArrow((java.awt.Shape) rectangle2D5);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = numberAxis0.getLabelInsets();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
        numberAxis0.setRightArrow(shape12);
        numberAxis0.setPositiveArrowVisible(true);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(shape12);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLowerMargin((double) 10.0f);
        categoryAxis0.configure();
        categoryAxis0.removeCategoryLabelToolTip((java.lang.Comparable) "First");
        java.awt.Stroke stroke6 = categoryAxis0.getAxisLineStroke();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions7 = org.jfree.chart.axis.CategoryLabelPositions.UP_45;
        categoryAxis0.setCategoryLabelPositions(categoryLabelPositions7);
        java.lang.String str10 = categoryAxis0.getCategoryLabelToolTip((java.lang.Comparable) (-1));
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(categoryLabelPositions7);
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator2 = piePlot1.getToolTipGenerator();
        java.awt.Font font3 = piePlot1.getLabelFont();
        java.awt.Stroke stroke5 = piePlot1.getSectionOutlineStroke((java.lang.Comparable) 0L);
        piePlot1.setCircular(false);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions9 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(0.0d);
        boolean boolean10 = piePlot1.equals((java.lang.Object) 0.0d);
        java.awt.Color color11 = java.awt.Color.GRAY;
        int int12 = color11.getTransparency();
        int int13 = color11.getAlpha();
        piePlot1.setLabelLinkPaint((java.awt.Paint) color11);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer16 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator18 = statisticalBarRenderer16.getSeriesURLGenerator((int) (short) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer19 = null;
        statisticalBarRenderer16.setGradientPaintTransformer(gradientPaintTransformer19);
        java.awt.Paint paint22 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        statisticalBarRenderer16.setSeriesOutlinePaint(2019, paint22);
        java.awt.Paint paint24 = statisticalBarRenderer16.getErrorIndicatorPaint();
        java.awt.Paint paint25 = statisticalBarRenderer16.getErrorIndicatorPaint();
        piePlot1.setSectionPaint((java.lang.Comparable) 1.561964399999E12d, paint25);
        org.junit.Assert.assertNull(pieToolTipGenerator2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertNotNull(categoryLabelPositions9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 255 + "'", int13 == 255);
        org.junit.Assert.assertNull(categoryURLGenerator18);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint25);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Color color2 = java.awt.Color.PINK;
        statisticalBarRenderer0.setBaseItemLabelPaint((java.awt.Paint) color2, false);
        java.awt.Color color5 = java.awt.Color.PINK;
        java.awt.color.ColorSpace colorSpace6 = color5.getColorSpace();
        java.awt.Color color7 = java.awt.Color.orange;
        int int8 = color7.getGreen();
        float[] floatArray14 = new float[] { (short) 0, 10.0f, (short) 10, (byte) 0, 0.0f };
        float[] floatArray15 = color7.getColorComponents(floatArray14);
        float[] floatArray16 = color2.getColorComponents(colorSpace6, floatArray14);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(colorSpace6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 200 + "'", int8 == 200);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D6 = labelBlock5.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D6, "", "Preceding");
        numberAxis1.setDownArrow((java.awt.Shape) rectangle2D6);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis1.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        double double13 = numberAxis12.getUpperBound();
        boolean boolean14 = numberAxis12.getAutoRangeStickyZero();
        boolean boolean15 = numberAxis12.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer16);
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        xYPlot17.setDataset(5, xYDataset19);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = xYPlot17.getRangeAxisEdge();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(rectangleEdge21);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        java.util.Date date2 = month0.getEnd();
        long long3 = month0.getLastMillisecond();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1561964399999L + "'", long3 == 1561964399999L);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D3 = labelBlock2.getBounds();
        org.jfree.chart.entity.ChartEntity chartEntity4 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D3);
        try {
            org.jfree.chart.util.ShapeUtilities.drawRotatedShape(graphics2D0, (java.awt.Shape) rectangle2D3, (double) 25566L, (float) (short) -1, 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D3);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D6 = labelBlock5.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D6, "", "Preceding");
        numberAxis1.setDownArrow((java.awt.Shape) rectangle2D6);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis1.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        double double13 = numberAxis12.getUpperBound();
        boolean boolean14 = numberAxis12.getAutoRangeStickyZero();
        boolean boolean15 = numberAxis12.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer16);
        xYPlot17.setRangeCrosshairVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean22 = categoryPlot21.isDomainGridlinesVisible();
        org.jfree.chart.axis.AxisLocation axisLocation23 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot21.setDomainAxisLocation(axisLocation23);
        xYPlot17.setRangeAxisLocation((int) (byte) 10, axisLocation23);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = xYPlot17.getRangeAxisEdge();
        java.awt.Paint paint27 = xYPlot17.getBackgroundPaint();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertNotNull(paint27);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = statisticalBarRenderer0.getSeriesURLGenerator((int) (short) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        statisticalBarRenderer0.setGradientPaintTransformer(gradientPaintTransformer3);
        java.awt.Paint paint7 = statisticalBarRenderer0.getItemPaint((int) (byte) 100, (int) '#');
        statisticalBarRenderer0.setSeriesCreateEntities(31, (java.lang.Boolean) true);
        org.jfree.chart.LegendItemCollection legendItemCollection11 = statisticalBarRenderer0.getLegendItems();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer12 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator14 = statisticalBarRenderer12.getSeriesURLGenerator((int) (short) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer15 = null;
        statisticalBarRenderer12.setGradientPaintTransformer(gradientPaintTransformer15);
        java.awt.Paint paint19 = statisticalBarRenderer12.getItemPaint((int) (byte) 100, (int) '#');
        statisticalBarRenderer12.setSeriesCreateEntities(31, (java.lang.Boolean) true);
        org.jfree.chart.LegendItemCollection legendItemCollection23 = statisticalBarRenderer12.getLegendItems();
        legendItemCollection11.addAll(legendItemCollection23);
        java.lang.Object obj25 = null;
        boolean boolean26 = legendItemCollection23.equals(obj25);
        int int27 = legendItemCollection23.getItemCount();
        org.junit.Assert.assertNull(categoryURLGenerator2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(legendItemCollection11);
        org.junit.Assert.assertNull(categoryURLGenerator14);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(legendItemCollection23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator2 = piePlot1.getToolTipGenerator();
        java.awt.Font font3 = piePlot1.getLabelFont();
        java.awt.Stroke stroke5 = piePlot1.getSectionOutlineStroke((java.lang.Comparable) 0L);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        double double8 = numberAxis7.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock11 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D12 = labelBlock11.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity15 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D12, "", "Preceding");
        numberAxis7.setDownArrow((java.awt.Shape) rectangle2D12);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = numberAxis7.getLabelInsets();
        numberAxis7.setVerticalTickLabels(true);
        java.awt.Stroke stroke20 = numberAxis7.getAxisLineStroke();
        piePlot1.setSectionOutlineStroke((java.lang.Comparable) "({0}, {1}) = {2}", stroke20);
        piePlot1.setCircular(true, true);
        org.junit.Assert.assertNull(pieToolTipGenerator2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        double double4 = numberAxis3.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock7 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D8 = labelBlock7.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity11 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D8, "", "Preceding");
        numberAxis3.setDownArrow((java.awt.Shape) rectangle2D8);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = numberAxis3.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        double double15 = numberAxis14.getUpperBound();
        boolean boolean16 = numberAxis14.getAutoRangeStickyZero();
        boolean boolean17 = numberAxis14.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis14, xYItemRenderer18);
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        xYPlot19.setDataset(5, xYDataset21);
        org.jfree.chart.JFreeChart jFreeChart24 = new org.jfree.chart.JFreeChart("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", font1, (org.jfree.chart.plot.Plot) xYPlot19, true);
        org.jfree.chart.title.TextTitle textTitle25 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj26 = textTitle25.clone();
        jFreeChart24.removeSubtitle((org.jfree.chart.title.Title) textTitle25);
        jFreeChart24.setAntiAlias(false);
        java.awt.Paint paint30 = jFreeChart24.getBorderPaint();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertNotNull(paint30);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = statisticalBarRenderer0.getSeriesURLGenerator((int) (short) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        statisticalBarRenderer0.setGradientPaintTransformer(gradientPaintTransformer3);
        java.awt.Paint paint7 = statisticalBarRenderer0.getItemPaint((int) (byte) 100, (int) '#');
        statisticalBarRenderer0.setSeriesCreateEntities(31, (java.lang.Boolean) true);
        org.jfree.chart.LegendItemCollection legendItemCollection11 = statisticalBarRenderer0.getLegendItems();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator12 = null;
        statisticalBarRenderer0.setBaseURLGenerator(categoryURLGenerator12);
        java.awt.Font font14 = statisticalBarRenderer0.getBaseItemLabelFont();
        double double15 = statisticalBarRenderer0.getMaximumBarWidth();
        org.junit.Assert.assertNull(categoryURLGenerator2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(legendItemCollection11);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        double double3 = numberAxis2.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D7 = labelBlock6.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity10 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D7, "", "Preceding");
        numberAxis2.setDownArrow((java.awt.Shape) rectangle2D7);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = numberAxis2.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        double double14 = numberAxis13.getUpperBound();
        boolean boolean15 = numberAxis13.getAutoRangeStickyZero();
        boolean boolean16 = numberAxis13.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis13, xYItemRenderer17);
        xYPlot18.setRangeCrosshairVisible(false);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("WMAP_Plot", (org.jfree.chart.plot.Plot) xYPlot18);
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle();
        jFreeChart21.addSubtitle((org.jfree.chart.title.Title) textTitle22);
        org.jfree.chart.title.TextTitle textTitle24 = new org.jfree.chart.title.TextTitle();
        java.lang.String str25 = textTitle24.getURLText();
        jFreeChart21.addSubtitle((org.jfree.chart.title.Title) textTitle24);
        java.awt.RenderingHints renderingHints27 = jFreeChart21.getRenderingHints();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertNotNull(renderingHints27);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        try {
            taskSeriesCollection0.remove(200);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: TaskSeriesCollection.remove(): index outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        int int1 = segmentedTimeline0.getSegmentsIncluded();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = new org.jfree.chart.axis.DateTickUnit(0, 5);
        int int5 = dateTickUnit4.getRollUnit();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month6.previous();
        java.util.Date date8 = month6.getEnd();
        org.jfree.chart.text.TextAnchor textAnchor10 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor11 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor12 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor11, textAnchor12);
        org.jfree.chart.axis.DateTick dateTick15 = new org.jfree.chart.axis.DateTick(date8, "CONTRACT", textAnchor10, textAnchor12, 0.2d);
        java.util.Date date16 = dateTickUnit4.addToDate(date8);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment17 = segmentedTimeline0.getSegment(date16);
        long long19 = segment17.calculateSegmentNumber((long) 2958465);
        long long20 = segment17.getSegmentNumber();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 5 + "'", int1 == 5);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(textAnchor10);
        org.junit.Assert.assertNotNull(itemLabelAnchor11);
        org.junit.Assert.assertNotNull(textAnchor12);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(segment17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 25566L + "'", long19 == 25566L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 45471L + "'", long20 == 45471L);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.data.time.DateRange dateRange0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double1 = dateRange0.getCentralValue();
        org.jfree.data.time.DateRange dateRange2 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double3 = dateRange2.getCentralValue();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange0, (org.jfree.data.Range) dateRange2);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.time.DateRange dateRange6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double7 = dateRange6.getCentralValue();
        org.jfree.data.time.DateRange dateRange8 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double9 = dateRange8.getCentralValue();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, (org.jfree.data.Range) dateRange8);
        numberAxis5.setRangeWithMargins((org.jfree.data.Range) dateRange6, true, false);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange0, (org.jfree.data.Range) dateRange6);
        org.jfree.data.Range range15 = rectangleConstraint14.getWidthRange();
        org.junit.Assert.assertNotNull(dateRange0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5d + "'", double1 == 0.5d);
        org.junit.Assert.assertNotNull(dateRange2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.5d + "'", double3 == 0.5d);
        org.junit.Assert.assertNotNull(dateRange6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.5d + "'", double7 == 0.5d);
        org.junit.Assert.assertNotNull(dateRange8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.5d + "'", double9 == 0.5d);
        org.junit.Assert.assertNotNull(range15);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.data.time.DateRange dateRange0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double1 = dateRange0.getCentralValue();
        double double2 = dateRange0.getUpperBound();
        java.util.Date date3 = dateRange0.getUpperDate();
        boolean boolean5 = dateRange0.contains(0.0d);
        org.junit.Assert.assertNotNull(dateRange0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5d + "'", double1 == 0.5d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("darkGray", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=10.0]", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=10.0]", image3, "Size2D[width=0.0, height=0.0]", "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "Size2D[width=0.0, height=0.0]");
        projectInfo7.setLicenceText("WMAP_Plot");
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        java.lang.Comparable[] comparableArray0 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray5 = new java.lang.Comparable[] { "CategoryLabelEntity: category=false, tooltip=, url=Preceding", "rect", (short) 1, (-1) };
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year10 = month9.getYear();
        java.lang.Comparable[] comparableArray12 = new java.lang.Comparable[] { 10.0d, ' ', 15, month9, 1.0f };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { 10L, 1, 15, 3600000L, 200, 0.5f };
        java.lang.Number[][] numberArray20 = new java.lang.Number[][] { numberArray19 };
        java.lang.Number[][] numberArray21 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset22 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray5, comparableArray12, numberArray20, numberArray21);
        java.lang.Comparable[] comparableArray29 = new java.lang.Comparable[] { "CategoryLabelEntity: category=false, tooltip=, url=Preceding", "rect", (short) 1, (-1) };
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year34 = month33.getYear();
        java.lang.Comparable[] comparableArray36 = new java.lang.Comparable[] { 10.0d, ' ', 15, month33, 1.0f };
        java.lang.Number[] numberArray43 = new java.lang.Number[] { 10L, 1, 15, 3600000L, 200, 0.5f };
        java.lang.Number[][] numberArray44 = new java.lang.Number[][] { numberArray43 };
        java.lang.Number[][] numberArray45 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset46 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray29, comparableArray36, numberArray44, numberArray45);
        org.jfree.data.category.CategoryDataset categoryDataset47 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("({0}, {1}) = {3} - {4}", "hi!", numberArray44);
        java.lang.Comparable[] comparableArray54 = new java.lang.Comparable[] { "CategoryLabelEntity: category=false, tooltip=, url=Preceding", "rect", (short) 1, (-1) };
        org.jfree.data.time.Month month58 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year59 = month58.getYear();
        java.lang.Comparable[] comparableArray61 = new java.lang.Comparable[] { 10.0d, ' ', 15, month58, 1.0f };
        java.lang.Number[] numberArray68 = new java.lang.Number[] { 10L, 1, 15, 3600000L, 200, 0.5f };
        java.lang.Number[][] numberArray69 = new java.lang.Number[][] { numberArray68 };
        java.lang.Number[][] numberArray70 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset71 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray54, comparableArray61, numberArray69, numberArray70);
        org.jfree.data.category.CategoryDataset categoryDataset72 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("({0}, {1}) = {3} - {4}", "hi!", numberArray69);
        try {
            org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset73 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray0, comparableArray12, numberArray44, numberArray69);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of series keys does not match the number of series in the data.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray0);
        org.junit.Assert.assertNotNull(comparableArray5);
        org.junit.Assert.assertNotNull(year10);
        org.junit.Assert.assertNotNull(comparableArray12);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(comparableArray29);
        org.junit.Assert.assertNotNull(year34);
        org.junit.Assert.assertNotNull(comparableArray36);
        org.junit.Assert.assertNotNull(numberArray43);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(categoryDataset47);
        org.junit.Assert.assertNotNull(comparableArray54);
        org.junit.Assert.assertNotNull(year59);
        org.junit.Assert.assertNotNull(comparableArray61);
        org.junit.Assert.assertNotNull(numberArray68);
        org.junit.Assert.assertNotNull(numberArray69);
        org.junit.Assert.assertNotNull(categoryDataset72);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("darkGray");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = categoryAxis1.getCategoryLabelPositions();
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D3 = labelBlock2.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity6 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D3, "", "Preceding");
        org.jfree.chart.entity.LegendItemEntity legendItemEntity7 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D3);
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator8 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator9 = null;
        java.lang.String str10 = legendItemEntity7.getImageMapAreaTag(toolTipTagFragmentGenerator8, uRLTagFragmentGenerator9);
        java.lang.Object obj11 = legendItemEntity7.clone();
        org.junit.Assert.assertNotNull(rectangle2D3);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator2 = piePlot1.getToolTipGenerator();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = null;
        piePlot1.setLabelGenerator(pieSectionLabelGenerator3);
        double double5 = piePlot1.getStartAngle();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator6 = piePlot1.getToolTipGenerator();
        org.junit.Assert.assertNull(pieToolTipGenerator2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 90.0d + "'", double5 == 90.0d);
        org.junit.Assert.assertNull(pieToolTipGenerator6);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D3 = labelBlock2.getBounds();
        boolean boolean5 = labelBlock2.equals((java.lang.Object) 1);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        double double8 = numberAxis7.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock11 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D12 = labelBlock11.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity15 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D12, "", "Preceding");
        numberAxis7.setDownArrow((java.awt.Shape) rectangle2D12);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = numberAxis7.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis();
        double double19 = numberAxis18.getUpperBound();
        boolean boolean20 = numberAxis18.getAutoRangeStickyZero();
        boolean boolean21 = numberAxis18.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) numberAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis18, xYItemRenderer22);
        xYPlot23.setRangeCrosshairVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = xYPlot23.getRangeAxisEdge(1);
        int int28 = xYPlot23.getDomainAxisCount();
        columnArrangement0.add((org.jfree.chart.block.Block) labelBlock2, (java.lang.Object) xYPlot23);
        org.jfree.chart.title.TextTitle textTitle30 = new org.jfree.chart.title.TextTitle();
        java.lang.String str31 = textTitle30.getURLText();
        java.lang.String str32 = textTitle30.getURLText();
        org.jfree.chart.block.LineBorder lineBorder33 = new org.jfree.chart.block.LineBorder();
        textTitle30.setFrame((org.jfree.chart.block.BlockFrame) lineBorder33);
        labelBlock2.setFrame((org.jfree.chart.block.BlockFrame) lineBorder33);
        java.awt.Paint paint36 = lineBorder33.getPaint();
        org.junit.Assert.assertNotNull(rectangle2D3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertNotNull(paint36);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D6 = labelBlock5.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D6, "", "Preceding");
        numberAxis1.setDownArrow((java.awt.Shape) rectangle2D6);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis1.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        double double13 = numberAxis12.getUpperBound();
        boolean boolean14 = numberAxis12.getAutoRangeStickyZero();
        boolean boolean15 = numberAxis12.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer16);
        org.jfree.chart.axis.AxisSpace axisSpace18 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = org.jfree.chart.util.RectangleEdge.LEFT;
        axisSpace18.ensureAtLeast((double) ' ', rectangleEdge20);
        xYPlot17.setFixedDomainAxisSpace(axisSpace18);
        java.lang.String str23 = axisSpace18.toString();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(rectangleEdge20);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean3 = categoryPlot2.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = categoryPlot2.getDomainAxisEdge((int) (short) 0);
        categoryPlot2.setAnchorValue((double) 10.0f, false);
        org.jfree.data.category.CategoryDataset categoryDataset10 = categoryPlot2.getDataset(2019);
        org.jfree.chart.event.PlotChangeListener plotChangeListener11 = null;
        categoryPlot2.removeChangeListener(plotChangeListener11);
        java.util.List list13 = categoryPlot2.getCategories();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType15 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer16 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean17 = lengthAdjustmentType15.equals((java.lang.Object) lineAndShapeRenderer16);
        java.lang.String str18 = lengthAdjustmentType15.toString();
        org.jfree.chart.block.LabelBlock labelBlock21 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D22 = labelBlock21.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity25 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D22, "", "Preceding");
        boolean boolean26 = lengthAdjustmentType15.equals((java.lang.Object) rectangle2D22);
        java.awt.geom.Rectangle2D rectangle2D29 = rectangleInsets14.createInsetRectangle(rectangle2D22, true, false);
        try {
            lineRenderer3D0.drawOutline(graphics2D1, categoryPlot2, rectangle2D22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNull(categoryDataset10);
        org.junit.Assert.assertNull(list13);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(lengthAdjustmentType15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "CONTRACT" + "'", str18.equals("CONTRACT"));
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(rectangle2D29);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.chart.block.CenterArrangement centerArrangement8 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.block.BlockContainer blockContainer9 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) centerArrangement8);
        double double10 = blockContainer9.getContentYOffset();
        java.util.List list11 = blockContainer9.getBlocks();
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem12 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) 0.5f, (java.lang.Number) (byte) 1, (java.lang.Number) 0.0d, (java.lang.Number) 10, (java.lang.Number) 10.0d, (java.lang.Number) 2.0d, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0E-8d, list11);
        java.lang.Number number13 = boxAndWhiskerItem12.getMaxRegularValue();
        java.util.List list14 = boxAndWhiskerItem12.getOutliers();
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 2.0d + "'", number13.equals(2.0d));
        org.junit.Assert.assertNotNull(list14);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D5 = labelBlock4.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity8 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D5, "", "Preceding");
        numberAxis0.setDownArrow((java.awt.Shape) rectangle2D5);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = numberAxis0.getLabelInsets();
        numberAxis0.setVerticalTickLabels(true);
        boolean boolean13 = numberAxis0.isInverted();
        numberAxis0.setLabelURL("rect");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.addValue((java.lang.Number) 15, (java.lang.Comparable) 4, (java.lang.Comparable) "DateTickMarkPosition.START");
        try {
            java.lang.Comparable comparable6 = defaultCategoryDataset0.getRowKey(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator3 = piePlot2.getToolTipGenerator();
        java.awt.Color color4 = java.awt.Color.gray;
        piePlot2.setLabelShadowPaint((java.awt.Paint) color4);
        piePlot2.setExplodePercent((java.lang.Comparable) 8.0d, (double) 7);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        double double10 = numberAxis9.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock13 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D14 = labelBlock13.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity17 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D14, "", "Preceding");
        numberAxis9.setDownArrow((java.awt.Shape) rectangle2D14);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = numberAxis9.getLabelInsets();
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
        numberAxis9.setRightArrow(shape21);
        java.awt.Paint paint23 = numberAxis9.getLabelPaint();
        piePlot2.setBaseSectionPaint(paint23);
        org.jfree.chart.util.Rotation rotation25 = piePlot2.getDirection();
        boolean boolean26 = piePlot2.getSectionOutlinesVisible();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit28 = new org.jfree.chart.axis.NumberTickUnit((double) 100L);
        java.awt.Paint paint29 = piePlot2.getSectionOutlinePaint((java.lang.Comparable) numberTickUnit28);
        int int30 = keyedObjects2D0.getRowIndex((java.lang.Comparable) numberTickUnit28);
        java.lang.String str32 = numberTickUnit28.valueToString((double) 5);
        org.junit.Assert.assertNull(pieToolTipGenerator3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(rotation25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNull(paint29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "5" + "'", str32.equals("5"));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getUpperBound();
        boolean boolean3 = numberAxis1.getAutoRangeStickyZero();
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        double double5 = numberAxis4.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock8 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D9 = labelBlock8.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity12 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D9, "", "Preceding");
        numberAxis4.setDownArrow((java.awt.Shape) rectangle2D9);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = numberAxis4.getLabelInsets();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot15.setRangeCrosshairValue((double) (byte) 1);
        org.jfree.chart.axis.ValueAxis valueAxis18 = categoryPlot15.getRangeAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = categoryPlot15.getDomainAxis((int) ' ');
        boolean boolean21 = numberAxis4.hasListener((java.util.EventListener) categoryPlot15);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis4, xYItemRenderer22);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        xYPlot23.setRenderer(xYItemRenderer24);
        int int26 = xYPlot23.getDomainAxisCount();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D9);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNull(valueAxis18);
        org.junit.Assert.assertNull(categoryAxis20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = statisticalBarRenderer0.getSeriesURLGenerator((int) (short) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        statisticalBarRenderer0.setGradientPaintTransformer(gradientPaintTransformer3);
        java.awt.Paint paint6 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        statisticalBarRenderer0.setSeriesOutlinePaint(2019, paint6);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint9 = statisticalBarRenderer8.getBaseOutlinePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = statisticalBarRenderer8.getBaseNegativeItemLabelPosition();
        statisticalBarRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition10);
        org.junit.Assert.assertNull(categoryURLGenerator2);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE8;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor1 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE7;
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor1, textAnchor2, textAnchor3, (double) 0L);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor3);
        java.lang.String str7 = textAnchor3.toString();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(itemLabelAnchor1);
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "TextAnchor.CENTER" + "'", str7.equals("TextAnchor.CENTER"));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = statisticalBarRenderer0.getSeriesURLGenerator((int) (short) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        statisticalBarRenderer0.setGradientPaintTransformer(gradientPaintTransformer3);
        java.awt.Paint paint7 = statisticalBarRenderer0.getItemPaint((int) (byte) 100, (int) '#');
        statisticalBarRenderer0.setSeriesCreateEntities(31, (java.lang.Boolean) true);
        org.jfree.chart.LegendItemCollection legendItemCollection11 = statisticalBarRenderer0.getLegendItems();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator12 = null;
        statisticalBarRenderer0.setBaseURLGenerator(categoryURLGenerator12);
        java.lang.Boolean boolean15 = statisticalBarRenderer0.getSeriesVisible(31);
        org.junit.Assert.assertNull(categoryURLGenerator2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(legendItemCollection11);
        org.junit.Assert.assertNull(boolean15);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = statisticalBarRenderer0.getSeriesPositiveItemLabelPosition(100);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(itemLabelPosition3);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator2 = piePlot1.getToolTipGenerator();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = null;
        piePlot1.setLabelGenerator(pieSectionLabelGenerator3);
        java.awt.Paint paint5 = piePlot1.getBaseSectionPaint();
        org.junit.Assert.assertNull(pieToolTipGenerator2);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = null;
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = null;
        try {
            org.jfree.chart.util.Size2D size2D4 = borderArrangement0.arrange(blockContainer1, graphics2D2, rectangleConstraint3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 500, (double) 2.0f);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D6 = labelBlock5.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D6, "", "Preceding");
        numberAxis1.setDownArrow((java.awt.Shape) rectangle2D6);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis1.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        double double13 = numberAxis12.getUpperBound();
        boolean boolean14 = numberAxis12.getAutoRangeStickyZero();
        boolean boolean15 = numberAxis12.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer16);
        xYPlot17.setRangeCrosshairVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean22 = categoryPlot21.isDomainGridlinesVisible();
        org.jfree.chart.axis.AxisLocation axisLocation23 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot21.setDomainAxisLocation(axisLocation23);
        xYPlot17.setRangeAxisLocation((int) (byte) 10, axisLocation23);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = xYPlot17.getRangeAxisEdge();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = xYPlot17.getRenderer();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertNull(xYItemRenderer27);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        double double3 = numberAxis2.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D7 = labelBlock6.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity10 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D7, "", "Preceding");
        numberAxis2.setDownArrow((java.awt.Shape) rectangle2D7);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = numberAxis2.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        double double14 = numberAxis13.getUpperBound();
        boolean boolean15 = numberAxis13.getAutoRangeStickyZero();
        boolean boolean16 = numberAxis13.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis13, xYItemRenderer17);
        xYPlot18.setRangeCrosshairVisible(false);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("WMAP_Plot", (org.jfree.chart.plot.Plot) xYPlot18);
        boolean boolean22 = jFreeChart21.isNotify();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo25 = null;
        java.awt.image.BufferedImage bufferedImage26 = jFreeChart21.createBufferedImage(1, 6, chartRenderingInfo25);
        int int27 = jFreeChart21.getSubtitleCount();
        float float28 = jFreeChart21.getBackgroundImageAlpha();
        float float29 = jFreeChart21.getBackgroundImageAlpha();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(bufferedImage26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + float28 + "' != '" + 0.5f + "'", float28 == 0.5f);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 0.5f + "'", float29 == 0.5f);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        java.awt.Color color2 = java.awt.Color.getColor("({0}, {1}) = {3} - {4}", 0);
        java.awt.image.ColorModel colorModel3 = null;
        java.awt.Rectangle rectangle4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.AffineTransform affineTransform6 = null;
        java.awt.RenderingHints renderingHints7 = null;
        java.awt.PaintContext paintContext8 = color2.createContext(colorModel3, rectangle4, rectangle2D5, affineTransform6, renderingHints7);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paintContext8);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = statisticalBarRenderer0.getSeriesURLGenerator((int) (short) 100);
        boolean boolean3 = statisticalBarRenderer0.getAutoPopulateSeriesPaint();
        statisticalBarRenderer0.setAutoPopulateSeriesPaint(false);
        boolean boolean6 = statisticalBarRenderer0.getBaseCreateEntities();
        org.junit.Assert.assertNull(categoryURLGenerator2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 500);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = valueMarker1.getLabelOffset();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = valueMarker1.getLabelAnchor();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(rectangleAnchor3);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D5 = labelBlock4.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity8 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D5, "", "Preceding");
        numberAxis0.setDownArrow((java.awt.Shape) rectangle2D5);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = numberAxis0.getLabelInsets();
        numberAxis0.setTickMarkOutsideLength(0.0f);
        double double13 = numberAxis0.getLowerMargin();
        java.awt.Shape shape14 = numberAxis0.getDownArrow();
        java.awt.Paint paint15 = numberAxis0.getAxisLinePaint();
        double double16 = numberAxis0.getFixedDimension();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.05d + "'", double13 == 0.05d);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLowerMargin((double) 10.0f);
        java.awt.Paint paint4 = categoryAxis0.getTickLabelPaint((java.lang.Comparable) 7);
        org.jfree.chart.axis.DateTickUnit dateTickUnit7 = new org.jfree.chart.axis.DateTickUnit(0, 5);
        int int8 = dateTickUnit7.getRollUnit();
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) dateTickUnit7, "Fourth");
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation5 = categoryPlot0.getDomainAxisLocation((int) '4');
        org.jfree.chart.axis.AxisSpace axisSpace6 = new org.jfree.chart.axis.AxisSpace();
        categoryPlot0.setFixedRangeAxisSpace(axisSpace6);
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot0);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        double double10 = numberAxis9.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock13 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D14 = labelBlock13.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity17 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D14, "", "Preceding");
        numberAxis9.setDownArrow((java.awt.Shape) rectangle2D14);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = numberAxis9.getLabelInsets();
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
        numberAxis9.setRightArrow(shape21);
        java.awt.Paint paint23 = numberAxis9.getLabelPaint();
        boolean boolean24 = legendTitle8.equals((java.lang.Object) numberAxis9);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot25.setRangeCrosshairValue((double) (byte) 1);
        double[] doubleArray35 = new double[] { (-1L), 0.0d };
        double[] doubleArray38 = new double[] { (-1L), 0.0d };
        double[] doubleArray41 = new double[] { (-1L), 0.0d };
        double[] doubleArray44 = new double[] { (-1L), 0.0d };
        double[][] doubleArray45 = new double[][] { doubleArray35, doubleArray38, doubleArray41, doubleArray44 };
        org.jfree.data.category.CategoryDataset categoryDataset46 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", doubleArray45);
        org.jfree.data.category.CategoryDataset categoryDataset47 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray45);
        double[] doubleArray54 = new double[] { (-1L), 0.0d };
        double[] doubleArray57 = new double[] { (-1L), 0.0d };
        double[] doubleArray60 = new double[] { (-1L), 0.0d };
        double[] doubleArray63 = new double[] { (-1L), 0.0d };
        double[][] doubleArray64 = new double[][] { doubleArray54, doubleArray57, doubleArray60, doubleArray63 };
        org.jfree.data.category.CategoryDataset categoryDataset65 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", doubleArray64);
        org.jfree.data.category.CategoryDataset categoryDataset66 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray64);
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset67 = new org.jfree.data.category.DefaultIntervalCategoryDataset(doubleArray45, doubleArray64);
        categoryPlot25.setDataset(100, (org.jfree.data.category.CategoryDataset) defaultIntervalCategoryDataset67);
        boolean boolean69 = legendTitle8.equals((java.lang.Object) 100);
        org.jfree.chart.block.BlockContainer blockContainer70 = legendTitle8.getItemContainer();
        boolean boolean71 = blockContainer70.isEmpty();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(categoryDataset46);
        org.junit.Assert.assertNotNull(categoryDataset47);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(categoryDataset65);
        org.junit.Assert.assertNotNull(categoryDataset66);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(blockContainer70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D3 = labelBlock2.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity6 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D3, "", "Preceding");
        org.jfree.chart.entity.LegendItemEntity legendItemEntity7 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D3);
        java.lang.Comparable comparable8 = legendItemEntity7.getSeriesKey();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset9 = new org.jfree.data.category.DefaultCategoryDataset();
        legendItemEntity7.setDataset((org.jfree.data.general.Dataset) defaultCategoryDataset9);
        int int12 = defaultCategoryDataset9.getRowIndex((java.lang.Comparable) "RectangleAnchor.BOTTOM_RIGHT");
        java.lang.Comparable comparable13 = null;
        try {
            int int14 = defaultCategoryDataset9.getColumnIndex(comparable13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D3);
        org.junit.Assert.assertNull(comparable8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D6 = labelBlock5.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D6, "", "Preceding");
        numberAxis1.setDownArrow((java.awt.Shape) rectangle2D6);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis1.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        double double13 = numberAxis12.getUpperBound();
        boolean boolean14 = numberAxis12.getAutoRangeStickyZero();
        boolean boolean15 = numberAxis12.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer16);
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = xYPlot17.getRendererForDataset(xYDataset18);
        org.jfree.chart.axis.AxisSpace axisSpace20 = xYPlot17.getFixedDomainAxisSpace();
        boolean boolean21 = xYPlot17.isDomainZeroBaselineVisible();
        java.awt.Stroke stroke22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYPlot17.setDomainCrosshairStroke(stroke22);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent24 = null;
        xYPlot17.rendererChanged(rendererChangeEvent24);
        org.jfree.data.xy.XYDataset xYDataset28 = null;
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis();
        double double30 = numberAxis29.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock33 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D34 = labelBlock33.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity37 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D34, "", "Preceding");
        numberAxis29.setDownArrow((java.awt.Shape) rectangle2D34);
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = numberAxis29.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis40 = new org.jfree.chart.axis.NumberAxis();
        double double41 = numberAxis40.getUpperBound();
        boolean boolean42 = numberAxis40.getAutoRangeStickyZero();
        boolean boolean43 = numberAxis40.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer44 = null;
        org.jfree.chart.plot.XYPlot xYPlot45 = new org.jfree.chart.plot.XYPlot(xYDataset28, (org.jfree.chart.axis.ValueAxis) numberAxis29, (org.jfree.chart.axis.ValueAxis) numberAxis40, xYItemRenderer44);
        org.jfree.data.xy.XYDataset xYDataset46 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = xYPlot45.getRendererForDataset(xYDataset46);
        org.jfree.chart.axis.AxisSpace axisSpace48 = xYPlot45.getFixedDomainAxisSpace();
        xYPlot45.setRangeZeroBaselineVisible(true);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer51 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator53 = statisticalBarRenderer51.getSeriesURLGenerator((int) (short) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer54 = null;
        statisticalBarRenderer51.setGradientPaintTransformer(gradientPaintTransformer54);
        java.awt.Paint paint57 = statisticalBarRenderer51.lookupSeriesFillPaint(0);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator58 = null;
        statisticalBarRenderer51.setBaseToolTipGenerator(categoryToolTipGenerator58, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition62 = null;
        statisticalBarRenderer51.setSeriesNegativeItemLabelPosition(0, itemLabelPosition62);
        statisticalBarRenderer51.setSeriesItemLabelsVisible(200, false);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D69 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 1L, (double) 31);
        boolean boolean71 = stackedBarRenderer3D69.equals((java.lang.Object) (-1.0f));
        stackedBarRenderer3D69.setRenderAsPercentages(true);
        java.awt.Stroke stroke76 = stackedBarRenderer3D69.getItemOutlineStroke(100, 3);
        statisticalBarRenderer51.setBaseStroke(stroke76, false);
        xYPlot45.setRangeZeroBaselineStroke(stroke76);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo82 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo83 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo82);
        xYPlot45.handleClick((int) 'a', 0, plotRenderingInfo83);
        java.awt.geom.Point2D point2D85 = null;
        try {
            xYPlot17.zoomDomainAxes((double) '4', 0.0d, plotRenderingInfo83, point2D85);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (54.6) <= upper (0.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(xYItemRenderer19);
        org.junit.Assert.assertNull(axisSpace20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNotNull(rectangleInsets39);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 1.0d + "'", double41 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNull(xYItemRenderer47);
        org.junit.Assert.assertNull(axisSpace48);
        org.junit.Assert.assertNull(categoryURLGenerator53);
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(stroke76);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryPlot0.getAxisOffset();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer2 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = statisticalBarRenderer2.getSeriesURLGenerator((int) (short) 100);
        int int5 = statisticalBarRenderer2.getColumnCount();
        double double6 = statisticalBarRenderer2.getItemMargin();
        java.awt.Paint paint7 = statisticalBarRenderer2.getBaseItemLabelPaint();
        categoryPlot0.setRangeGridlinePaint(paint7);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray9 = null;
        try {
            categoryPlot0.setDomainAxes(categoryAxisArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.time.DateRange dateRange1 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double2 = dateRange1.getCentralValue();
        org.jfree.data.time.DateRange dateRange3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double4 = dateRange3.getCentralValue();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange1, (org.jfree.data.Range) dateRange3);
        numberAxis0.setRangeWithMargins((org.jfree.data.Range) dateRange1, true, false);
        java.awt.Paint paint9 = numberAxis0.getTickMarkPaint();
        java.text.NumberFormat numberFormat10 = null;
        numberAxis0.setNumberFormatOverride(numberFormat10);
        org.junit.Assert.assertNotNull(dateRange1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5d + "'", double2 == 0.5d);
        org.junit.Assert.assertNotNull(dateRange3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.5d + "'", double4 == 0.5d);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) (short) 0, (int) (byte) -1, 2019);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator2 = piePlot1.getToolTipGenerator();
        double double3 = piePlot1.getLabelGap();
        java.awt.Paint paint4 = piePlot1.getLabelLinkPaint();
        org.junit.Assert.assertNull(pieToolTipGenerator2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        float float2 = waferMapPlot1.getForegroundAlpha();
        float float3 = waferMapPlot1.getBackgroundImageAlpha();
        java.lang.String str4 = waferMapPlot1.getPlotType();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.5f + "'", float3 == 0.5f);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "WMAP_Plot" + "'", str4.equals("WMAP_Plot"));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.util.List list1 = keyedObjects2D0.getColumnKeys();
        try {
            java.lang.Object obj4 = keyedObjects2D0.getObject(2, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D3 = labelBlock2.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity6 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D3, "", "Preceding");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection9 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection9);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity13 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D3, "CategoryLabelEntity: category=false, tooltip=, url=Preceding", "ThreadContext", (org.jfree.data.category.CategoryDataset) taskSeriesCollection9, (java.lang.Comparable) 'a', (java.lang.Comparable) 0L);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month14.previous();
        long long16 = month14.getLastMillisecond();
        categoryItemEntity13.setRowKey((java.lang.Comparable) long16);
        java.lang.Comparable comparable18 = categoryItemEntity13.getColumnKey();
        org.junit.Assert.assertNotNull(rectangle2D3);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1561964399999L + "'", long16 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + comparable18 + "' != '" + 0L + "'", comparable18.equals(0L));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        double double5 = numberAxis4.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock8 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D9 = labelBlock8.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity12 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D9, "", "Preceding");
        numberAxis4.setDownArrow((java.awt.Shape) rectangle2D9);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = numberAxis4.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis();
        double double16 = numberAxis15.getUpperBound();
        boolean boolean17 = numberAxis15.getAutoRangeStickyZero();
        boolean boolean18 = numberAxis15.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) numberAxis4, (org.jfree.chart.axis.ValueAxis) numberAxis15, xYItemRenderer19);
        boolean boolean21 = xYPlot20.isDomainCrosshairVisible();
        org.jfree.chart.axis.AxisLocation axisLocation23 = xYPlot20.getRangeAxisLocation((int) (short) -1);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer24 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke25 = statisticalBarRenderer24.getBaseStroke();
        xYPlot20.setDomainZeroBaselineStroke(stroke25);
        int int27 = year2.compareTo((java.lang.Object) stroke25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year2.previous();
        java.util.Date date29 = regularTimePeriod28.getEnd();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D9);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(date29);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.UP_90;
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 1L, (double) 31);
        boolean boolean4 = stackedBarRenderer3D2.equals((java.lang.Object) (-1.0f));
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = null;
        stackedBarRenderer3D2.setLegendItemToolTipGenerator(categorySeriesLabelGenerator5);
        java.awt.Paint paint8 = stackedBarRenderer3D2.lookupSeriesFillPaint((int) ' ');
        org.jfree.chart.block.LabelBlock labelBlock11 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D12 = labelBlock11.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity15 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D12, "", "Preceding");
        stackedBarRenderer3D2.setBaseShape((java.awt.Shape) rectangle2D12, false);
        boolean boolean18 = stackedBarRenderer3D2.getBaseCreateEntities();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D2 = labelBlock1.getBounds();
        java.lang.String str3 = labelBlock1.getURLText();
        org.junit.Assert.assertNotNull(rectangle2D2);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        double double1 = levelRenderer0.getItemMargin();
        levelRenderer0.setItemMargin(1.561964399999E12d);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot7.setRangeCrosshairValue((double) (byte) 1);
        java.awt.Color color10 = java.awt.Color.PINK;
        java.awt.color.ColorSpace colorSpace11 = color10.getColorSpace();
        categoryPlot7.setRangeCrosshairPaint((java.awt.Paint) color10);
        categoryPlot7.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis15.setLowerMargin((double) 10.0f);
        categoryAxis15.configure();
        org.jfree.chart.axis.DateTickUnit dateTickUnit21 = new org.jfree.chart.axis.DateTickUnit(0, 5);
        categoryAxis15.removeCategoryLabelToolTip((java.lang.Comparable) 0);
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis();
        double double24 = numberAxis23.getUpperBound();
        boolean boolean25 = numberAxis23.getAutoRangeStickyZero();
        numberAxis23.setLowerMargin((double) 3600000L);
        double double28 = numberAxis23.getAutoRangeMinimumSize();
        numberAxis23.setNegativeArrowVisible(true);
        double[] doubleArray35 = new double[] { (-1L), 0.0d };
        double[] doubleArray38 = new double[] { (-1L), 0.0d };
        double[] doubleArray41 = new double[] { (-1L), 0.0d };
        double[] doubleArray44 = new double[] { (-1L), 0.0d };
        double[][] doubleArray45 = new double[][] { doubleArray35, doubleArray38, doubleArray41, doubleArray44 };
        org.jfree.data.category.CategoryDataset categoryDataset46 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", doubleArray45);
        org.jfree.data.Range range47 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset46);
        java.lang.Number number48 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset46);
        java.lang.Number number49 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset46);
        try {
            levelRenderer0.drawItem(graphics2D4, categoryItemRendererState5, rectangle2D6, categoryPlot7, categoryAxis15, (org.jfree.chart.axis.ValueAxis) numberAxis23, categoryDataset46, (int) (byte) 100, 1900, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 4");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(colorSpace11);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0E-8d + "'", double28 == 1.0E-8d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(categoryDataset46);
        org.junit.Assert.assertNotNull(range47);
        org.junit.Assert.assertTrue("'" + number48 + "' != '" + 0.0d + "'", number48.equals(0.0d));
        org.junit.Assert.assertTrue("'" + number49 + "' != '" + 0.0d + "'", number49.equals(0.0d));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.jfree.chart.block.CenterArrangement centerArrangement8 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.block.BlockContainer blockContainer9 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) centerArrangement8);
        double double10 = blockContainer9.getContentYOffset();
        java.util.List list11 = blockContainer9.getBlocks();
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem12 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) 0.5f, (java.lang.Number) (byte) 1, (java.lang.Number) 0.0d, (java.lang.Number) 10, (java.lang.Number) 10.0d, (java.lang.Number) 2.0d, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0E-8d, list11);
        java.lang.Number number13 = boxAndWhiskerItem12.getMinRegularValue();
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 10.0d + "'", number13.equals(10.0d));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        double[] doubleArray6 = new double[] { (-1L), 0.0d };
        double[] doubleArray9 = new double[] { (-1L), 0.0d };
        double[] doubleArray12 = new double[] { (-1L), 0.0d };
        double[] doubleArray15 = new double[] { (-1L), 0.0d };
        double[][] doubleArray16 = new double[][] { doubleArray6, doubleArray9, doubleArray12, doubleArray15 };
        org.jfree.data.category.CategoryDataset categoryDataset17 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", doubleArray16);
        org.jfree.data.category.CategoryDataset categoryDataset18 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray16);
        double[] doubleArray25 = new double[] { (-1L), 0.0d };
        double[] doubleArray28 = new double[] { (-1L), 0.0d };
        double[] doubleArray31 = new double[] { (-1L), 0.0d };
        double[] doubleArray34 = new double[] { (-1L), 0.0d };
        double[][] doubleArray35 = new double[][] { doubleArray25, doubleArray28, doubleArray31, doubleArray34 };
        org.jfree.data.category.CategoryDataset categoryDataset36 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", doubleArray35);
        org.jfree.data.category.CategoryDataset categoryDataset37 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray35);
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset38 = new org.jfree.data.category.DefaultIntervalCategoryDataset(doubleArray16, doubleArray35);
        java.util.List list39 = defaultIntervalCategoryDataset38.getColumnKeys();
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = month40.previous();
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = month42.previous();
        try {
            java.lang.Number number44 = defaultIntervalCategoryDataset38.getEndValue((java.lang.Comparable) regularTimePeriod41, (java.lang.Comparable) month42);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unknown 'series' key.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(categoryDataset17);
        org.junit.Assert.assertNotNull(categoryDataset18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(categoryDataset36);
        org.junit.Assert.assertNotNull(categoryDataset37);
        org.junit.Assert.assertNotNull(list39);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator2 = piePlot1.getToolTipGenerator();
        java.awt.Font font3 = piePlot1.getLabelFont();
        java.awt.Stroke stroke5 = piePlot1.getSectionOutlineStroke((java.lang.Comparable) 0L);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        double double8 = numberAxis7.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock11 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D12 = labelBlock11.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity15 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D12, "", "Preceding");
        numberAxis7.setDownArrow((java.awt.Shape) rectangle2D12);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = numberAxis7.getLabelInsets();
        numberAxis7.setVerticalTickLabels(true);
        java.awt.Stroke stroke20 = numberAxis7.getAxisLineStroke();
        piePlot1.setSectionOutlineStroke((java.lang.Comparable) "({0}, {1}) = {2}", stroke20);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator22 = piePlot1.getLegendLabelURLGenerator();
        java.awt.Shape shape23 = piePlot1.getLegendItemShape();
        java.awt.Paint paint24 = piePlot1.getLabelLinkPaint();
        org.junit.Assert.assertNull(pieToolTipGenerator2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNull(pieURLGenerator22);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(paint24);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairValue((double) (byte) 1);
        double[] doubleArray10 = new double[] { (-1L), 0.0d };
        double[] doubleArray13 = new double[] { (-1L), 0.0d };
        double[] doubleArray16 = new double[] { (-1L), 0.0d };
        double[] doubleArray19 = new double[] { (-1L), 0.0d };
        double[][] doubleArray20 = new double[][] { doubleArray10, doubleArray13, doubleArray16, doubleArray19 };
        org.jfree.data.category.CategoryDataset categoryDataset21 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", doubleArray20);
        org.jfree.data.category.CategoryDataset categoryDataset22 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray20);
        double[] doubleArray29 = new double[] { (-1L), 0.0d };
        double[] doubleArray32 = new double[] { (-1L), 0.0d };
        double[] doubleArray35 = new double[] { (-1L), 0.0d };
        double[] doubleArray38 = new double[] { (-1L), 0.0d };
        double[][] doubleArray39 = new double[][] { doubleArray29, doubleArray32, doubleArray35, doubleArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", doubleArray39);
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray39);
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset42 = new org.jfree.data.category.DefaultIntervalCategoryDataset(doubleArray20, doubleArray39);
        categoryPlot0.setDataset(100, (org.jfree.data.category.CategoryDataset) defaultIntervalCategoryDataset42);
        org.jfree.data.Range range45 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultIntervalCategoryDataset42, 3.0d);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline47 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        int int48 = segmentedTimeline47.getSegmentsIncluded();
        org.jfree.chart.axis.DateTickUnit dateTickUnit51 = new org.jfree.chart.axis.DateTickUnit(0, 5);
        int int52 = dateTickUnit51.getRollUnit();
        org.jfree.data.time.Month month53 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = month53.previous();
        java.util.Date date55 = month53.getEnd();
        org.jfree.chart.text.TextAnchor textAnchor57 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor58 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor59 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition60 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor58, textAnchor59);
        org.jfree.chart.axis.DateTick dateTick62 = new org.jfree.chart.axis.DateTick(date55, "CONTRACT", textAnchor57, textAnchor59, 0.2d);
        java.util.Date date63 = dateTickUnit51.addToDate(date55);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment64 = segmentedTimeline47.getSegment(date63);
        try {
            java.lang.Number number65 = defaultIntervalCategoryDataset42.getEndValue((java.lang.Comparable) "WMAP_Plot", (java.lang.Comparable) date63);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unknown 'series' key.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(categoryDataset21);
        org.junit.Assert.assertNotNull(categoryDataset22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNotNull(range45);
        org.junit.Assert.assertNotNull(segmentedTimeline47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 5 + "'", int48 == 5);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod54);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(textAnchor57);
        org.junit.Assert.assertNotNull(itemLabelAnchor58);
        org.junit.Assert.assertNotNull(textAnchor59);
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertNotNull(segment64);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D6 = labelBlock5.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D6, "", "Preceding");
        numberAxis1.setDownArrow((java.awt.Shape) rectangle2D6);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis1.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        double double13 = numberAxis12.getUpperBound();
        boolean boolean14 = numberAxis12.getAutoRangeStickyZero();
        boolean boolean15 = numberAxis12.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer16);
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = xYPlot17.getRendererForDataset(xYDataset18);
        org.jfree.chart.axis.AxisSpace axisSpace20 = xYPlot17.getFixedDomainAxisSpace();
        xYPlot17.setRangeZeroBaselineVisible(true);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer23 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator25 = statisticalBarRenderer23.getSeriesURLGenerator((int) (short) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer26 = null;
        statisticalBarRenderer23.setGradientPaintTransformer(gradientPaintTransformer26);
        java.awt.Paint paint29 = statisticalBarRenderer23.lookupSeriesFillPaint(0);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator30 = null;
        statisticalBarRenderer23.setBaseToolTipGenerator(categoryToolTipGenerator30, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition34 = null;
        statisticalBarRenderer23.setSeriesNegativeItemLabelPosition(0, itemLabelPosition34);
        statisticalBarRenderer23.setSeriesItemLabelsVisible(200, false);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D41 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 1L, (double) 31);
        boolean boolean43 = stackedBarRenderer3D41.equals((java.lang.Object) (-1.0f));
        stackedBarRenderer3D41.setRenderAsPercentages(true);
        java.awt.Stroke stroke48 = stackedBarRenderer3D41.getItemOutlineStroke(100, 3);
        statisticalBarRenderer23.setBaseStroke(stroke48, false);
        xYPlot17.setRangeZeroBaselineStroke(stroke48);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo54 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo55 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo54);
        xYPlot17.handleClick((int) 'a', 0, plotRenderingInfo55);
        java.awt.geom.Rectangle2D rectangle2D57 = plotRenderingInfo55.getPlotArea();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(xYItemRenderer19);
        org.junit.Assert.assertNull(axisSpace20);
        org.junit.Assert.assertNull(categoryURLGenerator25);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNull(rectangle2D57);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D6 = labelBlock5.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D6, "", "Preceding");
        numberAxis1.setDownArrow((java.awt.Shape) rectangle2D6);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis1.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        double double13 = numberAxis12.getUpperBound();
        boolean boolean14 = numberAxis12.getAutoRangeStickyZero();
        boolean boolean15 = numberAxis12.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer16);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Point2D point2D21 = null;
        xYPlot17.zoomRangeAxes(0.0d, (double) 100L, plotRenderingInfo20, point2D21);
        java.awt.Paint paint23 = xYPlot17.getDomainZeroBaselinePaint();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(paint23);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 1L, (double) 31);
        boolean boolean4 = stackedBarRenderer3D2.equals((java.lang.Object) (-1.0f));
        java.awt.Paint paint5 = stackedBarRenderer3D2.getWallPaint();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D6 = labelBlock5.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D6, "", "Preceding");
        numberAxis1.setDownArrow((java.awt.Shape) rectangle2D6);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis1.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        double double13 = numberAxis12.getUpperBound();
        boolean boolean14 = numberAxis12.getAutoRangeStickyZero();
        boolean boolean15 = numberAxis12.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer16);
        boolean boolean18 = xYPlot17.isDomainCrosshairVisible();
        org.jfree.chart.axis.AxisLocation axisLocation20 = xYPlot17.getRangeAxisLocation((int) (short) -1);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer21 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke22 = statisticalBarRenderer21.getBaseStroke();
        xYPlot17.setDomainZeroBaselineStroke(stroke22);
        org.jfree.chart.plot.PlotOrientation plotOrientation24 = xYPlot17.getOrientation();
        xYPlot17.clearRangeMarkers((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(plotOrientation24);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setSeriesLinesVisible((int) '4', (java.lang.Boolean) true);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor5 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE7;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor7 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor5, textAnchor6, textAnchor7, (double) 0L);
        lineAndShapeRenderer0.setSeriesNegativeItemLabelPosition((int) '4', itemLabelPosition9);
        lineAndShapeRenderer0.setUseFillPaint(true);
        lineAndShapeRenderer0.setUseOutlinePaint(false);
        org.junit.Assert.assertNotNull(itemLabelAnchor5);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertNotNull(textAnchor7);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range1 = numberAxis0.getDefaultAutoRange();
        boolean boolean3 = numberAxis0.equals((java.lang.Object) (byte) -1);
        java.awt.Color color4 = java.awt.Color.RED;
        java.awt.Color color5 = color4.darker();
        numberAxis0.setTickLabelPaint((java.awt.Paint) color4);
        int int7 = color4.getRGB();
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-65536) + "'", int7 == (-65536));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.time.DateRange dateRange1 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double2 = dateRange1.getCentralValue();
        double double3 = dateRange1.getUpperBound();
        java.util.Date date4 = dateRange1.getLowerDate();
        java.util.Date date5 = dateRange1.getUpperDate();
        dateAxis0.setMaximumDate(date5);
        org.jfree.data.time.DateRange dateRange7 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str8 = dateRange7.toString();
        java.util.Date date9 = dateRange7.getUpperDate();
        org.jfree.data.Range range11 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange7, (double) 500);
        dateAxis0.setRange((org.jfree.data.Range) dateRange7, false, false);
        org.junit.Assert.assertNotNull(dateRange1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5d + "'", double2 == 0.5d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(dateRange7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str8.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(range11);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D5 = labelBlock4.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity8 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D5, "", "Preceding");
        org.jfree.chart.entity.LegendItemEntity legendItemEntity9 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D5);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer10 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint11 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        statisticalBarRenderer10.setBasePaint(paint11);
        org.jfree.chart.title.LegendGraphic legendGraphic13 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape) rectangle2D5, paint11);
        org.jfree.chart.text.TextMeasurer textMeasurer15 = null;
        org.jfree.chart.text.TextBlock textBlock16 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint11, (float) (short) 0, textMeasurer15);
        org.jfree.chart.text.TextLine textLine17 = textBlock16.getLastLine();
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.util.Size2D size2D19 = textBlock16.calculateDimensions(graphics2D18);
        double double20 = size2D19.getWidth();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(textBlock16);
        org.junit.Assert.assertNull(textLine17);
        org.junit.Assert.assertNotNull(size2D19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("({0}, {1}) = {2}");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint1 = statisticalBarRenderer0.getBaseOutlinePaint();
        java.awt.Paint paint4 = statisticalBarRenderer0.getItemOutlinePaint((int) (byte) 0, (int) (short) 1);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D3 = labelBlock2.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity6 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D3, "", "Preceding");
        org.jfree.chart.entity.LegendItemEntity legendItemEntity7 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D3);
        org.jfree.data.general.Dataset dataset8 = legendItemEntity7.getDataset();
        java.lang.String str9 = legendItemEntity7.getURLText();
        org.junit.Assert.assertNotNull(rectangle2D3);
        org.junit.Assert.assertNull(dataset8);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D5 = labelBlock4.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity8 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D5, "", "Preceding");
        org.jfree.chart.entity.LegendItemEntity legendItemEntity9 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D5);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer10 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint11 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        statisticalBarRenderer10.setBasePaint(paint11);
        org.jfree.chart.title.LegendGraphic legendGraphic13 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape) rectangle2D5, paint11);
        org.jfree.chart.text.TextMeasurer textMeasurer15 = null;
        org.jfree.chart.text.TextBlock textBlock16 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint11, (float) (short) 0, textMeasurer15);
        org.jfree.chart.text.TextLine textLine17 = textBlock16.getLastLine();
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.util.Size2D size2D19 = textBlock16.calculateDimensions(graphics2D18);
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor23 = null;
        textBlock16.draw(graphics2D20, (float) (short) -1, 0.0f, textBlockAnchor23);
        java.awt.Font font26 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        java.awt.Color color27 = java.awt.Color.RED;
        java.awt.Color color28 = color27.darker();
        textBlock16.addLine("({0}, {1}) = {2}", font26, (java.awt.Paint) color27);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(textBlock16);
        org.junit.Assert.assertNull(textLine17);
        org.junit.Assert.assertNotNull(size2D19);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(color28);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean1 = categoryAxis3D0.isAxisLineVisible();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint4 = statisticalBarRenderer3.getBaseOutlinePaint();
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("");
        java.awt.Font font7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        labelBlock6.setFont(font7);
        statisticalBarRenderer3.setBaseItemLabelFont(font7);
        categoryAxis3D0.setTickLabelFont((java.lang.Comparable) 11, font7);
        categoryAxis3D0.setAxisLineVisible(true);
        java.lang.Comparable comparable13 = null;
        try {
            java.lang.String str14 = categoryAxis3D0.getCategoryLabelToolTip(comparable13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(font7);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D6 = labelBlock5.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D6, "", "Preceding");
        numberAxis1.setDownArrow((java.awt.Shape) rectangle2D6);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis1.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        double double13 = numberAxis12.getUpperBound();
        boolean boolean14 = numberAxis12.getAutoRangeStickyZero();
        boolean boolean15 = numberAxis12.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer16);
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = xYPlot17.getRendererForDataset(xYDataset18);
        org.jfree.chart.axis.AxisSpace axisSpace20 = xYPlot17.getFixedDomainAxisSpace();
        xYPlot17.setRangeZeroBaselineVisible(true);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = xYPlot17.getRangeAxisEdge((int) (byte) 100);
        org.jfree.chart.axis.AxisLocation axisLocation26 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        xYPlot17.setDomainAxisLocation(5, axisLocation26, false);
        java.awt.Paint paint29 = xYPlot17.getRangeTickBandPaint();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(xYItemRenderer19);
        org.junit.Assert.assertNull(axisSpace20);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNull(paint29);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 1L, (double) 31);
        boolean boolean4 = stackedBarRenderer3D2.equals((java.lang.Object) (-1.0f));
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = null;
        stackedBarRenderer3D2.setLegendItemToolTipGenerator(categorySeriesLabelGenerator5);
        java.awt.Color color7 = java.awt.Color.YELLOW;
        stackedBarRenderer3D2.setBaseItemLabelPaint((java.awt.Paint) color7);
        boolean boolean9 = stackedBarRenderer3D2.getBaseCreateEntities();
        stackedBarRenderer3D2.setBaseItemLabelsVisible(false);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.JFreeChart jFreeChart14 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent17 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) categoryPlot13, jFreeChart14, 200, (int) (byte) 0);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor18 = categoryPlot13.getDomainGridlinePosition();
        categoryPlot13.clearDomainAxes();
        org.jfree.data.general.WaferMapDataset waferMapDataset20 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot21 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset20);
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.block.LabelBlock labelBlock25 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D26 = labelBlock25.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity29 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D26, "", "Preceding");
        waferMapPlot21.drawBackgroundImage(graphics2D22, rectangle2D26);
        org.jfree.chart.entity.ChartEntity chartEntity32 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D26, "Preceding");
        try {
            stackedBarRenderer3D2.drawBackground(graphics2D12, categoryPlot13, rectangle2D26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(categoryAnchor18);
        org.junit.Assert.assertNotNull(rectangle2D26);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryPlot0.getAxisOffset();
        boolean boolean2 = categoryPlot0.isDomainZoomable();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.LegendItemCollection legendItemCollection4 = categoryPlot0.getFixedLegendItems();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(legendItemCollection4);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange((double) 3, (double) 10.0f);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = statisticalBarRenderer0.getSeriesURLGenerator((int) (short) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        statisticalBarRenderer0.setGradientPaintTransformer(gradientPaintTransformer3);
        java.awt.Paint paint7 = statisticalBarRenderer0.getItemPaint((int) (byte) 100, (int) '#');
        statisticalBarRenderer0.setSeriesCreateEntities(31, (java.lang.Boolean) true);
        org.jfree.chart.LegendItemCollection legendItemCollection11 = statisticalBarRenderer0.getLegendItems();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer12 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator14 = statisticalBarRenderer12.getSeriesURLGenerator((int) (short) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer15 = null;
        statisticalBarRenderer12.setGradientPaintTransformer(gradientPaintTransformer15);
        java.awt.Paint paint19 = statisticalBarRenderer12.getItemPaint((int) (byte) 100, (int) '#');
        statisticalBarRenderer12.setSeriesCreateEntities(31, (java.lang.Boolean) true);
        org.jfree.chart.LegendItemCollection legendItemCollection23 = statisticalBarRenderer12.getLegendItems();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer24 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator26 = statisticalBarRenderer24.getSeriesURLGenerator((int) (short) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer27 = null;
        statisticalBarRenderer24.setGradientPaintTransformer(gradientPaintTransformer27);
        java.awt.Paint paint31 = statisticalBarRenderer24.getItemPaint((int) (byte) 100, (int) '#');
        statisticalBarRenderer24.setSeriesCreateEntities(31, (java.lang.Boolean) true);
        org.jfree.chart.LegendItemCollection legendItemCollection35 = statisticalBarRenderer24.getLegendItems();
        legendItemCollection23.addAll(legendItemCollection35);
        legendItemCollection11.addAll(legendItemCollection23);
        org.junit.Assert.assertNull(categoryURLGenerator2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(legendItemCollection11);
        org.junit.Assert.assertNull(categoryURLGenerator14);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(legendItemCollection23);
        org.junit.Assert.assertNull(categoryURLGenerator26);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(legendItemCollection35);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator3 = piePlot2.getToolTipGenerator();
        java.awt.Color color4 = java.awt.Color.gray;
        piePlot2.setLabelShadowPaint((java.awt.Paint) color4);
        piePlot2.setExplodePercent((java.lang.Comparable) 8.0d, (double) 7);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        double double10 = numberAxis9.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock13 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D14 = labelBlock13.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity17 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D14, "", "Preceding");
        numberAxis9.setDownArrow((java.awt.Shape) rectangle2D14);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = numberAxis9.getLabelInsets();
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
        numberAxis9.setRightArrow(shape21);
        java.awt.Paint paint23 = numberAxis9.getLabelPaint();
        piePlot2.setBaseSectionPaint(paint23);
        org.jfree.chart.util.Rotation rotation25 = piePlot2.getDirection();
        boolean boolean26 = piePlot2.getSectionOutlinesVisible();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit28 = new org.jfree.chart.axis.NumberTickUnit((double) 100L);
        java.awt.Paint paint29 = piePlot2.getSectionOutlinePaint((java.lang.Comparable) numberTickUnit28);
        int int30 = keyedObjects2D0.getRowIndex((java.lang.Comparable) numberTickUnit28);
        keyedObjects2D0.removeObject((java.lang.Comparable) 200, (java.lang.Comparable) "darkGray");
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = month34.previous();
        org.jfree.data.time.Year year36 = month34.getYear();
        int int37 = keyedObjects2D0.getRowIndex((java.lang.Comparable) month34);
        org.jfree.data.time.Year year38 = month34.getYear();
        org.junit.Assert.assertNull(pieToolTipGenerator3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(rotation25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNull(paint29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(year36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertNotNull(year38);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        java.awt.Color color0 = java.awt.Color.orange;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        int int1 = segmentedTimeline0.getSegmentsIncluded();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = new org.jfree.chart.axis.DateTickUnit(0, 5);
        int int5 = dateTickUnit4.getRollUnit();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month6.previous();
        java.util.Date date8 = month6.getEnd();
        org.jfree.chart.text.TextAnchor textAnchor10 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor11 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor12 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor11, textAnchor12);
        org.jfree.chart.axis.DateTick dateTick15 = new org.jfree.chart.axis.DateTick(date8, "CONTRACT", textAnchor10, textAnchor12, 0.2d);
        java.util.Date date16 = dateTickUnit4.addToDate(date8);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment17 = segmentedTimeline0.getSegment(date16);
        long long19 = segment17.calculateSegmentNumber((long) 2958465);
        segment17.moveIndexToStart();
        boolean boolean22 = segment17.contains((long) 128);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 5 + "'", int1 == 5);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(textAnchor10);
        org.junit.Assert.assertNotNull(itemLabelAnchor11);
        org.junit.Assert.assertNotNull(textAnchor12);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(segment17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 25566L + "'", long19 == 25566L);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator2 = piePlot1.getToolTipGenerator();
        java.awt.Color color3 = java.awt.Color.gray;
        piePlot1.setLabelShadowPaint((java.awt.Paint) color3);
        piePlot1.setLabelLinkMargin(0.0d);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator7 = null;
        piePlot1.setToolTipGenerator(pieToolTipGenerator7);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator9 = piePlot1.getToolTipGenerator();
        org.junit.Assert.assertNull(pieToolTipGenerator2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(pieToolTipGenerator9);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-457) + "'", int1 == (-457));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.jfree.chart.renderer.AreaRendererEndType areaRendererEndType0 = org.jfree.chart.renderer.AreaRendererEndType.LEVEL;
        java.lang.String str1 = areaRendererEndType0.toString();
        org.junit.Assert.assertNotNull(areaRendererEndType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AreaRendererEndType.LEVEL" + "'", str1.equals("AreaRendererEndType.LEVEL"));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge((int) (short) 0);
        categoryPlot0.setOutlineVisible(true);
        boolean boolean6 = categoryPlot0.isSubplot();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean1 = lineAndShapeRenderer0.getDrawOutlines();
        java.lang.Boolean boolean3 = lineAndShapeRenderer0.getSeriesLinesVisible(5);
        boolean boolean4 = lineAndShapeRenderer0.getDrawOutlines();
        boolean boolean5 = lineAndShapeRenderer0.getBaseShapesVisible();
        lineAndShapeRenderer0.setBaseItemLabelsVisible(true);
        java.awt.Stroke stroke9 = lineAndShapeRenderer0.getSeriesOutlineStroke((int) (short) 100);
        lineAndShapeRenderer0.setDrawOutlines(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(boolean3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(stroke9);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getUpperBound();
        numberAxis0.setTickMarkOutsideLength((float) (-1L));
        java.lang.Object obj4 = numberAxis0.clone();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D5 = labelBlock4.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity8 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D5, "", "Preceding");
        numberAxis0.setDownArrow((java.awt.Shape) rectangle2D5);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = numberAxis0.getLabelInsets();
        numberAxis0.setVerticalTickLabels(true);
        numberAxis0.setFixedAutoRange((double) 0);
        numberAxis0.setPositiveArrowVisible(false);
        numberAxis0.setLabelAngle(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNotNull(rectangleInsets10);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator2 = piePlot1.getToolTipGenerator();
        java.awt.Font font3 = piePlot1.getLabelFont();
        java.awt.Stroke stroke5 = piePlot1.getSectionOutlineStroke((java.lang.Comparable) 0L);
        int int6 = piePlot1.getPieIndex();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment7 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.VerticalAlignment verticalAlignment8 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement11 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment7, verticalAlignment8, (double) (byte) 100, (double) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement12 = new org.jfree.chart.block.FlowArrangement();
        boolean boolean14 = flowArrangement12.equals((java.lang.Object) (short) 0);
        org.jfree.chart.block.LabelBlock labelBlock16 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D17 = labelBlock16.getBounds();
        boolean boolean19 = labelBlock16.equals((java.lang.Object) 1);
        boolean boolean20 = flowArrangement12.equals((java.lang.Object) 1);
        org.jfree.chart.title.LegendTitle legendTitle21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement11, (org.jfree.chart.block.Arrangement) flowArrangement12);
        org.jfree.chart.block.CenterArrangement centerArrangement22 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.block.BlockContainer blockContainer23 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) centerArrangement22);
        double double24 = blockContainer23.getContentYOffset();
        java.util.List list25 = blockContainer23.getBlocks();
        legendTitle21.setWrapper(blockContainer23);
        org.junit.Assert.assertNull(pieToolTipGenerator2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(horizontalAlignment7);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(list25);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D6 = labelBlock5.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D6, "", "Preceding");
        numberAxis1.setDownArrow((java.awt.Shape) rectangle2D6);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis1.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        double double13 = numberAxis12.getUpperBound();
        boolean boolean14 = numberAxis12.getAutoRangeStickyZero();
        boolean boolean15 = numberAxis12.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer16);
        xYPlot17.setRangeCrosshairVisible(false);
        boolean boolean20 = xYPlot17.isRangeCrosshairLockedOnData();
        int int21 = xYPlot17.getBackgroundImageAlignment();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 15 + "'", int21 == 15);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.jfree.chart.renderer.OutlierListCollection outlierListCollection0 = new org.jfree.chart.renderer.OutlierListCollection();
        org.jfree.chart.renderer.Outlier outlier1 = null;
        boolean boolean2 = outlierListCollection0.add(outlier1);
        org.jfree.chart.renderer.Outlier outlier3 = null;
        boolean boolean4 = outlierListCollection0.add(outlier3);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D6 = labelBlock5.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D6, "", "Preceding");
        numberAxis1.setDownArrow((java.awt.Shape) rectangle2D6);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis1.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        double double13 = numberAxis12.getUpperBound();
        boolean boolean14 = numberAxis12.getAutoRangeStickyZero();
        boolean boolean15 = numberAxis12.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer16);
        boolean boolean18 = xYPlot17.isDomainCrosshairVisible();
        org.jfree.chart.axis.AxisLocation axisLocation20 = xYPlot17.getRangeAxisLocation((int) (short) -1);
        xYPlot17.setRangeCrosshairVisible(false);
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        xYPlot17.setDataset(xYDataset23);
        org.jfree.chart.JFreeChart jFreeChart25 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot17);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(axisLocation20);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        boolean boolean3 = segmentedTimeline0.containsDomainRange((long) 1, (long) 15);
        long long4 = segmentedTimeline0.getSegmentSize();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 86400000L + "'", long4 == 86400000L);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D6 = labelBlock5.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D6, "", "Preceding");
        numberAxis1.setDownArrow((java.awt.Shape) rectangle2D6);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis1.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        double double13 = numberAxis12.getUpperBound();
        boolean boolean14 = numberAxis12.getAutoRangeStickyZero();
        boolean boolean15 = numberAxis12.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer16);
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = xYPlot17.getRendererForDataset(xYDataset18);
        org.jfree.chart.axis.AxisSpace axisSpace20 = xYPlot17.getFixedDomainAxisSpace();
        boolean boolean21 = xYPlot17.isDomainZeroBaselineVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = xYPlot17.getAxisOffset();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        try {
            xYPlot17.handleClick(0, (int) (byte) 100, plotRenderingInfo25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(xYItemRenderer19);
        org.junit.Assert.assertNull(axisSpace20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(rectangleInsets22);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) centerArrangement0);
        org.jfree.chart.block.LabelBlock labelBlock3 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D4 = labelBlock3.getBounds();
        java.lang.Object obj5 = null;
        boolean boolean6 = labelBlock3.equals(obj5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = labelBlock3.getMargin();
        org.jfree.chart.block.LabelBlock labelBlock10 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D11 = labelBlock10.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity14 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D11, "", "Preceding");
        org.jfree.chart.entity.LegendItemEntity legendItemEntity15 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D11);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer16 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint17 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        statisticalBarRenderer16.setBasePaint(paint17);
        org.jfree.chart.title.LegendGraphic legendGraphic19 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape) rectangle2D11, paint17);
        java.awt.Paint paint20 = legendGraphic19.getFillPaint();
        labelBlock3.setPaint(paint20);
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj23 = textTitle22.clone();
        centerArrangement0.add((org.jfree.chart.block.Block) labelBlock3, obj23);
        java.awt.Font font25 = labelBlock3.getFont();
        org.junit.Assert.assertNotNull(rectangle2D4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertNotNull(font25);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer1 = new org.jfree.chart.renderer.category.StackedBarRenderer(false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = null;
        stackedBarRenderer1.setBaseURLGenerator(categoryURLGenerator2);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator4 = stackedBarRenderer1.getLegendItemToolTipGenerator();
        org.junit.Assert.assertNull(categorySeriesLabelGenerator4);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 1L, (double) 31);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = stackedBarRenderer3D2.getGradientPaintTransformer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        stackedBarRenderer3D2.setBaseURLGenerator(categoryURLGenerator4);
        org.junit.Assert.assertNotNull(gradientPaintTransformer3);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 100L, 8.0d, (double) 1900, (-1.0d));
        org.jfree.chart.ui.ProjectInfo projectInfo5 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str6 = projectInfo5.getCopyright();
        boolean boolean7 = rectangleInsets4.equals((java.lang.Object) projectInfo5);
        java.awt.Image image8 = projectInfo5.getLogo();
        java.lang.String str9 = projectInfo5.getVersion();
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(image8);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        double double3 = numberAxis2.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D7 = labelBlock6.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity10 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D7, "", "Preceding");
        numberAxis2.setDownArrow((java.awt.Shape) rectangle2D7);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = numberAxis2.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        double double14 = numberAxis13.getUpperBound();
        boolean boolean15 = numberAxis13.getAutoRangeStickyZero();
        boolean boolean16 = numberAxis13.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis13, xYItemRenderer17);
        xYPlot18.setRangeCrosshairVisible(false);
        java.lang.String str21 = xYPlot18.getPlotType();
        org.jfree.chart.axis.ValueAxis valueAxis22 = xYPlot18.getDomainAxis();
        double double23 = valueAxis22.getFixedDimension();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer24 = null;
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis22, polarItemRenderer24);
        org.jfree.chart.plot.PlotOrientation plotOrientation26 = polarPlot25.getOrientation();
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        try {
            java.awt.Point point30 = polarPlot25.translateValueThetaRadiusToJava2D(0.0d, (double) 1559372400000L, rectangle2D29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "XY Plot" + "'", str21.equals("XY Plot"));
        org.junit.Assert.assertNotNull(valueAxis22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(plotOrientation26);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.junit.Assert.assertNotNull(range0);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        int int1 = segmentedTimeline0.getSegmentsIncluded();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = new org.jfree.chart.axis.DateTickUnit(0, 5);
        int int5 = dateTickUnit4.getRollUnit();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month6.previous();
        java.util.Date date8 = month6.getEnd();
        org.jfree.chart.text.TextAnchor textAnchor10 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor11 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor12 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor11, textAnchor12);
        org.jfree.chart.axis.DateTick dateTick15 = new org.jfree.chart.axis.DateTick(date8, "CONTRACT", textAnchor10, textAnchor12, 0.2d);
        java.util.Date date16 = dateTickUnit4.addToDate(date8);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment17 = segmentedTimeline0.getSegment(date16);
        long long19 = segment17.calculateSegmentNumber((long) 2958465);
        boolean boolean21 = segment17.contains((long) 0);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 5 + "'", int1 == 5);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(textAnchor10);
        org.junit.Assert.assertNotNull(itemLabelAnchor11);
        org.junit.Assert.assertNotNull(textAnchor12);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(segment17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 25566L + "'", long19 == 25566L);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        org.jfree.chart.renderer.category.AreaRenderer areaRenderer0 = new org.jfree.chart.renderer.category.AreaRenderer();
        org.jfree.chart.renderer.AreaRendererEndType areaRendererEndType1 = org.jfree.chart.renderer.AreaRendererEndType.TAPER;
        areaRenderer0.setEndType(areaRendererEndType1);
        java.lang.Object obj3 = areaRenderer0.clone();
        org.junit.Assert.assertNotNull(areaRendererEndType1);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D3 = labelBlock2.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity6 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D3, "", "Preceding");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection9 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection9);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity13 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D3, "CategoryLabelEntity: category=false, tooltip=, url=Preceding", "ThreadContext", (org.jfree.data.category.CategoryDataset) taskSeriesCollection9, (java.lang.Comparable) 'a', (java.lang.Comparable) 0L);
        org.jfree.data.category.CategoryDataset categoryDataset14 = categoryItemEntity13.getDataset();
        java.lang.Comparable comparable15 = categoryItemEntity13.getColumnKey();
        org.jfree.data.category.CategoryDataset categoryDataset16 = categoryItemEntity13.getDataset();
        org.junit.Assert.assertNotNull(rectangle2D3);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNotNull(categoryDataset14);
        org.junit.Assert.assertTrue("'" + comparable15 + "' != '" + 0L + "'", comparable15.equals(0L));
        org.junit.Assert.assertNotNull(categoryDataset16);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean1 = lineAndShapeRenderer0.getDrawOutlines();
        java.lang.Boolean boolean3 = lineAndShapeRenderer0.getSeriesLinesVisible(5);
        lineAndShapeRenderer0.setBaseLinesVisible(true);
        int int6 = lineAndShapeRenderer0.getPassCount();
        boolean boolean7 = lineAndShapeRenderer0.getUseFillPaint();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(boolean3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        java.awt.Paint paint1 = lineRenderer3D0.getWallPaint();
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge((int) (short) 0);
        float float4 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.plot.Plot plot5 = categoryPlot0.getRootPlot();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        org.jfree.chart.block.BlockBorder blockBorder7 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color6);
        plot5.setOutlinePaint((java.awt.Paint) color6);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(plot5);
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D6 = labelBlock5.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D6, "", "Preceding");
        waferMapPlot1.drawBackgroundImage(graphics2D2, rectangle2D6);
        org.jfree.chart.entity.ChartEntity chartEntity12 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D6, "Preceding");
        java.lang.String str13 = chartEntity12.getShapeType();
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "rect" + "'", str13.equals("rect"));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = statisticalBarRenderer0.getSeriesURLGenerator((int) (short) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        statisticalBarRenderer0.setGradientPaintTransformer(gradientPaintTransformer3);
        java.awt.Paint paint7 = statisticalBarRenderer0.getItemPaint((int) (byte) 100, (int) '#');
        statisticalBarRenderer0.setSeriesCreateEntities(31, (java.lang.Boolean) true);
        org.jfree.chart.LegendItemCollection legendItemCollection11 = statisticalBarRenderer0.getLegendItems();
        int int12 = legendItemCollection11.getItemCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean14 = categoryPlot13.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = categoryPlot13.getDomainAxisEdge((int) (short) 0);
        float float17 = categoryPlot13.getForegroundAlpha();
        categoryPlot13.setDrawSharedDomainAxis(true);
        int int20 = categoryPlot13.getDatasetCount();
        org.jfree.chart.entity.EntityCollection entityCollection23 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo24 = new org.jfree.chart.ChartRenderingInfo(entityCollection23);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = chartRenderingInfo24.getPlotInfo();
        int int26 = plotRenderingInfo25.getSubplotCount();
        categoryPlot13.handleClick(3, 2958465, plotRenderingInfo25);
        boolean boolean28 = legendItemCollection11.equals((java.lang.Object) 3);
        org.junit.Assert.assertNull(categoryURLGenerator2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(legendItemCollection11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 1.0f + "'", float17 == 1.0f);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(plotRenderingInfo25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("RectangleEdge.TOP");
        taskSeries1.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        taskSeries1.removeChangeListener(seriesChangeListener4);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.time.DateRange dateRange1 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double2 = dateRange1.getCentralValue();
        double double3 = dateRange1.getUpperBound();
        java.util.Date date4 = dateRange1.getLowerDate();
        java.util.Date date5 = dateRange1.getUpperDate();
        dateAxis0.setMaximumDate(date5);
        java.util.Date date7 = dateAxis0.getMinimumDate();
        org.junit.Assert.assertNotNull(dateRange1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5d + "'", double2 == 0.5d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = null;
        taskSeriesCollection0.seriesChanged(seriesChangeEvent1);
        int int4 = taskSeriesCollection0.indexOf((java.lang.Comparable) (-1L));
        try {
            taskSeriesCollection0.remove((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: TaskSeriesCollection.remove(): index outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        org.jfree.chart.text.TextFragment textFragment1 = textLine0.getLastTextFragment();
        org.junit.Assert.assertNull(textFragment1);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D3 = labelBlock2.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity6 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D3, "", "Preceding");
        org.jfree.chart.entity.LegendItemEntity legendItemEntity7 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D3);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint9 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        statisticalBarRenderer8.setBasePaint(paint9);
        org.jfree.chart.title.LegendGraphic legendGraphic11 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape) rectangle2D3, paint9);
        java.awt.Shape shape12 = legendGraphic11.getLine();
        double double13 = legendGraphic11.getContentYOffset();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D16 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 1L, (double) 31);
        boolean boolean18 = stackedBarRenderer3D16.equals((java.lang.Object) (-1.0f));
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator19 = null;
        stackedBarRenderer3D16.setLegendItemToolTipGenerator(categorySeriesLabelGenerator19);
        java.awt.Color color21 = java.awt.Color.YELLOW;
        stackedBarRenderer3D16.setBaseItemLabelPaint((java.awt.Paint) color21);
        legendGraphic11.setLinePaint((java.awt.Paint) color21);
        boolean boolean24 = legendGraphic11.isShapeFilled();
        org.junit.Assert.assertNotNull(rectangle2D3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(shape12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.0d + "'", double13 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) (byte) 100, (double) (short) 100);
        org.jfree.chart.renderer.category.AreaRenderer areaRenderer5 = new org.jfree.chart.renderer.category.AreaRenderer();
        org.jfree.chart.renderer.AreaRendererEndType areaRendererEndType6 = org.jfree.chart.renderer.AreaRendererEndType.TAPER;
        areaRenderer5.setEndType(areaRendererEndType6);
        boolean boolean8 = horizontalAlignment0.equals((java.lang.Object) areaRenderer5);
        org.jfree.chart.renderer.AreaRendererEndType areaRendererEndType9 = org.jfree.chart.renderer.AreaRendererEndType.LEVEL;
        areaRenderer5.setEndType(areaRendererEndType9);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(areaRendererEndType6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(areaRendererEndType9);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.time.DateRange dateRange3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double4 = dateRange3.getCentralValue();
        org.jfree.data.time.DateRange dateRange5 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double6 = dateRange5.getCentralValue();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange3, (org.jfree.data.Range) dateRange5);
        numberAxis2.setRangeWithMargins((org.jfree.data.Range) dateRange3, true, false);
        java.awt.Paint paint11 = numberAxis2.getTickMarkPaint();
        org.jfree.data.KeyedObject keyedObject12 = new org.jfree.data.KeyedObject((java.lang.Comparable) year1, (java.lang.Object) paint11);
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(dateRange3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.5d + "'", double4 == 0.5d);
        org.junit.Assert.assertNotNull(dateRange5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.5d + "'", double6 == 0.5d);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        java.awt.Font font0 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        boolean boolean2 = flowArrangement0.equals((java.lang.Object) (short) 0);
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D5 = labelBlock4.getBounds();
        boolean boolean7 = labelBlock4.equals((java.lang.Object) 1);
        boolean boolean8 = flowArrangement0.equals((java.lang.Object) 1);
        flowArrangement0.clear();
        flowArrangement0.clear();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) (short) 1, 3.0d);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        java.lang.Comparable[] comparableArray4 = new java.lang.Comparable[] { "CategoryLabelEntity: category=false, tooltip=, url=Preceding", "rect", (short) 1, (-1) };
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year9 = month8.getYear();
        java.lang.Comparable[] comparableArray11 = new java.lang.Comparable[] { 10.0d, ' ', 15, month8, 1.0f };
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 10L, 1, 15, 3600000L, 200, 0.5f };
        java.lang.Number[][] numberArray19 = new java.lang.Number[][] { numberArray18 };
        java.lang.Number[][] numberArray20 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset21 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray4, comparableArray11, numberArray19, numberArray20);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline23 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        int int24 = segmentedTimeline23.getSegmentsIncluded();
        org.jfree.chart.axis.DateTickUnit dateTickUnit27 = new org.jfree.chart.axis.DateTickUnit(0, 5);
        int int28 = dateTickUnit27.getRollUnit();
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month29.previous();
        java.util.Date date31 = month29.getEnd();
        org.jfree.chart.text.TextAnchor textAnchor33 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor34 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor35 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition36 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor34, textAnchor35);
        org.jfree.chart.axis.DateTick dateTick38 = new org.jfree.chart.axis.DateTick(date31, "CONTRACT", textAnchor33, textAnchor35, 0.2d);
        java.util.Date date39 = dateTickUnit27.addToDate(date31);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment40 = segmentedTimeline23.getSegment(date39);
        long long42 = segment40.calculateSegmentNumber((long) 2958465);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment43 = segment40.copy();
        try {
            defaultIntervalCategoryDataset21.setEndValue(128, (java.lang.Comparable) segment40, (java.lang.Number) 25566L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset.setValue: series outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray4);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(comparableArray11);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(segmentedTimeline23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 5 + "'", int24 == 5);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(textAnchor33);
        org.junit.Assert.assertNotNull(itemLabelAnchor34);
        org.junit.Assert.assertNotNull(textAnchor35);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(segment40);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 25566L + "'", long42 == 25566L);
        org.junit.Assert.assertNotNull(segment43);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean1 = lineAndShapeRenderer0.getDrawOutlines();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer2 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint3 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        statisticalBarRenderer2.setBasePaint(paint3);
        boolean boolean5 = statisticalBarRenderer2.getIncludeBaseInRange();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer6.setSeriesLinesVisible((int) '4', (java.lang.Boolean) true);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor11 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE7;
        org.jfree.chart.text.TextAnchor textAnchor12 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor13 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor11, textAnchor12, textAnchor13, (double) 0L);
        lineAndShapeRenderer6.setSeriesNegativeItemLabelPosition((int) '4', itemLabelPosition15);
        statisticalBarRenderer2.setBaseNegativeItemLabelPosition(itemLabelPosition15);
        lineAndShapeRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition15);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier19 = lineAndShapeRenderer0.getDrawingSupplier();
        java.awt.Stroke stroke21 = lineAndShapeRenderer0.getSeriesStroke((int) 'a');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(itemLabelAnchor11);
        org.junit.Assert.assertNotNull(textAnchor12);
        org.junit.Assert.assertNotNull(textAnchor13);
        org.junit.Assert.assertNull(drawingSupplier19);
        org.junit.Assert.assertNull(stroke21);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = statisticalBarRenderer0.getSeriesURLGenerator((int) (short) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        statisticalBarRenderer0.setGradientPaintTransformer(gradientPaintTransformer3);
        java.awt.Paint paint7 = statisticalBarRenderer0.getItemPaint((int) (byte) 100, (int) '#');
        statisticalBarRenderer0.setSeriesCreateEntities(31, (java.lang.Boolean) true);
        org.jfree.chart.LegendItemCollection legendItemCollection11 = statisticalBarRenderer0.getLegendItems();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator12 = null;
        statisticalBarRenderer0.setBaseURLGenerator(categoryURLGenerator12);
        java.awt.Paint paint15 = statisticalBarRenderer0.getSeriesOutlinePaint((int) (byte) -1);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean18 = categoryPlot17.isDomainGridlinesVisible();
        org.jfree.chart.axis.AxisLocation axisLocation19 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot17.setDomainAxisLocation(axisLocation19);
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot21.setRangeCrosshairValue((double) (byte) 1);
        org.jfree.chart.axis.ValueAxis valueAxis24 = categoryPlot21.getRangeAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = categoryPlot21.getDomainAxis((int) ' ');
        org.jfree.chart.axis.CategoryAnchor categoryAnchor27 = categoryPlot21.getDomainGridlinePosition();
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range29 = numberAxis28.getDefaultAutoRange();
        boolean boolean31 = numberAxis28.equals((java.lang.Object) (byte) -1);
        categoryPlot21.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis28);
        numberAxis28.setRangeWithMargins(0.0d, 90.0d);
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis36.setLowerMargin((double) 10.0f);
        categoryAxis36.configure();
        categoryAxis36.removeCategoryLabelToolTip((java.lang.Comparable) "First");
        org.jfree.chart.block.LabelBlock labelBlock46 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D47 = labelBlock46.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity50 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D47, "", "Preceding");
        org.jfree.chart.entity.LegendItemEntity legendItemEntity51 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D47);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer52 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint53 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        statisticalBarRenderer52.setBasePaint(paint53);
        org.jfree.chart.title.LegendGraphic legendGraphic55 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape) rectangle2D47, paint53);
        org.jfree.chart.util.RectangleEdge rectangleEdge56 = null;
        double double57 = categoryAxis36.getCategoryMiddle(0, 4, rectangle2D47, rectangleEdge56);
        statisticalBarRenderer0.drawRangeGridline(graphics2D16, categoryPlot17, (org.jfree.chart.axis.ValueAxis) numberAxis28, rectangle2D47, (double) 100L);
        categoryPlot17.setRangeCrosshairValue((double) 0L, false);
        org.junit.Assert.assertNull(categoryURLGenerator2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(legendItemCollection11);
        org.junit.Assert.assertNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNull(valueAxis24);
        org.junit.Assert.assertNull(categoryAxis26);
        org.junit.Assert.assertNotNull(categoryAnchor27);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(rectangle2D47);
        org.junit.Assert.assertNotNull(paint53);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.awt.Color color1 = java.awt.Color.darkGray;
        boolean boolean2 = defaultCategoryDataset0.equals((java.lang.Object) color1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.previous();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        boolean boolean6 = month3.equals((java.lang.Object) chartChangeEventType5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month3.previous();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(200);
        defaultCategoryDataset0.removeValue((java.lang.Comparable) regularTimePeriod7, (java.lang.Comparable) spreadsheetDate9);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(chartChangeEventType5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.lang.String str1 = textTitle0.getURLText();
        java.lang.String str2 = textTitle0.getURLText();
        org.jfree.chart.block.LineBorder lineBorder3 = new org.jfree.chart.block.LineBorder();
        textTitle0.setFrame((org.jfree.chart.block.BlockFrame) lineBorder3);
        java.lang.Object obj5 = textTitle0.clone();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D6 = labelBlock5.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D6, "", "Preceding");
        numberAxis1.setDownArrow((java.awt.Shape) rectangle2D6);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis1.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        double double13 = numberAxis12.getUpperBound();
        boolean boolean14 = numberAxis12.getAutoRangeStickyZero();
        boolean boolean15 = numberAxis12.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer16);
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        xYPlot17.setDataset(5, xYDataset19);
        int int21 = xYPlot17.getRangeAxisCount();
        double double22 = xYPlot17.getRangeCrosshairValue();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D2 = labelBlock1.getBounds();
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D2);
        org.jfree.chart.entity.ChartEntity chartEntity4 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D2);
        chartEntity4.setToolTipText("5");
        org.junit.Assert.assertNotNull(rectangle2D2);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        org.jfree.data.DefaultKeyedValue defaultKeyedValue2 = new org.jfree.data.DefaultKeyedValue((java.lang.Comparable) "", (java.lang.Number) 10.0f);
        java.lang.Object obj3 = defaultKeyedValue2.clone();
        defaultKeyedValue2.setValue((java.lang.Number) (short) -1);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        java.awt.Color color0 = java.awt.Color.YELLOW;
        int int1 = color0.getGreen();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean3 = categoryPlot2.isDomainGridlinesVisible();
        java.awt.Paint paint4 = categoryPlot2.getOutlinePaint();
        boolean boolean5 = color0.equals((java.lang.Object) paint4);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D6 = labelBlock5.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D6, "", "Preceding");
        numberAxis1.setDownArrow((java.awt.Shape) rectangle2D6);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis1.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        double double13 = numberAxis12.getUpperBound();
        boolean boolean14 = numberAxis12.getAutoRangeStickyZero();
        boolean boolean15 = numberAxis12.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer16);
        xYPlot17.setRangeCrosshairVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean22 = categoryPlot21.isDomainGridlinesVisible();
        org.jfree.chart.axis.AxisLocation axisLocation23 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot21.setDomainAxisLocation(axisLocation23);
        xYPlot17.setRangeAxisLocation((int) (byte) 10, axisLocation23);
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis();
        double double27 = numberAxis26.getUpperBound();
        boolean boolean28 = numberAxis26.getAutoRangeStickyZero();
        boolean boolean29 = numberAxis26.isAutoRange();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand30 = numberAxis26.getMarkerBand();
        java.awt.Shape shape31 = numberAxis26.getUpArrow();
        numberAxis26.setVerticalTickLabels(false);
        int int34 = xYPlot17.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis26);
        xYPlot17.setWeight((int) (short) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 1.0d + "'", double27 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNull(markerAxisBand30);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.time.DateRange dateRange1 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double2 = dateRange1.getCentralValue();
        double double3 = dateRange1.getUpperBound();
        java.util.Date date4 = dateRange1.getLowerDate();
        java.util.Date date5 = dateRange1.getUpperDate();
        dateAxis0.setMaximumDate(date5);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        double double10 = numberAxis9.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock13 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D14 = labelBlock13.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity17 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D14, "", "Preceding");
        numberAxis9.setDownArrow((java.awt.Shape) rectangle2D14);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = numberAxis9.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis();
        double double21 = numberAxis20.getUpperBound();
        boolean boolean22 = numberAxis20.getAutoRangeStickyZero();
        boolean boolean23 = numberAxis20.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset8, (org.jfree.chart.axis.ValueAxis) numberAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis20, xYItemRenderer24);
        xYPlot25.setRangeCrosshairVisible(false);
        org.jfree.chart.JFreeChart jFreeChart28 = new org.jfree.chart.JFreeChart("WMAP_Plot", (org.jfree.chart.plot.Plot) xYPlot25);
        boolean boolean29 = jFreeChart28.isNotify();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo32 = null;
        java.awt.image.BufferedImage bufferedImage33 = jFreeChart28.createBufferedImage(1, 6, chartRenderingInfo32);
        org.jfree.chart.title.TextTitle textTitle34 = new org.jfree.chart.title.TextTitle();
        java.lang.String str35 = textTitle34.getURLText();
        java.lang.String str36 = textTitle34.getURLText();
        jFreeChart28.addSubtitle((org.jfree.chart.title.Title) textTitle34);
        boolean boolean38 = dateAxis0.equals((java.lang.Object) jFreeChart28);
        org.jfree.chart.axis.DateTickUnit dateTickUnit41 = new org.jfree.chart.axis.DateTickUnit(0, 5);
        int int42 = dateTickUnit41.getRollUnit();
        int int43 = dateTickUnit41.getCalendarField();
        dateAxis0.setTickUnit(dateTickUnit41);
        org.junit.Assert.assertNotNull(dateRange1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5d + "'", double2 == 0.5d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(bufferedImage33);
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D6 = labelBlock5.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D6, "", "Preceding");
        numberAxis1.setDownArrow((java.awt.Shape) rectangle2D6);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis1.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        double double13 = numberAxis12.getUpperBound();
        boolean boolean14 = numberAxis12.getAutoRangeStickyZero();
        boolean boolean15 = numberAxis12.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer16);
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = xYPlot17.getRendererForDataset(xYDataset18);
        org.jfree.chart.axis.AxisSpace axisSpace20 = xYPlot17.getFixedDomainAxisSpace();
        boolean boolean21 = xYPlot17.isDomainZeroBaselineVisible();
        java.awt.Stroke stroke22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYPlot17.setDomainCrosshairStroke(stroke22);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent24 = null;
        xYPlot17.rendererChanged(rendererChangeEvent24);
        org.jfree.chart.axis.AxisLocation axisLocation27 = xYPlot17.getDomainAxisLocation(255);
        org.jfree.chart.axis.AxisSpace axisSpace28 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = org.jfree.chart.util.RectangleEdge.LEFT;
        axisSpace28.ensureAtLeast((double) ' ', rectangleEdge30);
        axisSpace28.setBottom(0.0d);
        axisSpace28.setTop((double) (-1));
        double double36 = axisSpace28.getLeft();
        xYPlot17.setFixedRangeAxisSpace(axisSpace28);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(xYItemRenderer19);
        org.junit.Assert.assertNull(axisSpace20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 32.0d + "'", double36 == 32.0d);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_90;
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge((int) (short) 0);
        categoryPlot0.setAnchorValue((double) 10.0f, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = categoryPlot0.getDomainAxisEdge();
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator10 = piePlot9.getToolTipGenerator();
        java.awt.Font font11 = piePlot9.getLabelFont();
        java.awt.Stroke stroke13 = piePlot9.getSectionOutlineStroke((java.lang.Comparable) 0L);
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis();
        double double16 = numberAxis15.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock19 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D20 = labelBlock19.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity23 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D20, "", "Preceding");
        numberAxis15.setDownArrow((java.awt.Shape) rectangle2D20);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = numberAxis15.getLabelInsets();
        numberAxis15.setVerticalTickLabels(true);
        java.awt.Stroke stroke28 = numberAxis15.getAxisLineStroke();
        piePlot9.setSectionOutlineStroke((java.lang.Comparable) "({0}, {1}) = {2}", stroke28);
        categoryPlot0.setRangeGridlineStroke(stroke28);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNull(pieToolTipGenerator10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNull(stroke13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(stroke28);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("CONTRACT");
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = new org.jfree.chart.axis.DateTickUnit(0, 5);
        int int4 = dateTickUnit3.getRollUnit();
        boolean boolean5 = categoryLabelPositions0.equals((java.lang.Object) dateTickUnit3);
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 1L, (double) 31);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = stackedBarRenderer3D2.getGradientPaintTransformer();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer5 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = statisticalBarRenderer5.getSeriesURLGenerator((int) (short) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer8 = null;
        statisticalBarRenderer5.setGradientPaintTransformer(gradientPaintTransformer8);
        java.awt.Paint paint11 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        statisticalBarRenderer5.setSeriesOutlinePaint(2019, paint11);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer14 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.block.LabelBlock labelBlock17 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D18 = labelBlock17.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity21 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D18, "", "Preceding");
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double23 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D18, rectangleEdge22);
        statisticalBarRenderer14.setBaseShape((java.awt.Shape) rectangle2D18, true);
        statisticalBarRenderer5.setSeriesShape(1, (java.awt.Shape) rectangle2D18);
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.JFreeChart jFreeChart28 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent31 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) categoryPlot27, jFreeChart28, 200, (int) (byte) 0);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor32 = categoryPlot27.getDomainGridlinePosition();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer34 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer34.setSeriesLinesVisible((int) '4', (java.lang.Boolean) true);
        boolean boolean38 = lineAndShapeRenderer34.getBaseShapesFilled();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator39 = null;
        lineAndShapeRenderer34.setBaseToolTipGenerator(categoryToolTipGenerator39);
        categoryPlot27.setRenderer(1, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer34);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo43 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo44 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo43);
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState45 = stackedBarRenderer3D2.initialise(graphics2D4, rectangle2D18, categoryPlot27, 7, plotRenderingInfo44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gradientPaintTransformer3);
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(categoryAnchor32);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape4 = null;
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.previous();
        org.jfree.data.time.Year year7 = month5.getYear();
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        double double10 = numberAxis9.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock13 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D14 = labelBlock13.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity17 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D14, "", "Preceding");
        numberAxis9.setDownArrow((java.awt.Shape) rectangle2D14);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = numberAxis9.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis();
        double double21 = numberAxis20.getUpperBound();
        boolean boolean22 = numberAxis20.getAutoRangeStickyZero();
        boolean boolean23 = numberAxis20.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset8, (org.jfree.chart.axis.ValueAxis) numberAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis20, xYItemRenderer24);
        boolean boolean26 = xYPlot25.isDomainCrosshairVisible();
        org.jfree.chart.axis.AxisLocation axisLocation28 = xYPlot25.getRangeAxisLocation((int) (short) -1);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer29 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke30 = statisticalBarRenderer29.getBaseStroke();
        xYPlot25.setDomainZeroBaselineStroke(stroke30);
        int int32 = year7.compareTo((java.lang.Object) stroke30);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer33 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke34 = statisticalBarRenderer33.getBaseStroke();
        java.awt.Color color35 = java.awt.Color.PINK;
        statisticalBarRenderer33.setBaseItemLabelPaint((java.awt.Paint) color35, false);
        try {
            org.jfree.chart.LegendItem legendItem38 = new org.jfree.chart.LegendItem(attributedString0, "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "TextAnchor.CENTER", "XY Plot", shape4, stroke30, (java.awt.Paint) color35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(color35);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getUpperBound();
        boolean boolean3 = numberAxis1.getAutoRangeStickyZero();
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        double double5 = numberAxis4.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock8 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D9 = labelBlock8.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity12 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D9, "", "Preceding");
        numberAxis4.setDownArrow((java.awt.Shape) rectangle2D9);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = numberAxis4.getLabelInsets();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot15.setRangeCrosshairValue((double) (byte) 1);
        org.jfree.chart.axis.ValueAxis valueAxis18 = categoryPlot15.getRangeAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = categoryPlot15.getDomainAxis((int) ' ');
        boolean boolean21 = numberAxis4.hasListener((java.util.EventListener) categoryPlot15);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis4, xYItemRenderer22);
        java.awt.Paint paint24 = numberAxis1.getTickLabelPaint();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent25 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis1);
        org.jfree.chart.JFreeChart jFreeChart26 = axisChangeEvent25.getChart();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D9);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNull(valueAxis18);
        org.junit.Assert.assertNull(categoryAxis20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNull(jFreeChart26);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        java.awt.Font font1 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        java.awt.Color color2 = java.awt.Color.GRAY;
        int int3 = color2.getTransparency();
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("Preceding", font1, (java.awt.Paint) color2, (float) (short) -1);
        java.awt.Paint paint6 = textFragment5.getPaint();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE11;
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(textAnchor1);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str1 = projectInfo0.getCopyright();
        projectInfo0.setInfo("({0}, {1}) = {2}");
        java.lang.String str4 = projectInfo0.getCopyright();
        projectInfo0.setInfo("SortOrder.ASCENDING");
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        double double9 = numberAxis8.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock12 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D13 = labelBlock12.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity16 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D13, "", "Preceding");
        numberAxis8.setDownArrow((java.awt.Shape) rectangle2D13);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = numberAxis8.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis();
        double double20 = numberAxis19.getUpperBound();
        boolean boolean21 = numberAxis19.getAutoRangeStickyZero();
        boolean boolean22 = numberAxis19.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = null;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) numberAxis8, (org.jfree.chart.axis.ValueAxis) numberAxis19, xYItemRenderer23);
        xYPlot24.setRangeCrosshairVisible(false);
        java.lang.String str27 = xYPlot24.getPlotType();
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis();
        double double29 = numberAxis28.getUpperBound();
        boolean boolean30 = numberAxis28.getAutoRangeStickyZero();
        boolean boolean31 = numberAxis28.isAutoRange();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand32 = numberAxis28.getMarkerBand();
        java.awt.Shape shape33 = numberAxis28.getUpArrow();
        boolean boolean34 = numberAxis28.isPositiveArrowVisible();
        xYPlot24.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis28);
        int int36 = xYPlot24.getWeight();
        boolean boolean37 = projectInfo0.equals((java.lang.Object) int36);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "XY Plot" + "'", str27.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNull(markerAxisBand32);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D3 = labelBlock2.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity6 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D3, "", "Preceding");
        org.jfree.chart.entity.LegendItemEntity legendItemEntity7 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D3);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint9 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        statisticalBarRenderer8.setBasePaint(paint9);
        org.jfree.chart.title.LegendGraphic legendGraphic11 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape) rectangle2D3, paint9);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = legendGraphic11.getShapeAnchor();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = legendGraphic11.getShapeAnchor();
        java.awt.Paint paint14 = legendGraphic11.getFillPaint();
        legendGraphic11.setShapeOutlineVisible(true);
        boolean boolean17 = legendGraphic11.isShapeOutlineVisible();
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.data.time.DateRange dateRange19 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double20 = dateRange19.getCentralValue();
        org.jfree.data.time.DateRange dateRange21 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double22 = dateRange21.getCentralValue();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint23 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange19, (org.jfree.data.Range) dateRange21);
        org.jfree.data.time.DateRange dateRange24 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double25 = dateRange24.getCentralValue();
        org.jfree.data.time.DateRange dateRange26 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double27 = dateRange26.getCentralValue();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint28 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange24, (org.jfree.data.Range) dateRange26);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint30 = rectangleConstraint28.toFixedHeight((double) 10.0f);
        org.jfree.data.Range range31 = rectangleConstraint28.getWidthRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint32 = rectangleConstraint23.toRangeHeight(range31);
        try {
            org.jfree.chart.util.Size2D size2D33 = legendGraphic11.arrange(graphics2D18, rectangleConstraint23);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(dateRange19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.5d + "'", double20 == 0.5d);
        org.junit.Assert.assertNotNull(dateRange21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.5d + "'", double22 == 0.5d);
        org.junit.Assert.assertNotNull(dateRange24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.5d + "'", double25 == 0.5d);
        org.junit.Assert.assertNotNull(dateRange26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.5d + "'", double27 == 0.5d);
        org.junit.Assert.assertNotNull(rectangleConstraint30);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertNotNull(rectangleConstraint32);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Color color1 = java.awt.Color.gray;
        java.awt.Color color2 = color1.brighter();
        java.lang.String str3 = color1.toString();
        waterfallBarRenderer0.setFirstBarPaint((java.awt.Paint) color1);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean9 = categoryPlot8.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot8.getDomainAxisEdge((int) (short) 0);
        float float12 = categoryPlot8.getForegroundAlpha();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        categoryPlot8.setRenderer((int) (short) 100, categoryItemRenderer14, true);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor17 = categoryPlot8.getDomainGridlinePosition();
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer19 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator21 = statisticalBarRenderer19.getSeriesURLGenerator((int) (short) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer22 = null;
        statisticalBarRenderer19.setGradientPaintTransformer(gradientPaintTransformer22);
        java.awt.Paint paint26 = statisticalBarRenderer19.getItemPaint((int) (byte) 100, (int) '#');
        statisticalBarRenderer19.setSeriesCreateEntities(31, (java.lang.Boolean) true);
        org.jfree.chart.LegendItemCollection legendItemCollection30 = statisticalBarRenderer19.getLegendItems();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator31 = null;
        statisticalBarRenderer19.setBaseURLGenerator(categoryURLGenerator31);
        java.awt.Paint paint34 = statisticalBarRenderer19.getSeriesOutlinePaint((int) (byte) -1);
        java.awt.Graphics2D graphics2D35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean37 = categoryPlot36.isDomainGridlinesVisible();
        org.jfree.chart.axis.AxisLocation axisLocation38 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot36.setDomainAxisLocation(axisLocation38);
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot40.setRangeCrosshairValue((double) (byte) 1);
        org.jfree.chart.axis.ValueAxis valueAxis43 = categoryPlot40.getRangeAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis45 = categoryPlot40.getDomainAxis((int) ' ');
        org.jfree.chart.axis.CategoryAnchor categoryAnchor46 = categoryPlot40.getDomainGridlinePosition();
        org.jfree.chart.axis.NumberAxis numberAxis47 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range48 = numberAxis47.getDefaultAutoRange();
        boolean boolean50 = numberAxis47.equals((java.lang.Object) (byte) -1);
        categoryPlot40.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis47);
        numberAxis47.setRangeWithMargins(0.0d, 90.0d);
        org.jfree.chart.axis.CategoryAxis categoryAxis55 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis55.setLowerMargin((double) 10.0f);
        categoryAxis55.configure();
        categoryAxis55.removeCategoryLabelToolTip((java.lang.Comparable) "First");
        org.jfree.chart.block.LabelBlock labelBlock65 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D66 = labelBlock65.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity69 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D66, "", "Preceding");
        org.jfree.chart.entity.LegendItemEntity legendItemEntity70 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D66);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer71 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint72 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        statisticalBarRenderer71.setBasePaint(paint72);
        org.jfree.chart.title.LegendGraphic legendGraphic74 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape) rectangle2D66, paint72);
        org.jfree.chart.util.RectangleEdge rectangleEdge75 = null;
        double double76 = categoryAxis55.getCategoryMiddle(0, 4, rectangle2D66, rectangleEdge75);
        statisticalBarRenderer19.drawRangeGridline(graphics2D35, categoryPlot36, (org.jfree.chart.axis.ValueAxis) numberAxis47, rectangle2D66, (double) 100L);
        numberAxis47.setAutoRangeStickyZero(true);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection81 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range83 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection81, true);
        try {
            waterfallBarRenderer0.drawItem(graphics2D5, categoryItemRendererState6, rectangle2D7, categoryPlot8, categoryAxis18, (org.jfree.chart.axis.ValueAxis) numberAxis47, (org.jfree.data.category.CategoryDataset) taskSeriesCollection81, 0, 12, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java.awt.Color[r=128,g=128,b=128]" + "'", str3.equals("java.awt.Color[r=128,g=128,b=128]"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 1.0f + "'", float12 == 1.0f);
        org.junit.Assert.assertNotNull(categoryAnchor17);
        org.junit.Assert.assertNull(categoryURLGenerator21);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(legendItemCollection30);
        org.junit.Assert.assertNull(paint34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(axisLocation38);
        org.junit.Assert.assertNull(valueAxis43);
        org.junit.Assert.assertNull(categoryAxis45);
        org.junit.Assert.assertNotNull(categoryAnchor46);
        org.junit.Assert.assertNotNull(range48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(rectangle2D66);
        org.junit.Assert.assertNotNull(paint72);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertNull(range83);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        org.jfree.data.time.DateRange dateRange0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double1 = dateRange0.getCentralValue();
        double double2 = dateRange0.getUpperBound();
        java.util.Date date3 = dateRange0.getLowerDate();
        java.util.Date date4 = dateRange0.getUpperDate();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone5;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone5;
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date4, timeZone5);
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer10 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator12 = statisticalBarRenderer10.getSeriesURLGenerator((int) (short) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer13 = null;
        statisticalBarRenderer10.setGradientPaintTransformer(gradientPaintTransformer13);
        java.awt.Paint paint16 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        statisticalBarRenderer10.setSeriesOutlinePaint(2019, paint16);
        boolean boolean18 = textTitle9.equals((java.lang.Object) paint16);
        int int19 = month8.compareTo((java.lang.Object) boolean18);
        org.junit.Assert.assertNotNull(dateRange0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5d + "'", double1 == 0.5d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNull(categoryURLGenerator12);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 1L, (double) 31);
        boolean boolean4 = stackedBarRenderer3D2.equals((java.lang.Object) (-1.0f));
        stackedBarRenderer3D2.setRenderAsPercentages(true);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        stackedBarRenderer3D2.setWallPaint((java.awt.Paint) color7);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer10.setSeriesLinesVisible((int) '4', (java.lang.Boolean) true);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor15 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE7;
        org.jfree.chart.text.TextAnchor textAnchor16 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor17 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor15, textAnchor16, textAnchor17, (double) 0L);
        lineAndShapeRenderer10.setSeriesNegativeItemLabelPosition((int) '4', itemLabelPosition19);
        org.jfree.data.DefaultKeyedValue defaultKeyedValue23 = new org.jfree.data.DefaultKeyedValue((java.lang.Comparable) 0.0d, (java.lang.Number) 100.0f);
        boolean boolean24 = itemLabelPosition19.equals((java.lang.Object) 0.0d);
        try {
            stackedBarRenderer3D2.setSeriesNegativeItemLabelPosition((int) (short) -1, itemLabelPosition19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(itemLabelAnchor15);
        org.junit.Assert.assertNotNull(textAnchor16);
        org.junit.Assert.assertNotNull(textAnchor17);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 1L, (double) 31);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        double double6 = numberAxis5.getUpperBound();
        boolean boolean7 = numberAxis5.getAutoRangeStickyZero();
        org.jfree.chart.plot.Marker marker8 = null;
        org.jfree.data.general.WaferMapDataset waferMapDataset9 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot10 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset9);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.block.LabelBlock labelBlock14 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D15 = labelBlock14.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity18 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D15, "", "Preceding");
        waferMapPlot10.drawBackgroundImage(graphics2D11, rectangle2D15);
        stackedBarRenderer3D2.drawRangeMarker(graphics2D3, categoryPlot4, (org.jfree.chart.axis.ValueAxis) numberAxis5, marker8, rectangle2D15);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor21 = categoryPlot4.getDomainGridlinePosition();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        java.awt.geom.Point2D point2D25 = null;
        categoryPlot4.zoomRangeAxes((double) (-1), (double) ' ', plotRenderingInfo24, point2D25);
        org.jfree.data.category.CategoryDataset categoryDataset28 = categoryPlot4.getDataset((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNotNull(categoryAnchor21);
        org.junit.Assert.assertNull(categoryDataset28);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairValue((double) (byte) 1);
        double[] doubleArray10 = new double[] { (-1L), 0.0d };
        double[] doubleArray13 = new double[] { (-1L), 0.0d };
        double[] doubleArray16 = new double[] { (-1L), 0.0d };
        double[] doubleArray19 = new double[] { (-1L), 0.0d };
        double[][] doubleArray20 = new double[][] { doubleArray10, doubleArray13, doubleArray16, doubleArray19 };
        org.jfree.data.category.CategoryDataset categoryDataset21 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", doubleArray20);
        org.jfree.data.category.CategoryDataset categoryDataset22 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray20);
        double[] doubleArray29 = new double[] { (-1L), 0.0d };
        double[] doubleArray32 = new double[] { (-1L), 0.0d };
        double[] doubleArray35 = new double[] { (-1L), 0.0d };
        double[] doubleArray38 = new double[] { (-1L), 0.0d };
        double[][] doubleArray39 = new double[][] { doubleArray29, doubleArray32, doubleArray35, doubleArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", doubleArray39);
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray39);
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset42 = new org.jfree.data.category.DefaultIntervalCategoryDataset(doubleArray20, doubleArray39);
        categoryPlot0.setDataset(100, (org.jfree.data.category.CategoryDataset) defaultIntervalCategoryDataset42);
        categoryPlot0.setRangeGridlinesVisible(false);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(categoryDataset21);
        org.junit.Assert.assertNotNull(categoryDataset22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNotNull(categoryDataset41);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D3 = labelBlock2.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity6 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D3, "", "Preceding");
        org.jfree.chart.entity.LegendItemEntity legendItemEntity7 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D3);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint9 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        statisticalBarRenderer8.setBasePaint(paint9);
        org.jfree.chart.title.LegendGraphic legendGraphic11 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape) rectangle2D3, paint9);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = legendGraphic11.getShapeAnchor();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = legendGraphic11.getShapeAnchor();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor14 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor15 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE7;
        org.jfree.chart.text.TextAnchor textAnchor16 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor17 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor15, textAnchor16, textAnchor17, (double) 0L);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor22 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType23 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition25 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor21, textBlockAnchor22, categoryLabelWidthType23, (float) 2958465);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition27 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor13, textBlockAnchor14, textAnchor16, (double) 1561964399999L, categoryLabelWidthType23, (float) 3);
        double double28 = categoryLabelPosition27.getAngle();
        org.junit.Assert.assertNotNull(rectangle2D3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
        org.junit.Assert.assertNotNull(textBlockAnchor14);
        org.junit.Assert.assertNotNull(itemLabelAnchor15);
        org.junit.Assert.assertNotNull(textAnchor16);
        org.junit.Assert.assertNotNull(textAnchor17);
        org.junit.Assert.assertNotNull(rectangleAnchor21);
        org.junit.Assert.assertNotNull(textBlockAnchor22);
        org.junit.Assert.assertNotNull(categoryLabelWidthType23);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.561964399999E12d + "'", double28 == 1.561964399999E12d);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(1.0E-8d, 1.561964399999E12d);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D5 = labelBlock4.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity8 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D5, "", "Preceding");
        numberAxis0.setDownArrow((java.awt.Shape) rectangle2D5);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = numberAxis0.getLabelInsets();
        numberAxis0.setVerticalTickLabels(true);
        double[] doubleArray17 = new double[] { (-1L), 0.0d };
        double[] doubleArray20 = new double[] { (-1L), 0.0d };
        double[] doubleArray23 = new double[] { (-1L), 0.0d };
        double[] doubleArray26 = new double[] { (-1L), 0.0d };
        double[][] doubleArray27 = new double[][] { doubleArray17, doubleArray20, doubleArray23, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", doubleArray27);
        org.jfree.data.Range range29 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset28);
        numberAxis0.setRangeWithMargins(range29, false, true);
        numberAxis0.setTickMarksVisible(true);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNotNull(range29);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Comparable comparable2 = null;
        try {
            int int3 = taskSeriesCollection0.getSubIntervalCount((java.lang.Comparable) (-2208960000000L), comparable2);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) 24234L, (float) 3600000L, (float) 24234L);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLowerMargin((double) 10.0f);
        org.jfree.data.general.WaferMapDataset waferMapDataset3 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot4 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset3);
        float float5 = waferMapPlot4.getForegroundAlpha();
        java.lang.String str6 = waferMapPlot4.getPlotType();
        boolean boolean7 = categoryAxis0.equals((java.lang.Object) str6);
        float float8 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        categoryAxis0.setLowerMargin(0.0d);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 1.0f + "'", float5 == 1.0f);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "WMAP_Plot" + "'", str6.equals("WMAP_Plot"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.0f + "'", float8 == 0.0f);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition0 = new org.jfree.chart.labels.ItemLabelPosition();
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D6 = labelBlock5.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D6, "", "Preceding");
        numberAxis1.setDownArrow((java.awt.Shape) rectangle2D6);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis1.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        double double13 = numberAxis12.getUpperBound();
        boolean boolean14 = numberAxis12.getAutoRangeStickyZero();
        boolean boolean15 = numberAxis12.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer16);
        xYPlot17.clearDomainAxes();
        xYPlot17.clearDomainMarkers();
        xYPlot17.setRangeCrosshairVisible(true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.time.DateRange dateRange1 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double2 = dateRange1.getCentralValue();
        double double3 = dateRange1.getUpperBound();
        java.util.Date date4 = dateRange1.getLowerDate();
        java.util.Date date5 = dateRange1.getUpperDate();
        dateAxis0.setMaximumDate(date5);
        org.jfree.chart.axis.DateTickUnit dateTickUnit7 = null;
        try {
            java.util.Date date8 = dateAxis0.calculateLowestVisibleTickValue(dateTickUnit7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateRange1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5d + "'", double2 == 0.5d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (byte) 100);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairValue((double) (byte) 1);
        double[] doubleArray10 = new double[] { (-1L), 0.0d };
        double[] doubleArray13 = new double[] { (-1L), 0.0d };
        double[] doubleArray16 = new double[] { (-1L), 0.0d };
        double[] doubleArray19 = new double[] { (-1L), 0.0d };
        double[][] doubleArray20 = new double[][] { doubleArray10, doubleArray13, doubleArray16, doubleArray19 };
        org.jfree.data.category.CategoryDataset categoryDataset21 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", doubleArray20);
        org.jfree.data.category.CategoryDataset categoryDataset22 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray20);
        double[] doubleArray29 = new double[] { (-1L), 0.0d };
        double[] doubleArray32 = new double[] { (-1L), 0.0d };
        double[] doubleArray35 = new double[] { (-1L), 0.0d };
        double[] doubleArray38 = new double[] { (-1L), 0.0d };
        double[][] doubleArray39 = new double[][] { doubleArray29, doubleArray32, doubleArray35, doubleArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", doubleArray39);
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray39);
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset42 = new org.jfree.data.category.DefaultIntervalCategoryDataset(doubleArray20, doubleArray39);
        categoryPlot0.setDataset(100, (org.jfree.data.category.CategoryDataset) defaultIntervalCategoryDataset42);
        org.jfree.data.xy.XYDataset xYDataset45 = null;
        org.jfree.chart.axis.NumberAxis numberAxis46 = new org.jfree.chart.axis.NumberAxis();
        double double47 = numberAxis46.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock50 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D51 = labelBlock50.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity54 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D51, "", "Preceding");
        numberAxis46.setDownArrow((java.awt.Shape) rectangle2D51);
        org.jfree.chart.util.RectangleInsets rectangleInsets56 = numberAxis46.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis57 = new org.jfree.chart.axis.NumberAxis();
        double double58 = numberAxis57.getUpperBound();
        boolean boolean59 = numberAxis57.getAutoRangeStickyZero();
        boolean boolean60 = numberAxis57.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer61 = null;
        org.jfree.chart.plot.XYPlot xYPlot62 = new org.jfree.chart.plot.XYPlot(xYDataset45, (org.jfree.chart.axis.ValueAxis) numberAxis46, (org.jfree.chart.axis.ValueAxis) numberAxis57, xYItemRenderer61);
        xYPlot62.setRangeCrosshairVisible(false);
        org.jfree.chart.JFreeChart jFreeChart65 = new org.jfree.chart.JFreeChart("WMAP_Plot", (org.jfree.chart.plot.Plot) xYPlot62);
        org.jfree.chart.title.TextTitle textTitle66 = new org.jfree.chart.title.TextTitle();
        jFreeChart65.addSubtitle((org.jfree.chart.title.Title) textTitle66);
        org.jfree.chart.title.TextTitle textTitle68 = new org.jfree.chart.title.TextTitle();
        java.lang.String str69 = textTitle68.getURLText();
        jFreeChart65.addSubtitle((org.jfree.chart.title.Title) textTitle68);
        categoryPlot0.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart65);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(categoryDataset21);
        org.junit.Assert.assertNotNull(categoryDataset22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.0d + "'", double47 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D51);
        org.junit.Assert.assertNotNull(rectangleInsets56);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 1.0d + "'", double58 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertNull(str69);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("RectangleEdge.TOP");
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        taskSeries1.addPropertyChangeListener(propertyChangeListener2);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        java.awt.Shape shape0 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset3 = new org.jfree.data.category.DefaultCategoryDataset();
        int int5 = defaultCategoryDataset3.getColumnIndex((java.lang.Comparable) 10);
        defaultCategoryDataset3.removeValue((java.lang.Comparable) 0.5d, (java.lang.Comparable) 0.0d);
        try {
            org.jfree.chart.entity.CategoryItemEntity categoryItemEntity11 = new org.jfree.chart.entity.CategoryItemEntity(shape0, "CategoryLabelWidthType.CATEGORY", "AreaRendererEndType.LEVEL", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset3, (java.lang.Comparable) 1577865599999L, (java.lang.Comparable) 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        try {
            dateAxis0.setRange((double) (short) 0, (double) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, true);
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        double double4 = numberAxis3.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock7 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D8 = labelBlock7.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity11 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D8, "", "Preceding");
        numberAxis3.setDownArrow((java.awt.Shape) rectangle2D8);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = numberAxis3.getLabelInsets();
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
        numberAxis3.setRightArrow(shape15);
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.clone(shape15);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor18 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape15, rectangleAnchor18, 0.05d, 0.0d);
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.clone(shape21);
        statisticalLineAndShapeRenderer2.setBaseShape(shape21, false);
        statisticalLineAndShapeRenderer2.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) true);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(rectangleAnchor18);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(shape22);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        java.lang.Comparable comparable0 = null;
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D3 = labelBlock2.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity6 = new org.jfree.chart.entity.CategoryLabelEntity(comparable0, (java.awt.Shape) rectangle2D3, "ThreadContext", "Fourth");
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D3);
        org.junit.Assert.assertNotNull(rectangle2D3);
        org.junit.Assert.assertNotNull(shape7);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator2 = piePlot1.getToolTipGenerator();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = null;
        piePlot1.setLabelGenerator(pieSectionLabelGenerator3);
        java.awt.Paint paint5 = piePlot1.getLabelBackgroundPaint();
        java.awt.Color color7 = java.awt.Color.BLACK;
        int int8 = color7.getBlue();
        piePlot1.setSectionOutlinePaint((java.lang.Comparable) "Preceding", (java.awt.Paint) color7);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month10.previous();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        boolean boolean13 = month10.equals((java.lang.Object) chartChangeEventType12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month10.previous();
        java.awt.Stroke stroke15 = null;
        piePlot1.setSectionOutlineStroke((java.lang.Comparable) month10, stroke15);
        java.awt.Paint paint17 = piePlot1.getLabelPaint();
        org.junit.Assert.assertNull(pieToolTipGenerator2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(chartChangeEventType12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        int int2 = month1.getYearValue();
        int int3 = month1.getMonth();
        defaultKeyedValues0.addValue((java.lang.Comparable) int3, (double) (byte) 100);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.JFreeChart jFreeChart7 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent10 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) categoryPlot6, jFreeChart7, 200, (int) (byte) 0);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor11 = categoryPlot6.getDomainGridlinePosition();
        categoryPlot6.setAnchorValue((double) 900000L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = categoryPlot20.getAxisOffset();
        org.jfree.chart.block.LabelBlock labelBlock24 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D25 = labelBlock24.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity28 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D25, "", "Preceding");
        org.jfree.chart.entity.LegendItemEntity legendItemEntity29 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D25);
        java.awt.geom.Rectangle2D rectangle2D30 = rectangleInsets21.createOutsetRectangle(rectangle2D25);
        java.awt.geom.Point2D point2D31 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(0.0d, (double) 900000L, rectangle2D25);
        categoryPlot6.zoomRangeAxes((double) 3600000L, (double) 0.5f, plotRenderingInfo17, point2D31);
        org.jfree.chart.util.SortOrder sortOrder33 = categoryPlot6.getRowRenderingOrder();
        defaultKeyedValues0.sortByValues(sortOrder33);
        try {
            java.lang.Comparable comparable36 = defaultKeyedValues0.getKey((-65536));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNotNull(categoryAnchor11);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(point2D31);
        org.junit.Assert.assertNotNull(sortOrder33);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        axisState0.cursorRight((double) (byte) 1);
        axisState0.cursorLeft(1.561964399999E12d);
        axisState0.cursorDown((double) 5);
        axisState0.setMax(1.0E-8d);
        axisState0.setMax(0.0d);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getUpperBound();
        boolean boolean3 = numberAxis1.getAutoRangeStickyZero();
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        double double5 = numberAxis4.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock8 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D9 = labelBlock8.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity12 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D9, "", "Preceding");
        numberAxis4.setDownArrow((java.awt.Shape) rectangle2D9);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = numberAxis4.getLabelInsets();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot15.setRangeCrosshairValue((double) (byte) 1);
        org.jfree.chart.axis.ValueAxis valueAxis18 = categoryPlot15.getRangeAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = categoryPlot15.getDomainAxis((int) ' ');
        boolean boolean21 = numberAxis4.hasListener((java.util.EventListener) categoryPlot15);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis4, xYItemRenderer22);
        numberAxis4.setAutoRangeStickyZero(true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D9);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNull(valueAxis18);
        org.junit.Assert.assertNull(categoryAxis20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month1.previous();
        java.util.Date date3 = month1.getEnd();
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double5 = dateRange4.getCentralValue();
        double double6 = dateRange4.getUpperBound();
        java.util.Date date7 = dateRange4.getUpperDate();
        try {
            org.jfree.data.gantt.Task task8 = new org.jfree.data.gantt.Task("DateTickMarkPosition.START", date3, date7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires end >= start.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.5d + "'", double5 == 0.5d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = statisticalBarRenderer3.getSeriesURLGenerator((int) (short) 100);
        int int6 = statisticalBarRenderer3.getColumnCount();
        double double7 = statisticalBarRenderer3.getItemMargin();
        java.lang.Class<?> wildcardClass8 = statisticalBarRenderer3.getClass();
        java.io.InputStream inputStream9 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("SortOrder.ASCENDING", (java.lang.Class) wildcardClass8);
        java.net.URL uRL10 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", (java.lang.Class) wildcardClass8);
        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer12 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator14 = statisticalBarRenderer12.getSeriesURLGenerator((int) (short) 100);
        int int15 = statisticalBarRenderer12.getColumnCount();
        double double16 = statisticalBarRenderer12.getItemMargin();
        java.lang.Class<?> wildcardClass17 = statisticalBarRenderer12.getClass();
        java.lang.Object obj18 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", (java.lang.Class) wildcardClass8, (java.lang.Class) wildcardClass17);
        org.junit.Assert.assertNull(categoryURLGenerator5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.2d + "'", double7 == 0.2d);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNull(inputStream9);
        org.junit.Assert.assertNull(uRL10);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertNull(categoryURLGenerator14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.2d + "'", double16 == 0.2d);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNull(obj18);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) categoryPlot0, jFreeChart1, 200, (int) (byte) 0);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor5 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer7.setSeriesLinesVisible((int) '4', (java.lang.Boolean) true);
        boolean boolean11 = lineAndShapeRenderer7.getBaseShapesFilled();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = null;
        lineAndShapeRenderer7.setBaseToolTipGenerator(categoryToolTipGenerator12);
        categoryPlot0.setRenderer(1, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer7);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = categoryPlot0.getRangeAxisEdge(128);
        org.junit.Assert.assertNotNull(categoryAnchor5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(rectangleEdge16);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        int int2 = month1.getYearValue();
        int int3 = month1.getMonth();
        defaultKeyedValues0.addValue((java.lang.Comparable) int3, (double) (byte) 100);
        defaultKeyedValues0.setValue((java.lang.Comparable) 0, (java.lang.Number) (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = statisticalBarRenderer0.getSeriesURLGenerator((int) (short) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        statisticalBarRenderer0.setGradientPaintTransformer(gradientPaintTransformer3);
        java.awt.Paint paint7 = statisticalBarRenderer0.getItemPaint((int) (byte) 100, (int) '#');
        java.awt.Shape shape9 = statisticalBarRenderer0.getSeriesShape(3);
        boolean boolean10 = statisticalBarRenderer0.getAutoPopulateSeriesOutlineStroke();
        int int11 = statisticalBarRenderer0.getPassCount();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator13 = null;
        statisticalBarRenderer0.setSeriesItemLabelGenerator((int) ' ', categoryItemLabelGenerator13);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer16 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator18 = statisticalBarRenderer16.getSeriesURLGenerator((int) (short) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer19 = null;
        statisticalBarRenderer16.setGradientPaintTransformer(gradientPaintTransformer19);
        java.awt.Paint paint22 = statisticalBarRenderer16.lookupSeriesFillPaint(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition23 = null;
        statisticalBarRenderer16.setNegativeItemLabelPositionFallback(itemLabelPosition23);
        boolean boolean25 = statisticalBarRenderer16.getAutoPopulateSeriesPaint();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer26 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.block.LabelBlock labelBlock29 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D30 = labelBlock29.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity33 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D30, "", "Preceding");
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double35 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D30, rectangleEdge34);
        statisticalBarRenderer26.setBaseShape((java.awt.Shape) rectangle2D30, true);
        boolean boolean38 = statisticalBarRenderer16.equals((java.lang.Object) statisticalBarRenderer26);
        java.awt.Paint paint40 = statisticalBarRenderer26.lookupSeriesFillPaint((int) (byte) 0);
        statisticalBarRenderer0.setSeriesItemLabelPaint(0, paint40, false);
        org.junit.Assert.assertNull(categoryURLGenerator2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(shape9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNull(categoryURLGenerator18);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(rectangleEdge34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(paint40);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryPlot0.getAxisOffset();
        boolean boolean2 = categoryPlot0.isDomainZoomable();
        org.jfree.chart.entity.EntityCollection entityCollection4 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = new org.jfree.chart.ChartRenderingInfo(entityCollection4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = chartRenderingInfo5.getPlotInfo();
        int int7 = plotRenderingInfo6.getSubplotCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.JFreeChart jFreeChart9 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent12 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) categoryPlot8, jFreeChart9, 200, (int) (byte) 0);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor13 = categoryPlot8.getDomainGridlinePosition();
        categoryPlot8.setAnchorValue((double) 900000L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = categoryPlot22.getAxisOffset();
        org.jfree.chart.block.LabelBlock labelBlock26 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D27 = labelBlock26.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity30 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D27, "", "Preceding");
        org.jfree.chart.entity.LegendItemEntity legendItemEntity31 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D27);
        java.awt.geom.Rectangle2D rectangle2D32 = rectangleInsets23.createOutsetRectangle(rectangle2D27);
        java.awt.geom.Point2D point2D33 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(0.0d, (double) 900000L, rectangle2D27);
        categoryPlot8.zoomRangeAxes((double) 3600000L, (double) 0.5f, plotRenderingInfo19, point2D33);
        categoryPlot0.zoomDomainAxes((double) 2958465, plotRenderingInfo6, point2D33);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(categoryAnchor13);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertNotNull(point2D33);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        double double3 = numberAxis2.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D7 = labelBlock6.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity10 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D7, "", "Preceding");
        numberAxis2.setDownArrow((java.awt.Shape) rectangle2D7);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = numberAxis2.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        double double14 = numberAxis13.getUpperBound();
        boolean boolean15 = numberAxis13.getAutoRangeStickyZero();
        boolean boolean16 = numberAxis13.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis13, xYItemRenderer17);
        xYPlot18.setRangeCrosshairVisible(false);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("WMAP_Plot", (org.jfree.chart.plot.Plot) xYPlot18);
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle();
        jFreeChart21.addSubtitle((org.jfree.chart.title.Title) textTitle22);
        org.jfree.chart.title.TextTitle textTitle24 = new org.jfree.chart.title.TextTitle();
        boolean boolean25 = textTitle24.getExpandToFitSpace();
        jFreeChart21.setTitle(textTitle24);
        java.awt.Paint paint27 = textTitle24.getPaint();
        java.lang.String str28 = textTitle24.getText();
        boolean boolean29 = textTitle24.getExpandToFitSpace();
        double double30 = textTitle24.getContentYOffset();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "" + "'", str28.equals(""));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D3 = labelBlock2.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity6 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D3, "", "Preceding");
        org.jfree.chart.entity.LegendItemEntity legendItemEntity7 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D3);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint9 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        statisticalBarRenderer8.setBasePaint(paint9);
        org.jfree.chart.title.LegendGraphic legendGraphic11 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape) rectangle2D3, paint9);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = legendGraphic11.getShapeAnchor();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = legendGraphic11.getShapeAnchor();
        java.awt.Paint paint14 = legendGraphic11.getFillPaint();
        legendGraphic11.setShapeOutlineVisible(true);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.block.LabelBlock labelBlock20 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D21 = labelBlock20.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity24 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D21, "", "Preceding");
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double26 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D21, rectangleEdge25);
        try {
            legendGraphic11.draw(graphics2D17, rectangle2D21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertNotNull(rectangleEdge25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot0.setDomainAxisLocation(axisLocation2);
        categoryPlot0.clearRangeMarkers((-1));
        categoryPlot0.clearAnnotations();
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker((double) 500);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = valueMarker8.getLabelOffset();
        categoryPlot0.setAxisOffset(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(rectangleInsets9);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Paint paint3 = lineAndShapeRenderer0.getItemLabelPaint(2019, 8);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D5 = labelBlock4.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity8 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D5, "", "Preceding");
        numberAxis0.setDownArrow((java.awt.Shape) rectangle2D5);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = numberAxis0.getLabelInsets();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
        numberAxis0.setRightArrow(shape12);
        java.awt.Paint paint14 = numberAxis0.getLabelPaint();
        numberAxis0.setLabelURL("First");
        numberAxis0.setLabelAngle((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        statisticalBarRenderer0.setBasePaint(paint1);
        boolean boolean3 = statisticalBarRenderer0.getIncludeBaseInRange();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer4.setSeriesLinesVisible((int) '4', (java.lang.Boolean) true);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor9 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE7;
        org.jfree.chart.text.TextAnchor textAnchor10 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor11 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor9, textAnchor10, textAnchor11, (double) 0L);
        lineAndShapeRenderer4.setSeriesNegativeItemLabelPosition((int) '4', itemLabelPosition13);
        statisticalBarRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition13);
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot18.setRangeCrosshairValue((double) (byte) 1);
        org.jfree.chart.axis.ValueAxis valueAxis21 = categoryPlot18.getRangeAxis();
        categoryPlot18.configureRangeAxes();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo24 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo24);
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState26 = statisticalBarRenderer0.initialise(graphics2D16, rectangle2D17, categoryPlot18, 255, plotRenderingInfo25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(itemLabelAnchor9);
        org.junit.Assert.assertNotNull(textAnchor10);
        org.junit.Assert.assertNotNull(textAnchor11);
        org.junit.Assert.assertNull(valueAxis21);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D6 = labelBlock5.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D6, "", "Preceding");
        numberAxis1.setDownArrow((java.awt.Shape) rectangle2D6);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis1.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        double double13 = numberAxis12.getUpperBound();
        boolean boolean14 = numberAxis12.getAutoRangeStickyZero();
        boolean boolean15 = numberAxis12.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer16);
        xYPlot17.clearDomainAxes();
        java.awt.Color color20 = java.awt.Color.YELLOW;
        xYPlot17.setQuadrantPaint(3, (java.awt.Paint) color20);
        xYPlot17.setOutlineVisible(true);
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = xYPlot17.getDomainAxisEdge(1900);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(rectangleEdge25);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((double) 24234L);
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        org.jfree.chart.renderer.category.AreaRenderer areaRenderer0 = new org.jfree.chart.renderer.category.AreaRenderer();
        org.jfree.chart.renderer.AreaRendererEndType areaRendererEndType1 = org.jfree.chart.renderer.AreaRendererEndType.TAPER;
        areaRenderer0.setEndType(areaRendererEndType1);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        int int4 = segmentedTimeline3.getSegmentsIncluded();
        org.jfree.chart.axis.DateTickUnit dateTickUnit7 = new org.jfree.chart.axis.DateTickUnit(0, 5);
        int int8 = dateTickUnit7.getRollUnit();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month9.previous();
        java.util.Date date11 = month9.getEnd();
        org.jfree.chart.text.TextAnchor textAnchor13 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor14 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor15 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor14, textAnchor15);
        org.jfree.chart.axis.DateTick dateTick18 = new org.jfree.chart.axis.DateTick(date11, "CONTRACT", textAnchor13, textAnchor15, 0.2d);
        java.util.Date date19 = dateTickUnit7.addToDate(date11);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment20 = segmentedTimeline3.getSegment(date19);
        long long22 = segment20.calculateSegmentNumber((long) 2958465);
        boolean boolean23 = areaRendererEndType1.equals((java.lang.Object) 2958465);
        org.junit.Assert.assertNotNull(areaRendererEndType1);
        org.junit.Assert.assertNotNull(segmentedTimeline3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 5 + "'", int4 == 5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(textAnchor13);
        org.junit.Assert.assertNotNull(itemLabelAnchor14);
        org.junit.Assert.assertNotNull(textAnchor15);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(segment20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 25566L + "'", long22 == 25566L);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint3 = piePlot1.getSectionOutlinePaint((java.lang.Comparable) 2019);
        java.lang.Object obj4 = null;
        boolean boolean5 = piePlot1.equals(obj4);
        piePlot1.setIgnoreNullValues(false);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (byte) 1, jFreeChart1);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        chartChangeEvent2.setType(chartChangeEventType3);
        org.jfree.data.general.WaferMapDataset waferMapDataset5 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot6 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset5);
        float float7 = waferMapPlot6.getForegroundAlpha();
        boolean boolean8 = chartChangeEventType3.equals((java.lang.Object) waferMapPlot6);
        java.awt.Stroke stroke9 = null;
        waferMapPlot6.setOutlineStroke(stroke9);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        waferMapPlot6.rendererChanged(rendererChangeEvent11);
        org.junit.Assert.assertNotNull(chartChangeEventType3);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getUpperBound();
        numberAxis1.setTickMarkOutsideLength((float) (-1L));
        numberAxis1.setTickLabelsVisible(true);
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        double double9 = numberAxis8.getUpperBound();
        boolean boolean10 = numberAxis8.getAutoRangeStickyZero();
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        double double12 = numberAxis11.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock15 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D16 = labelBlock15.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity19 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D16, "", "Preceding");
        numberAxis11.setDownArrow((java.awt.Shape) rectangle2D16);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = numberAxis11.getLabelInsets();
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot22.setRangeCrosshairValue((double) (byte) 1);
        org.jfree.chart.axis.ValueAxis valueAxis25 = categoryPlot22.getRangeAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = categoryPlot22.getDomainAxis((int) ' ');
        boolean boolean28 = numberAxis11.hasListener((java.util.EventListener) categoryPlot22);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) numberAxis8, (org.jfree.chart.axis.ValueAxis) numberAxis11, xYItemRenderer29);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = null;
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis11, xYItemRenderer31);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNull(valueAxis25);
        org.junit.Assert.assertNull(categoryAxis27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D3 = labelBlock2.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity6 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D3, "", "Preceding");
        org.jfree.chart.entity.LegendItemEntity legendItemEntity7 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D3);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint9 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        statisticalBarRenderer8.setBasePaint(paint9);
        org.jfree.chart.title.LegendGraphic legendGraphic11 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape) rectangle2D3, paint9);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = legendGraphic11.getShapeAnchor();
        boolean boolean13 = legendGraphic11.isShapeOutlineVisible();
        double double14 = legendGraphic11.getWidth();
        org.junit.Assert.assertNotNull(rectangle2D3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean1 = lineAndShapeRenderer0.getDrawOutlines();
        java.lang.Boolean boolean3 = lineAndShapeRenderer0.getSeriesLinesVisible(5);
        lineAndShapeRenderer0.setBaseLinesVisible(true);
        lineAndShapeRenderer0.setBaseShapesFilled(false);
        java.lang.Boolean boolean9 = lineAndShapeRenderer0.getSeriesItemLabelsVisible((int) ' ');
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator10 = lineAndShapeRenderer0.getLegendItemURLGenerator();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(boolean3);
        org.junit.Assert.assertNull(boolean9);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator10);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        org.jfree.data.time.DateRange dateRange0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double1 = dateRange0.getCentralValue();
        double double2 = dateRange0.getUpperBound();
        java.util.Date date3 = dateRange0.getLowerDate();
        java.util.Date date4 = dateRange0.getUpperDate();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone5;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone5;
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date4, timeZone5);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent9 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) month8);
        org.junit.Assert.assertNotNull(dateRange0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5d + "'", double1 == 0.5d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone5);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 1L, (double) 31);
        boolean boolean4 = stackedBarRenderer3D2.equals((java.lang.Object) (-1.0f));
        stackedBarRenderer3D2.setRenderAsPercentages(true);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier7 = stackedBarRenderer3D2.getDrawingSupplier();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType8 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        boolean boolean9 = stackedBarRenderer3D2.equals((java.lang.Object) gradientPaintTransformType8);
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        double double12 = numberAxis11.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock15 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D16 = labelBlock15.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity19 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D16, "", "Preceding");
        numberAxis11.setDownArrow((java.awt.Shape) rectangle2D16);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = numberAxis11.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        double double23 = numberAxis22.getUpperBound();
        boolean boolean24 = numberAxis22.getAutoRangeStickyZero();
        boolean boolean25 = numberAxis22.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot(xYDataset10, (org.jfree.chart.axis.ValueAxis) numberAxis11, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer26);
        org.jfree.data.xy.XYDataset xYDataset28 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = xYPlot27.getRendererForDataset(xYDataset28);
        boolean boolean30 = gradientPaintTransformType8.equals((java.lang.Object) xYDataset28);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(drawingSupplier7);
        org.junit.Assert.assertNotNull(gradientPaintTransformType8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNull(xYItemRenderer29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairValue((double) (byte) 1);
        org.jfree.chart.axis.ValueAxis valueAxis4 = categoryPlot0.getRangeAxisForDataset((int) (byte) 1);
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis(31);
        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot0.getRangeAxisLocation();
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(axisLocation7);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator2 = piePlot1.getToolTipGenerator();
        java.awt.Font font3 = piePlot1.getLabelFont();
        java.awt.Stroke stroke5 = piePlot1.getSectionOutlineStroke((java.lang.Comparable) 0L);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        double double8 = numberAxis7.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock11 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D12 = labelBlock11.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity15 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D12, "", "Preceding");
        numberAxis7.setDownArrow((java.awt.Shape) rectangle2D12);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = numberAxis7.getLabelInsets();
        numberAxis7.setVerticalTickLabels(true);
        java.awt.Stroke stroke20 = numberAxis7.getAxisLineStroke();
        piePlot1.setSectionOutlineStroke((java.lang.Comparable) "({0}, {1}) = {2}", stroke20);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator22 = piePlot1.getLegendLabelURLGenerator();
        java.awt.Shape shape23 = piePlot1.getLegendItemShape();
        piePlot1.setIgnoreNullValues(true);
        org.junit.Assert.assertNull(pieToolTipGenerator2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNull(pieURLGenerator22);
        org.junit.Assert.assertNotNull(shape23);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setSeriesLinesVisible((int) '4', (java.lang.Boolean) true);
        lineAndShapeRenderer0.setBaseCreateEntities(true);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj1 = textTitle0.clone();
        java.awt.Paint paint2 = textTitle0.getPaint();
        textTitle0.setID("XY Plot");
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        long long2 = month0.getFirstMillisecond();
        java.util.Calendar calendar3 = null;
        try {
            month0.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1559372400000L + "'", long2 == 1559372400000L);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month1.previous();
        org.jfree.data.time.Year year3 = month1.getYear();
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        double double6 = numberAxis5.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock9 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D10 = labelBlock9.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity13 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D10, "", "Preceding");
        numberAxis5.setDownArrow((java.awt.Shape) rectangle2D10);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = numberAxis5.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis();
        double double17 = numberAxis16.getUpperBound();
        boolean boolean18 = numberAxis16.getAutoRangeStickyZero();
        boolean boolean19 = numberAxis16.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset4, (org.jfree.chart.axis.ValueAxis) numberAxis5, (org.jfree.chart.axis.ValueAxis) numberAxis16, xYItemRenderer20);
        boolean boolean22 = xYPlot21.isDomainCrosshairVisible();
        org.jfree.chart.axis.AxisLocation axisLocation24 = xYPlot21.getRangeAxisLocation((int) (short) -1);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer25 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke26 = statisticalBarRenderer25.getBaseStroke();
        xYPlot21.setDomainZeroBaselineStroke(stroke26);
        int int28 = year3.compareTo((java.lang.Object) stroke26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year3.previous();
        org.jfree.chart.util.ObjectList objectList30 = new org.jfree.chart.util.ObjectList();
        keyedObjects0.addObject((java.lang.Comparable) year3, (java.lang.Object) objectList30);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
    }
}

