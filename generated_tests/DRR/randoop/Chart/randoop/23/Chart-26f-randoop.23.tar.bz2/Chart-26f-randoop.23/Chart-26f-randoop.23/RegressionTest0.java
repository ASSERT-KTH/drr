import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.jfree.chart.plot.Plot plot0 = null;
        try {
            org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent(plot0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        java.lang.ClassLoader classLoader0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
        org.junit.Assert.assertNull(classLoader0);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name , locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(1, (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        java.lang.String str0 = org.jfree.chart.labels.IntervalCategoryToolTipGenerator.DEFAULT_TOOL_TIP_FORMAT_STRING;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "({0}, {1}) = {3} - {4}" + "'", str0.equals("({0}, {1}) = {3} - {4}"));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        java.lang.String str0 = org.jfree.chart.labels.StandardCategoryToolTipGenerator.DEFAULT_TOOL_TIP_FORMAT_STRING;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "({0}, {1}) = {2}" + "'", str0.equals("({0}, {1}) = {2}"));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        boolean boolean2 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) (short) 10, (java.lang.Object) 10L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_TICK_UNIT_SELECTION;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D2 = labelBlock1.getBounds();
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D2);
        java.lang.Object obj4 = chartEntity3.clone();
        org.junit.Assert.assertNotNull(rectangle2D2);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.geom.Point2D point2D1 = org.jfree.chart.util.SerialUtilities.readPoint2D(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D3 = labelBlock2.getBounds();
        try {
            org.jfree.chart.util.ShapeUtilities.drawRotatedShape(graphics2D0, (java.awt.Shape) rectangle2D3, (double) (short) 1, (float) (byte) 10, (float) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D3);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("({0}, {1}) = {2}", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE6;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        java.util.TimeZone timeZone0 = null;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone0;
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        int int0 = org.jfree.chart.axis.DateTickUnit.SECOND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((-1));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Preceding" + "'", str1.equals("Preceding"));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addYears((int) '4', serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = null;
        try {
            statisticalBarRenderer0.setBaseStroke(stroke1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.25d + "'", double0 == 0.25d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE5;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = statisticalBarRenderer0.getSeriesURLGenerator((int) (short) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        statisticalBarRenderer0.setGradientPaintTransformer(gradientPaintTransformer3);
        org.jfree.chart.event.RendererChangeListener rendererChangeListener5 = null;
        try {
            statisticalBarRenderer0.addChangeListener(rendererChangeListener5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryURLGenerator2);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        java.lang.Class class0 = null;
        try {
            boolean boolean1 = org.jfree.chart.util.SerialUtilities.isSerializable(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_START_ANGLE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 90.0d + "'", double0 == 90.0d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE1;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range1 = numberAxis0.getDefaultAutoRange();
        boolean boolean3 = numberAxis0.equals((java.lang.Object) (byte) -1);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit4 = null;
        try {
            numberAxis0.setTickUnit(numberTickUnit4, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unit' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.data.time.DateRange dateRange0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double1 = dateRange0.getCentralValue();
        org.jfree.data.time.DateRange dateRange2 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double3 = dateRange2.getCentralValue();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange0, (org.jfree.data.Range) dateRange2);
        java.lang.String str5 = rectangleConstraint4.toString();
        org.junit.Assert.assertNotNull(dateRange0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5d + "'", double1 == 0.5d);
        org.junit.Assert.assertNotNull(dateRange2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.5d + "'", double3 == 0.5d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]" + "'", str5.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]"));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        java.util.Date date1 = null;
        java.util.Date date2 = null;
        try {
            org.jfree.data.gantt.Task task3 = new org.jfree.data.gantt.Task("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", date1, date2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (short) 10, (int) '4', (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        java.text.DateFormatSymbols dateFormatSymbols0 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        org.junit.Assert.assertNotNull(dateFormatSymbols0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.labels.IntervalCategoryToolTipGenerator intervalCategoryToolTipGenerator2 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        java.awt.Color color0 = java.awt.Color.orange;
        float[] floatArray1 = new float[] {};
        try {
            float[] floatArray2 = color0.getComponents(floatArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray1);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.HOUR_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 3600000L + "'", long0 == 3600000L);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("hi!", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = statisticalBarRenderer1.getSeriesURLGenerator((int) (short) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer4 = null;
        statisticalBarRenderer1.setGradientPaintTransformer(gradientPaintTransformer4);
        java.awt.Paint paint8 = statisticalBarRenderer1.getItemPaint((int) (byte) 100, (int) '#');
        java.awt.Stroke stroke9 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer10 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint11 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        statisticalBarRenderer10.setBasePaint(paint11);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer13 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke14 = statisticalBarRenderer13.getBaseStroke();
        try {
            org.jfree.chart.plot.CategoryMarker categoryMarker16 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100L, paint8, stroke9, paint11, stroke14, (float) 3600000L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D5 = labelBlock4.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity8 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D5, "", "Preceding");
        numberAxis0.setDownArrow((java.awt.Shape) rectangle2D5);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = numberAxis0.getLabelInsets();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
        numberAxis0.setRightArrow(shape12);
        boolean boolean14 = numberAxis0.isNegativeArrowVisible();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = statisticalBarRenderer0.getSeriesURLGenerator((int) (short) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        statisticalBarRenderer0.setGradientPaintTransformer(gradientPaintTransformer3);
        java.awt.Paint paint6 = statisticalBarRenderer0.lookupSeriesFillPaint(0);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        statisticalBarRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator7, true);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = null;
        org.jfree.chart.block.LabelBlock labelBlock13 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D14 = labelBlock13.getBounds();
        org.jfree.chart.entity.ChartEntity chartEntity15 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D14);
        try {
            statisticalBarRenderer0.drawDomainGridline(graphics2D10, categoryPlot11, rectangle2D14, (double) 3600000L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryURLGenerator2);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(rectangle2D14);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        java.awt.Paint paint2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke4 = statisticalBarRenderer3.getBaseStroke();
        java.awt.Paint paint5 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        java.awt.Stroke stroke6 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        try {
            org.jfree.chart.plot.IntervalMarker intervalMarker8 = new org.jfree.chart.plot.IntervalMarker((double) 1, (double) 10L, paint2, stroke4, paint5, stroke6, (float) 31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D5 = labelBlock4.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity8 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D5, "", "Preceding");
        numberAxis0.setDownArrow((java.awt.Shape) rectangle2D5);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = numberAxis0.getLabelInsets();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
        numberAxis0.setRightArrow(shape12);
        numberAxis0.setAutoTickUnitSelection(false, false);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(shape12);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        java.awt.Color color1 = java.awt.Color.getColor("");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        java.awt.Color color1 = java.awt.Color.getColor("hi!");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("({0}, {1}) = {3} - {4}", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        int int0 = org.jfree.chart.axis.DateTickUnit.MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        int int0 = org.jfree.data.time.SerialDate.THIRD_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(31, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        java.awt.Font font0 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        java.awt.Color color0 = java.awt.Color.orange;
        java.awt.color.ColorSpace colorSpace1 = null;
        float[] floatArray2 = null;
        try {
            float[] floatArray3 = color0.getColorComponents(colorSpace1, floatArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        try {
            java.lang.Number number4 = taskSeriesCollection0.getStartValue((java.lang.Comparable) 0.25d, (java.lang.Comparable) 31, 200);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.data.function.Function2D function2D0 = null;
        try {
            org.jfree.data.xy.XYDataset xYDataset5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, (double) 10L, (double) 0.0f, 9, (java.lang.Comparable) (-1.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint1 = statisticalBarRenderer0.getBaseOutlinePaint();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = null;
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D7 = labelBlock6.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity10 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D7, "", "Preceding");
        org.jfree.chart.entity.LegendItemEntity legendItemEntity11 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D7);
        try {
            statisticalBarRenderer0.drawDomainGridline(graphics2D2, categoryPlot3, rectangle2D7, (double) 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(rectangle2D7);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) -1);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        try {
            taskSeriesCollection0.remove((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: TaskSeriesCollection.remove(): index outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_DOMAIN_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D7 = labelBlock6.getBounds();
        org.jfree.chart.entity.ChartEntity chartEntity8 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D7);
        java.awt.Paint paint10 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        java.awt.Color color12 = java.awt.Color.orange;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer13 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke14 = statisticalBarRenderer13.getBaseStroke();
        org.jfree.data.general.WaferMapDataset waferMapDataset16 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot17 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset16);
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.block.LabelBlock labelBlock21 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D22 = labelBlock21.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity25 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D22, "", "Preceding");
        waferMapPlot17.drawBackgroundImage(graphics2D18, rectangle2D22);
        java.awt.Stroke stroke27 = null;
        org.jfree.data.general.WaferMapDataset waferMapDataset28 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot29 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset28);
        float float30 = waferMapPlot29.getForegroundAlpha();
        java.awt.Color color31 = java.awt.Color.orange;
        waferMapPlot29.setNoDataMessagePaint((java.awt.Paint) color31);
        try {
            org.jfree.chart.LegendItem legendItem33 = new org.jfree.chart.LegendItem("({0}, {1}) = {3} - {4}", "Preceding", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, (java.awt.Shape) rectangle2D7, false, paint10, true, (java.awt.Paint) color12, stroke14, false, (java.awt.Shape) rectangle2D22, stroke27, (java.awt.Paint) color31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'lineStroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 1.0f + "'", float30 == 1.0f);
        org.junit.Assert.assertNotNull(color31);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = null;
        taskSeriesCollection0.seriesChanged(seriesChangeEvent1);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        long long5 = month4.getLastMillisecond();
        try {
            java.lang.Number number7 = taskSeriesCollection0.getPercentComplete((java.lang.Comparable) "Preceding", (java.lang.Comparable) long5, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1561964399999L + "'", long5 == 1561964399999L);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.data.time.DateRange dateRange0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double1 = dateRange0.getCentralValue();
        org.jfree.data.time.DateRange dateRange2 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double3 = dateRange2.getCentralValue();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange0, (org.jfree.data.Range) dateRange2);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = rectangleConstraint4.toFixedHeight((double) 10.0f);
        double double7 = rectangleConstraint6.getWidth();
        org.junit.Assert.assertNotNull(dateRange0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5d + "'", double1 == 0.5d);
        org.junit.Assert.assertNotNull(dateRange2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.5d + "'", double3 == 0.5d);
        org.junit.Assert.assertNotNull(rectangleConstraint6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.END;
        org.junit.Assert.assertNotNull(categoryAnchor0);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        java.lang.Object obj0 = null;
        boolean boolean2 = org.jfree.chart.util.ObjectUtilities.equal(obj0, (java.lang.Object) 100.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(200);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        projectInfo0.setCopyright("");
        java.lang.String str3 = projectInfo0.getCopyright();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        double double0 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_X_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 12.0d + "'", double0 == 12.0d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("WMAP_Plot", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D5 = labelBlock4.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity8 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D5, "", "Preceding");
        numberAxis0.setDownArrow((java.awt.Shape) rectangle2D5);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = numberAxis0.getLabelInsets();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
        numberAxis0.setRightArrow(shape12);
        double double14 = numberAxis0.getUpperBound();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        java.util.Date date1 = null;
        java.util.Date date2 = null;
        try {
            org.jfree.data.gantt.Task task3 = new org.jfree.data.gantt.Task("", date1, date2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = statisticalBarRenderer0.getSeriesURLGenerator((int) (short) 100);
        int int3 = statisticalBarRenderer0.getColumnCount();
        double double4 = statisticalBarRenderer0.getItemMargin();
        java.lang.Boolean boolean6 = statisticalBarRenderer0.getSeriesItemLabelsVisible(200);
        org.junit.Assert.assertNull(categoryURLGenerator2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2d + "'", double4 == 0.2d);
        org.junit.Assert.assertNull(boolean6);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE2;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        java.awt.Color color0 = java.awt.Color.DARK_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-8d + "'", double0 == 1.0E-8d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.LEFT;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) '4', (double) (byte) -1, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor3);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.MIDDLE;
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D5 = labelBlock4.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity8 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D5, "", "Preceding");
        numberAxis0.setDownArrow((java.awt.Shape) rectangle2D5);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = numberAxis0.getLabelInsets();
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D14 = rectangleInsets10.createOutsetRectangle(rectangle2D11, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNotNull(rectangleInsets10);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        try {
            categoryPlot0.setRangeAxisLocation((int) (short) 0, axisLocation3, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setRangeCrosshairValue((double) (byte) 1);
        org.jfree.chart.axis.ValueAxis valueAxis5 = categoryPlot2.getRangeAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = categoryPlot2.getDomainAxis((int) ' ');
        org.jfree.chart.block.LabelBlock labelBlock9 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D10 = labelBlock9.getBounds();
        org.jfree.chart.entity.ChartEntity chartEntity11 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D10);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = org.jfree.chart.util.RectangleEdge.LEFT;
        boolean boolean13 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge12);
        org.jfree.chart.axis.AxisSpace axisSpace14 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace15 = categoryAxis0.reserveSpace(graphics2D1, (org.jfree.chart.plot.Plot) categoryPlot2, rectangle2D10, rectangleEdge12, axisSpace14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNull(categoryAxis7);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D2 = labelBlock1.getBounds();
        boolean boolean4 = labelBlock1.equals((java.lang.Object) 1);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.block.LabelBlock labelBlock7 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D8 = labelBlock7.getBounds();
        org.jfree.chart.entity.ChartEntity chartEntity9 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D8);
        java.lang.Object obj10 = null;
        try {
            java.lang.Object obj11 = labelBlock1.draw(graphics2D5, rectangle2D8, obj10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(rectangle2D8);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(2019);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2019");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        java.awt.Font font1 = null;
        try {
            org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("hi!", font1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        try {
            java.lang.Number number4 = taskSeriesCollection0.getStartValue(0, 3, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        int int0 = org.jfree.data.time.SerialDate.SECOND_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        int int0 = org.jfree.chart.axis.DateTickUnit.YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        int int0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALIGNMENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(3);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        boolean boolean0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        try {
            java.lang.Number number4 = taskSeriesCollection0.getEndValue((java.lang.Comparable) 10, (java.lang.Comparable) (byte) 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D3 = labelBlock2.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity6 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D3, "", "Preceding");
        org.jfree.chart.entity.LegendItemEntity legendItemEntity7 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D3);
        java.lang.Comparable comparable8 = legendItemEntity7.getSeriesKey();
        java.lang.String str9 = legendItemEntity7.getURLText();
        org.junit.Assert.assertNotNull(rectangle2D3);
        org.junit.Assert.assertNull(comparable8);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("({0}, {1}) = {3} - {4}", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) categoryPlot0, jFreeChart1, 200, (int) (byte) 0);
        org.jfree.chart.JFreeChart jFreeChart5 = chartProgressEvent4.getChart();
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        chartProgressEvent4.setChart(jFreeChart6);
        org.junit.Assert.assertNull(jFreeChart5);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge((int) (short) 0);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(rectangleEdge3);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        boolean boolean0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        try {
            java.lang.Number number3 = taskSeriesCollection0.getValue((int) (short) 10, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(1);
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        double double3 = numberAxis2.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D7 = labelBlock6.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity10 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D7, "", "Preceding");
        numberAxis2.setDownArrow((java.awt.Shape) rectangle2D7);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = numberAxis2.getLabelInsets();
        numberAxis2.setVerticalTickLabels(true);
        double[] doubleArray19 = new double[] { (-1L), 0.0d };
        double[] doubleArray22 = new double[] { (-1L), 0.0d };
        double[] doubleArray25 = new double[] { (-1L), 0.0d };
        double[] doubleArray28 = new double[] { (-1L), 0.0d };
        double[][] doubleArray29 = new double[][] { doubleArray19, doubleArray22, doubleArray25, doubleArray28 };
        org.jfree.data.category.CategoryDataset categoryDataset30 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", doubleArray29);
        org.jfree.data.Range range31 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset30);
        numberAxis2.setRangeWithMargins(range31, false, true);
        int int35 = objectList1.indexOf((java.lang.Object) true);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(categoryDataset30);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLowerMargin((double) 10.0f);
        org.jfree.data.general.WaferMapDataset waferMapDataset3 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot4 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset3);
        float float5 = waferMapPlot4.getForegroundAlpha();
        java.lang.String str6 = waferMapPlot4.getPlotType();
        boolean boolean7 = categoryAxis0.equals((java.lang.Object) str6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.block.LabelBlock labelBlock11 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D12 = labelBlock11.getBounds();
        org.jfree.chart.block.LabelBlock labelBlock15 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D16 = labelBlock15.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity19 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D16, "", "Preceding");
        org.jfree.chart.entity.LegendItemEntity legendItemEntity20 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D16);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer21 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint22 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        statisticalBarRenderer21.setBasePaint(paint22);
        org.jfree.chart.title.LegendGraphic legendGraphic24 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape) rectangle2D16, paint22);
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        try {
            org.jfree.chart.axis.AxisState axisState27 = categoryAxis0.draw(graphics2D8, 0.0d, rectangle2D12, rectangle2D16, rectangleEdge25, plotRenderingInfo26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 1.0f + "'", float5 == 1.0f);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "WMAP_Plot" + "'", str6.equals("WMAP_Plot"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(rectangleEdge25);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.FIFTEEN_MINUTE_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 900000L + "'", long0 == 900000L);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        int int0 = org.jfree.data.time.SerialDate.FIRST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("hi!", graphics2D1, 10.0f, (float) 3, textAnchor4, (double) 9, (float) 10, (float) 900000L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        java.lang.ClassLoader classLoader0 = null;
        try {
            java.util.ResourceBundle.clearCache(classLoader0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("({0}, {1}) = {3} - {4}");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name ({0}, {1}) = {3} - {4}, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("({0}, {1}) = {2}", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        double[] doubleArray4 = new double[] { (-1L), 0.0d };
        double[] doubleArray7 = new double[] { (-1L), 0.0d };
        double[] doubleArray10 = new double[] { (-1L), 0.0d };
        double[] doubleArray13 = new double[] { (-1L), 0.0d };
        double[][] doubleArray14 = new double[][] { doubleArray4, doubleArray7, doubleArray10, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", doubleArray14);
        try {
            org.jfree.data.general.PieDataset pieDataset17 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset15, (java.lang.Comparable) 90.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        java.lang.Object obj0 = null;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        try {
            org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent(obj0, jFreeChart1, 2, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        try {
            defaultCategoryDataset0.removeRow((java.lang.Comparable) 100.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        float[] floatArray3 = new float[] {};
        try {
            float[] floatArray4 = java.awt.Color.RGBtoHSB(9, 15, 2, floatArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray3);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE1;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = null;
        taskSeriesCollection0.seriesChanged(seriesChangeEvent1);
        int int4 = taskSeriesCollection0.indexOf((java.lang.Comparable) (-1L));
        try {
            taskSeriesCollection0.remove(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: TaskSeriesCollection.remove(): index outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = null;
        taskSeriesCollection0.seriesChanged(seriesChangeEvent1);
        try {
            java.lang.Number number6 = taskSeriesCollection0.getStartValue(15, 9, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 15, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.chart.title.Title title0 = null;
        try {
            org.jfree.chart.event.TitleChangeEvent titleChangeEvent1 = new org.jfree.chart.event.TitleChangeEvent(title0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_45;
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        try {
            java.lang.Number number3 = taskSeriesCollection0.getStartValue((java.lang.Comparable) "hi!", (java.lang.Comparable) 1.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setSeriesLinesVisible((int) '4', (java.lang.Boolean) true);
        try {
            lineAndShapeRenderer0.setSeriesShapesVisible((-1), (java.lang.Boolean) false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) (short) 1);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "First" + "'", str1.equals("First"));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 1L, (double) 31);
        java.awt.Font font3 = null;
        try {
            stackedBarRenderer3D2.setBaseItemLabelFont(font3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getUpperBound();
        boolean boolean2 = numberAxis0.getAutoRangeStickyZero();
        boolean boolean3 = numberAxis0.isAutoRange();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis0.setMarkerBand(markerAxisBand4);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairValue((double) (byte) 1);
        org.jfree.chart.axis.ValueAxis valueAxis4 = categoryPlot0.getRangeAxisForDataset((int) (byte) 1);
        categoryPlot0.setRangeGridlinesVisible(true);
        org.junit.Assert.assertNull(valueAxis4);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D5 = labelBlock4.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity8 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D5, "", "Preceding");
        numberAxis0.setDownArrow((java.awt.Shape) rectangle2D5);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = numberAxis0.getLabelInsets();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot11.setRangeCrosshairValue((double) (byte) 1);
        org.jfree.chart.axis.ValueAxis valueAxis14 = categoryPlot11.getRangeAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = categoryPlot11.getDomainAxis((int) ' ');
        boolean boolean17 = numberAxis0.hasListener((java.util.EventListener) categoryPlot11);
        java.lang.String str18 = numberAxis0.getLabelToolTip();
        double[] doubleArray23 = new double[] { (-1L), 0.0d };
        double[] doubleArray26 = new double[] { (-1L), 0.0d };
        double[] doubleArray29 = new double[] { (-1L), 0.0d };
        double[] doubleArray32 = new double[] { (-1L), 0.0d };
        double[][] doubleArray33 = new double[][] { doubleArray23, doubleArray26, doubleArray29, doubleArray32 };
        org.jfree.data.category.CategoryDataset categoryDataset34 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", doubleArray33);
        org.jfree.data.Range range35 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset34);
        numberAxis0.setDefaultAutoRange(range35);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNull(valueAxis14);
        org.junit.Assert.assertNull(categoryAxis16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(categoryDataset34);
        org.junit.Assert.assertNotNull(range35);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(1);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor2 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE7;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor2, textAnchor3, textAnchor4, (double) 0L);
        boolean boolean7 = objectList1.equals((java.lang.Object) itemLabelAnchor2);
        org.junit.Assert.assertNotNull(itemLabelAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        double double0 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_Y_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 8.0d + "'", double0 == 8.0d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        int int0 = org.jfree.data.time.SerialDate.LAST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D5 = labelBlock4.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity8 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D5, "", "Preceding");
        numberAxis0.setDownArrow((java.awt.Shape) rectangle2D5);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = numberAxis0.getLabelInsets();
        boolean boolean11 = numberAxis0.isVerticalTickLabels();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = categoryPlot14.getAxisOffset();
        org.jfree.chart.block.LabelBlock labelBlock18 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D19 = labelBlock18.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity22 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D19, "", "Preceding");
        org.jfree.chart.entity.LegendItemEntity legendItemEntity23 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D19);
        java.awt.geom.Rectangle2D rectangle2D24 = rectangleInsets15.createOutsetRectangle(rectangle2D19);
        org.jfree.chart.block.LabelBlock labelBlock26 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D27 = labelBlock26.getBounds();
        org.jfree.chart.entity.ChartEntity chartEntity28 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D27);
        org.jfree.chart.entity.ChartEntity chartEntity29 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D27);
        org.jfree.chart.block.LabelBlock labelBlock32 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D33 = labelBlock32.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity36 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D33, "", "Preceding");
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double38 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D33, rectangleEdge37);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        try {
            org.jfree.chart.axis.AxisState axisState40 = numberAxis0.draw(graphics2D12, (double) 2, rectangle2D24, rectangle2D27, rectangleEdge37, plotRenderingInfo39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertNotNull(rectangle2D33);
        org.junit.Assert.assertNotNull(rectangleEdge37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_BOTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        axisState0.cursorRight(0.0d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 9);
        java.io.ObjectOutputStream objectOutputStream2 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeShape(shape1, objectOutputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D2 = labelBlock1.getBounds();
        labelBlock1.setPadding(1.0d, 10.0d, (double) 10L, (double) (-1));
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryPlot9.getAxisOffset();
        org.jfree.chart.block.LabelBlock labelBlock13 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D14 = labelBlock13.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity17 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D14, "", "Preceding");
        org.jfree.chart.entity.LegendItemEntity legendItemEntity18 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D14);
        java.awt.geom.Rectangle2D rectangle2D19 = rectangleInsets10.createOutsetRectangle(rectangle2D14);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer20 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator22 = statisticalBarRenderer20.getSeriesURLGenerator((int) (short) 100);
        int int23 = statisticalBarRenderer20.getColumnCount();
        boolean boolean25 = statisticalBarRenderer20.isSeriesVisibleInLegend(0);
        java.awt.Paint paint27 = null;
        statisticalBarRenderer20.setSeriesFillPaint(3, paint27);
        try {
            java.lang.Object obj29 = labelBlock1.draw(graphics2D8, rectangle2D19, (java.lang.Object) paint27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D2);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNull(categoryURLGenerator22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            double double1 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        float float0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.5f + "'", float0 == 0.5f);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.BAR_OUTLINE_WIDTH_THRESHOLD;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.0d + "'", double0 == 3.0d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D6 = labelBlock5.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D6, "", "Preceding");
        numberAxis1.setDownArrow((java.awt.Shape) rectangle2D6);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis1.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        double double13 = numberAxis12.getUpperBound();
        boolean boolean14 = numberAxis12.getAutoRangeStickyZero();
        boolean boolean15 = numberAxis12.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer16);
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = xYPlot17.getRendererForDataset(xYDataset18);
        org.jfree.chart.axis.AxisSpace axisSpace20 = xYPlot17.getFixedDomainAxisSpace();
        org.jfree.chart.plot.Marker marker22 = null;
        org.jfree.chart.util.Layer layer23 = null;
        try {
            xYPlot17.addRangeMarker(3, marker22, layer23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(xYItemRenderer19);
        org.junit.Assert.assertNull(axisSpace20);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        java.awt.Color color0 = java.awt.Color.blue;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        double[] doubleArray6 = new double[] { (-1L), 0.0d };
        double[] doubleArray9 = new double[] { (-1L), 0.0d };
        double[] doubleArray12 = new double[] { (-1L), 0.0d };
        double[] doubleArray15 = new double[] { (-1L), 0.0d };
        double[][] doubleArray16 = new double[][] { doubleArray6, doubleArray9, doubleArray12, doubleArray15 };
        org.jfree.data.category.CategoryDataset categoryDataset17 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", doubleArray16);
        org.jfree.data.category.CategoryDataset categoryDataset18 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray16);
        double[] doubleArray25 = new double[] { (-1L), 0.0d };
        double[] doubleArray28 = new double[] { (-1L), 0.0d };
        double[] doubleArray31 = new double[] { (-1L), 0.0d };
        double[] doubleArray34 = new double[] { (-1L), 0.0d };
        double[][] doubleArray35 = new double[][] { doubleArray25, doubleArray28, doubleArray31, doubleArray34 };
        org.jfree.data.category.CategoryDataset categoryDataset36 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", doubleArray35);
        org.jfree.data.category.CategoryDataset categoryDataset37 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray35);
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset38 = new org.jfree.data.category.DefaultIntervalCategoryDataset(doubleArray16, doubleArray35);
        java.lang.Comparable[] comparableArray40 = new java.lang.Comparable[] { ' ' };
        try {
            defaultIntervalCategoryDataset38.setSeriesKeys(comparableArray40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of series keys does not match the data.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(categoryDataset17);
        org.junit.Assert.assertNotNull(categoryDataset18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(categoryDataset36);
        org.junit.Assert.assertNotNull(categoryDataset37);
        org.junit.Assert.assertNotNull(comparableArray40);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.labels.IntervalCategoryToolTipGenerator intervalCategoryToolTipGenerator2 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator("rect", numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D3 = labelBlock2.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity6 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D3, "", "Preceding");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer7 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = statisticalBarRenderer7.getSeriesURLGenerator((int) (short) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer10 = null;
        statisticalBarRenderer7.setGradientPaintTransformer(gradientPaintTransformer10);
        java.awt.Paint paint13 = statisticalBarRenderer7.lookupSeriesFillPaint(0);
        boolean boolean14 = categoryLabelEntity6.equals((java.lang.Object) statisticalBarRenderer7);
        java.lang.String str15 = categoryLabelEntity6.toString();
        org.junit.Assert.assertNotNull(rectangle2D3);
        org.junit.Assert.assertNull(categoryURLGenerator9);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "CategoryLabelEntity: category=false, tooltip=, url=Preceding" + "'", str15.equals("CategoryLabelEntity: category=false, tooltip=, url=Preceding"));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = null;
        taskSeriesCollection0.seriesChanged(seriesChangeEvent1);
        org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, 9);
        try {
            java.lang.Number number7 = taskSeriesCollection0.getPercentComplete(100, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(pieDataset4);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator2 = piePlot1.getToolTipGenerator();
        java.awt.Font font3 = piePlot1.getLabelFont();
        java.awt.Stroke stroke5 = piePlot1.getSectionOutlineStroke((java.lang.Comparable) 0L);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor6 = null;
        try {
            piePlot1.setLabelDistributor(abstractPieLabelDistributor6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'distributor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(pieToolTipGenerator2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNull(stroke5);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        boolean boolean1 = textTitle0.getExpandToFitSpace();
        textTitle0.setNotify(false);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.data.time.DateRange dateRange5 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double6 = dateRange5.getCentralValue();
        org.jfree.data.time.DateRange dateRange7 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double8 = dateRange7.getCentralValue();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange5, (org.jfree.data.Range) dateRange7);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = rectangleConstraint9.toFixedHeight((double) 10.0f);
        try {
            org.jfree.chart.util.Size2D size2D12 = textTitle0.arrange(graphics2D4, rectangleConstraint9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateRange5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.5d + "'", double6 == 0.5d);
        org.junit.Assert.assertNotNull(dateRange7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.5d + "'", double8 == 0.5d);
        org.junit.Assert.assertNotNull(rectangleConstraint11);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D6 = labelBlock5.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D6, "", "Preceding");
        numberAxis1.setDownArrow((java.awt.Shape) rectangle2D6);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis1.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        double double13 = numberAxis12.getUpperBound();
        boolean boolean14 = numberAxis12.getAutoRangeStickyZero();
        boolean boolean15 = numberAxis12.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer16);
        org.jfree.chart.axis.AxisSpace axisSpace18 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = org.jfree.chart.util.RectangleEdge.LEFT;
        axisSpace18.ensureAtLeast((double) ' ', rectangleEdge20);
        xYPlot17.setFixedDomainAxisSpace(axisSpace18);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis24 = xYPlot17.getDomainAxisForDataset((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 'index' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(rectangleEdge20);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.lang.Object obj1 = barRenderer0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("");
        labelBlock1.setPadding(0.0d, (double) 'a', (double) (byte) 10, 100.0d);
        double double7 = labelBlock1.getHeight();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_STARTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getUpperBound();
        boolean boolean2 = numberAxis0.getAutoRangeStickyZero();
        boolean boolean3 = numberAxis0.isAutoRange();
        float float4 = numberAxis0.getTickMarkInsideLength();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairValue((double) (byte) 1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        categoryPlot0.setRangeCrosshairValue((double) '#');
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = null;
        org.jfree.chart.util.Layer layer8 = null;
        try {
            categoryPlot0.addDomainMarker((int) (byte) 0, categoryMarker7, layer8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset0, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator2 = piePlot1.getToolTipGenerator();
        double double3 = piePlot1.getMaximumLabelWidth();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D7 = labelBlock6.getBounds();
        org.jfree.chart.plot.PiePlot piePlot8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        try {
            org.jfree.chart.plot.PiePlotState piePlotState11 = piePlot1.initialise(graphics2D4, rectangle2D7, piePlot8, (java.lang.Integer) 3, plotRenderingInfo10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(pieToolTipGenerator2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertNotNull(rectangle2D7);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        java.awt.Color color0 = java.awt.Color.orange;
        int int1 = color0.getGreen();
        float[] floatArray7 = new float[] { (short) 0, 10.0f, (short) 10, (byte) 0, 0.0f };
        float[] floatArray8 = color0.getColorComponents(floatArray7);
        org.jfree.chart.JFreeChart jFreeChart10 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent11 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (byte) 1, jFreeChart10);
        org.jfree.chart.JFreeChart jFreeChart12 = null;
        chartChangeEvent11.setChart(jFreeChart12);
        boolean boolean14 = color0.equals((java.lang.Object) jFreeChart12);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 200 + "'", int1 == 200);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("CategoryLabelEntity: category=false, tooltip=, url=Preceding");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint1 = statisticalBarRenderer0.getBaseOutlinePaint();
        java.awt.Color color2 = java.awt.Color.GRAY;
        boolean boolean3 = org.jfree.chart.util.PaintUtilities.equal(paint1, (java.awt.Paint) color2);
        int int4 = color2.getRed();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 128 + "'", int4 == 128);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = null;
        taskSeriesCollection0.seriesChanged(seriesChangeEvent1);
        java.lang.Number number3 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        try {
            java.lang.Comparable comparable5 = taskSeriesCollection0.getRowKey(128);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 128, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0.0d + "'", number3.equals(0.0d));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        int int0 = org.jfree.chart.axis.ValueAxis.MAXIMUM_TICK_COUNT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 500 + "'", int0 == 500);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = statisticalBarRenderer0.getSeriesURLGenerator((int) (short) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        statisticalBarRenderer0.setGradientPaintTransformer(gradientPaintTransformer3);
        java.awt.Paint paint6 = statisticalBarRenderer0.lookupSeriesFillPaint(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = null;
        statisticalBarRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition7);
        boolean boolean11 = statisticalBarRenderer0.getItemVisible(31, 2019);
        org.junit.Assert.assertNull(categoryURLGenerator2);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.ASCENDING;
        java.lang.String str1 = sortOrder0.toString();
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SortOrder.ASCENDING" + "'", str1.equals("SortOrder.ASCENDING"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE12;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        java.awt.Color color0 = java.awt.Color.BLACK;
        int int1 = color0.getTransparency();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        double double1 = axisState0.getMax();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairValue((double) (byte) 1);
        org.jfree.chart.axis.ValueAxis valueAxis4 = categoryPlot0.getRangeAxisForDataset((int) (byte) 1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        try {
            categoryPlot0.handleClick(7, (int) (short) 1, plotRenderingInfo7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(valueAxis4);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        int int0 = org.jfree.data.time.SerialDate.WEDNESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1);
        java.lang.String str3 = textAnchor1.toString();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TextAnchor.BASELINE_RIGHT" + "'", str3.equals("TextAnchor.BASELINE_RIGHT"));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) categoryPlot0, jFreeChart1, 200, (int) (byte) 0);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor5 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        try {
            categoryPlot0.handleClick(0, 500, plotRenderingInfo8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(categoryAnchor5);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        java.util.TimeZone timeZone0 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.junit.Assert.assertNull(timeZone0);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        java.awt.Paint paint0 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        java.lang.Comparable[] comparableArray4 = new java.lang.Comparable[] { "CategoryLabelEntity: category=false, tooltip=, url=Preceding", "rect", (short) 1, (-1) };
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year9 = month8.getYear();
        java.lang.Comparable[] comparableArray11 = new java.lang.Comparable[] { 10.0d, ' ', 15, month8, 1.0f };
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 10L, 1, 15, 3600000L, 200, 0.5f };
        java.lang.Number[][] numberArray19 = new java.lang.Number[][] { numberArray18 };
        java.lang.Number[][] numberArray20 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset21 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray4, comparableArray11, numberArray19, numberArray20);
        try {
            defaultIntervalCategoryDataset21.setStartValue(8, (java.lang.Comparable) "RectangleAnchor.BOTTOM_RIGHT", (java.lang.Number) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset.setValue: series outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray4);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(comparableArray11);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray19);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_UPPER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = null;
        taskSeriesCollection0.seriesChanged(seriesChangeEvent1);
        org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, 9);
        try {
            java.lang.Number number8 = taskSeriesCollection0.getPercentComplete(31, (-1), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 31, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(pieDataset4);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_UPPER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2958465 + "'", int0 == 2958465);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) categoryPlot0, jFreeChart1, 200, (int) (byte) 0);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor5 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        categoryPlot0.zoomDomainAxes(100.0d, plotRenderingInfo7, point2D8);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot0.setRangeAxisLocation(axisLocation10);
        org.junit.Assert.assertNotNull(categoryAnchor5);
        org.junit.Assert.assertNotNull(axisLocation10);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D(1.561964399999E12d, (double) (short) -1);
        double double3 = size2D2.height;
        double double4 = size2D2.height;
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.0d) + "'", double4 == (-1.0d));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE4;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryPlot0.getAxisOffset();
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D5 = labelBlock4.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity8 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D5, "", "Preceding");
        org.jfree.chart.entity.LegendItemEntity legendItemEntity9 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D5);
        java.awt.geom.Rectangle2D rectangle2D10 = rectangleInsets1.createOutsetRectangle(rectangle2D5);
        double double12 = rectangleInsets1.calculateTopInset((double) 200);
        double double14 = rectangleInsets1.extendHeight((double) 128);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 128.0d + "'", double14 == 128.0d);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType0 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        java.lang.String str1 = categoryLabelWidthType0.toString();
        org.junit.Assert.assertNotNull(categoryLabelWidthType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CategoryLabelWidthType.CATEGORY" + "'", str1.equals("CategoryLabelWidthType.CATEGORY"));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (4) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.chart.block.LabelBlock labelBlock3 = new org.jfree.chart.block.LabelBlock("");
        java.awt.Font font4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        labelBlock3.setFont(font4);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer6 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = statisticalBarRenderer6.getSeriesURLGenerator((int) (short) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer9 = null;
        statisticalBarRenderer6.setGradientPaintTransformer(gradientPaintTransformer9);
        java.awt.Paint paint12 = statisticalBarRenderer6.lookupSeriesFillPaint(0);
        org.jfree.chart.text.TextFragment textFragment13 = new org.jfree.chart.text.TextFragment("", font4, paint12);
        java.awt.Color color14 = java.awt.Color.orange;
        org.jfree.chart.block.LabelBlock labelBlock15 = new org.jfree.chart.block.LabelBlock("Preceding", font4, (java.awt.Paint) color14);
        java.awt.Paint paint16 = labelBlock15.getPaint();
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNull(categoryURLGenerator8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = new org.jfree.chart.axis.CategoryLabelPositions();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions0, categoryLabelPosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'top' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(1);
        objectList1.clear();
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairValue((double) (byte) 1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis((int) ' ');
        org.jfree.chart.axis.CategoryAnchor categoryAnchor6 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range8 = numberAxis7.getDefaultAutoRange();
        boolean boolean10 = numberAxis7.equals((java.lang.Object) (byte) -1);
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis7);
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = null;
        try {
            categoryPlot0.addDomainMarker(categoryMarker12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(categoryAnchor6);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D6 = labelBlock5.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D6, "", "Preceding");
        numberAxis1.setDownArrow((java.awt.Shape) rectangle2D6);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis1.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        double double13 = numberAxis12.getUpperBound();
        boolean boolean14 = numberAxis12.getAutoRangeStickyZero();
        boolean boolean15 = numberAxis12.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer16);
        boolean boolean18 = xYPlot17.isDomainCrosshairVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        try {
            xYPlot17.handleClick(2019, 31, plotRenderingInfo21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge((int) (short) 0);
        float float4 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray5 = null;
        try {
            categoryPlot0.setRenderers(categoryItemRendererArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D5 = labelBlock4.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity8 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D5, "", "Preceding");
        numberAxis0.setDownArrow((java.awt.Shape) rectangle2D5);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = numberAxis0.getLabelInsets();
        numberAxis0.setVerticalTickLabels(true);
        java.awt.Stroke stroke13 = numberAxis0.getAxisLineStroke();
        numberAxis0.setLabel("java.awt.Color[r=128,g=128,b=128]");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_INVERTED;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D6 = labelBlock5.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D6, "", "Preceding");
        numberAxis1.setDownArrow((java.awt.Shape) rectangle2D6);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis1.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        double double13 = numberAxis12.getUpperBound();
        boolean boolean14 = numberAxis12.getAutoRangeStickyZero();
        boolean boolean15 = numberAxis12.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer16);
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = xYPlot17.getRendererForDataset(xYDataset18);
        org.jfree.chart.axis.AxisSpace axisSpace20 = xYPlot17.getFixedDomainAxisSpace();
        boolean boolean21 = xYPlot17.isDomainZeroBaselineVisible();
        org.jfree.chart.plot.PlotOrientation plotOrientation22 = null;
        try {
            xYPlot17.setOrientation(plotOrientation22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(xYItemRenderer19);
        org.junit.Assert.assertNull(axisSpace20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D2 = labelBlock1.getBounds();
        java.lang.Object obj3 = null;
        boolean boolean4 = labelBlock1.equals(obj3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.data.general.WaferMapDataset waferMapDataset6 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot7 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.block.LabelBlock labelBlock11 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D12 = labelBlock11.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity15 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D12, "", "Preceding");
        waferMapPlot7.drawBackgroundImage(graphics2D8, rectangle2D12);
        try {
            labelBlock1.draw(graphics2D5, rectangle2D12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(rectangle2D12);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = statisticalBarRenderer0.getSeriesURLGenerator((int) (short) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        statisticalBarRenderer0.setGradientPaintTransformer(gradientPaintTransformer3);
        java.awt.Paint paint7 = statisticalBarRenderer0.getItemPaint((int) (byte) 100, (int) '#');
        statisticalBarRenderer0.setSeriesCreateEntities(31, (java.lang.Boolean) true);
        org.jfree.chart.LegendItemCollection legendItemCollection11 = statisticalBarRenderer0.getLegendItems();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator12 = null;
        statisticalBarRenderer0.setBaseURLGenerator(categoryURLGenerator12);
        java.awt.Paint paint15 = statisticalBarRenderer0.getSeriesOutlinePaint((int) (byte) -1);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        statisticalBarRenderer0.setBasePaint((java.awt.Paint) color16);
        org.junit.Assert.assertNull(categoryURLGenerator2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(legendItemCollection11);
        org.junit.Assert.assertNull(paint15);
        org.junit.Assert.assertNotNull(color16);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str1 = projectInfo0.getCopyright();
        projectInfo0.setVersion("({0}, {1}) = {2}");
        org.jfree.chart.ui.Library library8 = new org.jfree.chart.ui.Library("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "", "Preceding", "({0}, {1}) = {2}");
        projectInfo0.addLibrary(library8);
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_NONE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean2 = lengthAdjustmentType0.equals((java.lang.Object) lineAndShapeRenderer1);
        java.lang.String str3 = lengthAdjustmentType0.toString();
        java.lang.String str4 = lengthAdjustmentType0.toString();
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "CONTRACT" + "'", str3.equals("CONTRACT"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "CONTRACT" + "'", str4.equals("CONTRACT"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.text.AttributedString attributedString1 = org.jfree.chart.util.SerialUtilities.readAttributedString(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryPlot0.getAxisOffset();
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D5 = labelBlock4.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity8 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D5, "", "Preceding");
        org.jfree.chart.entity.LegendItemEntity legendItemEntity9 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D5);
        java.awt.geom.Rectangle2D rectangle2D10 = rectangleInsets1.createOutsetRectangle(rectangle2D5);
        double double12 = rectangleInsets1.extendWidth((double) 1561964399999L);
        double double14 = rectangleInsets1.calculateTopOutset((double) 7);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.561964399999E12d + "'", double12 == 1.561964399999E12d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 1L, (double) 31);
        boolean boolean4 = stackedBarRenderer3D2.equals((java.lang.Object) (-1.0f));
        stackedBarRenderer3D2.setRenderAsPercentages(true);
        stackedBarRenderer3D2.setSeriesItemLabelsVisible(7, (java.lang.Boolean) false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = null;
        taskSeriesCollection0.seriesChanged(seriesChangeEvent1);
        int int4 = taskSeriesCollection0.indexOf((java.lang.Comparable) (-1L));
        try {
            java.lang.Number number8 = taskSeriesCollection0.getPercentComplete((java.lang.Comparable) 'a', (java.lang.Comparable) (-1.0f), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.chart.ui.Licences licences0 = new org.jfree.chart.ui.Licences();
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D2 = labelBlock1.getBounds();
        labelBlock1.setPadding(1.0d, 10.0d, (double) 10L, (double) (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryPlot8.getAxisOffset();
        org.jfree.chart.block.LabelBlock labelBlock12 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D13 = labelBlock12.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity16 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D13, "", "Preceding");
        org.jfree.chart.entity.LegendItemEntity legendItemEntity17 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D13);
        java.awt.geom.Rectangle2D rectangle2D18 = rectangleInsets9.createOutsetRectangle(rectangle2D13);
        double double20 = rectangleInsets9.calculateTopInset((double) 200);
        labelBlock1.setMargin(rectangleInsets9);
        java.awt.Graphics2D graphics2D22 = null;
        try {
            org.jfree.chart.util.Size2D size2D23 = labelBlock1.arrange(graphics2D22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D2);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = statisticalBarRenderer0.getSeriesURLGenerator((int) (short) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        statisticalBarRenderer0.setGradientPaintTransformer(gradientPaintTransformer3);
        java.awt.Paint paint6 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        statisticalBarRenderer0.setSeriesOutlinePaint(2019, paint6);
        java.awt.Paint paint8 = statisticalBarRenderer0.getErrorIndicatorPaint();
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator11 = piePlot10.getToolTipGenerator();
        java.awt.Color color12 = java.awt.Color.gray;
        piePlot10.setLabelShadowPaint((java.awt.Paint) color12);
        piePlot10.setExplodePercent((java.lang.Comparable) 8.0d, (double) 7);
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis();
        double double18 = numberAxis17.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock21 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D22 = labelBlock21.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity25 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D22, "", "Preceding");
        numberAxis17.setDownArrow((java.awt.Shape) rectangle2D22);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = numberAxis17.getLabelInsets();
        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
        numberAxis17.setRightArrow(shape29);
        java.awt.Paint paint31 = numberAxis17.getLabelPaint();
        piePlot10.setBaseSectionPaint(paint31);
        statisticalBarRenderer0.setBasePaint(paint31);
        org.junit.Assert.assertNull(categoryURLGenerator2);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(pieToolTipGenerator11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(paint31);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        java.lang.Object obj1 = null;
        boolean boolean2 = horizontalAlignment0.equals(obj1);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = null;
        taskSeriesCollection0.seriesChanged(seriesChangeEvent1);
        java.lang.Number number3 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        try {
            java.lang.Number number6 = taskSeriesCollection0.getPercentComplete((java.lang.Comparable) 7, (java.lang.Comparable) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0.0d + "'", number3.equals(0.0d));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        try {
            java.lang.Object obj3 = keyedObjects2D0.getObject(10, 500);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D3 = labelBlock2.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity6 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D3, "", "Preceding");
        org.jfree.chart.entity.LegendItemEntity legendItemEntity7 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D3);
        org.jfree.data.general.Dataset dataset8 = legendItemEntity7.getDataset();
        java.lang.String str9 = legendItemEntity7.getShapeType();
        java.lang.Comparable comparable10 = legendItemEntity7.getSeriesKey();
        org.junit.Assert.assertNotNull(rectangle2D3);
        org.junit.Assert.assertNull(dataset8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "rect" + "'", str9.equals("rect"));
        org.junit.Assert.assertNull(comparable10);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABELS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        java.lang.Comparable[] comparableArray4 = new java.lang.Comparable[] { "CategoryLabelEntity: category=false, tooltip=, url=Preceding", "rect", (short) 1, (-1) };
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year9 = month8.getYear();
        java.lang.Comparable[] comparableArray11 = new java.lang.Comparable[] { 10.0d, ' ', 15, month8, 1.0f };
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 10L, 1, 15, 3600000L, 200, 0.5f };
        java.lang.Number[][] numberArray19 = new java.lang.Number[][] { numberArray18 };
        java.lang.Number[][] numberArray20 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset21 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray4, comparableArray11, numberArray19, numberArray20);
        try {
            defaultIntervalCategoryDataset21.setEndValue(2958465, (java.lang.Comparable) "CategoryLabelEntity: category=false, tooltip=, url=Preceding", (java.lang.Number) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset.setValue: series outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray4);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(comparableArray11);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray19);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.data.time.DateRange dateRange2 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double3 = dateRange2.getCentralValue();
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double5 = dateRange4.getCentralValue();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange2, (org.jfree.data.Range) dateRange4);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = rectangleConstraint6.toFixedHeight((double) 10.0f);
        try {
            org.jfree.chart.util.Size2D size2D9 = textTitle0.arrange(graphics2D1, rectangleConstraint6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateRange2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.5d + "'", double3 == 0.5d);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.5d + "'", double5 == 0.5d);
        org.junit.Assert.assertNotNull(rectangleConstraint8);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.data.function.Function2D function2D0 = null;
        try {
            org.jfree.data.xy.XYDataset xYDataset5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, 0.0d, 0.0d, 3, (java.lang.Comparable) 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D5 = labelBlock4.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity8 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D5, "", "Preceding");
        org.jfree.chart.entity.LegendItemEntity legendItemEntity9 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D5);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer10 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint11 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        statisticalBarRenderer10.setBasePaint(paint11);
        org.jfree.chart.title.LegendGraphic legendGraphic13 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape) rectangle2D5, paint11);
        org.jfree.chart.text.TextMeasurer textMeasurer15 = null;
        org.jfree.chart.text.TextBlock textBlock16 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint11, (float) (short) 0, textMeasurer15);
        org.jfree.chart.text.TextLine textLine17 = textBlock16.getLastLine();
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.util.Size2D size2D19 = textBlock16.calculateDimensions(graphics2D18);
        java.lang.String str20 = size2D19.toString();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(textBlock16);
        org.junit.Assert.assertNull(textLine17);
        org.junit.Assert.assertNotNull(size2D19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Size2D[width=0.0, height=0.0]" + "'", str20.equals("Size2D[width=0.0, height=0.0]"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) categoryPlot0, jFreeChart1, 200, (int) (byte) 0);
        org.jfree.chart.JFreeChart jFreeChart5 = chartProgressEvent4.getChart();
        org.jfree.chart.JFreeChart jFreeChart6 = chartProgressEvent4.getChart();
        org.junit.Assert.assertNull(jFreeChart5);
        org.junit.Assert.assertNull(jFreeChart6);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D5 = labelBlock4.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity8 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D5, "", "Preceding");
        numberAxis0.setDownArrow((java.awt.Shape) rectangle2D5);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = numberAxis0.getLabelInsets();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot11.setRangeCrosshairValue((double) (byte) 1);
        org.jfree.chart.axis.ValueAxis valueAxis14 = categoryPlot11.getRangeAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = categoryPlot11.getDomainAxis((int) ' ');
        boolean boolean17 = numberAxis0.hasListener((java.util.EventListener) categoryPlot11);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = categoryPlot11.getRangeAxisEdge((int) '4');
        categoryPlot11.setDrawSharedDomainAxis(true);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNull(valueAxis14);
        org.junit.Assert.assertNull(categoryAxis16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(rectangleEdge19);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        java.awt.Font font0 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        statisticalBarRenderer0.setBasePaint(paint1);
        boolean boolean3 = statisticalBarRenderer0.getIncludeBaseInRange();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState5 = null;
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        double double7 = numberAxis6.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock10 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D11 = labelBlock10.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity14 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D11, "", "Preceding");
        numberAxis6.setDownArrow((java.awt.Shape) rectangle2D11);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D18 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 1L, (double) 31);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis();
        double double22 = numberAxis21.getUpperBound();
        boolean boolean23 = numberAxis21.getAutoRangeStickyZero();
        org.jfree.chart.plot.Marker marker24 = null;
        org.jfree.data.general.WaferMapDataset waferMapDataset25 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot26 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset25);
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.block.LabelBlock labelBlock30 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D31 = labelBlock30.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity34 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D31, "", "Preceding");
        waferMapPlot26.drawBackgroundImage(graphics2D27, rectangle2D31);
        stackedBarRenderer3D18.drawRangeMarker(graphics2D19, categoryPlot20, (org.jfree.chart.axis.ValueAxis) numberAxis21, marker24, rectangle2D31);
        boolean boolean37 = categoryPlot20.isDomainGridlinesVisible();
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis38.setLowerMargin((double) 10.0f);
        org.jfree.data.general.WaferMapDataset waferMapDataset41 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot42 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset41);
        float float43 = waferMapPlot42.getForegroundAlpha();
        java.lang.String str44 = waferMapPlot42.getPlotType();
        boolean boolean45 = categoryAxis38.equals((java.lang.Object) str44);
        org.jfree.chart.axis.NumberAxis numberAxis46 = new org.jfree.chart.axis.NumberAxis();
        double double47 = numberAxis46.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock50 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D51 = labelBlock50.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity54 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D51, "", "Preceding");
        numberAxis46.setDownArrow((java.awt.Shape) rectangle2D51);
        org.jfree.chart.util.RectangleInsets rectangleInsets56 = numberAxis46.getLabelInsets();
        java.awt.Shape shape58 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
        numberAxis46.setRightArrow(shape58);
        double[] doubleArray64 = new double[] { (-1L), 0.0d };
        double[] doubleArray67 = new double[] { (-1L), 0.0d };
        double[] doubleArray70 = new double[] { (-1L), 0.0d };
        double[] doubleArray73 = new double[] { (-1L), 0.0d };
        double[][] doubleArray74 = new double[][] { doubleArray64, doubleArray67, doubleArray70, doubleArray73 };
        org.jfree.data.category.CategoryDataset categoryDataset75 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", doubleArray74);
        org.jfree.data.Range range76 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset75);
        java.lang.Number number77 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset75);
        java.lang.Number number78 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset75);
        java.lang.Number number79 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset75);
        try {
            statisticalBarRenderer0.drawItem(graphics2D4, categoryItemRendererState5, rectangle2D11, categoryPlot20, categoryAxis38, (org.jfree.chart.axis.ValueAxis) numberAxis46, categoryDataset75, 6, 12, 128);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires StatisticalCategoryDataset.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + float43 + "' != '" + 1.0f + "'", float43 == 1.0f);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "WMAP_Plot" + "'", str44.equals("WMAP_Plot"));
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.0d + "'", double47 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D51);
        org.junit.Assert.assertNotNull(rectangleInsets56);
        org.junit.Assert.assertNotNull(shape58);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(categoryDataset75);
        org.junit.Assert.assertNotNull(range76);
        org.junit.Assert.assertTrue("'" + number77 + "' != '" + 0.0d + "'", number77.equals(0.0d));
        org.junit.Assert.assertTrue("'" + number78 + "' != '" + 0.0d + "'", number78.equals(0.0d));
        org.junit.Assert.assertTrue("'" + number79 + "' != '" + 0.0d + "'", number79.equals(0.0d));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.awt.Color color1 = java.awt.Color.darkGray;
        boolean boolean2 = defaultCategoryDataset0.equals((java.lang.Object) color1);
        try {
            java.lang.Comparable comparable4 = defaultCategoryDataset0.getColumnKey(15);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 15, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addMonths((int) 'a', serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        java.lang.Object obj0 = null;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        try {
            org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent(obj0, jFreeChart1, 12, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        org.jfree.data.time.Year year2 = month0.getYear();
        java.util.Calendar calendar3 = null;
        try {
            month0.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = statisticalBarRenderer1.getSeriesURLGenerator((int) (short) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer4 = null;
        statisticalBarRenderer1.setGradientPaintTransformer(gradientPaintTransformer4);
        java.awt.Paint paint8 = statisticalBarRenderer1.getItemPaint((int) (byte) 100, (int) '#');
        statisticalBarRenderer1.setSeriesCreateEntities(31, (java.lang.Boolean) true);
        org.jfree.chart.LegendItemCollection legendItemCollection12 = statisticalBarRenderer1.getLegendItems();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator13 = null;
        statisticalBarRenderer1.setBaseURLGenerator(categoryURLGenerator13);
        org.jfree.data.KeyedObject keyedObject15 = new org.jfree.data.KeyedObject((java.lang.Comparable) "rect", (java.lang.Object) categoryURLGenerator13);
        org.jfree.chart.block.LabelBlock labelBlock18 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D19 = labelBlock18.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity22 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D19, "", "Preceding");
        org.jfree.chart.entity.LegendItemEntity legendItemEntity23 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D19);
        boolean boolean24 = keyedObject15.equals((java.lang.Object) legendItemEntity23);
        java.lang.Object obj25 = keyedObject15.getObject();
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(legendItemCollection12);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(obj25);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        int int0 = org.jfree.data.time.SerialDate.SUNDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str1 = projectInfo0.getCopyright();
        projectInfo0.setInfo("({0}, {1}) = {2}");
        java.lang.String str4 = projectInfo0.getName();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge((int) (short) 0);
        categoryPlot0.setAnchorValue((double) 10.0f, false);
        org.jfree.data.category.CategoryDataset categoryDataset8 = categoryPlot0.getDataset(2019);
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        categoryPlot0.removeChangeListener(plotChangeListener9);
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        double double12 = numberAxis11.getUpperBound();
        boolean boolean13 = numberAxis11.getAutoRangeStickyZero();
        boolean boolean14 = numberAxis11.isAutoRange();
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis11);
        org.jfree.chart.plot.Marker marker16 = null;
        try {
            categoryPlot0.addRangeMarker(marker16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNull(categoryDataset8);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator1 = null;
        lineAndShapeRenderer0.setLegendItemToolTipGenerator(categorySeriesLabelGenerator1);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        java.lang.Comparable[] comparableArray4 = new java.lang.Comparable[] { "CategoryLabelEntity: category=false, tooltip=, url=Preceding", "rect", (short) 1, (-1) };
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year9 = month8.getYear();
        java.lang.Comparable[] comparableArray11 = new java.lang.Comparable[] { 10.0d, ' ', 15, month8, 1.0f };
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 10L, 1, 15, 3600000L, 200, 0.5f };
        java.lang.Number[][] numberArray19 = new java.lang.Number[][] { numberArray18 };
        java.lang.Number[][] numberArray20 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset21 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray4, comparableArray11, numberArray19, numberArray20);
        try {
            java.lang.Comparable comparable23 = defaultIntervalCategoryDataset21.getColumnKey(31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray4);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(comparableArray11);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray19);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator2 = piePlot1.getToolTipGenerator();
        java.awt.Font font3 = piePlot1.getLabelFont();
        double double4 = piePlot1.getMaximumLabelWidth();
        org.junit.Assert.assertNull(pieToolTipGenerator2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2d + "'", double4 == 0.2d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation5 = categoryPlot0.getDomainAxisLocation((int) '4');
        org.jfree.chart.axis.AxisSpace axisSpace6 = new org.jfree.chart.axis.AxisSpace();
        categoryPlot0.setFixedRangeAxisSpace(axisSpace6);
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot0);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer10 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.block.LabelBlock labelBlock13 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D14 = labelBlock13.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity17 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D14, "", "Preceding");
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double19 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D14, rectangleEdge18);
        statisticalBarRenderer10.setBaseShape((java.awt.Shape) rectangle2D14, true);
        try {
            java.lang.Object obj23 = legendTitle8.draw(graphics2D9, rectangle2D14, (java.lang.Object) "TextAnchor.BASELINE_RIGHT");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(1);
        java.lang.Object obj2 = objectList1.clone();
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str1 = projectInfo0.getCopyright();
        projectInfo0.setInfo("({0}, {1}) = {2}");
        java.util.List list4 = projectInfo0.getContributors();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNull(list4);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.START;
        org.junit.Assert.assertNotNull(categoryAnchor0);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 31);
        java.awt.Stroke stroke6 = null;
        java.awt.Color color7 = java.awt.Color.orange;
        int int8 = color7.getGreen();
        float[] floatArray14 = new float[] { (short) 0, 10.0f, (short) 10, (byte) 0, 0.0f };
        float[] floatArray15 = color7.getColorComponents(floatArray14);
        try {
            org.jfree.chart.LegendItem legendItem16 = new org.jfree.chart.LegendItem("({0}, {1}) = {2}", "({0}, {1}) = {3} - {4}", "java.awt.Color[r=128,g=128,b=128]", "Category 1", shape5, stroke6, (java.awt.Paint) color7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'lineStroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 200 + "'", int8 == 200);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray15);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D5 = labelBlock4.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity8 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D5, "", "Preceding");
        numberAxis0.setDownArrow((java.awt.Shape) rectangle2D5);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = numberAxis0.getLabelInsets();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot11.setRangeCrosshairValue((double) (byte) 1);
        org.jfree.chart.axis.ValueAxis valueAxis14 = categoryPlot11.getRangeAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = categoryPlot11.getDomainAxis((int) ' ');
        boolean boolean17 = numberAxis0.hasListener((java.util.EventListener) categoryPlot11);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = categoryPlot11.getRangeAxisEdge((int) (byte) 0);
        org.jfree.data.category.CategoryDataset categoryDataset20 = categoryPlot11.getDataset();
        java.awt.Color color21 = java.awt.Color.darkGray;
        categoryPlot11.setOutlinePaint((java.awt.Paint) color21);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNull(valueAxis14);
        org.junit.Assert.assertNull(categoryAxis16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertNull(categoryDataset20);
        org.junit.Assert.assertNotNull(color21);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement0.clear();
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D5 = labelBlock4.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity8 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D5, "", "Preceding");
        numberAxis0.setDownArrow((java.awt.Shape) rectangle2D5);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = numberAxis0.getLabelInsets();
        numberAxis0.setPositiveArrowVisible(true);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNotNull(rectangleInsets10);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 1L, (double) 31);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        double double6 = numberAxis5.getUpperBound();
        boolean boolean7 = numberAxis5.getAutoRangeStickyZero();
        org.jfree.chart.plot.Marker marker8 = null;
        org.jfree.data.general.WaferMapDataset waferMapDataset9 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot10 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset9);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.block.LabelBlock labelBlock14 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D15 = labelBlock14.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity18 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D15, "", "Preceding");
        waferMapPlot10.drawBackgroundImage(graphics2D11, rectangle2D15);
        stackedBarRenderer3D2.drawRangeMarker(graphics2D3, categoryPlot4, (org.jfree.chart.axis.ValueAxis) numberAxis5, marker8, rectangle2D15);
        boolean boolean21 = categoryPlot4.isDomainGridlinesVisible();
        org.jfree.chart.axis.AxisLocation axisLocation23 = categoryPlot4.getDomainAxisLocation(100);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(axisLocation23);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        double[] doubleArray6 = new double[] { (-1L), 0.0d };
        double[] doubleArray9 = new double[] { (-1L), 0.0d };
        double[] doubleArray12 = new double[] { (-1L), 0.0d };
        double[] doubleArray15 = new double[] { (-1L), 0.0d };
        double[][] doubleArray16 = new double[][] { doubleArray6, doubleArray9, doubleArray12, doubleArray15 };
        org.jfree.data.category.CategoryDataset categoryDataset17 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", doubleArray16);
        org.jfree.data.category.CategoryDataset categoryDataset18 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray16);
        double[] doubleArray25 = new double[] { (-1L), 0.0d };
        double[] doubleArray28 = new double[] { (-1L), 0.0d };
        double[] doubleArray31 = new double[] { (-1L), 0.0d };
        double[] doubleArray34 = new double[] { (-1L), 0.0d };
        double[][] doubleArray35 = new double[][] { doubleArray25, doubleArray28, doubleArray31, doubleArray34 };
        org.jfree.data.category.CategoryDataset categoryDataset36 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", doubleArray35);
        org.jfree.data.category.CategoryDataset categoryDataset37 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray35);
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset38 = new org.jfree.data.category.DefaultIntervalCategoryDataset(doubleArray16, doubleArray35);
        try {
            java.lang.Number number41 = defaultIntervalCategoryDataset38.getStartValue((java.lang.Comparable) 4, (java.lang.Comparable) "({0}, {1}) = {3} - {4}");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unknown 'series' key.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(categoryDataset17);
        org.junit.Assert.assertNotNull(categoryDataset18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(categoryDataset36);
        org.junit.Assert.assertNotNull(categoryDataset37);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("({0}, {1}) = {2}", graphics2D1, (float) '#', (float) 1561964399999L, 0.0d, (float) 1561964399999L, 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextPaint();
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year1.getFirstMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year1);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D6 = labelBlock5.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D6, "", "Preceding");
        numberAxis1.setDownArrow((java.awt.Shape) rectangle2D6);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis1.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        double double13 = numberAxis12.getUpperBound();
        boolean boolean14 = numberAxis12.getAutoRangeStickyZero();
        boolean boolean15 = numberAxis12.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer16);
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = xYPlot17.getRendererForDataset(xYDataset18);
        java.lang.Object obj20 = xYPlot17.clone();
        org.jfree.chart.axis.AxisLocation axisLocation22 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        xYPlot17.setRangeAxisLocation(0, axisLocation22, true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(xYItemRenderer19);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(axisLocation22);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D3 = labelBlock2.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity6 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D3, "", "Preceding");
        org.jfree.chart.entity.LegendItemEntity legendItemEntity7 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D3);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint9 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        statisticalBarRenderer8.setBasePaint(paint9);
        org.jfree.chart.title.LegendGraphic legendGraphic11 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape) rectangle2D3, paint9);
        java.awt.Shape shape12 = legendGraphic11.getLine();
        double double13 = legendGraphic11.getContentYOffset();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer14 = null;
        try {
            legendGraphic11.setFillPaintTransformer(gradientPaintTransformer14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'transformer' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(shape12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.0d + "'", double13 == 2.0d);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = statisticalBarRenderer0.getSeriesURLGenerator((int) (short) 100);
        int int3 = statisticalBarRenderer0.getColumnCount();
        double double4 = statisticalBarRenderer0.getItemMargin();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer5.setSeriesLinesVisible((int) '4', (java.lang.Boolean) true);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor10 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE7;
        org.jfree.chart.text.TextAnchor textAnchor11 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor12 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor10, textAnchor11, textAnchor12, (double) 0L);
        lineAndShapeRenderer5.setSeriesNegativeItemLabelPosition((int) '4', itemLabelPosition14);
        statisticalBarRenderer0.setPositiveItemLabelPositionFallback(itemLabelPosition14);
        org.junit.Assert.assertNull(categoryURLGenerator2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2d + "'", double4 == 0.2d);
        org.junit.Assert.assertNotNull(itemLabelAnchor10);
        org.junit.Assert.assertNotNull(textAnchor11);
        org.junit.Assert.assertNotNull(textAnchor12);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        int int0 = org.jfree.data.time.SerialDate.MINIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1900 + "'", int0 == 1900);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        java.text.AttributedString attributedString0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeAttributedString(attributedString0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        try {
            org.jfree.data.Range range2 = new org.jfree.data.Range((double) '4', 3.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (52.0) <= upper (3.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        java.awt.Color color0 = java.awt.Color.WHITE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.data.general.WaferMapDataset waferMapDataset1 = waferMapPlot0.getDataset();
        org.junit.Assert.assertNull(waferMapDataset1);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke1 = defaultDrawingSupplier0.getNextOutlineStroke();
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator2 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator("SortOrder.ASCENDING", numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("Category 1");
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D2 = labelBlock1.getBounds();
        labelBlock1.setPadding(1.0d, 10.0d, (double) 10L, (double) (-1));
        labelBlock1.setPadding((double) 10, (double) (-1.0f), (double) (byte) 100, (double) 3);
        java.lang.Object obj13 = labelBlock1.clone();
        java.awt.Paint paint14 = null;
        try {
            labelBlock1.setPaint(paint14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D2);
        org.junit.Assert.assertNotNull(obj13);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = statisticalBarRenderer0.getSeriesURLGenerator((int) (short) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        statisticalBarRenderer0.setGradientPaintTransformer(gradientPaintTransformer3);
        java.awt.Paint paint7 = statisticalBarRenderer0.getItemPaint((int) (byte) 100, (int) '#');
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean10 = categoryPlot9.isDomainGridlinesVisible();
        org.jfree.chart.axis.AxisLocation axisLocation11 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot9.setDomainAxisLocation(axisLocation11);
        categoryPlot9.clearRangeMarkers((-1));
        org.jfree.chart.block.LabelBlock labelBlock16 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D17 = labelBlock16.getBounds();
        try {
            statisticalBarRenderer0.drawBackground(graphics2D8, categoryPlot9, rectangle2D17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryURLGenerator2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(rectangle2D17);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D6 = labelBlock5.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D6, "", "Preceding");
        numberAxis1.setDownArrow((java.awt.Shape) rectangle2D6);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis1.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        double double13 = numberAxis12.getUpperBound();
        boolean boolean14 = numberAxis12.getAutoRangeStickyZero();
        boolean boolean15 = numberAxis12.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer16);
        xYPlot17.setRangeCrosshairVisible(false);
        java.lang.String str20 = xYPlot17.getPlotType();
        org.jfree.chart.axis.ValueAxis valueAxis21 = xYPlot17.getDomainAxis();
        valueAxis21.setFixedAutoRange(0.25d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "XY Plot" + "'", str20.equals("XY Plot"));
        org.junit.Assert.assertNotNull(valueAxis21);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        double double3 = numberAxis2.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D7 = labelBlock6.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity10 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D7, "", "Preceding");
        numberAxis2.setDownArrow((java.awt.Shape) rectangle2D7);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = numberAxis2.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        double double14 = numberAxis13.getUpperBound();
        boolean boolean15 = numberAxis13.getAutoRangeStickyZero();
        boolean boolean16 = numberAxis13.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis13, xYItemRenderer17);
        xYPlot18.setRangeCrosshairVisible(false);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("WMAP_Plot", (org.jfree.chart.plot.Plot) xYPlot18);
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle();
        jFreeChart21.addSubtitle((org.jfree.chart.title.Title) textTitle22);
        org.jfree.chart.event.ChartChangeListener chartChangeListener24 = null;
        try {
            jFreeChart21.addChangeListener(chartChangeListener24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D6 = labelBlock5.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D6, "", "Preceding");
        numberAxis1.setDownArrow((java.awt.Shape) rectangle2D6);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis1.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        double double13 = numberAxis12.getUpperBound();
        boolean boolean14 = numberAxis12.getAutoRangeStickyZero();
        boolean boolean15 = numberAxis12.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer16);
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        xYPlot17.setDataset(5, xYDataset19);
        xYPlot17.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder23 = null;
        try {
            xYPlot17.setSeriesRenderingOrder(seriesRenderingOrder23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.getUseFontMetricsGetStringBounds();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("CategoryLabelEntity: category=false, tooltip=, url=Preceding");
        org.jfree.chart.text.TextFragment textFragment3 = new org.jfree.chart.text.TextFragment("ERROR : Relative To String");
        textLine1.addFragment(textFragment3);
        java.awt.Graphics2D graphics2D5 = null;
        try {
            org.jfree.chart.util.Size2D size2D6 = textLine1.calculateDimensions(graphics2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = null;
        taskSeriesCollection0.seriesChanged(seriesChangeEvent1);
        int int4 = taskSeriesCollection0.indexOf((java.lang.Comparable) (-1L));
        try {
            taskSeriesCollection0.remove(7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: TaskSeriesCollection.remove(): index outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean1 = lineAndShapeRenderer0.getDrawOutlines();
        java.lang.Boolean boolean3 = lineAndShapeRenderer0.getSeriesLinesVisible(5);
        lineAndShapeRenderer0.setSeriesItemLabelsVisible(2, true);
        lineAndShapeRenderer0.setBaseShapesVisible(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(boolean3);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer1 = new org.jfree.chart.renderer.category.StackedBarRenderer(false);
        stackedBarRenderer1.setRenderAsPercentages(false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D3 = labelBlock2.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity6 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D3, "", "Preceding");
        org.jfree.chart.entity.LegendItemEntity legendItemEntity7 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D3);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint9 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        statisticalBarRenderer8.setBasePaint(paint9);
        org.jfree.chart.title.LegendGraphic legendGraphic11 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape) rectangle2D3, paint9);
        java.awt.Shape shape12 = legendGraphic11.getLine();
        double double13 = legendGraphic11.getContentYOffset();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D16 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 1L, (double) 31);
        boolean boolean18 = stackedBarRenderer3D16.equals((java.lang.Object) (-1.0f));
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator19 = null;
        stackedBarRenderer3D16.setLegendItemToolTipGenerator(categorySeriesLabelGenerator19);
        java.awt.Color color21 = java.awt.Color.YELLOW;
        stackedBarRenderer3D16.setBaseItemLabelPaint((java.awt.Paint) color21);
        legendGraphic11.setLinePaint((java.awt.Paint) color21);
        legendGraphic11.setLineVisible(true);
        org.junit.Assert.assertNotNull(rectangle2D3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(shape12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.0d + "'", double13 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(color21);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setSeriesLinesVisible((int) '4', (java.lang.Boolean) true);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor5 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE7;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor7 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor5, textAnchor6, textAnchor7, (double) 0L);
        lineAndShapeRenderer0.setSeriesNegativeItemLabelPosition((int) '4', itemLabelPosition9);
        org.jfree.chart.text.TextAnchor textAnchor11 = itemLabelPosition9.getRotationAnchor();
        org.junit.Assert.assertNotNull(itemLabelAnchor5);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertNotNull(textAnchor7);
        org.junit.Assert.assertNotNull(textAnchor11);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(4);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Fourth" + "'", str1.equals("Fourth"));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation5 = categoryPlot0.getDomainAxisLocation((int) '4');
        org.jfree.chart.axis.AxisSpace axisSpace6 = new org.jfree.chart.axis.AxisSpace();
        categoryPlot0.setFixedRangeAxisSpace(axisSpace6);
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = categoryPlot0.getDomainAxisEdge((int) (byte) 10);
        java.lang.String str10 = rectangleEdge9.toString();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "RectangleEdge.TOP" + "'", str10.equals("RectangleEdge.TOP"));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.awt.Image image1 = null;
        projectInfo0.setLogo(image1);
        projectInfo0.setLicenceText("Preceding");
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint3 = piePlot1.getSectionOutlinePaint((java.lang.Comparable) 2019);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent4 = null;
        piePlot1.markerChanged(markerChangeEvent4);
        piePlot1.setStartAngle((double) 10);
        org.junit.Assert.assertNull(paint3);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = statisticalBarRenderer1.getSeriesURLGenerator((int) (short) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer4 = null;
        statisticalBarRenderer1.setGradientPaintTransformer(gradientPaintTransformer4);
        java.awt.Paint paint7 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        statisticalBarRenderer1.setSeriesOutlinePaint(2019, paint7);
        boolean boolean9 = textTitle0.equals((java.lang.Object) paint7);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer10 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator12 = statisticalBarRenderer10.getSeriesURLGenerator((int) (short) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer13 = null;
        statisticalBarRenderer10.setGradientPaintTransformer(gradientPaintTransformer13);
        java.awt.Paint paint16 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        statisticalBarRenderer10.setSeriesOutlinePaint(2019, paint16);
        java.awt.Color color18 = java.awt.Color.BLACK;
        int int19 = color18.getBlue();
        java.awt.Paint paint20 = null;
        try {
            org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer21 = new org.jfree.chart.renderer.category.WaterfallBarRenderer(paint7, paint16, (java.awt.Paint) color18, paint20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'lastBarPaint' argument");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(categoryURLGenerator12);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_INCLUDES_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.data.time.DateRange dateRange0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double1 = dateRange0.getCentralValue();
        org.jfree.data.time.DateRange dateRange2 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double3 = dateRange2.getCentralValue();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange0, (org.jfree.data.Range) dateRange2);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = rectangleConstraint4.toFixedHeight((double) 10.0f);
        double double7 = rectangleConstraint4.getWidth();
        org.junit.Assert.assertNotNull(dateRange0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5d + "'", double1 == 0.5d);
        org.junit.Assert.assertNotNull(dateRange2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.5d + "'", double3 == 0.5d);
        org.junit.Assert.assertNotNull(rectangleConstraint6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = statisticalBarRenderer1.getSeriesURLGenerator((int) (short) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer4 = null;
        statisticalBarRenderer1.setGradientPaintTransformer(gradientPaintTransformer4);
        java.awt.Paint paint8 = statisticalBarRenderer1.getItemPaint((int) (byte) 100, (int) '#');
        statisticalBarRenderer1.setSeriesCreateEntities(31, (java.lang.Boolean) true);
        org.jfree.chart.LegendItemCollection legendItemCollection12 = statisticalBarRenderer1.getLegendItems();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator13 = null;
        statisticalBarRenderer1.setBaseURLGenerator(categoryURLGenerator13);
        org.jfree.data.KeyedObject keyedObject15 = new org.jfree.data.KeyedObject((java.lang.Comparable) "rect", (java.lang.Object) categoryURLGenerator13);
        org.jfree.chart.block.LabelBlock labelBlock18 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D19 = labelBlock18.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity22 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D19, "", "Preceding");
        org.jfree.chart.entity.LegendItemEntity legendItemEntity23 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D19);
        boolean boolean24 = keyedObject15.equals((java.lang.Object) legendItemEntity23);
        java.lang.Object obj25 = null;
        boolean boolean26 = keyedObject15.equals(obj25);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(legendItemCollection12);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        org.jfree.data.time.Year year2 = month0.getYear();
        try {
            java.lang.Object obj3 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) month0);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D3 = labelBlock2.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity6 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D3, "", "Preceding");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer7 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = statisticalBarRenderer7.getSeriesURLGenerator((int) (short) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer10 = null;
        statisticalBarRenderer7.setGradientPaintTransformer(gradientPaintTransformer10);
        java.awt.Paint paint13 = statisticalBarRenderer7.lookupSeriesFillPaint(0);
        boolean boolean14 = categoryLabelEntity6.equals((java.lang.Object) statisticalBarRenderer7);
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator15 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator16 = null;
        try {
            java.lang.String str17 = categoryLabelEntity6.getImageMapAreaTag(toolTipTagFragmentGenerator15, uRLTagFragmentGenerator16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D3);
        org.junit.Assert.assertNull(categoryURLGenerator9);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.previous();
        java.util.Date date4 = month2.getEnd();
        try {
            java.lang.Number number5 = taskSeriesCollection0.getEndValue((java.lang.Comparable) 0.2d, (java.lang.Comparable) month2);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D5 = labelBlock4.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity8 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D5, "", "Preceding");
        numberAxis0.setDownArrow((java.awt.Shape) rectangle2D5);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = numberAxis0.getLabelInsets();
        numberAxis0.setVerticalTickLabels(true);
        org.jfree.data.Range range13 = numberAxis0.getDefaultAutoRange();
        java.awt.Paint paint14 = numberAxis0.getTickLabelPaint();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        double double3 = numberAxis2.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D7 = labelBlock6.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity10 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D7, "", "Preceding");
        numberAxis2.setDownArrow((java.awt.Shape) rectangle2D7);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = numberAxis2.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        double double14 = numberAxis13.getUpperBound();
        boolean boolean15 = numberAxis13.getAutoRangeStickyZero();
        boolean boolean16 = numberAxis13.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis13, xYItemRenderer17);
        xYPlot18.setRangeCrosshairVisible(false);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("WMAP_Plot", (org.jfree.chart.plot.Plot) xYPlot18);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo25 = null;
        try {
            java.awt.image.BufferedImage bufferedImage26 = jFreeChart21.createBufferedImage((int) (byte) 0, (int) (short) -1, 200, chartRenderingInfo25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown image type 200");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        try {
            java.lang.Number number4 = taskSeriesCollection0.getStartValue((java.lang.Comparable) 128.0d, (java.lang.Comparable) 0.0f, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.FULL;
        org.junit.Assert.assertNotNull(rangeType0);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = null;
        taskSeriesCollection0.seriesChanged(seriesChangeEvent1);
        org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, 9);
        try {
            java.lang.Number number8 = taskSeriesCollection0.getPercentComplete((java.lang.Comparable) "({0}, {1}) = {3} - {4}", (java.lang.Comparable) "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", 9);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(pieDataset4);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        double double3 = numberAxis2.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D7 = labelBlock6.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity10 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D7, "", "Preceding");
        numberAxis2.setDownArrow((java.awt.Shape) rectangle2D7);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = numberAxis2.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        double double14 = numberAxis13.getUpperBound();
        boolean boolean15 = numberAxis13.getAutoRangeStickyZero();
        boolean boolean16 = numberAxis13.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis13, xYItemRenderer17);
        xYPlot18.setRangeCrosshairVisible(false);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("WMAP_Plot", (org.jfree.chart.plot.Plot) xYPlot18);
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle();
        jFreeChart21.addSubtitle((org.jfree.chart.title.Title) textTitle22);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean26 = categoryPlot25.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = categoryPlot25.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation30 = categoryPlot25.getDomainAxisLocation((int) '4');
        org.jfree.chart.axis.AxisSpace axisSpace31 = new org.jfree.chart.axis.AxisSpace();
        categoryPlot25.setFixedRangeAxisSpace(axisSpace31);
        org.jfree.chart.title.LegendTitle legendTitle33 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot25);
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = categoryPlot34.getAxisOffset();
        org.jfree.chart.block.LabelBlock labelBlock38 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D39 = labelBlock38.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity42 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D39, "", "Preceding");
        org.jfree.chart.entity.LegendItemEntity legendItemEntity43 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D39);
        java.awt.geom.Rectangle2D rectangle2D44 = rectangleInsets35.createOutsetRectangle(rectangle2D39);
        double double46 = rectangleInsets35.calculateTopInset((double) 200);
        legendTitle33.setItemLabelPadding(rectangleInsets35);
        try {
            jFreeChart21.addSubtitle((int) (byte) -1, (org.jfree.chart.title.Title) legendTitle33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'index' argument is out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertNotNull(axisLocation30);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertNotNull(rectangle2D39);
        org.junit.Assert.assertNotNull(rectangle2D44);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D6 = labelBlock5.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D6, "", "Preceding");
        numberAxis1.setDownArrow((java.awt.Shape) rectangle2D6);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis1.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        double double13 = numberAxis12.getUpperBound();
        boolean boolean14 = numberAxis12.getAutoRangeStickyZero();
        boolean boolean15 = numberAxis12.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer16);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Point2D point2D21 = null;
        xYPlot17.zoomRangeAxes(0.0d, (double) 100L, plotRenderingInfo20, point2D21);
        java.awt.Paint paint23 = xYPlot17.getRangeGridlinePaint();
        int int24 = xYPlot17.getDomainAxisCount();
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        try {
            xYPlot17.setQuadrantPaint((int) (byte) 100, (java.awt.Paint) color26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(color26);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.util.List list1 = defaultCategoryDataset0.getRowKeys();
        try {
            java.util.Collection collection2 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list1);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = statisticalBarRenderer0.getSeriesURLGenerator((int) (short) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        statisticalBarRenderer0.setGradientPaintTransformer(gradientPaintTransformer3);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator7 = statisticalBarRenderer0.getItemLabelGenerator((int) (short) 100, 0);
        org.junit.Assert.assertNull(categoryURLGenerator2);
        org.junit.Assert.assertNull(categoryItemLabelGenerator7);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator2 = piePlot1.getToolTipGenerator();
        double double3 = piePlot1.getMaximumLabelWidth();
        piePlot1.setStartAngle((double) 200);
        piePlot1.setCircular(false, true);
        org.junit.Assert.assertNull(pieToolTipGenerator2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        java.awt.Color color0 = java.awt.Color.LIGHT_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = statisticalBarRenderer0.getSeriesURLGenerator((int) (short) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        statisticalBarRenderer0.setGradientPaintTransformer(gradientPaintTransformer3);
        java.awt.Paint paint6 = statisticalBarRenderer0.lookupSeriesFillPaint(0);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        statisticalBarRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator7, true);
        java.awt.Paint paint10 = statisticalBarRenderer0.getBaseOutlinePaint();
        org.junit.Assert.assertNull(categoryURLGenerator2);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = null;
        taskSeriesCollection0.seriesChanged(seriesChangeEvent1);
        org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, 9);
        int int6 = taskSeriesCollection0.indexOf((java.lang.Comparable) 1.0E-8d);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer7 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.block.LabelBlock labelBlock10 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D11 = labelBlock10.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity14 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D11, "", "Preceding");
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double16 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D11, rectangleEdge15);
        statisticalBarRenderer7.setBaseShape((java.awt.Shape) rectangle2D11, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator21 = statisticalBarRenderer7.getItemLabelGenerator((int) (byte) -1, 10);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent22 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10);
        taskSeriesCollection0.seriesChanged(seriesChangeEvent22);
        org.junit.Assert.assertNotNull(pieDataset4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNull(categoryItemLabelGenerator21);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        java.lang.Class class0 = null;
        java.lang.ClassLoader classLoader1 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class0);
        org.junit.Assert.assertNotNull(classLoader1);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 9);
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.clone(shape1);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D6 = labelBlock5.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D6, "", "Preceding");
        numberAxis1.setDownArrow((java.awt.Shape) rectangle2D6);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis1.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        double double13 = numberAxis12.getUpperBound();
        boolean boolean14 = numberAxis12.getAutoRangeStickyZero();
        boolean boolean15 = numberAxis12.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer16);
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        xYPlot17.setDataset(5, xYDataset19);
        int int21 = xYPlot17.getDatasetCount();
        xYPlot17.clearDomainAxes();
        try {
            java.awt.Paint paint24 = xYPlot17.getQuadrantPaint((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D5 = labelBlock4.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity8 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D5, "", "Preceding");
        numberAxis0.setDownArrow((java.awt.Shape) rectangle2D5);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = numberAxis0.getLabelInsets();
        numberAxis0.setTickMarkOutsideLength(0.0f);
        double double13 = numberAxis0.getLowerMargin();
        org.jfree.data.general.WaferMapDataset waferMapDataset14 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot15 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset14);
        float float16 = waferMapPlot15.getForegroundAlpha();
        java.lang.String str17 = waferMapPlot15.getPlotType();
        numberAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot15);
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer19 = null;
        waferMapPlot15.setRenderer(waferMapRenderer19);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.05d + "'", double13 == 0.05d);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 1.0f + "'", float16 == 1.0f);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "WMAP_Plot" + "'", str17.equals("WMAP_Plot"));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("");
        labelBlock1.setPadding(0.0d, (double) 'a', (double) (byte) 10, 100.0d);
        java.lang.String str7 = labelBlock1.getToolTipText();
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        java.util.Calendar calendar2 = null;
        try {
            year1.peg(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year1);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D5 = labelBlock4.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity8 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D5, "", "Preceding");
        numberAxis0.setDownArrow((java.awt.Shape) rectangle2D5);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = numberAxis0.getLabelInsets();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot11.setRangeCrosshairValue((double) (byte) 1);
        org.jfree.chart.axis.ValueAxis valueAxis14 = categoryPlot11.getRangeAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = categoryPlot11.getDomainAxis((int) ' ');
        boolean boolean17 = numberAxis0.hasListener((java.util.EventListener) categoryPlot11);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = categoryPlot11.getRangeAxisEdge((int) '4');
        org.jfree.chart.plot.Plot plot20 = categoryPlot11.getParent();
        org.jfree.data.category.CategoryDataset categoryDataset21 = categoryPlot11.getDataset();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNull(valueAxis14);
        org.junit.Assert.assertNull(categoryAxis16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertNull(plot20);
        org.junit.Assert.assertNull(categoryDataset21);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getUpperBound();
        boolean boolean3 = numberAxis1.getAutoRangeStickyZero();
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        double double5 = numberAxis4.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock8 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D9 = labelBlock8.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity12 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D9, "", "Preceding");
        numberAxis4.setDownArrow((java.awt.Shape) rectangle2D9);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = numberAxis4.getLabelInsets();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot15.setRangeCrosshairValue((double) (byte) 1);
        org.jfree.chart.axis.ValueAxis valueAxis18 = categoryPlot15.getRangeAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = categoryPlot15.getDomainAxis((int) ' ');
        boolean boolean21 = numberAxis4.hasListener((java.util.EventListener) categoryPlot15);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis4, xYItemRenderer22);
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis();
        double double27 = numberAxis26.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock30 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D31 = labelBlock30.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity34 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D31, "", "Preceding");
        numberAxis26.setDownArrow((java.awt.Shape) rectangle2D31);
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = numberAxis26.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis();
        double double38 = numberAxis37.getUpperBound();
        boolean boolean39 = numberAxis37.getAutoRangeStickyZero();
        boolean boolean40 = numberAxis37.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer41 = null;
        org.jfree.chart.plot.XYPlot xYPlot42 = new org.jfree.chart.plot.XYPlot(xYDataset25, (org.jfree.chart.axis.ValueAxis) numberAxis26, (org.jfree.chart.axis.ValueAxis) numberAxis37, xYItemRenderer41);
        xYPlot42.setRangeCrosshairVisible(false);
        org.jfree.chart.JFreeChart jFreeChart45 = new org.jfree.chart.JFreeChart("WMAP_Plot", (org.jfree.chart.plot.Plot) xYPlot42);
        boolean boolean46 = jFreeChart45.isNotify();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType47 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent48 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYItemRenderer22, jFreeChart45, chartChangeEventType47);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D9);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNull(valueAxis18);
        org.junit.Assert.assertNull(categoryAxis20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 1.0d + "'", double27 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 1.0d + "'", double38 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(chartChangeEventType47);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE3;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation5 = categoryPlot0.getDomainAxisLocation((int) '4');
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis6.setLowerMargin((double) 10.0f);
        org.jfree.data.general.WaferMapDataset waferMapDataset9 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot10 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset9);
        float float11 = waferMapPlot10.getForegroundAlpha();
        java.lang.String str12 = waferMapPlot10.getPlotType();
        boolean boolean13 = categoryAxis6.equals((java.lang.Object) str12);
        categoryAxis6.clearCategoryLabelToolTips();
        java.util.List list15 = categoryPlot0.getCategoriesForAxis(categoryAxis6);
        categoryPlot0.clearDomainMarkers(100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 1.0f + "'", float11 == 1.0f);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "WMAP_Plot" + "'", str12.equals("WMAP_Plot"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(list15);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.data.time.DateRange dateRange0 = new org.jfree.data.time.DateRange();
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        java.text.AttributedString attributedString0 = null;
        org.jfree.data.general.WaferMapDataset waferMapDataset4 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot5 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.block.LabelBlock labelBlock9 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D10 = labelBlock9.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity13 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D10, "", "Preceding");
        waferMapPlot5.drawBackgroundImage(graphics2D6, rectangle2D10);
        org.jfree.chart.entity.ChartEntity chartEntity16 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D10, "Preceding");
        java.awt.Shape shape19 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape) rectangle2D10, 12.0d, (double) 10);
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis();
        double double22 = numberAxis21.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock25 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D26 = labelBlock25.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity29 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D26, "", "Preceding");
        numberAxis21.setDownArrow((java.awt.Shape) rectangle2D26);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = numberAxis21.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis();
        double double33 = numberAxis32.getUpperBound();
        boolean boolean34 = numberAxis32.getAutoRangeStickyZero();
        boolean boolean35 = numberAxis32.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer36 = null;
        org.jfree.chart.plot.XYPlot xYPlot37 = new org.jfree.chart.plot.XYPlot(xYDataset20, (org.jfree.chart.axis.ValueAxis) numberAxis21, (org.jfree.chart.axis.ValueAxis) numberAxis32, xYItemRenderer36);
        org.jfree.data.xy.XYDataset xYDataset38 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer39 = xYPlot37.getRendererForDataset(xYDataset38);
        org.jfree.chart.axis.AxisSpace axisSpace40 = xYPlot37.getFixedDomainAxisSpace();
        boolean boolean41 = xYPlot37.isDomainZeroBaselineVisible();
        java.awt.Stroke stroke42 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYPlot37.setDomainCrosshairStroke(stroke42);
        java.awt.Color color44 = java.awt.Color.PINK;
        try {
            org.jfree.chart.LegendItem legendItem45 = new org.jfree.chart.LegendItem(attributedString0, "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "CategoryLabelWidthType.CATEGORY", "First", (java.awt.Shape) rectangle2D10, stroke42, (java.awt.Paint) color44);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.0d + "'", double33 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNull(xYItemRenderer39);
        org.junit.Assert.assertNull(axisSpace40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(color44);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.START;
        java.lang.String str1 = dateTickMarkPosition0.toString();
        java.lang.String str2 = dateTickMarkPosition0.toString();
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DateTickMarkPosition.START" + "'", str1.equals("DateTickMarkPosition.START"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "DateTickMarkPosition.START" + "'", str2.equals("DateTickMarkPosition.START"));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D3 = labelBlock2.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity6 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D3, "", "Preceding");
        org.jfree.chart.entity.LegendItemEntity legendItemEntity7 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D3);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint9 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        statisticalBarRenderer8.setBasePaint(paint9);
        org.jfree.chart.title.LegendGraphic legendGraphic11 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape) rectangle2D3, paint9);
        java.awt.Shape shape12 = legendGraphic11.getLine();
        legendGraphic11.setShapeVisible(false);
        org.junit.Assert.assertNotNull(rectangle2D3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(shape12);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        double double3 = numberAxis2.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D7 = labelBlock6.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity10 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D7, "", "Preceding");
        numberAxis2.setDownArrow((java.awt.Shape) rectangle2D7);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = numberAxis2.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        double double14 = numberAxis13.getUpperBound();
        boolean boolean15 = numberAxis13.getAutoRangeStickyZero();
        boolean boolean16 = numberAxis13.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis13, xYItemRenderer17);
        xYPlot18.setRangeCrosshairVisible(false);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("WMAP_Plot", (org.jfree.chart.plot.Plot) xYPlot18);
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle();
        jFreeChart21.addSubtitle((org.jfree.chart.title.Title) textTitle22);
        org.jfree.chart.title.TextTitle textTitle24 = new org.jfree.chart.title.TextTitle();
        java.lang.String str25 = textTitle24.getURLText();
        jFreeChart21.addSubtitle((org.jfree.chart.title.Title) textTitle24);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo30 = null;
        try {
            java.awt.image.BufferedImage bufferedImage31 = jFreeChart21.createBufferedImage(11, 2019, 0, chartRenderingInfo30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown image type 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNull(str25);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D6 = labelBlock5.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D6, "", "Preceding");
        numberAxis1.setDownArrow((java.awt.Shape) rectangle2D6);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis1.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        double double13 = numberAxis12.getUpperBound();
        boolean boolean14 = numberAxis12.getAutoRangeStickyZero();
        boolean boolean15 = numberAxis12.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer16);
        xYPlot17.setRangeCrosshairVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = xYPlot17.getRangeAxisEdge(1);
        xYPlot17.mapDatasetToRangeAxis(500, 0);
        org.jfree.data.general.PieDataset pieDataset25 = null;
        org.jfree.chart.plot.PiePlot piePlot26 = new org.jfree.chart.plot.PiePlot(pieDataset25);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator27 = piePlot26.getToolTipGenerator();
        double double28 = piePlot26.getMaximumLabelWidth();
        piePlot26.setStartAngle((double) 200);
        xYPlot17.setParent((org.jfree.chart.plot.Plot) piePlot26);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder32 = null;
        try {
            xYPlot17.setSeriesRenderingOrder(seriesRenderingOrder32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertNull(pieToolTipGenerator27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.2d + "'", double28 == 0.2d);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        boolean boolean1 = textTitle0.getExpandToFitSpace();
        java.lang.String str2 = textTitle0.getURLText();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 1L, (double) 31);
        boolean boolean4 = stackedBarRenderer3D2.equals((java.lang.Object) (-1.0f));
        double double5 = stackedBarRenderer3D2.getUpperClip();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = categoryPlot7.getAxisOffset();
        org.jfree.chart.block.LabelBlock labelBlock11 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D12 = labelBlock11.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity15 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D12, "", "Preceding");
        org.jfree.chart.entity.LegendItemEntity legendItemEntity16 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D12);
        java.awt.geom.Rectangle2D rectangle2D17 = rectangleInsets8.createOutsetRectangle(rectangle2D12);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer18 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator20 = statisticalBarRenderer18.getSeriesURLGenerator((int) (short) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer21 = null;
        statisticalBarRenderer18.setGradientPaintTransformer(gradientPaintTransformer21);
        java.awt.Paint paint24 = statisticalBarRenderer18.lookupSeriesFillPaint(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition25 = null;
        statisticalBarRenderer18.setNegativeItemLabelPositionFallback(itemLabelPosition25);
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot27.setRangeCrosshairValue((double) (byte) 1);
        org.jfree.chart.axis.ValueAxis valueAxis30 = categoryPlot27.getRangeAxis();
        categoryPlot27.setRangeCrosshairValue((double) '#');
        statisticalBarRenderer18.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot27);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState36 = stackedBarRenderer3D2.initialise(graphics2D6, rectangle2D12, categoryPlot27, 9, plotRenderingInfo35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNull(categoryURLGenerator20);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNull(valueAxis30);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D6 = labelBlock5.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D6, "", "Preceding");
        numberAxis1.setDownArrow((java.awt.Shape) rectangle2D6);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis1.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        double double13 = numberAxis12.getUpperBound();
        boolean boolean14 = numberAxis12.getAutoRangeStickyZero();
        boolean boolean15 = numberAxis12.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer16);
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        xYPlot17.setDataset(5, xYDataset19);
        org.jfree.chart.util.Layer layer21 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection22 = xYPlot17.getRangeMarkers(layer21);
        org.jfree.chart.plot.PlotOrientation plotOrientation23 = null;
        try {
            xYPlot17.setOrientation(plotOrientation23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(layer21);
        org.junit.Assert.assertNull(collection22);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D6 = labelBlock5.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D6, "", "Preceding");
        numberAxis1.setDownArrow((java.awt.Shape) rectangle2D6);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis1.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        double double13 = numberAxis12.getUpperBound();
        boolean boolean14 = numberAxis12.getAutoRangeStickyZero();
        boolean boolean15 = numberAxis12.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer16);
        xYPlot17.clearDomainAxes();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent19 = null;
        xYPlot17.datasetChanged(datasetChangeEvent19);
        org.jfree.chart.LegendItemCollection legendItemCollection21 = xYPlot17.getFixedLegendItems();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(legendItemCollection21);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("SortOrder.ASCENDING");
        categoryAxis3D1.setLabelAngle((double) 11);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D5 = labelBlock4.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity8 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D5, "", "Preceding");
        numberAxis0.setDownArrow((java.awt.Shape) rectangle2D5);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = numberAxis0.getLabelInsets();
        boolean boolean11 = numberAxis0.isVerticalTickLabels();
        numberAxis0.setAutoRangeStickyZero(true);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        double double3 = numberAxis2.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D7 = labelBlock6.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity10 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D7, "", "Preceding");
        numberAxis2.setDownArrow((java.awt.Shape) rectangle2D7);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = numberAxis2.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        double double14 = numberAxis13.getUpperBound();
        boolean boolean15 = numberAxis13.getAutoRangeStickyZero();
        boolean boolean16 = numberAxis13.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis13, xYItemRenderer17);
        xYPlot18.setRangeCrosshairVisible(false);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("WMAP_Plot", (org.jfree.chart.plot.Plot) xYPlot18);
        boolean boolean22 = jFreeChart21.isNotify();
        java.awt.Image image23 = null;
        jFreeChart21.setBackgroundImage(image23);
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.block.LabelBlock labelBlock28 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D29 = labelBlock28.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity32 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D29, "", "Preceding");
        org.jfree.chart.entity.LegendItemEntity legendItemEntity33 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D29);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer34 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint35 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        statisticalBarRenderer34.setBasePaint(paint35);
        org.jfree.chart.title.LegendGraphic legendGraphic37 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape) rectangle2D29, paint35);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo38 = null;
        try {
            jFreeChart21.draw(graphics2D25, rectangle2D29, chartRenderingInfo38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertNotNull(paint35);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D6 = labelBlock5.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D6, "", "Preceding");
        numberAxis1.setDownArrow((java.awt.Shape) rectangle2D6);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis1.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        double double13 = numberAxis12.getUpperBound();
        boolean boolean14 = numberAxis12.getAutoRangeStickyZero();
        boolean boolean15 = numberAxis12.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer16);
        xYPlot17.setRangeCrosshairVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean22 = categoryPlot21.isDomainGridlinesVisible();
        org.jfree.chart.axis.AxisLocation axisLocation23 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot21.setDomainAxisLocation(axisLocation23);
        xYPlot17.setRangeAxisLocation((int) (byte) 10, axisLocation23);
        org.jfree.data.xy.XYDataset xYDataset26 = xYPlot17.getDataset();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertNull(xYDataset26);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D6 = labelBlock5.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D6, "", "Preceding");
        numberAxis1.setDownArrow((java.awt.Shape) rectangle2D6);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis1.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        double double13 = numberAxis12.getUpperBound();
        boolean boolean14 = numberAxis12.getAutoRangeStickyZero();
        boolean boolean15 = numberAxis12.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer16);
        xYPlot17.clearDomainAxes();
        java.awt.Stroke stroke19 = xYPlot17.getDomainGridlineStroke();
        java.awt.Color color20 = java.awt.Color.PINK;
        java.awt.color.ColorSpace colorSpace21 = color20.getColorSpace();
        xYPlot17.setRangeTickBandPaint((java.awt.Paint) color20);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(colorSpace21);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.CLASS_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ClassContext" + "'", str0.equals("ClassContext"));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        int int0 = org.jfree.data.time.SerialDate.FRIDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        int int0 = org.jfree.data.time.SerialDate.THURSDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = statisticalBarRenderer0.getSeriesURLGenerator((int) (short) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        statisticalBarRenderer0.setGradientPaintTransformer(gradientPaintTransformer3);
        java.awt.Paint paint6 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        statisticalBarRenderer0.setSeriesOutlinePaint(2019, paint6);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer9 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.block.LabelBlock labelBlock12 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D13 = labelBlock12.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity16 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D13, "", "Preceding");
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double18 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D13, rectangleEdge17);
        statisticalBarRenderer9.setBaseShape((java.awt.Shape) rectangle2D13, true);
        statisticalBarRenderer0.setSeriesShape(1, (java.awt.Shape) rectangle2D13);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator23 = statisticalBarRenderer0.getSeriesItemLabelGenerator((int) (byte) -1);
        org.junit.Assert.assertNull(categoryURLGenerator2);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNull(categoryItemLabelGenerator23);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        double double4 = numberAxis3.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock7 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D8 = labelBlock7.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity11 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D8, "", "Preceding");
        numberAxis3.setDownArrow((java.awt.Shape) rectangle2D8);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = numberAxis3.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        double double15 = numberAxis14.getUpperBound();
        boolean boolean16 = numberAxis14.getAutoRangeStickyZero();
        boolean boolean17 = numberAxis14.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis14, xYItemRenderer18);
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        xYPlot19.setDataset(5, xYDataset21);
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        double[] doubleArray28 = new double[] { (-1L), 0.0d };
        double[] doubleArray31 = new double[] { (-1L), 0.0d };
        double[] doubleArray34 = new double[] { (-1L), 0.0d };
        double[] doubleArray37 = new double[] { (-1L), 0.0d };
        double[][] doubleArray38 = new double[][] { doubleArray28, doubleArray31, doubleArray34, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", doubleArray38);
        org.jfree.data.Range range40 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset39);
        java.lang.Number number41 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset39);
        java.lang.Number number42 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset39);
        java.lang.Number number43 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset39);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent44 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) color23, (org.jfree.data.general.Dataset) categoryDataset39);
        xYPlot19.datasetChanged(datasetChangeEvent44);
        boolean boolean46 = standardGradientPaintTransformer1.equals((java.lang.Object) xYPlot19);
        java.awt.GradientPaint gradientPaint47 = null;
        org.jfree.chart.axis.NumberAxis numberAxis48 = new org.jfree.chart.axis.NumberAxis();
        double double49 = numberAxis48.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock52 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D53 = labelBlock52.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity56 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D53, "", "Preceding");
        numberAxis48.setDownArrow((java.awt.Shape) rectangle2D53);
        org.jfree.chart.util.RectangleInsets rectangleInsets58 = numberAxis48.getLabelInsets();
        java.awt.Shape shape60 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
        numberAxis48.setRightArrow(shape60);
        java.awt.Shape shape62 = org.jfree.chart.util.ShapeUtilities.clone(shape60);
        try {
            java.awt.GradientPaint gradientPaint63 = standardGradientPaintTransformer1.transform(gradientPaint47, shape62);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range40);
        org.junit.Assert.assertTrue("'" + number41 + "' != '" + 0.0d + "'", number41.equals(0.0d));
        org.junit.Assert.assertTrue("'" + number42 + "' != '" + 0.0d + "'", number42.equals(0.0d));
        org.junit.Assert.assertTrue("'" + number43 + "' != '" + 0.0d + "'", number43.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 1.0d + "'", double49 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D53);
        org.junit.Assert.assertNotNull(rectangleInsets58);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertNotNull(shape62);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = statisticalBarRenderer0.getSeriesURLGenerator((int) (short) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        statisticalBarRenderer0.setGradientPaintTransformer(gradientPaintTransformer3);
        java.awt.Paint paint6 = statisticalBarRenderer0.lookupSeriesFillPaint(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = null;
        statisticalBarRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition7);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot9.setRangeCrosshairValue((double) (byte) 1);
        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot9.getRangeAxis();
        categoryPlot9.setRangeCrosshairValue((double) '#');
        statisticalBarRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot9);
        boolean boolean16 = categoryPlot9.isOutlineVisible();
        org.junit.Assert.assertNull(categoryURLGenerator2);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(true);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        statisticalBarRenderer0.setBasePaint(paint1);
        boolean boolean3 = statisticalBarRenderer0.getIncludeBaseInRange();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer4.setSeriesLinesVisible((int) '4', (java.lang.Boolean) true);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor9 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE7;
        org.jfree.chart.text.TextAnchor textAnchor10 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor11 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor9, textAnchor10, textAnchor11, (double) 0L);
        lineAndShapeRenderer4.setSeriesNegativeItemLabelPosition((int) '4', itemLabelPosition13);
        statisticalBarRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition13);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = statisticalBarRenderer0.getPlot();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(itemLabelAnchor9);
        org.junit.Assert.assertNotNull(textAnchor10);
        org.junit.Assert.assertNotNull(textAnchor11);
        org.junit.Assert.assertNull(categoryPlot16);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        int int0 = org.jfree.data.time.SerialDate.FOLLOWING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator3 = piePlot2.getToolTipGenerator();
        java.awt.Color color4 = java.awt.Color.gray;
        piePlot2.setLabelShadowPaint((java.awt.Paint) color4);
        piePlot2.setExplodePercent((java.lang.Comparable) 8.0d, (double) 7);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        double double10 = numberAxis9.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock13 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D14 = labelBlock13.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity17 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D14, "", "Preceding");
        numberAxis9.setDownArrow((java.awt.Shape) rectangle2D14);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = numberAxis9.getLabelInsets();
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
        numberAxis9.setRightArrow(shape21);
        java.awt.Paint paint23 = numberAxis9.getLabelPaint();
        piePlot2.setBaseSectionPaint(paint23);
        org.jfree.chart.util.Rotation rotation25 = piePlot2.getDirection();
        boolean boolean26 = piePlot2.getSectionOutlinesVisible();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit28 = new org.jfree.chart.axis.NumberTickUnit((double) 100L);
        java.awt.Paint paint29 = piePlot2.getSectionOutlinePaint((java.lang.Comparable) numberTickUnit28);
        int int30 = keyedObjects2D0.getRowIndex((java.lang.Comparable) numberTickUnit28);
        try {
            keyedObjects2D0.removeColumn((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(pieToolTipGenerator3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(rotation25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNull(paint29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.chart.block.BlockResult blockResult0 = new org.jfree.chart.block.BlockResult();
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D6 = labelBlock5.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D6, "", "Preceding");
        numberAxis1.setDownArrow((java.awt.Shape) rectangle2D6);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis1.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        double double13 = numberAxis12.getUpperBound();
        boolean boolean14 = numberAxis12.getAutoRangeStickyZero();
        boolean boolean15 = numberAxis12.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer16);
        xYPlot17.setRangeCrosshairVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean22 = categoryPlot21.isDomainGridlinesVisible();
        org.jfree.chart.axis.AxisLocation axisLocation23 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot21.setDomainAxisLocation(axisLocation23);
        xYPlot17.setRangeAxisLocation((int) (byte) 10, axisLocation23);
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis();
        double double27 = numberAxis26.getUpperBound();
        boolean boolean28 = numberAxis26.getAutoRangeStickyZero();
        boolean boolean29 = numberAxis26.isAutoRange();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand30 = numberAxis26.getMarkerBand();
        java.awt.Shape shape31 = numberAxis26.getUpArrow();
        numberAxis26.setVerticalTickLabels(false);
        int int34 = xYPlot17.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis26);
        java.awt.Paint paint35 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        xYPlot17.setDomainGridlinePaint(paint35);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 1.0d + "'", double27 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNull(markerAxisBand30);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertNotNull(paint35);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge((int) (short) 0);
        float float4 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        categoryPlot0.setRenderer((int) (short) 100, categoryItemRenderer6, true);
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        double double11 = numberAxis10.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock14 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D15 = labelBlock14.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity18 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D15, "", "Preceding");
        numberAxis10.setDownArrow((java.awt.Shape) rectangle2D15);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = numberAxis10.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis();
        double double22 = numberAxis21.getUpperBound();
        boolean boolean23 = numberAxis21.getAutoRangeStickyZero();
        boolean boolean24 = numberAxis21.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer25 = null;
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot(xYDataset9, (org.jfree.chart.axis.ValueAxis) numberAxis10, (org.jfree.chart.axis.ValueAxis) numberAxis21, xYItemRenderer25);
        boolean boolean27 = xYPlot26.isDomainCrosshairVisible();
        org.jfree.chart.axis.AxisLocation axisLocation29 = xYPlot26.getRangeAxisLocation((int) (short) -1);
        categoryPlot0.setRangeAxisLocation(axisLocation29);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(axisLocation29);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType2 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition4 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1, categoryLabelWidthType2, (float) 2958465);
        java.lang.String str5 = categoryLabelWidthType2.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(categoryLabelWidthType2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "CategoryLabelWidthType.CATEGORY" + "'", str5.equals("CategoryLabelWidthType.CATEGORY"));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        double double4 = numberAxis3.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock7 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D8 = labelBlock7.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity11 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D8, "", "Preceding");
        numberAxis3.setDownArrow((java.awt.Shape) rectangle2D8);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = numberAxis3.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        double double15 = numberAxis14.getUpperBound();
        boolean boolean16 = numberAxis14.getAutoRangeStickyZero();
        boolean boolean17 = numberAxis14.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis14, xYItemRenderer18);
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        xYPlot19.setDataset(5, xYDataset21);
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        double[] doubleArray28 = new double[] { (-1L), 0.0d };
        double[] doubleArray31 = new double[] { (-1L), 0.0d };
        double[] doubleArray34 = new double[] { (-1L), 0.0d };
        double[] doubleArray37 = new double[] { (-1L), 0.0d };
        double[][] doubleArray38 = new double[][] { doubleArray28, doubleArray31, doubleArray34, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", doubleArray38);
        org.jfree.data.Range range40 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset39);
        java.lang.Number number41 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset39);
        java.lang.Number number42 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset39);
        java.lang.Number number43 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset39);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent44 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) color23, (org.jfree.data.general.Dataset) categoryDataset39);
        xYPlot19.datasetChanged(datasetChangeEvent44);
        boolean boolean46 = standardGradientPaintTransformer1.equals((java.lang.Object) xYPlot19);
        java.lang.Object obj47 = standardGradientPaintTransformer1.clone();
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range40);
        org.junit.Assert.assertTrue("'" + number41 + "' != '" + 0.0d + "'", number41.equals(0.0d));
        org.junit.Assert.assertTrue("'" + number42 + "' != '" + 0.0d + "'", number42.equals(0.0d));
        org.junit.Assert.assertTrue("'" + number43 + "' != '" + 0.0d + "'", number43.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(obj47);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 1L, (double) 31);
        boolean boolean4 = stackedBarRenderer3D2.equals((java.lang.Object) (-1.0f));
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = null;
        stackedBarRenderer3D2.setLegendItemToolTipGenerator(categorySeriesLabelGenerator5);
        java.awt.Paint paint8 = stackedBarRenderer3D2.lookupSeriesFillPaint((int) ' ');
        java.awt.Paint paint9 = stackedBarRenderer3D2.getWallPaint();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 1L, (double) 31);
        boolean boolean4 = stackedBarRenderer3D2.equals((java.lang.Object) (-1.0f));
        double double5 = stackedBarRenderer3D2.getUpperClip();
        java.awt.Color color7 = java.awt.Color.BLUE;
        stackedBarRenderer3D2.setSeriesPaint(12, (java.awt.Paint) color7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState10 = null;
        org.jfree.data.general.WaferMapDataset waferMapDataset11 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot12 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset11);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.block.LabelBlock labelBlock16 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D17 = labelBlock16.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity20 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D17, "", "Preceding");
        waferMapPlot12.drawBackgroundImage(graphics2D13, rectangle2D17);
        org.jfree.chart.entity.ChartEntity chartEntity23 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D17, "Preceding");
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape) rectangle2D17, 12.0d, (double) 10);
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean28 = categoryPlot27.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = categoryPlot27.getDomainAxisEdge((int) (short) 0);
        categoryPlot27.setAnchorValue((double) 10.0f, false);
        org.jfree.data.category.CategoryDataset categoryDataset35 = categoryPlot27.getDataset(2019);
        org.jfree.chart.event.PlotChangeListener plotChangeListener36 = null;
        categoryPlot27.removeChangeListener(plotChangeListener36);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D38 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean39 = categoryAxis3D38.isAxisLineVisible();
        org.jfree.chart.axis.NumberAxis numberAxis40 = new org.jfree.chart.axis.NumberAxis();
        double double41 = numberAxis40.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock44 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D45 = labelBlock44.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity48 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D45, "", "Preceding");
        numberAxis40.setDownArrow((java.awt.Shape) rectangle2D45);
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = numberAxis40.getLabelInsets();
        numberAxis40.setVerticalTickLabels(true);
        numberAxis40.setFixedAutoRange((double) 0);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset55 = new org.jfree.data.category.DefaultCategoryDataset();
        try {
            stackedBarRenderer3D2.drawItem(graphics2D9, categoryItemRendererState10, rectangle2D17, categoryPlot27, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D38, (org.jfree.chart.axis.ValueAxis) numberAxis40, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset55, (int) (short) 1, (int) ' ', (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertNull(categoryDataset35);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 1.0d + "'", double41 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D45);
        org.junit.Assert.assertNotNull(rectangleInsets50);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D6 = labelBlock5.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D6, "", "Preceding");
        numberAxis1.setDownArrow((java.awt.Shape) rectangle2D6);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis1.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        double double13 = numberAxis12.getUpperBound();
        boolean boolean14 = numberAxis12.getAutoRangeStickyZero();
        boolean boolean15 = numberAxis12.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer16);
        java.awt.Paint paint18 = xYPlot17.getRangeTickBandPaint();
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis();
        numberAxis20.zoomRange((double) 1900, (double) 1900);
        xYPlot17.setDomainAxis(5, (org.jfree.chart.axis.ValueAxis) numberAxis20, false);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(paint18);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator3 = piePlot2.getToolTipGenerator();
        java.awt.Color color4 = java.awt.Color.gray;
        piePlot2.setLabelShadowPaint((java.awt.Paint) color4);
        piePlot2.setExplodePercent((java.lang.Comparable) 8.0d, (double) 7);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        double double10 = numberAxis9.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock13 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D14 = labelBlock13.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity17 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D14, "", "Preceding");
        numberAxis9.setDownArrow((java.awt.Shape) rectangle2D14);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = numberAxis9.getLabelInsets();
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
        numberAxis9.setRightArrow(shape21);
        java.awt.Paint paint23 = numberAxis9.getLabelPaint();
        piePlot2.setBaseSectionPaint(paint23);
        org.jfree.chart.util.Rotation rotation25 = piePlot2.getDirection();
        boolean boolean26 = piePlot2.getSectionOutlinesVisible();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit28 = new org.jfree.chart.axis.NumberTickUnit((double) 100L);
        java.awt.Paint paint29 = piePlot2.getSectionOutlinePaint((java.lang.Comparable) numberTickUnit28);
        int int30 = keyedObjects2D0.getRowIndex((java.lang.Comparable) numberTickUnit28);
        java.awt.Paint paint31 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        int int32 = numberTickUnit28.compareTo((java.lang.Object) paint31);
        org.junit.Assert.assertNull(pieToolTipGenerator3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(rotation25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNull(paint29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge((int) (short) 0);
        categoryPlot0.setAnchorValue((double) 10.0f, false);
        org.jfree.data.category.CategoryDataset categoryDataset8 = categoryPlot0.getDataset(2019);
        java.awt.Paint paint9 = categoryPlot0.getRangeCrosshairPaint();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNull(categoryDataset8);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.junit.Assert.assertNotNull(plotOrientation0);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D3 = labelBlock2.getBounds();
        boolean boolean5 = labelBlock2.equals((java.lang.Object) 1);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        double double8 = numberAxis7.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock11 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D12 = labelBlock11.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity15 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D12, "", "Preceding");
        numberAxis7.setDownArrow((java.awt.Shape) rectangle2D12);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = numberAxis7.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis();
        double double19 = numberAxis18.getUpperBound();
        boolean boolean20 = numberAxis18.getAutoRangeStickyZero();
        boolean boolean21 = numberAxis18.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) numberAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis18, xYItemRenderer22);
        xYPlot23.setRangeCrosshairVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = xYPlot23.getRangeAxisEdge(1);
        int int28 = xYPlot23.getDomainAxisCount();
        columnArrangement0.add((org.jfree.chart.block.Block) labelBlock2, (java.lang.Object) xYPlot23);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation30 = null;
        try {
            xYPlot23.addAnnotation(xYAnnotation30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation5 = categoryPlot0.getDomainAxisLocation((int) '4');
        org.jfree.chart.axis.AxisSpace axisSpace6 = new org.jfree.chart.axis.AxisSpace();
        categoryPlot0.setFixedRangeAxisSpace(axisSpace6);
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot0);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        double double10 = numberAxis9.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock13 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D14 = labelBlock13.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity17 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D14, "", "Preceding");
        numberAxis9.setDownArrow((java.awt.Shape) rectangle2D14);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = numberAxis9.getLabelInsets();
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
        numberAxis9.setRightArrow(shape21);
        java.awt.Paint paint23 = numberAxis9.getLabelPaint();
        boolean boolean24 = legendTitle8.equals((java.lang.Object) numberAxis9);
        legendTitle8.setMargin((double) 15, (double) (byte) 10, (double) 3, (double) 9);
        java.awt.Graphics2D graphics2D30 = null;
        org.jfree.data.general.WaferMapDataset waferMapDataset31 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot32 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset31);
        java.awt.Graphics2D graphics2D33 = null;
        org.jfree.chart.block.LabelBlock labelBlock36 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D37 = labelBlock36.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity40 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D37, "", "Preceding");
        waferMapPlot32.drawBackgroundImage(graphics2D33, rectangle2D37);
        org.jfree.chart.entity.ChartEntity chartEntity43 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D37, "Preceding");
        try {
            legendTitle8.draw(graphics2D30, rectangle2D37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(rectangle2D37);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = new org.jfree.chart.axis.CategoryLabelPositions();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        double double3 = numberAxis2.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D7 = labelBlock6.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity10 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D7, "", "Preceding");
        numberAxis2.setDownArrow((java.awt.Shape) rectangle2D7);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = numberAxis2.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        double double14 = numberAxis13.getUpperBound();
        boolean boolean15 = numberAxis13.getAutoRangeStickyZero();
        boolean boolean16 = numberAxis13.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis13, xYItemRenderer17);
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        xYPlot18.setDataset(5, xYDataset20);
        int int22 = xYPlot18.getRangeAxisCount();
        boolean boolean23 = categoryLabelPositions0.equals((java.lang.Object) int22);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range1 = numberAxis0.getDefaultAutoRange();
        boolean boolean3 = numberAxis0.equals((java.lang.Object) (byte) -1);
        java.awt.Color color4 = java.awt.Color.RED;
        java.awt.Color color5 = color4.darker();
        numberAxis0.setTickLabelPaint((java.awt.Paint) color4);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator9 = piePlot8.getToolTipGenerator();
        java.awt.Color color10 = java.awt.Color.gray;
        piePlot8.setLabelShadowPaint((java.awt.Paint) color10);
        piePlot8.setExplodePercent((java.lang.Comparable) 8.0d, (double) 7);
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis();
        double double16 = numberAxis15.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock19 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D20 = labelBlock19.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity23 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D20, "", "Preceding");
        numberAxis15.setDownArrow((java.awt.Shape) rectangle2D20);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = numberAxis15.getLabelInsets();
        java.awt.Shape shape27 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
        numberAxis15.setRightArrow(shape27);
        java.awt.Paint paint29 = numberAxis15.getLabelPaint();
        piePlot8.setBaseSectionPaint(paint29);
        org.jfree.chart.util.Rotation rotation31 = piePlot8.getDirection();
        boolean boolean32 = piePlot8.getSectionOutlinesVisible();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit34 = new org.jfree.chart.axis.NumberTickUnit((double) 100L);
        java.awt.Paint paint35 = piePlot8.getSectionOutlinePaint((java.lang.Comparable) numberTickUnit34);
        numberAxis0.setTickUnit(numberTickUnit34, false, true);
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(pieToolTipGenerator9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(rotation31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNull(paint35);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = statisticalBarRenderer0.getSeriesURLGenerator((int) (short) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        statisticalBarRenderer0.setGradientPaintTransformer(gradientPaintTransformer3);
        java.awt.Paint paint7 = statisticalBarRenderer0.getItemPaint((int) (byte) 100, (int) '#');
        statisticalBarRenderer0.setSeriesCreateEntities(31, (java.lang.Boolean) true);
        java.awt.Color color12 = java.awt.Color.orange;
        int int13 = color12.getGreen();
        float[] floatArray19 = new float[] { (short) 0, 10.0f, (short) 10, (byte) 0, 0.0f };
        float[] floatArray20 = color12.getColorComponents(floatArray19);
        statisticalBarRenderer0.setSeriesPaint(0, (java.awt.Paint) color12, true);
        boolean boolean23 = statisticalBarRenderer0.getBaseItemLabelsVisible();
        org.junit.Assert.assertNull(categoryURLGenerator2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 200 + "'", int13 == 200);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        java.awt.Color color1 = java.awt.Color.GRAY;
        int int2 = color1.getTransparency();
        int int3 = color1.getAlpha();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke5 = statisticalBarRenderer4.getBaseStroke();
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator8 = piePlot7.getToolTipGenerator();
        java.awt.Color color9 = java.awt.Color.gray;
        piePlot7.setLabelShadowPaint((java.awt.Paint) color9);
        piePlot7.setExplodePercent((java.lang.Comparable) 8.0d, (double) 7);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        double double15 = numberAxis14.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock18 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D19 = labelBlock18.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity22 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D19, "", "Preceding");
        numberAxis14.setDownArrow((java.awt.Shape) rectangle2D19);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = numberAxis14.getLabelInsets();
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
        numberAxis14.setRightArrow(shape26);
        java.awt.Paint paint28 = numberAxis14.getLabelPaint();
        piePlot7.setBaseSectionPaint(paint28);
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis();
        double double32 = numberAxis31.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock35 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D36 = labelBlock35.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity39 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D36, "", "Preceding");
        numberAxis31.setDownArrow((java.awt.Shape) rectangle2D36);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = numberAxis31.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis42 = new org.jfree.chart.axis.NumberAxis();
        double double43 = numberAxis42.getUpperBound();
        boolean boolean44 = numberAxis42.getAutoRangeStickyZero();
        boolean boolean45 = numberAxis42.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer46 = null;
        org.jfree.chart.plot.XYPlot xYPlot47 = new org.jfree.chart.plot.XYPlot(xYDataset30, (org.jfree.chart.axis.ValueAxis) numberAxis31, (org.jfree.chart.axis.ValueAxis) numberAxis42, xYItemRenderer46);
        xYPlot47.setRangeCrosshairVisible(false);
        java.lang.String str50 = xYPlot47.getPlotType();
        java.awt.Stroke stroke51 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot47.setRangeZeroBaselineStroke(stroke51);
        try {
            org.jfree.chart.plot.ValueMarker valueMarker54 = new org.jfree.chart.plot.ValueMarker((double) 1, (java.awt.Paint) color1, stroke5, paint28, stroke51, (float) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 255 + "'", int3 == 255);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNull(pieToolTipGenerator8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0d + "'", double32 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D36);
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 1.0d + "'", double43 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "XY Plot" + "'", str50.equals("XY Plot"));
        org.junit.Assert.assertNotNull(stroke51);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) (byte) 100, (double) (short) 100);
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.data.time.DateRange dateRange7 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double8 = dateRange7.getCentralValue();
        org.jfree.data.time.DateRange dateRange9 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double10 = dateRange9.getCentralValue();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange7, (org.jfree.data.Range) dateRange9);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint11.toFixedHeight((double) 10.0f);
        java.lang.String str14 = rectangleConstraint13.toString();
        org.jfree.chart.util.Size2D size2D15 = blockContainer5.arrange(graphics2D6, rectangleConstraint13);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(dateRange7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.5d + "'", double8 == 0.5d);
        org.junit.Assert.assertNotNull(dateRange9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.5d + "'", double10 == 0.5d);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=10.0]" + "'", str14.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=10.0]"));
        org.junit.Assert.assertNotNull(size2D15);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = statisticalBarRenderer0.getSeriesURLGenerator((int) (short) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        statisticalBarRenderer0.setGradientPaintTransformer(gradientPaintTransformer3);
        java.awt.Paint paint7 = statisticalBarRenderer0.getItemPaint((int) (byte) 100, (int) '#');
        java.awt.Shape shape9 = statisticalBarRenderer0.getSeriesShape(3);
        boolean boolean10 = statisticalBarRenderer0.getAutoPopulateSeriesOutlineStroke();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer11 = statisticalBarRenderer0.getGradientPaintTransformer();
        org.junit.Assert.assertNull(categoryURLGenerator2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(shape9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(gradientPaintTransformer11);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        java.lang.String str1 = verticalAlignment0.toString();
        org.junit.Assert.assertNotNull(verticalAlignment0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "VerticalAlignment.BOTTOM" + "'", str1.equals("VerticalAlignment.BOTTOM"));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot4.setRangeCrosshairValue((double) (byte) 1);
        java.awt.Color color7 = java.awt.Color.PINK;
        java.awt.color.ColorSpace colorSpace8 = color7.getColorSpace();
        categoryPlot4.setRangeCrosshairPaint((java.awt.Paint) color7);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis10.setLowerMargin((double) 10.0f);
        java.awt.Paint paint14 = categoryAxis10.getTickLabelPaint((java.lang.Comparable) 7);
        categoryAxis10.setLowerMargin((double) 31);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot17.setRangeCrosshairValue((double) (byte) 1);
        org.jfree.chart.axis.ValueAxis valueAxis20 = categoryPlot17.getRangeAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = categoryPlot17.getDomainAxis((int) ' ');
        org.jfree.chart.axis.CategoryAnchor categoryAnchor23 = categoryPlot17.getDomainGridlinePosition();
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range25 = numberAxis24.getDefaultAutoRange();
        boolean boolean27 = numberAxis24.equals((java.lang.Object) (byte) -1);
        categoryPlot17.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis24);
        java.lang.Comparable[] comparableArray33 = new java.lang.Comparable[] { "CategoryLabelEntity: category=false, tooltip=, url=Preceding", "rect", (short) 1, (-1) };
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year38 = month37.getYear();
        java.lang.Comparable[] comparableArray40 = new java.lang.Comparable[] { 10.0d, ' ', 15, month37, 1.0f };
        java.lang.Number[] numberArray47 = new java.lang.Number[] { 10L, 1, 15, 3600000L, 200, 0.5f };
        java.lang.Number[][] numberArray48 = new java.lang.Number[][] { numberArray47 };
        java.lang.Number[][] numberArray49 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset50 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray33, comparableArray40, numberArray48, numberArray49);
        org.jfree.data.xy.XYDataset xYDataset51 = null;
        org.jfree.chart.axis.NumberAxis numberAxis52 = new org.jfree.chart.axis.NumberAxis();
        double double53 = numberAxis52.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock56 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D57 = labelBlock56.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity60 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D57, "", "Preceding");
        numberAxis52.setDownArrow((java.awt.Shape) rectangle2D57);
        org.jfree.chart.util.RectangleInsets rectangleInsets62 = numberAxis52.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis63 = new org.jfree.chart.axis.NumberAxis();
        double double64 = numberAxis63.getUpperBound();
        boolean boolean65 = numberAxis63.getAutoRangeStickyZero();
        boolean boolean66 = numberAxis63.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer67 = null;
        org.jfree.chart.plot.XYPlot xYPlot68 = new org.jfree.chart.plot.XYPlot(xYDataset51, (org.jfree.chart.axis.ValueAxis) numberAxis52, (org.jfree.chart.axis.ValueAxis) numberAxis63, xYItemRenderer67);
        xYPlot68.setRangeCrosshairVisible(false);
        java.lang.String str71 = xYPlot68.getPlotType();
        xYPlot68.setDomainCrosshairValue((double) 1, true);
        boolean boolean75 = defaultIntervalCategoryDataset50.hasListener((java.util.EventListener) xYPlot68);
        try {
            levelRenderer0.drawItem(graphics2D1, categoryItemRendererState2, rectangle2D3, categoryPlot4, categoryAxis10, (org.jfree.chart.axis.ValueAxis) numberAxis24, (org.jfree.data.category.CategoryDataset) defaultIntervalCategoryDataset50, 200, (int) (byte) 10, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset.getValue(): series index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(colorSpace8);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(valueAxis20);
        org.junit.Assert.assertNull(categoryAxis22);
        org.junit.Assert.assertNotNull(categoryAnchor23);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(comparableArray33);
        org.junit.Assert.assertNotNull(year38);
        org.junit.Assert.assertNotNull(comparableArray40);
        org.junit.Assert.assertNotNull(numberArray47);
        org.junit.Assert.assertNotNull(numberArray48);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 1.0d + "'", double53 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D57);
        org.junit.Assert.assertNotNull(rectangleInsets62);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 1.0d + "'", double64 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "XY Plot" + "'", str71.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 1L, (double) 31);
        boolean boolean4 = stackedBarRenderer3D2.equals((java.lang.Object) (-1.0f));
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        stackedBarRenderer3D2.setBaseURLGenerator(categoryURLGenerator5);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer7 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = statisticalBarRenderer7.getSeriesURLGenerator((int) (short) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer10 = null;
        statisticalBarRenderer7.setGradientPaintTransformer(gradientPaintTransformer10);
        java.awt.Paint paint13 = statisticalBarRenderer7.lookupSeriesFillPaint(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = null;
        statisticalBarRenderer7.setNegativeItemLabelPositionFallback(itemLabelPosition14);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot16.setRangeCrosshairValue((double) (byte) 1);
        org.jfree.chart.axis.ValueAxis valueAxis19 = categoryPlot16.getRangeAxis();
        categoryPlot16.setRangeCrosshairValue((double) '#');
        statisticalBarRenderer7.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot16);
        java.awt.Color color23 = java.awt.Color.orange;
        int int24 = color23.getGreen();
        statisticalBarRenderer7.setErrorIndicatorPaint((java.awt.Paint) color23);
        stackedBarRenderer3D2.setWallPaint((java.awt.Paint) color23);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(categoryURLGenerator9);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(valueAxis19);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 200 + "'", int24 == 200);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = statisticalBarRenderer0.getSeriesURLGenerator((int) (short) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        statisticalBarRenderer0.setGradientPaintTransformer(gradientPaintTransformer3);
        java.awt.Paint paint7 = statisticalBarRenderer0.getItemPaint((int) (byte) 100, (int) '#');
        statisticalBarRenderer0.setSeriesCreateEntities(31, (java.lang.Boolean) true);
        org.jfree.chart.LegendItemCollection legendItemCollection11 = statisticalBarRenderer0.getLegendItems();
        try {
            org.jfree.chart.LegendItem legendItem13 = legendItemCollection11.get(2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2019, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(categoryURLGenerator2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(legendItemCollection11);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) centerArrangement0);
        double double2 = blockContainer1.getContentYOffset();
        java.util.List list3 = blockContainer1.getBlocks();
        boolean boolean4 = blockContainer1.isEmpty();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int2 = defaultCategoryDataset0.getColumnIndex((java.lang.Comparable) 10);
        java.util.List list3 = defaultCategoryDataset0.getColumnKeys();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(list3);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 100);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        int int0 = org.jfree.chart.axis.DateTickUnit.MINUTE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        java.awt.Image image0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE;
        org.junit.Assert.assertNull(image0);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator2 = piePlot1.getToolTipGenerator();
        java.awt.Color color3 = java.awt.Color.gray;
        piePlot1.setLabelShadowPaint((java.awt.Paint) color3);
        piePlot1.setExplodePercent((java.lang.Comparable) 8.0d, (double) 7);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        double double9 = numberAxis8.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock12 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D13 = labelBlock12.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity16 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D13, "", "Preceding");
        numberAxis8.setDownArrow((java.awt.Shape) rectangle2D13);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = numberAxis8.getLabelInsets();
        java.awt.Shape shape20 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
        numberAxis8.setRightArrow(shape20);
        java.awt.Paint paint22 = numberAxis8.getLabelPaint();
        piePlot1.setBaseSectionPaint(paint22);
        org.jfree.chart.util.Rotation rotation24 = piePlot1.getDirection();
        piePlot1.setLabelLinksVisible(true);
        piePlot1.setLabelLinkMargin((double) 6);
        org.junit.Assert.assertNull(pieToolTipGenerator2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(rotation24);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", graphics2D1, (float) 1, (float) 8, (double) 100L, (float) (byte) 1, (float) ' ');
        org.junit.Assert.assertNull(shape7);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        try {
            keyedObjects0.removeValue((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.addValue((java.lang.Number) 15, (java.lang.Comparable) 4, (java.lang.Comparable) "DateTickMarkPosition.START");
        org.jfree.data.general.DatasetGroup datasetGroup5 = defaultCategoryDataset0.getGroup();
        org.junit.Assert.assertNotNull(datasetGroup5);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D6 = labelBlock5.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D6, "", "Preceding");
        numberAxis1.setDownArrow((java.awt.Shape) rectangle2D6);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis1.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        double double13 = numberAxis12.getUpperBound();
        boolean boolean14 = numberAxis12.getAutoRangeStickyZero();
        boolean boolean15 = numberAxis12.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer16);
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = xYPlot17.getRendererForDataset(xYDataset18);
        org.jfree.chart.axis.AxisSpace axisSpace20 = xYPlot17.getFixedDomainAxisSpace();
        boolean boolean21 = xYPlot17.isDomainZeroBaselineVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = xYPlot17.getAxisOffset();
        double double23 = rectangleInsets22.getBottom();
        java.lang.String str24 = rectangleInsets22.toString();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(xYItemRenderer19);
        org.junit.Assert.assertNull(axisSpace20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str24.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        java.lang.String str0 = org.jfree.chart.ui.Licences.LGPL;
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        try {
            java.lang.Number number3 = defaultCategoryDataset0.getValue((java.lang.Comparable) "Fourth", (java.lang.Comparable) 3);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unrecognised columnKey: 3");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 1L, (double) 31);
        boolean boolean4 = stackedBarRenderer3D2.equals((java.lang.Object) (-1.0f));
        double double5 = stackedBarRenderer3D2.getUpperClip();
        java.awt.Color color7 = java.awt.Color.BLUE;
        stackedBarRenderer3D2.setSeriesPaint(12, (java.awt.Paint) color7);
        java.io.ObjectOutputStream objectOutputStream9 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePaint((java.awt.Paint) color7, objectOutputStream9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        java.text.DateFormat dateFormat1 = null;
        try {
            org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator2 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator("rect", dateFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset7 = new org.jfree.data.category.DefaultCategoryDataset();
        java.awt.Color color8 = java.awt.Color.darkGray;
        boolean boolean9 = defaultCategoryDataset7.equals((java.lang.Object) color8);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.awt.Stroke stroke12 = null;
        org.jfree.chart.block.LineBorder lineBorder14 = new org.jfree.chart.block.LineBorder();
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.block.LabelBlock labelBlock18 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D19 = labelBlock18.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity22 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D19, "", "Preceding");
        org.jfree.chart.entity.LegendItemEntity legendItemEntity23 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D19);
        lineBorder14.draw(graphics2D15, rectangle2D19);
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis();
        double double27 = numberAxis26.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock30 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D31 = labelBlock30.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity34 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D31, "", "Preceding");
        numberAxis26.setDownArrow((java.awt.Shape) rectangle2D31);
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = numberAxis26.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis();
        double double38 = numberAxis37.getUpperBound();
        boolean boolean39 = numberAxis37.getAutoRangeStickyZero();
        boolean boolean40 = numberAxis37.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer41 = null;
        org.jfree.chart.plot.XYPlot xYPlot42 = new org.jfree.chart.plot.XYPlot(xYDataset25, (org.jfree.chart.axis.ValueAxis) numberAxis26, (org.jfree.chart.axis.ValueAxis) numberAxis37, xYItemRenderer41);
        org.jfree.data.xy.XYDataset xYDataset43 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer44 = xYPlot42.getRendererForDataset(xYDataset43);
        org.jfree.chart.axis.AxisSpace axisSpace45 = xYPlot42.getFixedDomainAxisSpace();
        xYPlot42.setRangeZeroBaselineVisible(true);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer48 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator50 = statisticalBarRenderer48.getSeriesURLGenerator((int) (short) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer51 = null;
        statisticalBarRenderer48.setGradientPaintTransformer(gradientPaintTransformer51);
        java.awt.Paint paint54 = statisticalBarRenderer48.lookupSeriesFillPaint(0);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator55 = null;
        statisticalBarRenderer48.setBaseToolTipGenerator(categoryToolTipGenerator55, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition59 = null;
        statisticalBarRenderer48.setSeriesNegativeItemLabelPosition(0, itemLabelPosition59);
        statisticalBarRenderer48.setSeriesItemLabelsVisible(200, false);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D66 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 1L, (double) 31);
        boolean boolean68 = stackedBarRenderer3D66.equals((java.lang.Object) (-1.0f));
        stackedBarRenderer3D66.setRenderAsPercentages(true);
        java.awt.Stroke stroke73 = stackedBarRenderer3D66.getItemOutlineStroke(100, 3);
        statisticalBarRenderer48.setBaseStroke(stroke73, false);
        xYPlot42.setRangeZeroBaselineStroke(stroke73);
        org.jfree.data.general.WaferMapDataset waferMapDataset77 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot78 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset77);
        float float79 = waferMapPlot78.getForegroundAlpha();
        java.awt.Color color80 = java.awt.Color.orange;
        waferMapPlot78.setNoDataMessagePaint((java.awt.Paint) color80);
        try {
            org.jfree.chart.LegendItem legendItem82 = new org.jfree.chart.LegendItem(attributedString0, "VerticalAlignment.BOTTOM", "", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=10.0]", false, shape5, true, (java.awt.Paint) color8, true, (java.awt.Paint) color11, stroke12, false, (java.awt.Shape) rectangle2D19, stroke73, (java.awt.Paint) color80);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 1.0d + "'", double27 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 1.0d + "'", double38 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNull(xYItemRenderer44);
        org.junit.Assert.assertNull(axisSpace45);
        org.junit.Assert.assertNull(categoryURLGenerator50);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(stroke73);
        org.junit.Assert.assertTrue("'" + float79 + "' != '" + 1.0f + "'", float79 == 1.0f);
        org.junit.Assert.assertNotNull(color80);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.data.time.DateRange dateRange0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double1 = dateRange0.getCentralValue();
        double double3 = dateRange0.constrain((double) (byte) 0);
        org.junit.Assert.assertNotNull(dateRange0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5d + "'", double1 == 0.5d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.DEFAULT_ITEM_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        java.awt.Stroke stroke0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairValue((double) (byte) 1);
        double[] doubleArray10 = new double[] { (-1L), 0.0d };
        double[] doubleArray13 = new double[] { (-1L), 0.0d };
        double[] doubleArray16 = new double[] { (-1L), 0.0d };
        double[] doubleArray19 = new double[] { (-1L), 0.0d };
        double[][] doubleArray20 = new double[][] { doubleArray10, doubleArray13, doubleArray16, doubleArray19 };
        org.jfree.data.category.CategoryDataset categoryDataset21 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", doubleArray20);
        org.jfree.data.category.CategoryDataset categoryDataset22 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray20);
        double[] doubleArray29 = new double[] { (-1L), 0.0d };
        double[] doubleArray32 = new double[] { (-1L), 0.0d };
        double[] doubleArray35 = new double[] { (-1L), 0.0d };
        double[] doubleArray38 = new double[] { (-1L), 0.0d };
        double[][] doubleArray39 = new double[][] { doubleArray29, doubleArray32, doubleArray35, doubleArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", doubleArray39);
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray39);
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset42 = new org.jfree.data.category.DefaultIntervalCategoryDataset(doubleArray20, doubleArray39);
        categoryPlot0.setDataset(100, (org.jfree.data.category.CategoryDataset) defaultIntervalCategoryDataset42);
        java.lang.Comparable comparable45 = defaultIntervalCategoryDataset42.getColumnKey(0);
        try {
            org.jfree.data.general.PieDataset pieDataset47 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultIntervalCategoryDataset42, (java.lang.Comparable) 2.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset.getValue(): series index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(categoryDataset21);
        org.junit.Assert.assertNotNull(categoryDataset22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertTrue("'" + comparable45 + "' != '" + "Category 1" + "'", comparable45.equals("Category 1"));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        java.awt.Paint paint0 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = statisticalBarRenderer0.getSeriesURLGenerator((int) (short) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        statisticalBarRenderer0.setGradientPaintTransformer(gradientPaintTransformer3);
        java.awt.Paint paint7 = statisticalBarRenderer0.getItemPaint((int) (byte) 100, (int) '#');
        statisticalBarRenderer0.setSeriesCreateEntities(31, (java.lang.Boolean) true);
        java.awt.Color color12 = java.awt.Color.orange;
        int int13 = color12.getGreen();
        float[] floatArray19 = new float[] { (short) 0, 10.0f, (short) 10, (byte) 0, 0.0f };
        float[] floatArray20 = color12.getColorComponents(floatArray19);
        statisticalBarRenderer0.setSeriesPaint(0, (java.awt.Paint) color12, true);
        statisticalBarRenderer0.setAutoPopulateSeriesPaint(true);
        org.junit.Assert.assertNull(categoryURLGenerator2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 200 + "'", int13 == 200);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        java.awt.Color color0 = java.awt.Color.red;
        int int1 = color0.getAlpha();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D1, (float) 1561964399999L, (float) 'a', textAnchor4, 100.0d, 100.0f, (float) 9);
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        long long2 = month0.getLastMillisecond();
        int int3 = month0.getYearValue();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_RIGHT;
        java.lang.String str1 = textBlockAnchor0.toString();
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextBlockAnchor.TOP_RIGHT" + "'", str1.equals("TextBlockAnchor.TOP_RIGHT"));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D3 = labelBlock2.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity6 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D3, "", "Preceding");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer7 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = statisticalBarRenderer7.getSeriesURLGenerator((int) (short) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer10 = null;
        statisticalBarRenderer7.setGradientPaintTransformer(gradientPaintTransformer10);
        java.awt.Paint paint13 = statisticalBarRenderer7.lookupSeriesFillPaint(0);
        boolean boolean14 = categoryLabelEntity6.equals((java.lang.Object) statisticalBarRenderer7);
        java.lang.Comparable comparable15 = categoryLabelEntity6.getKey();
        org.junit.Assert.assertNotNull(rectangle2D3);
        org.junit.Assert.assertNull(categoryURLGenerator9);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + comparable15 + "' != '" + false + "'", comparable15.equals(false));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle();
        boolean boolean2 = textTitle1.getExpandToFitSpace();
        textTitle1.setNotify(false);
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("");
        java.awt.Font font7 = labelBlock6.getFont();
        centerArrangement0.add((org.jfree.chart.block.Block) textTitle1, (java.lang.Object) labelBlock6);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement13 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment9, verticalAlignment10, (double) (byte) 100, (double) (short) 100);
        org.jfree.chart.block.BlockContainer blockContainer14 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement13);
        org.jfree.chart.block.Arrangement arrangement15 = blockContainer14.getArrangement();
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.data.time.DateRange dateRange17 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double18 = dateRange17.getCentralValue();
        org.jfree.data.time.DateRange dateRange19 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double20 = dateRange19.getCentralValue();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange17, (org.jfree.data.Range) dateRange19);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType22 = rectangleConstraint21.getHeightConstraintType();
        try {
            org.jfree.chart.util.Size2D size2D23 = centerArrangement0.arrange(blockContainer14, graphics2D16, rectangleConstraint21);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertNotNull(arrangement15);
        org.junit.Assert.assertNotNull(dateRange17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.5d + "'", double18 == 0.5d);
        org.junit.Assert.assertNotNull(dateRange19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.5d + "'", double20 == 0.5d);
        org.junit.Assert.assertNotNull(lengthConstraintType22);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition0 = new org.jfree.chart.axis.CategoryLabelPosition();
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = null;
        taskSeriesCollection0.seriesChanged(seriesChangeEvent1);
        org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, 9);
        org.jfree.data.Range range5 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        try {
            java.lang.Number number9 = taskSeriesCollection0.getStartValue((java.lang.Comparable) 15, (java.lang.Comparable) (short) -1, 500);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(pieDataset4);
        org.junit.Assert.assertNull(range5);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) centerArrangement0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.VerticalAlignment verticalAlignment3 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment2, verticalAlignment3, (double) (byte) 100, (double) (short) 100);
        org.jfree.chart.block.BlockContainer blockContainer7 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.data.time.DateRange dateRange9 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double10 = dateRange9.getCentralValue();
        org.jfree.data.time.DateRange dateRange11 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double12 = dateRange11.getCentralValue();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange9, (org.jfree.data.Range) dateRange11);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType14 = rectangleConstraint13.getHeightConstraintType();
        try {
            org.jfree.chart.util.Size2D size2D15 = centerArrangement0.arrange(blockContainer7, graphics2D8, rectangleConstraint13);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertNotNull(dateRange9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.5d + "'", double10 == 0.5d);
        org.junit.Assert.assertNotNull(dateRange11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.5d + "'", double12 == 0.5d);
        org.junit.Assert.assertNotNull(lengthConstraintType14);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) '#', (-1), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Green");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        java.awt.Color color0 = java.awt.Color.lightGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator2 = piePlot1.getToolTipGenerator();
        double double3 = piePlot1.getLabelGap();
        org.jfree.chart.plot.Plot plot4 = piePlot1.getRootPlot();
        org.junit.Assert.assertNull(pieToolTipGenerator2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(plot4);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator2 = piePlot1.getToolTipGenerator();
        java.awt.Font font3 = piePlot1.getLabelFont();
        java.awt.Stroke stroke5 = piePlot1.getSectionOutlineStroke((java.lang.Comparable) 0L);
        piePlot1.setIgnoreNullValues(true);
        org.junit.Assert.assertNull(pieToolTipGenerator2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNull(stroke5);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        java.lang.Number number1 = null;
        org.jfree.data.DefaultKeyedValue defaultKeyedValue2 = new org.jfree.data.DefaultKeyedValue((java.lang.Comparable) "CONTRACT", number1);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = statisticalBarRenderer0.getSeriesURLGenerator((int) (short) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        statisticalBarRenderer0.setGradientPaintTransformer(gradientPaintTransformer3);
        java.awt.Paint paint6 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        statisticalBarRenderer0.setSeriesOutlinePaint(2019, paint6);
        java.awt.Paint paint9 = statisticalBarRenderer0.getSeriesFillPaint((int) (short) 1);
        org.junit.Assert.assertNull(categoryURLGenerator2);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(paint9);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        try {
            java.awt.Color color1 = java.awt.Color.decode("rect");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"rect\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation5 = categoryPlot0.getDomainAxisLocation((int) '4');
        org.jfree.chart.axis.AxisSpace axisSpace6 = new org.jfree.chart.axis.AxisSpace();
        categoryPlot0.setFixedRangeAxisSpace(axisSpace6);
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot0);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryPlot9.getAxisOffset();
        org.jfree.chart.block.LabelBlock labelBlock13 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D14 = labelBlock13.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity17 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D14, "", "Preceding");
        org.jfree.chart.entity.LegendItemEntity legendItemEntity18 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D14);
        java.awt.geom.Rectangle2D rectangle2D19 = rectangleInsets10.createOutsetRectangle(rectangle2D14);
        double double21 = rectangleInsets10.calculateTopInset((double) 200);
        legendTitle8.setItemLabelPadding(rectangleInsets10);
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = categoryPlot24.getAxisOffset();
        org.jfree.chart.block.LabelBlock labelBlock28 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D29 = labelBlock28.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity32 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D29, "", "Preceding");
        org.jfree.chart.entity.LegendItemEntity legendItemEntity33 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D29);
        java.awt.geom.Rectangle2D rectangle2D34 = rectangleInsets25.createOutsetRectangle(rectangle2D29);
        org.jfree.chart.axis.DateTickUnit dateTickUnit37 = new org.jfree.chart.axis.DateTickUnit(0, 5);
        try {
            java.lang.Object obj38 = legendTitle8.draw(graphics2D23, rectangle2D29, (java.lang.Object) dateTickUnit37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertNotNull(rectangle2D34);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_OUTSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 2.0f + "'", float0 == 2.0f);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        java.awt.Color color0 = java.awt.Color.gray;
        java.awt.Color color1 = color0.brighter();
        java.lang.String str2 = color0.toString();
        int int3 = color0.getRed();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java.awt.Color[r=128,g=128,b=128]" + "'", str2.equals("java.awt.Color[r=128,g=128,b=128]"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 128 + "'", int3 == 128);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D3 = labelBlock2.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity6 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D3, "", "Preceding");
        org.jfree.chart.entity.LegendItemEntity legendItemEntity7 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D3);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint9 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        statisticalBarRenderer8.setBasePaint(paint9);
        org.jfree.chart.title.LegendGraphic legendGraphic11 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape) rectangle2D3, paint9);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = legendGraphic11.getShapeAnchor();
        java.awt.Paint paint13 = legendGraphic11.getFillPaint();
        boolean boolean14 = legendGraphic11.isShapeFilled();
        org.junit.Assert.assertNotNull(rectangle2D3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.data.KeyToGroupMap keyToGroupMap1 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable) 10.0f);
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.previous();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType4 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        boolean boolean5 = month2.equals((java.lang.Object) chartChangeEventType4);
        java.lang.Comparable comparable6 = keyToGroupMap1.getGroup((java.lang.Comparable) month2);
        java.lang.Object obj7 = keyToGroupMap1.clone();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(chartChangeEventType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 10.0f + "'", comparable6.equals(10.0f));
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        double double1 = levelRenderer0.getItemMargin();
        levelRenderer0.setItemMargin(1.561964399999E12d);
        double double4 = levelRenderer0.getMaximumItemWidth();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (short) 0);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 1L, (double) 31);
        boolean boolean4 = stackedBarRenderer3D2.equals((java.lang.Object) (-1.0f));
        stackedBarRenderer3D2.setRenderAsPercentages(true);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        stackedBarRenderer3D2.setWallPaint((java.awt.Paint) color7);
        boolean boolean9 = stackedBarRenderer3D2.getRenderAsPercentages();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) centerArrangement0);
        org.jfree.data.RangeType rangeType2 = org.jfree.data.RangeType.NEGATIVE;
        boolean boolean3 = blockContainer1.equals((java.lang.Object) rangeType2);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        double double6 = numberAxis5.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock9 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D10 = labelBlock9.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity13 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D10, "", "Preceding");
        numberAxis5.setDownArrow((java.awt.Shape) rectangle2D10);
        try {
            blockContainer1.draw(graphics2D4, rectangle2D10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rangeType2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D10);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D2 = labelBlock1.getBounds();
        boolean boolean4 = labelBlock1.equals((java.lang.Object) 1);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = labelBlock1.getPadding();
        labelBlock1.setHeight((double) 3600000L);
        org.junit.Assert.assertNotNull(rectangle2D2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(rectangleInsets5);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.lang.String str1 = textTitle0.getURLText();
        java.lang.String str2 = textTitle0.getText();
        java.lang.String str3 = textTitle0.getURLText();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        try {
            taskSeriesCollection0.remove(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: TaskSeriesCollection.remove(): index outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range1);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D3 = labelBlock2.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity6 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D3, "", "Preceding");
        org.jfree.chart.entity.LegendItemEntity legendItemEntity7 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D3);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint9 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        statisticalBarRenderer8.setBasePaint(paint9);
        org.jfree.chart.title.LegendGraphic legendGraphic11 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape) rectangle2D3, paint9);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = legendGraphic11.getShapeAnchor();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = legendGraphic11.getShapeAnchor();
        java.awt.Paint paint14 = legendGraphic11.getFillPaint();
        legendGraphic11.setShapeFilled(true);
        org.junit.Assert.assertNotNull(rectangle2D3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        java.awt.Font font1 = null;
        java.awt.Color color2 = java.awt.Color.orange;
        int int3 = color2.getGreen();
        float[] floatArray9 = new float[] { (short) 0, 10.0f, (short) 10, (byte) 0, 0.0f };
        float[] floatArray10 = color2.getColorComponents(floatArray9);
        try {
            org.jfree.chart.text.TextBlock textBlock11 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font1, (java.awt.Paint) color2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 200 + "'", int3 == 200);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 1L, (double) 31);
        boolean boolean4 = stackedBarRenderer3D2.equals((java.lang.Object) (-1.0f));
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = null;
        stackedBarRenderer3D2.setLegendItemToolTipGenerator(categorySeriesLabelGenerator5);
        java.awt.Paint paint8 = stackedBarRenderer3D2.lookupSeriesFillPaint((int) ' ');
        org.jfree.chart.block.LabelBlock labelBlock11 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D12 = labelBlock11.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity15 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D12, "", "Preceding");
        stackedBarRenderer3D2.setBaseShape((java.awt.Shape) rectangle2D12, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator18 = null;
        stackedBarRenderer3D2.setBaseItemLabelGenerator(categoryItemLabelGenerator18, true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(rectangle2D12);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        double double3 = numberAxis2.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D7 = labelBlock6.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity10 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D7, "", "Preceding");
        numberAxis2.setDownArrow((java.awt.Shape) rectangle2D7);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = numberAxis2.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        double double14 = numberAxis13.getUpperBound();
        boolean boolean15 = numberAxis13.getAutoRangeStickyZero();
        boolean boolean16 = numberAxis13.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis13, xYItemRenderer17);
        xYPlot18.setRangeCrosshairVisible(false);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("WMAP_Plot", (org.jfree.chart.plot.Plot) xYPlot18);
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle();
        jFreeChart21.addSubtitle((org.jfree.chart.title.Title) textTitle22);
        org.jfree.chart.title.TextTitle textTitle24 = new org.jfree.chart.title.TextTitle();
        java.lang.String str25 = textTitle24.getURLText();
        jFreeChart21.addSubtitle((org.jfree.chart.title.Title) textTitle24);
        java.lang.Object obj27 = textTitle24.clone();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertNotNull(obj27);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        java.awt.Color color0 = java.awt.Color.white;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D5 = labelBlock4.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity8 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D5, "", "Preceding");
        numberAxis0.setDownArrow((java.awt.Shape) rectangle2D5);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = numberAxis0.getLabelInsets();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot11.setRangeCrosshairValue((double) (byte) 1);
        org.jfree.chart.axis.ValueAxis valueAxis14 = categoryPlot11.getRangeAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = categoryPlot11.getDomainAxis((int) ' ');
        boolean boolean17 = numberAxis0.hasListener((java.util.EventListener) categoryPlot11);
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = null;
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis();
        double double21 = numberAxis20.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock24 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D25 = labelBlock24.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity28 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D25, "", "Preceding");
        numberAxis20.setDownArrow((java.awt.Shape) rectangle2D25);
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = numberAxis20.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis();
        double double32 = numberAxis31.getUpperBound();
        boolean boolean33 = numberAxis31.getAutoRangeStickyZero();
        boolean boolean34 = numberAxis31.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = null;
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot(xYDataset19, (org.jfree.chart.axis.ValueAxis) numberAxis20, (org.jfree.chart.axis.ValueAxis) numberAxis31, xYItemRenderer35);
        org.jfree.data.xy.XYDataset xYDataset38 = null;
        xYPlot36.setDataset(5, xYDataset38);
        org.jfree.chart.util.Layer layer40 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection41 = xYPlot36.getRangeMarkers(layer40);
        try {
            categoryPlot11.addDomainMarker(categoryMarker18, layer40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNull(valueAxis14);
        org.junit.Assert.assertNull(categoryAxis16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0d + "'", double32 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(layer40);
        org.junit.Assert.assertNull(collection41);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator2 = piePlot1.getToolTipGenerator();
        java.awt.Font font3 = piePlot1.getLabelFont();
        java.awt.Stroke stroke5 = piePlot1.getSectionOutlineStroke((java.lang.Comparable) 0L);
        int int6 = piePlot1.getPieIndex();
        double double8 = piePlot1.getExplodePercent((java.lang.Comparable) "CategoryLabelWidthType.CATEGORY");
        org.junit.Assert.assertNull(pieToolTipGenerator2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairValue((double) (byte) 1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis((int) ' ');
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = categoryPlot0.getRenderer();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation7 = null;
        try {
            categoryPlot0.addAnnotation(categoryAnnotation7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNull(categoryItemRenderer6);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = statisticalBarRenderer0.getSeriesURLGenerator((int) (short) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        statisticalBarRenderer0.setGradientPaintTransformer(gradientPaintTransformer3);
        java.awt.Paint paint6 = statisticalBarRenderer0.lookupSeriesFillPaint(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = null;
        statisticalBarRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition7);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot9.setRangeCrosshairValue((double) (byte) 1);
        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot9.getRangeAxis();
        categoryPlot9.setRangeCrosshairValue((double) '#');
        statisticalBarRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot9);
        java.awt.Color color16 = java.awt.Color.orange;
        int int17 = color16.getGreen();
        statisticalBarRenderer0.setErrorIndicatorPaint((java.awt.Paint) color16);
        java.lang.Boolean boolean20 = statisticalBarRenderer0.getSeriesVisibleInLegend(2019);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator23 = statisticalBarRenderer0.getURLGenerator(15, 0);
        org.junit.Assert.assertNull(categoryURLGenerator2);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 200 + "'", int17 == 200);
        org.junit.Assert.assertNull(boolean20);
        org.junit.Assert.assertNull(categoryURLGenerator23);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 1L, (double) 31);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        double double6 = numberAxis5.getUpperBound();
        boolean boolean7 = numberAxis5.getAutoRangeStickyZero();
        org.jfree.chart.plot.Marker marker8 = null;
        org.jfree.data.general.WaferMapDataset waferMapDataset9 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot10 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset9);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.block.LabelBlock labelBlock14 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D15 = labelBlock14.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity18 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D15, "", "Preceding");
        waferMapPlot10.drawBackgroundImage(graphics2D11, rectangle2D15);
        stackedBarRenderer3D2.drawRangeMarker(graphics2D3, categoryPlot4, (org.jfree.chart.axis.ValueAxis) numberAxis5, marker8, rectangle2D15);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor21 = categoryPlot4.getDomainGridlinePosition();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        java.awt.geom.Point2D point2D25 = null;
        categoryPlot4.zoomRangeAxes((double) (-1), (double) ' ', plotRenderingInfo24, point2D25);
        java.awt.Stroke stroke27 = categoryPlot4.getRangeCrosshairStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection28 = categoryPlot4.getFixedLegendItems();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNotNull(categoryAnchor21);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNull(legendItemCollection28);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        float float2 = waferMapPlot1.getForegroundAlpha();
        float float3 = waferMapPlot1.getBackgroundImageAlpha();
        waferMapPlot1.setBackgroundImageAlignment((int) '4');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.5f + "'", float3 == 0.5f);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D6 = labelBlock5.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D6, "", "Preceding");
        numberAxis1.setDownArrow((java.awt.Shape) rectangle2D6);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis1.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        double double13 = numberAxis12.getUpperBound();
        boolean boolean14 = numberAxis12.getAutoRangeStickyZero();
        boolean boolean15 = numberAxis12.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer16);
        java.awt.Paint paint18 = xYPlot17.getRangeTickBandPaint();
        xYPlot17.setDomainCrosshairVisible(true);
        java.util.List list21 = xYPlot17.getAnnotations();
        xYPlot17.setNoDataMessage("Size2D[width=0.0, height=0.0]");
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertNotNull(list21);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setBase(0.0d);
        barRenderer0.setDrawBarOutline(true);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        java.awt.Paint paint1 = lineBorder0.getPaint();
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        java.lang.Comparable[] comparableArray4 = new java.lang.Comparable[] { "CategoryLabelEntity: category=false, tooltip=, url=Preceding", "rect", (short) 1, (-1) };
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year9 = month8.getYear();
        java.lang.Comparable[] comparableArray11 = new java.lang.Comparable[] { 10.0d, ' ', 15, month8, 1.0f };
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 10L, 1, 15, 3600000L, 200, 0.5f };
        java.lang.Number[][] numberArray19 = new java.lang.Number[][] { numberArray18 };
        java.lang.Number[][] numberArray20 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset21 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray4, comparableArray11, numberArray19, numberArray20);
        java.lang.Comparable[] comparableArray24 = new java.lang.Comparable[] { "SortOrder.ASCENDING", 3 };
        java.lang.Comparable[] comparableArray29 = new java.lang.Comparable[] { "CategoryLabelEntity: category=false, tooltip=, url=Preceding", "rect", (short) 1, (-1) };
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year34 = month33.getYear();
        java.lang.Comparable[] comparableArray36 = new java.lang.Comparable[] { 10.0d, ' ', 15, month33, 1.0f };
        java.lang.Number[] numberArray43 = new java.lang.Number[] { 10L, 1, 15, 3600000L, 200, 0.5f };
        java.lang.Number[][] numberArray44 = new java.lang.Number[][] { numberArray43 };
        java.lang.Number[][] numberArray45 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset46 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray29, comparableArray36, numberArray44, numberArray45);
        java.lang.Number[] numberArray51 = new java.lang.Number[] { 0.25d, 3, 100.0f, 128.0d };
        java.lang.Number[] numberArray56 = new java.lang.Number[] { 0.25d, 3, 100.0f, 128.0d };
        java.lang.Number[] numberArray61 = new java.lang.Number[] { 0.25d, 3, 100.0f, 128.0d };
        java.lang.Number[] numberArray66 = new java.lang.Number[] { 0.25d, 3, 100.0f, 128.0d };
        java.lang.Number[] numberArray71 = new java.lang.Number[] { 0.25d, 3, 100.0f, 128.0d };
        java.lang.Number[] numberArray76 = new java.lang.Number[] { 0.25d, 3, 100.0f, 128.0d };
        java.lang.Number[][] numberArray77 = new java.lang.Number[][] { numberArray51, numberArray56, numberArray61, numberArray66, numberArray71, numberArray76 };
        try {
            org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset78 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray11, comparableArray24, numberArray44, numberArray77);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset: the number of series in the start value dataset does not match the number of series in the end value dataset.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray4);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(comparableArray11);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(comparableArray24);
        org.junit.Assert.assertNotNull(comparableArray29);
        org.junit.Assert.assertNotNull(year34);
        org.junit.Assert.assertNotNull(comparableArray36);
        org.junit.Assert.assertNotNull(numberArray43);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(numberArray51);
        org.junit.Assert.assertNotNull(numberArray56);
        org.junit.Assert.assertNotNull(numberArray61);
        org.junit.Assert.assertNotNull(numberArray66);
        org.junit.Assert.assertNotNull(numberArray71);
        org.junit.Assert.assertNotNull(numberArray76);
        org.junit.Assert.assertNotNull(numberArray77);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator2 = piePlot1.getToolTipGenerator();
        java.awt.Color color3 = java.awt.Color.gray;
        piePlot1.setLabelShadowPaint((java.awt.Paint) color3);
        piePlot1.setExplodePercent((java.lang.Comparable) 8.0d, (double) 7);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        double double9 = numberAxis8.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock12 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D13 = labelBlock12.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity16 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D13, "", "Preceding");
        numberAxis8.setDownArrow((java.awt.Shape) rectangle2D13);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = numberAxis8.getLabelInsets();
        java.awt.Shape shape20 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
        numberAxis8.setRightArrow(shape20);
        java.awt.Paint paint22 = numberAxis8.getLabelPaint();
        piePlot1.setBaseSectionPaint(paint22);
        org.jfree.chart.util.Rotation rotation24 = piePlot1.getDirection();
        boolean boolean25 = piePlot1.getSectionOutlinesVisible();
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D29 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 1L, (double) 31);
        java.awt.Graphics2D graphics2D30 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis();
        double double33 = numberAxis32.getUpperBound();
        boolean boolean34 = numberAxis32.getAutoRangeStickyZero();
        org.jfree.chart.plot.Marker marker35 = null;
        org.jfree.data.general.WaferMapDataset waferMapDataset36 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot37 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset36);
        java.awt.Graphics2D graphics2D38 = null;
        org.jfree.chart.block.LabelBlock labelBlock41 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D42 = labelBlock41.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity45 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D42, "", "Preceding");
        waferMapPlot37.drawBackgroundImage(graphics2D38, rectangle2D42);
        stackedBarRenderer3D29.drawRangeMarker(graphics2D30, categoryPlot31, (org.jfree.chart.axis.ValueAxis) numberAxis32, marker35, rectangle2D42);
        org.jfree.data.general.PieDataset pieDataset48 = null;
        org.jfree.chart.plot.PiePlot piePlot49 = new org.jfree.chart.plot.PiePlot(pieDataset48);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator50 = piePlot49.getToolTipGenerator();
        java.awt.Color color51 = java.awt.Color.gray;
        piePlot49.setLabelShadowPaint((java.awt.Paint) color51);
        piePlot49.setExplodePercent((java.lang.Comparable) 8.0d, (double) 7);
        org.jfree.chart.axis.NumberAxis numberAxis56 = new org.jfree.chart.axis.NumberAxis();
        double double57 = numberAxis56.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock60 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D61 = labelBlock60.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity64 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D61, "", "Preceding");
        numberAxis56.setDownArrow((java.awt.Shape) rectangle2D61);
        org.jfree.chart.util.RectangleInsets rectangleInsets66 = numberAxis56.getLabelInsets();
        java.awt.Shape shape68 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
        numberAxis56.setRightArrow(shape68);
        java.awt.Paint paint70 = numberAxis56.getLabelPaint();
        piePlot49.setBaseSectionPaint(paint70);
        java.awt.Color color72 = java.awt.Color.BLUE;
        piePlot49.setLabelBackgroundPaint((java.awt.Paint) color72);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo75 = null;
        try {
            org.jfree.chart.plot.PiePlotState piePlotState76 = piePlot1.initialise(graphics2D26, rectangle2D42, piePlot49, (java.lang.Integer) 5, plotRenderingInfo75);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(pieToolTipGenerator2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(rotation24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.0d + "'", double33 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(rectangle2D42);
        org.junit.Assert.assertNull(pieToolTipGenerator50);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 1.0d + "'", double57 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D61);
        org.junit.Assert.assertNotNull(rectangleInsets66);
        org.junit.Assert.assertNotNull(shape68);
        org.junit.Assert.assertNotNull(paint70);
        org.junit.Assert.assertNotNull(color72);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.data.general.DatasetGroup datasetGroup0 = new org.jfree.data.general.DatasetGroup();
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 1L, (double) 31);
        boolean boolean3 = stackedBarRenderer3D2.getIncludeBaseInRange();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D5 = labelBlock4.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity8 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D5, "", "Preceding");
        numberAxis0.setDownArrow((java.awt.Shape) rectangle2D5);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = numberAxis0.getLabelInsets();
        numberAxis0.setVerticalTickLabels(true);
        java.awt.Stroke stroke13 = numberAxis0.getAxisLineStroke();
        numberAxis0.setAutoTickUnitSelection(false, false);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.removeValue((java.lang.Comparable) "({0}, {1}) = {2}", (java.lang.Comparable) "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        defaultCategoryDataset0.setValue((double) 31, (java.lang.Comparable) "CategoryLabelEntity: category=false, tooltip=, url=Preceding", (java.lang.Comparable) 5);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = statisticalBarRenderer0.getSeriesURLGenerator((int) (short) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        statisticalBarRenderer0.setGradientPaintTransformer(gradientPaintTransformer3);
        java.awt.Paint paint6 = statisticalBarRenderer0.lookupSeriesFillPaint(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = null;
        statisticalBarRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition7);
        double double9 = statisticalBarRenderer0.getMaximumBarWidth();
        org.junit.Assert.assertNull(categoryURLGenerator2);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range1 = numberAxis0.getDefaultAutoRange();
        boolean boolean3 = numberAxis0.equals((java.lang.Object) (byte) -1);
        boolean boolean4 = numberAxis0.isAutoRange();
        numberAxis0.setInverted(false);
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setSeriesLinesVisible((int) '4', (java.lang.Boolean) true);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor5 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE7;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor7 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor5, textAnchor6, textAnchor7, (double) 0L);
        lineAndShapeRenderer0.setSeriesNegativeItemLabelPosition((int) '4', itemLabelPosition9);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.lang.String str12 = rectangleAnchor11.toString();
        boolean boolean13 = lineAndShapeRenderer0.equals((java.lang.Object) rectangleAnchor11);
        org.junit.Assert.assertNotNull(itemLabelAnchor5);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertNotNull(textAnchor7);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "RectangleAnchor.BOTTOM_RIGHT" + "'", str12.equals("RectangleAnchor.BOTTOM_RIGHT"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.awt.Image image1 = null;
        projectInfo0.setLogo(image1);
        org.jfree.chart.axis.AxisCollection axisCollection3 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list4 = axisCollection3.getAxesAtBottom();
        projectInfo0.setContributors(list4);
        projectInfo0.setLicenceText("Preceding");
        org.junit.Assert.assertNotNull(list4);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 'a', (float) (byte) 0);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity6 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) 0.5f, shape3, "hi!", "ClassContext");
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = statisticalBarRenderer0.getSeriesURLGenerator((int) (short) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        statisticalBarRenderer0.setGradientPaintTransformer(gradientPaintTransformer3);
        java.awt.Paint paint6 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        statisticalBarRenderer0.setSeriesOutlinePaint(2019, paint6);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = statisticalBarRenderer0.getDrawingSupplier();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator9 = statisticalBarRenderer0.getLegendItemLabelGenerator();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = null;
        statisticalBarRenderer0.setBaseURLGenerator(categoryURLGenerator10);
        org.junit.Assert.assertNull(categoryURLGenerator2);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator9);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean1 = lineAndShapeRenderer0.getDrawOutlines();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer2 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint3 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        statisticalBarRenderer2.setBasePaint(paint3);
        boolean boolean5 = statisticalBarRenderer2.getIncludeBaseInRange();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer6.setSeriesLinesVisible((int) '4', (java.lang.Boolean) true);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor11 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE7;
        org.jfree.chart.text.TextAnchor textAnchor12 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor13 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor11, textAnchor12, textAnchor13, (double) 0L);
        lineAndShapeRenderer6.setSeriesNegativeItemLabelPosition((int) '4', itemLabelPosition15);
        statisticalBarRenderer2.setBaseNegativeItemLabelPosition(itemLabelPosition15);
        lineAndShapeRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition15);
        java.lang.Boolean boolean20 = lineAndShapeRenderer0.getSeriesShapesFilled((int) (byte) 1);
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean23 = categoryPlot22.isDomainGridlinesVisible();
        org.jfree.data.general.WaferMapDataset waferMapDataset24 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot25 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset24);
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.block.LabelBlock labelBlock29 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D30 = labelBlock29.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity33 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D30, "", "Preceding");
        waferMapPlot25.drawBackgroundImage(graphics2D26, rectangle2D30);
        org.jfree.chart.entity.ChartEntity chartEntity36 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D30, "Preceding");
        java.awt.Shape shape39 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape) rectangle2D30, 12.0d, (double) 10);
        try {
            lineAndShapeRenderer0.drawDomainGridline(graphics2D21, categoryPlot22, rectangle2D30, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(itemLabelAnchor11);
        org.junit.Assert.assertNotNull(textAnchor12);
        org.junit.Assert.assertNotNull(textAnchor13);
        org.junit.Assert.assertNull(boolean20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(shape39);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        double[] doubleArray6 = new double[] { (-1L), 0.0d };
        double[] doubleArray9 = new double[] { (-1L), 0.0d };
        double[] doubleArray12 = new double[] { (-1L), 0.0d };
        double[] doubleArray15 = new double[] { (-1L), 0.0d };
        double[][] doubleArray16 = new double[][] { doubleArray6, doubleArray9, doubleArray12, doubleArray15 };
        org.jfree.data.category.CategoryDataset categoryDataset17 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", doubleArray16);
        org.jfree.data.category.CategoryDataset categoryDataset18 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray16);
        double[] doubleArray25 = new double[] { (-1L), 0.0d };
        double[] doubleArray28 = new double[] { (-1L), 0.0d };
        double[] doubleArray31 = new double[] { (-1L), 0.0d };
        double[] doubleArray34 = new double[] { (-1L), 0.0d };
        double[][] doubleArray35 = new double[][] { doubleArray25, doubleArray28, doubleArray31, doubleArray34 };
        org.jfree.data.category.CategoryDataset categoryDataset36 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", doubleArray35);
        org.jfree.data.category.CategoryDataset categoryDataset37 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray35);
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset38 = new org.jfree.data.category.DefaultIntervalCategoryDataset(doubleArray16, doubleArray35);
        double[] doubleArray43 = new double[] { (-1L), 0.0d };
        double[] doubleArray46 = new double[] { (-1L), 0.0d };
        double[] doubleArray49 = new double[] { (-1L), 0.0d };
        double[] doubleArray52 = new double[] { (-1L), 0.0d };
        double[][] doubleArray53 = new double[][] { doubleArray43, doubleArray46, doubleArray49, doubleArray52 };
        org.jfree.data.category.CategoryDataset categoryDataset54 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", doubleArray53);
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset55 = new org.jfree.data.category.DefaultIntervalCategoryDataset(doubleArray16, doubleArray53);
        int int57 = defaultIntervalCategoryDataset55.getCategoryIndex((java.lang.Comparable) 100L);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(categoryDataset17);
        org.junit.Assert.assertNotNull(categoryDataset18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(categoryDataset36);
        org.junit.Assert.assertNotNull(categoryDataset37);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(categoryDataset54);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-1) + "'", int57 == (-1));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        boolean boolean1 = textTitle0.getExpandToFitSpace();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        double double4 = numberAxis3.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock7 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D8 = labelBlock7.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity11 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D8, "", "Preceding");
        numberAxis3.setDownArrow((java.awt.Shape) rectangle2D8);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = numberAxis3.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        double double15 = numberAxis14.getUpperBound();
        boolean boolean16 = numberAxis14.getAutoRangeStickyZero();
        boolean boolean17 = numberAxis14.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis14, xYItemRenderer18);
        boolean boolean20 = xYPlot19.isDomainCrosshairVisible();
        boolean boolean21 = textTitle0.equals((java.lang.Object) xYPlot19);
        java.awt.Stroke stroke22 = xYPlot19.getRangeZeroBaselineStroke();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(stroke22);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        java.awt.Paint paint0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        double double3 = numberAxis2.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D7 = labelBlock6.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity10 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D7, "", "Preceding");
        numberAxis2.setDownArrow((java.awt.Shape) rectangle2D7);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = numberAxis2.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        double double14 = numberAxis13.getUpperBound();
        boolean boolean15 = numberAxis13.getAutoRangeStickyZero();
        boolean boolean16 = numberAxis13.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis13, xYItemRenderer17);
        xYPlot18.setRangeCrosshairVisible(false);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("WMAP_Plot", (org.jfree.chart.plot.Plot) xYPlot18);
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle();
        jFreeChart21.addSubtitle((org.jfree.chart.title.Title) textTitle22);
        org.jfree.chart.title.TextTitle textTitle24 = new org.jfree.chart.title.TextTitle();
        java.lang.String str25 = textTitle24.getURLText();
        jFreeChart21.addSubtitle((org.jfree.chart.title.Title) textTitle24);
        org.jfree.chart.event.ChartProgressListener chartProgressListener27 = null;
        jFreeChart21.addProgressListener(chartProgressListener27);
        org.jfree.chart.plot.Plot plot29 = jFreeChart21.getPlot();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertNotNull(plot29);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) categoryPlot0, jFreeChart1, 200, (int) (byte) 0);
        org.jfree.chart.JFreeChart jFreeChart5 = chartProgressEvent4.getChart();
        int int6 = chartProgressEvent4.getPercent();
        org.junit.Assert.assertNull(jFreeChart5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
        java.lang.String str2 = gradientPaintTransformType0.toString();
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GradientPaintTransformType.VERTICAL" + "'", str2.equals("GradientPaintTransformType.VERTICAL"));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation(0.5d, (double) 0.0f);
        java.lang.Number number3 = meanAndStandardDeviation2.getMean();
        java.lang.Number number4 = meanAndStandardDeviation2.getMean();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0.5d + "'", number3.equals(0.5d));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.5d + "'", number4.equals(0.5d));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) 'a', (double) (short) 0);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) '4', (double) 'a', false);
        boolean boolean4 = stackedBarRenderer3D3.getBaseItemLabelsVisible();
        stackedBarRenderer3D3.setBaseSeriesVisibleInLegend(true, false);
        stackedBarRenderer3D3.setRenderAsPercentages(false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        projectInfo0.setCopyright("");
        org.jfree.chart.ui.ProjectInfo projectInfo3 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str4 = projectInfo3.getCopyright();
        projectInfo3.setVersion("({0}, {1}) = {2}");
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo3);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D5 = labelBlock4.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity8 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D5, "", "Preceding");
        numberAxis0.setDownArrow((java.awt.Shape) rectangle2D5);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = numberAxis0.getLabelInsets();
        numberAxis0.setTickMarkOutsideLength(0.0f);
        boolean boolean13 = numberAxis0.isVisible();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D6 = labelBlock5.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D6, "", "Preceding");
        numberAxis1.setDownArrow((java.awt.Shape) rectangle2D6);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis1.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        double double13 = numberAxis12.getUpperBound();
        boolean boolean14 = numberAxis12.getAutoRangeStickyZero();
        boolean boolean15 = numberAxis12.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer16);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Point2D point2D21 = null;
        xYPlot17.zoomRangeAxes(0.0d, (double) 100L, plotRenderingInfo20, point2D21);
        java.awt.Paint paint23 = xYPlot17.getRangeGridlinePaint();
        double double24 = xYPlot17.getRangeCrosshairValue();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle();
        boolean boolean2 = textTitle1.getExpandToFitSpace();
        textTitle1.setNotify(false);
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("");
        java.awt.Font font7 = labelBlock6.getFont();
        centerArrangement0.add((org.jfree.chart.block.Block) textTitle1, (java.lang.Object) labelBlock6);
        org.jfree.chart.block.LabelBlock labelBlock10 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D11 = labelBlock10.getBounds();
        labelBlock10.setMargin(0.05d, (double) 0.0f, (double) 0.0f, (double) (short) 0);
        centerArrangement0.add((org.jfree.chart.block.Block) labelBlock10, (java.lang.Object) 128);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(rectangle2D11);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.FIRST_MONDAY_AFTER_1900;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + (-2208960000000L) + "'", long0 == (-2208960000000L));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        double double1 = levelRenderer0.getItemMargin();
        levelRenderer0.setItemMargin((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (byte) 1, jFreeChart1);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        chartChangeEvent2.setType(chartChangeEventType3);
        org.jfree.data.general.WaferMapDataset waferMapDataset5 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot6 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset5);
        float float7 = waferMapPlot6.getForegroundAlpha();
        boolean boolean8 = chartChangeEventType3.equals((java.lang.Object) waferMapPlot6);
        java.awt.Stroke stroke9 = null;
        waferMapPlot6.setOutlineStroke(stroke9);
        org.jfree.data.general.WaferMapDataset waferMapDataset11 = null;
        waferMapPlot6.setDataset(waferMapDataset11);
        org.junit.Assert.assertNotNull(chartChangeEventType3);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator3 = piePlot2.getToolTipGenerator();
        java.awt.Color color4 = java.awt.Color.gray;
        piePlot2.setLabelShadowPaint((java.awt.Paint) color4);
        piePlot2.setExplodePercent((java.lang.Comparable) 8.0d, (double) 7);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        double double10 = numberAxis9.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock13 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D14 = labelBlock13.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity17 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D14, "", "Preceding");
        numberAxis9.setDownArrow((java.awt.Shape) rectangle2D14);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = numberAxis9.getLabelInsets();
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
        numberAxis9.setRightArrow(shape21);
        java.awt.Paint paint23 = numberAxis9.getLabelPaint();
        piePlot2.setBaseSectionPaint(paint23);
        org.jfree.chart.util.Rotation rotation25 = piePlot2.getDirection();
        boolean boolean26 = piePlot2.getSectionOutlinesVisible();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit28 = new org.jfree.chart.axis.NumberTickUnit((double) 100L);
        java.awt.Paint paint29 = piePlot2.getSectionOutlinePaint((java.lang.Comparable) numberTickUnit28);
        int int30 = keyedObjects2D0.getRowIndex((java.lang.Comparable) numberTickUnit28);
        try {
            java.lang.Comparable comparable32 = keyedObjects2D0.getColumnKey(200);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 200, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(pieToolTipGenerator3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(rotation25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNull(paint29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.data.time.DateRange dateRange0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double1 = dateRange0.getCentralValue();
        double double2 = dateRange0.getUpperBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange0, (double) 3);
        org.jfree.data.Range range7 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange0, (double) 2019, false);
        org.junit.Assert.assertNotNull(dateRange0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5d + "'", double1 == 0.5d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(range7);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(7, 10, 15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D3 = labelBlock2.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity6 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D3, "", "Preceding");
        org.jfree.chart.entity.LegendItemEntity legendItemEntity7 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D3);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint9 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        statisticalBarRenderer8.setBasePaint(paint9);
        org.jfree.chart.title.LegendGraphic legendGraphic11 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape) rectangle2D3, paint9);
        java.awt.Shape shape12 = legendGraphic11.getLine();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        legendGraphic11.setShapeLocation(rectangleAnchor13);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = legendGraphic11.getPadding();
        org.junit.Assert.assertNotNull(rectangle2D3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(shape12);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
        org.junit.Assert.assertNotNull(rectangleInsets15);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = statisticalBarRenderer0.getSeriesURLGenerator((int) (short) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        statisticalBarRenderer0.setGradientPaintTransformer(gradientPaintTransformer3);
        java.awt.Paint paint6 = statisticalBarRenderer0.lookupSeriesFillPaint(0);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        statisticalBarRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator7, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = null;
        statisticalBarRenderer0.setSeriesNegativeItemLabelPosition(0, itemLabelPosition11);
        java.lang.Boolean boolean14 = statisticalBarRenderer0.getSeriesVisible(8);
        org.junit.Assert.assertNull(categoryURLGenerator2);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(boolean14);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.trimHeight((double) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis3.setLowerMargin((double) 10.0f);
        categoryAxis3.configure();
        categoryAxis3.removeCategoryLabelToolTip((java.lang.Comparable) "First");
        org.jfree.chart.block.LabelBlock labelBlock13 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D14 = labelBlock13.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity17 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D14, "", "Preceding");
        org.jfree.chart.entity.LegendItemEntity legendItemEntity18 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D14);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer19 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint20 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        statisticalBarRenderer19.setBasePaint(paint20);
        org.jfree.chart.title.LegendGraphic legendGraphic22 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape) rectangle2D14, paint20);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = null;
        double double24 = categoryAxis3.getCategoryMiddle(0, 4, rectangle2D14, rectangleEdge23);
        java.awt.geom.Rectangle2D rectangle2D25 = rectangleInsets0.createInsetRectangle(rectangle2D14);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-3.0d) + "'", double2 == (-3.0d));
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D25);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) categoryPlot0, jFreeChart1, 200, (int) (byte) 0);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor5 = categoryPlot0.getDomainGridlinePosition();
        categoryPlot0.setAnchorValue((double) 900000L, false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer9 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke10 = statisticalBarRenderer9.getBaseStroke();
        categoryPlot0.setRangeCrosshairStroke(stroke10);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        try {
            categoryPlot0.drawBackground(graphics2D12, rectangle2D13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(categoryAnchor5);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int1 = defaultCategoryDataset0.getRowCount();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }
}

