import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D3 = labelBlock2.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity6 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D3, "", "Preceding");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection9 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection9);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity13 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D3, "CategoryLabelEntity: category=false, tooltip=, url=Preceding", "ThreadContext", (org.jfree.data.category.CategoryDataset) taskSeriesCollection9, (java.lang.Comparable) 'a', (java.lang.Comparable) 0L);
        org.jfree.data.category.CategoryDataset categoryDataset14 = categoryItemEntity13.getDataset();
        java.lang.Comparable comparable15 = categoryItemEntity13.getColumnKey();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        long long17 = month16.getLastMillisecond();
        categoryItemEntity13.setRowKey((java.lang.Comparable) long17);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
        categoryItemEntity13.setColumnKey((java.lang.Comparable) month19);
        org.junit.Assert.assertNotNull(rectangle2D3);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNotNull(categoryDataset14);
        org.junit.Assert.assertTrue("'" + comparable15 + "' != '" + 0L + "'", comparable15.equals(0L));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1561964399999L + "'", long17 == 1561964399999L);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator2 = piePlot1.getToolTipGenerator();
        java.awt.Font font3 = piePlot1.getLabelFont();
        java.awt.Stroke stroke5 = piePlot1.getSectionOutlineStroke((java.lang.Comparable) 0L);
        piePlot1.setCircular(false);
        boolean boolean8 = piePlot1.getIgnoreZeroValues();
        org.junit.Assert.assertNull(pieToolTipGenerator2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("RectangleEdge.TOP");
        taskSeries1.setNotify(false);
        int int4 = taskSeries1.getItemCount();
        taskSeries1.setNotify(false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Paint paint1 = waterfallBarRenderer0.getPositiveBarPaint();
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D5 = labelBlock4.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity8 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D5, "", "Preceding");
        org.jfree.chart.entity.LegendItemEntity legendItemEntity9 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D5);
        java.lang.Comparable comparable10 = legendItemEntity9.getSeriesKey();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset11 = new org.jfree.data.category.DefaultCategoryDataset();
        legendItemEntity9.setDataset((org.jfree.data.general.Dataset) defaultCategoryDataset11);
        org.jfree.data.Range range13 = waterfallBarRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset11);
        java.awt.Paint paint14 = waterfallBarRenderer0.getFirstBarPaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNull(comparable10);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D6 = labelBlock5.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D6, "", "Preceding");
        numberAxis1.setDownArrow((java.awt.Shape) rectangle2D6);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis1.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        double double13 = numberAxis12.getUpperBound();
        boolean boolean14 = numberAxis12.getAutoRangeStickyZero();
        boolean boolean15 = numberAxis12.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer16);
        org.jfree.chart.axis.AxisSpace axisSpace18 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = org.jfree.chart.util.RectangleEdge.LEFT;
        axisSpace18.ensureAtLeast((double) ' ', rectangleEdge20);
        xYPlot17.setFixedDomainAxisSpace(axisSpace18);
        java.awt.Paint paint23 = xYPlot17.getDomainGridlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation24 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot17.setRangeAxisLocation(axisLocation24);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(axisLocation24);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint3 = piePlot1.getSectionOutlinePaint((java.lang.Comparable) 2019);
        java.lang.Object obj4 = null;
        boolean boolean5 = piePlot1.equals(obj4);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer6 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = statisticalBarRenderer6.getSeriesURLGenerator((int) (short) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer9 = null;
        statisticalBarRenderer6.setGradientPaintTransformer(gradientPaintTransformer9);
        java.awt.Paint paint13 = statisticalBarRenderer6.getItemPaint((int) (byte) 100, (int) '#');
        statisticalBarRenderer6.setSeriesCreateEntities(31, (java.lang.Boolean) true);
        org.jfree.chart.LegendItemCollection legendItemCollection17 = statisticalBarRenderer6.getLegendItems();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator18 = null;
        statisticalBarRenderer6.setBaseURLGenerator(categoryURLGenerator18);
        java.awt.Font font20 = statisticalBarRenderer6.getBaseItemLabelFont();
        piePlot1.setNoDataMessageFont(font20);
        piePlot1.setCircular(false);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(categoryURLGenerator8);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(legendItemCollection17);
        org.junit.Assert.assertNotNull(font20);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        waferMapPlot0.setRenderer(waferMapRenderer1);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        double double6 = numberAxis5.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock9 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D10 = labelBlock9.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity13 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D10, "", "Preceding");
        numberAxis5.setDownArrow((java.awt.Shape) rectangle2D10);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = numberAxis5.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis();
        double double17 = numberAxis16.getUpperBound();
        boolean boolean18 = numberAxis16.getAutoRangeStickyZero();
        boolean boolean19 = numberAxis16.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset4, (org.jfree.chart.axis.ValueAxis) numberAxis5, (org.jfree.chart.axis.ValueAxis) numberAxis16, xYItemRenderer20);
        xYPlot21.setRangeCrosshairVisible(false);
        org.jfree.chart.JFreeChart jFreeChart24 = new org.jfree.chart.JFreeChart("WMAP_Plot", (org.jfree.chart.plot.Plot) xYPlot21);
        boolean boolean25 = jFreeChart24.isNotify();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo28 = null;
        java.awt.image.BufferedImage bufferedImage29 = jFreeChart24.createBufferedImage(1, 6, chartRenderingInfo28);
        waferMapPlot0.setBackgroundImage((java.awt.Image) bufferedImage29);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(bufferedImage29);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator2 = piePlot1.getToolTipGenerator();
        java.awt.Font font3 = piePlot1.getLabelFont();
        java.awt.Stroke stroke5 = piePlot1.getSectionOutlineStroke((java.lang.Comparable) 0L);
        int int6 = piePlot1.getPieIndex();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment7 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.VerticalAlignment verticalAlignment8 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement11 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment7, verticalAlignment8, (double) (byte) 100, (double) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement12 = new org.jfree.chart.block.FlowArrangement();
        boolean boolean14 = flowArrangement12.equals((java.lang.Object) (short) 0);
        org.jfree.chart.block.LabelBlock labelBlock16 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D17 = labelBlock16.getBounds();
        boolean boolean19 = labelBlock16.equals((java.lang.Object) 1);
        boolean boolean20 = flowArrangement12.equals((java.lang.Object) 1);
        org.jfree.chart.title.LegendTitle legendTitle21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement11, (org.jfree.chart.block.Arrangement) flowArrangement12);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment22 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.VerticalAlignment verticalAlignment23 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement26 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment22, verticalAlignment23, (double) (byte) 100, (double) (short) 100);
        org.jfree.chart.block.BlockContainer blockContainer27 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement26);
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.data.time.DateRange dateRange29 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint31 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange29, (double) '#');
        org.jfree.chart.util.Size2D size2D32 = flowArrangement11.arrange(blockContainer27, graphics2D28, rectangleConstraint31);
        org.junit.Assert.assertNull(pieToolTipGenerator2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(horizontalAlignment7);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment22);
        org.junit.Assert.assertNotNull(dateRange29);
        org.junit.Assert.assertNotNull(size2D32);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        org.jfree.chart.axis.AxisSpace axisSpace1 = new org.jfree.chart.axis.AxisSpace();
        boolean boolean2 = projectInfo0.equals((java.lang.Object) axisSpace1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D6 = labelBlock5.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D6, "", "Preceding");
        numberAxis1.setDownArrow((java.awt.Shape) rectangle2D6);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis1.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        double double13 = numberAxis12.getUpperBound();
        boolean boolean14 = numberAxis12.getAutoRangeStickyZero();
        boolean boolean15 = numberAxis12.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer16);
        xYPlot17.setRangeCrosshairVisible(false);
        java.lang.String str20 = xYPlot17.getPlotType();
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        xYPlot17.setDataset((int) (short) 100, xYDataset22);
        org.jfree.chart.axis.ValueAxis valueAxis24 = xYPlot17.getRangeAxis();
        java.awt.Color color25 = java.awt.Color.gray;
        valueAxis24.setAxisLinePaint((java.awt.Paint) color25);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "XY Plot" + "'", str20.equals("XY Plot"));
        org.junit.Assert.assertNotNull(valueAxis24);
        org.junit.Assert.assertNotNull(color25);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) (byte) 100, (double) (short) 100);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer6 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = statisticalBarRenderer6.getSeriesURLGenerator((int) (short) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer9 = null;
        statisticalBarRenderer6.setGradientPaintTransformer(gradientPaintTransformer9);
        java.awt.Paint paint13 = statisticalBarRenderer6.getItemPaint((int) (byte) 100, (int) '#');
        statisticalBarRenderer6.setSeriesCreateEntities(31, (java.lang.Boolean) true);
        org.jfree.chart.LegendItemCollection legendItemCollection17 = statisticalBarRenderer6.getLegendItems();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator18 = null;
        statisticalBarRenderer6.setBaseURLGenerator(categoryURLGenerator18);
        java.awt.Font font20 = statisticalBarRenderer6.getBaseItemLabelFont();
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj22 = textTitle21.clone();
        java.awt.Paint paint23 = textTitle21.getPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean25 = categoryPlot24.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = categoryPlot24.getDomainAxisEdge((int) (short) 0);
        categoryPlot24.setAnchorValue((double) 10.0f, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = categoryPlot24.getDomainAxisEdge();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment32 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.VerticalAlignment verticalAlignment33 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = categoryPlot34.getAxisOffset();
        org.jfree.chart.block.LabelBlock labelBlock38 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D39 = labelBlock38.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity42 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D39, "", "Preceding");
        org.jfree.chart.entity.LegendItemEntity legendItemEntity43 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D39);
        java.awt.geom.Rectangle2D rectangle2D44 = rectangleInsets35.createOutsetRectangle(rectangle2D39);
        double double45 = rectangleInsets35.getBottom();
        org.jfree.chart.title.TextTitle textTitle46 = new org.jfree.chart.title.TextTitle("TextAnchor.BASELINE_RIGHT", font20, paint23, rectangleEdge31, horizontalAlignment32, verticalAlignment33, rectangleInsets35);
        org.jfree.chart.block.ColumnArrangement columnArrangement49 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment33, 3.0d, 1.05d);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNull(categoryURLGenerator8);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(legendItemCollection17);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertNotNull(horizontalAlignment32);
        org.junit.Assert.assertNotNull(verticalAlignment33);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertNotNull(rectangle2D39);
        org.junit.Assert.assertNotNull(rectangle2D44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = statisticalBarRenderer0.getSeriesURLGenerator((int) (short) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        statisticalBarRenderer0.setGradientPaintTransformer(gradientPaintTransformer3);
        java.awt.Paint paint7 = statisticalBarRenderer0.getItemPaint((int) (byte) 100, (int) '#');
        statisticalBarRenderer0.setSeriesCreateEntities(31, (java.lang.Boolean) true);
        org.jfree.chart.LegendItemCollection legendItemCollection11 = statisticalBarRenderer0.getLegendItems();
        double[] doubleArray16 = new double[] { (-1L), 0.0d };
        double[] doubleArray19 = new double[] { (-1L), 0.0d };
        double[] doubleArray22 = new double[] { (-1L), 0.0d };
        double[] doubleArray25 = new double[] { (-1L), 0.0d };
        double[][] doubleArray26 = new double[][] { doubleArray16, doubleArray19, doubleArray22, doubleArray25 };
        org.jfree.data.category.CategoryDataset categoryDataset27 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", doubleArray26);
        org.jfree.data.Range range28 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset27);
        org.jfree.data.Range range29 = statisticalBarRenderer0.findRangeBounds(categoryDataset27);
        org.junit.Assert.assertNull(categoryURLGenerator2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(legendItemCollection11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(categoryDataset27);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertNotNull(range29);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint3 = piePlot1.getSectionOutlinePaint((java.lang.Comparable) 2019);
        java.lang.Object obj4 = null;
        boolean boolean5 = piePlot1.equals(obj4);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator6 = null;
        piePlot1.setLegendLabelURLGenerator(pieURLGenerator6);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        double double3 = numberAxis2.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D7 = labelBlock6.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity10 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D7, "", "Preceding");
        numberAxis2.setDownArrow((java.awt.Shape) rectangle2D7);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = numberAxis2.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        double double14 = numberAxis13.getUpperBound();
        boolean boolean15 = numberAxis13.getAutoRangeStickyZero();
        boolean boolean16 = numberAxis13.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis13, xYItemRenderer17);
        xYPlot18.setRangeCrosshairVisible(false);
        java.lang.String str21 = xYPlot18.getPlotType();
        org.jfree.chart.axis.ValueAxis valueAxis22 = xYPlot18.getDomainAxis();
        double double23 = valueAxis22.getFixedDimension();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer24 = null;
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis22, polarItemRenderer24);
        org.jfree.chart.plot.PlotOrientation plotOrientation26 = polarPlot25.getOrientation();
        boolean boolean27 = polarPlot25.isDomainZoomable();
        int int28 = polarPlot25.getSeriesCount();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "XY Plot" + "'", str21.equals("XY Plot"));
        org.junit.Assert.assertNotNull(valueAxis22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(plotOrientation26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Paint paint1 = waterfallBarRenderer0.getPositiveBarPaint();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        double double4 = numberAxis3.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock7 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D8 = labelBlock7.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity11 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D8, "", "Preceding");
        numberAxis3.setDownArrow((java.awt.Shape) rectangle2D8);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = numberAxis3.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        double double15 = numberAxis14.getUpperBound();
        boolean boolean16 = numberAxis14.getAutoRangeStickyZero();
        boolean boolean17 = numberAxis14.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis14, xYItemRenderer18);
        xYPlot19.clearDomainAxes();
        java.awt.Color color22 = java.awt.Color.YELLOW;
        xYPlot19.setQuadrantPaint(3, (java.awt.Paint) color22);
        waterfallBarRenderer0.setNegativeBarPaint((java.awt.Paint) color22);
        int int25 = color22.getRed();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 255 + "'", int25 == 255);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D6 = labelBlock5.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D6, "", "Preceding");
        numberAxis1.setDownArrow((java.awt.Shape) rectangle2D6);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis1.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        double double13 = numberAxis12.getUpperBound();
        boolean boolean14 = numberAxis12.getAutoRangeStickyZero();
        boolean boolean15 = numberAxis12.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer16);
        xYPlot17.setRangeCrosshairVisible(false);
        java.lang.String str20 = xYPlot17.getPlotType();
        java.awt.Stroke stroke21 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot17.setRangeZeroBaselineStroke(stroke21);
        xYPlot17.setRangeCrosshairValue((double) 2019, false);
        int int26 = xYPlot17.getWeight();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "XY Plot" + "'", str20.equals("XY Plot"));
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator2 = piePlot1.getToolTipGenerator();
        java.awt.Color color3 = java.awt.Color.gray;
        piePlot1.setLabelShadowPaint((java.awt.Paint) color3);
        piePlot1.setExplodePercent((java.lang.Comparable) 8.0d, (double) 7);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        double double9 = numberAxis8.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock12 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D13 = labelBlock12.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity16 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D13, "", "Preceding");
        numberAxis8.setDownArrow((java.awt.Shape) rectangle2D13);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = numberAxis8.getLabelInsets();
        java.awt.Shape shape20 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
        numberAxis8.setRightArrow(shape20);
        java.awt.Paint paint22 = numberAxis8.getLabelPaint();
        piePlot1.setBaseSectionPaint(paint22);
        piePlot1.setMinimumArcAngleToDraw(3.0d);
        org.junit.Assert.assertNull(pieToolTipGenerator2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(paint22);
    }

//    @Test
//    public void test018() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test018");
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//        long long2 = segmentedTimeline0.getTimeFromLong(3600000L);
//        int int3 = segmentedTimeline0.getGroupSegmentCount();
//        java.util.List list4 = segmentedTimeline0.getExceptionSegments();
//        org.jfree.chart.axis.SegmentedTimeline.Segment segment6 = segmentedTimeline0.getSegment(100L);
//        org.junit.Assert.assertNotNull(segmentedTimeline0);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3600000L + "'", long2 == 3600000L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 7 + "'", int3 == 7);
//        org.junit.Assert.assertNotNull(list4);
//        org.junit.Assert.assertNotNull(segment6);
//    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLowerMargin((double) 10.0f);
        categoryAxis0.configure();
        categoryAxis0.removeCategoryLabelToolTip((java.lang.Comparable) "First");
        org.jfree.chart.block.LabelBlock labelBlock10 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D11 = labelBlock10.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity14 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D11, "", "Preceding");
        org.jfree.chart.entity.LegendItemEntity legendItemEntity15 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D11);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer16 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint17 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        statisticalBarRenderer16.setBasePaint(paint17);
        org.jfree.chart.title.LegendGraphic legendGraphic19 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape) rectangle2D11, paint17);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = categoryAxis0.getCategoryMiddle(0, 4, rectangle2D11, rectangleEdge20);
        java.awt.Font font22 = categoryAxis0.getLabelFont();
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(font22);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 1L, (double) 31);
        boolean boolean4 = stackedBarRenderer3D2.equals((java.lang.Object) (-1.0f));
        stackedBarRenderer3D2.setRenderAsPercentages(true);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier7 = stackedBarRenderer3D2.getDrawingSupplier();
        double double8 = stackedBarRenderer3D2.getUpperClip();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(drawingSupplier7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

//    @Test
//    public void test021() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test021");
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//        int int1 = segmentedTimeline0.getSegmentsIncluded();
//        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = new org.jfree.chart.axis.DateTickUnit(0, 5);
//        int int5 = dateTickUnit4.getRollUnit();
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month6.previous();
//        java.util.Date date8 = month6.getEnd();
//        org.jfree.chart.text.TextAnchor textAnchor10 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
//        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor11 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
//        org.jfree.chart.text.TextAnchor textAnchor12 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
//        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor11, textAnchor12);
//        org.jfree.chart.axis.DateTick dateTick15 = new org.jfree.chart.axis.DateTick(date8, "CONTRACT", textAnchor10, textAnchor12, 0.2d);
//        java.util.Date date16 = dateTickUnit4.addToDate(date8);
//        org.jfree.chart.axis.SegmentedTimeline.Segment segment17 = segmentedTimeline0.getSegment(date16);
//        long long19 = segment17.calculateSegmentNumber((long) 2958465);
//        segment17.moveIndexToStart();
//        org.jfree.chart.axis.SegmentedTimeline.Segment segment21 = segment17.copy();
//        org.junit.Assert.assertNotNull(segmentedTimeline0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 5 + "'", int1 == 5);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(textAnchor10);
//        org.junit.Assert.assertNotNull(itemLabelAnchor11);
//        org.junit.Assert.assertNotNull(textAnchor12);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(segment17);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 25566L + "'", long19 == 25566L);
//        org.junit.Assert.assertNotNull(segment21);
//    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int2 = defaultCategoryDataset0.getColumnIndex((java.lang.Comparable) 10);
        java.lang.Comparable comparable3 = null;
        defaultCategoryDataset0.removeColumn(comparable3);
        org.jfree.data.general.DatasetChangeListener datasetChangeListener5 = null;
        defaultCategoryDataset0.addChangeListener(datasetChangeListener5);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = statisticalBarRenderer1.getSeriesURLGenerator((int) (short) 100);
        int int4 = statisticalBarRenderer1.getColumnCount();
        double double5 = statisticalBarRenderer1.getItemMargin();
        java.lang.Class<?> wildcardClass6 = statisticalBarRenderer1.getClass();
        java.io.InputStream inputStream7 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("SortOrder.ASCENDING", (java.lang.Class) wildcardClass6);
        java.lang.ClassLoader classLoader8 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass6);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNull(inputStream7);
        org.junit.Assert.assertNotNull(classLoader8);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = statisticalBarRenderer0.getSeriesURLGenerator((int) (short) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        statisticalBarRenderer0.setGradientPaintTransformer(gradientPaintTransformer3);
        java.awt.Paint paint6 = statisticalBarRenderer0.lookupSeriesFillPaint(0);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        statisticalBarRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator7, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = null;
        statisticalBarRenderer0.setSeriesNegativeItemLabelPosition(0, itemLabelPosition11);
        statisticalBarRenderer0.setSeriesItemLabelsVisible(200, false);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D18 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 1L, (double) 31);
        boolean boolean20 = stackedBarRenderer3D18.equals((java.lang.Object) (-1.0f));
        stackedBarRenderer3D18.setRenderAsPercentages(true);
        java.awt.Stroke stroke25 = stackedBarRenderer3D18.getItemOutlineStroke(100, 3);
        statisticalBarRenderer0.setBaseStroke(stroke25, false);
        boolean boolean28 = statisticalBarRenderer0.getAutoPopulateSeriesFillPaint();
        boolean boolean30 = statisticalBarRenderer0.isSeriesVisibleInLegend(0);
        java.awt.Paint paint32 = statisticalBarRenderer0.getSeriesItemLabelPaint(12);
        org.junit.Assert.assertNull(categoryURLGenerator2);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNull(paint32);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setSeriesLinesVisible((int) '4', (java.lang.Boolean) true);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor5 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE7;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor7 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor5, textAnchor6, textAnchor7, (double) 0L);
        lineAndShapeRenderer0.setSeriesNegativeItemLabelPosition((int) '4', itemLabelPosition9);
        lineAndShapeRenderer0.setUseFillPaint(true);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot14.configureRangeAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis16.setLowerMargin((double) 10.0f);
        categoryAxis16.configure();
        org.jfree.chart.axis.DateTickUnit dateTickUnit22 = new org.jfree.chart.axis.DateTickUnit(0, 5);
        categoryAxis16.removeCategoryLabelToolTip((java.lang.Comparable) 0);
        org.jfree.chart.plot.CategoryMarker categoryMarker24 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType26 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer27 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean28 = lengthAdjustmentType26.equals((java.lang.Object) lineAndShapeRenderer27);
        java.lang.String str29 = lengthAdjustmentType26.toString();
        org.jfree.chart.block.LabelBlock labelBlock32 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D33 = labelBlock32.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity36 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D33, "", "Preceding");
        boolean boolean37 = lengthAdjustmentType26.equals((java.lang.Object) rectangle2D33);
        java.awt.geom.Rectangle2D rectangle2D40 = rectangleInsets25.createInsetRectangle(rectangle2D33, true, false);
        try {
            lineAndShapeRenderer0.drawDomainMarker(graphics2D13, categoryPlot14, categoryAxis16, categoryMarker24, rectangle2D40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelAnchor5);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertNotNull(textAnchor7);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(lengthAdjustmentType26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "CONTRACT" + "'", str29.equals("CONTRACT"));
        org.junit.Assert.assertNotNull(rectangle2D33);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(rectangle2D40);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = statisticalBarRenderer0.getSeriesURLGenerator((int) (short) 100);
        int int3 = statisticalBarRenderer0.getColumnCount();
        boolean boolean5 = statisticalBarRenderer0.isSeriesVisibleInLegend(0);
        java.awt.Paint paint7 = null;
        statisticalBarRenderer0.setSeriesFillPaint(3, paint7);
        statisticalBarRenderer0.setSeriesItemLabelsVisible((int) (short) 100, (java.lang.Boolean) true, false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer14 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint15 = statisticalBarRenderer14.getBaseOutlinePaint();
        org.jfree.chart.block.LabelBlock labelBlock17 = new org.jfree.chart.block.LabelBlock("");
        java.awt.Font font18 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        labelBlock17.setFont(font18);
        statisticalBarRenderer14.setBaseItemLabelFont(font18);
        statisticalBarRenderer0.setSeriesItemLabelFont(255, font18, true);
        org.junit.Assert.assertNull(categoryURLGenerator2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(font18);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        java.lang.String str0 = org.jfree.chart.ui.Licences.GPL;
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("AreaRendererEndType.LEVEL");
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        org.jfree.data.resources.DataPackageResources dataPackageResources0 = new org.jfree.data.resources.DataPackageResources();
        java.lang.Object[][] objArray1 = dataPackageResources0.getContents();
        org.junit.Assert.assertNotNull(objArray1);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        double double6 = numberAxis5.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock9 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D10 = labelBlock9.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity13 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D10, "", "Preceding");
        numberAxis5.setDownArrow((java.awt.Shape) rectangle2D10);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = numberAxis5.getLabelInsets();
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
        numberAxis5.setRightArrow(shape17);
        java.awt.Shape shape19 = org.jfree.chart.util.ShapeUtilities.clone(shape17);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor20 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.Shape shape23 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape17, rectangleAnchor20, 0.05d, 0.0d);
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.jfree.data.general.PieDataset pieDataset27 = null;
        org.jfree.chart.plot.PiePlot piePlot28 = new org.jfree.chart.plot.PiePlot(pieDataset27);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator29 = piePlot28.getToolTipGenerator();
        java.awt.Font font30 = piePlot28.getLabelFont();
        java.awt.Stroke stroke32 = piePlot28.getSectionOutlineStroke((java.lang.Comparable) 0L);
        piePlot28.setCircular(false);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions36 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(0.0d);
        boolean boolean37 = piePlot28.equals((java.lang.Object) 0.0d);
        java.awt.Color color38 = java.awt.Color.GRAY;
        int int39 = color38.getTransparency();
        int int40 = color38.getAlpha();
        piePlot28.setLabelLinkPaint((java.awt.Paint) color38);
        org.jfree.data.xy.XYDataset xYDataset42 = null;
        org.jfree.chart.axis.NumberAxis numberAxis43 = new org.jfree.chart.axis.NumberAxis();
        double double44 = numberAxis43.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock47 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D48 = labelBlock47.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity51 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D48, "", "Preceding");
        numberAxis43.setDownArrow((java.awt.Shape) rectangle2D48);
        org.jfree.chart.util.RectangleInsets rectangleInsets53 = numberAxis43.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis54 = new org.jfree.chart.axis.NumberAxis();
        double double55 = numberAxis54.getUpperBound();
        boolean boolean56 = numberAxis54.getAutoRangeStickyZero();
        boolean boolean57 = numberAxis54.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer58 = null;
        org.jfree.chart.plot.XYPlot xYPlot59 = new org.jfree.chart.plot.XYPlot(xYDataset42, (org.jfree.chart.axis.ValueAxis) numberAxis43, (org.jfree.chart.axis.ValueAxis) numberAxis54, xYItemRenderer58);
        org.jfree.data.xy.XYDataset xYDataset61 = null;
        xYPlot59.setDataset(5, xYDataset61);
        xYPlot59.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder65 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot59.setDatasetRenderingOrder(datasetRenderingOrder65);
        java.awt.Stroke stroke67 = xYPlot59.getRangeGridlineStroke();
        org.jfree.chart.axis.NumberAxis numberAxis69 = new org.jfree.chart.axis.NumberAxis();
        double double70 = numberAxis69.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock73 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D74 = labelBlock73.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity77 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D74, "", "Preceding");
        numberAxis69.setDownArrow((java.awt.Shape) rectangle2D74);
        org.jfree.chart.util.RectangleInsets rectangleInsets79 = numberAxis69.getLabelInsets();
        numberAxis69.setTickMarkOutsideLength(0.0f);
        double double82 = numberAxis69.getLowerMargin();
        java.awt.Shape shape83 = numberAxis69.getDownArrow();
        java.awt.Stroke stroke84 = null;
        org.jfree.chart.util.SortOrder sortOrder85 = org.jfree.chart.util.SortOrder.ASCENDING;
        java.awt.Paint paint86 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        boolean boolean87 = sortOrder85.equals((java.lang.Object) paint86);
        try {
            org.jfree.chart.LegendItem legendItem88 = new org.jfree.chart.LegendItem("CategoryLabelWidthType.CATEGORY", "RectangleAnchor.BOTTOM_RIGHT", "CONTRACT", "TextBlockAnchor.TOP_RIGHT", true, shape23, true, (java.awt.Paint) color25, false, (java.awt.Paint) color38, stroke67, true, shape83, stroke84, paint86);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'lineStroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(rectangleAnchor20);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNull(pieToolTipGenerator29);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertNull(stroke32);
        org.junit.Assert.assertNotNull(categoryLabelPositions36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 255 + "'", int40 == 255);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 1.0d + "'", double44 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D48);
        org.junit.Assert.assertNotNull(rectangleInsets53);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 1.0d + "'", double55 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder65);
        org.junit.Assert.assertNotNull(stroke67);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 1.0d + "'", double70 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D74);
        org.junit.Assert.assertNotNull(rectangleInsets79);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 0.05d + "'", double82 == 0.05d);
        org.junit.Assert.assertNotNull(shape83);
        org.junit.Assert.assertNotNull(sortOrder85);
        org.junit.Assert.assertNotNull(paint86);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        double double3 = numberAxis2.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D7 = labelBlock6.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity10 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D7, "", "Preceding");
        numberAxis2.setDownArrow((java.awt.Shape) rectangle2D7);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = numberAxis2.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        double double14 = numberAxis13.getUpperBound();
        boolean boolean15 = numberAxis13.getAutoRangeStickyZero();
        boolean boolean16 = numberAxis13.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis13, xYItemRenderer17);
        xYPlot18.setRangeCrosshairVisible(false);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("WMAP_Plot", (org.jfree.chart.plot.Plot) xYPlot18);
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle();
        jFreeChart21.addSubtitle((org.jfree.chart.title.Title) textTitle22);
        org.jfree.chart.title.TextTitle textTitle24 = new org.jfree.chart.title.TextTitle();
        java.lang.String str25 = textTitle24.getURLText();
        jFreeChart21.addSubtitle((org.jfree.chart.title.Title) textTitle24);
        org.jfree.chart.event.ChartProgressListener chartProgressListener27 = null;
        jFreeChart21.addProgressListener(chartProgressListener27);
        jFreeChart21.fireChartChanged();
        jFreeChart21.setAntiAlias(false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNull(str25);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        double double3 = numberAxis2.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D7 = labelBlock6.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity10 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D7, "", "Preceding");
        numberAxis2.setDownArrow((java.awt.Shape) rectangle2D7);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = numberAxis2.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        double double14 = numberAxis13.getUpperBound();
        boolean boolean15 = numberAxis13.getAutoRangeStickyZero();
        boolean boolean16 = numberAxis13.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis13, xYItemRenderer17);
        xYPlot18.setRangeCrosshairVisible(false);
        java.lang.String str21 = xYPlot18.getPlotType();
        org.jfree.chart.axis.ValueAxis valueAxis22 = xYPlot18.getDomainAxis();
        double double23 = valueAxis22.getFixedDimension();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer24 = null;
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis22, polarItemRenderer24);
        org.jfree.chart.plot.PlotOrientation plotOrientation26 = polarPlot25.getOrientation();
        boolean boolean27 = polarPlot25.isDomainZoomable();
        java.lang.String str28 = polarPlot25.getPlotType();
        polarPlot25.zoom((double) '4');
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "XY Plot" + "'", str21.equals("XY Plot"));
        org.junit.Assert.assertNotNull(valueAxis22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(plotOrientation26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Polar Plot" + "'", str28.equals("Polar Plot"));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        java.text.DateFormat dateFormat4 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = new org.jfree.chart.axis.DateTickUnit(0, (int) '4', 12, 3, dateFormat4);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot0.setDomainAxisLocation(axisLocation2);
        categoryPlot0.clearRangeMarkers((-1));
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = categoryPlot0.getDomainAxis(100);
        java.awt.Font font8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        categoryPlot0.setNoDataMessageFont(font8);
        java.lang.Object obj10 = categoryPlot0.clone();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNull(categoryAxis7);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 500);
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        org.jfree.chart.block.BlockBorder blockBorder3 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color2);
        valueMarker1.setPaint((java.awt.Paint) color2);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle();
        boolean boolean2 = textTitle1.getExpandToFitSpace();
        textTitle1.setNotify(false);
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("");
        java.awt.Font font7 = labelBlock6.getFont();
        centerArrangement0.add((org.jfree.chart.block.Block) textTitle1, (java.lang.Object) labelBlock6);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        textTitle1.setTextAlignment(horizontalAlignment9);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.time.DateRange dateRange1 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double2 = dateRange1.getCentralValue();
        double double3 = dateRange1.getUpperBound();
        java.util.Date date4 = dateRange1.getLowerDate();
        java.util.Date date5 = dateRange1.getUpperDate();
        dateAxis0.setMaximumDate(date5);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        double double10 = numberAxis9.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock13 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D14 = labelBlock13.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity17 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D14, "", "Preceding");
        numberAxis9.setDownArrow((java.awt.Shape) rectangle2D14);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = numberAxis9.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis();
        double double21 = numberAxis20.getUpperBound();
        boolean boolean22 = numberAxis20.getAutoRangeStickyZero();
        boolean boolean23 = numberAxis20.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset8, (org.jfree.chart.axis.ValueAxis) numberAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis20, xYItemRenderer24);
        xYPlot25.setRangeCrosshairVisible(false);
        org.jfree.chart.JFreeChart jFreeChart28 = new org.jfree.chart.JFreeChart("WMAP_Plot", (org.jfree.chart.plot.Plot) xYPlot25);
        boolean boolean29 = jFreeChart28.isNotify();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo32 = null;
        java.awt.image.BufferedImage bufferedImage33 = jFreeChart28.createBufferedImage(1, 6, chartRenderingInfo32);
        org.jfree.chart.title.TextTitle textTitle34 = new org.jfree.chart.title.TextTitle();
        java.lang.String str35 = textTitle34.getURLText();
        java.lang.String str36 = textTitle34.getURLText();
        jFreeChart28.addSubtitle((org.jfree.chart.title.Title) textTitle34);
        boolean boolean38 = dateAxis0.equals((java.lang.Object) jFreeChart28);
        dateAxis0.setLowerMargin(0.0d);
        java.util.Date date41 = null;
        org.jfree.chart.block.LabelBlock labelBlock44 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D45 = labelBlock44.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity48 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D45, "", "Preceding");
        org.jfree.chart.entity.LegendItemEntity legendItemEntity49 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D45);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer50 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint51 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        statisticalBarRenderer50.setBasePaint(paint51);
        org.jfree.chart.title.LegendGraphic legendGraphic53 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape) rectangle2D45, paint51);
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean55 = categoryPlot54.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge57 = categoryPlot54.getDomainAxisEdge((int) (short) 0);
        categoryPlot54.setAnchorValue((double) 10.0f, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge61 = categoryPlot54.getDomainAxisEdge();
        try {
            double double62 = dateAxis0.dateToJava2D(date41, rectangle2D45, rectangleEdge61);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateRange1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5d + "'", double2 == 0.5d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(bufferedImage33);
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(rectangle2D45);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(rectangleEdge57);
        org.junit.Assert.assertNotNull(rectangleEdge61);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.time.DateRange dateRange1 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double2 = dateRange1.getCentralValue();
        org.jfree.data.time.DateRange dateRange3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double4 = dateRange3.getCentralValue();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange1, (org.jfree.data.Range) dateRange3);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.time.DateRange dateRange7 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double8 = dateRange7.getCentralValue();
        org.jfree.data.time.DateRange dateRange9 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double10 = dateRange9.getCentralValue();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange7, (org.jfree.data.Range) dateRange9);
        numberAxis6.setRangeWithMargins((org.jfree.data.Range) dateRange7, true, false);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange1, (org.jfree.data.Range) dateRange7);
        dateAxis0.setRange((org.jfree.data.Range) dateRange1, false, true);
        java.util.Date date19 = dateRange1.getLowerDate();
        org.junit.Assert.assertNotNull(dateRange1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5d + "'", double2 == 0.5d);
        org.junit.Assert.assertNotNull(dateRange3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.5d + "'", double4 == 0.5d);
        org.junit.Assert.assertNotNull(dateRange7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.5d + "'", double8 == 0.5d);
        org.junit.Assert.assertNotNull(dateRange9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.5d + "'", double10 == 0.5d);
        org.junit.Assert.assertNotNull(date19);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        statisticalBarRenderer0.setBasePaint(paint1);
        boolean boolean3 = statisticalBarRenderer0.getIncludeBaseInRange();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer4.setSeriesLinesVisible((int) '4', (java.lang.Boolean) true);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor9 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE7;
        org.jfree.chart.text.TextAnchor textAnchor10 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor11 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor9, textAnchor10, textAnchor11, (double) 0L);
        lineAndShapeRenderer4.setSeriesNegativeItemLabelPosition((int) '4', itemLabelPosition13);
        statisticalBarRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition13);
        org.jfree.data.RangeType rangeType16 = org.jfree.data.RangeType.NEGATIVE;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean18 = categoryPlot17.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = categoryPlot17.getDomainAxisEdge((int) (short) 0);
        categoryPlot17.setAnchorValue((double) 10.0f, false);
        org.jfree.data.category.CategoryDataset categoryDataset25 = categoryPlot17.getDataset(2019);
        org.jfree.chart.event.PlotChangeListener plotChangeListener26 = null;
        categoryPlot17.removeChangeListener(plotChangeListener26);
        boolean boolean28 = rangeType16.equals((java.lang.Object) categoryPlot17);
        statisticalBarRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot17);
        java.awt.Graphics2D graphics2D30 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType31 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer32 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean33 = lengthAdjustmentType31.equals((java.lang.Object) lineAndShapeRenderer32);
        java.lang.String str34 = lengthAdjustmentType31.toString();
        org.jfree.chart.block.LabelBlock labelBlock37 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D38 = labelBlock37.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity41 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D38, "", "Preceding");
        boolean boolean42 = lengthAdjustmentType31.equals((java.lang.Object) rectangle2D38);
        try {
            categoryPlot17.drawOutline(graphics2D30, rectangle2D38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(itemLabelAnchor9);
        org.junit.Assert.assertNotNull(textAnchor10);
        org.junit.Assert.assertNotNull(textAnchor11);
        org.junit.Assert.assertNotNull(rangeType16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNull(categoryDataset25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(lengthAdjustmentType31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "CONTRACT" + "'", str34.equals("CONTRACT"));
        org.junit.Assert.assertNotNull(rectangle2D38);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D3 = labelBlock2.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity6 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D3, "", "Preceding");
        org.jfree.chart.entity.LegendItemEntity legendItemEntity7 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D3);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint9 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        statisticalBarRenderer8.setBasePaint(paint9);
        org.jfree.chart.title.LegendGraphic legendGraphic11 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape) rectangle2D3, paint9);
        java.io.ObjectOutputStream objectOutputStream12 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeShape((java.awt.Shape) rectangle2D3, objectOutputStream12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D3);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.util.List list1 = defaultCategoryDataset0.getRowKeys();
        int int2 = defaultCategoryDataset0.getRowCount();
        int int4 = defaultCategoryDataset0.getColumnIndex((java.lang.Comparable) 9);
        try {
            defaultCategoryDataset0.removeColumn(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D5 = labelBlock4.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity8 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D5, "", "Preceding");
        numberAxis0.setDownArrow((java.awt.Shape) rectangle2D5);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = numberAxis0.getLabelInsets();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
        numberAxis0.setRightArrow(shape12);
        java.awt.Paint paint14 = numberAxis0.getLabelPaint();
        numberAxis0.setLowerMargin((double) 8);
        java.lang.String str17 = numberAxis0.getLabel();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(str17);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.time.DateRange dateRange1 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double2 = dateRange1.getCentralValue();
        org.jfree.data.time.DateRange dateRange3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double4 = dateRange3.getCentralValue();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange1, (org.jfree.data.Range) dateRange3);
        numberAxis0.setRangeWithMargins((org.jfree.data.Range) dateRange1, true, false);
        boolean boolean11 = dateRange1.intersects(100.0d, (double) 200);
        org.junit.Assert.assertNotNull(dateRange1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5d + "'", double2 == 0.5d);
        org.junit.Assert.assertNotNull(dateRange3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.5d + "'", double4 == 0.5d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D6 = labelBlock5.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D6, "", "Preceding");
        numberAxis1.setDownArrow((java.awt.Shape) rectangle2D6);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis1.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        double double13 = numberAxis12.getUpperBound();
        boolean boolean14 = numberAxis12.getAutoRangeStickyZero();
        boolean boolean15 = numberAxis12.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer16);
        java.util.EventListener eventListener18 = null;
        boolean boolean19 = numberAxis12.hasListener(eventListener18);
        double[] doubleArray24 = new double[] { (-1L), 0.0d };
        double[] doubleArray27 = new double[] { (-1L), 0.0d };
        double[] doubleArray30 = new double[] { (-1L), 0.0d };
        double[] doubleArray33 = new double[] { (-1L), 0.0d };
        double[][] doubleArray34 = new double[][] { doubleArray24, doubleArray27, doubleArray30, doubleArray33 };
        org.jfree.data.category.CategoryDataset categoryDataset35 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", doubleArray34);
        org.jfree.data.Range range36 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset35);
        numberAxis12.setDefaultAutoRange(range36);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(categoryDataset35);
        org.junit.Assert.assertNotNull(range36);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) 6, (double) (short) 1, 0.0d, (double) '#');
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        org.jfree.chart.renderer.OutlierListCollection outlierListCollection0 = new org.jfree.chart.renderer.OutlierListCollection();
        org.jfree.chart.renderer.Outlier outlier1 = null;
        boolean boolean2 = outlierListCollection0.add(outlier1);
        outlierListCollection0.setHighFarOut(false);
        java.util.Iterator iterator5 = outlierListCollection0.iterator();
        outlierListCollection0.setLowFarOut(false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(iterator5);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = statisticalBarRenderer0.getSeriesURLGenerator((int) (short) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        statisticalBarRenderer0.setGradientPaintTransformer(gradientPaintTransformer3);
        java.awt.Paint paint6 = statisticalBarRenderer0.lookupSeriesFillPaint(0);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        statisticalBarRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator7, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = null;
        statisticalBarRenderer0.setSeriesNegativeItemLabelPosition(0, itemLabelPosition11);
        statisticalBarRenderer0.setSeriesItemLabelsVisible(200, false);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D18 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 1L, (double) 31);
        boolean boolean20 = stackedBarRenderer3D18.equals((java.lang.Object) (-1.0f));
        stackedBarRenderer3D18.setRenderAsPercentages(true);
        java.awt.Stroke stroke25 = stackedBarRenderer3D18.getItemOutlineStroke(100, 3);
        statisticalBarRenderer0.setBaseStroke(stroke25, false);
        statisticalBarRenderer0.setAutoPopulateSeriesShape(false);
        org.junit.Assert.assertNull(categoryURLGenerator2);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(stroke25);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range1 = numberAxis0.getDefaultAutoRange();
        java.awt.Shape shape2 = numberAxis0.getDownArrow();
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = statisticalBarRenderer0.getSeriesURLGenerator((int) (short) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        statisticalBarRenderer0.setGradientPaintTransformer(gradientPaintTransformer3);
        java.awt.Paint paint6 = statisticalBarRenderer0.lookupSeriesFillPaint(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = null;
        statisticalBarRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition7);
        statisticalBarRenderer0.setSeriesItemLabelsVisible(4, (java.lang.Boolean) true, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = statisticalBarRenderer0.getNegativeItemLabelPosition(31, 31);
        org.junit.Assert.assertNull(categoryURLGenerator2);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("RectangleEdge.TOP");
        taskSeries1.setNotify(false);
        int int4 = taskSeries1.getItemCount();
        taskSeries1.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = statisticalBarRenderer0.getSeriesURLGenerator((int) (short) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        statisticalBarRenderer0.setGradientPaintTransformer(gradientPaintTransformer3);
        java.awt.Paint paint6 = statisticalBarRenderer0.lookupSeriesFillPaint(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = null;
        statisticalBarRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition7);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot9.setRangeCrosshairValue((double) (byte) 1);
        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot9.getRangeAxis();
        categoryPlot9.setRangeCrosshairValue((double) '#');
        statisticalBarRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot9);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent16 = null;
        categoryPlot9.rendererChanged(rendererChangeEvent16);
        org.jfree.chart.plot.CategoryMarker categoryMarker19 = null;
        org.jfree.chart.util.Layer layer20 = org.jfree.chart.util.Layer.BACKGROUND;
        try {
            categoryPlot9.addDomainMarker(12, categoryMarker19, layer20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryURLGenerator2);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNotNull(layer20);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D6 = labelBlock5.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D6, "", "Preceding");
        numberAxis1.setDownArrow((java.awt.Shape) rectangle2D6);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis1.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        double double13 = numberAxis12.getUpperBound();
        boolean boolean14 = numberAxis12.getAutoRangeStickyZero();
        boolean boolean15 = numberAxis12.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer16);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Point2D point2D21 = null;
        xYPlot17.zoomRangeAxes(0.0d, (double) 100L, plotRenderingInfo20, point2D21);
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean24 = categoryPlot23.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot23.getDomainAxisEdge((int) (short) 0);
        float float27 = categoryPlot23.getForegroundAlpha();
        categoryPlot23.setDrawSharedDomainAxis(true);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier30 = categoryPlot23.getDrawingSupplier();
        xYPlot17.setDrawingSupplier(drawingSupplier30);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertTrue("'" + float27 + "' != '" + 1.0f + "'", float27 == 1.0f);
        org.junit.Assert.assertNotNull(drawingSupplier30);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D6 = labelBlock5.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D6, "", "Preceding");
        numberAxis1.setDownArrow((java.awt.Shape) rectangle2D6);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis1.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        double double13 = numberAxis12.getUpperBound();
        boolean boolean14 = numberAxis12.getAutoRangeStickyZero();
        boolean boolean15 = numberAxis12.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer16);
        xYPlot17.setRangeCrosshairVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean22 = categoryPlot21.isDomainGridlinesVisible();
        org.jfree.chart.axis.AxisLocation axisLocation23 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot21.setDomainAxisLocation(axisLocation23);
        xYPlot17.setRangeAxisLocation((int) (byte) 10, axisLocation23);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = xYPlot17.getRangeAxisEdge();
        boolean boolean27 = xYPlot17.isRangeGridlinesVisible();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D6 = labelBlock5.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D6, "", "Preceding");
        numberAxis1.setDownArrow((java.awt.Shape) rectangle2D6);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis1.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        double double13 = numberAxis12.getUpperBound();
        boolean boolean14 = numberAxis12.getAutoRangeStickyZero();
        boolean boolean15 = numberAxis12.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer16);
        java.awt.Stroke stroke18 = numberAxis12.getTickMarkStroke();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType0 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        org.junit.Assert.assertNotNull(categoryLabelWidthType0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.awt.Image image1 = null;
        projectInfo0.setLogo(image1);
        java.lang.String str3 = projectInfo0.getInfo();
        java.lang.String str4 = projectInfo0.getName();
        projectInfo0.setVersion("Preceding");
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNull(str4);
    }

//    @Test
//    public void test058() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test058");
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//        boolean boolean3 = segmentedTimeline0.containsDomainRange((long) 1, (long) 15);
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline4 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//        int int5 = segmentedTimeline4.getSegmentsIncluded();
//        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = new org.jfree.chart.axis.DateTickUnit(0, 5);
//        int int9 = dateTickUnit8.getRollUnit();
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month10.previous();
//        java.util.Date date12 = month10.getEnd();
//        org.jfree.chart.text.TextAnchor textAnchor14 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
//        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor15 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
//        org.jfree.chart.text.TextAnchor textAnchor16 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
//        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor15, textAnchor16);
//        org.jfree.chart.axis.DateTick dateTick19 = new org.jfree.chart.axis.DateTick(date12, "CONTRACT", textAnchor14, textAnchor16, 0.2d);
//        java.util.Date date20 = dateTickUnit8.addToDate(date12);
//        org.jfree.chart.axis.SegmentedTimeline.Segment segment21 = segmentedTimeline4.getSegment(date20);
//        org.jfree.data.time.DateRange dateRange22 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
//        double double23 = dateRange22.getCentralValue();
//        double double24 = dateRange22.getUpperBound();
//        java.util.Date date25 = dateRange22.getLowerDate();
//        segmentedTimeline4.addException(date25);
//        segmentedTimeline0.setBaseTimeline(segmentedTimeline4);
//        org.junit.Assert.assertNotNull(segmentedTimeline0);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertNotNull(segmentedTimeline4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 5 + "'", int5 == 5);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(textAnchor14);
//        org.junit.Assert.assertNotNull(itemLabelAnchor15);
//        org.junit.Assert.assertNotNull(textAnchor16);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(segment21);
//        org.junit.Assert.assertNotNull(dateRange22);
//        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.5d + "'", double23 == 0.5d);
//        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
//        org.junit.Assert.assertNotNull(date25);
//    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Paint paint1 = waterfallBarRenderer0.getPositiveBarPaint();
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D5 = labelBlock4.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity8 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D5, "", "Preceding");
        org.jfree.chart.entity.LegendItemEntity legendItemEntity9 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D5);
        java.lang.Comparable comparable10 = legendItemEntity9.getSeriesKey();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset11 = new org.jfree.data.category.DefaultCategoryDataset();
        legendItemEntity9.setDataset((org.jfree.data.general.Dataset) defaultCategoryDataset11);
        org.jfree.data.Range range13 = waterfallBarRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset11);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection14 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent15 = null;
        taskSeriesCollection14.seriesChanged(seriesChangeEvent15);
        int int18 = taskSeriesCollection14.indexOf((java.lang.Comparable) (-1L));
        int int19 = taskSeriesCollection14.getColumnCount();
        boolean boolean20 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.category.CategoryDataset) taskSeriesCollection14);
        java.util.List list21 = taskSeriesCollection14.getColumnKeys();
        org.jfree.data.Range range22 = waterfallBarRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection14);
        org.jfree.data.Range range23 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection14);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNull(comparable10);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNull(range22);
        org.junit.Assert.assertNull(range23);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator4 = piePlot3.getToolTipGenerator();
        java.awt.Color color5 = java.awt.Color.gray;
        piePlot3.setLabelShadowPaint((java.awt.Paint) color5);
        piePlot3.setExplodePercent((java.lang.Comparable) 8.0d, (double) 7);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        double double11 = numberAxis10.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock14 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D15 = labelBlock14.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity18 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D15, "", "Preceding");
        numberAxis10.setDownArrow((java.awt.Shape) rectangle2D15);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = numberAxis10.getLabelInsets();
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
        numberAxis10.setRightArrow(shape22);
        java.awt.Paint paint24 = numberAxis10.getLabelPaint();
        piePlot3.setBaseSectionPaint(paint24);
        java.awt.Color color26 = java.awt.Color.BLUE;
        piePlot3.setLabelBackgroundPaint((java.awt.Paint) color26);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator28 = piePlot3.getLegendLabelGenerator();
        piePlot1.setLegendLabelToolTipGenerator(pieSectionLabelGenerator28);
        org.junit.Assert.assertNull(pieToolTipGenerator4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator28);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) categoryPlot0, jFreeChart1, 200, (int) (byte) 0);
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot0.setRangeAxisLocation(axisLocation5, false);
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = null;
        org.jfree.chart.util.Layer layer9 = null;
        try {
            categoryPlot0.addDomainMarker(categoryMarker8, layer9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation5);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        org.jfree.chart.renderer.OutlierListCollection outlierListCollection0 = new org.jfree.chart.renderer.OutlierListCollection();
        outlierListCollection0.setHighFarOut(false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator2 = piePlot1.getToolTipGenerator();
        java.awt.Color color3 = java.awt.Color.gray;
        piePlot1.setLabelShadowPaint((java.awt.Paint) color3);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator5 = null;
        piePlot1.setToolTipGenerator(pieToolTipGenerator5);
        java.awt.Color color7 = java.awt.Color.BLUE;
        java.awt.Color color8 = java.awt.Color.orange;
        int int9 = color8.getGreen();
        float[] floatArray15 = new float[] { (short) 0, 10.0f, (short) 10, (byte) 0, 0.0f };
        float[] floatArray16 = color8.getColorComponents(floatArray15);
        float[] floatArray17 = color7.getColorComponents(floatArray15);
        piePlot1.setLabelBackgroundPaint((java.awt.Paint) color7);
        org.junit.Assert.assertNull(pieToolTipGenerator2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 200 + "'", int9 == 200);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D6 = labelBlock5.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D6, "", "Preceding");
        numberAxis1.setDownArrow((java.awt.Shape) rectangle2D6);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis1.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        double double13 = numberAxis12.getUpperBound();
        boolean boolean14 = numberAxis12.getAutoRangeStickyZero();
        boolean boolean15 = numberAxis12.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer16);
        xYPlot17.setRangeCrosshairVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean22 = categoryPlot21.isDomainGridlinesVisible();
        org.jfree.chart.axis.AxisLocation axisLocation23 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot21.setDomainAxisLocation(axisLocation23);
        xYPlot17.setRangeAxisLocation((int) (byte) 10, axisLocation23);
        boolean boolean26 = xYPlot17.isRangeGridlinesVisible();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        axisState0.cursorRight((double) (byte) 1);
        double double3 = axisState0.getMax();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month1.previous();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        boolean boolean4 = month1.equals((java.lang.Object) chartChangeEventType3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month1.previous();
        org.jfree.data.gantt.Task task6 = new org.jfree.data.gantt.Task("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=10.0]", (org.jfree.data.time.TimePeriod) month1);
        java.lang.Object obj7 = task6.clone();
        org.jfree.data.time.TimePeriod timePeriod8 = task6.getDuration();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(chartChangeEventType3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(timePeriod8);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(200);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        java.awt.geom.GeneralPath generalPath0 = null;
        java.awt.geom.GeneralPath generalPath1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(generalPath0, generalPath1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation5 = categoryPlot0.getDomainAxisLocation((int) '4');
        org.jfree.chart.axis.AxisSpace axisSpace6 = new org.jfree.chart.axis.AxisSpace();
        categoryPlot0.setFixedRangeAxisSpace(axisSpace6);
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot0);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        double double10 = numberAxis9.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock13 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D14 = labelBlock13.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity17 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D14, "", "Preceding");
        numberAxis9.setDownArrow((java.awt.Shape) rectangle2D14);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = numberAxis9.getLabelInsets();
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
        numberAxis9.setRightArrow(shape21);
        java.awt.Paint paint23 = numberAxis9.getLabelPaint();
        boolean boolean24 = legendTitle8.equals((java.lang.Object) numberAxis9);
        legendTitle8.setMargin((double) 15, (double) (byte) 10, (double) 3, (double) 9);
        java.awt.Graphics2D graphics2D30 = null;
        org.jfree.chart.util.Size2D size2D31 = legendTitle8.arrange(graphics2D30);
        java.lang.String str32 = size2D31.toString();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(size2D31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Size2D[width=0.0, height=0.0]" + "'", str32.equals("Size2D[width=0.0, height=0.0]"));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        org.jfree.data.time.DateRange dateRange0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str1 = dateRange0.toString();
        org.jfree.data.Range range4 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange0, 0.0d, true);
        org.junit.Assert.assertNotNull(dateRange0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str1.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertNotNull(range4);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        statisticalBarRenderer0.setBasePaint(paint1);
        boolean boolean3 = statisticalBarRenderer0.getIncludeBaseInRange();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer4.setSeriesLinesVisible((int) '4', (java.lang.Boolean) true);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor9 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE7;
        org.jfree.chart.text.TextAnchor textAnchor10 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor11 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor9, textAnchor10, textAnchor11, (double) 0L);
        lineAndShapeRenderer4.setSeriesNegativeItemLabelPosition((int) '4', itemLabelPosition13);
        statisticalBarRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition13);
        statisticalBarRenderer0.setIncludeBaseInRange(true);
        java.awt.Shape shape19 = statisticalBarRenderer0.getSeriesShape(0);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(itemLabelAnchor9);
        org.junit.Assert.assertNotNull(textAnchor10);
        org.junit.Assert.assertNotNull(textAnchor11);
        org.junit.Assert.assertNull(shape19);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        double double3 = numberAxis2.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D7 = labelBlock6.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity10 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D7, "", "Preceding");
        numberAxis2.setDownArrow((java.awt.Shape) rectangle2D7);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = numberAxis2.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        double double14 = numberAxis13.getUpperBound();
        boolean boolean15 = numberAxis13.getAutoRangeStickyZero();
        boolean boolean16 = numberAxis13.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis13, xYItemRenderer17);
        xYPlot18.setRangeCrosshairVisible(false);
        java.lang.String str21 = xYPlot18.getPlotType();
        org.jfree.chart.axis.ValueAxis valueAxis22 = xYPlot18.getDomainAxis();
        double double23 = valueAxis22.getFixedDimension();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer24 = null;
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis22, polarItemRenderer24);
        org.jfree.chart.plot.PlotOrientation plotOrientation26 = polarPlot25.getOrientation();
        polarPlot25.removeCornerTextItem("GradientPaintTransformType.VERTICAL");
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "XY Plot" + "'", str21.equals("XY Plot"));
        org.junit.Assert.assertNotNull(valueAxis22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(plotOrientation26);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D(1.561964399999E12d, (double) (short) -1);
        double double3 = size2D2.getHeight();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        org.jfree.chart.block.CenterArrangement centerArrangement8 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.block.BlockContainer blockContainer9 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) centerArrangement8);
        double double10 = blockContainer9.getContentYOffset();
        java.util.List list11 = blockContainer9.getBlocks();
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem12 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) 0.5f, (java.lang.Number) (byte) 1, (java.lang.Number) 0.0d, (java.lang.Number) 10, (java.lang.Number) 10.0d, (java.lang.Number) 2.0d, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0E-8d, list11);
        java.lang.Number number13 = boxAndWhiskerItem12.getMedian();
        java.lang.Object obj14 = null;
        boolean boolean15 = boxAndWhiskerItem12.equals(obj14);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + (byte) 1 + "'", number13.equals((byte) 1));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        java.lang.String str1 = rectangleConstraint0.toString();
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]" + "'", str1.equals("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]"));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) (byte) 100, (double) (short) 100);
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer7 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = statisticalBarRenderer7.getSeriesURLGenerator((int) (short) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer10 = null;
        statisticalBarRenderer7.setGradientPaintTransformer(gradientPaintTransformer10);
        java.awt.Paint paint13 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        statisticalBarRenderer7.setSeriesOutlinePaint(2019, paint13);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer16 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.block.LabelBlock labelBlock19 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D20 = labelBlock19.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity23 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D20, "", "Preceding");
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double25 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D20, rectangleEdge24);
        statisticalBarRenderer16.setBaseShape((java.awt.Shape) rectangle2D20, true);
        statisticalBarRenderer7.setSeriesShape(1, (java.awt.Shape) rectangle2D20);
        org.jfree.chart.axis.AxisState axisState29 = new org.jfree.chart.axis.AxisState();
        try {
            java.lang.Object obj30 = blockContainer5.draw(graphics2D6, rectangle2D20, (java.lang.Object) axisState29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNull(categoryURLGenerator9);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        org.jfree.data.KeyToGroupMap keyToGroupMap1 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable) 10.0f);
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.previous();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType4 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        boolean boolean5 = month2.equals((java.lang.Object) chartChangeEventType4);
        java.lang.Comparable comparable6 = keyToGroupMap1.getGroup((java.lang.Comparable) month2);
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker((double) 500);
        valueMarker8.setLabel("ThreadContext");
        float float11 = valueMarker8.getAlpha();
        boolean boolean12 = keyToGroupMap1.equals((java.lang.Object) valueMarker8);
        java.util.List list13 = keyToGroupMap1.getGroups();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(chartChangeEventType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 10.0f + "'", comparable6.equals(10.0f));
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.8f + "'", float11 == 0.8f);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(list13);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D6 = labelBlock5.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D6, "", "Preceding");
        numberAxis1.setDownArrow((java.awt.Shape) rectangle2D6);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis1.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        double double13 = numberAxis12.getUpperBound();
        boolean boolean14 = numberAxis12.getAutoRangeStickyZero();
        boolean boolean15 = numberAxis12.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer16);
        xYPlot17.setRangeCrosshairVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = xYPlot17.getRangeAxisEdge(1);
        xYPlot17.mapDatasetToRangeAxis(500, 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = xYPlot17.getRangeAxisEdge((int) '4');
        org.jfree.data.general.DatasetGroup datasetGroup27 = xYPlot17.getDatasetGroup();
        java.lang.String str28 = xYPlot17.getNoDataMessage();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertNull(datasetGroup27);
        org.junit.Assert.assertNull(str28);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke1 = defaultDrawingSupplier0.getNextStroke();
        org.jfree.data.time.DateRange dateRange2 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double3 = dateRange2.getCentralValue();
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double5 = dateRange4.getCentralValue();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange2, (org.jfree.data.Range) dateRange4);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType7 = rectangleConstraint6.getHeightConstraintType();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType8 = rectangleConstraint6.getHeightConstraintType();
        boolean boolean9 = defaultDrawingSupplier0.equals((java.lang.Object) rectangleConstraint6);
        java.awt.Stroke stroke10 = defaultDrawingSupplier0.getNextStroke();
        java.awt.Paint paint11 = defaultDrawingSupplier0.getNextOutlinePaint();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(dateRange2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.5d + "'", double3 == 0.5d);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.5d + "'", double5 == 0.5d);
        org.junit.Assert.assertNotNull(lengthConstraintType7);
        org.junit.Assert.assertNotNull(lengthConstraintType8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint11);
    }

//    @Test
//    public void test080() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test080");
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//        boolean boolean3 = segmentedTimeline0.containsDomainRange((long) 1, (long) 15);
//        int int4 = segmentedTimeline0.getGroupSegmentCount();
//        org.junit.Assert.assertNotNull(segmentedTimeline0);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 7 + "'", int4 == 7);
//    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(200);
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D5 = labelBlock4.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity8 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D5, "", "Preceding");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection11 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range12 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection11);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity15 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D5, "CategoryLabelEntity: category=false, tooltip=, url=Preceding", "ThreadContext", (org.jfree.data.category.CategoryDataset) taskSeriesCollection11, (java.lang.Comparable) 'a', (java.lang.Comparable) 0L);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month16.previous();
        long long18 = month16.getLastMillisecond();
        categoryItemEntity15.setRowKey((java.lang.Comparable) long18);
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.time.DateRange dateRange21 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double22 = dateRange21.getCentralValue();
        double double23 = dateRange21.getUpperBound();
        java.util.Date date24 = dateRange21.getLowerDate();
        java.util.Date date25 = dateRange21.getUpperDate();
        dateAxis20.setMaximumDate(date25);
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance(date25);
        categoryItemEntity15.setColumnKey((java.lang.Comparable) serialDate27);
        boolean boolean29 = spreadsheetDate1.isOn(serialDate27);
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1561964399999L + "'", long18 == 1561964399999L);
        org.junit.Assert.assertNotNull(dateRange21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.5d + "'", double22 == 0.5d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        int int2 = month1.getYearValue();
        int int3 = month1.getMonth();
        defaultKeyedValues0.addValue((java.lang.Comparable) int3, (double) (byte) 100);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.JFreeChart jFreeChart7 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent10 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) categoryPlot6, jFreeChart7, 200, (int) (byte) 0);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor11 = categoryPlot6.getDomainGridlinePosition();
        categoryPlot6.setAnchorValue((double) 900000L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = categoryPlot20.getAxisOffset();
        org.jfree.chart.block.LabelBlock labelBlock24 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D25 = labelBlock24.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity28 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D25, "", "Preceding");
        org.jfree.chart.entity.LegendItemEntity legendItemEntity29 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D25);
        java.awt.geom.Rectangle2D rectangle2D30 = rectangleInsets21.createOutsetRectangle(rectangle2D25);
        java.awt.geom.Point2D point2D31 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(0.0d, (double) 900000L, rectangle2D25);
        categoryPlot6.zoomRangeAxes((double) 3600000L, (double) 0.5f, plotRenderingInfo17, point2D31);
        org.jfree.chart.util.SortOrder sortOrder33 = categoryPlot6.getRowRenderingOrder();
        defaultKeyedValues0.sortByValues(sortOrder33);
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer36 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        org.jfree.data.KeyToGroupMap keyToGroupMap38 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable) 10.0f);
        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = month39.previous();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType41 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        boolean boolean42 = month39.equals((java.lang.Object) chartChangeEventType41);
        java.lang.Comparable comparable43 = keyToGroupMap38.getGroup((java.lang.Comparable) month39);
        org.jfree.chart.plot.ValueMarker valueMarker45 = new org.jfree.chart.plot.ValueMarker((double) 500);
        valueMarker45.setLabel("ThreadContext");
        float float48 = valueMarker45.getAlpha();
        boolean boolean49 = keyToGroupMap38.equals((java.lang.Object) valueMarker45);
        groupedStackedBarRenderer36.setSeriesToGroupMap(keyToGroupMap38);
        org.jfree.data.time.DateRange dateRange51 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str52 = dateRange51.toString();
        java.util.Date date53 = dateRange51.getUpperDate();
        int int54 = keyToGroupMap38.getGroupIndex((java.lang.Comparable) date53);
        try {
            defaultKeyedValues0.insertValue(200, (java.lang.Comparable) int54, (double) 45471L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 'position' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNotNull(categoryAnchor11);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(point2D31);
        org.junit.Assert.assertNotNull(sortOrder33);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(chartChangeEventType41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + comparable43 + "' != '" + 10.0f + "'", comparable43.equals(10.0f));
        org.junit.Assert.assertTrue("'" + float48 + "' != '" + 0.8f + "'", float48 == 0.8f);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(dateRange51);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str52.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.time.DateRange dateRange1 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double2 = dateRange1.getCentralValue();
        org.jfree.data.time.DateRange dateRange3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double4 = dateRange3.getCentralValue();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange1, (org.jfree.data.Range) dateRange3);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.time.DateRange dateRange7 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double8 = dateRange7.getCentralValue();
        org.jfree.data.time.DateRange dateRange9 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double10 = dateRange9.getCentralValue();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange7, (org.jfree.data.Range) dateRange9);
        numberAxis6.setRangeWithMargins((org.jfree.data.Range) dateRange7, true, false);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange1, (org.jfree.data.Range) dateRange7);
        dateAxis0.setRange((org.jfree.data.Range) dateRange1, false, true);
        dateAxis0.setInverted(false);
        java.text.DateFormat dateFormat21 = dateAxis0.getDateFormatOverride();
        org.junit.Assert.assertNotNull(dateRange1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5d + "'", double2 == 0.5d);
        org.junit.Assert.assertNotNull(dateRange3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.5d + "'", double4 == 0.5d);
        org.junit.Assert.assertNotNull(dateRange7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.5d + "'", double8 == 0.5d);
        org.junit.Assert.assertNotNull(dateRange9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.5d + "'", double10 == 0.5d);
        org.junit.Assert.assertNull(dateFormat21);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        java.lang.Comparable[] comparableArray8 = new java.lang.Comparable[] { "CategoryLabelEntity: category=false, tooltip=, url=Preceding", "rect", (short) 1, (-1) };
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year13 = month12.getYear();
        java.lang.Comparable[] comparableArray15 = new java.lang.Comparable[] { 10.0d, ' ', 15, month12, 1.0f };
        java.lang.Number[] numberArray22 = new java.lang.Number[] { 10L, 1, 15, 3600000L, 200, 0.5f };
        java.lang.Number[][] numberArray23 = new java.lang.Number[][] { numberArray22 };
        java.lang.Number[][] numberArray24 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset25 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray8, comparableArray15, numberArray23, numberArray24);
        org.jfree.data.category.CategoryDataset categoryDataset26 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("({0}, {1}) = {3} - {4}", "hi!", numberArray23);
        org.jfree.data.category.CategoryDataset categoryDataset27 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BASELINE_RIGHT", "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", numberArray23);
        org.junit.Assert.assertNotNull(comparableArray8);
        org.junit.Assert.assertNotNull(year13);
        org.junit.Assert.assertNotNull(comparableArray15);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(categoryDataset26);
        org.junit.Assert.assertNotNull(categoryDataset27);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = statisticalBarRenderer0.getSeriesURLGenerator((int) (short) 100);
        int int3 = statisticalBarRenderer0.getColumnCount();
        double double4 = statisticalBarRenderer0.getItemMargin();
        java.lang.Class<?> wildcardClass5 = statisticalBarRenderer0.getClass();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator8 = statisticalBarRenderer0.getItemLabelGenerator((int) (byte) 0, (int) (byte) 1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = statisticalBarRenderer0.getBaseURLGenerator();
        double double10 = statisticalBarRenderer0.getUpperClip();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor12 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE7;
        org.jfree.chart.text.TextAnchor textAnchor13 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor14 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor12, textAnchor13, textAnchor14, (double) 0L);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor17 = itemLabelPosition16.getItemLabelAnchor();
        statisticalBarRenderer0.setSeriesPositiveItemLabelPosition((int) '#', itemLabelPosition16, true);
        boolean boolean20 = statisticalBarRenderer0.getIncludeBaseInRange();
        org.junit.Assert.assertNull(categoryURLGenerator2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2d + "'", double4 == 0.2d);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(categoryItemLabelGenerator8);
        org.junit.Assert.assertNull(categoryURLGenerator9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(itemLabelAnchor12);
        org.junit.Assert.assertNotNull(textAnchor13);
        org.junit.Assert.assertNotNull(textAnchor14);
        org.junit.Assert.assertNotNull(itemLabelAnchor17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D6 = labelBlock5.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D6, "", "Preceding");
        numberAxis1.setDownArrow((java.awt.Shape) rectangle2D6);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis1.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        double double13 = numberAxis12.getUpperBound();
        boolean boolean14 = numberAxis12.getAutoRangeStickyZero();
        boolean boolean15 = numberAxis12.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer16);
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        xYPlot17.setDataset(5, xYDataset19);
        xYPlot17.setRangeCrosshairValue((double) 1577865599999L);
        boolean boolean23 = xYPlot17.isOutlineVisible();
        xYPlot17.clearRangeMarkers();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = statisticalBarRenderer0.getSeriesURLGenerator((int) (short) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        statisticalBarRenderer0.setGradientPaintTransformer(gradientPaintTransformer3);
        java.awt.Paint paint6 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        statisticalBarRenderer0.setSeriesOutlinePaint(2019, paint6);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator8 = statisticalBarRenderer0.getLegendItemURLGenerator();
        java.lang.Object obj9 = statisticalBarRenderer0.clone();
        java.awt.Paint paint11 = statisticalBarRenderer0.getSeriesOutlinePaint(8);
        org.junit.Assert.assertNull(categoryURLGenerator2);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator8);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(paint11);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.MINUTE_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 60000L + "'", long0 == 60000L);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        java.util.Date date2 = month0.getEnd();
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor5 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor5, textAnchor6);
        org.jfree.chart.axis.DateTick dateTick9 = new org.jfree.chart.axis.DateTick(date2, "CONTRACT", textAnchor4, textAnchor6, 0.2d);
        double double10 = dateTick9.getValue();
        double double11 = dateTick9.getValue();
        org.jfree.chart.text.TextAnchor textAnchor12 = dateTick9.getTextAnchor();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(itemLabelAnchor5);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.561964399999E12d + "'", double10 == 1.561964399999E12d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.561964399999E12d + "'", double11 == 1.561964399999E12d);
        org.junit.Assert.assertNotNull(textAnchor12);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Shape shape1 = org.jfree.chart.util.SerialUtilities.readShape(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator2 = piePlot1.getToolTipGenerator();
        java.awt.Color color3 = java.awt.Color.gray;
        piePlot1.setLabelShadowPaint((java.awt.Paint) color3);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator5 = null;
        piePlot1.setToolTipGenerator(pieToolTipGenerator5);
        piePlot1.setBackgroundAlpha((float) 45471L);
        org.junit.Assert.assertNull(pieToolTipGenerator2);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = statisticalBarRenderer1.getSeriesURLGenerator((int) (short) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer4 = null;
        statisticalBarRenderer1.setGradientPaintTransformer(gradientPaintTransformer4);
        java.awt.Paint paint8 = statisticalBarRenderer1.getItemPaint((int) (byte) 100, (int) '#');
        java.awt.Shape shape10 = statisticalBarRenderer1.getSeriesShape(3);
        boolean boolean11 = statisticalBarRenderer1.getAutoPopulateSeriesOutlineStroke();
        int int12 = statisticalBarRenderer1.getPassCount();
        org.jfree.chart.block.LabelBlock labelBlock15 = new org.jfree.chart.block.LabelBlock("");
        java.awt.Font font16 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        labelBlock15.setFont(font16);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer18 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator20 = statisticalBarRenderer18.getSeriesURLGenerator((int) (short) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer21 = null;
        statisticalBarRenderer18.setGradientPaintTransformer(gradientPaintTransformer21);
        java.awt.Paint paint24 = statisticalBarRenderer18.lookupSeriesFillPaint(0);
        org.jfree.chart.text.TextFragment textFragment25 = new org.jfree.chart.text.TextFragment("", font16, paint24);
        statisticalBarRenderer1.setBaseItemLabelFont(font16);
        java.awt.Color color27 = java.awt.Color.BLACK;
        int int28 = color27.getBlue();
        int int29 = color27.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock30 = new org.jfree.chart.block.LabelBlock("ClassContext", font16, (java.awt.Paint) color27);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer31 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean32 = lineAndShapeRenderer31.getDrawOutlines();
        java.lang.Boolean boolean34 = lineAndShapeRenderer31.getSeriesLinesVisible(5);
        boolean boolean35 = lineAndShapeRenderer31.getDrawOutlines();
        lineAndShapeRenderer31.setUseFillPaint(false);
        boolean boolean38 = labelBlock30.equals((java.lang.Object) lineAndShapeRenderer31);
        java.lang.Comparable[] comparableArray45 = new java.lang.Comparable[] { "CategoryLabelEntity: category=false, tooltip=, url=Preceding", "rect", (short) 1, (-1) };
        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year50 = month49.getYear();
        java.lang.Comparable[] comparableArray52 = new java.lang.Comparable[] { 10.0d, ' ', 15, month49, 1.0f };
        java.lang.Number[] numberArray59 = new java.lang.Number[] { 10L, 1, 15, 3600000L, 200, 0.5f };
        java.lang.Number[][] numberArray60 = new java.lang.Number[][] { numberArray59 };
        java.lang.Number[][] numberArray61 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset62 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray45, comparableArray52, numberArray60, numberArray61);
        org.jfree.data.category.CategoryDataset categoryDataset63 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("({0}, {1}) = {3} - {4}", "hi!", numberArray60);
        org.jfree.data.Range range64 = lineAndShapeRenderer31.findRangeBounds(categoryDataset63);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNull(categoryURLGenerator20);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNull(boolean34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(comparableArray45);
        org.junit.Assert.assertNotNull(year50);
        org.junit.Assert.assertNotNull(comparableArray52);
        org.junit.Assert.assertNotNull(numberArray59);
        org.junit.Assert.assertNotNull(numberArray60);
        org.junit.Assert.assertNotNull(categoryDataset63);
        org.junit.Assert.assertNotNull(range64);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Nearest" + "'", str1.equals("Nearest"));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.labels.IntervalCategoryToolTipGenerator intervalCategoryToolTipGenerator2 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator("Preceding", numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer1 = new org.jfree.chart.renderer.category.StackedBarRenderer(false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = null;
        stackedBarRenderer1.setBaseURLGenerator(categoryURLGenerator2);
        stackedBarRenderer1.setRenderAsPercentages(false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.ASCENDING;
        java.awt.Paint paint1 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        boolean boolean2 = sortOrder0.equals((java.lang.Object) paint1);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent7 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) categoryPlot3, jFreeChart4, 200, (int) (byte) 0);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor8 = categoryPlot3.getDomainGridlinePosition();
        categoryPlot3.setAnchorValue((double) 900000L, false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer12 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke13 = statisticalBarRenderer12.getBaseStroke();
        categoryPlot3.setRangeCrosshairStroke(stroke13);
        boolean boolean15 = sortOrder0.equals((java.lang.Object) stroke13);
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(categoryAnchor8);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getUpperBound();
        boolean boolean2 = numberAxis0.getAutoRangeStickyZero();
        boolean boolean3 = numberAxis0.isAutoRange();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = numberAxis0.getMarkerBand();
        java.awt.Shape shape5 = numberAxis0.getUpArrow();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(markerAxisBand4);
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 200, (double) (short) 100, false);
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D7 = labelBlock6.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity10 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D7, "", "Preceding");
        org.jfree.chart.entity.LegendItemEntity legendItemEntity11 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D7);
        stackedBarRenderer3D3.setBaseShape((java.awt.Shape) rectangle2D7);
        org.junit.Assert.assertNotNull(rectangle2D7);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 1L, (double) 31);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        double double6 = numberAxis5.getUpperBound();
        boolean boolean7 = numberAxis5.getAutoRangeStickyZero();
        org.jfree.chart.plot.Marker marker8 = null;
        org.jfree.data.general.WaferMapDataset waferMapDataset9 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot10 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset9);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.block.LabelBlock labelBlock14 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D15 = labelBlock14.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity18 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D15, "", "Preceding");
        waferMapPlot10.drawBackgroundImage(graphics2D11, rectangle2D15);
        stackedBarRenderer3D2.drawRangeMarker(graphics2D3, categoryPlot4, (org.jfree.chart.axis.ValueAxis) numberAxis5, marker8, rectangle2D15);
        double double21 = categoryPlot4.getRangeCrosshairValue();
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection23 = categoryPlot4.getDomainMarkers(layer22);
        org.jfree.chart.axis.ValueAxis valueAxis25 = categoryPlot4.getRangeAxis((int) (short) -1);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertNull(collection23);
        org.junit.Assert.assertNull(valueAxis25);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D3 = labelBlock2.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity6 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D3, "", "Preceding");
        org.jfree.chart.entity.LegendItemEntity legendItemEntity7 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D3);
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator8 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator9 = null;
        java.lang.String str10 = legendItemEntity7.getImageMapAreaTag(toolTipTagFragmentGenerator8, uRLTagFragmentGenerator9);
        java.lang.String str11 = legendItemEntity7.getShapeType();
        org.junit.Assert.assertNotNull(rectangle2D3);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "rect" + "'", str11.equals("rect"));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = statisticalBarRenderer1.getSeriesURLGenerator((int) (short) 100);
        int int4 = statisticalBarRenderer1.getColumnCount();
        double double5 = statisticalBarRenderer1.getItemMargin();
        java.lang.Class<?> wildcardClass6 = statisticalBarRenderer1.getClass();
        java.io.InputStream inputStream7 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("java.awt.Color[r=128,g=128,b=128]", (java.lang.Class) wildcardClass6);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNull(inputStream7);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryPlot0.getAxisOffset();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer2 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = statisticalBarRenderer2.getSeriesURLGenerator((int) (short) 100);
        int int5 = statisticalBarRenderer2.getColumnCount();
        double double6 = statisticalBarRenderer2.getItemMargin();
        java.awt.Paint paint7 = statisticalBarRenderer2.getBaseItemLabelPaint();
        categoryPlot0.setRangeGridlinePaint(paint7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        categoryPlot0.setRenderer(3, categoryItemRenderer10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = categoryPlot0.getRenderer(12);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.JFreeChart jFreeChart15 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent18 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) categoryPlot14, jFreeChart15, 200, (int) (byte) 0);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor19 = categoryPlot14.getDomainGridlinePosition();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        categoryPlot14.zoomDomainAxes(100.0d, plotRenderingInfo21, point2D22);
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis();
        double double26 = numberAxis25.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock29 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D30 = labelBlock29.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity33 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D30, "", "Preceding");
        numberAxis25.setDownArrow((java.awt.Shape) rectangle2D30);
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = numberAxis25.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis();
        double double37 = numberAxis36.getUpperBound();
        boolean boolean38 = numberAxis36.getAutoRangeStickyZero();
        boolean boolean39 = numberAxis36.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer40 = null;
        org.jfree.chart.plot.XYPlot xYPlot41 = new org.jfree.chart.plot.XYPlot(xYDataset24, (org.jfree.chart.axis.ValueAxis) numberAxis25, (org.jfree.chart.axis.ValueAxis) numberAxis36, xYItemRenderer40);
        xYPlot41.setRangeCrosshairVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean46 = categoryPlot45.isDomainGridlinesVisible();
        org.jfree.chart.axis.AxisLocation axisLocation47 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot45.setDomainAxisLocation(axisLocation47);
        xYPlot41.setRangeAxisLocation((int) (byte) 10, axisLocation47);
        categoryPlot14.setDomainAxisLocation(axisLocation47, false);
        categoryPlot14.setRangeCrosshairLockedOnData(true);
        java.awt.Font font54 = categoryPlot14.getNoDataMessageFont();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder55 = categoryPlot14.getDatasetRenderingOrder();
        org.jfree.chart.axis.CategoryAxis categoryAxis56 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis56.setLowerMargin((double) 10.0f);
        categoryAxis56.configure();
        categoryAxis56.removeCategoryLabelToolTip((java.lang.Comparable) "First");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D62 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean63 = categoryAxis3D62.isAxisLineVisible();
        java.lang.Object obj64 = categoryAxis3D62.clone();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray65 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis56, categoryAxis3D62 };
        categoryPlot14.setDomainAxes(categoryAxisArray65);
        categoryPlot0.setDomainAxes(categoryAxisArray65);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(categoryItemRenderer13);
        org.junit.Assert.assertNotNull(categoryAnchor19);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0d + "'", double26 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.0d + "'", double37 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(axisLocation47);
        org.junit.Assert.assertNotNull(font54);
        org.junit.Assert.assertNotNull(datasetRenderingOrder55);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNotNull(obj64);
        org.junit.Assert.assertNotNull(categoryAxisArray65);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        float float2 = waferMapPlot1.getForegroundAlpha();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        waferMapPlot1.markerChanged(markerChangeEvent3);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        double double7 = numberAxis6.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock10 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D11 = labelBlock10.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity14 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D11, "", "Preceding");
        numberAxis6.setDownArrow((java.awt.Shape) rectangle2D11);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = numberAxis6.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis();
        double double18 = numberAxis17.getUpperBound();
        boolean boolean19 = numberAxis17.getAutoRangeStickyZero();
        boolean boolean20 = numberAxis17.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis17, xYItemRenderer21);
        boolean boolean23 = xYPlot22.isDomainCrosshairVisible();
        org.jfree.chart.axis.AxisLocation axisLocation25 = xYPlot22.getRangeAxisLocation((int) (short) -1);
        xYPlot22.setRangeCrosshairVisible(false);
        waferMapPlot1.setParent((org.jfree.chart.plot.Plot) xYPlot22);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(axisLocation25);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        java.lang.Object obj1 = strokeList0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        double double3 = numberAxis2.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D7 = labelBlock6.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity10 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D7, "", "Preceding");
        numberAxis2.setDownArrow((java.awt.Shape) rectangle2D7);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = numberAxis2.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        double double14 = numberAxis13.getUpperBound();
        boolean boolean15 = numberAxis13.getAutoRangeStickyZero();
        boolean boolean16 = numberAxis13.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis13, xYItemRenderer17);
        xYPlot18.setRangeCrosshairVisible(false);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("WMAP_Plot", (org.jfree.chart.plot.Plot) xYPlot18);
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle();
        jFreeChart21.addSubtitle((org.jfree.chart.title.Title) textTitle22);
        org.jfree.chart.title.TextTitle textTitle24 = new org.jfree.chart.title.TextTitle();
        boolean boolean25 = textTitle24.getExpandToFitSpace();
        jFreeChart21.setTitle(textTitle24);
        java.awt.Font font27 = textTitle24.getFont();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(font27);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        java.awt.Color color0 = java.awt.Color.pink;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = statisticalBarRenderer1.getSeriesURLGenerator((int) (short) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer4 = null;
        statisticalBarRenderer1.setGradientPaintTransformer(gradientPaintTransformer4);
        java.awt.Paint paint8 = statisticalBarRenderer1.getItemPaint((int) (byte) 100, (int) '#');
        statisticalBarRenderer1.setSeriesCreateEntities(31, (java.lang.Boolean) true);
        org.jfree.chart.LegendItemCollection legendItemCollection12 = statisticalBarRenderer1.getLegendItems();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator13 = null;
        statisticalBarRenderer1.setBaseURLGenerator(categoryURLGenerator13);
        java.awt.Font font15 = statisticalBarRenderer1.getBaseItemLabelFont();
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj17 = textTitle16.clone();
        java.awt.Paint paint18 = textTitle16.getPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean20 = categoryPlot19.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = categoryPlot19.getDomainAxisEdge((int) (short) 0);
        categoryPlot19.setAnchorValue((double) 10.0f, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot19.getDomainAxisEdge();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment27 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.VerticalAlignment verticalAlignment28 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = categoryPlot29.getAxisOffset();
        org.jfree.chart.block.LabelBlock labelBlock33 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D34 = labelBlock33.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity37 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D34, "", "Preceding");
        org.jfree.chart.entity.LegendItemEntity legendItemEntity38 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D34);
        java.awt.geom.Rectangle2D rectangle2D39 = rectangleInsets30.createOutsetRectangle(rectangle2D34);
        double double40 = rectangleInsets30.getBottom();
        org.jfree.chart.title.TextTitle textTitle41 = new org.jfree.chart.title.TextTitle("TextAnchor.BASELINE_RIGHT", font15, paint18, rectangleEdge26, horizontalAlignment27, verticalAlignment28, rectangleInsets30);
        org.jfree.data.general.PieDataset pieDataset42 = null;
        org.jfree.chart.plot.PiePlot piePlot43 = new org.jfree.chart.plot.PiePlot(pieDataset42);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator44 = piePlot43.getToolTipGenerator();
        java.awt.Font font45 = piePlot43.getLabelFont();
        java.awt.Stroke stroke47 = piePlot43.getSectionOutlineStroke((java.lang.Comparable) 0L);
        piePlot43.setCircular(false);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions51 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(0.0d);
        boolean boolean52 = piePlot43.equals((java.lang.Object) 0.0d);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator53 = piePlot43.getLegendLabelToolTipGenerator();
        java.awt.Paint paint54 = piePlot43.getLabelOutlinePaint();
        textTitle41.setPaint(paint54);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(legendItemCollection12);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertNotNull(horizontalAlignment27);
        org.junit.Assert.assertNotNull(verticalAlignment28);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNotNull(rectangle2D39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNull(pieToolTipGenerator44);
        org.junit.Assert.assertNotNull(font45);
        org.junit.Assert.assertNull(stroke47);
        org.junit.Assert.assertNotNull(categoryLabelPositions51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator53);
        org.junit.Assert.assertNotNull(paint54);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean1 = lineAndShapeRenderer0.getDrawOutlines();
        java.lang.Boolean boolean3 = lineAndShapeRenderer0.getSeriesLinesVisible(5);
        boolean boolean4 = lineAndShapeRenderer0.getDrawOutlines();
        boolean boolean5 = lineAndShapeRenderer0.getBaseShapesVisible();
        lineAndShapeRenderer0.setBaseItemLabelsVisible(true);
        boolean boolean8 = lineAndShapeRenderer0.getBaseShapesVisible();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(boolean3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

//    @Test
//    public void test109() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test109");
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//        long long1 = segmentedTimeline0.getStartTime();
//        org.junit.Assert.assertNotNull(segmentedTimeline0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-2208960000000L) + "'", long1 == (-2208960000000L));
//    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        double[] doubleArray6 = new double[] { (-1L), 0.0d };
        double[] doubleArray9 = new double[] { (-1L), 0.0d };
        double[] doubleArray12 = new double[] { (-1L), 0.0d };
        double[] doubleArray15 = new double[] { (-1L), 0.0d };
        double[][] doubleArray16 = new double[][] { doubleArray6, doubleArray9, doubleArray12, doubleArray15 };
        org.jfree.data.category.CategoryDataset categoryDataset17 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", doubleArray16);
        org.jfree.data.category.CategoryDataset categoryDataset18 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray16);
        double[] doubleArray25 = new double[] { (-1L), 0.0d };
        double[] doubleArray28 = new double[] { (-1L), 0.0d };
        double[] doubleArray31 = new double[] { (-1L), 0.0d };
        double[] doubleArray34 = new double[] { (-1L), 0.0d };
        double[][] doubleArray35 = new double[][] { doubleArray25, doubleArray28, doubleArray31, doubleArray34 };
        org.jfree.data.category.CategoryDataset categoryDataset36 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", doubleArray35);
        org.jfree.data.category.CategoryDataset categoryDataset37 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray35);
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset38 = new org.jfree.data.category.DefaultIntervalCategoryDataset(doubleArray16, doubleArray35);
        double[] doubleArray43 = new double[] { (-1L), 0.0d };
        double[] doubleArray46 = new double[] { (-1L), 0.0d };
        double[] doubleArray49 = new double[] { (-1L), 0.0d };
        double[] doubleArray52 = new double[] { (-1L), 0.0d };
        double[][] doubleArray53 = new double[][] { doubleArray43, doubleArray46, doubleArray49, doubleArray52 };
        org.jfree.data.category.CategoryDataset categoryDataset54 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", doubleArray53);
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset55 = new org.jfree.data.category.DefaultIntervalCategoryDataset(doubleArray16, doubleArray53);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D56 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean57 = categoryAxis3D56.isAxisLineVisible();
        java.lang.Object obj58 = categoryAxis3D56.clone();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D60 = new org.jfree.chart.axis.NumberAxis3D("TextAnchor.BASELINE_RIGHT");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer61 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator63 = statisticalBarRenderer61.getSeriesURLGenerator((int) (short) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer64 = null;
        statisticalBarRenderer61.setGradientPaintTransformer(gradientPaintTransformer64);
        java.awt.Paint paint67 = statisticalBarRenderer61.lookupSeriesFillPaint(0);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator68 = null;
        statisticalBarRenderer61.setBaseToolTipGenerator(categoryToolTipGenerator68, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition72 = null;
        statisticalBarRenderer61.setSeriesNegativeItemLabelPosition(0, itemLabelPosition72);
        statisticalBarRenderer61.setSeriesItemLabelsVisible(200, false);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D79 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 1L, (double) 31);
        boolean boolean81 = stackedBarRenderer3D79.equals((java.lang.Object) (-1.0f));
        stackedBarRenderer3D79.setRenderAsPercentages(true);
        java.awt.Stroke stroke86 = stackedBarRenderer3D79.getItemOutlineStroke(100, 3);
        statisticalBarRenderer61.setBaseStroke(stroke86, false);
        statisticalBarRenderer61.setAutoPopulateSeriesOutlinePaint(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot91 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultIntervalCategoryDataset55, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D56, (org.jfree.chart.axis.ValueAxis) numberAxis3D60, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer61);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(categoryDataset17);
        org.junit.Assert.assertNotNull(categoryDataset18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(categoryDataset36);
        org.junit.Assert.assertNotNull(categoryDataset37);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(categoryDataset54);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertNotNull(obj58);
        org.junit.Assert.assertNull(categoryURLGenerator63);
        org.junit.Assert.assertNotNull(paint67);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNotNull(stroke86);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range1 = numberAxis0.getDefaultAutoRange();
        boolean boolean3 = numberAxis0.equals((java.lang.Object) (byte) -1);
        java.awt.Color color4 = java.awt.Color.RED;
        java.awt.Color color5 = color4.darker();
        numberAxis0.setTickLabelPaint((java.awt.Paint) color4);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit7 = numberAxis0.getTickUnit();
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(numberTickUnit7);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D3 = labelBlock2.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity6 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D3, "", "Preceding");
        org.jfree.chart.entity.LegendItemEntity legendItemEntity7 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D3);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint9 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        statisticalBarRenderer8.setBasePaint(paint9);
        org.jfree.chart.title.LegendGraphic legendGraphic11 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape) rectangle2D3, paint9);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = legendGraphic11.getShapeAnchor();
        boolean boolean13 = legendGraphic11.isShapeOutlineVisible();
        java.awt.Stroke stroke14 = legendGraphic11.getOutlineStroke();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean16 = lineAndShapeRenderer15.getDrawOutlines();
        java.lang.Boolean boolean18 = lineAndShapeRenderer15.getSeriesLinesVisible(5);
        boolean boolean19 = lineAndShapeRenderer15.getDrawOutlines();
        boolean boolean20 = lineAndShapeRenderer15.getBaseShapesVisible();
        java.awt.Color color21 = java.awt.Color.gray;
        java.awt.Color color22 = color21.brighter();
        lineAndShapeRenderer15.setBaseItemLabelPaint((java.awt.Paint) color21, true);
        legendGraphic11.setFillPaint((java.awt.Paint) color21);
        org.junit.Assert.assertNotNull(rectangle2D3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNull(boolean18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(color22);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        java.awt.color.ColorSpace colorSpace1 = color0.getColorSpace();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(colorSpace1);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D2 = labelBlock1.getBounds();
        boolean boolean4 = labelBlock1.equals((java.lang.Object) 1);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = labelBlock1.getPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        labelBlock1.setMargin(rectangleInsets6);
        org.junit.Assert.assertNotNull(rectangle2D2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 500);
        java.awt.Stroke stroke2 = valueMarker1.getOutlineStroke();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType3 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean5 = lengthAdjustmentType3.equals((java.lang.Object) lineAndShapeRenderer4);
        java.lang.String str6 = lengthAdjustmentType3.toString();
        valueMarker1.setLabelOffsetType(lengthAdjustmentType3);
        java.awt.Stroke stroke8 = valueMarker1.getOutlineStroke();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(lengthAdjustmentType3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "CONTRACT" + "'", str6.equals("CONTRACT"));
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = statisticalBarRenderer0.getSeriesURLGenerator((int) (short) 100);
        int int3 = statisticalBarRenderer0.getColumnCount();
        double double4 = statisticalBarRenderer0.getItemMargin();
        java.lang.Class<?> wildcardClass5 = statisticalBarRenderer0.getClass();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator8 = statisticalBarRenderer0.getItemLabelGenerator((int) (byte) 0, (int) (byte) 1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = statisticalBarRenderer0.getBaseURLGenerator();
        double double10 = statisticalBarRenderer0.getUpperClip();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor12 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE7;
        org.jfree.chart.text.TextAnchor textAnchor13 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor14 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor12, textAnchor13, textAnchor14, (double) 0L);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor17 = itemLabelPosition16.getItemLabelAnchor();
        statisticalBarRenderer0.setSeriesPositiveItemLabelPosition((int) '#', itemLabelPosition16, true);
        org.jfree.chart.event.RendererChangeListener rendererChangeListener20 = null;
        try {
            statisticalBarRenderer0.removeChangeListener(rendererChangeListener20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryURLGenerator2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2d + "'", double4 == 0.2d);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(categoryItemLabelGenerator8);
        org.junit.Assert.assertNull(categoryURLGenerator9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(itemLabelAnchor12);
        org.junit.Assert.assertNotNull(textAnchor13);
        org.junit.Assert.assertNotNull(textAnchor14);
        org.junit.Assert.assertNotNull(itemLabelAnchor17);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("First");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]");
        java.lang.Throwable throwable2 = null;
        try {
            unknownKeyException1.addSuppressed(throwable2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        int int2 = month1.getYearValue();
        int int3 = month1.getMonth();
        defaultKeyedValues0.addValue((java.lang.Comparable) int3, (double) (byte) 100);
        try {
            defaultKeyedValues0.insertValue(6, (java.lang.Comparable) 0.5d, (double) 10.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 'position' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        boolean boolean1 = textTitle0.getExpandToFitSpace();
        textTitle0.setNotify(false);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryPlot5.getAxisOffset();
        org.jfree.chart.block.LabelBlock labelBlock9 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D10 = labelBlock9.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity13 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D10, "", "Preceding");
        org.jfree.chart.entity.LegendItemEntity legendItemEntity14 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D10);
        java.awt.geom.Rectangle2D rectangle2D15 = rectangleInsets6.createOutsetRectangle(rectangle2D10);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean17 = categoryPlot16.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = categoryPlot16.getDomainAxisEdge((int) (short) 0);
        categoryPlot16.setAnchorValue((double) 10.0f, false);
        org.jfree.data.category.CategoryDataset categoryDataset24 = categoryPlot16.getDataset(2019);
        org.jfree.chart.event.PlotChangeListener plotChangeListener25 = null;
        categoryPlot16.removeChangeListener(plotChangeListener25);
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis();
        double double28 = numberAxis27.getUpperBound();
        boolean boolean29 = numberAxis27.getAutoRangeStickyZero();
        boolean boolean30 = numberAxis27.isAutoRange();
        categoryPlot16.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis27);
        java.lang.Object obj32 = textTitle0.draw(graphics2D4, rectangle2D10, (java.lang.Object) categoryPlot16);
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = categoryPlot16.getDomainAxisEdge();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertNull(categoryDataset24);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0d + "'", double28 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNull(obj32);
        org.junit.Assert.assertNotNull(rectangleEdge33);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = barRenderer0.lookupSeriesShape(7);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        barRenderer0.setSeriesURLGenerator((int) (byte) 0, categoryURLGenerator4);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = barRenderer0.getBaseToolTipGenerator();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryToolTipGenerator6);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.time.DateRange dateRange1 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double2 = dateRange1.getCentralValue();
        org.jfree.data.time.DateRange dateRange3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double4 = dateRange3.getCentralValue();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange1, (org.jfree.data.Range) dateRange3);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.time.DateRange dateRange7 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double8 = dateRange7.getCentralValue();
        org.jfree.data.time.DateRange dateRange9 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double10 = dateRange9.getCentralValue();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange7, (org.jfree.data.Range) dateRange9);
        numberAxis6.setRangeWithMargins((org.jfree.data.Range) dateRange7, true, false);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange1, (org.jfree.data.Range) dateRange7);
        dateAxis0.setRange((org.jfree.data.Range) dateRange1, false, true);
        java.text.DateFormat dateFormat19 = null;
        dateAxis0.setDateFormatOverride(dateFormat19);
        dateAxis0.setVisible(true);
        org.junit.Assert.assertNotNull(dateRange1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5d + "'", double2 == 0.5d);
        org.junit.Assert.assertNotNull(dateRange3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.5d + "'", double4 == 0.5d);
        org.junit.Assert.assertNotNull(dateRange7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.5d + "'", double8 == 0.5d);
        org.junit.Assert.assertNotNull(dateRange9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.5d + "'", double10 == 0.5d);
    }

//    @Test
//    public void test124() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test124");
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//        long long2 = segmentedTimeline0.getTimeFromLong(3600000L);
//        int int3 = segmentedTimeline0.getGroupSegmentCount();
//        segmentedTimeline0.setStartTime((long) (-65536));
//        org.junit.Assert.assertNotNull(segmentedTimeline0);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3600000L + "'", long2 == 3600000L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 7 + "'", int3 == 7);
//    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D3 = labelBlock2.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity6 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D3, "", "Preceding");
        org.jfree.chart.entity.LegendItemEntity legendItemEntity7 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D3);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint9 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        statisticalBarRenderer8.setBasePaint(paint9);
        org.jfree.chart.title.LegendGraphic legendGraphic11 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape) rectangle2D3, paint9);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = legendGraphic11.getShapeAnchor();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = legendGraphic11.getShapeAnchor();
        java.awt.Paint paint14 = legendGraphic11.getFillPaint();
        legendGraphic11.setShapeOutlineVisible(true);
        boolean boolean17 = legendGraphic11.isShapeOutlineVisible();
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType19 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean21 = lengthAdjustmentType19.equals((java.lang.Object) lineAndShapeRenderer20);
        java.lang.String str22 = lengthAdjustmentType19.toString();
        org.jfree.chart.block.LabelBlock labelBlock25 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D26 = labelBlock25.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity29 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D26, "", "Preceding");
        boolean boolean30 = lengthAdjustmentType19.equals((java.lang.Object) rectangle2D26);
        java.awt.Shape shape34 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D26, 0.0d, (float) 1561964399999L, (float) 10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer35 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer35.setSeriesLinesVisible((int) '4', (java.lang.Boolean) true);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor40 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE7;
        org.jfree.chart.text.TextAnchor textAnchor41 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor42 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition44 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor40, textAnchor41, textAnchor42, (double) 0L);
        lineAndShapeRenderer35.setSeriesNegativeItemLabelPosition((int) '4', itemLabelPosition44);
        org.jfree.chart.block.LineBorder lineBorder47 = new org.jfree.chart.block.LineBorder();
        java.awt.Graphics2D graphics2D48 = null;
        org.jfree.chart.block.LabelBlock labelBlock51 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D52 = labelBlock51.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity55 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D52, "", "Preceding");
        org.jfree.chart.entity.LegendItemEntity legendItemEntity56 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D52);
        lineBorder47.draw(graphics2D48, rectangle2D52);
        java.awt.Paint paint58 = lineBorder47.getPaint();
        lineAndShapeRenderer35.setSeriesItemLabelPaint((int) (short) 10, paint58, false);
        try {
            java.lang.Object obj61 = legendGraphic11.draw(graphics2D18, rectangle2D26, (java.lang.Object) false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(lengthAdjustmentType19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "CONTRACT" + "'", str22.equals("CONTRACT"));
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNotNull(itemLabelAnchor40);
        org.junit.Assert.assertNotNull(textAnchor41);
        org.junit.Assert.assertNotNull(textAnchor42);
        org.junit.Assert.assertNotNull(rectangle2D52);
        org.junit.Assert.assertNotNull(paint58);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.util.List list1 = keyedObjects2D0.getColumnKeys();
        org.jfree.chart.axis.AxisCollection axisCollection2 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list3 = axisCollection2.getAxesAtBottom();
        java.util.List list4 = axisCollection2.getAxesAtTop();
        boolean boolean5 = keyedObjects2D0.equals((java.lang.Object) axisCollection2);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        float[] floatArray6 = new float[] { 5, 10.0f, 900000L, (-2208960000000L) };
        float[] floatArray7 = color1.getRGBComponents(floatArray6);
        java.awt.Color color8 = java.awt.Color.getColor("AreaRendererEndType.LEVEL", color1);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        int int1 = categoryAxis3D0.getMaximumCategoryLabelLines();
        org.jfree.chart.plot.Plot plot2 = categoryAxis3D0.getPlot();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNull(plot2);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        org.jfree.chart.LegendItem legendItem3 = boxAndWhiskerRenderer0.getLegendItem((int) (byte) 10, 5);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState5 = null;
        org.jfree.data.general.WaferMapDataset waferMapDataset6 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot7 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset6);
        java.lang.String str8 = waferMapPlot7.getPlotType();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.block.LabelBlock labelBlock12 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D13 = labelBlock12.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity16 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D13, "", "Preceding");
        waferMapPlot7.drawBackgroundImage(graphics2D9, rectangle2D13);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.JFreeChart jFreeChart19 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent22 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) categoryPlot18, jFreeChart19, 200, (int) (byte) 0);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor23 = categoryPlot18.getDomainGridlinePosition();
        categoryPlot18.setAnchorValue((double) 900000L, false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer27 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke28 = statisticalBarRenderer27.getBaseStroke();
        categoryPlot18.setRangeCrosshairStroke(stroke28);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D30 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.data.xy.XYDataset xYDataset31 = null;
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis();
        double double33 = numberAxis32.getUpperBound();
        boolean boolean34 = numberAxis32.getAutoRangeStickyZero();
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis();
        double double36 = numberAxis35.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock39 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D40 = labelBlock39.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity43 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D40, "", "Preceding");
        numberAxis35.setDownArrow((java.awt.Shape) rectangle2D40);
        org.jfree.chart.util.RectangleInsets rectangleInsets45 = numberAxis35.getLabelInsets();
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot46.setRangeCrosshairValue((double) (byte) 1);
        org.jfree.chart.axis.ValueAxis valueAxis49 = categoryPlot46.getRangeAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis51 = categoryPlot46.getDomainAxis((int) ' ');
        boolean boolean52 = numberAxis35.hasListener((java.util.EventListener) categoryPlot46);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer53 = null;
        org.jfree.chart.plot.XYPlot xYPlot54 = new org.jfree.chart.plot.XYPlot(xYDataset31, (org.jfree.chart.axis.ValueAxis) numberAxis32, (org.jfree.chart.axis.ValueAxis) numberAxis35, xYItemRenderer53);
        org.jfree.data.category.CategoryDataset categoryDataset55 = null;
        try {
            boxAndWhiskerRenderer0.drawItem(graphics2D4, categoryItemRendererState5, rectangle2D13, categoryPlot18, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D30, (org.jfree.chart.axis.ValueAxis) numberAxis32, categoryDataset55, (int) 'a', (-1), (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: BoxAndWhiskerRenderer.drawItem() : the data should be of type BoxAndWhiskerCategoryDataset only.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "WMAP_Plot" + "'", str8.equals("WMAP_Plot"));
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(categoryAnchor23);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.0d + "'", double33 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.0d + "'", double36 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D40);
        org.junit.Assert.assertNotNull(rectangleInsets45);
        org.junit.Assert.assertNull(valueAxis49);
        org.junit.Assert.assertNull(categoryAxis51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        java.awt.Paint paint0 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        defaultKeyedValues0.addValue((java.lang.Comparable) 0.8f, (java.lang.Number) (-65536));
        org.jfree.chart.util.StrokeList strokeList4 = new org.jfree.chart.util.StrokeList();
        boolean boolean5 = defaultKeyedValues0.equals((java.lang.Object) strokeList4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month6.previous();
        org.jfree.data.time.Year year8 = month6.getYear();
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        double double11 = numberAxis10.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock14 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D15 = labelBlock14.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity18 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D15, "", "Preceding");
        numberAxis10.setDownArrow((java.awt.Shape) rectangle2D15);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = numberAxis10.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis();
        double double22 = numberAxis21.getUpperBound();
        boolean boolean23 = numberAxis21.getAutoRangeStickyZero();
        boolean boolean24 = numberAxis21.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer25 = null;
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot(xYDataset9, (org.jfree.chart.axis.ValueAxis) numberAxis10, (org.jfree.chart.axis.ValueAxis) numberAxis21, xYItemRenderer25);
        boolean boolean27 = xYPlot26.isDomainCrosshairVisible();
        org.jfree.chart.axis.AxisLocation axisLocation29 = xYPlot26.getRangeAxisLocation((int) (short) -1);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer30 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke31 = statisticalBarRenderer30.getBaseStroke();
        xYPlot26.setDomainZeroBaselineStroke(stroke31);
        int int33 = year8.compareTo((java.lang.Object) stroke31);
        long long34 = year8.getLastMillisecond();
        defaultKeyedValues0.removeValue((java.lang.Comparable) year8);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(axisLocation29);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1577865599999L + "'", long34 == 1577865599999L);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D6 = labelBlock5.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D6, "", "Preceding");
        numberAxis1.setDownArrow((java.awt.Shape) rectangle2D6);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis1.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        double double13 = numberAxis12.getUpperBound();
        boolean boolean14 = numberAxis12.getAutoRangeStickyZero();
        boolean boolean15 = numberAxis12.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer16);
        xYPlot17.setRangeCrosshairVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = xYPlot17.getRangeAxisEdge(1);
        xYPlot17.mapDatasetToRangeAxis(500, 0);
        java.awt.Paint paint25 = xYPlot17.getRangeTickBandPaint();
        org.jfree.chart.plot.ValueMarker valueMarker28 = new org.jfree.chart.plot.ValueMarker((double) 500);
        java.awt.Stroke stroke29 = valueMarker28.getOutlineStroke();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType30 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer31 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean32 = lengthAdjustmentType30.equals((java.lang.Object) lineAndShapeRenderer31);
        java.lang.String str33 = lengthAdjustmentType30.toString();
        valueMarker28.setLabelOffsetType(lengthAdjustmentType30);
        java.awt.Paint paint35 = valueMarker28.getOutlinePaint();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor36 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE7;
        org.jfree.chart.text.TextAnchor textAnchor37 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor38 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition40 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor36, textAnchor37, textAnchor38, (double) 0L);
        valueMarker28.setLabelTextAnchor(textAnchor37);
        org.jfree.chart.util.Layer layer42 = null;
        xYPlot17.addRangeMarker(255, (org.jfree.chart.plot.Marker) valueMarker28, layer42);
        org.jfree.chart.plot.ValueMarker valueMarker45 = new org.jfree.chart.plot.ValueMarker((double) 500);
        java.awt.Font font46 = valueMarker45.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = valueMarker45.getLabelOffset();
        org.jfree.chart.util.Layer layer48 = null;
        xYPlot17.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker45, layer48);
        org.jfree.data.general.PieDataset pieDataset50 = null;
        org.jfree.chart.plot.PiePlot piePlot51 = new org.jfree.chart.plot.PiePlot(pieDataset50);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator52 = piePlot51.getToolTipGenerator();
        double double53 = piePlot51.getMaximumLabelWidth();
        valueMarker45.addChangeListener((org.jfree.chart.event.MarkerChangeListener) piePlot51);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertNull(paint25);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(lengthAdjustmentType30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "CONTRACT" + "'", str33.equals("CONTRACT"));
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(itemLabelAnchor36);
        org.junit.Assert.assertNotNull(textAnchor37);
        org.junit.Assert.assertNotNull(textAnchor38);
        org.junit.Assert.assertNotNull(font46);
        org.junit.Assert.assertNotNull(rectangleInsets47);
        org.junit.Assert.assertNull(pieToolTipGenerator52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.2d + "'", double53 == 0.2d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = null;
        taskSeriesCollection0.seriesChanged(seriesChangeEvent1);
        java.lang.Number number3 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        java.lang.Number number4 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = null;
        taskSeriesCollection0.seriesChanged(seriesChangeEvent5);
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0.0d + "'", number3.equals(0.0d));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.0d + "'", number4.equals(0.0d));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getUpperBound();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D6 = labelBlock5.getBounds();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, (java.awt.Shape) rectangle2D6, "", "Preceding");
        numberAxis1.setDownArrow((java.awt.Shape) rectangle2D6);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis1.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        double double13 = numberAxis12.getUpperBound();
        boolean boolean14 = numberAxis12.getAutoRangeStickyZero();
        boolean boolean15 = numberAxis12.isAutoRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer16);
        xYPlot17.setRangeCrosshairVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = xYPlot17.getRangeAxisEdge(1);
        xYPlot17.mapDatasetToRangeAxis(500, 0);
        java.awt.Paint paint25 = xYPlot17.getRangeTickBandPaint();
        org.jfree.chart.plot.ValueMarker valueMarker28 = new org.jfree.chart.plot.ValueMarker((double) 500);
        java.awt.Stroke stroke29 = valueMarker28.getOutlineStroke();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType30 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer31 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean32 = lengthAdjustmentType30.equals((java.lang.Object) lineAndShapeRenderer31);
        java.lang.String str33 = lengthAdjustmentType30.toString();
        valueMarker28.setLabelOffsetType(lengthAdjustmentType30);
        java.awt.Paint paint35 = valueMarker28.getOutlinePaint();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor36 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE7;
        org.jfree.chart.text.TextAnchor textAnchor37 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor38 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition40 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor36, textAnchor37, textAnchor38, (double) 0L);
        valueMarker28.setLabelTextAnchor(textAnchor37);
        org.jfree.chart.util.Layer layer42 = null;
        xYPlot17.addRangeMarker(255, (org.jfree.chart.plot.Marker) valueMarker28, layer42);
        java.awt.Stroke stroke44 = valueMarker28.getStroke();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertNull(paint25);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(lengthAdjustmentType30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "CONTRACT" + "'", str33.equals("CONTRACT"));
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(itemLabelAnchor36);
        org.junit.Assert.assertNotNull(textAnchor37);
        org.junit.Assert.assertNotNull(textAnchor38);
        org.junit.Assert.assertNotNull(stroke44);
    }
}

