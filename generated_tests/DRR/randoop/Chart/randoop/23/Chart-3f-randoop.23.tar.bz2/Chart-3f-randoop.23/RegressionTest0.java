import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        int int0 = org.jfree.data.time.Year.MINIMUM_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-9999) + "'", int0 == (-9999));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Calendar calendar1 = null;
        try {
            year0.peg(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = year0.getLastMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = year0.getFirstMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        int int0 = org.jfree.data.time.Year.MAXIMUM_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) ' ', 0, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("hi!");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.jfree.data.time.SerialDate serialDate0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(serialDate0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'serialDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = month0.getFirstMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (short) 1, seriesChangeInfo1);
        java.lang.Class<?> wildcardClass3 = seriesChangeEvent2.getClass();
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.util.TimeZone timeZone3 = null;
        try {
            org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date1, timeZone3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 5");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year((int) '#');
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year7, (double) '#', true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = regularTimePeriod2.getMiddleMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, 1, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
        int int6 = day2.compareTo((java.lang.Object) 1L);
        long long7 = day2.getLastMillisecond();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = day2.getLastMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) (byte) 10, false);
        timeSeries9.setNotify(false);
        java.util.Collection collection16 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries9);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        java.util.Date date18 = year17.getEnd();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
        java.lang.String str20 = day19.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day19.next();
        try {
            timeSeries1.add(regularTimePeriod21, (java.lang.Number) 1577865599999L, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Day, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "31-December-2019" + "'", str20.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod21);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        boolean boolean3 = year0.equals((java.lang.Object) (-1.0d));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.previous();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        try {
            timeSeries1.delete((-9999), 10, false);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -9999");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) '#', (int) '#', 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        java.util.Calendar calendar3 = null;
        try {
            year1.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        java.lang.String str5 = day4.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day4.next();
        int int7 = day4.getMonth();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (double) 100);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries1.removeChangeListener(seriesChangeListener10);
        try {
            org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy((int) (short) 10, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "31-December-2019" + "'", str5.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.util.TimeZone timeZone3 = null;
        try {
            org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date1, timeZone3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        java.util.TimeZone timeZone2 = null;
        try {
            org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date1, timeZone2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        java.lang.String str5 = day4.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day4.next();
        int int7 = day4.getMonth();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (double) 100);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries1.removeChangeListener(seriesChangeListener10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.addOrUpdate(timeSeriesDataItem12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "31-December-2019" + "'", str5.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) ' ', 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setNotify(false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = null;
        try {
            timeSeries1.add(timeSeriesDataItem8, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        java.util.Calendar calendar7 = null;
        try {
            long long8 = day4.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
        int int5 = day2.getMonth();
        java.lang.String str6 = day2.toString();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day2, "", "org.jfree.data.event.SeriesChangeEvent[source=1]");
        try {
            timeSeries9.update(10, (java.lang.Number) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "31-December-2019" + "'", str6.equals("31-December-2019"));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = month0.getFirstMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(12, 0, 9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'month' argument must be in the range 1 to 12.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        try {
            timeSeries1.delete((-1), 5, false);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setNotify(false);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = timeSeries1.getTimePeriod(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (short) 1, year1);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.util.Date date7 = year6.getEnd();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date7);
        java.lang.String str9 = day8.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day8.next();
        int int11 = day8.getMonth();
        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) day8, (double) 100);
        boolean boolean14 = year1.equals((java.lang.Object) day8);
        java.util.Calendar calendar15 = null;
        try {
            long long16 = year1.getLastMillisecond(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "31-December-2019" + "'", str9.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 12 + "'", int11 == 12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (short) 1, year1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.next();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = regularTimePeriod4.getMiddleMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.removeChangeListener(seriesChangeListener6);
        java.lang.Comparable comparable8 = timeSeries1.getKey();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.util.Date date10 = year9.getEnd();
        boolean boolean12 = year9.equals((java.lang.Object) (-1.0d));
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) 0.0f);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 'a' + "'", comparable8.equals('a'));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(10, 0, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        java.lang.Object obj8 = timeSeries1.clone();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        timeSeries10.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) (byte) 10, false);
        timeSeries10.setNotify(false);
        java.util.Collection collection17 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries10);
        timeSeries1.setDomainDescription("");
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year20, (java.lang.Number) (-1));
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(collection17);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        java.lang.Object obj8 = timeSeries1.clone();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        timeSeries10.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) month15, (java.lang.Number) (byte) 10, false);
        timeSeries14.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        timeSeries22.add((org.jfree.data.time.RegularTimePeriod) month23, (java.lang.Number) (byte) 10, false);
        timeSeries22.setNotify(false);
        java.util.Collection collection29 = timeSeries14.getTimePeriodsUniqueToOtherSeries(timeSeries22);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries22.getDataItem((org.jfree.data.time.RegularTimePeriod) year30);
        timeSeries10.add(timeSeriesDataItem31, false);
        try {
            timeSeries1.add(timeSeriesDataItem31);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(collection29);
        org.junit.Assert.assertNotNull(timeSeriesDataItem31);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
        java.util.Date date5 = regularTimePeriod4.getStart();
        java.util.TimeZone timeZone6 = null;
        try {
            org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5, timeZone6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod0 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod0, (double) 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries(comparable0, "2019", "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        boolean boolean3 = year0.equals((java.lang.Object) (-1.0d));
        int int5 = year0.compareTo((java.lang.Object) 1.0d);
        java.util.Calendar calendar6 = null;
        try {
            year0.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (short) 1, year1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.next();
        java.util.Calendar calendar5 = null;
        try {
            month3.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("35");
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = null;
        try {
            timeSeries1.update(regularTimePeriod6, (java.lang.Number) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        java.lang.String str5 = day4.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day4.next();
        int int7 = day4.getMonth();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (double) 100);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries1.addChangeListener(seriesChangeListener10);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.next();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        java.util.Date date16 = year15.getEnd();
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date16);
        long long18 = day17.getLastMillisecond();
        int int19 = year13.compareTo((java.lang.Object) day17);
        org.jfree.data.time.Year year21 = org.jfree.data.time.Year.parseYear("2019");
        int int22 = day17.compareTo((java.lang.Object) "2019");
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day17, 0.0d, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period 31-December-2019 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "31-December-2019" + "'", str5.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577865599999L + "'", long18 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(year21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        boolean boolean3 = year0.equals((java.lang.Object) (-1.0d));
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year0.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setNotify(false);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.lang.String str11 = year10.toString();
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year10, (double) 9999);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2019" + "'", str11.equals("2019"));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((-1), (int) ' ', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) (byte) 10, false);
        timeSeries9.setNotify(false);
        java.util.Collection collection16 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries9);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) year17);
        try {
            timeSeries9.delete((int) (short) 1, (int) (short) 1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertNotNull(timeSeriesDataItem18);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setRangeDescription("hi!");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeries1.getNextTimePeriod();
        timeSeries1.setNotify(true);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries1.getDataItem((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        boolean boolean3 = year1.equals((java.lang.Object) "31-December-2019");
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year1.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        timeSeries1.setDescription("");
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = timeSeries1.getTimePeriod(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.removeChangeListener(seriesChangeListener6);
        timeSeries1.setDomainDescription("31-December-2019");
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        java.util.Date date12 = year11.getEnd();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (short) 1, year11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year11.next();
        try {
            timeSeries1.add(regularTimePeriod14, (java.lang.Number) 0, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (short) 1, year1);
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year1.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setRangeDescription("hi!");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeries1.getNextTimePeriod();
        timeSeries1.setNotify(true);
        java.lang.String str11 = timeSeries1.getDescription();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        java.util.Date date13 = year12.getEnd();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        java.lang.String str15 = day14.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day14.next();
        int int17 = day14.getMonth();
        java.lang.String str18 = day14.toString();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day14, "", "org.jfree.data.event.SeriesChangeEvent[source=1]");
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day14, (double) (-1.0f));
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Day, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "31-December-2019" + "'", str15.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 12 + "'", int17 == 12);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "31-December-2019" + "'", str18.equals("31-December-2019"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        java.lang.Object obj8 = timeSeries1.clone();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        timeSeries10.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) (byte) 10, false);
        timeSeries10.setNotify(false);
        java.util.Collection collection17 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries10);
        timeSeries10.setDescription("org.jfree.data.time.TimePeriodFormatException: hi!");
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(collection17);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        double double2 = timeSeries1.getMinY();
        try {
            java.lang.Number number4 = timeSeries1.getValue(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod0 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod0, (java.lang.Number) (-9999));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        java.lang.String str5 = day4.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day4.next();
        int int7 = day4.getMonth();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (double) 100);
        long long10 = day4.getLastMillisecond();
        java.util.Calendar calendar11 = null;
        try {
            long long12 = day4.getFirstMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "31-December-2019" + "'", str5.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.time.TimePeriodFormatException: hi!");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) (byte) 10, false);
        timeSeries9.setNotify(false);
        java.util.Collection collection16 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries9);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) year17);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries9.addChangeListener(seriesChangeListener19);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        java.util.Date date23 = year22.getEnd();
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month((int) (short) 1, year22);
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        java.util.Date date28 = year27.getEnd();
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date28);
        java.lang.String str30 = day29.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = day29.next();
        int int32 = day29.getMonth();
        timeSeries26.add((org.jfree.data.time.RegularTimePeriod) day29, (double) 100);
        boolean boolean35 = year22.equals((java.lang.Object) day29);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day29, (java.lang.Number) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Day, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertNotNull(timeSeriesDataItem18);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "31-December-2019" + "'", str30.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 12 + "'", int32 == 12);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1, "", "hi!");
        try {
            timeSeries3.delete((int) 'a', (int) (short) 0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(3);
        java.util.Calendar calendar2 = null;
        try {
            year1.peg(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        java.util.Calendar calendar6 = null;
        try {
            month2.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        long long2 = month0.getFirstMillisecond();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = month0.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1559372400000L + "'", long2 == 1559372400000L);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) (byte) 10, false);
        timeSeries9.setNotify(false);
        java.util.Collection collection16 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries9);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) year17);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries9.addChangeListener(seriesChangeListener19);
        timeSeries9.setDomainDescription("");
        java.beans.PropertyChangeListener propertyChangeListener23 = null;
        timeSeries9.removePropertyChangeListener(propertyChangeListener23);
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertNotNull(timeSeriesDataItem18);
    }

//    @Test
//    public void test086() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test086");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.util.Date date1 = year0.getEnd();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        java.lang.String str3 = day2.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
//        int int6 = day2.compareTo((java.lang.Object) 1L);
//        long long7 = day2.getLastMillisecond();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int9 = day2.compareTo((java.lang.Object) day8);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day8.next();
//        java.util.Calendar calendar11 = null;
//        try {
//            long long12 = day8.getMiddleMillisecond(calendar11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 204 + "'", int9 == 204);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) '4', 0, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(31, 8, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        java.lang.String str5 = day4.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day4.next();
        int int7 = day4.getMonth();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (double) 100);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries1.removeChangeListener(seriesChangeListener10);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        java.lang.String str13 = year12.toString();
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year12, (java.lang.Number) 1);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "31-December-2019" + "'", str5.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019" + "'", str13.equals("2019"));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Calendar calendar1 = null;
        try {
            month0.peg(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.removeChangeListener(seriesChangeListener6);
        timeSeries1.setDomainDescription("31-December-2019");
        timeSeries1.fireSeriesChanged();
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        java.lang.String str6 = month2.toString();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = month2.getLastMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (short) 1, year1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year1.next();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year1.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
        java.util.Date date5 = regularTimePeriod4.getStart();
        java.util.TimeZone timeZone6 = null;
        java.util.Locale locale7 = null;
        try {
            org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date5, timeZone6, locale7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("35");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = timeSeries1.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setRangeDescription("hi!");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener8);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year((int) ' ');
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year11, (double) 3, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = month0.getLastMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        java.lang.String str5 = day4.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day4.next();
        int int7 = day4.getMonth();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (double) 100);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        boolean boolean13 = year10.equals((java.lang.Object) (-1.0d));
        int int15 = year10.compareTo((java.lang.Object) 1.0d);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        java.util.Date date17 = year16.getEnd();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date17);
        java.lang.String str19 = day18.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day18.next();
        int int21 = day18.getMonth();
        java.lang.String str22 = day18.toString();
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year10, (org.jfree.data.time.RegularTimePeriod) day18);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries1.getDataItem((int) (byte) 0);
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
        timeSeries27.add((org.jfree.data.time.RegularTimePeriod) month28, (java.lang.Number) (byte) 10, false);
        timeSeries27.setRangeDescription("hi!");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = timeSeries27.getNextTimePeriod();
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
        timeSeries36.add((org.jfree.data.time.RegularTimePeriod) month37, (java.lang.Number) (byte) 10, false);
        timeSeries36.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month();
        timeSeries44.add((org.jfree.data.time.RegularTimePeriod) month45, (java.lang.Number) (byte) 10, false);
        timeSeries44.setNotify(false);
        java.util.Collection collection51 = timeSeries36.getTimePeriodsUniqueToOtherSeries(timeSeries44);
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = timeSeries44.getDataItem((org.jfree.data.time.RegularTimePeriod) year52);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = timeSeries27.addOrUpdate(timeSeriesDataItem53);
        try {
            timeSeries1.add(timeSeriesDataItem54, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "31-December-2019" + "'", str5.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "31-December-2019" + "'", str19.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 12 + "'", int21 == 12);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "31-December-2019" + "'", str22.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertNotNull(timeSeriesDataItem25);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(collection51);
        org.junit.Assert.assertNotNull(timeSeriesDataItem53);
        org.junit.Assert.assertNotNull(timeSeriesDataItem54);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        java.lang.Object obj8 = timeSeries1.clone();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        timeSeries10.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) (byte) 10, false);
        timeSeries10.setNotify(false);
        java.util.Collection collection17 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries10);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries1.getDataItem((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(collection17);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setRangeDescription("hi!");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeries1.getNextTimePeriod();
        timeSeries1.setNotify(true);
        java.lang.String str11 = timeSeries1.getDescription();
        try {
            timeSeries1.delete((int) (byte) 10, (int) (byte) 100, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNull(str11);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        int int4 = day2.getYear();
        java.util.Calendar calendar5 = null;
        try {
            day2.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) (byte) 10, false);
        timeSeries9.setNotify(false);
        java.util.Collection collection16 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries9);
        boolean boolean17 = timeSeries1.getNotify();
        timeSeries1.removeAgedItems((long) 'a', true);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Date date23 = fixedMillisecond22.getTime();
        long long24 = fixedMillisecond22.getFirstMillisecond();
        java.util.Date date25 = fixedMillisecond22.getTime();
        long long26 = fixedMillisecond22.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond22.previous();
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (java.lang.Number) (short) 1, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 100L + "'", long24 == 100L);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 100L + "'", long26 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Date date2 = fixedMillisecond1.getTime();
        long long3 = fixedMillisecond1.getFirstMillisecond();
        java.util.Date date4 = fixedMillisecond1.getTime();
        java.lang.Object obj5 = null;
        int int6 = fixedMillisecond1.compareTo(obj5);
        java.util.Calendar calendar7 = null;
        fixedMillisecond1.peg(calendar7);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setRangeDescription("hi!");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeries1.getNextTimePeriod();
        timeSeries1.setDomainDescription("2019");
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        java.util.Date date12 = year11.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        java.lang.String str14 = day13.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day13.next();
        int int16 = day13.getMonth();
        java.lang.String str17 = day13.toString();
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day13, "", "org.jfree.data.event.SeriesChangeEvent[source=1]");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day13, (java.lang.Number) (-1L));
        try {
            timeSeries1.add(timeSeriesDataItem22);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Day, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "31-December-2019" + "'", str14.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 12 + "'", int16 == 12);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "31-December-2019" + "'", str17.equals("31-December-2019"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (short) 1, seriesChangeInfo1);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo3 = null;
        seriesChangeEvent2.setSummary(seriesChangeInfo3);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo5 = seriesChangeEvent2.getSummary();
        java.lang.Object obj6 = seriesChangeEvent2.getSource();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo7 = seriesChangeEvent2.getSummary();
        org.junit.Assert.assertNull(seriesChangeInfo5);
        org.junit.Assert.assertTrue("'" + obj6 + "' != '" + (short) 1 + "'", obj6.equals((short) 1));
        org.junit.Assert.assertNull(seriesChangeInfo7);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (short) 1, year1);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException5.getSuppressed();
        boolean boolean10 = month3.equals((java.lang.Object) throwableArray9);
        java.util.Calendar calendar11 = null;
        try {
            long long12 = month3.getFirstMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date1);
        java.util.TimeZone timeZone5 = null;
        java.util.Locale locale6 = null;
        try {
            org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date1, timeZone5, locale6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("June 2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        boolean boolean3 = year1.equals((java.lang.Object) 2);
        long long4 = year1.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61125897600001L) + "'", long4 == (-61125897600001L));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.Year year9 = org.jfree.data.time.Year.parseYear("2019");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) year9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = fixedMillisecond12.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = fixedMillisecond12.next();
        boolean boolean15 = timeSeriesDataItem10.equals((java.lang.Object) regularTimePeriod14);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        timeSeries17.add((org.jfree.data.time.RegularTimePeriod) month18, (java.lang.Number) (byte) 10, false);
        timeSeries17.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
        timeSeries25.add((org.jfree.data.time.RegularTimePeriod) month26, (java.lang.Number) (byte) 10, false);
        timeSeries25.setNotify(false);
        java.util.Collection collection32 = timeSeries17.getTimePeriodsUniqueToOtherSeries(timeSeries25);
        boolean boolean33 = timeSeriesDataItem10.equals((java.lang.Object) collection32);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(collection32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        int int4 = day2.getYear();
        int int6 = day2.compareTo((java.lang.Object) 0);
        int int7 = day2.getMonth();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) (byte) 10, false);
        timeSeries9.setNotify(false);
        java.util.Collection collection16 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries9);
        boolean boolean17 = timeSeries1.getNotify();
        timeSeries1.removeAgedItems((long) 'a', true);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = timeSeries1.getNextTimePeriod();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
        timeSeries25.add((org.jfree.data.time.RegularTimePeriod) month26, (java.lang.Number) (byte) 10, false);
        timeSeries25.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
        timeSeries33.add((org.jfree.data.time.RegularTimePeriod) month34, (java.lang.Number) (byte) 10, false);
        timeSeries33.setNotify(false);
        java.util.Collection collection40 = timeSeries25.getTimePeriodsUniqueToOtherSeries(timeSeries33);
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries33.getDataItem((org.jfree.data.time.RegularTimePeriod) year41);
        java.lang.Object obj43 = timeSeriesDataItem42.clone();
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = year45.next();
        int int47 = timeSeriesDataItem42.compareTo((java.lang.Object) year45);
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
        java.util.Date date51 = year50.getEnd();
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(date51);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = timeSeries49.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day52, (java.lang.Number) 0.0f);
        int int55 = timeSeriesDataItem42.compareTo((java.lang.Object) 0.0f);
        timeSeries23.add(timeSeriesDataItem42);
        try {
            timeSeries1.add(timeSeriesDataItem42, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period June 2019 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(collection40);
        org.junit.Assert.assertNotNull(timeSeriesDataItem42);
        org.junit.Assert.assertNotNull(obj43);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNull(timeSeriesDataItem54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Month month1 = new org.jfree.data.time.Month(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        java.util.Calendar calendar2 = null;
        try {
            year0.peg(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(35, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Date date2 = fixedMillisecond1.getTime();
        long long3 = fixedMillisecond1.getFirstMillisecond();
        java.util.Date date4 = fixedMillisecond1.getTime();
        java.lang.Object obj5 = null;
        int int6 = fixedMillisecond1.compareTo(obj5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        java.util.Date date8 = year7.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.lang.String str10 = day9.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day9.next();
        boolean boolean12 = fixedMillisecond1.equals((java.lang.Object) regularTimePeriod11);
        long long13 = fixedMillisecond1.getSerialIndex();
        java.util.Date date14 = fixedMillisecond1.getTime();
        java.util.TimeZone timeZone15 = null;
        try {
            org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date14, timeZone15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 100L + "'", long13 == 100L);
        org.junit.Assert.assertNotNull(date14);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "org.jfree.data.time.TimePeriodFormatException: hi!", "31-December-2019");
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        java.lang.String str5 = day4.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day4.next();
        int int7 = day4.getMonth();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (double) 100);
        try {
            timeSeries1.delete(0, (int) (short) 100, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "31-December-2019" + "'", str5.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) (byte) 10, false);
        timeSeries3.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        timeSeries11.add((org.jfree.data.time.RegularTimePeriod) month12, (java.lang.Number) (byte) 10, false);
        timeSeries11.setNotify(false);
        java.util.Collection collection18 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries11);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries11.getDataItem((org.jfree.data.time.RegularTimePeriod) year19);
        java.lang.Object obj21 = timeSeriesDataItem20.clone();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year23.next();
        int int25 = timeSeriesDataItem20.compareTo((java.lang.Object) year23);
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        java.util.Date date29 = year28.getEnd();
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date29);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries27.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day30, (java.lang.Number) 0.0f);
        int int33 = timeSeriesDataItem20.compareTo((java.lang.Object) 0.0f);
        timeSeries1.add(timeSeriesDataItem20);
        try {
            timeSeries1.update(7, (java.lang.Number) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection18);
        org.junit.Assert.assertNotNull(timeSeriesDataItem20);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNull(timeSeriesDataItem32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = null;
        try {
            timeSeries1.add(regularTimePeriod7, (java.lang.Number) 11, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
    }

//    @Test
//    public void test124() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test124");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
//        timeSeries1.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
//        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) (byte) 10, false);
//        timeSeries5.setNotify(false);
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
//        timeSeries13.add((org.jfree.data.time.RegularTimePeriod) month14, (java.lang.Number) (byte) 10, false);
//        timeSeries13.setNotify(false);
//        java.util.Collection collection20 = timeSeries5.getTimePeriodsUniqueToOtherSeries(timeSeries13);
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) year21);
//        timeSeries1.add(timeSeriesDataItem22, false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar26 = null;
//        long long27 = fixedMillisecond25.getFirstMillisecond(calendar26);
//        java.lang.Number number28 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25);
//        try {
//            timeSeries1.update(3, (java.lang.Number) 10L);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(collection20);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem22);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560185128497L + "'", long27 == 1560185128497L);
//        org.junit.Assert.assertTrue("'" + number28 + "' != '" + (byte) 10 + "'", number28.equals((byte) 10));
//    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        timeSeries1.setMaximumItemCount(2);
        java.lang.Class class10 = timeSeries1.getTimePeriodClass();
        long long11 = timeSeries1.getMaximumItemAge();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9223372036854775807L + "'", long11 == 9223372036854775807L);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        java.lang.String str5 = day4.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day4.next();
        int int7 = day4.getMonth();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (double) 100);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        timeSeries11.add((org.jfree.data.time.RegularTimePeriod) month12, (java.lang.Number) (byte) 10, false);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        java.util.Date date19 = year18.getEnd();
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date19);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries17.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day20, (java.lang.Number) 0.0f);
        boolean boolean23 = timeSeries17.getNotify();
        java.lang.Object obj24 = timeSeries17.clone();
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        timeSeries26.add((org.jfree.data.time.RegularTimePeriod) month27, (java.lang.Number) (byte) 10, false);
        timeSeries26.setNotify(false);
        java.util.Collection collection33 = timeSeries17.getTimePeriodsUniqueToOtherSeries(timeSeries26);
        int int34 = month12.compareTo((java.lang.Object) timeSeries17);
        int int35 = month12.getMonth();
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month12, (double) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "31-December-2019" + "'", str5.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertNotNull(collection33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 6 + "'", int35 == 6);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        double double2 = timeSeries1.getMinY();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

//    @Test
//    public void test128() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test128");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
//        timeSeries1.setNotify(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond8.getFirstMillisecond(calendar9);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
//        java.lang.Object obj12 = timeSeries1.clone();
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560185128766L + "'", long10 == 1560185128766L);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem11);
//        org.junit.Assert.assertNotNull(obj12);
//    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1577779200000L);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.Year year9 = org.jfree.data.time.Year.parseYear("2019");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) year9);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        timeSeries12.add((org.jfree.data.time.RegularTimePeriod) month13, (java.lang.Number) (byte) 10, false);
        timeSeries12.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
        timeSeries20.add((org.jfree.data.time.RegularTimePeriod) month21, (java.lang.Number) (byte) 10, false);
        timeSeries20.setNotify(false);
        java.util.Collection collection27 = timeSeries12.getTimePeriodsUniqueToOtherSeries(timeSeries20);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries20.getDataItem((org.jfree.data.time.RegularTimePeriod) year28);
        timeSeriesDataItem29.setValue((java.lang.Number) (byte) 1);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo33 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent34 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (short) 1, seriesChangeInfo33);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo35 = seriesChangeEvent34.getSummary();
        int int36 = timeSeriesDataItem29.compareTo((java.lang.Object) seriesChangeInfo35);
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month();
        timeSeries38.add((org.jfree.data.time.RegularTimePeriod) month39, (java.lang.Number) (byte) 10, false);
        timeSeries38.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month();
        timeSeries46.add((org.jfree.data.time.RegularTimePeriod) month47, (java.lang.Number) (byte) 10, false);
        timeSeries46.setNotify(false);
        java.util.Collection collection53 = timeSeries38.getTimePeriodsUniqueToOtherSeries(timeSeries46);
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem55 = timeSeries46.getDataItem((org.jfree.data.time.RegularTimePeriod) year54);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = year54.previous();
        boolean boolean57 = timeSeriesDataItem29.equals((java.lang.Object) year54);
        try {
            timeSeries1.add(timeSeriesDataItem29);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period June 2019 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(collection27);
        org.junit.Assert.assertNotNull(timeSeriesDataItem29);
        org.junit.Assert.assertNull(seriesChangeInfo35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(collection53);
        org.junit.Assert.assertNotNull(timeSeriesDataItem55);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) (byte) 10, false);
        timeSeries9.setNotify(false);
        java.util.Collection collection16 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries9);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) year17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year17.previous();
        long long20 = year17.getSerialIndex();
        java.util.Calendar calendar21 = null;
        try {
            year17.peg(calendar21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertNotNull(timeSeriesDataItem18);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2019L + "'", long20 == 2019L);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setRangeDescription("hi!");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeries1.getNextTimePeriod();
        timeSeries1.setNotify(true);
        java.lang.String str11 = timeSeries1.getDomainDescription();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year((int) '#');
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) year13);
        java.lang.Comparable comparable15 = timeSeries1.getKey();
        boolean boolean16 = timeSeries1.isEmpty();
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Time" + "'", str11.equals("Time"));
        org.junit.Assert.assertTrue("'" + comparable15 + "' != '" + 'a' + "'", comparable15.equals('a'));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setNotify(false);
        timeSeries1.fireSeriesChanged();
        timeSeries1.setMaximumItemAge((long) 31);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        try {
            java.lang.Number number3 = timeSeries1.getValue((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        java.lang.Object obj8 = null;
        boolean boolean9 = timeSeries1.equals(obj8);
        try {
            timeSeries1.delete(5, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod2, (java.lang.Number) (-1L));
        timeSeriesDataItem4.setSelected(false);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Time");
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.util.Date date4 = year3.getEnd();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        long long6 = day5.getLastMillisecond();
        int int7 = year1.compareTo((java.lang.Object) day5);
        org.jfree.data.time.Year year9 = org.jfree.data.time.Year.parseYear("2019");
        int int10 = day5.compareTo((java.lang.Object) "2019");
        org.jfree.data.time.SerialDate serialDate11 = day5.getSerialDate();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(serialDate11);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        java.util.List list8 = timeSeries1.getItems();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        timeSeries10.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) (byte) 10, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries10.removeChangeListener(seriesChangeListener15);
        org.jfree.data.time.Year year18 = org.jfree.data.time.Year.parseYear("2019");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries10.getDataItem((org.jfree.data.time.RegularTimePeriod) year18);
        try {
            timeSeries1.add(timeSeriesDataItem19, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNotNull(year18);
        org.junit.Assert.assertNotNull(timeSeriesDataItem19);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(3);
        long long2 = year1.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-62041132800001L) + "'", long2 == (-62041132800001L));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("2019");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        java.lang.String str5 = day4.toString();
        boolean boolean6 = year1.equals((java.lang.Object) str5);
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "31-December-2019" + "'", str5.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(10, (int) (byte) 100, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        java.util.Calendar calendar6 = null;
        try {
            long long7 = month2.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.removeChangeListener(seriesChangeListener6);
        java.lang.Comparable comparable8 = timeSeries1.getKey();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = null;
        try {
            timeSeries1.add(regularTimePeriod9, (java.lang.Number) 2, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 'a' + "'", comparable8.equals('a'));
    }

//    @Test
//    public void test145() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test145");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
//        timeSeries1.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
//        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) (byte) 10, false);
//        timeSeries5.setNotify(false);
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
//        timeSeries13.add((org.jfree.data.time.RegularTimePeriod) month14, (java.lang.Number) (byte) 10, false);
//        timeSeries13.setNotify(false);
//        java.util.Collection collection20 = timeSeries5.getTimePeriodsUniqueToOtherSeries(timeSeries13);
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) year21);
//        timeSeries1.add(timeSeriesDataItem22, false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar26 = null;
//        long long27 = fixedMillisecond25.getFirstMillisecond(calendar26);
//        java.lang.Number number28 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25);
//        long long29 = fixedMillisecond25.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(collection20);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem22);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560185130365L + "'", long27 == 1560185130365L);
//        org.junit.Assert.assertTrue("'" + number28 + "' != '" + (byte) 10 + "'", number28.equals((byte) 10));
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560185130365L + "'", long29 == 1560185130365L);
//    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        java.lang.Object obj8 = timeSeries1.clone();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        timeSeries10.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) (byte) 10, false);
        timeSeries10.setNotify(false);
        java.util.Collection collection17 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries10);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        timeSeries19.add((org.jfree.data.time.RegularTimePeriod) month20, (java.lang.Number) (byte) 10, false);
        timeSeries19.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
        timeSeries27.add((org.jfree.data.time.RegularTimePeriod) month28, (java.lang.Number) (byte) 10, false);
        timeSeries27.setNotify(false);
        java.util.Collection collection34 = timeSeries19.getTimePeriodsUniqueToOtherSeries(timeSeries27);
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries27.getDataItem((org.jfree.data.time.RegularTimePeriod) year35);
        timeSeriesDataItem36.setValue((java.lang.Number) (byte) 1);
        boolean boolean40 = timeSeriesDataItem36.equals((java.lang.Object) (-1.0f));
        try {
            timeSeries10.add(timeSeriesDataItem36, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period June 2019 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertNotNull(collection34);
        org.junit.Assert.assertNotNull(timeSeriesDataItem36);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Date date2 = fixedMillisecond1.getTime();
        long long3 = fixedMillisecond1.getFirstMillisecond();
        long long4 = fixedMillisecond1.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass1 = year0.getClass();
        java.lang.Class class2 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) wildcardClass1);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(class2);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setRangeDescription("hi!");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener8);
        java.util.Collection collection10 = timeSeries1.getTimePeriods();
        org.junit.Assert.assertNotNull(collection10);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        timeSeries1.setDescription("");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.addChangeListener(seriesChangeListener4);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        java.lang.Object obj8 = timeSeries1.clone();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        long long12 = day11.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) day11);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.util.Date date15 = year14.getEnd();
        long long16 = year14.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year14.next();
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year14, (java.lang.Number) (-1));
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43830L + "'", long12 == 43830L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1577865599999L + "'", long16 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        boolean boolean3 = year0.equals((java.lang.Object) (-1.0d));
        int int5 = year0.compareTo((java.lang.Object) 1.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year0.previous();
        java.util.Calendar calendar7 = null;
        try {
            year0.peg(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

//    @Test
//    public void test153() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test153");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
//        timeSeries1.setNotify(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond8.getFirstMillisecond(calendar9);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
//        try {
//            org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy(9, 12);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560185132932L + "'", long10 == 1560185132932L);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem11);
//    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        timeSeries1.setMaximumItemCount(2);
        java.lang.Class class10 = timeSeries1.getTimePeriodClass();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year((int) ' ');
        boolean boolean14 = year12.equals((java.lang.Object) "31-December-2019");
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year12, (double) 0);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException1.getSuppressed();
        java.lang.String str6 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray7);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        java.lang.Object obj8 = timeSeries1.clone();
        int int9 = timeSeries1.getItemCount();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
        int int5 = day2.getMonth();
        java.lang.String str6 = day2.toString();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day2, "", "org.jfree.data.event.SeriesChangeEvent[source=1]");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day2, (java.lang.Number) (-1L));
        java.lang.Number number12 = timeSeriesDataItem11.getValue();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "31-December-2019" + "'", str6.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (-1L) + "'", number12.equals((-1L)));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.Year year9 = org.jfree.data.time.Year.parseYear("2019");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) year9);
        timeSeries1.setNotify(true);
        java.lang.String str13 = timeSeries1.getDomainDescription();
        java.lang.Class class14 = timeSeries1.getTimePeriodClass();
        timeSeries1.removeAgedItems(true);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Time" + "'", str13.equals("Time"));
        org.junit.Assert.assertNotNull(class14);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod0 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod0, (java.lang.Number) Double.NaN);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
        int int3 = year1.getYear();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 35 + "'", int3 == 35);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("Time");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 5");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (short) 1, seriesChangeInfo1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (short) 1);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Date date2 = fixedMillisecond1.getTime();
        long long3 = fixedMillisecond1.getFirstMillisecond();
        java.util.Date date4 = fixedMillisecond1.getTime();
        java.lang.Object obj5 = null;
        int int6 = fixedMillisecond1.compareTo(obj5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        java.util.Date date8 = year7.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.lang.String str10 = day9.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day9.next();
        boolean boolean12 = fixedMillisecond1.equals((java.lang.Object) regularTimePeriod11);
        long long13 = fixedMillisecond1.getSerialIndex();
        java.util.Date date14 = fixedMillisecond1.getTime();
        java.util.TimeZone timeZone15 = null;
        try {
            org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date14, timeZone15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 100L + "'", long13 == 100L);
        org.junit.Assert.assertNotNull(date14);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        long long4 = day2.getFirstMillisecond();
        java.lang.String str5 = day2.toString();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577779200000L + "'", long4 == 1577779200000L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "31-December-2019" + "'", str5.equals("31-December-2019"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.Year year9 = org.jfree.data.time.Year.parseYear("2019");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) year9);
        timeSeries1.setNotify(true);
        java.lang.String str13 = timeSeries1.getRangeDescription();
        try {
            timeSeries1.delete(0, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Value" + "'", str13.equals("Value"));
    }

//    @Test
//    public void test166() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test166");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.util.Date date1 = year0.getEnd();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        java.lang.String str3 = day2.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
//        int int6 = day2.compareTo((java.lang.Object) 1L);
//        long long7 = day2.getLastMillisecond();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int9 = day2.compareTo((java.lang.Object) day8);
//        int int10 = day2.getDayOfMonth();
//        java.lang.String str11 = day2.toString();
//        java.lang.String str12 = day2.toString();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 204 + "'", int9 == 204);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 31 + "'", int10 == 31);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "31-December-2019" + "'", str11.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "31-December-2019" + "'", str12.equals("31-December-2019"));
//    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass1 = year0.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Date date4 = fixedMillisecond3.getTime();
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass1, date4, timeZone5);
        java.util.TimeZone timeZone7 = null;
        try {
            org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date4, timeZone7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(regularTimePeriod6);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.Year year9 = org.jfree.data.time.Year.parseYear("2019");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) year9);
        boolean boolean11 = timeSeries1.getNotify();
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) (byte) 10, false);
        timeSeries9.setNotify(false);
        java.util.Collection collection16 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries9);
        try {
            timeSeries1.delete(1, (int) (short) 10, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection16);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        int int6 = month2.getMonth();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = month2.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Date date2 = fixedMillisecond1.getTime();
        long long3 = fixedMillisecond1.getFirstMillisecond();
        java.util.Date date4 = fixedMillisecond1.getTime();
        java.lang.Object obj5 = null;
        int int6 = fixedMillisecond1.compareTo(obj5);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day11, (java.lang.Number) 0.0f);
        int int15 = day11.compareTo((java.lang.Object) (short) 0);
        int int16 = fixedMillisecond1.compareTo((java.lang.Object) int15);
        long long17 = fixedMillisecond1.getSerialIndex();
        java.lang.String str18 = fixedMillisecond1.toString();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent19 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) fixedMillisecond1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 100L + "'", long17 == 100L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str18.equals("Wed Dec 31 16:00:00 PST 1969"));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries(comparable0, "35", "org.jfree.data.time.TimePeriodFormatException: hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.removeChangeListener(seriesChangeListener6);
        java.lang.Comparable comparable8 = timeSeries1.getKey();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        java.util.Date date12 = year11.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        java.lang.String str14 = day13.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day13.next();
        int int16 = day13.getMonth();
        timeSeries10.add((org.jfree.data.time.RegularTimePeriod) day13, (double) 100);
        long long19 = day13.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) day13);
        int int21 = day13.getDayOfMonth();
        java.lang.String str22 = day13.toString();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        java.lang.String str24 = year23.toString();
        int int25 = day13.compareTo((java.lang.Object) str24);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 'a' + "'", comparable8.equals('a'));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "31-December-2019" + "'", str14.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 12 + "'", int16 == 12);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1577865599999L + "'", long19 == 1577865599999L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 31 + "'", int21 == 31);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "31-December-2019" + "'", str22.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "2019" + "'", str24.equals("2019"));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, (int) (byte) 0, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
        int int6 = day2.compareTo((java.lang.Object) 1L);
        long long7 = day2.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577779200000L + "'", long7 == 1577779200000L);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        long long4 = day2.getFirstMillisecond();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = day2.getMiddleMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577779200000L + "'", long4 == 1577779200000L);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setRangeDescription("hi!");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeries1.getNextTimePeriod();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        timeSeries10.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) (byte) 10, false);
        timeSeries10.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
        timeSeries18.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) (byte) 10, false);
        timeSeries18.setNotify(false);
        java.util.Collection collection25 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries18.getDataItem((org.jfree.data.time.RegularTimePeriod) year26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries1.addOrUpdate(timeSeriesDataItem27);
        boolean boolean29 = timeSeriesDataItem27.isSelected();
        java.lang.Number number30 = timeSeriesDataItem27.getValue();
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(collection25);
        org.junit.Assert.assertNotNull(timeSeriesDataItem27);
        org.junit.Assert.assertNotNull(timeSeriesDataItem28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + number30 + "' != '" + (byte) 10 + "'", number30.equals((byte) 10));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        java.lang.String str6 = month2.toString();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = month2.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        long long3 = day2.getSerialIndex();
        int int4 = day2.getYear();
        java.util.Calendar calendar5 = null;
        try {
            day2.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43830L + "'", long3 == 43830L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
        int int5 = day2.getMonth();
        java.lang.String str6 = day2.toString();
        long long7 = day2.getSerialIndex();
        int int8 = day2.getMonth();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "31-December-2019" + "'", str6.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43830L + "'", long7 == 43830L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
    }

//    @Test
//    public void test181() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test181");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.util.Date date1 = year0.getEnd();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        java.lang.String str3 = day2.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
//        int int6 = day2.compareTo((java.lang.Object) 1L);
//        long long7 = day2.getLastMillisecond();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int9 = day2.compareTo((java.lang.Object) day8);
//        int int10 = day2.getDayOfMonth();
//        java.lang.String str11 = day2.toString();
//        int int12 = day2.getMonth();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 204 + "'", int9 == 204);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 31 + "'", int10 == 31);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "31-December-2019" + "'", str11.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 12 + "'", int12 == 12);
//    }

//    @Test
//    public void test182() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test182");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "2019", "");
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
//        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
//        timeSeries6.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10, false);
//        timeSeries6.setNotify(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond13.getFirstMillisecond(calendar14);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries6.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13);
//        timeSeries4.add(timeSeriesDataItem16, true);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = timeSeriesDataItem16.getPeriod();
//        boolean boolean20 = day0.equals((java.lang.Object) timeSeriesDataItem16);
//        long long21 = day0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560185136721L + "'", long15 == 1560185136721L);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem16);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560150000000L + "'", long21 == 1560150000000L);
//    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        int int2 = month0.getYearValue();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = month0.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        try {
            timeSeries1.delete(35, (int) '4', true);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        java.lang.Object obj8 = null;
        boolean boolean9 = timeSeries1.equals(obj8);
        try {
            timeSeries1.delete(7, 35);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setRangeDescription("hi!");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeries1.getNextTimePeriod();
        timeSeries1.setNotify(true);
        java.lang.String str11 = timeSeries1.getDomainDescription();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year((int) '#');
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) year13);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = timeSeries1.getTimePeriod((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Time" + "'", str11.equals("Time"));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year0.getMiddleMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
        int int5 = day2.getMonth();
        java.lang.String str6 = day2.toString();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day2, "", "org.jfree.data.event.SeriesChangeEvent[source=1]");
        org.jfree.data.time.SerialDate serialDate10 = day2.getSerialDate();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate10);
        java.lang.String str12 = day11.toString();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "31-December-2019" + "'", str6.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "31-December-2019" + "'", str12.equals("31-December-2019"));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        java.lang.Object obj8 = timeSeries1.clone();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        timeSeries10.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) (byte) 10, false);
        timeSeries10.setNotify(false);
        java.util.Collection collection17 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries10);
        timeSeries1.setDomainDescription("");
        java.util.Collection collection20 = timeSeries1.getTimePeriods();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        java.util.Date date22 = year21.getEnd();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        java.lang.String str24 = day23.toString();
        long long25 = day23.getFirstMillisecond();
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day23, (java.lang.Number) 0L, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period 31-December-2019 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertNotNull(collection20);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "31-December-2019" + "'", str24.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1577779200000L + "'", long25 == 1577779200000L);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        java.lang.Object obj8 = timeSeries1.clone();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        long long12 = day11.getSerialIndex();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day11);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) month14);
        java.util.Calendar calendar16 = null;
        try {
            long long17 = month14.getLastMillisecond(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43830L + "'", long12 == 43830L);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
        int int5 = day2.getMonth();
        java.lang.String str6 = day2.toString();
        java.util.Date date7 = day2.getEnd();
        java.util.TimeZone timeZone8 = null;
        try {
            org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date7, timeZone8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "31-December-2019" + "'", str6.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("June 2019");
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) 0.0f);
        boolean boolean13 = timeSeries7.getNotify();
        java.lang.Object obj14 = timeSeries7.clone();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        timeSeries16.add((org.jfree.data.time.RegularTimePeriod) month17, (java.lang.Number) (byte) 10, false);
        timeSeries16.setNotify(false);
        java.util.Collection collection23 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries16);
        int int24 = month2.compareTo((java.lang.Object) timeSeries7);
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        java.util.Date date28 = year27.getEnd();
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date28);
        java.lang.String str30 = day29.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = day29.next();
        int int32 = day29.getMonth();
        timeSeries26.add((org.jfree.data.time.RegularTimePeriod) day29, (double) 100);
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        java.util.Date date36 = year35.getEnd();
        boolean boolean38 = year35.equals((java.lang.Object) (-1.0d));
        int int40 = year35.compareTo((java.lang.Object) 1.0d);
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
        java.util.Date date42 = year41.getEnd();
        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(date42);
        java.lang.String str44 = day43.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = day43.next();
        int int46 = day43.getMonth();
        java.lang.String str47 = day43.toString();
        org.jfree.data.time.TimeSeries timeSeries48 = timeSeries26.createCopy((org.jfree.data.time.RegularTimePeriod) year35, (org.jfree.data.time.RegularTimePeriod) day43);
        java.lang.String str49 = year35.toString();
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
        java.util.Date date51 = year50.getEnd();
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(date51);
        java.lang.String str53 = day52.toString();
        int int54 = day52.getYear();
        org.jfree.data.time.TimeSeries timeSeries55 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) year35, (org.jfree.data.time.RegularTimePeriod) day52);
        try {
            org.jfree.data.time.TimeSeries timeSeries58 = timeSeries7.createCopy((int) '#', 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(collection23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "31-December-2019" + "'", str30.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 12 + "'", int32 == 12);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "31-December-2019" + "'", str44.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 12 + "'", int46 == 12);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "31-December-2019" + "'", str47.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(timeSeries48);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "2019" + "'", str49.equals("2019"));
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "31-December-2019" + "'", str53.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 2019 + "'", int54 == 2019);
        org.junit.Assert.assertNotNull(timeSeries55);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        int int2 = month0.getYearValue();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Date date5 = fixedMillisecond4.getTime();
        long long6 = fixedMillisecond4.getFirstMillisecond();
        java.util.Date date7 = fixedMillisecond4.getTime();
        java.lang.Object obj8 = null;
        int int9 = fixedMillisecond4.compareTo(obj8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        java.lang.String str13 = day12.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day12.next();
        boolean boolean15 = fixedMillisecond4.equals((java.lang.Object) regularTimePeriod14);
        java.util.Calendar calendar16 = null;
        long long17 = fixedMillisecond4.getMiddleMillisecond(calendar16);
        int int18 = month0.compareTo((java.lang.Object) fixedMillisecond4);
        long long19 = fixedMillisecond4.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "31-December-2019" + "'", str13.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 100L + "'", long17 == 100L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 100L + "'", long19 == 100L);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setRangeDescription("hi!");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeries1.getNextTimePeriod();
        timeSeries1.setNotify(true);
        java.lang.String str11 = timeSeries1.getDomainDescription();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year((int) '#');
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) year13);
        java.lang.String str15 = year13.toString();
        java.util.Calendar calendar16 = null;
        try {
            year13.peg(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Time" + "'", str11.equals("Time"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "35" + "'", str15.equals("35"));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
        int int5 = day2.getMonth();
        java.lang.String str6 = day2.toString();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = day2.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "31-December-2019" + "'", str6.equals("31-December-2019"));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) 0.0f);
        boolean boolean13 = timeSeries7.getNotify();
        java.lang.Object obj14 = timeSeries7.clone();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        timeSeries16.add((org.jfree.data.time.RegularTimePeriod) month17, (java.lang.Number) (byte) 10, false);
        timeSeries16.setNotify(false);
        java.util.Collection collection23 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries16);
        int int24 = month2.compareTo((java.lang.Object) timeSeries7);
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        java.util.Date date28 = year27.getEnd();
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date28);
        java.lang.String str30 = day29.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = day29.next();
        int int32 = day29.getMonth();
        timeSeries26.add((org.jfree.data.time.RegularTimePeriod) day29, (double) 100);
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        java.util.Date date36 = year35.getEnd();
        boolean boolean38 = year35.equals((java.lang.Object) (-1.0d));
        int int40 = year35.compareTo((java.lang.Object) 1.0d);
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
        java.util.Date date42 = year41.getEnd();
        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(date42);
        java.lang.String str44 = day43.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = day43.next();
        int int46 = day43.getMonth();
        java.lang.String str47 = day43.toString();
        org.jfree.data.time.TimeSeries timeSeries48 = timeSeries26.createCopy((org.jfree.data.time.RegularTimePeriod) year35, (org.jfree.data.time.RegularTimePeriod) day43);
        java.lang.String str49 = year35.toString();
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
        java.util.Date date51 = year50.getEnd();
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(date51);
        java.lang.String str53 = day52.toString();
        int int54 = day52.getYear();
        org.jfree.data.time.TimeSeries timeSeries55 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) year35, (org.jfree.data.time.RegularTimePeriod) day52);
        org.jfree.data.time.TimeSeries timeSeries57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year();
        java.util.Date date59 = year58.getEnd();
        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day(date59);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem62 = timeSeries57.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day60, (java.lang.Number) 0.0f);
        boolean boolean63 = timeSeries57.getNotify();
        java.lang.Object obj64 = timeSeries57.clone();
        org.jfree.data.time.TimeSeries timeSeries66 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month67 = new org.jfree.data.time.Month();
        timeSeries66.add((org.jfree.data.time.RegularTimePeriod) month67, (java.lang.Number) (byte) 10, false);
        timeSeries66.setNotify(false);
        java.util.Collection collection73 = timeSeries57.getTimePeriodsUniqueToOtherSeries(timeSeries66);
        org.jfree.data.time.TimeSeries timeSeries75 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year76 = new org.jfree.data.time.Year();
        java.util.Date date77 = year76.getEnd();
        org.jfree.data.time.Day day78 = new org.jfree.data.time.Day(date77);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem80 = timeSeries75.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day78, (java.lang.Number) 0.0f);
        boolean boolean81 = timeSeries75.getNotify();
        java.lang.Object obj82 = timeSeries75.clone();
        org.jfree.data.time.Year year83 = new org.jfree.data.time.Year();
        java.util.Date date84 = year83.getEnd();
        org.jfree.data.time.Day day85 = new org.jfree.data.time.Day(date84);
        long long86 = day85.getSerialIndex();
        timeSeries75.delete((org.jfree.data.time.RegularTimePeriod) day85);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem88 = timeSeries57.getDataItem((org.jfree.data.time.RegularTimePeriod) day85);
        try {
            timeSeries7.add(timeSeriesDataItem88, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period 31-December-2019 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(collection23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "31-December-2019" + "'", str30.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 12 + "'", int32 == 12);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "31-December-2019" + "'", str44.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 12 + "'", int46 == 12);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "31-December-2019" + "'", str47.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(timeSeries48);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "2019" + "'", str49.equals("2019"));
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "31-December-2019" + "'", str53.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 2019 + "'", int54 == 2019);
        org.junit.Assert.assertNotNull(timeSeries55);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertNull(timeSeriesDataItem62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNotNull(obj64);
        org.junit.Assert.assertNotNull(collection73);
        org.junit.Assert.assertNotNull(date77);
        org.junit.Assert.assertNull(timeSeriesDataItem80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + true + "'", boolean81 == true);
        org.junit.Assert.assertNotNull(obj82);
        org.junit.Assert.assertNotNull(date84);
        org.junit.Assert.assertTrue("'" + long86 + "' != '" + 43830L + "'", long86 == 43830L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem88);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
        java.util.TimeZone timeZone4 = null;
        try {
            org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date1, timeZone4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(35, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.Year year9 = org.jfree.data.time.Year.parseYear("2019");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) year9);
        timeSeries1.setNotify(true);
        java.lang.String str13 = timeSeries1.getDomainDescription();
        try {
            timeSeries1.delete(7, 10, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Time" + "'", str13.equals("Time"));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        java.util.List list8 = timeSeries1.getItems();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        long long10 = month9.getLastMillisecond();
        org.jfree.data.time.Year year11 = month9.getYear();
        java.lang.Number number12 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) year11);
        timeSeries1.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: hi!");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Date date18 = fixedMillisecond17.getTime();
        long long19 = fixedMillisecond17.getFirstMillisecond();
        java.util.Date date20 = fixedMillisecond17.getTime();
        java.lang.Object obj21 = null;
        int int22 = fixedMillisecond17.compareTo(obj21);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        java.util.Date date24 = year23.getEnd();
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date24);
        java.lang.String str26 = day25.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = day25.next();
        boolean boolean28 = fixedMillisecond17.equals((java.lang.Object) regularTimePeriod27);
        long long29 = fixedMillisecond17.getSerialIndex();
        java.util.Date date30 = fixedMillisecond17.getTime();
        try {
            org.jfree.data.time.TimeSeries timeSeries31 = timeSeries1.createCopy(regularTimePeriod15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'start' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1561964399999L + "'", long10 == 1561964399999L);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 0.0f + "'", number12.equals(0.0f));
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 100L + "'", long19 == 100L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "31-December-2019" + "'", str26.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 100L + "'", long29 == 100L);
        org.junit.Assert.assertNotNull(date30);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        long long2 = month0.getFirstMillisecond();
        java.lang.String str3 = month0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month0.next();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1559372400000L + "'", long2 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (short) 1, year1);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException5.getSuppressed();
        boolean boolean10 = month3.equals((java.lang.Object) throwableArray9);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo12 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent13 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (short) 1, seriesChangeInfo12);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo14 = seriesChangeEvent13.getSummary();
        java.lang.String str15 = seriesChangeEvent13.toString();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo16 = null;
        seriesChangeEvent13.setSummary(seriesChangeInfo16);
        java.lang.Object obj18 = seriesChangeEvent13.getSource();
        java.lang.Object obj19 = seriesChangeEvent13.getSource();
        int int20 = month3.compareTo((java.lang.Object) seriesChangeEvent13);
        long long21 = month3.getSerialIndex();
        java.util.Calendar calendar22 = null;
        try {
            long long23 = month3.getLastMillisecond(calendar22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(seriesChangeInfo14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=1]" + "'", str15.equals("org.jfree.data.event.SeriesChangeEvent[source=1]"));
        org.junit.Assert.assertTrue("'" + obj18 + "' != '" + (short) 1 + "'", obj18.equals((short) 1));
        org.junit.Assert.assertTrue("'" + obj19 + "' != '" + (short) 1 + "'", obj19.equals((short) 1));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 24229L + "'", long21 == 24229L);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, (int) (byte) 10, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test205() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test205");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.util.Date date1 = year0.getEnd();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        java.lang.String str3 = day2.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
//        int int6 = day2.compareTo((java.lang.Object) 1L);
//        long long7 = day2.getLastMillisecond();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int9 = day2.compareTo((java.lang.Object) day8);
//        int int10 = day2.getDayOfMonth();
//        java.util.Calendar calendar11 = null;
//        try {
//            long long12 = day2.getLastMillisecond(calendar11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 204 + "'", int9 == 204);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 31 + "'", int10 == 31);
//    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) (byte) 10, false);
        timeSeries9.setNotify(false);
        java.util.Collection collection16 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries9);
        timeSeries9.setNotify(false);
        int int19 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        java.util.Date date22 = year21.getEnd();
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month((int) (short) 1, year21);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        java.util.Date date27 = year26.getEnd();
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date27);
        java.lang.String str29 = day28.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = day28.next();
        int int31 = day28.getMonth();
        timeSeries25.add((org.jfree.data.time.RegularTimePeriod) day28, (double) 100);
        boolean boolean34 = year21.equals((java.lang.Object) day28);
        try {
            timeSeries9.add((org.jfree.data.time.RegularTimePeriod) day28, 0.0d, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Day, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2147483647 + "'", int19 == 2147483647);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "31-December-2019" + "'", str29.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 12 + "'", int31 == 12);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        java.util.Date date8 = year7.getEnd();
        boolean boolean10 = year7.equals((java.lang.Object) (-1.0d));
        int int12 = year7.compareTo((java.lang.Object) 1.0d);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) year7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeriesDataItem13.getPeriod();
        int int16 = timeSeriesDataItem13.compareTo((java.lang.Object) 2019);
        timeSeriesDataItem13.setSelected(true);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.removeChangeListener(seriesChangeListener6);
        java.lang.Comparable comparable8 = timeSeries1.getKey();
        java.util.Collection collection9 = timeSeries1.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        timeSeries11.add((org.jfree.data.time.RegularTimePeriod) month12, (java.lang.Number) (byte) 10, false);
        timeSeries11.setRangeDescription("hi!");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = timeSeries11.getNextTimePeriod();
        timeSeries11.setNotify(true);
        java.lang.String str21 = timeSeries11.getDomainDescription();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year((int) '#');
        timeSeries11.delete((org.jfree.data.time.RegularTimePeriod) year23);
        java.lang.Comparable comparable25 = timeSeries11.getKey();
        java.util.Collection collection26 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond27, "", "hi!");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = fixedMillisecond27.previous();
        timeSeries11.delete(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 'a' + "'", comparable8.equals('a'));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Time" + "'", str21.equals("Time"));
        org.junit.Assert.assertTrue("'" + comparable25 + "' != '" + 'a' + "'", comparable25.equals('a'));
        org.junit.Assert.assertNotNull(collection26);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.removeChangeListener(seriesChangeListener6);
        java.lang.Comparable comparable8 = timeSeries1.getKey();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        java.util.Date date12 = year11.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        java.lang.String str14 = day13.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day13.next();
        int int16 = day13.getMonth();
        timeSeries10.add((org.jfree.data.time.RegularTimePeriod) day13, (double) 100);
        long long19 = day13.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) day13);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        timeSeries22.add((org.jfree.data.time.RegularTimePeriod) month23, (java.lang.Number) (byte) 10, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener27 = null;
        timeSeries22.removeChangeListener(seriesChangeListener27);
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month();
        timeSeries30.add((org.jfree.data.time.RegularTimePeriod) month31, (java.lang.Number) (byte) 10, false);
        timeSeries30.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month();
        timeSeries38.add((org.jfree.data.time.RegularTimePeriod) month39, (java.lang.Number) (byte) 10, false);
        timeSeries38.setNotify(false);
        java.util.Collection collection45 = timeSeries30.getTimePeriodsUniqueToOtherSeries(timeSeries38);
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = timeSeries38.getDataItem((org.jfree.data.time.RegularTimePeriod) year46);
        java.lang.Object obj48 = timeSeriesDataItem47.clone();
        java.lang.Number number49 = timeSeriesDataItem47.getValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = timeSeries22.addOrUpdate(timeSeriesDataItem47);
        boolean boolean51 = timeSeriesDataItem50.isSelected();
        try {
            timeSeries1.add(timeSeriesDataItem50);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period June 2019 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 'a' + "'", comparable8.equals('a'));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "31-December-2019" + "'", str14.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 12 + "'", int16 == 12);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1577865599999L + "'", long19 == 1577865599999L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem20);
        org.junit.Assert.assertNotNull(collection45);
        org.junit.Assert.assertNotNull(timeSeriesDataItem47);
        org.junit.Assert.assertNotNull(obj48);
        org.junit.Assert.assertTrue("'" + number49 + "' != '" + (byte) 10 + "'", number49.equals((byte) 10));
        org.junit.Assert.assertNotNull(timeSeriesDataItem50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.removeChangeListener(seriesChangeListener6);
        timeSeries1.removeAgedItems(1560185129286L, false);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener11);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(3);
        try {
            org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(31, year2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        boolean boolean3 = year1.equals((java.lang.Object) 2);
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year1.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) false);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getMiddleMillisecond(calendar4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 100L + "'", long5 == 100L);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        java.util.Date date8 = year7.getEnd();
        boolean boolean10 = year7.equals((java.lang.Object) (-1.0d));
        int int12 = year7.compareTo((java.lang.Object) 1.0d);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) year7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeriesDataItem13.getPeriod();
        java.lang.Number number15 = timeSeriesDataItem13.getValue();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 0.0f + "'", number15.equals(0.0f));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (short) 1, year1);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException5.getSuppressed();
        boolean boolean10 = month3.equals((java.lang.Object) throwableArray9);
        int int11 = month3.getMonth();
        java.util.Calendar calendar12 = null;
        try {
            month3.peg(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Date date2 = fixedMillisecond1.getTime();
        long long3 = fixedMillisecond1.getFirstMillisecond();
        java.util.Date date4 = fixedMillisecond1.getTime();
        java.lang.Object obj5 = null;
        int int6 = fixedMillisecond1.compareTo(obj5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        java.util.Date date8 = year7.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.lang.String str10 = day9.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day9.next();
        boolean boolean12 = fixedMillisecond1.equals((java.lang.Object) regularTimePeriod11);
        long long13 = fixedMillisecond1.getSerialIndex();
        java.util.Date date14 = fixedMillisecond1.getTime();
        java.util.TimeZone timeZone15 = null;
        java.util.Locale locale16 = null;
        try {
            org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date14, timeZone15, locale16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 100L + "'", long13 == 100L);
        org.junit.Assert.assertNotNull(date14);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
        java.util.Date date5 = regularTimePeriod4.getStart();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date5);
        java.lang.String str7 = timeSeries6.getDescription();
        java.lang.String str8 = timeSeries6.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        java.util.Date date12 = year11.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (java.lang.Number) 0.0f);
        boolean boolean16 = timeSeries10.getNotify();
        java.lang.Object obj17 = timeSeries10.clone();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        java.util.Date date19 = year18.getEnd();
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date19);
        long long21 = day20.getSerialIndex();
        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) day20);
        java.lang.Object obj23 = timeSeries10.clone();
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries6.addAndOrUpdate(timeSeries10);
        try {
            java.lang.Number number26 = timeSeries6.getValue(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Value" + "'", str8.equals("Value"));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 43830L + "'", long21 == 43830L);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertNotNull(timeSeries24);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        java.lang.Object obj8 = timeSeries1.clone();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        long long12 = day11.getSerialIndex();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day11);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries1.createCopy(0, 6);
        timeSeries1.setMaximumItemAge(100L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43830L + "'", long12 == 43830L);
        org.junit.Assert.assertNotNull(timeSeries16);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        java.lang.Object obj8 = timeSeries1.clone();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        timeSeries10.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) (byte) 10, false);
        timeSeries10.setNotify(false);
        java.util.Collection collection17 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries10);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.util.Date date21 = year20.getEnd();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date21);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries19.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day22, (java.lang.Number) 0.0f);
        boolean boolean25 = timeSeries19.getNotify();
        java.lang.Object obj26 = timeSeries19.clone();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        java.util.Date date28 = year27.getEnd();
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date28);
        long long30 = day29.getSerialIndex();
        timeSeries19.delete((org.jfree.data.time.RegularTimePeriod) day29);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) day29);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day29, (double) 1560185128766L);
        boolean boolean35 = timeSeriesDataItem34.isSelected();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 43830L + "'", long30 == 43830L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        java.lang.String str3 = year1.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year1.next();
        java.lang.String str5 = year1.toString();
        java.lang.Class<?> wildcardClass6 = year1.getClass();
        java.lang.String str7 = year1.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "35" + "'", str3.equals("35"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "35" + "'", str5.equals("35"));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "35" + "'", str7.equals("35"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) (byte) 10, false);
        timeSeries9.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        timeSeries17.add((org.jfree.data.time.RegularTimePeriod) month18, (java.lang.Number) (byte) 10, false);
        timeSeries17.setNotify(false);
        java.util.Collection collection24 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries17);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries17.getDataItem((org.jfree.data.time.RegularTimePeriod) year25);
        java.lang.Object obj27 = timeSeriesDataItem26.clone();
        java.lang.Number number28 = timeSeriesDataItem26.getValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries1.addOrUpdate(timeSeriesDataItem26);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries1.getDataItem(9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9999, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection24);
        org.junit.Assert.assertNotNull(timeSeriesDataItem26);
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertTrue("'" + number28 + "' != '" + (byte) 10 + "'", number28.equals((byte) 10));
        org.junit.Assert.assertNotNull(timeSeriesDataItem29);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        java.lang.String str5 = day4.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day4.next();
        int int7 = day4.getMonth();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (double) 100);
        java.lang.Object obj10 = timeSeries1.clone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = timeSeries1.getNextTimePeriod();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        timeSeries13.add((org.jfree.data.time.RegularTimePeriod) month14, (java.lang.Number) (byte) 10, false);
        java.lang.String str18 = month14.toString();
        int int19 = month14.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month14.next();
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month14, (java.lang.Number) 11, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "31-December-2019" + "'", str5.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass1 = year0.getClass();
        java.lang.Class class2 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) wildcardClass1);
        java.lang.String str4 = seriesChangeEvent3.toString();
        java.lang.Object obj5 = seriesChangeEvent3.getSource();
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=class org.jfree.data.time.Year]" + "'", str4.equals("org.jfree.data.event.SeriesChangeEvent[source=class org.jfree.data.time.Year]"));
        org.junit.Assert.assertNotNull(obj5);
    }

//    @Test
//    public void test225() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test225");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
//        timeSeries1.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
//        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) (byte) 10, false);
//        timeSeries5.setNotify(false);
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
//        timeSeries13.add((org.jfree.data.time.RegularTimePeriod) month14, (java.lang.Number) (byte) 10, false);
//        timeSeries13.setNotify(false);
//        java.util.Collection collection20 = timeSeries5.getTimePeriodsUniqueToOtherSeries(timeSeries13);
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) year21);
//        timeSeries1.add(timeSeriesDataItem22, false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar26 = null;
//        long long27 = fixedMillisecond25.getFirstMillisecond(calendar26);
//        java.lang.Number number28 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25);
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
//        java.util.Date date30 = year29.getEnd();
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date30);
//        long long32 = day31.getSerialIndex();
//        int int33 = day31.getYear();
//        try {
//            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day31, (double) 1560185132837L, false);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Day, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(collection20);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem22);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560185142056L + "'", long27 == 1560185142056L);
//        org.junit.Assert.assertTrue("'" + number28 + "' != '" + (byte) 10 + "'", number28.equals((byte) 10));
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 43830L + "'", long32 == 43830L);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2019 + "'", int33 == 2019);
//    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setRangeDescription("hi!");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeries1.getNextTimePeriod();
        timeSeries1.setNotify(true);
        java.lang.String str11 = timeSeries1.getDomainDescription();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = null;
        try {
            timeSeries1.delete(regularTimePeriod12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Time" + "'", str11.equals("Time"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1, "", "hi!");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = null;
        try {
            timeSeries3.update(regularTimePeriod4, (java.lang.Number) 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        java.lang.String str5 = day4.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day4.next();
        int int7 = day4.getMonth();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (double) 100);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries1.addChangeListener(seriesChangeListener10);
        timeSeries1.removeAgedItems(false);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year15.next();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        java.util.Date date18 = year17.getEnd();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
        long long20 = day19.getLastMillisecond();
        int int21 = year15.compareTo((java.lang.Object) day19);
        long long22 = day19.getSerialIndex();
        java.lang.String str23 = day19.toString();
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day19, (double) 10.0f);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period 31-December-2019 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "31-December-2019" + "'", str5.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1577865599999L + "'", long20 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 43830L + "'", long22 == 43830L);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "31-December-2019" + "'", str23.equals("31-December-2019"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) (byte) 10, false);
        timeSeries9.setNotify(false);
        java.util.Collection collection16 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries9);
        boolean boolean17 = timeSeries1.getNotify();
        timeSeries1.removeAgedItems((long) 'a', true);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = timeSeries1.getNextTimePeriod();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        java.util.Date date25 = year24.getEnd();
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date25);
        java.lang.String str27 = day26.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day26.next();
        int int29 = day26.getMonth();
        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) day26, (double) 100);
        java.lang.Object obj32 = timeSeries23.clone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = timeSeries23.getNextTimePeriod();
        try {
            timeSeries1.add(regularTimePeriod33, (java.lang.Number) 100.0f, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Day, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "31-December-2019" + "'", str27.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 12 + "'", int29 == 12);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        timeSeries1.setDescription("");
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = timeSeries1.getTimePeriod((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        int int8 = timeSeries1.getItemCount();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Date date13 = fixedMillisecond12.getTime();
        long long14 = fixedMillisecond12.getFirstMillisecond();
        java.util.Date date15 = fixedMillisecond12.getTime();
        java.lang.Object obj16 = null;
        int int17 = fixedMillisecond12.compareTo(obj16);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.util.Date date21 = year20.getEnd();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date21);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries19.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day22, (java.lang.Number) 0.0f);
        int int26 = day22.compareTo((java.lang.Object) (short) 0);
        int int27 = fixedMillisecond12.compareTo((java.lang.Object) int26);
        long long28 = fixedMillisecond12.getSerialIndex();
        java.lang.String str29 = fixedMillisecond12.toString();
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month();
        timeSeries31.add((org.jfree.data.time.RegularTimePeriod) month32, (java.lang.Number) (byte) 10, false);
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        java.util.Date date39 = year38.getEnd();
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date39);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day40, (java.lang.Number) 0.0f);
        boolean boolean43 = timeSeries37.getNotify();
        java.lang.Object obj44 = timeSeries37.clone();
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month();
        timeSeries46.add((org.jfree.data.time.RegularTimePeriod) month47, (java.lang.Number) (byte) 10, false);
        timeSeries46.setNotify(false);
        java.util.Collection collection53 = timeSeries37.getTimePeriodsUniqueToOtherSeries(timeSeries46);
        int int54 = month32.compareTo((java.lang.Object) timeSeries37);
        int int55 = month32.getMonth();
        org.jfree.data.time.TimeSeries timeSeries56 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (org.jfree.data.time.RegularTimePeriod) month32);
        java.util.Calendar calendar57 = null;
        fixedMillisecond12.peg(calendar57);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 100L + "'", long14 == 100L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 100L + "'", long28 == 100L);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str29.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNull(timeSeriesDataItem42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(obj44);
        org.junit.Assert.assertNotNull(collection53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 6 + "'", int55 == 6);
        org.junit.Assert.assertNotNull(timeSeries56);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560185132837L);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        java.lang.Object obj8 = timeSeries1.clone();
        timeSeries1.setNotify(false);
        boolean boolean11 = timeSeries1.isEmpty();
        try {
            timeSeries1.delete(9999, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.util.Date date4 = year3.getEnd();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        long long6 = day5.getLastMillisecond();
        int int7 = year1.compareTo((java.lang.Object) day5);
        java.lang.String str8 = year1.toString();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        long long12 = day11.getSerialIndex();
        int int13 = day11.getYear();
        boolean boolean14 = year1.equals((java.lang.Object) day11);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "35" + "'", str8.equals("35"));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43830L + "'", long12 == 43830L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setRangeDescription("hi!");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeries1.getNextTimePeriod();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = timeSeries1.getTimePeriod(9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        java.lang.Object obj8 = timeSeries1.clone();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        timeSeries10.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) (byte) 10, false);
        timeSeries10.setNotify(false);
        java.util.Collection collection17 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries10);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.util.Date date21 = year20.getEnd();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date21);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries19.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day22, (java.lang.Number) 0.0f);
        boolean boolean25 = timeSeries19.getNotify();
        java.lang.Object obj26 = timeSeries19.clone();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        java.util.Date date28 = year27.getEnd();
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date28);
        long long30 = day29.getSerialIndex();
        timeSeries19.delete((org.jfree.data.time.RegularTimePeriod) day29);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) day29);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Date date35 = fixedMillisecond34.getTime();
        long long36 = fixedMillisecond34.getFirstMillisecond();
        java.util.Date date37 = fixedMillisecond34.getTime();
        java.lang.Object obj38 = null;
        int int39 = fixedMillisecond34.compareTo(obj38);
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        java.util.Date date41 = year40.getEnd();
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(date41);
        java.lang.String str43 = day42.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = day42.next();
        boolean boolean45 = fixedMillisecond34.equals((java.lang.Object) regularTimePeriod44);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34, (double) 35);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 43830L + "'", long30 == 43830L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem32);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 100L + "'", long36 == 100L);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "31-December-2019" + "'", str43.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

//    @Test
//    public void test237() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test237");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.util.Date date1 = year0.getEnd();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        java.lang.String str3 = day2.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
//        int int6 = day2.compareTo((java.lang.Object) 1L);
//        long long7 = day2.getLastMillisecond();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int9 = day2.compareTo((java.lang.Object) day8);
//        int int10 = day2.getDayOfMonth();
//        java.lang.String str11 = day2.toString();
//        java.lang.String str12 = day2.toString();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 204 + "'", int9 == 204);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 31 + "'", int10 == 31);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "31-December-2019" + "'", str11.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "31-December-2019" + "'", str12.equals("31-December-2019"));
//    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.removeChangeListener(seriesChangeListener6);
        timeSeries1.setDomainDescription("31-December-2019");
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        timeSeries11.add((org.jfree.data.time.RegularTimePeriod) month12, (java.lang.Number) (byte) 10, false);
        timeSeries11.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        timeSeries19.add((org.jfree.data.time.RegularTimePeriod) month20, (java.lang.Number) (byte) 10, false);
        timeSeries19.setNotify(false);
        java.util.Collection collection26 = timeSeries11.getTimePeriodsUniqueToOtherSeries(timeSeries19);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries19.getDataItem((org.jfree.data.time.RegularTimePeriod) year27);
        timeSeriesDataItem28.setValue((java.lang.Number) (byte) 1);
        boolean boolean32 = timeSeriesDataItem28.equals((java.lang.Object) (-1.0f));
        boolean boolean33 = timeSeries1.equals((java.lang.Object) (-1.0f));
        java.lang.Comparable comparable34 = timeSeries1.getKey();
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
        timeSeries36.add((org.jfree.data.time.RegularTimePeriod) month37, (java.lang.Number) (byte) 10, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener41 = null;
        timeSeries36.removeChangeListener(seriesChangeListener41);
        java.lang.Comparable comparable43 = timeSeries36.getKey();
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year();
        java.util.Date date47 = year46.getEnd();
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date47);
        java.lang.String str49 = day48.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = day48.next();
        int int51 = day48.getMonth();
        timeSeries45.add((org.jfree.data.time.RegularTimePeriod) day48, (double) 100);
        long long54 = day48.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem55 = timeSeries36.getDataItem((org.jfree.data.time.RegularTimePeriod) day48);
        try {
            timeSeries1.add(timeSeriesDataItem55, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period June 2019 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(collection26);
        org.junit.Assert.assertNotNull(timeSeriesDataItem28);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + comparable34 + "' != '" + 'a' + "'", comparable34.equals('a'));
        org.junit.Assert.assertTrue("'" + comparable43 + "' != '" + 'a' + "'", comparable43.equals('a'));
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "31-December-2019" + "'", str49.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 12 + "'", int51 == 12);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1577865599999L + "'", long54 == 1577865599999L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem55);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) 10);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        java.lang.String str5 = day4.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day4.next();
        int int7 = day4.getMonth();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (double) 100);
        timeSeries1.setDomainDescription("org.jfree.data.event.SeriesChangeEvent[source=1]");
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "31-December-2019" + "'", str5.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setRangeDescription("hi!");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener8);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        timeSeries11.add((org.jfree.data.time.RegularTimePeriod) month12, (java.lang.Number) (byte) 10, false);
        timeSeries11.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        timeSeries19.add((org.jfree.data.time.RegularTimePeriod) month20, (java.lang.Number) (byte) 10, false);
        timeSeries19.setNotify(false);
        java.util.Collection collection26 = timeSeries11.getTimePeriodsUniqueToOtherSeries(timeSeries19);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries19.getDataItem((org.jfree.data.time.RegularTimePeriod) year27);
        java.lang.Object obj29 = timeSeriesDataItem28.clone();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = year31.next();
        int int33 = timeSeriesDataItem28.compareTo((java.lang.Object) year31);
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        java.util.Date date37 = year36.getEnd();
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date37);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries35.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day38, (java.lang.Number) 0.0f);
        int int41 = timeSeriesDataItem28.compareTo((java.lang.Object) 0.0f);
        try {
            timeSeries1.add(timeSeriesDataItem28, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period June 2019 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(collection26);
        org.junit.Assert.assertNotNull(timeSeriesDataItem28);
        org.junit.Assert.assertNotNull(obj29);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNull(timeSeriesDataItem40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        java.lang.String str3 = year1.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year1.next();
        java.lang.String str5 = year1.toString();
        java.lang.Class<?> wildcardClass6 = year1.getClass();
        int int8 = year1.compareTo((java.lang.Object) 1560185136721L);
        int int9 = year1.getYear();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "35" + "'", str3.equals("35"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "35" + "'", str5.equals("35"));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 35 + "'", int9 == 35);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Date date12 = fixedMillisecond11.getTime();
        long long13 = fixedMillisecond11.getFirstMillisecond();
        java.util.Date date14 = fixedMillisecond11.getTime();
        long long15 = fixedMillisecond11.getFirstMillisecond();
        java.util.Calendar calendar16 = null;
        long long17 = fixedMillisecond11.getFirstMillisecond(calendar16);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (java.lang.Number) 1560185129286L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 100L + "'", long13 == 100L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 100L + "'", long15 == 100L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 100L + "'", long17 == 100L);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        java.lang.Object obj8 = timeSeries1.clone();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        timeSeries10.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) (byte) 10, false);
        timeSeries10.setNotify(false);
        java.util.Collection collection17 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries10);
        timeSeries1.setDomainDescription("");
        java.util.Collection collection20 = timeSeries1.getTimePeriods();
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener21);
        java.lang.Comparable comparable23 = timeSeries1.getKey();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = timeSeries1.getTimePeriod((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertNotNull(collection20);
        org.junit.Assert.assertTrue("'" + comparable23 + "' != '" + 'a' + "'", comparable23.equals('a'));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) (byte) 10, false);
        timeSeries9.setNotify(false);
        java.util.Collection collection16 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries9);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) year17);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries9.addChangeListener(seriesChangeListener19);
        timeSeries9.setDomainDescription("");
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        java.util.Date date26 = year25.getEnd();
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries24.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day27, (java.lang.Number) 0.0f);
        boolean boolean30 = timeSeries24.getNotify();
        int int31 = timeSeries24.getItemCount();
        java.beans.PropertyChangeListener propertyChangeListener32 = null;
        timeSeries24.removePropertyChangeListener(propertyChangeListener32);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Date date36 = fixedMillisecond35.getTime();
        long long37 = fixedMillisecond35.getFirstMillisecond();
        java.util.Date date38 = fixedMillisecond35.getTime();
        java.lang.Object obj39 = null;
        int int40 = fixedMillisecond35.compareTo(obj39);
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year();
        java.util.Date date44 = year43.getEnd();
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date44);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = timeSeries42.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day45, (java.lang.Number) 0.0f);
        int int49 = day45.compareTo((java.lang.Object) (short) 0);
        int int50 = fixedMillisecond35.compareTo((java.lang.Object) int49);
        long long51 = fixedMillisecond35.getSerialIndex();
        java.lang.String str52 = fixedMillisecond35.toString();
        org.jfree.data.time.TimeSeries timeSeries54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month();
        timeSeries54.add((org.jfree.data.time.RegularTimePeriod) month55, (java.lang.Number) (byte) 10, false);
        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year();
        java.util.Date date62 = year61.getEnd();
        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day(date62);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem65 = timeSeries60.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day63, (java.lang.Number) 0.0f);
        boolean boolean66 = timeSeries60.getNotify();
        java.lang.Object obj67 = timeSeries60.clone();
        org.jfree.data.time.TimeSeries timeSeries69 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month70 = new org.jfree.data.time.Month();
        timeSeries69.add((org.jfree.data.time.RegularTimePeriod) month70, (java.lang.Number) (byte) 10, false);
        timeSeries69.setNotify(false);
        java.util.Collection collection76 = timeSeries60.getTimePeriodsUniqueToOtherSeries(timeSeries69);
        int int77 = month55.compareTo((java.lang.Object) timeSeries60);
        int int78 = month55.getMonth();
        org.jfree.data.time.TimeSeries timeSeries79 = timeSeries24.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35, (org.jfree.data.time.RegularTimePeriod) month55);
        try {
            timeSeries9.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35, (java.lang.Number) 2147483647, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertNotNull(timeSeriesDataItem18);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 100L + "'", long37 == 100L);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNull(timeSeriesDataItem47);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 100L + "'", long51 == 100L);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str52.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertNotNull(date62);
        org.junit.Assert.assertNull(timeSeriesDataItem65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertNotNull(obj67);
        org.junit.Assert.assertNotNull(collection76);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 1 + "'", int77 == 1);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 6 + "'", int78 == 6);
        org.junit.Assert.assertNotNull(timeSeries79);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
        int int5 = day2.getMonth();
        java.lang.String str6 = day2.toString();
        java.util.Date date7 = day2.getEnd();
        java.util.TimeZone timeZone8 = null;
        java.util.Locale locale9 = null;
        try {
            org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date7, timeZone8, locale9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "31-December-2019" + "'", str6.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.removeChangeListener(seriesChangeListener6);
        java.lang.Comparable comparable8 = timeSeries1.getKey();
        timeSeries1.setMaximumItemCount((int) (short) 100);
        timeSeries1.setRangeDescription("31-December-2019");
        timeSeries1.setMaximumItemAge(1560185128766L);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 'a' + "'", comparable8.equals('a'));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        org.jfree.data.time.SerialDate serialDate7 = day4.getSerialDate();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = day4.getFirstMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertNotNull(serialDate7);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Date date2 = fixedMillisecond1.getTime();
        long long3 = fixedMillisecond1.getFirstMillisecond();
        java.util.Date date4 = fixedMillisecond1.getTime();
        java.util.TimeZone timeZone5 = null;
        try {
            org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date4, timeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        timeSeries1.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) (byte) 10, false);
        timeSeries5.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        timeSeries13.add((org.jfree.data.time.RegularTimePeriod) month14, (java.lang.Number) (byte) 10, false);
        timeSeries13.setNotify(false);
        java.util.Collection collection20 = timeSeries5.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) year21);
        timeSeries1.add(timeSeriesDataItem22, false);
        double double25 = timeSeries1.getMinY();
        boolean boolean26 = timeSeries1.isEmpty();
        timeSeries1.setKey((java.lang.Comparable) (-61047057600001L));
        org.junit.Assert.assertNotNull(collection20);
        org.junit.Assert.assertNotNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 10.0d + "'", double25 == 10.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setRangeDescription("hi!");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeries1.getNextTimePeriod();
        timeSeries1.setNotify(true);
        java.lang.String str11 = timeSeries1.getDomainDescription();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener12);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Time" + "'", str11.equals("Time"));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (short) 1, year2);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        java.lang.Throwable[] throwableArray10 = timePeriodFormatException6.getSuppressed();
        boolean boolean11 = month4.equals((java.lang.Object) throwableArray10);
        int int12 = month4.getMonth();
        org.jfree.data.time.Year year13 = month4.getYear();
        try {
            org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (byte) 0, year13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(year13);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        boolean boolean2 = month0.equals((java.lang.Object) (byte) -1);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = month0.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
        int int5 = day2.getMonth();
        java.lang.String str6 = day2.toString();
        long long7 = day2.getSerialIndex();
        boolean boolean9 = day2.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: hi!");
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "31-December-2019" + "'", str6.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43830L + "'", long7 == 43830L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.Year year9 = org.jfree.data.time.Year.parseYear("2019");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) year9);
        timeSeries1.setNotify(true);
        java.lang.String str13 = timeSeries1.getDomainDescription();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries1.addOrUpdate(regularTimePeriod14, (java.lang.Number) 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Time" + "'", str13.equals("Time"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
        java.util.Date date5 = regularTimePeriod4.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond6.previous();
        long long8 = fixedMillisecond6.getSerialIndex();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865600000L + "'", long8 == 1577865600000L);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Time");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.Year year9 = org.jfree.data.time.Year.parseYear("2019");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) year9);
        timeSeries1.setNotify(true);
        java.lang.String str13 = timeSeries1.getDomainDescription();
        java.lang.Class class14 = timeSeries1.getTimePeriodClass();
        timeSeries1.clear();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener16 = null;
        timeSeries1.addChangeListener(seriesChangeListener16);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Time" + "'", str13.equals("Time"));
        org.junit.Assert.assertNotNull(class14);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        java.util.Date date8 = year7.getEnd();
        boolean boolean10 = year7.equals((java.lang.Object) (-1.0d));
        int int12 = year7.compareTo((java.lang.Object) 1.0d);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) year7);
        double double14 = timeSeries1.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        timeSeries16.add((org.jfree.data.time.RegularTimePeriod) month17, (java.lang.Number) (byte) 10, false);
        java.lang.String str21 = month17.toString();
        int int22 = month17.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month17.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month17.next();
        try {
            timeSeries1.add(regularTimePeriod24, (java.lang.Number) 3);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "June 2019" + "'", str21.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        long long4 = day2.getFirstMillisecond();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = day2.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577779200000L + "'", long4 == 1577779200000L);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.util.Date date4 = year3.getEnd();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        long long6 = day5.getLastMillisecond();
        int int7 = year1.compareTo((java.lang.Object) day5);
        int int8 = year1.getYear();
        java.lang.String str9 = year1.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 35 + "'", int8 == 35);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "35" + "'", str9.equals("35"));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        int int8 = timeSeries1.getItemCount();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Date date13 = fixedMillisecond12.getTime();
        long long14 = fixedMillisecond12.getFirstMillisecond();
        java.util.Date date15 = fixedMillisecond12.getTime();
        java.lang.Object obj16 = null;
        int int17 = fixedMillisecond12.compareTo(obj16);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.util.Date date21 = year20.getEnd();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date21);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries19.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day22, (java.lang.Number) 0.0f);
        int int26 = day22.compareTo((java.lang.Object) (short) 0);
        int int27 = fixedMillisecond12.compareTo((java.lang.Object) int26);
        long long28 = fixedMillisecond12.getSerialIndex();
        java.lang.String str29 = fixedMillisecond12.toString();
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month();
        timeSeries31.add((org.jfree.data.time.RegularTimePeriod) month32, (java.lang.Number) (byte) 10, false);
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        java.util.Date date39 = year38.getEnd();
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date39);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day40, (java.lang.Number) 0.0f);
        boolean boolean43 = timeSeries37.getNotify();
        java.lang.Object obj44 = timeSeries37.clone();
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month();
        timeSeries46.add((org.jfree.data.time.RegularTimePeriod) month47, (java.lang.Number) (byte) 10, false);
        timeSeries46.setNotify(false);
        java.util.Collection collection53 = timeSeries37.getTimePeriodsUniqueToOtherSeries(timeSeries46);
        int int54 = month32.compareTo((java.lang.Object) timeSeries37);
        int int55 = month32.getMonth();
        org.jfree.data.time.TimeSeries timeSeries56 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (org.jfree.data.time.RegularTimePeriod) month32);
        double double57 = timeSeries1.getMinY();
        try {
            timeSeries1.update(2147483647, (java.lang.Number) 1560185143590L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2147483647, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 100L + "'", long14 == 100L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 100L + "'", long28 == 100L);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str29.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNull(timeSeriesDataItem42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(obj44);
        org.junit.Assert.assertNotNull(collection53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 6 + "'", int55 == 6);
        org.junit.Assert.assertNotNull(timeSeries56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setNotify(false);
        double double8 = timeSeries1.getMinY();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        timeSeries10.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) (byte) 10, false);
        timeSeries10.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
        timeSeries18.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) (byte) 10, false);
        timeSeries18.setNotify(false);
        java.util.Collection collection25 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries18.getDataItem((org.jfree.data.time.RegularTimePeriod) year26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year26.previous();
        int int29 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) year26);
        long long30 = year26.getSerialIndex();
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 10.0d + "'", double8 == 10.0d);
        org.junit.Assert.assertNotNull(collection25);
        org.junit.Assert.assertNotNull(timeSeriesDataItem27);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 2019L + "'", long30 == 2019L);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.removeChangeListener(seriesChangeListener6);
        timeSeries1.setDomainDescription("31-December-2019");
        java.lang.String str10 = timeSeries1.getDescription();
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        timeSeries2.add((org.jfree.data.time.RegularTimePeriod) month3, (java.lang.Number) (byte) 10, false);
        timeSeries2.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        timeSeries10.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) (byte) 10, false);
        timeSeries10.setNotify(false);
        java.util.Collection collection17 = timeSeries2.getTimePeriodsUniqueToOtherSeries(timeSeries10);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries10.getDataItem((org.jfree.data.time.RegularTimePeriod) year18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year18.previous();
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(6, year18);
        int int22 = month21.getMonth();
        java.util.Calendar calendar23 = null;
        try {
            long long24 = month21.getLastMillisecond(calendar23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertNotNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
    }

//    @Test
//    public void test267() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test267");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.util.Date date1 = year0.getEnd();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        java.lang.String str3 = day2.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
//        int int6 = day2.compareTo((java.lang.Object) 1L);
//        long long7 = day2.getLastMillisecond();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int9 = day2.compareTo((java.lang.Object) day8);
//        int int10 = day2.getDayOfMonth();
//        java.lang.Object obj11 = null;
//        int int12 = day2.compareTo(obj11);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 204 + "'", int9 == 204);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 31 + "'", int10 == 31);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        java.lang.Object obj8 = timeSeries1.clone();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        long long12 = day11.getSerialIndex();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day11);
        java.lang.Object obj14 = timeSeries1.clone();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        java.util.Date date17 = year16.getEnd();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 1, year16);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) year16);
        long long20 = year16.getSerialIndex();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43830L + "'", long12 == 43830L);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2019L + "'", long20 == 2019L);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (short) 1, year1);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException5.getSuppressed();
        boolean boolean10 = month3.equals((java.lang.Object) throwableArray9);
        int int11 = month3.getMonth();
        org.jfree.data.time.Year year12 = month3.getYear();
        org.jfree.data.time.Year year13 = month3.getYear();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(year12);
        org.junit.Assert.assertNotNull(year13);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1, "", "hi!");
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) (byte) 10, false);
        timeSeries5.setRangeDescription("hi!");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries5.getNextTimePeriod();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) month15, (java.lang.Number) (byte) 10, false);
        timeSeries14.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        timeSeries22.add((org.jfree.data.time.RegularTimePeriod) month23, (java.lang.Number) (byte) 10, false);
        timeSeries22.setNotify(false);
        java.util.Collection collection29 = timeSeries14.getTimePeriodsUniqueToOtherSeries(timeSeries22);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries22.getDataItem((org.jfree.data.time.RegularTimePeriod) year30);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries5.addOrUpdate(timeSeriesDataItem31);
        boolean boolean33 = timeSeriesDataItem31.isSelected();
        boolean boolean34 = timeSeries3.equals((java.lang.Object) boolean33);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(collection29);
        org.junit.Assert.assertNotNull(timeSeriesDataItem31);
        org.junit.Assert.assertNotNull(timeSeriesDataItem32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        boolean boolean3 = year1.equals((java.lang.Object) 2);
        java.util.Calendar calendar4 = null;
        try {
            year1.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

//    @Test
//    public void test272() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test272");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "2019", "");
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
//        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) (byte) 10, false);
//        timeSeries5.setNotify(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar13 = null;
//        long long14 = fixedMillisecond12.getFirstMillisecond(calendar13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries5.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
//        timeSeries3.add(timeSeriesDataItem15, true);
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
//        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
//        java.util.Date date21 = year20.getEnd();
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date21);
//        java.lang.String str23 = day22.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day22.next();
//        int int25 = day22.getMonth();
//        timeSeries19.add((org.jfree.data.time.RegularTimePeriod) day22, (double) 100);
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
//        java.util.Date date29 = year28.getEnd();
//        boolean boolean31 = year28.equals((java.lang.Object) (-1.0d));
//        int int33 = year28.compareTo((java.lang.Object) 1.0d);
//        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
//        java.util.Date date35 = year34.getEnd();
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date35);
//        java.lang.String str37 = day36.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = day36.next();
//        int int39 = day36.getMonth();
//        java.lang.String str40 = day36.toString();
//        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries19.createCopy((org.jfree.data.time.RegularTimePeriod) year28, (org.jfree.data.time.RegularTimePeriod) day36);
//        double double42 = timeSeries19.getMinY();
//        java.util.List list43 = timeSeries19.getItems();
//        boolean boolean44 = timeSeriesDataItem15.equals((java.lang.Object) timeSeries19);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560185151695L + "'", long14 == 1560185151695L);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem15);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "31-December-2019" + "'", str23.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 12 + "'", int25 == 12);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "31-December-2019" + "'", str37.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 12 + "'", int39 == 12);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "31-December-2019" + "'", str40.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(timeSeries41);
//        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 100.0d + "'", double42 == 100.0d);
//        org.junit.Assert.assertNotNull(list43);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.removeChangeListener(seriesChangeListener6);
        timeSeries1.setDomainDescription("31-December-2019");
        try {
            timeSeries1.delete(10, (int) (byte) 100, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        java.lang.String str5 = day4.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day4.next();
        int int7 = day4.getMonth();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (double) 100);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries1.addChangeListener(seriesChangeListener10);
        try {
            timeSeries1.delete((int) (short) 0, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "31-December-2019" + "'", str5.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("Value");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setRangeDescription("hi!");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeries1.getNextTimePeriod();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        java.lang.String str12 = day11.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day11.next();
        java.util.Date date14 = regularTimePeriod13.getStart();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date14);
        java.lang.String str16 = timeSeries15.getDescription();
        java.util.Collection collection17 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries15);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        java.util.Date date19 = year18.getEnd();
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date19);
        java.lang.String str21 = day20.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day20.next();
        int int23 = day20.getMonth();
        java.lang.String str24 = day20.toString();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day20, "", "org.jfree.data.event.SeriesChangeEvent[source=1]");
        org.jfree.data.time.SerialDate serialDate28 = day20.getSerialDate();
        java.lang.String str29 = day20.toString();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day20, (java.lang.Number) 1560185142033L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Day, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "31-December-2019" + "'", str12.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "31-December-2019" + "'", str21.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 12 + "'", int23 == 12);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "31-December-2019" + "'", str24.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "31-December-2019" + "'", str29.equals("31-December-2019"));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0);
        java.util.Calendar calendar2 = null;
        try {
            month0.peg(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.event.SeriesChangeEvent[source=class org.jfree.data.time.Year]");
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.Year year9 = org.jfree.data.time.Year.parseYear("2019");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) year9);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries1.addChangeListener(seriesChangeListener11);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(timeSeriesDataItem10);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "2019", "");
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        timeSeries6.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10, false);
        timeSeries6.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) month15, (java.lang.Number) (byte) 10, false);
        timeSeries14.setNotify(false);
        java.util.Collection collection21 = timeSeries6.getTimePeriodsUniqueToOtherSeries(timeSeries14);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries14.getDataItem((org.jfree.data.time.RegularTimePeriod) year22);
        timeSeriesDataItem23.setValue((java.lang.Number) (byte) 1);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo27 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent28 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (short) 1, seriesChangeInfo27);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo29 = seriesChangeEvent28.getSummary();
        int int30 = timeSeriesDataItem23.compareTo((java.lang.Object) seriesChangeInfo29);
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
        timeSeries32.add((org.jfree.data.time.RegularTimePeriod) month33, (java.lang.Number) (byte) 10, false);
        timeSeries32.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month();
        timeSeries40.add((org.jfree.data.time.RegularTimePeriod) month41, (java.lang.Number) (byte) 10, false);
        timeSeries40.setNotify(false);
        java.util.Collection collection47 = timeSeries32.getTimePeriodsUniqueToOtherSeries(timeSeries40);
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries40.getDataItem((org.jfree.data.time.RegularTimePeriod) year48);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = year48.previous();
        boolean boolean51 = timeSeriesDataItem23.equals((java.lang.Object) year48);
        timeSeries3.add(timeSeriesDataItem23, true);
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertNotNull(collection21);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertNull(seriesChangeInfo29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(collection47);
        org.junit.Assert.assertNotNull(timeSeriesDataItem49);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
        java.util.Date date5 = regularTimePeriod4.getStart();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date5);
        java.lang.String str7 = timeSeries6.getDescription();
        java.lang.String str8 = timeSeries6.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        java.util.Date date12 = year11.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (java.lang.Number) 0.0f);
        boolean boolean16 = timeSeries10.getNotify();
        java.lang.Object obj17 = timeSeries10.clone();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        java.util.Date date19 = year18.getEnd();
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date19);
        long long21 = day20.getSerialIndex();
        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) day20);
        java.lang.Object obj23 = timeSeries10.clone();
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries6.addAndOrUpdate(timeSeries10);
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        timeSeries26.add((org.jfree.data.time.RegularTimePeriod) month27, (java.lang.Number) (byte) 10, false);
        timeSeries26.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month();
        timeSeries34.add((org.jfree.data.time.RegularTimePeriod) month35, (java.lang.Number) (byte) 10, false);
        timeSeries34.setNotify(false);
        java.util.Collection collection41 = timeSeries26.getTimePeriodsUniqueToOtherSeries(timeSeries34);
        boolean boolean42 = timeSeries26.getNotify();
        timeSeries26.removeAgedItems((long) 'a', true);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = timeSeries26.getNextTimePeriod();
        java.lang.String str47 = regularTimePeriod46.toString();
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year();
        java.util.Date date49 = year48.getEnd();
        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(date49);
        java.lang.String str51 = day50.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = day50.next();
        int int53 = day50.getMonth();
        java.lang.String str54 = day50.toString();
        org.jfree.data.time.TimeSeries timeSeries57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day50, "", "org.jfree.data.event.SeriesChangeEvent[source=1]");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day50, (java.lang.Number) (-1L));
        org.jfree.data.time.TimeSeries timeSeries60 = timeSeries6.createCopy(regularTimePeriod46, (org.jfree.data.time.RegularTimePeriod) day50);
        java.util.Calendar calendar61 = null;
        try {
            long long62 = day50.getFirstMillisecond(calendar61);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Value" + "'", str8.equals("Value"));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 43830L + "'", long21 == 43830L);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertNotNull(timeSeries24);
        org.junit.Assert.assertNotNull(collection41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "July 2019" + "'", str47.equals("July 2019"));
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "31-December-2019" + "'", str51.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 12 + "'", int53 == 12);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "31-December-2019" + "'", str54.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(timeSeries60);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        double double2 = timeSeries1.getMinY();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener3);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
        java.util.Date date5 = regularTimePeriod4.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date5);
        long long8 = month7.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865600000L + "'", long8 == 1577865600000L);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) (byte) 10, false);
        timeSeries9.setNotify(false);
        java.util.Collection collection16 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries9);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener17 = null;
        timeSeries1.addChangeListener(seriesChangeListener17);
        timeSeries1.fireSeriesChanged();
        org.junit.Assert.assertNotNull(collection16);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setNotify(false);
        double double8 = timeSeries1.getMinY();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Date date11 = fixedMillisecond10.getTime();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(date11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Date date15 = fixedMillisecond14.getTime();
        int int16 = month12.compareTo((java.lang.Object) fixedMillisecond14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month12, (java.lang.Number) 1560185123923L);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 10.0d + "'", double8 == 10.0d);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.removeChangeListener(seriesChangeListener6);
        timeSeries1.setDomainDescription("31-December-2019");
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        timeSeries11.add((org.jfree.data.time.RegularTimePeriod) month12, (java.lang.Number) (byte) 10, false);
        timeSeries11.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        timeSeries19.add((org.jfree.data.time.RegularTimePeriod) month20, (java.lang.Number) (byte) 10, false);
        timeSeries19.setNotify(false);
        java.util.Collection collection26 = timeSeries11.getTimePeriodsUniqueToOtherSeries(timeSeries19);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries19.getDataItem((org.jfree.data.time.RegularTimePeriod) year27);
        timeSeriesDataItem28.setValue((java.lang.Number) (byte) 1);
        boolean boolean32 = timeSeriesDataItem28.equals((java.lang.Object) (-1.0f));
        boolean boolean33 = timeSeries1.equals((java.lang.Object) (-1.0f));
        timeSeries1.setNotify(true);
        org.junit.Assert.assertNotNull(collection26);
        org.junit.Assert.assertNotNull(timeSeriesDataItem28);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        java.lang.String str5 = day4.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day4.next();
        int int7 = day4.getMonth();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (double) 100);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        boolean boolean13 = year10.equals((java.lang.Object) (-1.0d));
        int int15 = year10.compareTo((java.lang.Object) 1.0d);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        java.util.Date date17 = year16.getEnd();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date17);
        java.lang.String str19 = day18.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day18.next();
        int int21 = day18.getMonth();
        java.lang.String str22 = day18.toString();
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year10, (org.jfree.data.time.RegularTimePeriod) day18);
        double double24 = timeSeries23.getMaxY();
        timeSeries23.setMaximumItemCount(0);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "31-December-2019" + "'", str5.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "31-December-2019" + "'", str19.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 12 + "'", int21 == 12);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "31-December-2019" + "'", str22.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 100.0d + "'", double24 == 100.0d);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date1);
        int int5 = day4.getDayOfMonth();
        int int6 = day4.getDayOfMonth();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 31 + "'", int5 == 31);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 31 + "'", int6 == 31);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("July 2019");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "July 2019", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: hi!", "January 2020");
        org.junit.Assert.assertNotNull(month1);
    }

//    @Test
//    public void test290() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test290");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.util.Date date1 = year0.getEnd();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        java.lang.String str3 = day2.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
//        int int6 = day2.compareTo((java.lang.Object) 1L);
//        long long7 = day2.getLastMillisecond();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int9 = day2.compareTo((java.lang.Object) day8);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day8.next();
//        java.util.Calendar calendar11 = null;
//        try {
//            day8.peg(calendar11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 204 + "'", int9 == 204);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        java.lang.Object obj8 = timeSeries1.clone();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        long long12 = day11.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) day11);
        double double14 = timeSeries1.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener15);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43830L + "'", long12 == 43830L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
        java.util.Date date5 = regularTimePeriod4.getStart();
        java.util.TimeZone timeZone6 = null;
        try {
            org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date5, timeZone6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.Year year9 = org.jfree.data.time.Year.parseYear("2019");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) year9);
        timeSeries1.setNotify(true);
        java.lang.String str13 = timeSeries1.getDomainDescription();
        java.lang.Class class14 = timeSeries1.getTimePeriodClass();
        timeSeries1.clear();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        java.util.Date date19 = year18.getEnd();
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date19);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries17.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day20, (java.lang.Number) 0.0f);
        boolean boolean23 = timeSeries17.getNotify();
        java.lang.Object obj24 = timeSeries17.clone();
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        timeSeries26.add((org.jfree.data.time.RegularTimePeriod) month27, (java.lang.Number) (byte) 10, false);
        timeSeries26.setNotify(false);
        java.util.Collection collection33 = timeSeries17.getTimePeriodsUniqueToOtherSeries(timeSeries26);
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        java.util.Date date37 = year36.getEnd();
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date37);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries35.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day38, (java.lang.Number) 0.0f);
        boolean boolean41 = timeSeries35.getNotify();
        java.lang.Object obj42 = timeSeries35.clone();
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year();
        java.util.Date date44 = year43.getEnd();
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date44);
        long long46 = day45.getSerialIndex();
        timeSeries35.delete((org.jfree.data.time.RegularTimePeriod) day45);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = timeSeries17.getDataItem((org.jfree.data.time.RegularTimePeriod) day45);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day45, (double) 1560185128766L);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day45, (double) (short) 0, true);
        long long54 = timeSeries1.getMaximumItemAge();
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Time" + "'", str13.equals("Time"));
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertNotNull(collection33);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNull(timeSeriesDataItem40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(obj42);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 43830L + "'", long46 == 43830L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem48);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 9223372036854775807L + "'", long54 == 9223372036854775807L);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) (byte) 10, false);
        timeSeries9.setNotify(false);
        java.util.Collection collection16 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries9);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener17 = null;
        timeSeries1.addChangeListener(seriesChangeListener17);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        java.util.Date date22 = year21.getEnd();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day23, (java.lang.Number) 0.0f);
        boolean boolean26 = timeSeries20.getNotify();
        int int27 = timeSeries20.getItemCount();
        java.beans.PropertyChangeListener propertyChangeListener28 = null;
        timeSeries20.removePropertyChangeListener(propertyChangeListener28);
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Date date32 = fixedMillisecond31.getTime();
        long long33 = fixedMillisecond31.getFirstMillisecond();
        java.util.Date date34 = fixedMillisecond31.getTime();
        java.lang.Object obj35 = null;
        int int36 = fixedMillisecond31.compareTo(obj35);
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
        java.util.Date date40 = year39.getEnd();
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date40);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries38.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day41, (java.lang.Number) 0.0f);
        int int45 = day41.compareTo((java.lang.Object) (short) 0);
        int int46 = fixedMillisecond31.compareTo((java.lang.Object) int45);
        long long47 = fixedMillisecond31.getSerialIndex();
        java.lang.String str48 = fixedMillisecond31.toString();
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month();
        timeSeries50.add((org.jfree.data.time.RegularTimePeriod) month51, (java.lang.Number) (byte) 10, false);
        org.jfree.data.time.TimeSeries timeSeries56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year();
        java.util.Date date58 = year57.getEnd();
        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day(date58);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem61 = timeSeries56.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day59, (java.lang.Number) 0.0f);
        boolean boolean62 = timeSeries56.getNotify();
        java.lang.Object obj63 = timeSeries56.clone();
        org.jfree.data.time.TimeSeries timeSeries65 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month66 = new org.jfree.data.time.Month();
        timeSeries65.add((org.jfree.data.time.RegularTimePeriod) month66, (java.lang.Number) (byte) 10, false);
        timeSeries65.setNotify(false);
        java.util.Collection collection72 = timeSeries56.getTimePeriodsUniqueToOtherSeries(timeSeries65);
        int int73 = month51.compareTo((java.lang.Object) timeSeries56);
        int int74 = month51.getMonth();
        org.jfree.data.time.TimeSeries timeSeries75 = timeSeries20.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond31, (org.jfree.data.time.RegularTimePeriod) month51);
        java.lang.Number number76 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) month51);
        java.util.Collection collection77 = timeSeries1.getTimePeriods();
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNull(timeSeriesDataItem25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 100L + "'", long33 == 100L);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNull(timeSeriesDataItem43);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 100L + "'", long47 == 100L);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str48.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertNull(timeSeriesDataItem61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(obj63);
        org.junit.Assert.assertNotNull(collection72);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 1 + "'", int73 == 1);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 6 + "'", int74 == 6);
        org.junit.Assert.assertNotNull(timeSeries75);
        org.junit.Assert.assertTrue("'" + number76 + "' != '" + (byte) 10 + "'", number76.equals((byte) 10));
        org.junit.Assert.assertNotNull(collection77);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) (byte) 10, false);
        timeSeries9.setNotify(false);
        java.util.Collection collection16 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries9);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener17 = null;
        timeSeries1.addChangeListener(seriesChangeListener17);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        java.util.Date date22 = year21.getEnd();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day23, (java.lang.Number) 0.0f);
        boolean boolean26 = timeSeries20.getNotify();
        int int27 = timeSeries20.getItemCount();
        java.beans.PropertyChangeListener propertyChangeListener28 = null;
        timeSeries20.removePropertyChangeListener(propertyChangeListener28);
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Date date32 = fixedMillisecond31.getTime();
        long long33 = fixedMillisecond31.getFirstMillisecond();
        java.util.Date date34 = fixedMillisecond31.getTime();
        java.lang.Object obj35 = null;
        int int36 = fixedMillisecond31.compareTo(obj35);
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
        java.util.Date date40 = year39.getEnd();
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date40);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries38.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day41, (java.lang.Number) 0.0f);
        int int45 = day41.compareTo((java.lang.Object) (short) 0);
        int int46 = fixedMillisecond31.compareTo((java.lang.Object) int45);
        long long47 = fixedMillisecond31.getSerialIndex();
        java.lang.String str48 = fixedMillisecond31.toString();
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month();
        timeSeries50.add((org.jfree.data.time.RegularTimePeriod) month51, (java.lang.Number) (byte) 10, false);
        org.jfree.data.time.TimeSeries timeSeries56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year();
        java.util.Date date58 = year57.getEnd();
        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day(date58);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem61 = timeSeries56.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day59, (java.lang.Number) 0.0f);
        boolean boolean62 = timeSeries56.getNotify();
        java.lang.Object obj63 = timeSeries56.clone();
        org.jfree.data.time.TimeSeries timeSeries65 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month66 = new org.jfree.data.time.Month();
        timeSeries65.add((org.jfree.data.time.RegularTimePeriod) month66, (java.lang.Number) (byte) 10, false);
        timeSeries65.setNotify(false);
        java.util.Collection collection72 = timeSeries56.getTimePeriodsUniqueToOtherSeries(timeSeries65);
        int int73 = month51.compareTo((java.lang.Object) timeSeries56);
        int int74 = month51.getMonth();
        org.jfree.data.time.TimeSeries timeSeries75 = timeSeries20.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond31, (org.jfree.data.time.RegularTimePeriod) month51);
        java.lang.Number number76 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) month51);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = month51.previous();
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNull(timeSeriesDataItem25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 100L + "'", long33 == 100L);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNull(timeSeriesDataItem43);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 100L + "'", long47 == 100L);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str48.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertNull(timeSeriesDataItem61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(obj63);
        org.junit.Assert.assertNotNull(collection72);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 1 + "'", int73 == 1);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 6 + "'", int74 == 6);
        org.junit.Assert.assertNotNull(timeSeries75);
        org.junit.Assert.assertTrue("'" + number76 + "' != '" + (byte) 10 + "'", number76.equals((byte) 10));
        org.junit.Assert.assertNotNull(regularTimePeriod77);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        long long2 = fixedMillisecond1.getFirstMillisecond();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setNotify(false);
        double double8 = timeSeries1.getMinY();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        timeSeries10.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) (byte) 10, false);
        timeSeries10.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
        timeSeries18.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) (byte) 10, false);
        timeSeries18.setNotify(false);
        java.util.Collection collection25 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries18.getDataItem((org.jfree.data.time.RegularTimePeriod) year26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year26.previous();
        int int29 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) year26);
        long long30 = year26.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 10.0d + "'", double8 == 10.0d);
        org.junit.Assert.assertNotNull(collection25);
        org.junit.Assert.assertNotNull(timeSeriesDataItem27);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1577865599999L + "'", long30 == 1577865599999L);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
        java.util.Date date5 = regularTimePeriod4.getStart();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date5);
        java.lang.String str7 = timeSeries6.getDescription();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = timeSeries6.getTimePeriod((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        org.jfree.data.time.Year year2 = month0.getYear();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = month0.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertNotNull(year2);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (short) 1, year1);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException5.getSuppressed();
        boolean boolean10 = month3.equals((java.lang.Object) throwableArray9);
        int int11 = month3.getMonth();
        org.jfree.data.time.Year year12 = month3.getYear();
        long long13 = year12.getLastMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(year12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        timeSeries2.add((org.jfree.data.time.RegularTimePeriod) month3, (java.lang.Number) (byte) 10, false);
        timeSeries2.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        timeSeries10.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) (byte) 10, false);
        timeSeries10.setNotify(false);
        java.util.Collection collection17 = timeSeries2.getTimePeriodsUniqueToOtherSeries(timeSeries10);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries10.getDataItem((org.jfree.data.time.RegularTimePeriod) year18);
        try {
            org.jfree.data.time.Month month20 = new org.jfree.data.time.Month((int) '4', year18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertNotNull(timeSeriesDataItem19);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        java.lang.String str5 = day4.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day4.next();
        int int7 = day4.getMonth();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (double) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = timeSeries1.getNextTimePeriod();
        timeSeries1.setRangeDescription("35");
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "31-December-2019" + "'", str5.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener8);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        java.util.Date date13 = year12.getEnd();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        java.lang.String str15 = day14.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day14.next();
        int int17 = day14.getMonth();
        timeSeries11.add((org.jfree.data.time.RegularTimePeriod) day14, (double) 100);
        int int20 = day14.getDayOfMonth();
        int int21 = day14.getMonth();
        long long22 = day14.getFirstMillisecond();
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day14, (double) 1560150000000L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Day, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "31-December-2019" + "'", str15.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 12 + "'", int17 == 12);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 31 + "'", int20 == 31);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 12 + "'", int21 == 12);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1577779200000L + "'", long22 == 1577779200000L);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries(comparable0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        int int2 = month0.getYearValue();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = month0.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
        java.util.Date date5 = regularTimePeriod4.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date5);
        java.util.TimeZone timeZone8 = null;
        java.util.Locale locale9 = null;
        try {
            org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date5, timeZone8, locale9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month2.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month2.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        java.lang.Object obj8 = timeSeries1.clone();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        timeSeries10.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) (byte) 10, false);
        timeSeries10.setNotify(false);
        java.util.Collection collection17 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries10);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.util.Date date21 = year20.getEnd();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date21);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries19.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day22, (java.lang.Number) 0.0f);
        boolean boolean25 = timeSeries19.getNotify();
        java.lang.Object obj26 = timeSeries19.clone();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        java.util.Date date28 = year27.getEnd();
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date28);
        long long30 = day29.getSerialIndex();
        timeSeries19.delete((org.jfree.data.time.RegularTimePeriod) day29);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) day29);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day29, (double) 1560185128766L);
        java.util.Calendar calendar35 = null;
        try {
            long long36 = day29.getLastMillisecond(calendar35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 43830L + "'", long30 == 43830L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem32);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("2019");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 5");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = day0.getFirstMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Date date2 = fixedMillisecond1.getTime();
        long long3 = fixedMillisecond1.getFirstMillisecond();
        java.util.Date date4 = fixedMillisecond1.getTime();
        long long5 = fixedMillisecond1.getLastMillisecond();
        long long6 = fixedMillisecond1.getLastMillisecond();
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond1.getFirstMillisecond(calendar7);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 100L + "'", long5 == 100L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        org.jfree.data.time.Year year2 = month0.getYear();
        java.util.Date date3 = month0.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month0.next();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0, "", "hi!");
        timeSeries3.fireSeriesChanged();
        boolean boolean5 = timeSeries3.isEmpty();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        java.util.List list8 = timeSeries1.getItems();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        long long10 = month9.getLastMillisecond();
        org.jfree.data.time.Year year11 = month9.getYear();
        java.lang.Number number12 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) year11);
        long long13 = year11.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year11.next();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1561964399999L + "'", long10 == 1561964399999L);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 0.0f + "'", number12.equals(0.0f));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) (byte) 10, false);
        timeSeries9.setNotify(false);
        java.util.Collection collection16 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries9);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener17 = null;
        timeSeries1.addChangeListener(seriesChangeListener17);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries1.removeChangeListener(seriesChangeListener19);
        org.junit.Assert.assertNotNull(collection16);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
        java.util.Date date5 = regularTimePeriod4.getStart();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date5);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day11, (java.lang.Number) 0.0f);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.util.Date date15 = year14.getEnd();
        boolean boolean17 = year14.equals((java.lang.Object) (-1.0d));
        int int19 = year14.compareTo((java.lang.Object) 1.0d);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries8.getDataItem((org.jfree.data.time.RegularTimePeriod) year14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year14, (java.lang.Number) 1L);
        java.util.Calendar calendar23 = null;
        try {
            long long24 = year14.getFirstMillisecond(calendar23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(timeSeriesDataItem20);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        java.lang.Class class0 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Date date3 = fixedMillisecond2.getTime();
        long long4 = fixedMillisecond2.getFirstMillisecond();
        java.util.Date date5 = fixedMillisecond2.getTime();
        java.lang.Object obj6 = null;
        int int7 = fixedMillisecond2.compareTo(obj6);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date9);
        java.lang.String str11 = day10.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day10.next();
        boolean boolean13 = fixedMillisecond2.equals((java.lang.Object) regularTimePeriod12);
        long long14 = fixedMillisecond2.getSerialIndex();
        java.util.Date date15 = fixedMillisecond2.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(date15);
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date15, timeZone17);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "31-December-2019" + "'", str11.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 100L + "'", long14 == 100L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNull(regularTimePeriod18);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
        java.util.Date date5 = regularTimePeriod4.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date5);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(date5);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        timeSeries1.setDescription("");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        java.util.Date date8 = year7.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        long long10 = day9.getLastMillisecond();
        int int11 = year5.compareTo((java.lang.Object) day9);
        long long12 = day9.getSerialIndex();
        java.lang.String str13 = day9.toString();
        timeSeries1.setKey((java.lang.Comparable) day9);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43830L + "'", long12 == 43830L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "31-December-2019" + "'", str13.equals("31-December-2019"));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Date date2 = fixedMillisecond1.getTime();
        long long3 = fixedMillisecond1.getLastMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        java.lang.Object obj8 = timeSeries1.clone();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        long long12 = day11.getSerialIndex();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day11);
        java.lang.Object obj14 = timeSeries1.clone();
        java.lang.Class<?> wildcardClass15 = obj14.getClass();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43830L + "'", long12 == 43830L);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        java.lang.Object obj8 = timeSeries1.clone();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        long long12 = day11.getSerialIndex();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day11);
        java.lang.Object obj14 = timeSeries1.clone();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        java.util.Date date17 = year16.getEnd();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 1, year16);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) year16);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year16);
        try {
            timeSeries20.setMaximumItemCount((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'maximum' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43830L + "'", long12 == 43830L);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(date17);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "2019", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        timeSeries3.removeAgedItems(1560185141463L, true);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo9 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timePeriodFormatException7, seriesChangeInfo9);
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
        java.util.Date date5 = regularTimePeriod4.getStart();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date5);
        java.lang.String str7 = timeSeries6.getDescription();
        java.lang.String str8 = timeSeries6.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        java.util.Date date12 = year11.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (java.lang.Number) 0.0f);
        boolean boolean16 = timeSeries10.getNotify();
        java.lang.Object obj17 = timeSeries10.clone();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        java.util.Date date19 = year18.getEnd();
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date19);
        long long21 = day20.getSerialIndex();
        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) day20);
        java.lang.Object obj23 = timeSeries10.clone();
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries6.addAndOrUpdate(timeSeries10);
        java.beans.PropertyChangeListener propertyChangeListener25 = null;
        timeSeries24.addPropertyChangeListener(propertyChangeListener25);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener27 = null;
        timeSeries24.addChangeListener(seriesChangeListener27);
        timeSeries24.fireSeriesChanged();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Value" + "'", str8.equals("Value"));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 43830L + "'", long21 == 43830L);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertNotNull(timeSeries24);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener8);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.previous();
        timeSeries1.update(regularTimePeriod12, (java.lang.Number) 1560185128766L);
        java.lang.String str15 = timeSeries1.getDomainDescription();
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Time" + "'", str15.equals("Time"));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) (byte) 10, false);
        timeSeries9.setNotify(false);
        java.util.Collection collection16 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries9);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener17 = null;
        timeSeries1.addChangeListener(seriesChangeListener17);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        java.util.Date date22 = year21.getEnd();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day23, (java.lang.Number) 0.0f);
        boolean boolean26 = timeSeries20.getNotify();
        int int27 = timeSeries20.getItemCount();
        java.beans.PropertyChangeListener propertyChangeListener28 = null;
        timeSeries20.removePropertyChangeListener(propertyChangeListener28);
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Date date32 = fixedMillisecond31.getTime();
        long long33 = fixedMillisecond31.getFirstMillisecond();
        java.util.Date date34 = fixedMillisecond31.getTime();
        java.lang.Object obj35 = null;
        int int36 = fixedMillisecond31.compareTo(obj35);
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
        java.util.Date date40 = year39.getEnd();
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date40);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries38.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day41, (java.lang.Number) 0.0f);
        int int45 = day41.compareTo((java.lang.Object) (short) 0);
        int int46 = fixedMillisecond31.compareTo((java.lang.Object) int45);
        long long47 = fixedMillisecond31.getSerialIndex();
        java.lang.String str48 = fixedMillisecond31.toString();
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month();
        timeSeries50.add((org.jfree.data.time.RegularTimePeriod) month51, (java.lang.Number) (byte) 10, false);
        org.jfree.data.time.TimeSeries timeSeries56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year();
        java.util.Date date58 = year57.getEnd();
        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day(date58);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem61 = timeSeries56.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day59, (java.lang.Number) 0.0f);
        boolean boolean62 = timeSeries56.getNotify();
        java.lang.Object obj63 = timeSeries56.clone();
        org.jfree.data.time.TimeSeries timeSeries65 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month66 = new org.jfree.data.time.Month();
        timeSeries65.add((org.jfree.data.time.RegularTimePeriod) month66, (java.lang.Number) (byte) 10, false);
        timeSeries65.setNotify(false);
        java.util.Collection collection72 = timeSeries56.getTimePeriodsUniqueToOtherSeries(timeSeries65);
        int int73 = month51.compareTo((java.lang.Object) timeSeries56);
        int int74 = month51.getMonth();
        org.jfree.data.time.TimeSeries timeSeries75 = timeSeries20.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond31, (org.jfree.data.time.RegularTimePeriod) month51);
        java.lang.Number number76 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) month51);
        org.jfree.data.time.TimeSeries timeSeries78 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year79 = new org.jfree.data.time.Year();
        java.util.Date date80 = year79.getEnd();
        org.jfree.data.time.Day day81 = new org.jfree.data.time.Day(date80);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem83 = timeSeries78.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day81, (java.lang.Number) 0.0f);
        org.jfree.data.time.SerialDate serialDate84 = day81.getSerialDate();
        int int85 = day81.getDayOfMonth();
        java.lang.String str86 = day81.toString();
        int int87 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) day81);
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNull(timeSeriesDataItem25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 100L + "'", long33 == 100L);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNull(timeSeriesDataItem43);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 100L + "'", long47 == 100L);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str48.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertNull(timeSeriesDataItem61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(obj63);
        org.junit.Assert.assertNotNull(collection72);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 1 + "'", int73 == 1);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 6 + "'", int74 == 6);
        org.junit.Assert.assertNotNull(timeSeries75);
        org.junit.Assert.assertTrue("'" + number76 + "' != '" + (byte) 10 + "'", number76.equals((byte) 10));
        org.junit.Assert.assertNotNull(date80);
        org.junit.Assert.assertNull(timeSeriesDataItem83);
        org.junit.Assert.assertNotNull(serialDate84);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 31 + "'", int85 == 31);
        org.junit.Assert.assertTrue("'" + str86 + "' != '" + "31-December-2019" + "'", str86.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 0 + "'", int87 == 0);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) (byte) 10, false);
        timeSeries9.setNotify(false);
        java.util.Collection collection16 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries9);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) year17);
        timeSeriesDataItem18.setValue((java.lang.Number) 1559372400000L);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo21 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent22 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeriesDataItem18, seriesChangeInfo21);
        java.lang.Object obj23 = seriesChangeEvent22.getSource();
        java.lang.Object obj24 = seriesChangeEvent22.getSource();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo25 = null;
        seriesChangeEvent22.setSummary(seriesChangeInfo25);
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertNotNull(timeSeriesDataItem18);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertNotNull(obj24);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) (byte) 10, false);
        timeSeries9.setNotify(false);
        java.util.Collection collection16 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries9);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) year17);
        timeSeriesDataItem18.setValue((java.lang.Number) 1559372400000L);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo21 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent22 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeriesDataItem18, seriesChangeInfo21);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo23 = null;
        seriesChangeEvent22.setSummary(seriesChangeInfo23);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo25 = null;
        seriesChangeEvent22.setSummary(seriesChangeInfo25);
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertNotNull(timeSeriesDataItem18);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        java.lang.Object obj8 = timeSeries1.clone();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        long long12 = day11.getSerialIndex();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day11);
        java.lang.Object obj14 = timeSeries1.clone();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        java.util.Date date17 = year16.getEnd();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 1, year16);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) year16);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year16);
        java.lang.String str21 = year16.toString();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43830L + "'", long12 == 43830L);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2019" + "'", str21.equals("2019"));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        java.lang.Object obj8 = null;
        boolean boolean9 = timeSeries1.equals(obj8);
        boolean boolean10 = timeSeries1.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        timeSeries12.add((org.jfree.data.time.RegularTimePeriod) month13, (java.lang.Number) (byte) 10, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener17 = null;
        timeSeries12.removeChangeListener(seriesChangeListener17);
        org.jfree.data.time.Year year20 = org.jfree.data.time.Year.parseYear("2019");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries12.getDataItem((org.jfree.data.time.RegularTimePeriod) year20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = fixedMillisecond23.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = fixedMillisecond23.next();
        boolean boolean26 = timeSeriesDataItem21.equals((java.lang.Object) regularTimePeriod25);
        int int27 = timeSeries1.getIndex(regularTimePeriod25);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(year20);
        org.junit.Assert.assertNotNull(timeSeriesDataItem21);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
        java.util.Date date5 = regularTimePeriod4.getStart();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date5);
        java.util.Collection collection7 = timeSeries6.getTimePeriods();
        java.lang.String str8 = timeSeries6.getRangeDescription();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = null;
        try {
            timeSeries6.add(timeSeriesDataItem9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(collection7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Value" + "'", str8.equals("Value"));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) (byte) 10, false);
        timeSeries9.setNotify(false);
        java.util.Collection collection16 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries9);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) year17);
        java.lang.Object obj19 = timeSeriesDataItem18.clone();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year21.next();
        int int23 = timeSeriesDataItem18.compareTo((java.lang.Object) year21);
        long long24 = year21.getFirstMillisecond();
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertNotNull(timeSeriesDataItem18);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-61062825600000L) + "'", long24 == (-61062825600000L));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (short) 1, year1);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException5.getSuppressed();
        boolean boolean10 = month3.equals((java.lang.Object) throwableArray9);
        int int11 = month3.getMonth();
        org.jfree.data.time.Year year12 = month3.getYear();
        long long13 = month3.getLastMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(year12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1549007999999L + "'", long13 == 1549007999999L);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        org.jfree.data.time.Year year2 = month0.getYear();
        java.util.Date date3 = month0.getStart();
        java.util.TimeZone timeZone4 = null;
        try {
            org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date3, timeZone4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "2019", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        timeSeries3.setDomainDescription("");
        timeSeries3.setDomainDescription("35");
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (short) 1, seriesChangeInfo1);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo3 = seriesChangeEvent2.getSummary();
        java.lang.String str4 = seriesChangeEvent2.toString();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo5 = seriesChangeEvent2.getSummary();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo6 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) seriesChangeEvent2, seriesChangeInfo6);
        org.junit.Assert.assertNull(seriesChangeInfo3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=1]" + "'", str4.equals("org.jfree.data.event.SeriesChangeEvent[source=1]"));
        org.junit.Assert.assertNull(seriesChangeInfo5);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
        java.util.Date date5 = regularTimePeriod4.getStart();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date5);
        java.lang.String str7 = timeSeries6.getDescription();
        java.lang.String str8 = timeSeries6.getRangeDescription();
        long long9 = timeSeries6.getMaximumItemAge();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Value" + "'", str8.equals("Value"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        java.lang.String str5 = day4.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day4.next();
        int int7 = day4.getMonth();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (double) 100);
        java.lang.Object obj10 = timeSeries1.clone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = timeSeries1.getNextTimePeriod();
        java.util.List list12 = timeSeries1.getItems();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "31-December-2019" + "'", str5.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(list12);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        java.lang.Object obj8 = timeSeries1.clone();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        long long12 = day11.getSerialIndex();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day11);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries1.createCopy(0, 6);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        long long18 = month17.getLastMillisecond();
        org.jfree.data.time.Year year19 = month17.getYear();
        java.lang.Number number20 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month17, number20);
        timeSeries1.add(timeSeriesDataItem21);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43830L + "'", long12 == 43830L);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1561964399999L + "'", long18 == 1561964399999L);
        org.junit.Assert.assertNotNull(year19);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.removeChangeListener(seriesChangeListener6);
        java.lang.Comparable comparable8 = timeSeries1.getKey();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        java.util.Date date12 = year11.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        java.lang.String str14 = day13.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day13.next();
        int int16 = day13.getMonth();
        timeSeries10.add((org.jfree.data.time.RegularTimePeriod) day13, (double) 100);
        long long19 = day13.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) day13);
        int int21 = day13.getDayOfMonth();
        long long22 = day13.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 'a' + "'", comparable8.equals('a'));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "31-December-2019" + "'", str14.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 12 + "'", int16 == 12);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1577865599999L + "'", long19 == 1577865599999L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 31 + "'", int21 == 31);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1577779200000L + "'", long22 == 1577779200000L);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
        int int5 = day2.getMonth();
        java.lang.String str6 = day2.toString();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day2, "", "org.jfree.data.event.SeriesChangeEvent[source=1]");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day2, (java.lang.Number) (-1L));
        java.lang.Class<?> wildcardClass12 = timeSeriesDataItem11.getClass();
        java.lang.Number number13 = timeSeriesDataItem11.getValue();
        java.lang.Object obj14 = timeSeriesDataItem11.clone();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        timeSeries16.add((org.jfree.data.time.RegularTimePeriod) month17, (java.lang.Number) (byte) 10, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener21 = null;
        timeSeries16.removeChangeListener(seriesChangeListener21);
        java.lang.Comparable comparable23 = timeSeries16.getKey();
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        java.util.Date date27 = year26.getEnd();
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date27);
        java.lang.String str29 = day28.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = day28.next();
        int int31 = day28.getMonth();
        timeSeries25.add((org.jfree.data.time.RegularTimePeriod) day28, (double) 100);
        long long34 = day28.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries16.getDataItem((org.jfree.data.time.RegularTimePeriod) day28);
        int int36 = day28.getDayOfMonth();
        java.lang.String str37 = day28.toString();
        java.util.Date date38 = day28.getEnd();
        int int39 = timeSeriesDataItem11.compareTo((java.lang.Object) day28);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "31-December-2019" + "'", str6.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + (-1L) + "'", number13.equals((-1L)));
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertTrue("'" + comparable23 + "' != '" + 'a' + "'", comparable23.equals('a'));
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "31-December-2019" + "'", str29.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 12 + "'", int31 == 12);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1577865599999L + "'", long34 == 1577865599999L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 31 + "'", int36 == 31);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "31-December-2019" + "'", str37.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Date date2 = fixedMillisecond1.getTime();
        long long3 = fixedMillisecond1.getFirstMillisecond();
        java.util.Date date4 = fixedMillisecond1.getTime();
        java.lang.Object obj5 = null;
        int int6 = fixedMillisecond1.compareTo(obj5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        java.util.Date date8 = year7.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.lang.String str10 = day9.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day9.next();
        boolean boolean12 = fixedMillisecond1.equals((java.lang.Object) regularTimePeriod11);
        long long13 = fixedMillisecond1.getSerialIndex();
        java.util.Date date14 = fixedMillisecond1.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond1.previous();
        long long16 = fixedMillisecond1.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 100L + "'", long13 == 100L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 100L + "'", long16 == 100L);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year1.previous();
        java.util.Calendar calendar4 = null;
        try {
            year1.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        java.util.Locale locale2 = null;
        try {
            org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date0, timeZone1, locale2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        org.jfree.data.time.SerialDate serialDate7 = day4.getSerialDate();
        int int8 = day4.getDayOfMonth();
        java.lang.String str9 = day4.toString();
        long long10 = day4.getLastMillisecond();
        java.lang.String str11 = day4.toString();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 31 + "'", int8 == 31);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "31-December-2019" + "'", str9.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "31-December-2019" + "'", str11.equals("31-December-2019"));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
    }

//    @Test
//    public void test350() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test350");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
//        timeSeries1.setNotify(false);
//        double double8 = timeSeries1.getMinY();
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        timeSeries10.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) (byte) 10, false);
//        timeSeries10.setNotify(false);
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
//        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
//        timeSeries18.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) (byte) 10, false);
//        timeSeries18.setNotify(false);
//        java.util.Collection collection25 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries18);
//        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries18.getDataItem((org.jfree.data.time.RegularTimePeriod) year26);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener28 = null;
//        timeSeries18.addChangeListener(seriesChangeListener28);
//        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
//        java.util.Date date31 = year30.getEnd();
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date31);
//        java.lang.String str33 = day32.toString();
//        long long34 = day32.getFirstMillisecond();
//        int int35 = day32.getYear();
//        timeSeries18.setKey((java.lang.Comparable) day32);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = day32.previous();
//        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day32);
//        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year((int) '#');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = year40.next();
//        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
//        java.util.Date date43 = year42.getEnd();
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date43);
//        long long45 = day44.getLastMillisecond();
//        int int46 = year40.compareTo((java.lang.Object) day44);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar48 = null;
//        long long49 = fixedMillisecond47.getFirstMillisecond(calendar48);
//        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
//        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year();
//        java.util.Date date53 = year52.getEnd();
//        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(date53);
//        java.lang.String str55 = day54.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = day54.next();
//        int int57 = day54.getMonth();
//        timeSeries51.add((org.jfree.data.time.RegularTimePeriod) day54, (double) 100);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener60 = null;
//        timeSeries51.addChangeListener(seriesChangeListener60);
//        java.lang.Object obj62 = timeSeries51.clone();
//        boolean boolean63 = fixedMillisecond47.equals((java.lang.Object) timeSeries51);
//        int int64 = day44.compareTo((java.lang.Object) fixedMillisecond47);
//        int int65 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 10.0d + "'", double8 == 10.0d);
//        org.junit.Assert.assertNotNull(collection25);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem27);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "31-December-2019" + "'", str33.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1577779200000L + "'", long34 == 1577779200000L);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2019 + "'", int35 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1577865599999L + "'", long45 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1560185169553L + "'", long49 == 1560185169553L);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "31-December-2019" + "'", str55.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod56);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 12 + "'", int57 == 12);
//        org.junit.Assert.assertNotNull(obj62);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-1) + "'", int65 == (-1));
//    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Date date2 = fixedMillisecond1.getTime();
        long long3 = fixedMillisecond1.getFirstMillisecond();
        java.util.Date date4 = fixedMillisecond1.getTime();
        long long5 = fixedMillisecond1.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond1.previous();
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond1.getFirstMillisecond(calendar7);
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond1.getLastMillisecond(calendar9);
        long long11 = fixedMillisecond1.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 100L + "'", long5 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) (byte) 10, false);
        timeSeries9.setNotify(false);
        java.util.Collection collection16 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries9);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) year17);
        timeSeriesDataItem18.setValue((java.lang.Number) (byte) 1);
        boolean boolean22 = timeSeriesDataItem18.equals((java.lang.Object) (-1.0f));
        boolean boolean23 = timeSeriesDataItem18.isSelected();
        java.lang.Object obj24 = timeSeriesDataItem18.clone();
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertNotNull(timeSeriesDataItem18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(obj24);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        java.lang.String str6 = month2.toString();
        int int7 = month2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month2.next();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        int int13 = year1.compareTo((java.lang.Object) timePeriodFormatException3);
        java.util.Calendar calendar14 = null;
        try {
            year1.peg(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        java.lang.String str3 = year1.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year1.next();
        java.lang.String str5 = year1.toString();
        java.lang.Class<?> wildcardClass6 = year1.getClass();
        int int8 = year1.compareTo((java.lang.Object) 1560185136721L);
        java.util.Calendar calendar9 = null;
        try {
            long long10 = year1.getLastMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "35" + "'", str3.equals("35"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "35" + "'", str5.equals("35"));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        int int6 = month2.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month2.next();
        long long8 = regularTimePeriod7.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1563303599999L + "'", long8 == 1563303599999L);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        java.lang.Object obj8 = timeSeries1.clone();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        long long12 = day11.getSerialIndex();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day11);
        java.lang.Object obj14 = timeSeries1.clone();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        java.util.Date date17 = year16.getEnd();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 1, year16);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) year16);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year16);
        try {
            timeSeries20.delete(1, (int) (byte) 0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43830L + "'", long12 == 43830L);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(date17);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "2019", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        timeSeries3.setDomainDescription("");
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeries3.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        timeSeries1.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) (byte) 10, false);
        timeSeries5.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        timeSeries13.add((org.jfree.data.time.RegularTimePeriod) month14, (java.lang.Number) (byte) 10, false);
        timeSeries13.setNotify(false);
        java.util.Collection collection20 = timeSeries5.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) year21);
        timeSeries1.add(timeSeriesDataItem22, false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = timeSeries1.getNextTimePeriod();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
        timeSeries27.add((org.jfree.data.time.RegularTimePeriod) month28, (java.lang.Number) (byte) 10, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener32 = null;
        timeSeries27.removeChangeListener(seriesChangeListener32);
        timeSeries27.setDomainDescription("31-December-2019");
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month();
        timeSeries37.add((org.jfree.data.time.RegularTimePeriod) month38, (java.lang.Number) (byte) 10, false);
        timeSeries37.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month();
        timeSeries45.add((org.jfree.data.time.RegularTimePeriod) month46, (java.lang.Number) (byte) 10, false);
        timeSeries45.setNotify(false);
        java.util.Collection collection52 = timeSeries37.getTimePeriodsUniqueToOtherSeries(timeSeries45);
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = timeSeries45.getDataItem((org.jfree.data.time.RegularTimePeriod) year53);
        timeSeriesDataItem54.setValue((java.lang.Number) (byte) 1);
        boolean boolean58 = timeSeriesDataItem54.equals((java.lang.Object) (-1.0f));
        boolean boolean59 = timeSeries27.equals((java.lang.Object) (-1.0f));
        boolean boolean60 = timeSeries1.equals((java.lang.Object) (-1.0f));
        double double61 = timeSeries1.getMaxY();
        org.junit.Assert.assertNotNull(collection20);
        org.junit.Assert.assertNotNull(timeSeriesDataItem22);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(collection52);
        org.junit.Assert.assertNotNull(timeSeriesDataItem54);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 10.0d + "'", double61 == 10.0d);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        java.lang.Object obj8 = null;
        boolean boolean9 = timeSeries1.equals(obj8);
        boolean boolean10 = timeSeries1.isEmpty();
        try {
            timeSeries1.update(5, (java.lang.Number) 9223372036854775807L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setNotify(false);
        timeSeries1.fireSeriesChanged();
        double double9 = timeSeries1.getMaxY();
        java.lang.String str10 = timeSeries1.getDomainDescription();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 10.0d + "'", double9 == 10.0d);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Time" + "'", str10.equals("Time"));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Date date2 = fixedMillisecond1.getTime();
        java.util.Date date3 = fixedMillisecond1.getTime();
        long long4 = fixedMillisecond1.getSerialIndex();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        boolean boolean3 = year1.equals((java.lang.Object) "31-December-2019");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year1.previous();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (short) 1, year1);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException5.getSuppressed();
        boolean boolean10 = month3.equals((java.lang.Object) throwableArray9);
        int int11 = month3.getMonth();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month3, "org.jfree.data.time.TimePeriodFormatException: hi!", "35");
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        java.lang.Object obj8 = timeSeries1.clone();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        long long12 = day11.getSerialIndex();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day11);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries1.createCopy(0, 6);
        int int17 = timeSeries16.getMaximumItemCount();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = null;
        try {
            timeSeries16.delete(regularTimePeriod18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43830L + "'", long12 == 43830L);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        java.util.List list8 = timeSeries1.getItems();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener9);
        double double11 = timeSeries1.getMinY();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        timeSeries1.setDescription("");
        double double9 = timeSeries1.getMaxY();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo10 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) double9, seriesChangeInfo10);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) 0.0f);
        int int11 = day7.compareTo((java.lang.Object) (short) 0);
        boolean boolean12 = fixedMillisecond1.equals((java.lang.Object) (short) 0);
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond1.getFirstMillisecond(calendar13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond1.next();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 100L + "'", long14 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.removeChangeListener(seriesChangeListener6);
        timeSeries1.setDomainDescription("31-December-2019");
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        timeSeries11.add((org.jfree.data.time.RegularTimePeriod) month12, (java.lang.Number) (byte) 10, false);
        timeSeries11.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        timeSeries19.add((org.jfree.data.time.RegularTimePeriod) month20, (java.lang.Number) (byte) 10, false);
        timeSeries19.setNotify(false);
        java.util.Collection collection26 = timeSeries11.getTimePeriodsUniqueToOtherSeries(timeSeries19);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries19.getDataItem((org.jfree.data.time.RegularTimePeriod) year27);
        timeSeriesDataItem28.setValue((java.lang.Number) (byte) 1);
        boolean boolean32 = timeSeriesDataItem28.equals((java.lang.Object) (-1.0f));
        boolean boolean33 = timeSeries1.equals((java.lang.Object) (-1.0f));
        timeSeries1.removeAgedItems(false);
        timeSeries1.removeAgedItems((long) 'a', true);
        java.lang.Comparable comparable39 = null;
        try {
            timeSeries1.setKey(comparable39);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(collection26);
        org.junit.Assert.assertNotNull(timeSeriesDataItem28);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setNotify(false);
        timeSeries1.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener9);
        try {
            timeSeries1.update(2147483647, (java.lang.Number) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2147483647, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) 0.0f);
        int int11 = day7.compareTo((java.lang.Object) (short) 0);
        boolean boolean12 = fixedMillisecond1.equals((java.lang.Object) (short) 0);
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond1.getMiddleMillisecond(calendar13);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 100L + "'", long14 == 100L);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        int int8 = timeSeries1.getItemCount();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Date date13 = fixedMillisecond12.getTime();
        long long14 = fixedMillisecond12.getFirstMillisecond();
        java.util.Date date15 = fixedMillisecond12.getTime();
        java.lang.Object obj16 = null;
        int int17 = fixedMillisecond12.compareTo(obj16);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.util.Date date21 = year20.getEnd();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date21);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries19.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day22, (java.lang.Number) 0.0f);
        int int26 = day22.compareTo((java.lang.Object) (short) 0);
        int int27 = fixedMillisecond12.compareTo((java.lang.Object) int26);
        long long28 = fixedMillisecond12.getSerialIndex();
        java.lang.String str29 = fixedMillisecond12.toString();
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month();
        timeSeries31.add((org.jfree.data.time.RegularTimePeriod) month32, (java.lang.Number) (byte) 10, false);
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        java.util.Date date39 = year38.getEnd();
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date39);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day40, (java.lang.Number) 0.0f);
        boolean boolean43 = timeSeries37.getNotify();
        java.lang.Object obj44 = timeSeries37.clone();
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month();
        timeSeries46.add((org.jfree.data.time.RegularTimePeriod) month47, (java.lang.Number) (byte) 10, false);
        timeSeries46.setNotify(false);
        java.util.Collection collection53 = timeSeries37.getTimePeriodsUniqueToOtherSeries(timeSeries46);
        int int54 = month32.compareTo((java.lang.Object) timeSeries37);
        int int55 = month32.getMonth();
        org.jfree.data.time.TimeSeries timeSeries56 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (org.jfree.data.time.RegularTimePeriod) month32);
        double double57 = timeSeries1.getMinY();
        org.jfree.data.time.TimeSeries timeSeries59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month60 = new org.jfree.data.time.Month();
        timeSeries59.add((org.jfree.data.time.RegularTimePeriod) month60, (java.lang.Number) (byte) 10, false);
        timeSeries59.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries67 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month68 = new org.jfree.data.time.Month();
        timeSeries67.add((org.jfree.data.time.RegularTimePeriod) month68, (java.lang.Number) (byte) 10, false);
        timeSeries67.setNotify(false);
        java.util.Collection collection74 = timeSeries59.getTimePeriodsUniqueToOtherSeries(timeSeries67);
        org.jfree.data.time.Year year75 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem76 = timeSeries67.getDataItem((org.jfree.data.time.RegularTimePeriod) year75);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = year75.previous();
        long long78 = year75.getFirstMillisecond();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo79 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent80 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year75, seriesChangeInfo79);
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year75, (double) (-61125897600001L));
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 100L + "'", long14 == 100L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 100L + "'", long28 == 100L);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str29.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNull(timeSeriesDataItem42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(obj44);
        org.junit.Assert.assertNotNull(collection53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 6 + "'", int55 == 6);
        org.junit.Assert.assertNotNull(timeSeries56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertNotNull(collection74);
        org.junit.Assert.assertNotNull(timeSeriesDataItem76);
        org.junit.Assert.assertNotNull(regularTimePeriod77);
        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 1546329600000L + "'", long78 == 1546329600000L);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Date date2 = fixedMillisecond1.getTime();
        long long3 = fixedMillisecond1.getFirstMillisecond();
        java.util.Date date4 = fixedMillisecond1.getTime();
        long long5 = fixedMillisecond1.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond1.previous();
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond1.getFirstMillisecond(calendar7);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        java.util.Date date12 = year11.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (java.lang.Number) 0.0f);
        org.jfree.data.time.SerialDate serialDate16 = day13.getSerialDate();
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(serialDate16);
        boolean boolean18 = fixedMillisecond1.equals((java.lang.Object) day17);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 100L + "'", long5 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("June 2019");
        org.junit.Assert.assertNotNull(month1);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        long long7 = day4.getFirstMillisecond();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = day4.getFirstMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577779200000L + "'", long7 == 1577779200000L);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        java.lang.String str6 = month2.toString();
        int int7 = month2.getYearValue();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = month2.getFirstMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setRangeDescription("hi!");
        timeSeries1.removeAgedItems(false);
    }

//    @Test
//    public void test378() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test378");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "2019", "");
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
//        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) (byte) 10, false);
//        timeSeries5.setNotify(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar13 = null;
//        long long14 = fixedMillisecond12.getFirstMillisecond(calendar13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries5.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
//        timeSeries3.add(timeSeriesDataItem15, true);
//        java.lang.String str18 = timeSeries3.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        timeSeries20.add((org.jfree.data.time.RegularTimePeriod) month21, (java.lang.Number) (byte) 10, false);
//        timeSeries20.setNotify(false);
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
//        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month();
//        timeSeries28.add((org.jfree.data.time.RegularTimePeriod) month29, (java.lang.Number) (byte) 10, false);
//        timeSeries28.setNotify(false);
//        java.util.Collection collection35 = timeSeries20.getTimePeriodsUniqueToOtherSeries(timeSeries28);
//        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries28.getDataItem((org.jfree.data.time.RegularTimePeriod) year36);
//        timeSeriesDataItem37.setValue((java.lang.Number) (byte) 1);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo41 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent42 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (short) 1, seriesChangeInfo41);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo43 = seriesChangeEvent42.getSummary();
//        int int44 = timeSeriesDataItem37.compareTo((java.lang.Object) seriesChangeInfo43);
//        timeSeriesDataItem37.setValue((java.lang.Number) 1.0d);
//        try {
//            timeSeries3.add(timeSeriesDataItem37, true);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period June 2019 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560185173237L + "'", long14 == 1560185173237L);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem15);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "2019" + "'", str18.equals("2019"));
//        org.junit.Assert.assertNotNull(collection35);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem37);
//        org.junit.Assert.assertNull(seriesChangeInfo43);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
//    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (short) 1, seriesChangeInfo1);
        java.lang.String str3 = seriesChangeEvent2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=1]" + "'", str3.equals("org.jfree.data.event.SeriesChangeEvent[source=1]"));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        timeSeries1.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond10.previous();
        long long12 = fixedMillisecond10.getMiddleMillisecond();
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond10.getFirstMillisecond(calendar13);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (double) 5);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 100L + "'", long12 == 100L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 100L + "'", long14 == 100L);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        java.lang.String str5 = day4.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day4.next();
        int int7 = day4.getMonth();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (double) 100);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        boolean boolean13 = year10.equals((java.lang.Object) (-1.0d));
        int int15 = year10.compareTo((java.lang.Object) 1.0d);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        java.util.Date date17 = year16.getEnd();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date17);
        java.lang.String str19 = day18.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day18.next();
        int int21 = day18.getMonth();
        java.lang.String str22 = day18.toString();
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year10, (org.jfree.data.time.RegularTimePeriod) day18);
        int int24 = year10.getYear();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year10, "org.jfree.data.event.SeriesChangeEvent[source=class org.jfree.data.time.Year]", "35");
        java.util.Collection collection28 = timeSeries27.getTimePeriods();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "31-December-2019" + "'", str5.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "31-December-2019" + "'", str19.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 12 + "'", int21 == 12);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "31-December-2019" + "'", str22.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
        org.junit.Assert.assertNotNull(collection28);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Date date2 = fixedMillisecond1.getTime();
        long long3 = fixedMillisecond1.getFirstMillisecond();
        java.util.Date date4 = fixedMillisecond1.getTime();
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getFirstMillisecond(calendar5);
        long long7 = fixedMillisecond1.getSerialIndex();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Date date2 = fixedMillisecond1.getTime();
        java.util.Date date3 = fixedMillisecond1.getTime();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        java.util.TimeZone timeZone5 = null;
        try {
            org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date3, timeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        timeSeries1.setMaximumItemCount(2);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        java.util.Date date13 = year12.getEnd();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day14, (java.lang.Number) 0.0f);
        boolean boolean17 = timeSeries11.getNotify();
        java.lang.Object obj18 = timeSeries11.clone();
        timeSeries11.setNotify(false);
        timeSeries11.delete(0, 0, true);
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Date date27 = fixedMillisecond26.getTime();
        int int28 = timeSeries11.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, (java.lang.Number) 1549007999999L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1, "", "hi!");
        timeSeries3.clear();
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (short) 1, year1);
        java.util.Calendar calendar4 = null;
        try {
            long long5 = month3.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        java.util.TimeZone timeZone4 = null;
        try {
            org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date2, timeZone4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        timeSeries1.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) (byte) 10, false);
        timeSeries5.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        timeSeries13.add((org.jfree.data.time.RegularTimePeriod) month14, (java.lang.Number) (byte) 10, false);
        timeSeries13.setNotify(false);
        java.util.Collection collection20 = timeSeries5.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) year21);
        timeSeries1.add(timeSeriesDataItem22, false);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        java.util.Date date27 = year26.getEnd();
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month((int) (short) 1, year26);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException30 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException32 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException30.addSuppressed((java.lang.Throwable) timePeriodFormatException32);
        java.lang.Throwable[] throwableArray34 = timePeriodFormatException30.getSuppressed();
        boolean boolean35 = month28.equals((java.lang.Object) throwableArray34);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month28, (double) 10, true);
        java.lang.Class class39 = timeSeries1.getTimePeriodClass();
        org.junit.Assert.assertNotNull(collection20);
        org.junit.Assert.assertNotNull(timeSeriesDataItem22);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(throwableArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(class39);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        java.lang.Object obj8 = timeSeries1.clone();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        timeSeries10.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) (byte) 10, false);
        timeSeries10.setNotify(false);
        java.util.Collection collection17 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries10);
        timeSeries1.setDomainDescription("");
        java.util.Collection collection20 = timeSeries1.getTimePeriods();
        long long21 = timeSeries1.getMaximumItemAge();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        java.util.Date date23 = year22.getEnd();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date23);
        java.lang.String str25 = day24.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = day24.next();
        int int27 = day24.getMonth();
        java.lang.String str28 = day24.toString();
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day24, "", "org.jfree.data.event.SeriesChangeEvent[source=1]");
        org.jfree.data.time.SerialDate serialDate32 = day24.getSerialDate();
        java.lang.String str33 = day24.toString();
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) day24, (java.lang.Number) 31);
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month();
        long long37 = month36.getLastMillisecond();
        org.jfree.data.time.Year year38 = month36.getYear();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month36, (java.lang.Number) (-1.0d));
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertNotNull(collection20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 9223372036854775807L + "'", long21 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "31-December-2019" + "'", str25.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 12 + "'", int27 == 12);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "31-December-2019" + "'", str28.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "31-December-2019" + "'", str33.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1561964399999L + "'", long37 == 1561964399999L);
        org.junit.Assert.assertNotNull(year38);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        int int8 = timeSeries1.getItemCount();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Date date13 = fixedMillisecond12.getTime();
        long long14 = fixedMillisecond12.getFirstMillisecond();
        java.util.Date date15 = fixedMillisecond12.getTime();
        java.lang.Object obj16 = null;
        int int17 = fixedMillisecond12.compareTo(obj16);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.util.Date date21 = year20.getEnd();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date21);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries19.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day22, (java.lang.Number) 0.0f);
        int int26 = day22.compareTo((java.lang.Object) (short) 0);
        int int27 = fixedMillisecond12.compareTo((java.lang.Object) int26);
        long long28 = fixedMillisecond12.getSerialIndex();
        java.lang.String str29 = fixedMillisecond12.toString();
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month();
        timeSeries31.add((org.jfree.data.time.RegularTimePeriod) month32, (java.lang.Number) (byte) 10, false);
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        java.util.Date date39 = year38.getEnd();
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date39);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day40, (java.lang.Number) 0.0f);
        boolean boolean43 = timeSeries37.getNotify();
        java.lang.Object obj44 = timeSeries37.clone();
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month();
        timeSeries46.add((org.jfree.data.time.RegularTimePeriod) month47, (java.lang.Number) (byte) 10, false);
        timeSeries46.setNotify(false);
        java.util.Collection collection53 = timeSeries37.getTimePeriodsUniqueToOtherSeries(timeSeries46);
        int int54 = month32.compareTo((java.lang.Object) timeSeries37);
        int int55 = month32.getMonth();
        org.jfree.data.time.TimeSeries timeSeries56 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (org.jfree.data.time.RegularTimePeriod) month32);
        timeSeries56.removeAgedItems((long) 9, false);
        org.jfree.data.time.Year year60 = new org.jfree.data.time.Year();
        java.util.Date date61 = year60.getEnd();
        boolean boolean63 = year60.equals((java.lang.Object) (-1.0d));
        int int65 = year60.compareTo((java.lang.Object) 1.0d);
        java.lang.Number number66 = timeSeries56.getValue((org.jfree.data.time.RegularTimePeriod) year60);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 100L + "'", long14 == 100L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 100L + "'", long28 == 100L);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str29.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNull(timeSeriesDataItem42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(obj44);
        org.junit.Assert.assertNotNull(collection53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 6 + "'", int55 == 6);
        org.junit.Assert.assertNotNull(timeSeries56);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1 + "'", int65 == 1);
        org.junit.Assert.assertTrue("'" + number66 + "' != '" + 0.0f + "'", number66.equals(0.0f));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) (byte) 10, false);
        timeSeries9.setNotify(false);
        java.util.Collection collection16 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries9);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) year17);
        timeSeriesDataItem18.setValue((java.lang.Number) 1559372400000L);
        java.lang.Object obj21 = timeSeriesDataItem18.clone();
        boolean boolean22 = timeSeriesDataItem18.isSelected();
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertNotNull(timeSeriesDataItem18);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
        java.util.Date date5 = regularTimePeriod4.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date5);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date5);
        timeSeries7.setDomainDescription("July 2019");
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.Year year9 = org.jfree.data.time.Year.parseYear("2019");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) year9);
        java.lang.Number number11 = timeSeriesDataItem10.getValue();
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (byte) 10 + "'", number11.equals((byte) 10));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.event.SeriesChangeEvent[source=1]");
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("31-December-2019");
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
        java.util.TimeZone timeZone4 = null;
        java.util.Locale locale5 = null;
        try {
            org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date1, timeZone4, locale5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
        java.util.Date date5 = regularTimePeriod4.getStart();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date5);
        java.lang.String str7 = timeSeries6.getDescription();
        java.lang.String str8 = timeSeries6.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        java.util.Date date12 = year11.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (java.lang.Number) 0.0f);
        boolean boolean16 = timeSeries10.getNotify();
        java.lang.Object obj17 = timeSeries10.clone();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        java.util.Date date19 = year18.getEnd();
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date19);
        long long21 = day20.getSerialIndex();
        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) day20);
        java.lang.Object obj23 = timeSeries10.clone();
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries6.addAndOrUpdate(timeSeries10);
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        timeSeries26.add((org.jfree.data.time.RegularTimePeriod) month27, (java.lang.Number) (byte) 10, false);
        timeSeries26.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month();
        timeSeries34.add((org.jfree.data.time.RegularTimePeriod) month35, (java.lang.Number) (byte) 10, false);
        timeSeries34.setNotify(false);
        java.util.Collection collection41 = timeSeries26.getTimePeriodsUniqueToOtherSeries(timeSeries34);
        boolean boolean42 = timeSeries26.getNotify();
        timeSeries26.removeAgedItems((long) 'a', true);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = timeSeries26.getNextTimePeriod();
        java.lang.String str47 = regularTimePeriod46.toString();
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year();
        java.util.Date date49 = year48.getEnd();
        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(date49);
        java.lang.String str51 = day50.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = day50.next();
        int int53 = day50.getMonth();
        java.lang.String str54 = day50.toString();
        org.jfree.data.time.TimeSeries timeSeries57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day50, "", "org.jfree.data.event.SeriesChangeEvent[source=1]");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day50, (java.lang.Number) (-1L));
        org.jfree.data.time.TimeSeries timeSeries60 = timeSeries6.createCopy(regularTimePeriod46, (org.jfree.data.time.RegularTimePeriod) day50);
        timeSeries60.removeAgedItems(true);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Value" + "'", str8.equals("Value"));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 43830L + "'", long21 == 43830L);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertNotNull(timeSeries24);
        org.junit.Assert.assertNotNull(collection41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "July 2019" + "'", str47.equals("July 2019"));
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "31-December-2019" + "'", str51.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 12 + "'", int53 == 12);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "31-December-2019" + "'", str54.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(timeSeries60);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
        java.util.Date date5 = regularTimePeriod4.getStart();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod4);
        int int7 = timeSeries6.getItemCount();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) (byte) 10, false);
        timeSeries9.setNotify(false);
        java.util.Collection collection16 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries9);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) year17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year17.previous();
        long long20 = year17.getSerialIndex();
        long long21 = year17.getSerialIndex();
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertNotNull(timeSeriesDataItem18);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2019L + "'", long20 == 2019L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 2019L + "'", long21 == 2019L);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.util.Date date4 = year3.getEnd();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        long long6 = day5.getLastMillisecond();
        int int7 = year1.compareTo((java.lang.Object) day5);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date9);
        java.lang.String str11 = day10.toString();
        int int12 = day10.getYear();
        boolean boolean13 = day5.equals((java.lang.Object) day10);
        java.util.Date date14 = day5.getStart();
        java.util.Calendar calendar15 = null;
        try {
            long long16 = day5.getLastMillisecond(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "31-December-2019" + "'", str11.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(date14);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        timeSeries2.add((org.jfree.data.time.RegularTimePeriod) month3, (java.lang.Number) (byte) 10, false);
        timeSeries2.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        timeSeries10.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) (byte) 10, false);
        timeSeries10.setNotify(false);
        java.util.Collection collection17 = timeSeries2.getTimePeriodsUniqueToOtherSeries(timeSeries10);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries10.getDataItem((org.jfree.data.time.RegularTimePeriod) year18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year18.previous();
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(6, year18);
        int int22 = month21.getMonth();
        int int23 = month21.getYearValue();
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertNotNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
        int int5 = day2.getMonth();
        java.lang.String str6 = day2.toString();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day2, "", "org.jfree.data.event.SeriesChangeEvent[source=1]");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day2, (java.lang.Number) (-1L));
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        java.util.Date date13 = year12.getEnd();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        java.lang.String str15 = day14.toString();
        long long16 = day14.getLastMillisecond();
        int int17 = timeSeriesDataItem11.compareTo((java.lang.Object) long16);
        timeSeriesDataItem11.setSelected(false);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "31-December-2019" + "'", str6.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "31-December-2019" + "'", str15.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1577865599999L + "'", long16 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        java.lang.Object obj8 = timeSeries1.clone();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        long long12 = day11.getSerialIndex();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day11);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries1.createCopy(0, 6);
        int int17 = timeSeries16.getMaximumItemCount();
        boolean boolean18 = timeSeries16.isEmpty();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43830L + "'", long12 == 43830L);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Date date2 = fixedMillisecond1.getTime();
        long long3 = fixedMillisecond1.getFirstMillisecond();
        java.util.Date date4 = fixedMillisecond1.getTime();
        java.lang.Object obj5 = null;
        int int6 = fixedMillisecond1.compareTo(obj5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        java.util.Date date8 = year7.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.lang.String str10 = day9.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day9.next();
        boolean boolean12 = fixedMillisecond1.equals((java.lang.Object) regularTimePeriod11);
        long long13 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond1.getLastMillisecond(calendar14);
        long long16 = fixedMillisecond1.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 100L + "'", long13 == 100L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 100L + "'", long15 == 100L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 100L + "'", long16 == 100L);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        java.lang.Object obj8 = timeSeries1.clone();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        timeSeries10.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) (byte) 10, false);
        timeSeries10.setNotify(false);
        java.util.Collection collection17 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries10);
        timeSeries1.setDomainDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Date date22 = fixedMillisecond21.getTime();
        java.util.Date date23 = fixedMillisecond21.getTime();
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, (double) 1560185142033L, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(date23);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Date date2 = fixedMillisecond1.getTime();
        long long3 = fixedMillisecond1.getFirstMillisecond();
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("July 2019");
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (short) 1, year1);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException5.getSuppressed();
        boolean boolean10 = month3.equals((java.lang.Object) throwableArray9);
        int int11 = month3.getMonth();
        org.jfree.data.time.Year year12 = month3.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month3.next();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(year12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Date date2 = fixedMillisecond1.getTime();
        long long3 = fixedMillisecond1.getFirstMillisecond();
        java.util.Date date4 = fixedMillisecond1.getTime();
        java.lang.Object obj5 = null;
        int int6 = fixedMillisecond1.compareTo(obj5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        java.util.Date date8 = year7.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.lang.String str10 = day9.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day9.next();
        boolean boolean12 = fixedMillisecond1.equals((java.lang.Object) regularTimePeriod11);
        long long13 = fixedMillisecond1.getSerialIndex();
        long long14 = fixedMillisecond1.getSerialIndex();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 100L + "'", long13 == 100L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 100L + "'", long14 == 100L);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) (byte) 10, false);
        timeSeries9.setNotify(false);
        java.util.Collection collection16 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries9);
        boolean boolean17 = timeSeries9.getNotify();
        timeSeries9.removeAgedItems(true);
        timeSeries9.removeAgedItems(false);
        java.lang.String str22 = timeSeries9.getDomainDescription();
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Time" + "'", str22.equals("Time"));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date1);
        int int5 = day4.getDayOfMonth();
        java.util.Date date6 = day4.getEnd();
        java.util.TimeZone timeZone7 = null;
        java.util.Locale locale8 = null;
        try {
            org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date6, timeZone7, locale8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 31 + "'", int5 == 31);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        boolean boolean3 = year1.equals((java.lang.Object) 2);
        long long4 = year1.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61157520000000L) + "'", long4 == (-61157520000000L));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setRangeDescription("hi!");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeries1.getNextTimePeriod();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        timeSeries10.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) (byte) 10, false);
        timeSeries10.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
        timeSeries18.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) (byte) 10, false);
        timeSeries18.setNotify(false);
        java.util.Collection collection25 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries18.getDataItem((org.jfree.data.time.RegularTimePeriod) year26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries1.addOrUpdate(timeSeriesDataItem27);
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        java.util.Date date30 = year29.getEnd();
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date30);
        java.lang.String str32 = day31.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = day31.next();
        java.util.Date date34 = regularTimePeriod33.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond(date34);
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month(date34);
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date34);
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) day37, (java.lang.Number) (short) 10);
        try {
            timeSeries1.delete((int) (byte) 10, 3, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(collection25);
        org.junit.Assert.assertNotNull(timeSeriesDataItem27);
        org.junit.Assert.assertNotNull(timeSeriesDataItem28);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "31-December-2019" + "'", str32.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(date34);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        org.jfree.data.time.Year year2 = month0.getYear();
        java.lang.Number number3 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, number3);
        java.lang.Number number5 = null;
        timeSeriesDataItem4.setValue(number5);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertNotNull(year2);
    }

//    @Test
//    public void test415() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test415");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
//        java.util.Date date6 = year5.getEnd();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
//        java.lang.String str8 = day7.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day7.next();
//        int int10 = day7.getMonth();
//        timeSeries4.add((org.jfree.data.time.RegularTimePeriod) day7, (double) 100);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
//        timeSeries4.addChangeListener(seriesChangeListener13);
//        java.lang.Object obj15 = timeSeries4.clone();
//        boolean boolean16 = fixedMillisecond0.equals((java.lang.Object) timeSeries4);
//        java.util.Calendar calendar17 = null;
//        long long18 = fixedMillisecond0.getLastMillisecond(calendar17);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560185176569L + "'", long2 == 1560185176569L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "31-December-2019" + "'", str8.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
//        org.junit.Assert.assertNotNull(obj15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560185176569L + "'", long18 == 1560185176569L);
//    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        java.util.List list8 = timeSeries1.getItems();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener9);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        timeSeries12.add((org.jfree.data.time.RegularTimePeriod) month13, (java.lang.Number) (byte) 10, false);
        timeSeries12.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
        timeSeries20.add((org.jfree.data.time.RegularTimePeriod) month21, (java.lang.Number) (byte) 10, false);
        timeSeries20.setNotify(false);
        java.util.Collection collection27 = timeSeries12.getTimePeriodsUniqueToOtherSeries(timeSeries20);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries20.getDataItem((org.jfree.data.time.RegularTimePeriod) year28);
        timeSeriesDataItem29.setValue((java.lang.Number) (byte) 1);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo33 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent34 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (short) 1, seriesChangeInfo33);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo35 = seriesChangeEvent34.getSummary();
        int int36 = timeSeriesDataItem29.compareTo((java.lang.Object) seriesChangeInfo35);
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month();
        timeSeries38.add((org.jfree.data.time.RegularTimePeriod) month39, (java.lang.Number) (byte) 10, false);
        timeSeries38.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month();
        timeSeries46.add((org.jfree.data.time.RegularTimePeriod) month47, (java.lang.Number) (byte) 10, false);
        timeSeries46.setNotify(false);
        java.util.Collection collection53 = timeSeries38.getTimePeriodsUniqueToOtherSeries(timeSeries46);
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem55 = timeSeries46.getDataItem((org.jfree.data.time.RegularTimePeriod) year54);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = year54.previous();
        boolean boolean57 = timeSeriesDataItem29.equals((java.lang.Object) year54);
        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year();
        java.util.Date date59 = year58.getEnd();
        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day(date59);
        java.lang.String str61 = day60.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = day60.next();
        java.util.Date date63 = regularTimePeriod62.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond64 = new org.jfree.data.time.FixedMillisecond(date63);
        org.jfree.data.time.Month month65 = new org.jfree.data.time.Month(date63);
        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day(date63);
        boolean boolean67 = timeSeriesDataItem29.equals((java.lang.Object) day66);
        try {
            timeSeries1.add(timeSeriesDataItem29);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNotNull(collection27);
        org.junit.Assert.assertNotNull(timeSeriesDataItem29);
        org.junit.Assert.assertNull(seriesChangeInfo35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(collection53);
        org.junit.Assert.assertNotNull(timeSeriesDataItem55);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "31-December-2019" + "'", str61.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod62);
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        org.jfree.data.time.SerialDate serialDate7 = day4.getSerialDate();
        int int8 = day4.getDayOfMonth();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = day4.getLastMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 31 + "'", int8 == 31);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        java.lang.String str6 = month2.toString();
        java.util.Calendar calendar7 = null;
        try {
            month2.peg(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date3);
        int int7 = day6.getDayOfMonth();
        boolean boolean8 = month0.equals((java.lang.Object) int7);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 31 + "'", int7 == 31);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        java.lang.Object obj8 = timeSeries1.clone();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        long long12 = day11.getSerialIndex();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day11);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries1.createCopy(0, 6);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        timeSeries19.add((org.jfree.data.time.RegularTimePeriod) month20, (java.lang.Number) (byte) 10, false);
        timeSeries19.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
        timeSeries27.add((org.jfree.data.time.RegularTimePeriod) month28, (java.lang.Number) (byte) 10, false);
        timeSeries27.setNotify(false);
        java.util.Collection collection34 = timeSeries19.getTimePeriodsUniqueToOtherSeries(timeSeries27);
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries27.getDataItem((org.jfree.data.time.RegularTimePeriod) year35);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = year35.previous();
        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month(6, year35);
        java.lang.String str39 = year35.toString();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) year35);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = timeSeries1.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43830L + "'", long12 == 43830L);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(collection34);
        org.junit.Assert.assertNotNull(timeSeriesDataItem36);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "2019" + "'", str39.equals("2019"));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        java.lang.String str7 = day4.toString();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "31-December-2019" + "'", str7.equals("31-December-2019"));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.time.TimePeriodFormatException: hi!");
        java.lang.String str2 = seriesException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException9.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        java.lang.String str15 = seriesException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str2.equals("org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str15.equals("org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        org.jfree.data.general.SeriesException seriesException12 = new org.jfree.data.general.SeriesException("org.jfree.data.time.TimePeriodFormatException: hi!");
        java.lang.String str13 = seriesException12.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException17);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException22 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException20.addSuppressed((java.lang.Throwable) timePeriodFormatException22);
        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException20);
        seriesException12.addSuppressed((java.lang.Throwable) timePeriodFormatException15);
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) seriesException12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str13.equals("org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) (byte) 10, false);
        timeSeries9.setNotify(false);
        java.util.Collection collection16 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries9);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) year17);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries9.addChangeListener(seriesChangeListener19);
        int int21 = timeSeries9.getMaximumItemCount();
        java.lang.String str22 = timeSeries9.getDescription();
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
        timeSeries24.add((org.jfree.data.time.RegularTimePeriod) month25, (java.lang.Number) (byte) 10, false);
        timeSeries24.setNotify(false);
        double double31 = timeSeries24.getMinY();
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
        timeSeries33.add((org.jfree.data.time.RegularTimePeriod) month34, (java.lang.Number) (byte) 10, false);
        timeSeries33.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month();
        timeSeries41.add((org.jfree.data.time.RegularTimePeriod) month42, (java.lang.Number) (byte) 10, false);
        timeSeries41.setNotify(false);
        java.util.Collection collection48 = timeSeries33.getTimePeriodsUniqueToOtherSeries(timeSeries41);
        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = timeSeries41.getDataItem((org.jfree.data.time.RegularTimePeriod) year49);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener51 = null;
        timeSeries41.addChangeListener(seriesChangeListener51);
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year();
        java.util.Date date54 = year53.getEnd();
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day(date54);
        java.lang.String str56 = day55.toString();
        long long57 = day55.getFirstMillisecond();
        int int58 = day55.getYear();
        timeSeries41.setKey((java.lang.Comparable) day55);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = day55.previous();
        timeSeries24.delete((org.jfree.data.time.RegularTimePeriod) day55);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem63 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day55, (java.lang.Number) 100.0d);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Day, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertNotNull(timeSeriesDataItem18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2147483647 + "'", int21 == 2147483647);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 10.0d + "'", double31 == 10.0d);
        org.junit.Assert.assertNotNull(collection48);
        org.junit.Assert.assertNotNull(timeSeriesDataItem50);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "31-December-2019" + "'", str56.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1577779200000L + "'", long57 == 1577779200000L);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 2019 + "'", int58 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod60);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setRangeDescription("hi!");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeries1.getNextTimePeriod();
        timeSeries1.setNotify(true);
        java.lang.String str11 = timeSeries1.getDescription();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.util.Date date15 = year14.getEnd();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
        java.lang.String str17 = day16.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day16.next();
        int int19 = day16.getMonth();
        timeSeries13.add((org.jfree.data.time.RegularTimePeriod) day16, (double) 100);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        java.util.Date date23 = year22.getEnd();
        boolean boolean25 = year22.equals((java.lang.Object) (-1.0d));
        int int27 = year22.compareTo((java.lang.Object) 1.0d);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        java.util.Date date29 = year28.getEnd();
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date29);
        java.lang.String str31 = day30.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = day30.next();
        int int33 = day30.getMonth();
        java.lang.String str34 = day30.toString();
        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries13.createCopy((org.jfree.data.time.RegularTimePeriod) year22, (org.jfree.data.time.RegularTimePeriod) day30);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries13.getDataItem((int) (byte) 0);
        try {
            timeSeries1.add(timeSeriesDataItem37, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Day, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "31-December-2019" + "'", str17.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 12 + "'", int19 == 12);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "31-December-2019" + "'", str31.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 12 + "'", int33 == 12);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "31-December-2019" + "'", str34.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(timeSeries35);
        org.junit.Assert.assertNotNull(timeSeriesDataItem37);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.util.Date date4 = year3.getEnd();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        long long6 = day5.getLastMillisecond();
        int int7 = year1.compareTo((java.lang.Object) day5);
        org.jfree.data.time.Year year9 = org.jfree.data.time.Year.parseYear("2019");
        int int10 = day5.compareTo((java.lang.Object) "2019");
        int int11 = day5.getDayOfMonth();
        long long12 = day5.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 31 + "'", int11 == 31);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        java.lang.Object obj8 = timeSeries1.clone();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        long long12 = day11.getSerialIndex();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day11);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries1.createCopy(0, 6);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        java.util.Date date20 = year19.getEnd();
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day21, (java.lang.Number) 0.0f);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        java.util.Date date25 = year24.getEnd();
        boolean boolean27 = year24.equals((java.lang.Object) (-1.0d));
        int int29 = year24.compareTo((java.lang.Object) 1.0d);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries18.getDataItem((org.jfree.data.time.RegularTimePeriod) year24);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year24, (double) 7);
        java.util.Calendar calendar33 = null;
        try {
            year24.peg(calendar33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43830L + "'", long12 == 43830L);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNull(timeSeriesDataItem23);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(timeSeriesDataItem30);
        org.junit.Assert.assertNull(timeSeriesDataItem32);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date1);
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        java.util.Date date8 = year7.getEnd();
        boolean boolean10 = year7.equals((java.lang.Object) (-1.0d));
        int int12 = year7.compareTo((java.lang.Object) 1.0d);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) year7);
        long long14 = year7.getFirstMillisecond();
        java.util.Calendar calendar15 = null;
        try {
            long long16 = year7.getFirstMillisecond(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (short) 1, year1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod4, 0.0d);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month7);
        boolean boolean9 = timeSeriesDataItem6.equals((java.lang.Object) timeSeries8);
        timeSeriesDataItem6.setValue((java.lang.Number) 1560185130365L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        boolean boolean3 = year0.equals((java.lang.Object) (-1.0d));
        int int5 = year0.compareTo((java.lang.Object) 1.0d);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) 0.0f);
        boolean boolean13 = timeSeries7.getNotify();
        java.lang.Object obj14 = timeSeries7.clone();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        timeSeries16.add((org.jfree.data.time.RegularTimePeriod) month17, (java.lang.Number) (byte) 10, false);
        timeSeries16.setNotify(false);
        java.util.Collection collection23 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries16);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        java.util.Date date27 = year26.getEnd();
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date27);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries25.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day28, (java.lang.Number) 0.0f);
        boolean boolean31 = timeSeries25.getNotify();
        java.lang.Object obj32 = timeSeries25.clone();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        java.util.Date date34 = year33.getEnd();
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date34);
        long long36 = day35.getSerialIndex();
        timeSeries25.delete((org.jfree.data.time.RegularTimePeriod) day35);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) day35);
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
        java.util.Date date40 = year39.getEnd();
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date40);
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year(date40);
        long long43 = year42.getMiddleMillisecond();
        int int44 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) year42);
        int int45 = year0.compareTo((java.lang.Object) year42);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(collection23);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNull(timeSeriesDataItem30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 43830L + "'", long36 == 43830L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem38);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1562097599999L + "'", long43 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Date date2 = fixedMillisecond1.getTime();
        long long3 = fixedMillisecond1.getFirstMillisecond();
        java.util.Date date4 = fixedMillisecond1.getTime();
        java.lang.Object obj5 = null;
        int int6 = fixedMillisecond1.compareTo(obj5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        java.util.Date date8 = year7.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.lang.String str10 = day9.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day9.next();
        boolean boolean12 = fixedMillisecond1.equals((java.lang.Object) regularTimePeriod11);
        long long13 = fixedMillisecond1.getSerialIndex();
        java.util.Date date14 = fixedMillisecond1.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(date14);
        java.util.TimeZone timeZone16 = null;
        try {
            org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date14, timeZone16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 100L + "'", long13 == 100L);
        org.junit.Assert.assertNotNull(date14);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        java.util.List list8 = timeSeries1.getItems();
        timeSeries1.fireSeriesChanged();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        long long13 = day12.getSerialIndex();
        int int14 = day12.getYear();
        java.lang.Number number15 = null;
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day12, number15, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period 31-December-2019 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43830L + "'", long13 == 43830L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        boolean boolean3 = year0.equals((java.lang.Object) (-1.0d));
        int int5 = year0.compareTo((java.lang.Object) 1.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year0.previous();
        long long7 = year0.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        java.lang.String str13 = day12.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day12.next();
        int int15 = day12.getMonth();
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) day12, (double) 100);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        java.util.Date date19 = year18.getEnd();
        boolean boolean21 = year18.equals((java.lang.Object) (-1.0d));
        int int23 = year18.compareTo((java.lang.Object) 1.0d);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        java.util.Date date25 = year24.getEnd();
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date25);
        java.lang.String str27 = day26.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day26.next();
        int int29 = day26.getMonth();
        java.lang.String str30 = day26.toString();
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries9.createCopy((org.jfree.data.time.RegularTimePeriod) year18, (org.jfree.data.time.RegularTimePeriod) day26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries9.getDataItem((int) (byte) 0);
        java.util.Collection collection34 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries9);
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month35);
        int int37 = month35.getMonth();
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month();
        timeSeries39.add((org.jfree.data.time.RegularTimePeriod) month40, (java.lang.Number) (byte) 10, false);
        timeSeries39.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month();
        timeSeries47.add((org.jfree.data.time.RegularTimePeriod) month48, (java.lang.Number) (byte) 10, false);
        timeSeries47.setNotify(false);
        java.util.Collection collection54 = timeSeries39.getTimePeriodsUniqueToOtherSeries(timeSeries47);
        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem56 = timeSeries47.getDataItem((org.jfree.data.time.RegularTimePeriod) year55);
        java.lang.Object obj57 = timeSeriesDataItem56.clone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = timeSeriesDataItem56.getPeriod();
        org.jfree.data.time.TimeSeries timeSeries59 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month35, regularTimePeriod58);
        java.lang.String str60 = timeSeries59.getDomainDescription();
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "31-December-2019" + "'", str13.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 12 + "'", int15 == 12);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "31-December-2019" + "'", str27.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 12 + "'", int29 == 12);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "31-December-2019" + "'", str30.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(timeSeries31);
        org.junit.Assert.assertNotNull(timeSeriesDataItem33);
        org.junit.Assert.assertNotNull(collection34);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 6 + "'", int37 == 6);
        org.junit.Assert.assertNotNull(collection54);
        org.junit.Assert.assertNotNull(timeSeriesDataItem56);
        org.junit.Assert.assertNotNull(obj57);
        org.junit.Assert.assertNotNull(regularTimePeriod58);
        org.junit.Assert.assertNotNull(timeSeries59);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "Time" + "'", str60.equals("Time"));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) (byte) 10, false);
        timeSeries9.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        timeSeries17.add((org.jfree.data.time.RegularTimePeriod) month18, (java.lang.Number) (byte) 10, false);
        timeSeries17.setNotify(false);
        java.util.Collection collection24 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries17);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries17.getDataItem((org.jfree.data.time.RegularTimePeriod) year25);
        java.lang.Object obj27 = timeSeriesDataItem26.clone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = timeSeriesDataItem26.getPeriod();
        try {
            timeSeries1.add(regularTimePeriod28, (java.lang.Number) (-62041132800001L));
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(collection24);
        org.junit.Assert.assertNotNull(timeSeriesDataItem26);
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Date date2 = fixedMillisecond1.getTime();
        long long3 = fixedMillisecond1.getFirstMillisecond();
        java.util.Date date4 = fixedMillisecond1.getTime();
        java.lang.Object obj5 = null;
        int int6 = fixedMillisecond1.compareTo(obj5);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day11, (java.lang.Number) 0.0f);
        int int15 = day11.compareTo((java.lang.Object) (short) 0);
        int int16 = fixedMillisecond1.compareTo((java.lang.Object) int15);
        long long17 = fixedMillisecond1.getSerialIndex();
        java.lang.String str18 = fixedMillisecond1.toString();
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond1.getLastMillisecond(calendar19);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 100L + "'", long17 == 100L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str18.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Date date2 = fixedMillisecond1.getTime();
        long long3 = fixedMillisecond1.getFirstMillisecond();
        java.util.Date date4 = fixedMillisecond1.getTime();
        java.lang.Object obj5 = null;
        int int6 = fixedMillisecond1.compareTo(obj5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        java.util.Date date8 = year7.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.lang.String str10 = day9.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day9.next();
        boolean boolean12 = fixedMillisecond1.equals((java.lang.Object) regularTimePeriod11);
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond1.getMiddleMillisecond(calendar13);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        java.util.Date date18 = year17.getEnd();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
        java.lang.String str20 = day19.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day19.next();
        int int22 = day19.getMonth();
        timeSeries16.add((org.jfree.data.time.RegularTimePeriod) day19, (double) 100);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        java.util.Date date26 = year25.getEnd();
        boolean boolean28 = year25.equals((java.lang.Object) (-1.0d));
        int int30 = year25.compareTo((java.lang.Object) 1.0d);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        java.util.Date date32 = year31.getEnd();
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date32);
        java.lang.String str34 = day33.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = day33.next();
        int int36 = day33.getMonth();
        java.lang.String str37 = day33.toString();
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries16.createCopy((org.jfree.data.time.RegularTimePeriod) year25, (org.jfree.data.time.RegularTimePeriod) day33);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries16.getDataItem((int) (byte) 0);
        boolean boolean41 = fixedMillisecond1.equals((java.lang.Object) (byte) 0);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 100L + "'", long14 == 100L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "31-December-2019" + "'", str20.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 12 + "'", int22 == 12);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "31-December-2019" + "'", str34.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 12 + "'", int36 == 12);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "31-December-2019" + "'", str37.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertNotNull(timeSeriesDataItem40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560185156702L);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        java.lang.Object obj8 = timeSeries1.clone();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        long long12 = day11.getSerialIndex();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day11);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) month14);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        java.util.Date date17 = year16.getEnd();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date17);
        java.lang.String str19 = day18.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day18.next();
        int int21 = day18.getMonth();
        java.lang.String str22 = day18.toString();
        java.util.Date date23 = day18.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day18, (double) ' ');
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43830L + "'", long12 == 43830L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "31-December-2019" + "'", str19.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 12 + "'", int21 == 12);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "31-December-2019" + "'", str22.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNull(timeSeriesDataItem25);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        java.lang.String str6 = month2.toString();
        int int7 = month2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month2.next();
        long long9 = month2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1561964399999L + "'", long9 == 1561964399999L);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        boolean boolean2 = month0.equals((java.lang.Object) (byte) -1);
        int int3 = month0.getMonth();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
        int int6 = day2.compareTo((java.lang.Object) 1L);
        int int7 = day2.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day2.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day2.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod9, (java.lang.Number) 10.0d);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
        int int6 = day2.compareTo((java.lang.Object) 1L);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int6, "hi!", "");
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
        java.util.Date date5 = regularTimePeriod4.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month7.next();
        java.lang.String str9 = month7.toString();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "January 2020" + "'", str9.equals("January 2020"));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        java.util.Date date8 = year7.getEnd();
        boolean boolean10 = year7.equals((java.lang.Object) (-1.0d));
        int int12 = year7.compareTo((java.lang.Object) 1.0d);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) year7);
        double double14 = timeSeries1.getMaxY();
        double double15 = timeSeries1.getMaxY();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(9, (int) (byte) 0, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        int int8 = timeSeries1.getItemCount();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Date date13 = fixedMillisecond12.getTime();
        long long14 = fixedMillisecond12.getFirstMillisecond();
        java.util.Date date15 = fixedMillisecond12.getTime();
        java.lang.Object obj16 = null;
        int int17 = fixedMillisecond12.compareTo(obj16);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.util.Date date21 = year20.getEnd();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date21);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries19.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day22, (java.lang.Number) 0.0f);
        int int26 = day22.compareTo((java.lang.Object) (short) 0);
        int int27 = fixedMillisecond12.compareTo((java.lang.Object) int26);
        long long28 = fixedMillisecond12.getSerialIndex();
        java.lang.String str29 = fixedMillisecond12.toString();
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month();
        timeSeries31.add((org.jfree.data.time.RegularTimePeriod) month32, (java.lang.Number) (byte) 10, false);
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        java.util.Date date39 = year38.getEnd();
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date39);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day40, (java.lang.Number) 0.0f);
        boolean boolean43 = timeSeries37.getNotify();
        java.lang.Object obj44 = timeSeries37.clone();
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month();
        timeSeries46.add((org.jfree.data.time.RegularTimePeriod) month47, (java.lang.Number) (byte) 10, false);
        timeSeries46.setNotify(false);
        java.util.Collection collection53 = timeSeries37.getTimePeriodsUniqueToOtherSeries(timeSeries46);
        int int54 = month32.compareTo((java.lang.Object) timeSeries37);
        int int55 = month32.getMonth();
        org.jfree.data.time.TimeSeries timeSeries56 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (org.jfree.data.time.RegularTimePeriod) month32);
        timeSeries56.removeAgedItems((long) 9, false);
        org.jfree.data.time.Year year60 = new org.jfree.data.time.Year();
        java.util.Date date61 = year60.getEnd();
        int int62 = timeSeries56.getIndex((org.jfree.data.time.RegularTimePeriod) year60);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 100L + "'", long14 == 100L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 100L + "'", long28 == 100L);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str29.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNull(timeSeriesDataItem42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(obj44);
        org.junit.Assert.assertNotNull(collection53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 6 + "'", int55 == 6);
        org.junit.Assert.assertNotNull(timeSeries56);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
    }

//    @Test
//    public void test449() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test449");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "2019", "");
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
//        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
//        timeSeries6.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10, false);
//        timeSeries6.setNotify(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond13.getFirstMillisecond(calendar14);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries6.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13);
//        timeSeries4.add(timeSeriesDataItem16, true);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = timeSeriesDataItem16.getPeriod();
//        boolean boolean20 = day0.equals((java.lang.Object) timeSeriesDataItem16);
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "2019", "");
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
//        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
//        timeSeries26.add((org.jfree.data.time.RegularTimePeriod) month27, (java.lang.Number) (byte) 10, false);
//        timeSeries26.setNotify(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar34 = null;
//        long long35 = fixedMillisecond33.getFirstMillisecond(calendar34);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries26.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33);
//        timeSeries24.add(timeSeriesDataItem36, true);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = timeSeriesDataItem36.getPeriod();
//        boolean boolean40 = timeSeriesDataItem16.equals((java.lang.Object) timeSeriesDataItem36);
//        timeSeriesDataItem36.setValue((java.lang.Number) (short) 0);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560185180188L + "'", long15 == 1560185180188L);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem16);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560185180196L + "'", long35 == 1560185180196L);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem36);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
        int int6 = day2.compareTo((java.lang.Object) 1L);
        int int7 = day2.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day2.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day2.previous();
        long long10 = day2.getSerialIndex();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 43830L + "'", long10 == 43830L);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
        java.util.Date date5 = regularTimePeriod4.getStart();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date5);
        java.lang.String str7 = timeSeries6.getDescription();
        java.lang.String str8 = timeSeries6.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        java.util.Date date12 = year11.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (java.lang.Number) 0.0f);
        boolean boolean16 = timeSeries10.getNotify();
        java.lang.Object obj17 = timeSeries10.clone();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        java.util.Date date19 = year18.getEnd();
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date19);
        long long21 = day20.getSerialIndex();
        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) day20);
        java.lang.Object obj23 = timeSeries10.clone();
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries6.addAndOrUpdate(timeSeries10);
        java.beans.PropertyChangeListener propertyChangeListener25 = null;
        timeSeries24.addPropertyChangeListener(propertyChangeListener25);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener27 = null;
        timeSeries24.addChangeListener(seriesChangeListener27);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException32 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException34 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException32.addSuppressed((java.lang.Throwable) timePeriodFormatException34);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException37 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException39 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException37.addSuppressed((java.lang.Throwable) timePeriodFormatException39);
        timePeriodFormatException32.addSuppressed((java.lang.Throwable) timePeriodFormatException37);
        int int42 = year30.compareTo((java.lang.Object) timePeriodFormatException32);
        int int43 = timeSeries24.getIndex((org.jfree.data.time.RegularTimePeriod) year30);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Value" + "'", str8.equals("Value"));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 43830L + "'", long21 == 43830L);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertNotNull(timeSeries24);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        java.lang.Throwable[] throwableArray14 = timePeriodFormatException10.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        java.lang.String str18 = timePeriodFormatException16.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str18.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
        java.util.Date date5 = regularTimePeriod4.getStart();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date5);
        java.lang.String str7 = timeSeries6.getDescription();
        java.lang.String str8 = timeSeries6.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        java.util.Date date12 = year11.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (java.lang.Number) 0.0f);
        boolean boolean16 = timeSeries10.getNotify();
        java.lang.Object obj17 = timeSeries10.clone();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        java.util.Date date19 = year18.getEnd();
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date19);
        long long21 = day20.getSerialIndex();
        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) day20);
        java.lang.Object obj23 = timeSeries10.clone();
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries6.addAndOrUpdate(timeSeries10);
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        timeSeries26.add((org.jfree.data.time.RegularTimePeriod) month27, (java.lang.Number) (byte) 10, false);
        timeSeries26.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month();
        timeSeries34.add((org.jfree.data.time.RegularTimePeriod) month35, (java.lang.Number) (byte) 10, false);
        timeSeries34.setNotify(false);
        java.util.Collection collection41 = timeSeries26.getTimePeriodsUniqueToOtherSeries(timeSeries34);
        boolean boolean42 = timeSeries26.getNotify();
        timeSeries26.removeAgedItems((long) 'a', true);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = timeSeries26.getNextTimePeriod();
        java.lang.String str47 = regularTimePeriod46.toString();
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year();
        java.util.Date date49 = year48.getEnd();
        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(date49);
        java.lang.String str51 = day50.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = day50.next();
        int int53 = day50.getMonth();
        java.lang.String str54 = day50.toString();
        org.jfree.data.time.TimeSeries timeSeries57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day50, "", "org.jfree.data.event.SeriesChangeEvent[source=1]");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day50, (java.lang.Number) (-1L));
        org.jfree.data.time.TimeSeries timeSeries60 = timeSeries6.createCopy(regularTimePeriod46, (org.jfree.data.time.RegularTimePeriod) day50);
        java.beans.PropertyChangeListener propertyChangeListener61 = null;
        timeSeries6.removePropertyChangeListener(propertyChangeListener61);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Value" + "'", str8.equals("Value"));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 43830L + "'", long21 == 43830L);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertNotNull(timeSeries24);
        org.junit.Assert.assertNotNull(collection41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "July 2019" + "'", str47.equals("July 2019"));
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "31-December-2019" + "'", str51.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 12 + "'", int53 == 12);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "31-December-2019" + "'", str54.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(timeSeries60);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) (byte) 10, false);
        timeSeries9.setNotify(false);
        java.util.Collection collection16 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries9);
        boolean boolean17 = timeSeries1.getNotify();
        timeSeries1.removeAgedItems((long) 'a', true);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = timeSeries1.getNextTimePeriod();
        java.lang.Class<?> wildcardClass22 = regularTimePeriod21.getClass();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        java.util.Date date24 = year23.getEnd();
        java.util.TimeZone timeZone25 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass22, date24, timeZone25);
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNull(regularTimePeriod26);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) (byte) 10, false);
        timeSeries9.setNotify(false);
        java.util.Collection collection16 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries9);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) year17);
        java.lang.Object obj19 = timeSeriesDataItem18.clone();
        timeSeriesDataItem18.setSelected(false);
        timeSeriesDataItem18.setSelected(true);
        timeSeriesDataItem18.setSelected(true);
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertNotNull(timeSeriesDataItem18);
        org.junit.Assert.assertNotNull(obj19);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (short) 1, year1);
        int int4 = month3.getMonth();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date1);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date1);
        org.junit.Assert.assertNotNull(date1);
    }

//    @Test
//    public void test458() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test458");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
//        timeSeries1.setNotify(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond8.getFirstMillisecond(calendar9);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
//        java.util.Date date13 = year12.getEnd();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
//        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date13);
//        long long16 = year15.getMiddleMillisecond();
//        timeSeries1.setKey((java.lang.Comparable) year15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = null;
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2, "org.jfree.data.time.TimePeriodFormatException: hi!", "org.jfree.data.event.SeriesChangeEvent[source=1]");
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
//        java.util.Date date24 = year23.getEnd();
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date24);
//        java.lang.String str26 = day25.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = day25.next();
//        java.util.Date date28 = regularTimePeriod27.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond(date28);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = fixedMillisecond29.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = fixedMillisecond29.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries22.addOrUpdate(regularTimePeriod31, (java.lang.Number) 100.0f);
//        try {
//            org.jfree.data.time.TimeSeries timeSeries34 = timeSeries1.createCopy(regularTimePeriod18, regularTimePeriod31);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'start' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560185182204L + "'", long10 == 1560185182204L);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem11);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1562097599999L + "'", long16 == 1562097599999L);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "31-December-2019" + "'", str26.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertNull(timeSeriesDataItem33);
//    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) (byte) 10, false);
        timeSeries9.setNotify(false);
        java.util.Collection collection16 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries9);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener17 = null;
        timeSeries1.addChangeListener(seriesChangeListener17);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        java.util.Date date22 = year21.getEnd();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day23, (java.lang.Number) 0.0f);
        boolean boolean26 = timeSeries20.getNotify();
        int int27 = timeSeries20.getItemCount();
        java.beans.PropertyChangeListener propertyChangeListener28 = null;
        timeSeries20.removePropertyChangeListener(propertyChangeListener28);
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Date date32 = fixedMillisecond31.getTime();
        long long33 = fixedMillisecond31.getFirstMillisecond();
        java.util.Date date34 = fixedMillisecond31.getTime();
        java.lang.Object obj35 = null;
        int int36 = fixedMillisecond31.compareTo(obj35);
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
        java.util.Date date40 = year39.getEnd();
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date40);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries38.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day41, (java.lang.Number) 0.0f);
        int int45 = day41.compareTo((java.lang.Object) (short) 0);
        int int46 = fixedMillisecond31.compareTo((java.lang.Object) int45);
        long long47 = fixedMillisecond31.getSerialIndex();
        java.lang.String str48 = fixedMillisecond31.toString();
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month();
        timeSeries50.add((org.jfree.data.time.RegularTimePeriod) month51, (java.lang.Number) (byte) 10, false);
        org.jfree.data.time.TimeSeries timeSeries56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year();
        java.util.Date date58 = year57.getEnd();
        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day(date58);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem61 = timeSeries56.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day59, (java.lang.Number) 0.0f);
        boolean boolean62 = timeSeries56.getNotify();
        java.lang.Object obj63 = timeSeries56.clone();
        org.jfree.data.time.TimeSeries timeSeries65 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month66 = new org.jfree.data.time.Month();
        timeSeries65.add((org.jfree.data.time.RegularTimePeriod) month66, (java.lang.Number) (byte) 10, false);
        timeSeries65.setNotify(false);
        java.util.Collection collection72 = timeSeries56.getTimePeriodsUniqueToOtherSeries(timeSeries65);
        int int73 = month51.compareTo((java.lang.Object) timeSeries56);
        int int74 = month51.getMonth();
        org.jfree.data.time.TimeSeries timeSeries75 = timeSeries20.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond31, (org.jfree.data.time.RegularTimePeriod) month51);
        java.lang.Number number76 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) month51);
        java.beans.PropertyChangeListener propertyChangeListener77 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener77);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener79 = null;
        timeSeries1.removeChangeListener(seriesChangeListener79);
        int int81 = timeSeries1.getItemCount();
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNull(timeSeriesDataItem25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 100L + "'", long33 == 100L);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNull(timeSeriesDataItem43);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 100L + "'", long47 == 100L);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str48.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertNull(timeSeriesDataItem61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(obj63);
        org.junit.Assert.assertNotNull(collection72);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 1 + "'", int73 == 1);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 6 + "'", int74 == 6);
        org.junit.Assert.assertNotNull(timeSeries75);
        org.junit.Assert.assertTrue("'" + number76 + "' != '" + (byte) 10 + "'", number76.equals((byte) 10));
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 1 + "'", int81 == 1);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        java.util.Locale locale2 = null;
        try {
            org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date0, timeZone1, locale2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.util.Date date4 = year3.getEnd();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        long long6 = day5.getLastMillisecond();
        int int7 = year1.compareTo((java.lang.Object) day5);
        int int8 = year1.getYear();
        java.lang.String str9 = year1.toString();
        java.util.Calendar calendar10 = null;
        try {
            long long11 = year1.getLastMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 35 + "'", int8 == 35);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "35" + "'", str9.equals("35"));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        java.lang.String str5 = day4.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day4.next();
        int int7 = day4.getMonth();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (double) 100);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        boolean boolean13 = year10.equals((java.lang.Object) (-1.0d));
        int int15 = year10.compareTo((java.lang.Object) 1.0d);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        java.util.Date date17 = year16.getEnd();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date17);
        java.lang.String str19 = day18.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day18.next();
        int int21 = day18.getMonth();
        java.lang.String str22 = day18.toString();
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year10, (org.jfree.data.time.RegularTimePeriod) day18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day18.next();
        org.jfree.data.time.SerialDate serialDate25 = day18.getSerialDate();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "31-December-2019" + "'", str5.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "31-December-2019" + "'", str19.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 12 + "'", int21 == 12);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "31-December-2019" + "'", str22.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(serialDate25);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Date date2 = fixedMillisecond1.getTime();
        long long3 = fixedMillisecond1.getFirstMillisecond();
        java.util.Date date4 = fixedMillisecond1.getTime();
        java.lang.Object obj5 = null;
        int int6 = fixedMillisecond1.compareTo(obj5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        java.util.Date date8 = year7.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.lang.String str10 = day9.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day9.next();
        boolean boolean12 = fixedMillisecond1.equals((java.lang.Object) regularTimePeriod11);
        long long13 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond1.getLastMillisecond(calendar14);
        java.util.Calendar calendar16 = null;
        fixedMillisecond1.peg(calendar16);
        long long18 = fixedMillisecond1.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 100L + "'", long13 == 100L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 100L + "'", long15 == 100L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 100L + "'", long18 == 100L);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("June 2019");
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        java.lang.Object obj8 = timeSeries1.clone();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        timeSeries10.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) (byte) 10, false);
        timeSeries10.setNotify(false);
        java.util.Collection collection17 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries10);
        timeSeries1.setDomainDescription("");
        java.util.Collection collection20 = timeSeries1.getTimePeriods();
        java.lang.Class class21 = timeSeries1.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) month24, (java.lang.Number) (byte) 10, false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = month24.previous();
        int int29 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month24.next();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertNotNull(collection20);
        org.junit.Assert.assertNotNull(class21);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setRangeDescription("hi!");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeries1.getNextTimePeriod();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        timeSeries10.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) (byte) 10, false);
        timeSeries10.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
        timeSeries18.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) (byte) 10, false);
        timeSeries18.setNotify(false);
        java.util.Collection collection25 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries18.getDataItem((org.jfree.data.time.RegularTimePeriod) year26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries1.addOrUpdate(timeSeriesDataItem27);
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        java.util.Date date30 = year29.getEnd();
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date30);
        java.lang.String str32 = day31.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = day31.next();
        java.util.Date date34 = regularTimePeriod33.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond(date34);
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month(date34);
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date34);
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) day37, (java.lang.Number) (short) 10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Date date42 = fixedMillisecond41.getTime();
        java.util.Date date43 = fixedMillisecond41.getTime();
        int int44 = day37.compareTo((java.lang.Object) fixedMillisecond41);
        java.util.Calendar calendar45 = null;
        long long46 = fixedMillisecond41.getLastMillisecond(calendar45);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(collection25);
        org.junit.Assert.assertNotNull(timeSeriesDataItem27);
        org.junit.Assert.assertNotNull(timeSeriesDataItem28);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "31-December-2019" + "'", str32.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 100L + "'", long46 == 100L);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        org.jfree.data.time.Year year2 = month0.getYear();
        int int3 = year2.getYear();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year2.getMiddleMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Date date2 = fixedMillisecond1.getTime();
        long long3 = fixedMillisecond1.getFirstMillisecond();
        java.util.Date date4 = fixedMillisecond1.getTime();
        java.lang.Object obj5 = null;
        int int6 = fixedMillisecond1.compareTo(obj5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        java.util.Date date8 = year7.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.lang.String str10 = day9.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day9.next();
        boolean boolean12 = fixedMillisecond1.equals((java.lang.Object) regularTimePeriod11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = fixedMillisecond1.previous();
        long long14 = fixedMillisecond1.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 100L + "'", long14 == 100L);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        java.lang.String str6 = month2.toString();
        int int7 = month2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month2.next();
        java.lang.String str10 = month2.toString();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "June 2019" + "'", str10.equals("June 2019"));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        java.util.Date date8 = year7.getEnd();
        boolean boolean10 = year7.equals((java.lang.Object) (-1.0d));
        int int12 = year7.compareTo((java.lang.Object) 1.0d);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) year7);
        java.lang.Object obj14 = timeSeries1.clone();
        org.jfree.data.time.TimeSeries timeSeries15 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries16 = timeSeries1.addAndOrUpdate(timeSeries15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        java.lang.Object obj8 = timeSeries1.clone();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        long long12 = day11.getSerialIndex();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day11);
        java.lang.Object obj14 = timeSeries1.clone();
        java.lang.Class class15 = timeSeries1.getTimePeriodClass();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        java.util.Date date17 = year16.getEnd();
        long long18 = year16.getLastMillisecond();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year16, (java.lang.Number) (-62041132800001L), true);
        java.lang.String str22 = timeSeries1.getDescription();
        java.lang.String str23 = timeSeries1.getDomainDescription();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43830L + "'", long12 == 43830L);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNull(class15);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577865599999L + "'", long18 == 1577865599999L);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Time" + "'", str23.equals("Time"));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(9999, 0, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("2019");
        java.lang.String str2 = year1.toString();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.removeChangeListener(seriesChangeListener6);
        timeSeries1.setDomainDescription("31-December-2019");
        timeSeries1.removeAgedItems(43830L, true);
        java.lang.String str13 = timeSeries1.getRangeDescription();
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Value" + "'", str13.equals("Value"));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.removeChangeListener(seriesChangeListener6);
        java.lang.Comparable comparable8 = timeSeries1.getKey();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        java.util.Date date12 = year11.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        java.lang.String str14 = day13.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day13.next();
        int int16 = day13.getMonth();
        timeSeries10.add((org.jfree.data.time.RegularTimePeriod) day13, (double) 100);
        long long19 = day13.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) day13);
        boolean boolean21 = timeSeriesDataItem20.isSelected();
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 'a' + "'", comparable8.equals('a'));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "31-December-2019" + "'", str14.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 12 + "'", int16 == 12);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1577865599999L + "'", long19 == 1577865599999L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        java.util.Date date8 = year7.getEnd();
        boolean boolean10 = year7.equals((java.lang.Object) (-1.0d));
        int int12 = year7.compareTo((java.lang.Object) 1.0d);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) year7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeriesDataItem13.getPeriod();
        int int16 = timeSeriesDataItem13.compareTo((java.lang.Object) 2019);
        java.lang.Number number17 = timeSeriesDataItem13.getValue();
        java.lang.Object obj18 = timeSeriesDataItem13.clone();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 0.0f + "'", number17.equals(0.0f));
        org.junit.Assert.assertNotNull(obj18);
    }

//    @Test
//    public void test477() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test477");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "2019", "");
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
//        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
//        timeSeries6.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10, false);
//        timeSeries6.setNotify(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond13.getFirstMillisecond(calendar14);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries6.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13);
//        timeSeries4.add(timeSeriesDataItem16, true);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = timeSeriesDataItem16.getPeriod();
//        boolean boolean20 = day0.equals((java.lang.Object) timeSeriesDataItem16);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day0.next();
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560185184144L + "'", long15 == 1560185184144L);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem16);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        java.lang.String str5 = day4.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day4.next();
        int int7 = day4.getMonth();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (double) 100);
        java.lang.String str10 = timeSeries1.getDescription();
        java.lang.Class class11 = timeSeries1.getTimePeriodClass();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "31-December-2019" + "'", str5.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(class11);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(5);
        long long2 = year1.getSerialIndex();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.util.Date date4 = year3.getEnd();
        boolean boolean6 = year3.equals((java.lang.Object) (-1.0d));
        int int8 = year3.compareTo((java.lang.Object) 1.0d);
        long long9 = year3.getFirstMillisecond();
        boolean boolean10 = year1.equals((java.lang.Object) year3);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5L + "'", long2 == 5L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560185124238L);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.Year year9 = org.jfree.data.time.Year.parseYear("2019");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) year9);
        timeSeries1.setNotify(true);
        java.lang.String str13 = timeSeries1.getDomainDescription();
        java.lang.Class class14 = timeSeries1.getTimePeriodClass();
        timeSeries1.clear();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries1.getDataItem(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Time" + "'", str13.equals("Time"));
        org.junit.Assert.assertNotNull(class14);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
        java.util.Date date5 = regularTimePeriod4.getStart();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date5);
        java.lang.String str7 = timeSeries6.getDescription();
        java.lang.String str8 = timeSeries6.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        java.util.Date date12 = year11.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (java.lang.Number) 0.0f);
        boolean boolean16 = timeSeries10.getNotify();
        java.lang.Object obj17 = timeSeries10.clone();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        java.util.Date date19 = year18.getEnd();
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date19);
        long long21 = day20.getSerialIndex();
        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) day20);
        java.lang.Object obj23 = timeSeries10.clone();
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries6.addAndOrUpdate(timeSeries10);
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        java.util.Date date28 = year27.getEnd();
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date28);
        java.lang.String str30 = day29.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = day29.next();
        int int32 = day29.getMonth();
        timeSeries26.add((org.jfree.data.time.RegularTimePeriod) day29, (double) 100);
        long long35 = day29.getLastMillisecond();
        java.lang.String str36 = day29.toString();
        int int37 = timeSeries10.getIndex((org.jfree.data.time.RegularTimePeriod) day29);
        timeSeries10.setDomainDescription("June 2019");
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Value" + "'", str8.equals("Value"));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 43830L + "'", long21 == 43830L);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertNotNull(timeSeries24);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "31-December-2019" + "'", str30.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 12 + "'", int32 == 12);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1577865599999L + "'", long35 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "31-December-2019" + "'", str36.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (short) 1, seriesChangeInfo1);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo3 = seriesChangeEvent2.getSummary();
        java.lang.String str4 = seriesChangeEvent2.toString();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo5 = null;
        seriesChangeEvent2.setSummary(seriesChangeInfo5);
        java.lang.Object obj7 = seriesChangeEvent2.getSource();
        java.lang.Object obj8 = seriesChangeEvent2.getSource();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo9 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.event.SeriesChangeEvent(obj8, seriesChangeInfo9);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo11 = null;
        seriesChangeEvent10.setSummary(seriesChangeInfo11);
        org.junit.Assert.assertNull(seriesChangeInfo3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=1]" + "'", str4.equals("org.jfree.data.event.SeriesChangeEvent[source=1]"));
        org.junit.Assert.assertTrue("'" + obj7 + "' != '" + (short) 1 + "'", obj7.equals((short) 1));
        org.junit.Assert.assertTrue("'" + obj8 + "' != '" + (short) 1 + "'", obj8.equals((short) 1));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Date date2 = fixedMillisecond1.getTime();
        long long3 = fixedMillisecond1.getFirstMillisecond();
        java.util.Date date4 = fixedMillisecond1.getTime();
        java.lang.Object obj5 = null;
        int int6 = fixedMillisecond1.compareTo(obj5);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day11, (java.lang.Number) 0.0f);
        int int15 = day11.compareTo((java.lang.Object) (short) 0);
        int int16 = fixedMillisecond1.compareTo((java.lang.Object) int15);
        long long17 = fixedMillisecond1.getLastMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 100L + "'", long17 == 100L);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        timeSeries1.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) (byte) 10, false);
        timeSeries5.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        timeSeries13.add((org.jfree.data.time.RegularTimePeriod) month14, (java.lang.Number) (byte) 10, false);
        timeSeries13.setNotify(false);
        java.util.Collection collection20 = timeSeries5.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) year21);
        timeSeries1.add(timeSeriesDataItem22, false);
        double double25 = timeSeries1.getMinY();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        java.util.Date date29 = year28.getEnd();
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date29);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries27.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day30, (java.lang.Number) 0.0f);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        java.util.Date date34 = year33.getEnd();
        boolean boolean36 = year33.equals((java.lang.Object) (-1.0d));
        int int38 = year33.compareTo((java.lang.Object) 1.0d);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries27.getDataItem((org.jfree.data.time.RegularTimePeriod) year33);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = timeSeriesDataItem39.getPeriod();
        int int42 = timeSeriesDataItem39.compareTo((java.lang.Object) 2019);
        java.lang.Number number43 = timeSeriesDataItem39.getValue();
        try {
            timeSeries1.add(timeSeriesDataItem39, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Day, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(collection20);
        org.junit.Assert.assertNotNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 10.0d + "'", double25 == 10.0d);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNull(timeSeriesDataItem32);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(timeSeriesDataItem39);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertTrue("'" + number43 + "' != '" + 0.0f + "'", number43.equals(0.0f));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        java.lang.Object obj8 = timeSeries1.clone();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        long long12 = day11.getSerialIndex();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day11);
        java.lang.Object obj14 = timeSeries1.clone();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        java.util.Date date17 = year16.getEnd();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 1, year16);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) year16);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year16);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        timeSeries22.add((org.jfree.data.time.RegularTimePeriod) month23, (java.lang.Number) (byte) 10, false);
        timeSeries22.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month();
        timeSeries30.add((org.jfree.data.time.RegularTimePeriod) month31, (java.lang.Number) (byte) 10, false);
        timeSeries30.setNotify(false);
        java.util.Collection collection37 = timeSeries22.getTimePeriodsUniqueToOtherSeries(timeSeries30);
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries30.getDataItem((org.jfree.data.time.RegularTimePeriod) year38);
        java.lang.Object obj40 = timeSeriesDataItem39.clone();
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = year42.next();
        int int44 = timeSeriesDataItem39.compareTo((java.lang.Object) year42);
        timeSeries20.add(timeSeriesDataItem39);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43830L + "'", long12 == 43830L);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(collection37);
        org.junit.Assert.assertNotNull(timeSeriesDataItem39);
        org.junit.Assert.assertNotNull(obj40);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) (byte) 10, false);
        timeSeries9.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        timeSeries17.add((org.jfree.data.time.RegularTimePeriod) month18, (java.lang.Number) (byte) 10, false);
        timeSeries17.setNotify(false);
        java.util.Collection collection24 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries17);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries17.getDataItem((org.jfree.data.time.RegularTimePeriod) year25);
        java.lang.Object obj27 = timeSeriesDataItem26.clone();
        java.lang.Number number28 = timeSeriesDataItem26.getValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries1.addOrUpdate(timeSeriesDataItem26);
        boolean boolean30 = timeSeriesDataItem29.isSelected();
        java.lang.Class<?> wildcardClass31 = timeSeriesDataItem29.getClass();
        org.junit.Assert.assertNotNull(collection24);
        org.junit.Assert.assertNotNull(timeSeriesDataItem26);
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertTrue("'" + number28 + "' != '" + (byte) 10 + "'", number28.equals((byte) 10));
        org.junit.Assert.assertNotNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(wildcardClass31);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        org.jfree.data.time.Year year2 = month0.getYear();
        java.util.Date date3 = month0.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day2.previous();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(12, 7);
        java.util.Calendar calendar3 = null;
        try {
            month2.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        java.lang.Object obj8 = null;
        boolean boolean9 = timeSeries1.equals(obj8);
        boolean boolean10 = timeSeries1.isEmpty();
        timeSeries1.setDomainDescription("");
        double double13 = timeSeries1.getMaxY();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

//    @Test
//    public void test492() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test492");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
//        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
//        java.util.Date date3 = year2.getEnd();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
//        boolean boolean7 = timeSeries1.getNotify();
//        java.lang.Object obj8 = timeSeries1.clone();
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        timeSeries10.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) (byte) 10, false);
//        timeSeries10.setNotify(false);
//        java.util.Collection collection17 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries10);
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year((int) '#');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year19.next();
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
//        java.util.Date date22 = year21.getEnd();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
//        long long24 = day23.getLastMillisecond();
//        int int25 = year19.compareTo((java.lang.Object) day23);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar27 = null;
//        long long28 = fixedMillisecond26.getFirstMillisecond(calendar27);
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
//        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
//        java.util.Date date32 = year31.getEnd();
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date32);
//        java.lang.String str34 = day33.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = day33.next();
//        int int36 = day33.getMonth();
//        timeSeries30.add((org.jfree.data.time.RegularTimePeriod) day33, (double) 100);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener39 = null;
//        timeSeries30.addChangeListener(seriesChangeListener39);
//        java.lang.Object obj41 = timeSeries30.clone();
//        boolean boolean42 = fixedMillisecond26.equals((java.lang.Object) timeSeries30);
//        int int43 = day23.compareTo((java.lang.Object) fixedMillisecond26);
//        long long44 = fixedMillisecond26.getFirstMillisecond();
//        try {
//            timeSeries10.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, (java.lang.Number) (-62041132800001L));
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNull(timeSeriesDataItem6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(obj8);
//        org.junit.Assert.assertNotNull(collection17);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1577865599999L + "'", long24 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560185185195L + "'", long28 == 1560185185195L);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "31-December-2019" + "'", str34.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 12 + "'", int36 == 12);
//        org.junit.Assert.assertNotNull(obj41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1560185185195L + "'", long44 == 1560185185195L);
//    }

//    @Test
//    public void test493() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test493");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "2019", "");
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
//        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) (byte) 10, false);
//        timeSeries5.setNotify(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar13 = null;
//        long long14 = fixedMillisecond12.getFirstMillisecond(calendar13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries5.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
//        timeSeries3.add(timeSeriesDataItem15, true);
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
//        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
//        java.util.Date date21 = year20.getEnd();
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date21);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries19.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day22, (java.lang.Number) 0.0f);
//        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
//        java.util.Date date26 = year25.getEnd();
//        boolean boolean28 = year25.equals((java.lang.Object) (-1.0d));
//        int int30 = year25.compareTo((java.lang.Object) 1.0d);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries19.getDataItem((org.jfree.data.time.RegularTimePeriod) year25);
//        java.lang.Number number32 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) year25);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
//        java.util.Date date35 = fixedMillisecond34.getTime();
//        long long36 = fixedMillisecond34.getFirstMillisecond();
//        java.util.Date date37 = fixedMillisecond34.getTime();
//        java.lang.Object obj38 = null;
//        int int39 = fixedMillisecond34.compareTo(obj38);
//        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
//        java.util.Date date41 = year40.getEnd();
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(date41);
//        java.lang.String str43 = day42.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = day42.next();
//        boolean boolean45 = fixedMillisecond34.equals((java.lang.Object) regularTimePeriod44);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = fixedMillisecond34.previous();
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = timeSeries3.addOrUpdate(regularTimePeriod46, (java.lang.Number) 43830L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560185185216L + "'", long14 == 1560185185216L);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem15);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNull(timeSeriesDataItem24);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem31);
//        org.junit.Assert.assertTrue("'" + number32 + "' != '" + (byte) 10 + "'", number32.equals((byte) 10));
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 100L + "'", long36 == 100L);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "31-December-2019" + "'", str43.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod44);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (short) 1, seriesChangeInfo1);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo3 = seriesChangeEvent2.getSummary();
        java.lang.String str4 = seriesChangeEvent2.toString();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo5 = null;
        seriesChangeEvent2.setSummary(seriesChangeInfo5);
        java.lang.Object obj7 = seriesChangeEvent2.getSource();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo8 = null;
        seriesChangeEvent2.setSummary(seriesChangeInfo8);
        org.junit.Assert.assertNull(seriesChangeInfo3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=1]" + "'", str4.equals("org.jfree.data.event.SeriesChangeEvent[source=1]"));
        org.junit.Assert.assertTrue("'" + obj7 + "' != '" + (short) 1 + "'", obj7.equals((short) 1));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
        int int5 = day2.getMonth();
        java.lang.String str6 = day2.toString();
        long long7 = day2.getSerialIndex();
        long long8 = day2.getSerialIndex();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "31-December-2019" + "'", str6.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43830L + "'", long7 == 43830L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 43830L + "'", long8 == 43830L);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) 0.0f);
        int int11 = day7.compareTo((java.lang.Object) (short) 0);
        boolean boolean12 = fixedMillisecond1.equals((java.lang.Object) (short) 0);
        java.lang.String str13 = fixedMillisecond1.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str13.equals("Wed Dec 31 16:00:00 PST 1969"));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        java.lang.Object obj8 = timeSeries1.clone();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        long long12 = day11.getSerialIndex();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day11);
        java.lang.Object obj14 = timeSeries1.clone();
        java.lang.Class class15 = timeSeries1.getTimePeriodClass();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month16);
        timeSeries17.setDescription("");
        java.lang.String str20 = timeSeries17.getRangeDescription();
        java.util.Collection collection21 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries17);
        timeSeries17.removeAgedItems(false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43830L + "'", long12 == 43830L);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNull(class15);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Value" + "'", str20.equals("Value"));
        org.junit.Assert.assertNotNull(collection21);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        java.lang.String str5 = day4.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day4.next();
        int int7 = day4.getMonth();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (double) 100);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        boolean boolean13 = year10.equals((java.lang.Object) (-1.0d));
        int int15 = year10.compareTo((java.lang.Object) 1.0d);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        java.util.Date date17 = year16.getEnd();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date17);
        java.lang.String str19 = day18.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day18.next();
        int int21 = day18.getMonth();
        java.lang.String str22 = day18.toString();
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year10, (org.jfree.data.time.RegularTimePeriod) day18);
        int int24 = year10.getYear();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year10, "org.jfree.data.event.SeriesChangeEvent[source=class org.jfree.data.time.Year]", "35");
        try {
            java.lang.Number number29 = timeSeries27.getValue(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "31-December-2019" + "'", str5.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "31-December-2019" + "'", str19.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 12 + "'", int21 == 12);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "31-December-2019" + "'", str22.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setRangeDescription("hi!");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeries1.getNextTimePeriod();
        timeSeries1.setDomainDescription("2019");
        double double11 = timeSeries1.getMinY();
        timeSeries1.setDomainDescription("org.jfree.data.event.SeriesChangeEvent[source=class org.jfree.data.time.Year]");
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 10.0d + "'", double11 == 10.0d);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        timeSeries1.setDescription("");
        java.lang.Class<?> wildcardClass4 = timeSeries1.getClass();
        org.junit.Assert.assertNotNull(wildcardClass4);
    }
}

