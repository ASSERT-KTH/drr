import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
        int int5 = day2.getMonth();
        java.lang.String str6 = day2.toString();
        org.jfree.data.time.SerialDate serialDate7 = day2.getSerialDate();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(serialDate7);
        long long9 = day8.getSerialIndex();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "31-December-2019" + "'", str6.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 43830L + "'", long9 == 43830L);
    }

//    @Test
//    public void test002() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test002");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
//        timeSeries1.setNotify(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond8.getFirstMillisecond(calendar9);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
//        try {
//            org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy(100, 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560185186385L + "'", long10 == 1560185186385L);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem11);
//    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        java.lang.Object obj8 = null;
        boolean boolean9 = timeSeries1.equals(obj8);
        boolean boolean10 = timeSeries1.isEmpty();
        timeSeries1.setNotify(true);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.removeChangeListener(seriesChangeListener6);
        java.lang.Comparable comparable8 = timeSeries1.getKey();
        java.util.Collection collection9 = timeSeries1.getTimePeriods();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = timeSeries1.getNextTimePeriod();
        java.lang.Class<?> wildcardClass11 = timeSeries1.getClass();
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 'a' + "'", comparable8.equals('a'));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass1 = year0.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Date date4 = fixedMillisecond3.getTime();
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass1, date4, timeZone5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date4);
        java.util.TimeZone timeZone8 = null;
        try {
            org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date4, timeZone8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(regularTimePeriod6);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
        java.util.Date date5 = regularTimePeriod4.getStart();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod4);
        try {
            java.lang.Number number8 = timeSeries6.getValue((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
        int int6 = day2.compareTo((java.lang.Object) 1L);
        int int7 = day2.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day2.previous();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.util.Date date10 = year9.getEnd();
        boolean boolean12 = year9.equals((java.lang.Object) (-1.0d));
        int int14 = year9.compareTo((java.lang.Object) 1.0d);
        long long15 = year9.getFirstMillisecond();
        int int16 = day2.compareTo((java.lang.Object) long15);
        java.util.Calendar calendar17 = null;
        try {
            long long18 = day2.getLastMillisecond(calendar17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1546329600000L + "'", long15 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 0L, seriesChangeInfo1);
    }

//    @Test
//    public void test009() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test009");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "2019", "");
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
//        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
//        timeSeries6.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 10, false);
//        timeSeries6.setNotify(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond13.getFirstMillisecond(calendar14);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries6.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13);
//        timeSeries4.add(timeSeriesDataItem16, true);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = timeSeriesDataItem16.getPeriod();
//        boolean boolean20 = day0.equals((java.lang.Object) timeSeriesDataItem16);
//        java.util.Calendar calendar21 = null;
//        try {
//            long long22 = day0.getLastMillisecond(calendar21);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560185186523L + "'", long15 == 1560185186523L);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem16);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0, "", "hi!");
        java.lang.Class<?> wildcardClass4 = fixedMillisecond0.getClass();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        java.util.Date date8 = year7.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.lang.String str10 = day9.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day9.next();
        int int12 = day9.getMonth();
        timeSeries6.add((org.jfree.data.time.RegularTimePeriod) day9, (double) 100);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        java.util.Date date16 = year15.getEnd();
        boolean boolean18 = year15.equals((java.lang.Object) (-1.0d));
        int int20 = year15.compareTo((java.lang.Object) 1.0d);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        java.util.Date date22 = year21.getEnd();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        java.lang.String str24 = day23.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day23.next();
        int int26 = day23.getMonth();
        java.lang.String str27 = day23.toString();
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) year15, (org.jfree.data.time.RegularTimePeriod) day23);
        double double29 = timeSeries6.getMinY();
        java.util.List list30 = timeSeries6.getItems();
        int int31 = fixedMillisecond0.compareTo((java.lang.Object) list30);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 12 + "'", int12 == 12);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "31-December-2019" + "'", str24.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 12 + "'", int26 == 12);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "31-December-2019" + "'", str27.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 100.0d + "'", double29 == 100.0d);
        org.junit.Assert.assertNotNull(list30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        int int8 = timeSeries1.getItemCount();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener9);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries1.removeChangeListener(seriesChangeListener11);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setRangeDescription("hi!");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeries1.getNextTimePeriod();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        java.lang.String str12 = day11.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day11.next();
        java.util.Date date14 = regularTimePeriod13.getStart();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date14);
        java.lang.String str16 = timeSeries15.getDescription();
        java.util.Collection collection17 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries15);
        try {
            timeSeries1.setMaximumItemCount((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'maximum' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "31-December-2019" + "'", str12.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(collection17);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) (byte) 10, false);
        timeSeries9.setNotify(false);
        java.util.Collection collection16 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries9);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) year17);
        timeSeriesDataItem18.setValue((java.lang.Number) (byte) 1);
        boolean boolean22 = timeSeriesDataItem18.equals((java.lang.Object) (-1.0f));
        boolean boolean23 = timeSeriesDataItem18.isSelected();
        boolean boolean24 = timeSeriesDataItem18.isSelected();
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertNotNull(timeSeriesDataItem18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Date date2 = fixedMillisecond1.getTime();
        long long3 = fixedMillisecond1.getFirstMillisecond();
        java.util.Date date4 = fixedMillisecond1.getTime();
        java.lang.Object obj5 = null;
        int int6 = fixedMillisecond1.compareTo(obj5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        java.util.Date date8 = year7.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.lang.String str10 = day9.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day9.next();
        boolean boolean12 = fixedMillisecond1.equals((java.lang.Object) regularTimePeriod11);
        long long13 = fixedMillisecond1.getSerialIndex();
        java.util.Date date14 = fixedMillisecond1.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond1.previous();
        java.util.Calendar calendar16 = null;
        long long17 = fixedMillisecond1.getFirstMillisecond(calendar16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Date date20 = fixedMillisecond19.getTime();
        java.util.Date date21 = fixedMillisecond19.getTime();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date21);
        boolean boolean23 = fixedMillisecond1.equals((java.lang.Object) date21);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 100L + "'", long13 == 100L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 100L + "'", long17 == 100L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Date date2 = fixedMillisecond1.getTime();
        long long3 = fixedMillisecond1.getFirstMillisecond();
        java.util.Date date4 = fixedMillisecond1.getTime();
        java.lang.Object obj5 = null;
        int int6 = fixedMillisecond1.compareTo(obj5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond1.next();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
        java.util.Date date5 = regularTimePeriod4.getStart();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date5);
        java.lang.String str7 = timeSeries6.getDescription();
        java.lang.String str8 = timeSeries6.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        java.util.Date date12 = year11.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (java.lang.Number) 0.0f);
        boolean boolean16 = timeSeries10.getNotify();
        java.lang.Object obj17 = timeSeries10.clone();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        java.util.Date date19 = year18.getEnd();
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date19);
        long long21 = day20.getSerialIndex();
        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) day20);
        java.lang.Object obj23 = timeSeries10.clone();
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries6.addAndOrUpdate(timeSeries10);
        java.beans.PropertyChangeListener propertyChangeListener25 = null;
        timeSeries24.addPropertyChangeListener(propertyChangeListener25);
        timeSeries24.removeAgedItems(false);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Value" + "'", str8.equals("Value"));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 43830L + "'", long21 == 43830L);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertNotNull(timeSeries24);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.removeChangeListener(seriesChangeListener6);
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener8);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("org.jfree.data.event.SeriesChangeEvent[source=class org.jfree.data.time.Year]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the month.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setRangeDescription("hi!");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener8);
        timeSeries1.removeAgedItems(1560185128766L, false);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=class org.jfree.data.time.Year]");
    }

//    @Test
//    public void test020() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test020");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.util.Date date1 = year0.getEnd();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        java.lang.String str3 = day2.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
//        int int6 = day2.compareTo((java.lang.Object) 1L);
//        long long7 = day2.getLastMillisecond();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int9 = day2.compareTo((java.lang.Object) day8);
//        int int10 = day2.getDayOfMonth();
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
//        timeSeries12.add((org.jfree.data.time.RegularTimePeriod) month13, (java.lang.Number) (byte) 10, false);
//        timeSeries12.setRangeDescription("hi!");
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
//        java.util.Date date22 = year21.getEnd();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
//        java.lang.String str24 = day23.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day23.next();
//        int int26 = day23.getMonth();
//        timeSeries20.add((org.jfree.data.time.RegularTimePeriod) day23, (double) 100);
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
//        java.util.Date date30 = year29.getEnd();
//        boolean boolean32 = year29.equals((java.lang.Object) (-1.0d));
//        int int34 = year29.compareTo((java.lang.Object) 1.0d);
//        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
//        java.util.Date date36 = year35.getEnd();
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date36);
//        java.lang.String str38 = day37.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = day37.next();
//        int int40 = day37.getMonth();
//        java.lang.String str41 = day37.toString();
//        org.jfree.data.time.TimeSeries timeSeries42 = timeSeries20.createCopy((org.jfree.data.time.RegularTimePeriod) year29, (org.jfree.data.time.RegularTimePeriod) day37);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries20.getDataItem((int) (byte) 0);
//        java.util.Collection collection45 = timeSeries12.getTimePeriodsUniqueToOtherSeries(timeSeries20);
//        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month46);
//        int int48 = month46.getMonth();
//        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
//        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month();
//        timeSeries50.add((org.jfree.data.time.RegularTimePeriod) month51, (java.lang.Number) (byte) 10, false);
//        timeSeries50.setNotify(false);
//        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
//        org.jfree.data.time.Month month59 = new org.jfree.data.time.Month();
//        timeSeries58.add((org.jfree.data.time.RegularTimePeriod) month59, (java.lang.Number) (byte) 10, false);
//        timeSeries58.setNotify(false);
//        java.util.Collection collection65 = timeSeries50.getTimePeriodsUniqueToOtherSeries(timeSeries58);
//        org.jfree.data.time.Year year66 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem67 = timeSeries58.getDataItem((org.jfree.data.time.RegularTimePeriod) year66);
//        java.lang.Object obj68 = timeSeriesDataItem67.clone();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = timeSeriesDataItem67.getPeriod();
//        org.jfree.data.time.TimeSeries timeSeries70 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) month46, regularTimePeriod69);
//        boolean boolean71 = day2.equals((java.lang.Object) month46);
//        int int73 = month46.compareTo((java.lang.Object) 3);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 204 + "'", int9 == 204);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 31 + "'", int10 == 31);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "31-December-2019" + "'", str24.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 12 + "'", int26 == 12);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "31-December-2019" + "'", str38.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 12 + "'", int40 == 12);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "31-December-2019" + "'", str41.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(timeSeries42);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem44);
//        org.junit.Assert.assertNotNull(collection45);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 6 + "'", int48 == 6);
//        org.junit.Assert.assertNotNull(collection65);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem67);
//        org.junit.Assert.assertNotNull(obj68);
//        org.junit.Assert.assertNotNull(regularTimePeriod69);
//        org.junit.Assert.assertNotNull(timeSeries70);
//        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 1 + "'", int73 == 1);
//    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.Year year9 = org.jfree.data.time.Year.parseYear("2019");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) year9);
        timeSeries1.setNotify(true);
        java.lang.String str13 = timeSeries1.getDomainDescription();
        timeSeries1.setDomainDescription("");
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Time" + "'", str13.equals("Time"));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        java.lang.String str5 = day4.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day4.next();
        int int7 = day4.getMonth();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (double) 100);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries1.addChangeListener(seriesChangeListener10);
        timeSeries1.removeAgedItems(false);
        long long14 = timeSeries1.getMaximumItemAge();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "31-December-2019" + "'", str5.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 9223372036854775807L + "'", long14 == 9223372036854775807L);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        java.lang.String str6 = month2.toString();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        java.lang.String str12 = day11.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day11.next();
        int int14 = day11.getMonth();
        timeSeries8.add((org.jfree.data.time.RegularTimePeriod) day11, (double) 100);
        boolean boolean17 = month2.equals((java.lang.Object) 100);
        java.util.Calendar calendar18 = null;
        try {
            long long19 = month2.getLastMillisecond(calendar18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "31-December-2019" + "'", str12.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 12 + "'", int14 == 12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        java.lang.Object obj8 = timeSeries1.clone();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        long long12 = day11.getSerialIndex();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day11);
        java.lang.Object obj14 = timeSeries1.clone();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        java.util.Date date17 = year16.getEnd();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 1, year16);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) year16);
        java.util.Date date20 = year16.getEnd();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43830L + "'", long12 == 43830L);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(date20);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) 0.0f);
        boolean boolean13 = timeSeries7.getNotify();
        java.lang.Object obj14 = timeSeries7.clone();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        timeSeries16.add((org.jfree.data.time.RegularTimePeriod) month17, (java.lang.Number) (byte) 10, false);
        timeSeries16.setNotify(false);
        java.util.Collection collection23 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries16);
        int int24 = month2.compareTo((java.lang.Object) timeSeries7);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException28 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException30 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException28.addSuppressed((java.lang.Throwable) timePeriodFormatException30);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException33 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException35 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException33.addSuppressed((java.lang.Throwable) timePeriodFormatException35);
        timePeriodFormatException28.addSuppressed((java.lang.Throwable) timePeriodFormatException33);
        int int38 = year26.compareTo((java.lang.Object) timePeriodFormatException28);
        int int39 = month2.compareTo((java.lang.Object) int38);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(collection23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        java.lang.Object obj8 = timeSeries1.clone();
        timeSeries1.setNotify(false);
        timeSeries1.delete(0, 0, true);
        try {
            timeSeries1.update(0, (java.lang.Number) 1560185153555L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        java.lang.String str5 = day4.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day4.next();
        int int7 = day4.getMonth();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (double) 100);
        java.lang.String str10 = timeSeries1.getDescription();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.addOrUpdate(regularTimePeriod11, (double) 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "31-December-2019" + "'", str5.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        java.lang.String str5 = day4.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day4.next();
        int int7 = day4.getMonth();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (double) 100);
        timeSeries1.removeAgedItems(true);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "31-December-2019" + "'", str5.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Date date2 = fixedMillisecond1.getTime();
        long long3 = fixedMillisecond1.getFirstMillisecond();
        java.util.Date date4 = fixedMillisecond1.getTime();
        java.lang.Object obj5 = null;
        int int6 = fixedMillisecond1.compareTo(obj5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        java.util.Date date8 = year7.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.lang.String str10 = day9.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day9.next();
        boolean boolean12 = fixedMillisecond1.equals((java.lang.Object) regularTimePeriod11);
        long long13 = fixedMillisecond1.getSerialIndex();
        java.util.Date date14 = fixedMillisecond1.getTime();
        java.util.Date date15 = fixedMillisecond1.getEnd();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 100L + "'", long13 == 100L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(date15);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) (byte) 10, false);
        timeSeries9.setNotify(false);
        java.util.Collection collection16 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries9);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) year17);
        java.lang.String str19 = timeSeries9.getRangeDescription();
        long long20 = timeSeries9.getMaximumItemAge();
        timeSeries9.setDescription("org.jfree.data.time.TimePeriodFormatException: hi!");
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertNotNull(timeSeriesDataItem18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Value" + "'", str19.equals("Value"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 9223372036854775807L + "'", long20 == 9223372036854775807L);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.removeChangeListener(seriesChangeListener6);
        java.lang.Comparable comparable8 = timeSeries1.getKey();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        java.util.Date date12 = year11.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        java.lang.String str14 = day13.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day13.next();
        int int16 = day13.getMonth();
        timeSeries10.add((org.jfree.data.time.RegularTimePeriod) day13, (double) 100);
        long long19 = day13.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) day13);
        timeSeries1.removeAgedItems(false);
        boolean boolean23 = timeSeries1.isEmpty();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener24 = null;
        timeSeries1.addChangeListener(seriesChangeListener24);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 'a' + "'", comparable8.equals('a'));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "31-December-2019" + "'", str14.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 12 + "'", int16 == 12);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1577865599999L + "'", long19 == 1577865599999L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        java.lang.String str5 = day4.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day4.next();
        int int7 = day4.getMonth();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (double) 100);
        java.lang.Object obj10 = timeSeries1.clone();
        timeSeries1.removeAgedItems(43830L, true);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year15.next();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        java.util.Date date18 = year17.getEnd();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
        long long20 = day19.getLastMillisecond();
        int int21 = year15.compareTo((java.lang.Object) day19);
        java.lang.String str22 = year15.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) year15);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "31-December-2019" + "'", str5.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1577865599999L + "'", long20 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "35" + "'", str22.equals("35"));
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(2019);
        long long2 = year1.getLastMillisecond();
        int int3 = year1.getYear();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) (byte) 10, false);
        timeSeries9.setNotify(false);
        java.util.Collection collection16 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries9);
        boolean boolean17 = timeSeries9.getNotify();
        timeSeries9.removeAgedItems(true);
        timeSeries9.removeAgedItems(false);
        java.lang.Comparable comparable22 = timeSeries9.getKey();
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
        timeSeries24.add((org.jfree.data.time.RegularTimePeriod) month25, (java.lang.Number) (byte) 10, false);
        timeSeries24.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
        timeSeries32.add((org.jfree.data.time.RegularTimePeriod) month33, (java.lang.Number) (byte) 10, false);
        timeSeries32.setNotify(false);
        java.util.Collection collection39 = timeSeries24.getTimePeriodsUniqueToOtherSeries(timeSeries32);
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries32.getDataItem((org.jfree.data.time.RegularTimePeriod) year40);
        java.lang.Object obj42 = timeSeriesDataItem41.clone();
        timeSeriesDataItem41.setSelected(false);
        java.lang.Number number45 = timeSeriesDataItem41.getValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = timeSeries9.addOrUpdate(timeSeriesDataItem41);
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + comparable22 + "' != '" + 'a' + "'", comparable22.equals('a'));
        org.junit.Assert.assertNotNull(collection39);
        org.junit.Assert.assertNotNull(timeSeriesDataItem41);
        org.junit.Assert.assertNotNull(obj42);
        org.junit.Assert.assertTrue("'" + number45 + "' != '" + (byte) 10 + "'", number45.equals((byte) 10));
        org.junit.Assert.assertNotNull(timeSeriesDataItem46);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (double) 31);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (short) 1, year1);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.util.Date date7 = year6.getEnd();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date7);
        java.lang.String str9 = day8.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day8.next();
        int int11 = day8.getMonth();
        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) day8, (double) 100);
        boolean boolean14 = year1.equals((java.lang.Object) day8);
        org.jfree.data.time.SerialDate serialDate15 = day8.getSerialDate();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(serialDate15);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "31-December-2019" + "'", str9.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 12 + "'", int11 == 12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(serialDate15);
    }

//    @Test
//    public void test038() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test038");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) day0, seriesChangeInfo1);
//        java.lang.String str3 = seriesChangeEvent2.toString();
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=10-June-2019]" + "'", str3.equals("org.jfree.data.event.SeriesChangeEvent[source=10-June-2019]"));
//    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
        java.util.Date date5 = regularTimePeriod4.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date5);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) (byte) 10, false);
        timeSeries9.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries9.addPropertyChangeListener(propertyChangeListener16);
        int int18 = month7.compareTo((java.lang.Object) timeSeries9);
        long long19 = month7.getLastMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1580543999999L + "'", long19 == 1580543999999L);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date1);
        int int5 = day4.getDayOfMonth();
        java.util.Date date6 = day4.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("2019");
        boolean boolean10 = month7.equals((java.lang.Object) timePeriodFormatException9);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 31 + "'", int5 == 31);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        timeSeries4.add((org.jfree.data.time.RegularTimePeriod) month5, (java.lang.Number) (byte) 10, false);
        timeSeries4.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        timeSeries12.add((org.jfree.data.time.RegularTimePeriod) month13, (java.lang.Number) (byte) 10, false);
        timeSeries12.setNotify(false);
        java.util.Collection collection19 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries12);
        timeSeries12.setNotify(false);
        boolean boolean22 = year1.equals((java.lang.Object) false);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) (byte) 10, false);
        timeSeries9.setNotify(false);
        java.util.Collection collection16 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries9);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) year17);
        timeSeriesDataItem18.setValue((java.lang.Number) (byte) 1);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo22 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent23 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (short) 1, seriesChangeInfo22);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo24 = seriesChangeEvent23.getSummary();
        int int25 = timeSeriesDataItem18.compareTo((java.lang.Object) seriesChangeInfo24);
        timeSeriesDataItem18.setValue((java.lang.Number) 1.0d);
        timeSeriesDataItem18.setValue((java.lang.Number) 1561964399999L);
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertNotNull(timeSeriesDataItem18);
        org.junit.Assert.assertNull(seriesChangeInfo24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        java.lang.String str13 = day12.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day12.next();
        int int15 = day12.getMonth();
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) day12, (double) 100);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        java.util.Date date19 = year18.getEnd();
        boolean boolean21 = year18.equals((java.lang.Object) (-1.0d));
        int int23 = year18.compareTo((java.lang.Object) 1.0d);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        java.util.Date date25 = year24.getEnd();
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date25);
        java.lang.String str27 = day26.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day26.next();
        int int29 = day26.getMonth();
        java.lang.String str30 = day26.toString();
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries9.createCopy((org.jfree.data.time.RegularTimePeriod) year18, (org.jfree.data.time.RegularTimePeriod) day26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries9.getDataItem((int) (byte) 0);
        java.util.Collection collection34 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries9);
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month35);
        int int37 = month35.getMonth();
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month();
        timeSeries39.add((org.jfree.data.time.RegularTimePeriod) month40, (java.lang.Number) (byte) 10, false);
        timeSeries39.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month();
        timeSeries47.add((org.jfree.data.time.RegularTimePeriod) month48, (java.lang.Number) (byte) 10, false);
        timeSeries47.setNotify(false);
        java.util.Collection collection54 = timeSeries39.getTimePeriodsUniqueToOtherSeries(timeSeries47);
        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem56 = timeSeries47.getDataItem((org.jfree.data.time.RegularTimePeriod) year55);
        java.lang.Object obj57 = timeSeriesDataItem56.clone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = timeSeriesDataItem56.getPeriod();
        org.jfree.data.time.TimeSeries timeSeries59 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month35, regularTimePeriod58);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener60 = null;
        timeSeries1.addChangeListener(seriesChangeListener60);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "31-December-2019" + "'", str13.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 12 + "'", int15 == 12);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "31-December-2019" + "'", str27.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 12 + "'", int29 == 12);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "31-December-2019" + "'", str30.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(timeSeries31);
        org.junit.Assert.assertNotNull(timeSeriesDataItem33);
        org.junit.Assert.assertNotNull(collection34);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 6 + "'", int37 == 6);
        org.junit.Assert.assertNotNull(collection54);
        org.junit.Assert.assertNotNull(timeSeriesDataItem56);
        org.junit.Assert.assertNotNull(obj57);
        org.junit.Assert.assertNotNull(regularTimePeriod58);
        org.junit.Assert.assertNotNull(timeSeries59);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("31-December-2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the month.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
        java.util.Date date5 = regularTimePeriod4.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date5);
        java.lang.String str8 = month7.toString();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = month7.getLastMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "January 2020" + "'", str8.equals("January 2020"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Date date2 = fixedMillisecond1.getTime();
        long long3 = fixedMillisecond1.getFirstMillisecond();
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond1.previous();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) fixedMillisecond1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
        java.util.Date date5 = regularTimePeriod4.getStart();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date5);
        java.util.Collection collection7 = timeSeries6.getTimePeriods();
        java.lang.String str8 = timeSeries6.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        timeSeries10.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) (byte) 10, false);
        timeSeries10.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
        timeSeries18.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) (byte) 10, false);
        timeSeries18.setNotify(false);
        java.util.Collection collection25 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        boolean boolean26 = timeSeries18.getNotify();
        boolean boolean27 = timeSeries6.equals((java.lang.Object) boolean26);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(collection7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Value" + "'", str8.equals("Value"));
        org.junit.Assert.assertNotNull(collection25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) (byte) 10, false);
        timeSeries9.setNotify(false);
        java.util.Collection collection16 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries9);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
        timeSeries18.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) (byte) 10, false);
        int int23 = month19.getMonth();
        org.jfree.data.time.Year year24 = month19.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year24.next();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
        timeSeries27.add((org.jfree.data.time.RegularTimePeriod) month28, (java.lang.Number) (byte) 10, false);
        timeSeries27.setNotify(false);
        double double34 = timeSeries27.getMinY();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener35 = null;
        timeSeries27.removeChangeListener(seriesChangeListener35);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = timeSeries27.getNextTimePeriod();
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries1.createCopy(regularTimePeriod25, regularTimePeriod37);
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 6 + "'", int23 == 6);
        org.junit.Assert.assertNotNull(year24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 10.0d + "'", double34 == 10.0d);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(timeSeries38);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 2);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 0, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560185118796L);
        long long2 = fixedMillisecond1.getFirstMillisecond();
        long long3 = fixedMillisecond1.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560185118796L + "'", long2 == 1560185118796L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560185118796L + "'", long3 == 1560185118796L);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setRangeDescription("hi!");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeries1.getNextTimePeriod();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        java.lang.String str12 = day11.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day11.next();
        java.util.Date date14 = regularTimePeriod13.getStart();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date14);
        java.lang.String str16 = timeSeries15.getDescription();
        java.util.Collection collection17 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries15);
        timeSeries1.setNotify(false);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "31-December-2019" + "'", str12.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(collection17);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        long long2 = month0.getFirstMillisecond();
        java.lang.String str3 = month0.toString();
        long long4 = month0.getFirstMillisecond();
        int int5 = month0.getMonth();
        int int6 = month0.getMonth();
        org.jfree.data.time.Year year7 = month0.getYear();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1559372400000L + "'", long2 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1559372400000L + "'", long4 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertNotNull(year7);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        java.lang.Object obj8 = timeSeries1.clone();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        long long12 = day11.getSerialIndex();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day11);
        java.util.Calendar calendar14 = null;
        try {
            day11.peg(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43830L + "'", long12 == 43830L);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.Year year9 = org.jfree.data.time.Year.parseYear("2019");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) year9);
        timeSeries1.setNotify(true);
        java.lang.String str13 = timeSeries1.getDomainDescription();
        java.lang.Class class14 = timeSeries1.getTimePeriodClass();
        timeSeries1.clear();
        timeSeries1.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: hi!");
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        java.util.Date date19 = year18.getEnd();
        long long20 = year18.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year18.next();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) 100L);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Time" + "'", str13.equals("Time"));
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1577865599999L + "'", long20 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        java.lang.String str5 = day4.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day4.next();
        int int7 = day4.getMonth();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (double) 100);
        long long10 = day4.getLastMillisecond();
        long long11 = day4.getSerialIndex();
        int int12 = day4.getYear();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "31-December-2019" + "'", str5.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 43830L + "'", long11 == 43830L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        long long2 = year0.getLastMillisecond();
        long long3 = year0.getLastMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        java.lang.Object obj8 = timeSeries1.clone();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        timeSeries10.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) (byte) 10, false);
        timeSeries10.setNotify(false);
        java.util.Collection collection17 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries10);
        timeSeries1.setDomainDescription("");
        java.util.Collection collection20 = timeSeries1.getTimePeriods();
        java.lang.Class class21 = timeSeries1.getTimePeriodClass();
        long long22 = timeSeries1.getMaximumItemAge();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertNotNull(collection20);
        org.junit.Assert.assertNotNull(class21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 9223372036854775807L + "'", long22 == 9223372036854775807L);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("35");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 5");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        java.lang.String str3 = year1.toString();
        java.lang.String str4 = year1.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "35" + "'", str3.equals("35"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "35" + "'", str4.equals("35"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 9999);
        java.util.Calendar calendar3 = null;
        try {
            year0.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        java.lang.Object obj8 = timeSeries1.clone();
        timeSeries1.setNotify(false);
        timeSeries1.delete(0, 0, true);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Date date17 = fixedMillisecond16.getTime();
        int int18 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries1.getDataItem(35);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
        int int5 = day2.getMonth();
        java.lang.String str6 = day2.toString();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day2, "", "org.jfree.data.event.SeriesChangeEvent[source=1]");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day2, (java.lang.Number) (-1L));
        java.util.Calendar calendar12 = null;
        try {
            long long13 = day2.getMiddleMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "31-December-2019" + "'", str6.equals("31-December-2019"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.removeChangeListener(seriesChangeListener6);
        java.lang.Comparable comparable8 = timeSeries1.getKey();
        timeSeries1.setMaximumItemCount((int) (short) 100);
        timeSeries1.setRangeDescription("31-December-2019");
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.createCopy((int) (short) 0, 0);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year17.next();
        java.lang.String str19 = year17.toString();
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year17, (double) 1L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 'a' + "'", comparable8.equals('a'));
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "35" + "'", str19.equals("35"));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        int int6 = month2.getMonth();
        org.jfree.data.time.Year year7 = month2.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.next();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo9 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year7, seriesChangeInfo9);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
        java.util.Date date5 = regularTimePeriod4.getStart();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date5);
        java.lang.String str7 = timeSeries6.getDescription();
        java.lang.String str8 = timeSeries6.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        java.util.Date date12 = year11.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (java.lang.Number) 0.0f);
        boolean boolean16 = timeSeries10.getNotify();
        java.lang.Object obj17 = timeSeries10.clone();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        java.util.Date date19 = year18.getEnd();
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date19);
        long long21 = day20.getSerialIndex();
        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) day20);
        java.lang.Object obj23 = timeSeries10.clone();
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries6.addAndOrUpdate(timeSeries10);
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        timeSeries26.add((org.jfree.data.time.RegularTimePeriod) month27, (java.lang.Number) (byte) 10, false);
        timeSeries26.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month();
        timeSeries34.add((org.jfree.data.time.RegularTimePeriod) month35, (java.lang.Number) (byte) 10, false);
        timeSeries34.setNotify(false);
        java.util.Collection collection41 = timeSeries26.getTimePeriodsUniqueToOtherSeries(timeSeries34);
        boolean boolean42 = timeSeries26.getNotify();
        timeSeries26.removeAgedItems((long) 'a', true);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = timeSeries26.getNextTimePeriod();
        java.lang.String str47 = regularTimePeriod46.toString();
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year();
        java.util.Date date49 = year48.getEnd();
        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(date49);
        java.lang.String str51 = day50.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = day50.next();
        int int53 = day50.getMonth();
        java.lang.String str54 = day50.toString();
        org.jfree.data.time.TimeSeries timeSeries57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day50, "", "org.jfree.data.event.SeriesChangeEvent[source=1]");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day50, (java.lang.Number) (-1L));
        org.jfree.data.time.TimeSeries timeSeries60 = timeSeries6.createCopy(regularTimePeriod46, (org.jfree.data.time.RegularTimePeriod) day50);
        org.jfree.data.time.FixedMillisecond fixedMillisecond62 = new org.jfree.data.time.FixedMillisecond((-1L));
        timeSeries6.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond62);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Value" + "'", str8.equals("Value"));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 43830L + "'", long21 == 43830L);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertNotNull(timeSeries24);
        org.junit.Assert.assertNotNull(collection41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "July 2019" + "'", str47.equals("July 2019"));
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "31-December-2019" + "'", str51.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 12 + "'", int53 == 12);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "31-December-2019" + "'", str54.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(timeSeries60);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) 0.0f);
        boolean boolean13 = timeSeries7.getNotify();
        java.lang.Object obj14 = timeSeries7.clone();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        timeSeries16.add((org.jfree.data.time.RegularTimePeriod) month17, (java.lang.Number) (byte) 10, false);
        timeSeries16.setNotify(false);
        java.util.Collection collection23 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries16);
        int int24 = month2.compareTo((java.lang.Object) timeSeries7);
        java.util.Date date25 = month2.getStart();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(date25);
        java.lang.String str27 = month26.toString();
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(collection23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "June 2019" + "'", str27.equals("June 2019"));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        java.lang.String str6 = month2.toString();
        int int7 = month2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month2.next();
        long long10 = month2.getSerialIndex();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 24234L + "'", long10 == 24234L);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        long long2 = month0.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Date date2 = fixedMillisecond1.getTime();
        long long3 = fixedMillisecond1.getFirstMillisecond();
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond1.previous();
        java.lang.Number number6 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod5, number6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

//    @Test
//    public void test071() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test071");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "2019", "");
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
//        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) (byte) 10, false);
//        timeSeries5.setNotify(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar13 = null;
//        long long14 = fixedMillisecond12.getFirstMillisecond(calendar13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries5.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
//        timeSeries3.add(timeSeriesDataItem15, true);
//        java.lang.Number number18 = timeSeriesDataItem15.getValue();
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560185191860L + "'", long14 == 1560185191860L);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem15);
//        org.junit.Assert.assertTrue("'" + number18 + "' != '" + (byte) 10 + "'", number18.equals((byte) 10));
//    }

//    @Test
//    public void test072() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test072");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.util.Date date1 = year0.getEnd();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        java.lang.String str3 = day2.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
//        int int6 = day2.compareTo((java.lang.Object) 1L);
//        long long7 = day2.getLastMillisecond();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int9 = day2.compareTo((java.lang.Object) day8);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day8.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day8.next();
//        org.jfree.data.time.SerialDate serialDate12 = day8.getSerialDate();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 204 + "'", int9 == 204);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(serialDate12);
//    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass1 = year0.getClass();
        java.lang.Class class2 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) wildcardClass1);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        java.util.Date date5 = year4.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date5);
        int int9 = day8.getDayOfMonth();
        java.util.Date date10 = day8.getEnd();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass1, date10, timeZone11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(date10);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 31 + "'", int9 == 31);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod12);
    }

//    @Test
//    public void test074() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test074");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "2019", "");
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
//        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) (byte) 10, false);
//        timeSeries5.setNotify(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar13 = null;
//        long long14 = fixedMillisecond12.getFirstMillisecond(calendar13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries5.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
//        timeSeries3.add(timeSeriesDataItem15, true);
//        java.lang.String str18 = timeSeries3.getDomainDescription();
//        try {
//            timeSeries3.delete(100, (int) ' ', true);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560185192023L + "'", long14 == 1560185192023L);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem15);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "2019" + "'", str18.equals("2019"));
//    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.removeChangeListener(seriesChangeListener6);
        timeSeries1.setDomainDescription("31-December-2019");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.getDataItem(0);
        org.junit.Assert.assertNotNull(timeSeriesDataItem11);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
        int int5 = day2.getMonth();
        java.lang.String str6 = day2.toString();
        org.jfree.data.time.SerialDate serialDate7 = day2.getSerialDate();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(serialDate7);
        long long9 = day8.getFirstMillisecond();
        long long10 = day8.getLastMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "31-December-2019" + "'", str6.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577779200000L + "'", long9 == 1577779200000L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        java.lang.Object obj8 = timeSeries1.clone();
        timeSeries1.setNotify(false);
        timeSeries1.delete(0, 0, true);
        java.lang.Class class15 = timeSeries1.getTimePeriodClass();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNull(class15);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        int int3 = timeSeries2.getMaximumItemCount();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2147483647 + "'", int3 == 2147483647);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) (byte) 10, false);
        timeSeries9.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        timeSeries17.add((org.jfree.data.time.RegularTimePeriod) month18, (java.lang.Number) (byte) 10, false);
        timeSeries17.setNotify(false);
        java.util.Collection collection24 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries17);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries17.getDataItem((org.jfree.data.time.RegularTimePeriod) year25);
        java.lang.Object obj27 = timeSeriesDataItem26.clone();
        java.lang.Number number28 = timeSeriesDataItem26.getValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries1.addOrUpdate(timeSeriesDataItem26);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = year31.next();
        java.lang.String str33 = year31.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = year31.next();
        java.lang.String str35 = year31.toString();
        java.lang.Class<?> wildcardClass36 = year31.getClass();
        int int38 = year31.compareTo((java.lang.Object) 1560185136721L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = year31.next();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year31, (java.lang.Number) 9999);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(collection24);
        org.junit.Assert.assertNotNull(timeSeriesDataItem26);
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertTrue("'" + number28 + "' != '" + (byte) 10 + "'", number28.equals((byte) 10));
        org.junit.Assert.assertNotNull(timeSeriesDataItem29);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "35" + "'", str33.equals("35"));
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "35" + "'", str35.equals("35"));
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        java.lang.Object obj8 = timeSeries1.clone();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        long long12 = day11.getSerialIndex();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day11);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) month14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month14, (java.lang.Number) 1.0d);
        org.jfree.data.time.Year year18 = month14.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = month14.next();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43830L + "'", long12 == 43830L);
        org.junit.Assert.assertNotNull(year18);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.removeChangeListener(seriesChangeListener6);
        timeSeries1.setDomainDescription("31-December-2019");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = timeSeries1.getNextTimePeriod();
        java.util.List list11 = timeSeries1.getItems();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        timeSeries13.add((org.jfree.data.time.RegularTimePeriod) month14, (java.lang.Number) (byte) 10, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries13.removeChangeListener(seriesChangeListener18);
        org.jfree.data.time.Year year21 = org.jfree.data.time.Year.parseYear("2019");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) year21);
        timeSeries13.setNotify(true);
        java.lang.String str25 = timeSeries13.getDomainDescription();
        java.lang.Class class26 = timeSeries13.getTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = timeSeries13.getNextTimePeriod();
        timeSeries1.add(regularTimePeriod27, (java.lang.Number) 1560185118796L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertNotNull(year21);
        org.junit.Assert.assertNotNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Time" + "'", str25.equals("Time"));
        org.junit.Assert.assertNotNull(class26);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        java.lang.Object obj8 = timeSeries1.clone();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        timeSeries10.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) (byte) 10, false);
        timeSeries10.setNotify(false);
        java.util.Collection collection17 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries10);
        timeSeries1.setDomainDescription("");
        java.util.Collection collection20 = timeSeries1.getTimePeriods();
        long long21 = timeSeries1.getMaximumItemAge();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        java.util.Date date23 = year22.getEnd();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date23);
        java.lang.String str25 = day24.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = day24.next();
        int int27 = day24.getMonth();
        java.lang.String str28 = day24.toString();
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day24, "", "org.jfree.data.event.SeriesChangeEvent[source=1]");
        org.jfree.data.time.SerialDate serialDate32 = day24.getSerialDate();
        java.lang.String str33 = day24.toString();
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) day24, (java.lang.Number) 31);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener36 = null;
        timeSeries1.removeChangeListener(seriesChangeListener36);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertNotNull(collection20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 9223372036854775807L + "'", long21 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "31-December-2019" + "'", str25.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 12 + "'", int27 == 12);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "31-December-2019" + "'", str28.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "31-December-2019" + "'", str33.equals("31-December-2019"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        java.lang.Object obj8 = timeSeries1.clone();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        timeSeries10.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) (byte) 10, false);
        timeSeries10.setNotify(false);
        java.util.Collection collection17 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries10);
        boolean boolean18 = timeSeries1.isEmpty();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) (byte) 10, false);
        timeSeries9.setNotify(false);
        java.util.Collection collection16 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries9);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) year17);
        java.lang.String str19 = timeSeries9.getRangeDescription();
        long long20 = timeSeries9.getMaximumItemAge();
        try {
            java.lang.Number number22 = timeSeries9.getValue(35);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertNotNull(timeSeriesDataItem18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Value" + "'", str19.equals("Value"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 9223372036854775807L + "'", long20 == 9223372036854775807L);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0);
        long long2 = month0.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.previous();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24234L + "'", long2 == 24234L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        double double2 = timeSeries1.getMinY();
        double double3 = timeSeries1.getMinY();
        long long4 = timeSeries1.getMaximumItemAge();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        org.jfree.data.time.Year year2 = month0.getYear();
        java.util.Date date3 = month0.getStart();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        long long5 = day4.getSerialIndex();
        long long6 = day4.getFirstMillisecond();
        int int7 = day4.getMonth();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43617L + "'", long5 == 43617L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1559372400000L + "'", long6 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        long long3 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getFirstMillisecond(calendar4);
        long long6 = fixedMillisecond1.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 100L + "'", long5 == 100L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (short) 1, year1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.previous();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        java.lang.String str13 = day12.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day12.next();
        int int15 = day12.getMonth();
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) day12, (double) 100);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        java.util.Date date19 = year18.getEnd();
        boolean boolean21 = year18.equals((java.lang.Object) (-1.0d));
        int int23 = year18.compareTo((java.lang.Object) 1.0d);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        java.util.Date date25 = year24.getEnd();
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date25);
        java.lang.String str27 = day26.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day26.next();
        int int29 = day26.getMonth();
        java.lang.String str30 = day26.toString();
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries9.createCopy((org.jfree.data.time.RegularTimePeriod) year18, (org.jfree.data.time.RegularTimePeriod) day26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries9.getDataItem((int) (byte) 0);
        java.util.Collection collection34 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries9);
        java.lang.String str35 = timeSeries1.getDescription();
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "31-December-2019" + "'", str13.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 12 + "'", int15 == 12);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "31-December-2019" + "'", str27.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 12 + "'", int29 == 12);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "31-December-2019" + "'", str30.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(timeSeries31);
        org.junit.Assert.assertNotNull(timeSeriesDataItem33);
        org.junit.Assert.assertNotNull(collection34);
        org.junit.Assert.assertNull(str35);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        java.lang.String str5 = day4.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day4.next();
        int int7 = day4.getMonth();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (double) 100);
        java.lang.Object obj10 = timeSeries1.clone();
        timeSeries1.setDomainDescription("");
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "31-December-2019" + "'", str5.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.util.Date date4 = year3.getEnd();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        long long6 = day5.getLastMillisecond();
        int int7 = year1.compareTo((java.lang.Object) day5);
        long long8 = day5.getSerialIndex();
        org.jfree.data.time.SerialDate serialDate9 = day5.getSerialDate();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 43830L + "'", long8 == 43830L);
        org.junit.Assert.assertNotNull(serialDate9);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.util.Date date4 = year3.getEnd();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        long long6 = day5.getLastMillisecond();
        int int7 = year1.compareTo((java.lang.Object) day5);
        java.lang.String str8 = year1.toString();
        long long9 = year1.getMiddleMillisecond();
        int int10 = year1.getYear();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "35" + "'", str8.equals("35"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61047057600001L) + "'", long9 == (-61047057600001L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 35 + "'", int10 == 35);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "2019", "");
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        timeSeries3.removeAgedItems(false);
        java.lang.Class<?> wildcardClass7 = timeSeries3.getClass();
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        java.lang.Object obj8 = timeSeries1.clone();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        long long12 = day11.getSerialIndex();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day11);
        java.lang.Object obj14 = timeSeries1.clone();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        java.util.Date date17 = year16.getEnd();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 1, year16);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) year16);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year16);
        timeSeries20.setKey((java.lang.Comparable) 100L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43830L + "'", long12 == 43830L);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(date17);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (short) 1, seriesChangeInfo1);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo3 = seriesChangeEvent2.getSummary();
        java.lang.String str4 = seriesChangeEvent2.toString();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo5 = null;
        seriesChangeEvent2.setSummary(seriesChangeInfo5);
        java.lang.Object obj7 = seriesChangeEvent2.getSource();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo8 = seriesChangeEvent2.getSummary();
        org.junit.Assert.assertNull(seriesChangeInfo3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=1]" + "'", str4.equals("org.jfree.data.event.SeriesChangeEvent[source=1]"));
        org.junit.Assert.assertTrue("'" + obj7 + "' != '" + (short) 1 + "'", obj7.equals((short) 1));
        org.junit.Assert.assertNull(seriesChangeInfo8);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        java.lang.String str4 = day2.toString();
        java.lang.Object obj5 = null;
        boolean boolean6 = day2.equals(obj5);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "31-December-2019" + "'", str4.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (short) 1, year1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod4, 0.0d);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month7);
        boolean boolean9 = timeSeriesDataItem6.equals((java.lang.Object) timeSeries8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = timeSeriesDataItem6.getPeriod();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        java.util.Date date14 = year13.getEnd();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
        java.lang.String str16 = day15.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day15.next();
        int int18 = day15.getMonth();
        timeSeries12.add((org.jfree.data.time.RegularTimePeriod) day15, (double) 100);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        java.util.Date date22 = year21.getEnd();
        boolean boolean24 = year21.equals((java.lang.Object) (-1.0d));
        int int26 = year21.compareTo((java.lang.Object) 1.0d);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        java.util.Date date28 = year27.getEnd();
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date28);
        java.lang.String str30 = day29.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = day29.next();
        int int32 = day29.getMonth();
        java.lang.String str33 = day29.toString();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) year21, (org.jfree.data.time.RegularTimePeriod) day29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = day29.next();
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month();
        timeSeries37.add((org.jfree.data.time.RegularTimePeriod) month38, (java.lang.Number) (byte) 10, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener42 = null;
        timeSeries37.removeChangeListener(seriesChangeListener42);
        java.lang.Comparable comparable44 = timeSeries37.getKey();
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year();
        java.util.Date date48 = year47.getEnd();
        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day(date48);
        java.lang.String str50 = day49.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = day49.next();
        int int52 = day49.getMonth();
        timeSeries46.add((org.jfree.data.time.RegularTimePeriod) day49, (double) 100);
        long long55 = day49.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem56 = timeSeries37.getDataItem((org.jfree.data.time.RegularTimePeriod) day49);
        long long57 = day49.getFirstMillisecond();
        int int58 = day29.compareTo((java.lang.Object) day49);
        int int59 = timeSeriesDataItem6.compareTo((java.lang.Object) day49);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = day49.next();
        java.util.Date date61 = regularTimePeriod60.getStart();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "31-December-2019" + "'", str16.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 12 + "'", int18 == 12);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "31-December-2019" + "'", str30.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 12 + "'", int32 == 12);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "31-December-2019" + "'", str33.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertTrue("'" + comparable44 + "' != '" + 'a' + "'", comparable44.equals('a'));
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "31-December-2019" + "'", str50.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 12 + "'", int52 == 12);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1577865599999L + "'", long55 == 1577865599999L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem56);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1577779200000L + "'", long57 == 1577779200000L);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod60);
        org.junit.Assert.assertNotNull(date61);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        int int8 = timeSeries1.getItemCount();
        timeSeries1.setMaximumItemAge(1560185142033L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(9999);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        long long2 = month0.getFirstMillisecond();
        java.lang.String str3 = month0.toString();
        long long4 = month0.getFirstMillisecond();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = month0.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1559372400000L + "'", long2 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1559372400000L + "'", long4 == 1559372400000L);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        double double2 = timeSeries1.getMinY();
        double double3 = timeSeries1.getMinY();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        java.util.Date date5 = year4.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        java.lang.String str7 = day6.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day6.next();
        timeSeries1.delete(regularTimePeriod8);
        java.util.Date date10 = regularTimePeriod8.getStart();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "31-December-2019" + "'", str7.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.event.SeriesChangeEvent[source=class org.jfree.data.time.Year]");
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
        int int5 = day2.getMonth();
        java.lang.String str6 = day2.toString();
        java.util.Date date7 = day2.getEnd();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date7);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "31-December-2019" + "'", str6.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        int int8 = timeSeries1.getItemCount();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Date date13 = fixedMillisecond12.getTime();
        long long14 = fixedMillisecond12.getFirstMillisecond();
        java.util.Date date15 = fixedMillisecond12.getTime();
        java.lang.Object obj16 = null;
        int int17 = fixedMillisecond12.compareTo(obj16);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.util.Date date21 = year20.getEnd();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date21);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries19.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day22, (java.lang.Number) 0.0f);
        int int26 = day22.compareTo((java.lang.Object) (short) 0);
        int int27 = fixedMillisecond12.compareTo((java.lang.Object) int26);
        long long28 = fixedMillisecond12.getSerialIndex();
        java.lang.String str29 = fixedMillisecond12.toString();
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month();
        timeSeries31.add((org.jfree.data.time.RegularTimePeriod) month32, (java.lang.Number) (byte) 10, false);
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        java.util.Date date39 = year38.getEnd();
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date39);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day40, (java.lang.Number) 0.0f);
        boolean boolean43 = timeSeries37.getNotify();
        java.lang.Object obj44 = timeSeries37.clone();
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month();
        timeSeries46.add((org.jfree.data.time.RegularTimePeriod) month47, (java.lang.Number) (byte) 10, false);
        timeSeries46.setNotify(false);
        java.util.Collection collection53 = timeSeries37.getTimePeriodsUniqueToOtherSeries(timeSeries46);
        int int54 = month32.compareTo((java.lang.Object) timeSeries37);
        int int55 = month32.getMonth();
        org.jfree.data.time.TimeSeries timeSeries56 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (org.jfree.data.time.RegularTimePeriod) month32);
        double double57 = timeSeries1.getMinY();
        timeSeries1.setDomainDescription("31-December-2019");
        timeSeries1.removeAgedItems(2019L, false);
        boolean boolean63 = timeSeries1.isEmpty();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 100L + "'", long14 == 100L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 100L + "'", long28 == 100L);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str29.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNull(timeSeriesDataItem42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(obj44);
        org.junit.Assert.assertNotNull(collection53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 6 + "'", int55 == 6);
        org.junit.Assert.assertNotNull(timeSeries56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        java.lang.Object obj8 = timeSeries1.clone();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        timeSeries10.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) (byte) 10, false);
        timeSeries10.setNotify(false);
        java.util.Collection collection17 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries10);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.util.Date date21 = year20.getEnd();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date21);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries19.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day22, (java.lang.Number) 0.0f);
        boolean boolean25 = timeSeries19.getNotify();
        java.lang.Object obj26 = timeSeries19.clone();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        java.util.Date date28 = year27.getEnd();
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date28);
        long long30 = day29.getSerialIndex();
        timeSeries19.delete((org.jfree.data.time.RegularTimePeriod) day29);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) day29);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day29, (double) 1560185128766L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = day29.previous();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 43830L + "'", long30 == 43830L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem32);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setRangeDescription("hi!");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeries1.getNextTimePeriod();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        java.lang.String str12 = day11.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day11.next();
        java.util.Date date14 = regularTimePeriod13.getStart();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date14);
        java.lang.String str16 = timeSeries15.getDescription();
        java.util.Collection collection17 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries15);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        timeSeries19.add((org.jfree.data.time.RegularTimePeriod) month20, (java.lang.Number) (byte) 10, false);
        timeSeries19.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        java.util.Date date29 = year28.getEnd();
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date29);
        java.lang.String str31 = day30.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = day30.next();
        int int33 = day30.getMonth();
        timeSeries27.add((org.jfree.data.time.RegularTimePeriod) day30, (double) 100);
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        java.util.Date date37 = year36.getEnd();
        boolean boolean39 = year36.equals((java.lang.Object) (-1.0d));
        int int41 = year36.compareTo((java.lang.Object) 1.0d);
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        java.util.Date date43 = year42.getEnd();
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date43);
        java.lang.String str45 = day44.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = day44.next();
        int int47 = day44.getMonth();
        java.lang.String str48 = day44.toString();
        org.jfree.data.time.TimeSeries timeSeries49 = timeSeries27.createCopy((org.jfree.data.time.RegularTimePeriod) year36, (org.jfree.data.time.RegularTimePeriod) day44);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = timeSeries27.getDataItem((int) (byte) 0);
        java.util.Collection collection52 = timeSeries19.getTimePeriodsUniqueToOtherSeries(timeSeries27);
        org.jfree.data.time.Month month53 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month53);
        int int55 = month53.getMonth();
        org.jfree.data.time.TimeSeries timeSeries57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month58 = new org.jfree.data.time.Month();
        timeSeries57.add((org.jfree.data.time.RegularTimePeriod) month58, (java.lang.Number) (byte) 10, false);
        timeSeries57.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries65 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month66 = new org.jfree.data.time.Month();
        timeSeries65.add((org.jfree.data.time.RegularTimePeriod) month66, (java.lang.Number) (byte) 10, false);
        timeSeries65.setNotify(false);
        java.util.Collection collection72 = timeSeries57.getTimePeriodsUniqueToOtherSeries(timeSeries65);
        org.jfree.data.time.Year year73 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem74 = timeSeries65.getDataItem((org.jfree.data.time.RegularTimePeriod) year73);
        java.lang.Object obj75 = timeSeriesDataItem74.clone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = timeSeriesDataItem74.getPeriod();
        org.jfree.data.time.TimeSeries timeSeries77 = timeSeries19.createCopy((org.jfree.data.time.RegularTimePeriod) month53, regularTimePeriod76);
        java.lang.Number number78 = null;
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) month53, number78);
        java.lang.Object obj80 = null;
        boolean boolean81 = timeSeries15.equals(obj80);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "31-December-2019" + "'", str12.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "31-December-2019" + "'", str31.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 12 + "'", int33 == 12);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "31-December-2019" + "'", str45.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 12 + "'", int47 == 12);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "31-December-2019" + "'", str48.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(timeSeries49);
        org.junit.Assert.assertNotNull(timeSeriesDataItem51);
        org.junit.Assert.assertNotNull(collection52);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 6 + "'", int55 == 6);
        org.junit.Assert.assertNotNull(collection72);
        org.junit.Assert.assertNotNull(timeSeriesDataItem74);
        org.junit.Assert.assertNotNull(obj75);
        org.junit.Assert.assertNotNull(regularTimePeriod76);
        org.junit.Assert.assertNotNull(timeSeries77);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
    }

//    @Test
//    public void test108() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test108");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "2019", "");
//        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
//        timeSeries3.removeAgedItems(false);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "2019", "");
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
//        timeSeries13.add((org.jfree.data.time.RegularTimePeriod) month14, (java.lang.Number) (byte) 10, false);
//        timeSeries13.setNotify(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond20.getFirstMillisecond(calendar21);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20);
//        timeSeries11.add(timeSeriesDataItem23, true);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = timeSeriesDataItem23.getPeriod();
//        boolean boolean27 = day7.equals((java.lang.Object) timeSeriesDataItem23);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo28 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent29 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeriesDataItem23, seriesChangeInfo28);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = timeSeriesDataItem23.getPeriod();
//        timeSeries3.add(timeSeriesDataItem23, false);
//        org.junit.Assert.assertNull(class4);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560185196320L + "'", long22 == 1560185196320L);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
        java.util.Date date5 = regularTimePeriod4.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond6.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond6.previous();
        java.util.Calendar calendar9 = null;
        fixedMillisecond6.peg(calendar9);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0);
        timeSeries1.setDescription("");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.addChangeListener(seriesChangeListener4);
        timeSeries1.setDescription("");
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
        int int5 = day2.getMonth();
        int int6 = day2.getYear();
        long long7 = day2.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577779200000L + "'", long7 == 1577779200000L);
    }

//    @Test
//    public void test112() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test112");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        long long3 = fixedMillisecond0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560185196433L + "'", long2 == 1560185196433L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560185196433L + "'", long3 == 1560185196433L);
//    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        java.util.Calendar calendar4 = null;
        fixedMillisecond3.peg(calendar4);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond3.getMiddleMillisecond(calendar6);
        java.util.Date date8 = fixedMillisecond3.getTime();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.removeChangeListener(seriesChangeListener6);
        int int8 = timeSeries1.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        java.util.Date date12 = year11.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (java.lang.Number) 0.0f);
        boolean boolean16 = timeSeries10.getNotify();
        java.lang.Object obj17 = timeSeries10.clone();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        timeSeries19.add((org.jfree.data.time.RegularTimePeriod) month20, (java.lang.Number) (byte) 10, false);
        timeSeries19.setNotify(false);
        java.util.Collection collection26 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries19);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        java.util.Date date30 = year29.getEnd();
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date30);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries28.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day31, (java.lang.Number) 0.0f);
        boolean boolean34 = timeSeries28.getNotify();
        java.lang.Object obj35 = timeSeries28.clone();
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        java.util.Date date37 = year36.getEnd();
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date37);
        long long39 = day38.getSerialIndex();
        timeSeries28.delete((org.jfree.data.time.RegularTimePeriod) day38);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries10.getDataItem((org.jfree.data.time.RegularTimePeriod) day38);
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        java.util.Date date43 = year42.getEnd();
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date43);
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year(date43);
        long long46 = year45.getMiddleMillisecond();
        int int47 = timeSeries10.getIndex((org.jfree.data.time.RegularTimePeriod) year45);
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) year45, (java.lang.Number) 24234L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(collection26);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNull(timeSeriesDataItem33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(obj35);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 43830L + "'", long39 == 43830L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem41);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1562097599999L + "'", long46 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.Year year9 = org.jfree.data.time.Year.parseYear("2019");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) year9);
        int int11 = timeSeries1.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.util.Date date15 = year14.getEnd();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day16, (java.lang.Number) 0.0f);
        boolean boolean19 = timeSeries13.getNotify();
        java.lang.Object obj20 = timeSeries13.clone();
        timeSeries13.setNotify(false);
        timeSeries13.delete(0, 0, true);
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries1.addAndOrUpdate(timeSeries13);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = fixedMillisecond29.previous();
        long long31 = fixedMillisecond29.getMiddleMillisecond();
        java.util.Calendar calendar32 = null;
        long long33 = fixedMillisecond29.getFirstMillisecond(calendar32);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29, (java.lang.Number) 31);
        timeSeries13.add(timeSeriesDataItem35, false);
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        boolean boolean40 = timeSeriesDataItem35.equals((java.lang.Object) 0.0f);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2147483647 + "'", int11 == 2147483647);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(timeSeries27);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 100L + "'", long31 == 100L);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 100L + "'", long33 == 100L);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

//    @Test
//    public void test116() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test116");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.util.Date date1 = year0.getEnd();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        java.lang.String str3 = day2.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
//        int int6 = day2.compareTo((java.lang.Object) 1L);
//        long long7 = day2.getLastMillisecond();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int9 = day2.compareTo((java.lang.Object) day8);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day8.next();
//        long long11 = day8.getLastMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 204 + "'", int9 == 204);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560236399999L + "'", long11 == 1560236399999L);
//    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        java.lang.Object obj8 = timeSeries1.clone();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        long long12 = day11.getSerialIndex();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day11);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries1.createCopy(0, 6);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        java.util.Date date20 = year19.getEnd();
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day21, (java.lang.Number) 0.0f);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        java.util.Date date25 = year24.getEnd();
        boolean boolean27 = year24.equals((java.lang.Object) (-1.0d));
        int int29 = year24.compareTo((java.lang.Object) 1.0d);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries18.getDataItem((org.jfree.data.time.RegularTimePeriod) year24);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year24, (double) 7);
        org.jfree.data.time.TimeSeries timeSeries33 = null;
        try {
            java.util.Collection collection34 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43830L + "'", long12 == 43830L);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNull(timeSeriesDataItem23);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(timeSeriesDataItem30);
        org.junit.Assert.assertNull(timeSeriesDataItem32);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
        java.util.Date date5 = regularTimePeriod4.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond6.previous();
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond6.getMiddleMillisecond(calendar8);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865600000L + "'", long9 == 1577865600000L);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        java.util.List list8 = timeSeries1.getItems();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond11, "", "hi!");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond11.previous();
        timeSeries1.delete(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) (byte) 10, false);
        timeSeries9.setNotify(false);
        java.util.Collection collection16 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries9);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) year17);
        try {
            timeSeries9.update(1, (java.lang.Number) 1560150000000L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertNotNull(timeSeriesDataItem18);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Date date2 = fixedMillisecond1.getTime();
        long long3 = fixedMillisecond1.getFirstMillisecond();
        java.util.Date date4 = fixedMillisecond1.getTime();
        java.lang.Object obj5 = null;
        int int6 = fixedMillisecond1.compareTo(obj5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        java.util.Date date8 = year7.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.lang.String str10 = day9.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day9.next();
        boolean boolean12 = fixedMillisecond1.equals((java.lang.Object) regularTimePeriod11);
        java.util.Calendar calendar13 = null;
        fixedMillisecond1.peg(calendar13);
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond1.getMiddleMillisecond(calendar15);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "2019", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener21 = null;
        timeSeries20.removeChangeListener(seriesChangeListener21);
        boolean boolean23 = fixedMillisecond1.equals((java.lang.Object) seriesChangeListener21);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 100L + "'", long16 == 100L);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
        int int5 = day2.getMonth();
        java.lang.String str6 = day2.toString();
        org.jfree.data.time.SerialDate serialDate7 = day2.getSerialDate();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(serialDate7);
        long long9 = day8.getFirstMillisecond();
        java.lang.String str10 = day8.toString();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "31-December-2019" + "'", str6.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577779200000L + "'", long9 == 1577779200000L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.removeChangeListener(seriesChangeListener6);
        java.lang.Comparable comparable8 = timeSeries1.getKey();
        java.util.Collection collection9 = timeSeries1.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        timeSeries11.add((org.jfree.data.time.RegularTimePeriod) month12, (java.lang.Number) (byte) 10, false);
        timeSeries11.setRangeDescription("hi!");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = timeSeries11.getNextTimePeriod();
        timeSeries11.setNotify(true);
        java.lang.String str21 = timeSeries11.getDomainDescription();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year((int) '#');
        timeSeries11.delete((org.jfree.data.time.RegularTimePeriod) year23);
        java.lang.Comparable comparable25 = timeSeries11.getKey();
        java.util.Collection collection26 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries11);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries11.getDataItem(4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 'a' + "'", comparable8.equals('a'));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Time" + "'", str21.equals("Time"));
        org.junit.Assert.assertTrue("'" + comparable25 + "' != '" + 'a' + "'", comparable25.equals('a'));
        org.junit.Assert.assertNotNull(collection26);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.Year year9 = org.jfree.data.time.Year.parseYear("2019");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) year9);
        timeSeries1.setNotify(true);
        java.lang.String str13 = timeSeries1.getDomainDescription();
        java.lang.Class class14 = timeSeries1.getTimePeriodClass();
        timeSeries1.clear();
        timeSeries1.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: hi!");
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries1.getDataItem((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Time" + "'", str13.equals("Time"));
        org.junit.Assert.assertNotNull(class14);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        java.lang.Object obj8 = timeSeries1.clone();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        timeSeries10.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) (byte) 10, false);
        timeSeries10.setNotify(false);
        java.util.Collection collection17 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries10);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.util.Date date21 = year20.getEnd();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date21);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries19.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day22, (java.lang.Number) 0.0f);
        boolean boolean25 = timeSeries19.getNotify();
        java.lang.Object obj26 = timeSeries19.clone();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        java.util.Date date28 = year27.getEnd();
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date28);
        long long30 = day29.getSerialIndex();
        timeSeries19.delete((org.jfree.data.time.RegularTimePeriod) day29);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) day29);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        java.util.Date date34 = year33.getEnd();
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date34);
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date34);
        long long37 = year36.getMiddleMillisecond();
        int int38 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) year36);
        timeSeries1.clear();
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        java.util.Date date43 = year42.getEnd();
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date43);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = timeSeries41.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day44, (java.lang.Number) 0.0f);
        boolean boolean47 = timeSeries41.getNotify();
        java.lang.Object obj48 = timeSeries41.clone();
        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year();
        java.util.Date date50 = year49.getEnd();
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date50);
        long long52 = day51.getSerialIndex();
        timeSeries41.delete((org.jfree.data.time.RegularTimePeriod) day51);
        java.lang.Object obj54 = timeSeries41.clone();
        java.lang.Class class55 = timeSeries41.getTimePeriodClass();
        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year();
        java.util.Date date57 = year56.getEnd();
        long long58 = year56.getLastMillisecond();
        timeSeries41.add((org.jfree.data.time.RegularTimePeriod) year56, (java.lang.Number) (-62041132800001L), true);
        java.lang.String str62 = year56.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = year56.previous();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year56, (java.lang.Number) (byte) 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 43830L + "'", long30 == 43830L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem32);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1562097599999L + "'", long37 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNull(timeSeriesDataItem46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(obj48);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 43830L + "'", long52 == 43830L);
        org.junit.Assert.assertNotNull(obj54);
        org.junit.Assert.assertNull(class55);
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1577865599999L + "'", long58 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "2019" + "'", str62.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod63);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setRangeDescription("hi!");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeries1.getNextTimePeriod();
        timeSeries1.setNotify(true);
        java.lang.String str11 = timeSeries1.getDescription();
        timeSeries1.setKey((java.lang.Comparable) 1560185169553L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNull(str11);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setNotify(false);
        timeSeries1.setNotify(true);
        java.lang.String str10 = timeSeries1.getDomainDescription();
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Time" + "'", str10.equals("Time"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) false);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) (byte) 10, false);
        timeSeries5.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        timeSeries13.add((org.jfree.data.time.RegularTimePeriod) month14, (java.lang.Number) (byte) 10, false);
        timeSeries13.setNotify(false);
        java.util.Collection collection20 = timeSeries5.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) year21);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener23 = null;
        timeSeries13.addChangeListener(seriesChangeListener23);
        int int25 = fixedMillisecond1.compareTo((java.lang.Object) seriesChangeListener23);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = fixedMillisecond1.previous();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(collection20);
        org.junit.Assert.assertNotNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0);
        timeSeries1.setDescription("");
        timeSeries1.removeAgedItems(true);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.Year year9 = org.jfree.data.time.Year.parseYear("2019");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) year9);
        int int11 = timeSeries1.getMaximumItemCount();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        java.util.Date date13 = year12.getEnd();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        java.lang.String str15 = day14.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day14.next();
        java.util.Date date17 = regularTimePeriod16.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = fixedMillisecond18.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        java.util.Calendar calendar21 = null;
        long long22 = fixedMillisecond18.getLastMillisecond(calendar21);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2147483647 + "'", int11 == 2147483647);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "31-December-2019" + "'", str15.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(timeSeriesDataItem20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1577865600000L + "'", long22 == 1577865600000L);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        java.lang.String str3 = year1.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year1.next();
        long long5 = year1.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "35" + "'", str3.equals("35"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61031289600001L) + "'", long5 == (-61031289600001L));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        java.lang.String str6 = month2.toString();
        int int7 = month2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month2.next();
        long long9 = month2.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560668399999L + "'", long9 == 1560668399999L);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) (byte) 10, false);
        timeSeries9.setNotify(false);
        java.util.Collection collection16 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries9);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) year17);
        timeSeriesDataItem18.setValue((java.lang.Number) 1559372400000L);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo21 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent22 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeriesDataItem18, seriesChangeInfo21);
        timeSeriesDataItem18.setValue((java.lang.Number) (short) 1);
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertNotNull(timeSeriesDataItem18);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setNotify(false);
        timeSeries1.fireSeriesChanged();
        double double9 = timeSeries1.getMaxY();
        timeSeries1.removeAgedItems(true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 10.0d + "'", double9 == 10.0d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date1);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date1);
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        java.lang.Object obj8 = timeSeries1.clone();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        long long12 = day11.getSerialIndex();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day11);
        java.lang.Object obj14 = timeSeries1.clone();
        java.lang.Class class15 = timeSeries1.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Date date18 = fixedMillisecond17.getTime();
        long long19 = fixedMillisecond17.getFirstMillisecond();
        java.util.Date date20 = fixedMillisecond17.getTime();
        java.lang.Object obj21 = null;
        int int22 = fixedMillisecond17.compareTo(obj21);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        java.util.Date date24 = year23.getEnd();
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date24);
        java.lang.String str26 = day25.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = day25.next();
        boolean boolean28 = fixedMillisecond17.equals((java.lang.Object) regularTimePeriod27);
        long long29 = fixedMillisecond17.getSerialIndex();
        java.util.Date date30 = fixedMillisecond17.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = fixedMillisecond17.previous();
        java.util.Calendar calendar32 = null;
        long long33 = fixedMillisecond17.getFirstMillisecond(calendar32);
        int int34 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
        java.util.Calendar calendar35 = null;
        long long36 = fixedMillisecond17.getLastMillisecond(calendar35);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43830L + "'", long12 == 43830L);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNull(class15);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 100L + "'", long19 == 100L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "31-December-2019" + "'", str26.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 100L + "'", long29 == 100L);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 100L + "'", long33 == 100L);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 100L + "'", long36 == 100L);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        org.jfree.data.time.SerialDate serialDate7 = day4.getSerialDate();
        int int8 = day4.getDayOfMonth();
        java.lang.String str9 = day4.toString();
        long long10 = day4.getLastMillisecond();
        long long11 = day4.getLastMillisecond();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 31 + "'", int8 == 31);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "31-December-2019" + "'", str9.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        java.lang.String str3 = year1.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year1.next();
        java.lang.String str5 = year1.toString();
        java.lang.Class<?> wildcardClass6 = year1.getClass();
        int int8 = year1.compareTo((java.lang.Object) 1560185136721L);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560185136721L);
        timeSeries9.setDomainDescription("org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: hi!");
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "35" + "'", str3.equals("35"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "35" + "'", str5.equals("35"));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
        java.util.Date date5 = regularTimePeriod4.getStart();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date5);
        java.lang.String str7 = timeSeries6.getDescription();
        java.lang.String str8 = timeSeries6.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        java.util.Date date12 = year11.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (java.lang.Number) 0.0f);
        boolean boolean16 = timeSeries10.getNotify();
        java.lang.Object obj17 = timeSeries10.clone();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        java.util.Date date19 = year18.getEnd();
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date19);
        long long21 = day20.getSerialIndex();
        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) day20);
        java.lang.Object obj23 = timeSeries10.clone();
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries6.addAndOrUpdate(timeSeries10);
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        timeSeries26.add((org.jfree.data.time.RegularTimePeriod) month27, (java.lang.Number) (byte) 10, false);
        timeSeries26.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month();
        timeSeries34.add((org.jfree.data.time.RegularTimePeriod) month35, (java.lang.Number) (byte) 10, false);
        timeSeries34.setNotify(false);
        java.util.Collection collection41 = timeSeries26.getTimePeriodsUniqueToOtherSeries(timeSeries34);
        boolean boolean42 = timeSeries26.getNotify();
        timeSeries26.removeAgedItems((long) 'a', true);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = timeSeries26.getNextTimePeriod();
        java.lang.String str47 = regularTimePeriod46.toString();
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year();
        java.util.Date date49 = year48.getEnd();
        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(date49);
        java.lang.String str51 = day50.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = day50.next();
        int int53 = day50.getMonth();
        java.lang.String str54 = day50.toString();
        org.jfree.data.time.TimeSeries timeSeries57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day50, "", "org.jfree.data.event.SeriesChangeEvent[source=1]");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day50, (java.lang.Number) (-1L));
        org.jfree.data.time.TimeSeries timeSeries60 = timeSeries6.createCopy(regularTimePeriod46, (org.jfree.data.time.RegularTimePeriod) day50);
        try {
            org.jfree.data.time.TimeSeries timeSeries63 = timeSeries6.createCopy(9999, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Value" + "'", str8.equals("Value"));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 43830L + "'", long21 == 43830L);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertNotNull(timeSeries24);
        org.junit.Assert.assertNotNull(collection41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "July 2019" + "'", str47.equals("July 2019"));
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "31-December-2019" + "'", str51.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 12 + "'", int53 == 12);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "31-December-2019" + "'", str54.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(timeSeries60);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (short) 1, year1);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException5.getSuppressed();
        boolean boolean10 = month3.equals((java.lang.Object) throwableArray9);
        java.lang.String str11 = month3.toString();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "January 2019" + "'", str11.equals("January 2019"));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.removeChangeListener(seriesChangeListener6);
        java.lang.Comparable comparable8 = timeSeries1.getKey();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        java.util.Date date12 = year11.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        java.lang.String str14 = day13.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day13.next();
        int int16 = day13.getMonth();
        timeSeries10.add((org.jfree.data.time.RegularTimePeriod) day13, (double) 100);
        long long19 = day13.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) day13);
        boolean boolean21 = timeSeries1.isEmpty();
        timeSeries1.fireSeriesChanged();
        int int23 = timeSeries1.getItemCount();
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 'a' + "'", comparable8.equals('a'));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "31-December-2019" + "'", str14.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 12 + "'", int16 == 12);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1577865599999L + "'", long19 == 1577865599999L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (short) 1, seriesChangeInfo1);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo3 = seriesChangeEvent2.getSummary();
        java.lang.String str4 = seriesChangeEvent2.toString();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo5 = null;
        seriesChangeEvent2.setSummary(seriesChangeInfo5);
        java.lang.Object obj7 = seriesChangeEvent2.getSource();
        java.lang.Object obj8 = seriesChangeEvent2.getSource();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo9 = seriesChangeEvent2.getSummary();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo10 = null;
        seriesChangeEvent2.setSummary(seriesChangeInfo10);
        org.junit.Assert.assertNull(seriesChangeInfo3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=1]" + "'", str4.equals("org.jfree.data.event.SeriesChangeEvent[source=1]"));
        org.junit.Assert.assertTrue("'" + obj7 + "' != '" + (short) 1 + "'", obj7.equals((short) 1));
        org.junit.Assert.assertTrue("'" + obj8 + "' != '" + (short) 1 + "'", obj8.equals((short) 1));
        org.junit.Assert.assertNull(seriesChangeInfo9);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date1);
        java.util.TimeZone timeZone7 = null;
        try {
            org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date1, timeZone7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        java.lang.Object obj8 = null;
        boolean boolean9 = timeSeries1.equals(obj8);
        try {
            timeSeries1.delete(0, (int) (short) 1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.Year year9 = org.jfree.data.time.Year.parseYear("2019");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) year9);
        int int11 = timeSeries1.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.util.Date date15 = year14.getEnd();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day16, (java.lang.Number) 0.0f);
        boolean boolean19 = timeSeries13.getNotify();
        java.lang.Object obj20 = timeSeries13.clone();
        timeSeries13.setNotify(false);
        timeSeries13.delete(0, 0, true);
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries1.addAndOrUpdate(timeSeries13);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = fixedMillisecond29.previous();
        long long31 = fixedMillisecond29.getMiddleMillisecond();
        java.util.Calendar calendar32 = null;
        long long33 = fixedMillisecond29.getFirstMillisecond(calendar32);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29, (java.lang.Number) 31);
        timeSeries13.add(timeSeriesDataItem35, false);
        boolean boolean38 = timeSeriesDataItem35.isSelected();
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2147483647 + "'", int11 == 2147483647);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(timeSeries27);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 100L + "'", long31 == 100L);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 100L + "'", long33 == 100L);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
        java.util.Date date5 = regularTimePeriod4.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date5);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date5);
        java.lang.String str8 = timeSeries7.getDomainDescription();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
        java.util.Date date5 = regularTimePeriod4.getStart();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date5);
        java.util.Collection collection7 = timeSeries6.getTimePeriods();
        java.lang.String str8 = timeSeries6.getRangeDescription();
        timeSeries6.removeAgedItems(1560185196320L, false);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(collection7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Value" + "'", str8.equals("Value"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Date date2 = fixedMillisecond1.getTime();
        long long3 = fixedMillisecond1.getFirstMillisecond();
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond1.previous();
        long long6 = fixedMillisecond1.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        java.lang.Object obj8 = timeSeries1.clone();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        timeSeries10.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) (byte) 10, false);
        timeSeries10.setNotify(false);
        java.util.Collection collection17 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries10);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.util.Date date21 = year20.getEnd();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date21);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries19.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day22, (java.lang.Number) 0.0f);
        boolean boolean25 = timeSeries19.getNotify();
        java.lang.Object obj26 = timeSeries19.clone();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        java.util.Date date28 = year27.getEnd();
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date28);
        long long30 = day29.getSerialIndex();
        timeSeries19.delete((org.jfree.data.time.RegularTimePeriod) day29);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) day29);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        java.util.Date date34 = year33.getEnd();
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date34);
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date34);
        long long37 = year36.getMiddleMillisecond();
        int int38 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) year36);
        java.util.Calendar calendar39 = null;
        try {
            long long40 = year36.getLastMillisecond(calendar39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 43830L + "'", long30 == 43830L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem32);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1562097599999L + "'", long37 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test150");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "2019", "");
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
//        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) (byte) 10, false);
//        timeSeries5.setNotify(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar13 = null;
//        long long14 = fixedMillisecond12.getFirstMillisecond(calendar13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries5.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
//        timeSeries3.add(timeSeriesDataItem15, true);
//        double double18 = timeSeries3.getMaxY();
//        java.lang.Object obj19 = null;
//        boolean boolean20 = timeSeries3.equals(obj19);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560185200160L + "'", long14 == 1560185200160L);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem15);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 10.0d + "'", double18 == 10.0d);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        java.lang.Object obj8 = timeSeries1.clone();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        timeSeries10.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) (byte) 10, false);
        timeSeries10.setNotify(false);
        java.util.Collection collection17 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries10);
        timeSeries1.setDomainDescription("");
        java.util.Collection collection20 = timeSeries1.getTimePeriods();
        long long21 = timeSeries1.getMaximumItemAge();
        java.lang.String str22 = timeSeries1.getDescription();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertNotNull(collection20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 9223372036854775807L + "'", long21 == 9223372036854775807L);
        org.junit.Assert.assertNull(str22);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        java.lang.String str13 = day12.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day12.next();
        int int15 = day12.getMonth();
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) day12, (double) 100);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        java.util.Date date19 = year18.getEnd();
        boolean boolean21 = year18.equals((java.lang.Object) (-1.0d));
        int int23 = year18.compareTo((java.lang.Object) 1.0d);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        java.util.Date date25 = year24.getEnd();
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date25);
        java.lang.String str27 = day26.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day26.next();
        int int29 = day26.getMonth();
        java.lang.String str30 = day26.toString();
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries9.createCopy((org.jfree.data.time.RegularTimePeriod) year18, (org.jfree.data.time.RegularTimePeriod) day26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries9.getDataItem((int) (byte) 0);
        java.util.Collection collection34 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries9);
        timeSeries1.setMaximumItemAge(1560185153553L);
        timeSeries1.setDomainDescription("Value");
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "31-December-2019" + "'", str13.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 12 + "'", int15 == 12);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "31-December-2019" + "'", str27.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 12 + "'", int29 == 12);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "31-December-2019" + "'", str30.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(timeSeries31);
        org.junit.Assert.assertNotNull(timeSeriesDataItem33);
        org.junit.Assert.assertNotNull(collection34);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        java.lang.Object obj8 = timeSeries1.clone();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        long long12 = day11.getSerialIndex();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day11);
        java.lang.Object obj14 = timeSeries1.clone();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        java.util.Date date17 = year16.getEnd();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 1, year16);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) year16);
        java.lang.Class class20 = timeSeries1.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        timeSeries22.add((org.jfree.data.time.RegularTimePeriod) month23, (java.lang.Number) (byte) 10, false);
        timeSeries22.setRangeDescription("hi!");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = timeSeries22.getNextTimePeriod();
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month();
        timeSeries31.add((org.jfree.data.time.RegularTimePeriod) month32, (java.lang.Number) (byte) 10, false);
        timeSeries31.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month();
        timeSeries39.add((org.jfree.data.time.RegularTimePeriod) month40, (java.lang.Number) (byte) 10, false);
        timeSeries39.setNotify(false);
        java.util.Collection collection46 = timeSeries31.getTimePeriodsUniqueToOtherSeries(timeSeries39);
        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = timeSeries39.getDataItem((org.jfree.data.time.RegularTimePeriod) year47);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries22.addOrUpdate(timeSeriesDataItem48);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = timeSeries1.addOrUpdate(timeSeriesDataItem49);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43830L + "'", long12 == 43830L);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(class20);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(collection46);
        org.junit.Assert.assertNotNull(timeSeriesDataItem48);
        org.junit.Assert.assertNotNull(timeSeriesDataItem49);
        org.junit.Assert.assertNull(timeSeriesDataItem50);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        java.util.List list8 = timeSeries1.getItems();
        timeSeries1.fireSeriesChanged();
        timeSeries1.clear();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(list8);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Date date2 = fixedMillisecond1.getTime();
        java.util.Date date3 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        java.util.Calendar calendar5 = null;
        try {
            year4.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1561964399999L);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.Year year9 = org.jfree.data.time.Year.parseYear("2019");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) year9);
        timeSeries1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener13);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(timeSeriesDataItem10);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.Year year9 = org.jfree.data.time.Year.parseYear("2019");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) year9);
        int int11 = timeSeries1.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.util.Date date15 = year14.getEnd();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day16, (java.lang.Number) 0.0f);
        boolean boolean19 = timeSeries13.getNotify();
        java.lang.Object obj20 = timeSeries13.clone();
        timeSeries13.setNotify(false);
        timeSeries13.delete(0, 0, true);
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries1.addAndOrUpdate(timeSeries13);
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month();
        timeSeries29.add((org.jfree.data.time.RegularTimePeriod) month30, (java.lang.Number) (byte) 10, false);
        timeSeries29.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month();
        timeSeries37.add((org.jfree.data.time.RegularTimePeriod) month38, (java.lang.Number) (byte) 10, false);
        timeSeries37.setNotify(false);
        java.util.Collection collection44 = timeSeries29.getTimePeriodsUniqueToOtherSeries(timeSeries37);
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = timeSeries37.getDataItem((org.jfree.data.time.RegularTimePeriod) year45);
        timeSeriesDataItem46.setValue((java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries1.addOrUpdate(timeSeriesDataItem46);
        timeSeries1.removeAgedItems(false);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2147483647 + "'", int11 == 2147483647);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(timeSeries27);
        org.junit.Assert.assertNotNull(collection44);
        org.junit.Assert.assertNotNull(timeSeriesDataItem46);
        org.junit.Assert.assertNotNull(timeSeriesDataItem49);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.Year year9 = org.jfree.data.time.Year.parseYear("2019");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) year9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = fixedMillisecond12.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = fixedMillisecond12.next();
        boolean boolean15 = timeSeriesDataItem10.equals((java.lang.Object) regularTimePeriod14);
        java.lang.String str16 = regularTimePeriod14.toString();
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str16.equals("Wed Dec 31 16:00:00 PST 1969"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        java.lang.Object obj8 = null;
        boolean boolean9 = timeSeries1.equals(obj8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = timeSeries1.getNextTimePeriod();
        java.util.Calendar calendar11 = null;
        try {
            long long12 = regularTimePeriod10.getMiddleMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(35, 100, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        int int8 = timeSeries1.getItemCount();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Date date13 = fixedMillisecond12.getTime();
        long long14 = fixedMillisecond12.getFirstMillisecond();
        java.util.Date date15 = fixedMillisecond12.getTime();
        java.lang.Object obj16 = null;
        int int17 = fixedMillisecond12.compareTo(obj16);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.util.Date date21 = year20.getEnd();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date21);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries19.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day22, (java.lang.Number) 0.0f);
        int int26 = day22.compareTo((java.lang.Object) (short) 0);
        int int27 = fixedMillisecond12.compareTo((java.lang.Object) int26);
        long long28 = fixedMillisecond12.getSerialIndex();
        java.lang.String str29 = fixedMillisecond12.toString();
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month();
        timeSeries31.add((org.jfree.data.time.RegularTimePeriod) month32, (java.lang.Number) (byte) 10, false);
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        java.util.Date date39 = year38.getEnd();
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date39);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day40, (java.lang.Number) 0.0f);
        boolean boolean43 = timeSeries37.getNotify();
        java.lang.Object obj44 = timeSeries37.clone();
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month();
        timeSeries46.add((org.jfree.data.time.RegularTimePeriod) month47, (java.lang.Number) (byte) 10, false);
        timeSeries46.setNotify(false);
        java.util.Collection collection53 = timeSeries37.getTimePeriodsUniqueToOtherSeries(timeSeries46);
        int int54 = month32.compareTo((java.lang.Object) timeSeries37);
        int int55 = month32.getMonth();
        org.jfree.data.time.TimeSeries timeSeries56 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (org.jfree.data.time.RegularTimePeriod) month32);
        double double57 = timeSeries1.getMinY();
        timeSeries1.setDomainDescription("31-December-2019");
        org.jfree.data.time.TimeSeries timeSeries61 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month62 = new org.jfree.data.time.Month();
        timeSeries61.add((org.jfree.data.time.RegularTimePeriod) month62, (java.lang.Number) (byte) 10, false);
        java.lang.String str66 = month62.toString();
        int int67 = month62.getYearValue();
        int int68 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month62);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 100L + "'", long14 == 100L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 100L + "'", long28 == 100L);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str29.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNull(timeSeriesDataItem42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(obj44);
        org.junit.Assert.assertNotNull(collection53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 6 + "'", int55 == 6);
        org.junit.Assert.assertNotNull(timeSeries56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "June 2019" + "'", str66.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 2019 + "'", int67 == 2019);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
    }

//    @Test
//    public void test163() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test163");
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) '#');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
//        java.util.Date date4 = year3.getEnd();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
//        long long6 = day5.getLastMillisecond();
//        int int7 = year1.compareTo((java.lang.Object) day5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond8.getFirstMillisecond(calendar9);
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
//        java.util.Date date14 = year13.getEnd();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
//        java.lang.String str16 = day15.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day15.next();
//        int int18 = day15.getMonth();
//        timeSeries12.add((org.jfree.data.time.RegularTimePeriod) day15, (double) 100);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener21 = null;
//        timeSeries12.addChangeListener(seriesChangeListener21);
//        java.lang.Object obj23 = timeSeries12.clone();
//        boolean boolean24 = fixedMillisecond8.equals((java.lang.Object) timeSeries12);
//        int int25 = day5.compareTo((java.lang.Object) fixedMillisecond8);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, 0.0d);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560185201923L + "'", long10 == 1560185201923L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "31-December-2019" + "'", str16.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 12 + "'", int18 == 12);
//        org.junit.Assert.assertNotNull(obj23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) (byte) 10, false);
        timeSeries3.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        timeSeries11.add((org.jfree.data.time.RegularTimePeriod) month12, (java.lang.Number) (byte) 10, false);
        timeSeries11.setNotify(false);
        java.util.Collection collection18 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries11);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries11.getDataItem((org.jfree.data.time.RegularTimePeriod) year19);
        java.lang.Object obj21 = timeSeriesDataItem20.clone();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year23.next();
        int int25 = timeSeriesDataItem20.compareTo((java.lang.Object) year23);
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        java.util.Date date29 = year28.getEnd();
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date29);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries27.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day30, (java.lang.Number) 0.0f);
        int int33 = timeSeriesDataItem20.compareTo((java.lang.Object) 0.0f);
        timeSeries1.add(timeSeriesDataItem20);
        boolean boolean35 = timeSeries1.isEmpty();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = timeSeries1.getTimePeriod((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection18);
        org.junit.Assert.assertNotNull(timeSeriesDataItem20);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNull(timeSeriesDataItem32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("2019");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
        java.util.Date date5 = regularTimePeriod4.getStart();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date5);
        java.lang.String str7 = timeSeries6.getDescription();
        java.lang.String str8 = timeSeries6.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        java.util.Date date12 = year11.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (java.lang.Number) 0.0f);
        boolean boolean16 = timeSeries10.getNotify();
        java.lang.Object obj17 = timeSeries10.clone();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        java.util.Date date19 = year18.getEnd();
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date19);
        long long21 = day20.getSerialIndex();
        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) day20);
        java.lang.Object obj23 = timeSeries10.clone();
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries6.addAndOrUpdate(timeSeries10);
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        timeSeries26.add((org.jfree.data.time.RegularTimePeriod) month27, (java.lang.Number) (byte) 10, false);
        timeSeries26.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month();
        timeSeries34.add((org.jfree.data.time.RegularTimePeriod) month35, (java.lang.Number) (byte) 10, false);
        timeSeries34.setNotify(false);
        java.util.Collection collection41 = timeSeries26.getTimePeriodsUniqueToOtherSeries(timeSeries34);
        boolean boolean42 = timeSeries26.getNotify();
        timeSeries26.removeAgedItems((long) 'a', true);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = timeSeries26.getNextTimePeriod();
        java.lang.String str47 = regularTimePeriod46.toString();
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year();
        java.util.Date date49 = year48.getEnd();
        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(date49);
        java.lang.String str51 = day50.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = day50.next();
        int int53 = day50.getMonth();
        java.lang.String str54 = day50.toString();
        org.jfree.data.time.TimeSeries timeSeries57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day50, "", "org.jfree.data.event.SeriesChangeEvent[source=1]");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day50, (java.lang.Number) (-1L));
        org.jfree.data.time.TimeSeries timeSeries60 = timeSeries6.createCopy(regularTimePeriod46, (org.jfree.data.time.RegularTimePeriod) day50);
        java.beans.PropertyChangeListener propertyChangeListener61 = null;
        timeSeries60.removePropertyChangeListener(propertyChangeListener61);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Value" + "'", str8.equals("Value"));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 43830L + "'", long21 == 43830L);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertNotNull(timeSeries24);
        org.junit.Assert.assertNotNull(collection41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "July 2019" + "'", str47.equals("July 2019"));
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "31-December-2019" + "'", str51.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 12 + "'", int53 == 12);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "31-December-2019" + "'", str54.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(timeSeries60);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.Year year9 = org.jfree.data.time.Year.parseYear("2019");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) year9);
        int int11 = timeSeries1.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.util.Date date15 = year14.getEnd();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day16, (java.lang.Number) 0.0f);
        boolean boolean19 = timeSeries13.getNotify();
        java.lang.Object obj20 = timeSeries13.clone();
        timeSeries13.setNotify(false);
        timeSeries13.delete(0, 0, true);
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries1.addAndOrUpdate(timeSeries13);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = fixedMillisecond29.previous();
        long long31 = fixedMillisecond29.getMiddleMillisecond();
        java.util.Calendar calendar32 = null;
        long long33 = fixedMillisecond29.getFirstMillisecond(calendar32);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29, (java.lang.Number) 31);
        timeSeries13.add(timeSeriesDataItem35, false);
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        java.util.Date date39 = year38.getEnd();
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date39);
        java.lang.String str41 = day40.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = day40.next();
        java.util.Date date43 = regularTimePeriod42.getStart();
        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod42);
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year();
        java.util.Date date48 = year47.getEnd();
        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day(date48);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = timeSeries46.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day49, (java.lang.Number) 0.0f);
        boolean boolean52 = timeSeries46.getNotify();
        timeSeries46.setMaximumItemCount(2);
        java.lang.Class class55 = timeSeries46.getTimePeriodClass();
        boolean boolean56 = timeSeries44.equals((java.lang.Object) timeSeries46);
        boolean boolean57 = timeSeriesDataItem35.equals((java.lang.Object) timeSeries46);
        double double58 = timeSeries46.getMinY();
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2147483647 + "'", int11 == 2147483647);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(timeSeries27);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 100L + "'", long31 == 100L);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 100L + "'", long33 == 100L);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "31-December-2019" + "'", str41.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNull(timeSeriesDataItem51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(class55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.Year year9 = org.jfree.data.time.Year.parseYear("2019");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) year9);
        timeSeriesDataItem10.setValue((java.lang.Number) 1560185196320L);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(timeSeriesDataItem10);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) false);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) (byte) 10, false);
        timeSeries5.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        timeSeries13.add((org.jfree.data.time.RegularTimePeriod) month14, (java.lang.Number) (byte) 10, false);
        timeSeries13.setNotify(false);
        java.util.Collection collection20 = timeSeries5.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) year21);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener23 = null;
        timeSeries13.addChangeListener(seriesChangeListener23);
        int int25 = fixedMillisecond1.compareTo((java.lang.Object) seriesChangeListener23);
        long long26 = fixedMillisecond1.getFirstMillisecond();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        java.util.Date date28 = year27.getEnd();
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date28);
        java.lang.String str30 = day29.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = day29.next();
        java.util.Date date32 = regularTimePeriod31.getStart();
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date32);
        java.lang.String str34 = timeSeries33.getDescription();
        java.lang.String str35 = timeSeries33.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        java.util.Date date39 = year38.getEnd();
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date39);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day40, (java.lang.Number) 0.0f);
        boolean boolean43 = timeSeries37.getNotify();
        java.lang.Object obj44 = timeSeries37.clone();
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year();
        java.util.Date date46 = year45.getEnd();
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(date46);
        long long48 = day47.getSerialIndex();
        timeSeries37.delete((org.jfree.data.time.RegularTimePeriod) day47);
        java.lang.Object obj50 = timeSeries37.clone();
        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries33.addAndOrUpdate(timeSeries37);
        boolean boolean52 = fixedMillisecond1.equals((java.lang.Object) timeSeries37);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = null;
        try {
            timeSeries37.delete(regularTimePeriod53);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(collection20);
        org.junit.Assert.assertNotNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 100L + "'", long26 == 100L);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "31-December-2019" + "'", str30.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNull(str34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Value" + "'", str35.equals("Value"));
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNull(timeSeriesDataItem42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(obj44);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 43830L + "'", long48 == 43830L);
        org.junit.Assert.assertNotNull(obj50);
        org.junit.Assert.assertNotNull(timeSeries51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) -1, 31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test171() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test171");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.util.Date date1 = year0.getEnd();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        java.lang.String str3 = day2.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
//        int int6 = day2.compareTo((java.lang.Object) 1L);
//        long long7 = day2.getLastMillisecond();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int9 = day2.compareTo((java.lang.Object) day8);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day8.next();
//        java.util.Date date11 = day8.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day8.next();
//        java.util.Calendar calendar13 = null;
//        try {
//            day8.peg(calendar13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 204 + "'", int9 == 204);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
        java.util.Date date5 = regularTimePeriod4.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date5);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date5);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date5);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        java.lang.String str5 = day4.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day4.next();
        int int7 = day4.getMonth();
        java.lang.String str8 = day4.toString();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, "", "org.jfree.data.event.SeriesChangeEvent[source=1]");
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries11.removePropertyChangeListener(propertyChangeListener12);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        java.util.Date date17 = year16.getEnd();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date17);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries15.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day18, (java.lang.Number) 0.0f);
        boolean boolean21 = timeSeries15.getNotify();
        java.lang.Object obj22 = timeSeries15.clone();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        java.util.Date date24 = year23.getEnd();
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date24);
        long long26 = day25.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries15.getDataItem((org.jfree.data.time.RegularTimePeriod) day25);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries11.addOrUpdate(timeSeriesDataItem27);
        int int29 = year0.compareTo((java.lang.Object) timeSeriesDataItem27);
        boolean boolean30 = timeSeriesDataItem27.isSelected();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "31-December-2019" + "'", str5.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "31-December-2019" + "'", str8.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 43830L + "'", long26 == 43830L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem27);
        org.junit.Assert.assertNull(timeSeriesDataItem28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Date date2 = fixedMillisecond1.getTime();
        long long3 = fixedMillisecond1.getFirstMillisecond();
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.util.Date date4 = year3.getEnd();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        java.lang.String str6 = day5.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day5.next();
        java.util.Date date8 = regularTimePeriod7.getStart();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date8);
        java.lang.String str10 = timeSeries9.getDescription();
        java.lang.String str11 = timeSeries9.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.util.Date date15 = year14.getEnd();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day16, (java.lang.Number) 0.0f);
        boolean boolean19 = timeSeries13.getNotify();
        java.lang.Object obj20 = timeSeries13.clone();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        java.util.Date date22 = year21.getEnd();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        long long24 = day23.getSerialIndex();
        timeSeries13.delete((org.jfree.data.time.RegularTimePeriod) day23);
        java.lang.Object obj26 = timeSeries13.clone();
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries9.addAndOrUpdate(timeSeries13);
        java.beans.PropertyChangeListener propertyChangeListener28 = null;
        timeSeries27.addPropertyChangeListener(propertyChangeListener28);
        boolean boolean30 = year1.equals((java.lang.Object) timeSeries27);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "31-December-2019" + "'", str6.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Value" + "'", str11.equals("Value"));
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 43830L + "'", long24 == 43830L);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertNotNull(timeSeries27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
        java.util.Date date5 = regularTimePeriod4.getStart();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5);
        java.util.TimeZone timeZone8 = null;
        try {
            org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date5, timeZone8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.Year year9 = org.jfree.data.time.Year.parseYear("2019");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) year9);
        timeSeries1.setNotify(true);
        java.lang.String str13 = timeSeries1.getDomainDescription();
        boolean boolean14 = timeSeries1.getNotify();
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Time" + "'", str13.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
        int int5 = day2.getMonth();
        java.lang.String str6 = day2.toString();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day2, "", "org.jfree.data.event.SeriesChangeEvent[source=1]");
        org.jfree.data.time.SerialDate serialDate10 = day2.getSerialDate();
        java.lang.String str11 = day2.toString();
        long long12 = day2.getLastMillisecond();
        long long13 = day2.getSerialIndex();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "31-December-2019" + "'", str6.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "31-December-2019" + "'", str11.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43830L + "'", long13 == 43830L);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener8);
        timeSeries1.setDescription("org.jfree.data.event.SeriesChangeEvent[source=1]");
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        timeSeries13.add((org.jfree.data.time.RegularTimePeriod) month14, (java.lang.Number) (byte) 10, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries13.removeChangeListener(seriesChangeListener18);
        java.lang.Comparable comparable20 = timeSeries13.getKey();
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        java.util.Date date24 = year23.getEnd();
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date24);
        java.lang.String str26 = day25.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = day25.next();
        int int28 = day25.getMonth();
        timeSeries22.add((org.jfree.data.time.RegularTimePeriod) day25, (double) 100);
        long long31 = day25.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) day25);
        timeSeries13.removeAgedItems(false);
        boolean boolean35 = timeSeries1.equals((java.lang.Object) timeSeries13);
        org.junit.Assert.assertTrue("'" + comparable20 + "' != '" + 'a' + "'", comparable20.equals('a'));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "31-December-2019" + "'", str26.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 12 + "'", int28 == 12);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1577865599999L + "'", long31 == 1577865599999L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

//    @Test
//    public void test180() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test180");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getMiddleMillisecond(calendar3);
//        long long5 = fixedMillisecond0.getSerialIndex();
//        long long6 = fixedMillisecond0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560185203855L + "'", long2 == 1560185203855L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560185203855L + "'", long4 == 1560185203855L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560185203855L + "'", long5 == 1560185203855L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560185203855L + "'", long6 == 1560185203855L);
//    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setRangeDescription("hi!");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeries1.getNextTimePeriod();
        timeSeries1.setNotify(true);
        java.lang.String str11 = timeSeries1.getDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Date date14 = fixedMillisecond13.getTime();
        long long15 = fixedMillisecond13.getMiddleMillisecond();
        int int16 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13);
        long long17 = fixedMillisecond13.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 100L + "'", long15 == 100L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 100L + "'", long17 == 100L);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        timeSeries1.setMaximumItemCount(2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries1.removeChangeListener(seriesChangeListener10);
        java.lang.String str12 = timeSeries1.getDomainDescription();
        boolean boolean13 = timeSeries1.isEmpty();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Time" + "'", str12.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener8);
        java.util.Collection collection10 = timeSeries1.getTimePeriods();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries1.getTimePeriod(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection10);
    }

//    @Test
//    public void test184() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test184");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
//        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
//        java.util.Date date3 = year2.getEnd();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
//        boolean boolean7 = timeSeries1.getNotify();
//        java.lang.Object obj8 = timeSeries1.clone();
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
//        java.util.Date date10 = year9.getEnd();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
//        long long12 = day11.getSerialIndex();
//        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day11);
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries1.createCopy(0, 6);
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
//        java.util.Date date20 = year19.getEnd();
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date20);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day21, (java.lang.Number) 0.0f);
//        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
//        java.util.Date date25 = year24.getEnd();
//        boolean boolean27 = year24.equals((java.lang.Object) (-1.0d));
//        int int29 = year24.compareTo((java.lang.Object) 1.0d);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries18.getDataItem((org.jfree.data.time.RegularTimePeriod) year24);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year24, (double) 7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar34 = null;
//        long long35 = fixedMillisecond33.getFirstMillisecond(calendar34);
//        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year((int) '#');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = year37.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod38, (java.lang.Number) (-1L));
//        int int41 = fixedMillisecond33.compareTo((java.lang.Object) (-1L));
//        java.lang.Number number42 = null;
//        try {
//            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33, number42);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNull(timeSeriesDataItem6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(obj8);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43830L + "'", long12 == 43830L);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNull(timeSeriesDataItem23);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem30);
//        org.junit.Assert.assertNull(timeSeriesDataItem32);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560185203940L + "'", long35 == 1560185203940L);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
//    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.removeChangeListener(seriesChangeListener6);
        timeSeries1.setDomainDescription("31-December-2019");
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        timeSeries11.add((org.jfree.data.time.RegularTimePeriod) month12, (java.lang.Number) (byte) 10, false);
        timeSeries11.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        timeSeries19.add((org.jfree.data.time.RegularTimePeriod) month20, (java.lang.Number) (byte) 10, false);
        timeSeries19.setNotify(false);
        java.util.Collection collection26 = timeSeries11.getTimePeriodsUniqueToOtherSeries(timeSeries19);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries19.getDataItem((org.jfree.data.time.RegularTimePeriod) year27);
        timeSeriesDataItem28.setValue((java.lang.Number) (byte) 1);
        boolean boolean32 = timeSeriesDataItem28.equals((java.lang.Object) (-1.0f));
        boolean boolean33 = timeSeries1.equals((java.lang.Object) (-1.0f));
        java.lang.Comparable comparable34 = timeSeries1.getKey();
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        java.util.Date date36 = year35.getEnd();
        long long37 = year35.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = year35.next();
        boolean boolean39 = timeSeries1.equals((java.lang.Object) regularTimePeriod38);
        java.lang.Number number41 = timeSeries1.getValue(0);
        org.junit.Assert.assertNotNull(collection26);
        org.junit.Assert.assertNotNull(timeSeriesDataItem28);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + comparable34 + "' != '" + 'a' + "'", comparable34.equals('a'));
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1577865599999L + "'", long37 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + number41 + "' != '" + (byte) 10 + "'", number41.equals((byte) 10));
    }

//    @Test
//    public void test186() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test186");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0, "", "hi!");
//        long long4 = fixedMillisecond0.getFirstMillisecond();
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond0.getLastMillisecond(calendar5);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560185204161L + "'", long4 == 1560185204161L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560185204161L + "'", long6 == 1560185204161L);
//    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
        int int5 = day2.getMonth();
        java.lang.String str6 = day2.toString();
        long long7 = day2.getFirstMillisecond();
        long long8 = day2.getLastMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "31-December-2019" + "'", str6.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577779200000L + "'", long7 == 1577779200000L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.removeChangeListener(seriesChangeListener6);
        java.lang.Comparable comparable8 = timeSeries1.getKey();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        java.util.Date date12 = year11.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        java.lang.String str14 = day13.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day13.next();
        int int16 = day13.getMonth();
        timeSeries10.add((org.jfree.data.time.RegularTimePeriod) day13, (double) 100);
        long long19 = day13.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) day13);
        int int21 = day13.getDayOfMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day13.previous();
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 'a' + "'", comparable8.equals('a'));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "31-December-2019" + "'", str14.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 12 + "'", int16 == 12);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1577865599999L + "'", long19 == 1577865599999L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 31 + "'", int21 == 31);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        int int2 = month0.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.previous();
        long long4 = month0.getLastMillisecond();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = month0.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1561964399999L + "'", long4 == 1561964399999L);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        java.lang.Object obj8 = timeSeries1.clone();
        timeSeries1.setNotify(false);
        timeSeries1.delete(0, 0, true);
        java.util.Collection collection15 = timeSeries1.getTimePeriods();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(collection15);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
        java.util.Date date5 = regularTimePeriod4.getStart();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod4);
        timeSeries6.removeAgedItems(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond9, "", "hi!");
        java.lang.Class<?> wildcardClass13 = fixedMillisecond9.getClass();
        timeSeries6.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (java.lang.Number) 0.0d, false);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

//    @Test
//    public void test192() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test192");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.util.Date date1 = year0.getEnd();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        java.lang.String str3 = day2.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
//        int int6 = day2.compareTo((java.lang.Object) 1L);
//        long long7 = day2.getLastMillisecond();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int9 = day2.compareTo((java.lang.Object) day8);
//        int int10 = day2.getDayOfMonth();
//        java.util.Date date11 = day2.getStart();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 204 + "'", int9 == 204);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 31 + "'", int10 == 31);
//        org.junit.Assert.assertNotNull(date11);
//    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Date date2 = fixedMillisecond1.getTime();
        long long3 = fixedMillisecond1.getFirstMillisecond();
        java.util.Date date4 = fixedMillisecond1.getTime();
        java.lang.Object obj5 = null;
        int int6 = fixedMillisecond1.compareTo(obj5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        java.util.Date date8 = year7.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.lang.String str10 = day9.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day9.next();
        boolean boolean12 = fixedMillisecond1.equals((java.lang.Object) regularTimePeriod11);
        long long13 = fixedMillisecond1.getSerialIndex();
        java.util.Date date14 = fixedMillisecond1.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond1.previous();
        java.util.Calendar calendar16 = null;
        long long17 = fixedMillisecond1.getMiddleMillisecond(calendar16);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 100L + "'", long13 == 100L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 100L + "'", long17 == 100L);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        int int8 = timeSeries1.getItemCount();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Date date13 = fixedMillisecond12.getTime();
        long long14 = fixedMillisecond12.getFirstMillisecond();
        java.util.Date date15 = fixedMillisecond12.getTime();
        java.lang.Object obj16 = null;
        int int17 = fixedMillisecond12.compareTo(obj16);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.util.Date date21 = year20.getEnd();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date21);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries19.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day22, (java.lang.Number) 0.0f);
        int int26 = day22.compareTo((java.lang.Object) (short) 0);
        int int27 = fixedMillisecond12.compareTo((java.lang.Object) int26);
        long long28 = fixedMillisecond12.getSerialIndex();
        java.lang.String str29 = fixedMillisecond12.toString();
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month();
        timeSeries31.add((org.jfree.data.time.RegularTimePeriod) month32, (java.lang.Number) (byte) 10, false);
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        java.util.Date date39 = year38.getEnd();
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date39);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day40, (java.lang.Number) 0.0f);
        boolean boolean43 = timeSeries37.getNotify();
        java.lang.Object obj44 = timeSeries37.clone();
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month();
        timeSeries46.add((org.jfree.data.time.RegularTimePeriod) month47, (java.lang.Number) (byte) 10, false);
        timeSeries46.setNotify(false);
        java.util.Collection collection53 = timeSeries37.getTimePeriodsUniqueToOtherSeries(timeSeries46);
        int int54 = month32.compareTo((java.lang.Object) timeSeries37);
        int int55 = month32.getMonth();
        org.jfree.data.time.TimeSeries timeSeries56 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (org.jfree.data.time.RegularTimePeriod) month32);
        timeSeries56.removeAgedItems(true);
        boolean boolean60 = timeSeries56.equals((java.lang.Object) "hi!");
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 100L + "'", long14 == 100L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 100L + "'", long28 == 100L);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str29.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNull(timeSeriesDataItem42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(obj44);
        org.junit.Assert.assertNotNull(collection53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 6 + "'", int55 == 6);
        org.junit.Assert.assertNotNull(timeSeries56);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
        int int5 = day2.getMonth();
        java.lang.String str6 = day2.toString();
        long long7 = day2.getFirstMillisecond();
        java.lang.String str8 = day2.toString();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "31-December-2019" + "'", str6.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577779200000L + "'", long7 == 1577779200000L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "31-December-2019" + "'", str8.equals("31-December-2019"));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560185118796L);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        java.util.Date date5 = year4.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        java.lang.String str7 = day6.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day6.next();
        int int9 = day6.getMonth();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day6, (double) 100);
        java.lang.Object obj12 = timeSeries3.clone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeries3.getNextTimePeriod();
        int int14 = timeSeries3.getMaximumItemCount();
        java.util.Collection collection15 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "31-December-2019" + "'", str7.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 12 + "'", int9 == 12);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2147483647 + "'", int14 == 2147483647);
        org.junit.Assert.assertNotNull(collection15);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.previous();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Date date2 = fixedMillisecond1.getTime();
        long long3 = fixedMillisecond1.getFirstMillisecond();
        java.util.Date date4 = fixedMillisecond1.getTime();
        java.lang.Object obj5 = null;
        int int6 = fixedMillisecond1.compareTo(obj5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        java.util.Date date8 = year7.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.lang.String str10 = day9.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day9.next();
        boolean boolean12 = fixedMillisecond1.equals((java.lang.Object) regularTimePeriod11);
        long long13 = fixedMillisecond1.getSerialIndex();
        java.util.Date date14 = fixedMillisecond1.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond1.previous();
        java.util.Calendar calendar16 = null;
        long long17 = fixedMillisecond1.getFirstMillisecond(calendar16);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        timeSeries19.add((org.jfree.data.time.RegularTimePeriod) month20, (java.lang.Number) (byte) 10, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener24 = null;
        timeSeries19.removeChangeListener(seriesChangeListener24);
        boolean boolean26 = fixedMillisecond1.equals((java.lang.Object) seriesChangeListener24);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 100L + "'", long13 == 100L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 100L + "'", long17 == 100L);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        java.util.Date date8 = year7.getEnd();
        boolean boolean10 = year7.equals((java.lang.Object) (-1.0d));
        int int12 = year7.compareTo((java.lang.Object) 1.0d);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) year7);
        java.lang.Class class14 = timeSeries1.getTimePeriodClass();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(class14);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        org.jfree.data.time.SerialDate serialDate7 = day4.getSerialDate();
        int int8 = day4.getDayOfMonth();
        java.lang.String str9 = day4.toString();
        long long10 = day4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day4.previous();
        long long12 = day4.getLastMillisecond();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 31 + "'", int8 == 31);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "31-December-2019" + "'", str9.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.next();
        long long5 = month3.getSerialIndex();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 23640L + "'", long5 == 23640L);
    }

//    @Test
//    public void test202() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test202");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getMiddleMillisecond(calendar3);
//        long long5 = fixedMillisecond0.getSerialIndex();
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond0.getMiddleMillisecond(calendar6);
//        long long8 = fixedMillisecond0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560185205806L + "'", long2 == 1560185205806L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560185205806L + "'", long4 == 1560185205806L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560185205806L + "'", long5 == 1560185205806L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560185205806L + "'", long7 == 1560185205806L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560185205806L + "'", long8 == 1560185205806L);
//    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 6);
        long long2 = fixedMillisecond1.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 6L + "'", long2 == 6L);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        boolean boolean2 = month0.equals((java.lang.Object) (byte) -1);
        long long3 = month0.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month0.next();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setNotify(false);
        timeSeries1.setNotify(true);
        java.lang.Comparable comparable10 = timeSeries1.getKey();
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + 'a' + "'", comparable10.equals('a'));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(10, 9, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        java.lang.String str5 = day4.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day4.next();
        int int7 = day4.getMonth();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (double) 100);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries1.addChangeListener(seriesChangeListener10);
        java.lang.Comparable comparable12 = timeSeries1.getKey();
        timeSeries1.removeAgedItems(true);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "31-December-2019" + "'", str5.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + 'a' + "'", comparable12.equals('a'));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setRangeDescription("hi!");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeries1.getNextTimePeriod();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        java.lang.String str12 = day11.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day11.next();
        java.util.Date date14 = regularTimePeriod13.getStart();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date14);
        java.lang.String str16 = timeSeries15.getDescription();
        java.util.Collection collection17 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries15);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        timeSeries19.add((org.jfree.data.time.RegularTimePeriod) month20, (java.lang.Number) (byte) 10, false);
        timeSeries19.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        java.util.Date date29 = year28.getEnd();
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date29);
        java.lang.String str31 = day30.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = day30.next();
        int int33 = day30.getMonth();
        timeSeries27.add((org.jfree.data.time.RegularTimePeriod) day30, (double) 100);
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        java.util.Date date37 = year36.getEnd();
        boolean boolean39 = year36.equals((java.lang.Object) (-1.0d));
        int int41 = year36.compareTo((java.lang.Object) 1.0d);
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        java.util.Date date43 = year42.getEnd();
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date43);
        java.lang.String str45 = day44.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = day44.next();
        int int47 = day44.getMonth();
        java.lang.String str48 = day44.toString();
        org.jfree.data.time.TimeSeries timeSeries49 = timeSeries27.createCopy((org.jfree.data.time.RegularTimePeriod) year36, (org.jfree.data.time.RegularTimePeriod) day44);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = timeSeries27.getDataItem((int) (byte) 0);
        java.util.Collection collection52 = timeSeries19.getTimePeriodsUniqueToOtherSeries(timeSeries27);
        org.jfree.data.time.Month month53 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month53);
        int int55 = month53.getMonth();
        org.jfree.data.time.TimeSeries timeSeries57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month58 = new org.jfree.data.time.Month();
        timeSeries57.add((org.jfree.data.time.RegularTimePeriod) month58, (java.lang.Number) (byte) 10, false);
        timeSeries57.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries65 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month66 = new org.jfree.data.time.Month();
        timeSeries65.add((org.jfree.data.time.RegularTimePeriod) month66, (java.lang.Number) (byte) 10, false);
        timeSeries65.setNotify(false);
        java.util.Collection collection72 = timeSeries57.getTimePeriodsUniqueToOtherSeries(timeSeries65);
        org.jfree.data.time.Year year73 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem74 = timeSeries65.getDataItem((org.jfree.data.time.RegularTimePeriod) year73);
        java.lang.Object obj75 = timeSeriesDataItem74.clone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = timeSeriesDataItem74.getPeriod();
        org.jfree.data.time.TimeSeries timeSeries77 = timeSeries19.createCopy((org.jfree.data.time.RegularTimePeriod) month53, regularTimePeriod76);
        java.lang.Number number78 = null;
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) month53, number78);
        try {
            java.lang.Number number81 = timeSeries15.getValue(204);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 204, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "31-December-2019" + "'", str12.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "31-December-2019" + "'", str31.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 12 + "'", int33 == 12);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "31-December-2019" + "'", str45.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 12 + "'", int47 == 12);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "31-December-2019" + "'", str48.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(timeSeries49);
        org.junit.Assert.assertNotNull(timeSeriesDataItem51);
        org.junit.Assert.assertNotNull(collection52);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 6 + "'", int55 == 6);
        org.junit.Assert.assertNotNull(collection72);
        org.junit.Assert.assertNotNull(timeSeriesDataItem74);
        org.junit.Assert.assertNotNull(obj75);
        org.junit.Assert.assertNotNull(regularTimePeriod76);
        org.junit.Assert.assertNotNull(timeSeries77);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        java.lang.Object obj8 = timeSeries1.clone();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        long long12 = day11.getSerialIndex();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day11);
        java.lang.String str14 = timeSeries1.getDomainDescription();
        try {
            timeSeries1.delete(9, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43830L + "'", long12 == 43830L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Time" + "'", str14.equals("Time"));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        long long4 = day2.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day2, (java.lang.Number) 5L);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577779200000L + "'", long4 == 1577779200000L);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date1);
        long long4 = year3.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year3, (double) 0.0f);
        int int7 = year3.getYear();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = year3.getLastMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1562097599999L + "'", long4 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
        int int5 = day2.getMonth();
        java.lang.String str6 = day2.toString();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day2, "", "org.jfree.data.event.SeriesChangeEvent[source=1]");
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries9.removePropertyChangeListener(propertyChangeListener10);
        java.lang.Object obj12 = timeSeries9.clone();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "31-December-2019" + "'", str6.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("2019");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("org.jfree.data.time.TimePeriodFormatException: hi!");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException3);
        java.lang.String str5 = seriesException1.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.general.SeriesException: 2019" + "'", str5.equals("org.jfree.data.general.SeriesException: 2019"));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.util.Date date7 = year6.getEnd();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date7);
        java.lang.String str9 = day8.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day8.next();
        int int11 = day8.getMonth();
        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) day8, (double) 100);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.util.Date date15 = year14.getEnd();
        boolean boolean17 = year14.equals((java.lang.Object) (-1.0d));
        int int19 = year14.compareTo((java.lang.Object) 1.0d);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.util.Date date21 = year20.getEnd();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date21);
        java.lang.String str23 = day22.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day22.next();
        int int25 = day22.getMonth();
        java.lang.String str26 = day22.toString();
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) year14, (org.jfree.data.time.RegularTimePeriod) day22);
        double double28 = timeSeries5.getMinY();
        int int29 = day3.compareTo((java.lang.Object) double28);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "31-December-2019" + "'", str9.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 12 + "'", int11 == 12);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "31-December-2019" + "'", str23.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 12 + "'", int25 == 12);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "31-December-2019" + "'", str26.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(timeSeries27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 100.0d + "'", double28 == 100.0d);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date1);
        long long5 = year4.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.event.SeriesChangeEvent[source=1]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        org.jfree.data.time.SerialDate serialDate7 = day4.getSerialDate();
        int int8 = day4.getDayOfMonth();
        java.lang.String str9 = day4.toString();
        java.util.Calendar calendar10 = null;
        try {
            day4.peg(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 31 + "'", int8 == 31);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "31-December-2019" + "'", str9.equals("31-December-2019"));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
        java.util.Date date5 = regularTimePeriod4.getStart();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date5);
        java.lang.String str7 = timeSeries6.getDescription();
        java.lang.String str8 = timeSeries6.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        java.util.Date date12 = year11.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (java.lang.Number) 0.0f);
        boolean boolean16 = timeSeries10.getNotify();
        java.lang.Object obj17 = timeSeries10.clone();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        java.util.Date date19 = year18.getEnd();
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date19);
        long long21 = day20.getSerialIndex();
        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) day20);
        java.lang.Object obj23 = timeSeries10.clone();
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries6.addAndOrUpdate(timeSeries10);
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        timeSeries26.add((org.jfree.data.time.RegularTimePeriod) month27, (java.lang.Number) (byte) 10, false);
        timeSeries26.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month();
        timeSeries34.add((org.jfree.data.time.RegularTimePeriod) month35, (java.lang.Number) (byte) 10, false);
        timeSeries34.setNotify(false);
        java.util.Collection collection41 = timeSeries26.getTimePeriodsUniqueToOtherSeries(timeSeries34);
        boolean boolean42 = timeSeries26.getNotify();
        timeSeries26.removeAgedItems((long) 'a', true);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = timeSeries26.getNextTimePeriod();
        java.lang.String str47 = regularTimePeriod46.toString();
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year();
        java.util.Date date49 = year48.getEnd();
        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(date49);
        java.lang.String str51 = day50.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = day50.next();
        int int53 = day50.getMonth();
        java.lang.String str54 = day50.toString();
        org.jfree.data.time.TimeSeries timeSeries57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day50, "", "org.jfree.data.event.SeriesChangeEvent[source=1]");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day50, (java.lang.Number) (-1L));
        org.jfree.data.time.TimeSeries timeSeries60 = timeSeries6.createCopy(regularTimePeriod46, (org.jfree.data.time.RegularTimePeriod) day50);
        long long61 = timeSeries60.getMaximumItemAge();
        double double62 = timeSeries60.getMaxY();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Value" + "'", str8.equals("Value"));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 43830L + "'", long21 == 43830L);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertNotNull(timeSeries24);
        org.junit.Assert.assertNotNull(collection41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "July 2019" + "'", str47.equals("July 2019"));
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "31-December-2019" + "'", str51.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 12 + "'", int53 == 12);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "31-December-2019" + "'", str54.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(timeSeries60);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 9223372036854775807L + "'", long61 == 9223372036854775807L);
        org.junit.Assert.assertEquals((double) double62, Double.NaN, 0);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
        java.util.Date date5 = regularTimePeriod4.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date5);
        java.util.TimeZone timeZone7 = null;
        try {
            org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date5, timeZone7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        java.lang.String str13 = day12.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day12.next();
        int int15 = day12.getMonth();
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) day12, (double) 100);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        java.util.Date date19 = year18.getEnd();
        boolean boolean21 = year18.equals((java.lang.Object) (-1.0d));
        int int23 = year18.compareTo((java.lang.Object) 1.0d);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        java.util.Date date25 = year24.getEnd();
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date25);
        java.lang.String str27 = day26.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day26.next();
        int int29 = day26.getMonth();
        java.lang.String str30 = day26.toString();
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries9.createCopy((org.jfree.data.time.RegularTimePeriod) year18, (org.jfree.data.time.RegularTimePeriod) day26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries9.getDataItem((int) (byte) 0);
        java.util.Collection collection34 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries9);
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month35);
        int int37 = month35.getMonth();
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month();
        timeSeries39.add((org.jfree.data.time.RegularTimePeriod) month40, (java.lang.Number) (byte) 10, false);
        timeSeries39.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month();
        timeSeries47.add((org.jfree.data.time.RegularTimePeriod) month48, (java.lang.Number) (byte) 10, false);
        timeSeries47.setNotify(false);
        java.util.Collection collection54 = timeSeries39.getTimePeriodsUniqueToOtherSeries(timeSeries47);
        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem56 = timeSeries47.getDataItem((org.jfree.data.time.RegularTimePeriod) year55);
        java.lang.Object obj57 = timeSeriesDataItem56.clone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = timeSeriesDataItem56.getPeriod();
        org.jfree.data.time.TimeSeries timeSeries59 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month35, regularTimePeriod58);
        int int60 = month35.getMonth();
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "31-December-2019" + "'", str13.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 12 + "'", int15 == 12);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "31-December-2019" + "'", str27.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 12 + "'", int29 == 12);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "31-December-2019" + "'", str30.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(timeSeries31);
        org.junit.Assert.assertNotNull(timeSeriesDataItem33);
        org.junit.Assert.assertNotNull(collection34);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 6 + "'", int37 == 6);
        org.junit.Assert.assertNotNull(collection54);
        org.junit.Assert.assertNotNull(timeSeriesDataItem56);
        org.junit.Assert.assertNotNull(obj57);
        org.junit.Assert.assertNotNull(regularTimePeriod58);
        org.junit.Assert.assertNotNull(timeSeries59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 6 + "'", int60 == 6);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        java.lang.Object obj8 = timeSeries1.clone();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        long long12 = day11.getSerialIndex();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day11);
        int int14 = timeSeries1.getItemCount();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43830L + "'", long12 == 43830L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Date date6 = fixedMillisecond5.getTime();
        int int7 = month3.compareTo((java.lang.Object) fixedMillisecond5);
        long long8 = month3.getLastMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 28799999L + "'", long8 == 28799999L);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.Year year9 = org.jfree.data.time.Year.parseYear("2019");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) year9);
        int int11 = timeSeries1.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.util.Date date15 = year14.getEnd();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day16, (java.lang.Number) 0.0f);
        boolean boolean19 = timeSeries13.getNotify();
        java.lang.Object obj20 = timeSeries13.clone();
        timeSeries13.setNotify(false);
        timeSeries13.delete(0, 0, true);
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries1.addAndOrUpdate(timeSeries13);
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month();
        timeSeries29.add((org.jfree.data.time.RegularTimePeriod) month30, (java.lang.Number) (byte) 10, false);
        timeSeries29.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month();
        timeSeries37.add((org.jfree.data.time.RegularTimePeriod) month38, (java.lang.Number) (byte) 10, false);
        timeSeries37.setNotify(false);
        java.util.Collection collection44 = timeSeries29.getTimePeriodsUniqueToOtherSeries(timeSeries37);
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = timeSeries37.getDataItem((org.jfree.data.time.RegularTimePeriod) year45);
        timeSeriesDataItem46.setValue((java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries1.addOrUpdate(timeSeriesDataItem46);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = timeSeriesDataItem49.getPeriod();
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2147483647 + "'", int11 == 2147483647);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(timeSeries27);
        org.junit.Assert.assertNotNull(collection44);
        org.junit.Assert.assertNotNull(timeSeriesDataItem46);
        org.junit.Assert.assertNotNull(timeSeriesDataItem49);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560185118796L);
        long long2 = fixedMillisecond1.getFirstMillisecond();
        long long3 = fixedMillisecond1.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560185118796L + "'", long2 == 1560185118796L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560185118796L + "'", long3 == 1560185118796L);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        java.lang.String str5 = day4.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day4.next();
        int int7 = day4.getMonth();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (double) 100);
        long long10 = day4.getLastMillisecond();
        long long11 = day4.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, "Time", "org.jfree.data.time.TimePeriodFormatException: hi!");
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        boolean boolean16 = day4.equals((java.lang.Object) month15);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "31-December-2019" + "'", str5.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 43830L + "'", long11 == 43830L);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        java.lang.String str5 = day4.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day4.next();
        int int7 = day4.getMonth();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (double) 100);
        long long10 = day4.getLastMillisecond();
        java.lang.String str11 = day4.toString();
        java.util.Calendar calendar12 = null;
        try {
            long long13 = day4.getLastMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "31-December-2019" + "'", str5.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "31-December-2019" + "'", str11.equals("31-December-2019"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("January 2020");
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((-9999), 35, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) 0.0f);
        boolean boolean13 = timeSeries7.getNotify();
        java.lang.Object obj14 = timeSeries7.clone();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        timeSeries16.add((org.jfree.data.time.RegularTimePeriod) month17, (java.lang.Number) (byte) 10, false);
        timeSeries16.setNotify(false);
        java.util.Collection collection23 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries16);
        int int24 = month2.compareTo((java.lang.Object) timeSeries7);
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        java.util.Date date28 = year27.getEnd();
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date28);
        java.lang.String str30 = day29.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = day29.next();
        int int32 = day29.getMonth();
        timeSeries26.add((org.jfree.data.time.RegularTimePeriod) day29, (double) 100);
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        java.util.Date date36 = year35.getEnd();
        boolean boolean38 = year35.equals((java.lang.Object) (-1.0d));
        int int40 = year35.compareTo((java.lang.Object) 1.0d);
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
        java.util.Date date42 = year41.getEnd();
        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(date42);
        java.lang.String str44 = day43.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = day43.next();
        int int46 = day43.getMonth();
        java.lang.String str47 = day43.toString();
        org.jfree.data.time.TimeSeries timeSeries48 = timeSeries26.createCopy((org.jfree.data.time.RegularTimePeriod) year35, (org.jfree.data.time.RegularTimePeriod) day43);
        java.lang.String str49 = year35.toString();
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
        java.util.Date date51 = year50.getEnd();
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(date51);
        java.lang.String str53 = day52.toString();
        int int54 = day52.getYear();
        org.jfree.data.time.TimeSeries timeSeries55 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) year35, (org.jfree.data.time.RegularTimePeriod) day52);
        int int56 = year35.getYear();
        long long57 = year35.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(collection23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "31-December-2019" + "'", str30.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 12 + "'", int32 == 12);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "31-December-2019" + "'", str44.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 12 + "'", int46 == 12);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "31-December-2019" + "'", str47.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(timeSeries48);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "2019" + "'", str49.equals("2019"));
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "31-December-2019" + "'", str53.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 2019 + "'", int54 == 2019);
        org.junit.Assert.assertNotNull(timeSeries55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 2019 + "'", int56 == 2019);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1562097599999L + "'", long57 == 1562097599999L);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, 2147483647);
        java.util.Date date3 = month2.getStart();
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        timeSeries1.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) (byte) 10, false);
        timeSeries5.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        timeSeries13.add((org.jfree.data.time.RegularTimePeriod) month14, (java.lang.Number) (byte) 10, false);
        timeSeries13.setNotify(false);
        java.util.Collection collection20 = timeSeries5.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) year21);
        timeSeries1.add(timeSeriesDataItem22, false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = timeSeries1.getNextTimePeriod();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
        timeSeries27.add((org.jfree.data.time.RegularTimePeriod) month28, (java.lang.Number) (byte) 10, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener32 = null;
        timeSeries27.removeChangeListener(seriesChangeListener32);
        timeSeries27.setDomainDescription("31-December-2019");
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month();
        timeSeries37.add((org.jfree.data.time.RegularTimePeriod) month38, (java.lang.Number) (byte) 10, false);
        timeSeries37.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month();
        timeSeries45.add((org.jfree.data.time.RegularTimePeriod) month46, (java.lang.Number) (byte) 10, false);
        timeSeries45.setNotify(false);
        java.util.Collection collection52 = timeSeries37.getTimePeriodsUniqueToOtherSeries(timeSeries45);
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = timeSeries45.getDataItem((org.jfree.data.time.RegularTimePeriod) year53);
        timeSeriesDataItem54.setValue((java.lang.Number) (byte) 1);
        boolean boolean58 = timeSeriesDataItem54.equals((java.lang.Object) (-1.0f));
        boolean boolean59 = timeSeries27.equals((java.lang.Object) (-1.0f));
        boolean boolean60 = timeSeries1.equals((java.lang.Object) (-1.0f));
        java.lang.Class class61 = timeSeries1.getTimePeriodClass();
        int int62 = timeSeries1.getMaximumItemCount();
        org.junit.Assert.assertNotNull(collection20);
        org.junit.Assert.assertNotNull(timeSeriesDataItem22);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(collection52);
        org.junit.Assert.assertNotNull(timeSeriesDataItem54);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(class61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 2147483647 + "'", int62 == 2147483647);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        java.lang.String str3 = year1.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year1.next();
        java.lang.String str5 = year1.toString();
        java.lang.Class<?> wildcardClass6 = year1.getClass();
        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass6);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "35" + "'", str3.equals("35"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "35" + "'", str5.equals("35"));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(class7);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.lang.Object obj2 = null;
        boolean boolean3 = year0.equals(obj2);
        java.lang.Number number4 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, number4);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        int int8 = timeSeries1.getItemCount();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Date date13 = fixedMillisecond12.getTime();
        long long14 = fixedMillisecond12.getFirstMillisecond();
        java.util.Date date15 = fixedMillisecond12.getTime();
        java.lang.Object obj16 = null;
        int int17 = fixedMillisecond12.compareTo(obj16);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.util.Date date21 = year20.getEnd();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date21);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries19.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day22, (java.lang.Number) 0.0f);
        int int26 = day22.compareTo((java.lang.Object) (short) 0);
        int int27 = fixedMillisecond12.compareTo((java.lang.Object) int26);
        long long28 = fixedMillisecond12.getSerialIndex();
        java.lang.String str29 = fixedMillisecond12.toString();
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month();
        timeSeries31.add((org.jfree.data.time.RegularTimePeriod) month32, (java.lang.Number) (byte) 10, false);
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        java.util.Date date39 = year38.getEnd();
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date39);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day40, (java.lang.Number) 0.0f);
        boolean boolean43 = timeSeries37.getNotify();
        java.lang.Object obj44 = timeSeries37.clone();
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month();
        timeSeries46.add((org.jfree.data.time.RegularTimePeriod) month47, (java.lang.Number) (byte) 10, false);
        timeSeries46.setNotify(false);
        java.util.Collection collection53 = timeSeries37.getTimePeriodsUniqueToOtherSeries(timeSeries46);
        int int54 = month32.compareTo((java.lang.Object) timeSeries37);
        int int55 = month32.getMonth();
        org.jfree.data.time.TimeSeries timeSeries56 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (org.jfree.data.time.RegularTimePeriod) month32);
        double double57 = timeSeries1.getMinY();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener58 = null;
        timeSeries1.addChangeListener(seriesChangeListener58);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 100L + "'", long14 == 100L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 100L + "'", long28 == 100L);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str29.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNull(timeSeriesDataItem42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(obj44);
        org.junit.Assert.assertNotNull(collection53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 6 + "'", int55 == 6);
        org.junit.Assert.assertNotNull(timeSeries56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        java.util.Date date8 = year7.getEnd();
        boolean boolean10 = year7.equals((java.lang.Object) (-1.0d));
        int int12 = year7.compareTo((java.lang.Object) 1.0d);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) year7);
        boolean boolean14 = timeSeriesDataItem13.isSelected();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 0.0f);
        boolean boolean7 = timeSeries1.getNotify();
        timeSeries1.setMaximumItemCount(2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = timeSeries1.getTimePeriod(0);
        try {
            org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy((int) (short) 1, (-9999));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) (byte) 10, false);
        timeSeries9.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        timeSeries17.add((org.jfree.data.time.RegularTimePeriod) month18, (java.lang.Number) (byte) 10, false);
        timeSeries17.setNotify(false);
        java.util.Collection collection24 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries17);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries17.getDataItem((org.jfree.data.time.RegularTimePeriod) year25);
        java.lang.Object obj27 = timeSeriesDataItem26.clone();
        java.lang.Number number28 = timeSeriesDataItem26.getValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries1.addOrUpdate(timeSeriesDataItem26);
        boolean boolean30 = timeSeries1.getNotify();
        java.lang.Comparable comparable31 = timeSeries1.getKey();
        java.lang.Comparable comparable32 = timeSeries1.getKey();
        org.junit.Assert.assertNotNull(collection24);
        org.junit.Assert.assertNotNull(timeSeriesDataItem26);
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertTrue("'" + number28 + "' != '" + (byte) 10 + "'", number28.equals((byte) 10));
        org.junit.Assert.assertNotNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + comparable31 + "' != '" + 'a' + "'", comparable31.equals('a'));
        org.junit.Assert.assertTrue("'" + comparable32 + "' != '" + 'a' + "'", comparable32.equals('a'));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setRangeDescription("hi!");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeries1.getNextTimePeriod();
        timeSeries1.setNotify(true);
        java.lang.String str11 = timeSeries1.getDescription();
        try {
            org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy((-9999), (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNull(str11);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        timeSeries1.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) (byte) 10, false);
        timeSeries9.setNotify(false);
        java.util.Collection collection16 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries9);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) year17);
        java.lang.String str19 = timeSeries9.getRangeDescription();
        java.util.List list20 = timeSeries9.getItems();
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertNotNull(timeSeriesDataItem18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Value" + "'", str19.equals("Value"));
        org.junit.Assert.assertNotNull(list20);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (short) 1, year9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month11.next();
        timeSeries1.setKey((java.lang.Comparable) regularTimePeriod12);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass1 = year0.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Date date4 = fixedMillisecond3.getTime();
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass1, date4, timeZone5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date4);
        java.lang.String str8 = month7.toString();
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "December 1969" + "'", str8.equals("December 1969"));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        java.util.Calendar calendar4 = null;
        fixedMillisecond3.peg(calendar4);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond3.getMiddleMillisecond(calendar6);
        java.util.Calendar calendar8 = null;
        fixedMillisecond3.peg(calendar8);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2);
        long long5 = year4.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) 0.0f);
        int int8 = year4.getYear();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (byte) 1, year4);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1562097599999L + "'", long5 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.Year year9 = org.jfree.data.time.Year.parseYear("2019");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) year9);
        timeSeries1.setNotify(true);
        java.lang.String str13 = timeSeries1.getRangeDescription();
        timeSeries1.setMaximumItemCount(2);
        java.lang.String str16 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Date date19 = fixedMillisecond18.getTime();
        java.util.Date date20 = fixedMillisecond18.getTime();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) year21);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Value" + "'", str13.equals("Value"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date20);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 10, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.Year year9 = org.jfree.data.time.Year.parseYear("2019");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) year9);
        int int11 = timeSeries1.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.util.Date date15 = year14.getEnd();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day16, (java.lang.Number) 0.0f);
        boolean boolean19 = timeSeries13.getNotify();
        java.lang.Object obj20 = timeSeries13.clone();
        timeSeries13.setNotify(false);
        timeSeries13.delete(0, 0, true);
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries1.addAndOrUpdate(timeSeries13);
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month();
        timeSeries29.add((org.jfree.data.time.RegularTimePeriod) month30, (java.lang.Number) (byte) 10, false);
        timeSeries29.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month();
        timeSeries37.add((org.jfree.data.time.RegularTimePeriod) month38, (java.lang.Number) (byte) 10, false);
        timeSeries37.setNotify(false);
        java.util.Collection collection44 = timeSeries29.getTimePeriodsUniqueToOtherSeries(timeSeries37);
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = timeSeries37.getDataItem((org.jfree.data.time.RegularTimePeriod) year45);
        timeSeriesDataItem46.setValue((java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries1.addOrUpdate(timeSeriesDataItem46);
        double double50 = timeSeries1.getMinY();
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2147483647 + "'", int11 == 2147483647);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(timeSeries27);
        org.junit.Assert.assertNotNull(collection44);
        org.junit.Assert.assertNotNull(timeSeriesDataItem46);
        org.junit.Assert.assertNotNull(timeSeriesDataItem49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 1.0d + "'", double50 == 1.0d);
    }
}

